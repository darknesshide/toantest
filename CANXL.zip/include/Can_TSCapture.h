/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_TSCapture.h                                                                                     */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024, 2025 Renesas Electronics Corporation. All rights reserved.                                               */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Controller register structure                                                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        X5H                                                                                   */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.1: 03/10/2025 : Update macro cover for API
 * 1.1.0: 18/07/2025 : Add CAN_GCTR_TSRST_SET, CAN_GCFG_TSSS_SET, CAN_GCFG_TSP_MASK
                     : Update Can_HwGetEgressTimeStamp
 * 1.0.3: 24/04/2025 : Change Can_TimeStampType to TimeStampType
 * 1.0.2: 28/03/2025 : Support QAC version 11.6.0
 * 1.0.0: 03/10/2024 : Initial version
 */
/**********************************************************************************************************************/

#ifndef CAN_TS_CAPTURE_H
#define CAN_TS_CAPTURE_H

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"
#if (((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)) \
    || ((CAN_CANXL_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_CANXL_SUPPORTED == STD_ON)))
extern FUNC(boolean, CAN_PRIVATE_CODE) Can_TSCapUnitInit(CONST(uint8, AUTOMATIC) LucNoOfUnits);
#if  (CAN_DEVICE_NAME == CAN_X5X)
extern FUNC(void, CAN_PRIVATE_CODE) Can_TSCapUnitDeInit(CONST(uint8, AUTOMATIC) LucUnit);
#endif /* #if (CAN_DEVICE_NAME == CAN_X5X)  */
#endif
#if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
#if  (CAN_DEVICE_NAME == CAN_X5X)
extern FUNC(void, CAN_PRIVATE_CODE) Can_TSCapChStart(CONST(uint8, AUTOMATIC) LucChannel);

extern FUNC(void, CAN_PRIVATE_CODE) Can_HwGetCurrentTime(uint8 LucControllerId, 
                                    P2VAR(Can_TimeStampType, AUTOMATIC, CAN_APPL_DATA) LpTimeStampPtr);                 /* PRQA S 3432 # JV-01 */
#endif
extern FUNC(void, CAN_PRIVATE_CODE) Can_HwGetEgressTimeStamp(CONST(uint16, AUTOMATIC) LucHthId,
  CONST(uint8, AUTOMATIC) LucController,
  CONST(uint32, AUTOMATIC) LulTSRAMOffset);
extern FUNC(void, CAN_PRIVATE_CODE) Can_HwGetIngressTimeStamp(CONST(uint16, AUTOMATIC) LucHohId,
  CONST(uint8, AUTOMATIC) LucController, CONST(uint32, AUTOMATIC) LulTSRAMOffset);
#endif
#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
/* Mask for set sleep Can Time Sync Hw */
#define CAN_GTSSLCTRL_SLEEP_SET                                 0x00000001UL
#define CAN_GFDCFG_TSCCFG_VALID_INDICATION                      (0x01UL << 8UL)
#define CAN_PTPTMEC_TE_SET                                      0x00000003UL
#define CAN_EXTSCTR_EXTSEN_SET                                  0x00000001UL
#define CAN_PTPTMDC_DISABLE                                     0x00000003UL
/* Bit indicate Rx or Tx capture is enable */
#define CAN_TSSELCFG_TXMASK_SET                                 (0x01UL << 9UL)
#define CAN_TSSELCFG_RXMASK_SET                                 (0x01UL << 8UL)
/* Number maximum supported gPTP Timer */
#define CAN_MAX_GPTP_TIMER_NUMBER                               0x02U
/* Address offset of Can Time Stampe ID register */
#define CAN_TIME_STAMP_ID_OFFSET                                0x00000004UL
/* Time Stample Offset */
#define CAN_THLACC0_TMTS_OFFSET                                 16UL
#define CAN_THLACC0_TMTS_MASK                                   0x0000FFFFUL
#define CAN_XXPTR_XXTS_MASK                                     0x0000FFFFUL
#define CAN_GCTR_TSRST_SET                                     (0x01UL << 16UL)
/* GENTOOL OUTPUT */
#define CAN_GCFG_TSSS_SET                                       (0xFFFFEFFFUL)
#define CAN_GCFG_TSP_MASK                                       (0x00000F00UL)
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
#endif /* #ifndef CAN_TS_CAPTURE_H */
