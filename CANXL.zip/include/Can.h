/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can.h                                                                                               */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024 - 2026 Renesas Electronics Corporation. All rights reserved.                                              */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains macros, CAN type definitions, enumerations,                                                     */
/* data types and API function prototypes of CAN Driver.                                                              */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.2: 05/05/2025 : Update CAN_SW_PATCH_VERSION for X5H
 * 1.3.1: 09/03/2026 : Remove CAN_PERIPHERAL_CLOCK, update CAN_SW_PATCH_VERSION
                       Add CAN_E_INVALID_CORE, add Os.h, ucKernelCoreID
 *        23/01/2026 : Update CAN_SW_PATCH_VERSION for X5H
 * 1.3.0: 15/01/2026 : Update CAN_SW_MINOR_VERSION for U5x
 * 1.2.2: 31/12/2025 : Update CAN_SW_PATCH_VERSION for X5H
 * 1.2.1: 28/11/2025 : Update CAN_SW_PATCH_VERSION for X5H
 * 1.2.0: 14/11/2025 : Update CAN_SW_PATCH_VERSION
 * 1.1.2: 28/10/2025 : Update CAN_SW_PATCH_VERSION for X5H
 * 1.1.1: 28/09/2025 : Update CAN_SW_PATCH_VERSION
 * 1.1.0: 21/08/2025 : Add new function Can_InitDetCheck 
 *        23/07/2025 : Change TimeStampType to Can_TimeStampType
 *                     Add macro device name
 *                     Update CAN_SW_PATCH_VERSION
 * 1.0.5  18/06/2025 : Add macro CAN_E_INV_MODE  
 *        23/06/2025 : Increase CAN_SW_PATCH_VERSION
 * 1.0.4: 09/06/2025 : Update patch version
                     : Remove unuse memory section
 * 1.0.3: 24/04/2025 : Change Can_TimeStampType to TimeStampType
 *                   : Update Module Software version information
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/

#ifndef CAN_HEADER
#define CAN_HEADER

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/

/* Register structure Header file */
#include "Can_CommonRegStruct.h"

/* CAN Pre-compile configuration Header File */
#include "Can_Cfg.h"

/* include mc33 lib */
#if (CAN_DEVICE_NAME == CAN_U5X)
#include "mcal_Types.h"
#endif

/* Included for the declaration of Det_ReportError() */
/* and Det_ReportRuntimeError */
#include "Det.h"

/* CAN Driver GeneralTypes Header File */
#include "Can_GeneralTypes.h"

/* Included for declaration of MainFunction in scheduler */
#include "SchM_Can.h"

/* Include Autosar Com Type */
#include "ComStack_Types.h"

/* Include specific Register struct */
#include "Can_RegStruct.h"
#if (CAN_CANXL_SUPPORTED == STD_ON)
#include "CanXL_RegStruct.h"
#endif
#if (CAN_MULTI_CORE_SUPPORT == STD_ON)
#include "Os.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

#define CAN_VENDOR_ID      CAN_VENDOR_ID_VALUE
#define CAN_MODULE_ID      CAN_MODULE_ID_VALUE
#define CAN_INSTANCE_ID    CAN_INSTANCE_ID_VALUE

/* AUTOSAR release version information */
#define CAN_AR_R23_11_VERSION           490

#define CAN_AR_RELEASE_MAJOR_VERSION    4U
#define CAN_AR_RELEASE_MINOR_VERSION    9U
#define CAN_AR_RELEASE_REVISION_VERSION 0U                                                                              /* PRQA S 0791 # JV-01 */

#if (CAN_DEVICE_NAME == CAN_X5X)
/* Module Software version information */
#define CAN_SW_MAJOR_VERSION            1U
#define CAN_SW_MINOR_VERSION            5U
#define CAN_SW_PATCH_VERSION            32U
#elif (CAN_DEVICE_NAME == CAN_U5X)
#define CAN_SW_MAJOR_VERSION            1U
#define CAN_SW_MINOR_VERSION            3U
#define CAN_SW_PATCH_VERSION            1U
#endif


/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3684)    : Array declared with unknown size.                                                            */
/* Rule                : CERTCCM ARR02, MISRA C:2012 Rule-8.11                                                        */
/* JV-01 Justification : Arrays used are verified in the file which are only declarations and size is configuration   */
/*                       dependent.                                                                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7, CWE Rule CWE-398, CWE-569                                            */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1336)    : Parameter identifiers missing in declaration of a function type.                             */
/* Rule                : MISRA C:2012 Rule-8.2, CWE Rule CWE-398, CWE-569                                             */
/* JV-01 Justification : Parameter identifiers are  missing however not impact the MCAL operation.                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0791)    : [U] Macro identifier does not differ from other macro identifier(s) (e.g. '%s') within       */
/*                       the specified number of significant characters.                                              */
/* Rule                : CERTCCM DCL23, MISRA C:2012 Rule-5.4                                                         */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule (Symbolic Name or Published         */
/*                       Macro's name), so this is accepted.                                                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
#define Can_CommonReturnType          Std_ReturnType
#define CAN_COMMON_OK                  E_OK
#define CAN_COMMON_NOT_OK              E_NOT_OK

#define Can_CommonControllerStateType Can_ControllerStateType
#define CAN_COMMON_STATE_UNINIT        CAN_CS_UNINIT
#define CAN_COMMON_STATE_STARTED       CAN_CS_STARTED
#define CAN_COMMON_STATE_STOPPED       CAN_CS_STOPPED
#define CAN_COMMON_STATE_SLEEP         CAN_CS_SLEEP
#define CAN_COMMON_STATE_WAKEUP
#define CAN_MAX_VALID_STATE_TRANSITION CAN_CS_SLEEP
#define CAN_COMMON_IF_STATE_STARTED    CAN_CS_STARTED
#define CAN_COMMON_IF_STATE_STOPPED    CAN_CS_STOPPED
#define CAN_COMMON_IF_STATE_SLEEP      CAN_CS_SLEEP
#define CAN_ZERO                       (uint8)0x00U
#define CAN_FOUR                       (uint8)0x04U
/***********************************************************************************************************************
**                                                    Service IDs                                                     **
***********************************************************************************************************************/
/* Service ID for Can_Init */
#define CAN_INIT_SID                   (uint8)0x00U
/* Service ID for Can_MainFunction_Write */
#define CAN_MAIN_WRITE_SID             (uint8)0x01U
/* Service ID for Can_SetControllerMode */
#define CAN_SET_MODECNTRL_SID          (uint8)0x03U
/* Service ID for Can_DisableControllerInterupts */
#define CAN_DISABLE_CNTRL_INT_SID      (uint8)0x04U
/* Service ID for Can_EnableControllerInterupts */
#define CAN_ENABLE_CNTRL_INT_SID       (uint8)0x05U
/* Service ID for Can_Write */
#define CAN_WRITE_SID                  (uint8)0x06U
/* Service ID for Can_GetVersionInfo */
#define CAN_GET_VERSIONINFO_SID        (uint8)0x07U
/* Service ID for Can_MainFunction_Read */
#define CAN_MAIN_READ_SID              (uint8)0x08U
/* Service ID for Can_MainFunction_BusOff */
#define CAN_MAIN_BUSOFF_SID            (uint8)0x09U
/* Service ID for Can_MainFunction_Wakeup */
#define CAN_MAIN_WAKEUP_SID            (uint8)0x0AU
/* Service ID for Can_CheckWakeup */
#define CAN_CHECK_WAKEUP_SID           (uint8)0x0BU
/* Service ID for Can_MainFunction_Mode */
#define CAN_MAIN_MODE_SID              (uint8)0x0CU
/* Service ID for Can_ChangeBaudrate */
#define CAN_CHANGE_BAUDRATE_SID        (uint8)0x0DU
/* Service ID for Can_CheckBaudrate */
#define CAN_CHECK_BAUDRATE_SID         (uint8)0x0EU
/* Service ID for Can_SetBaudrate */
#define CAN_SET_BAUDRATE_SID           (uint8)0x0FU
/* Service ID for Can_DeInit */
#define CAN_DEINIT_SID                 (uint8)0x10U
/* Service ID for Can_GetControllerErrorState */
#define CAN_GET_ERRSTATECNTRL_SID      (uint8)0x11U
/* Service ID for Can_GetControllerMode */
#define CAN_GET_MODECNTRL_SID          (uint8)0x12U
/* Service ID for Can_RxProcessing */
#define CAN_RXPROCESSING_SID           (uint8)0x13U
/* Service ID for Can_RAMTest */
#define CAN_RAMTEST_SID                         (uint8)0x22U
/* Service ID for Can_SelfTestChannel */
#define CAN_SELFTEST_CHANNEL_SID                (uint8)0x23U
/* Service ID for Can_GetCurrentTime */
#define CAN_GETCURRENTTIME_SID        (uint8)0x32U
/* Service ID for Can_EnableEgressTime */
#define CAN_ENABLEEGRESSTIME_SID      (uint8)0x33U
/* Service ID for Can_GetEgressTime */
#define CAN_GETEGRESSTIME_SID         (uint8)0x34U
/* Service ID for Can_GetIngressTime */
#define CAN_GETINGRESSTIME_SID         (uint8)0x35U

/* DET ERRORS */
/* API service called with null Pointer */
#define CAN_E_PARAM_POINTER            (uint8)0x01U
/* API service called with wrong Handle */
#define CAN_E_PARAM_HANDLE             (uint8)0x02U
/* API service called with wrong Controller Id */
#define CAN_E_PARAM_CONTROLLER         (uint8)0x04U
/* API service called with de-initialization */
#define CAN_E_UNINIT                   (uint8)0x05U
/* API service called with wrong Transition */
#define CAN_E_TRANSITION               (uint8)0x06U
/* API service called with wrong Data length */
#define CAN_E_PARAM_DATA_LENGTH        (uint8)0x03U
/* Received CAN Message is lost */
#define CAN_E_DATALOST                 (uint8)0x01U
/* API service called with invalid baudrate value */
#define CAN_E_PARAM_BAUDRATE           (uint8)0x07U
/* API service called with invalid configuration set selection */
/* API service called when CANFD is not in Global Stop mode */
#define CAN_RAMTEST_E_INITIALIZED             (uint8)0x14U
/* API service called with BlockId is out of range */
#define CAN_RAMTEST_E_OUT_OF_RANGE            (uint8)0x15U
#define CAN_E_INIT_FAILED              (uint8)0x09U
/* Service ID for Can_GetControllerRxErrorCounter */
#define CAN_GET_CONTROLLER_RXERROR_COUNTER_SID  (uint8)0x30U
/* Service ID for Can_GetControllerTxErrorCounter */
#define CAN_GET_CONTROLLER_TXERROR_COUNTER_SID  (uint8)0x31U
/* API service called with wrong database address */
#define CAN_E_INVALID_DATABASE         (uint8)0xEFU
/* Invalid mode */
#define CAN_E_INV_MODE                  (uint8)0x21U

#if (CAN_MULTI_CORE_SUPPORT == STD_ON)
#define CAN_E_INVALID_CORE          (uint8)0xF1U
#endif

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
/* CAN Driver Initialization configuration */
typedef struct STag_Can_ConfigType
{
  /* StartOfDbToc */
  VAR(uint32, AUTOMATIC) ulStartOfDbToc;
  /* Element number of HWUnitInfo */
  VAR(uint8, AUTOMATIC) ucNoOfUnits;
  /* Element number of pControllerPCConfig and pControllerPBConfig */
  VAR(uint8, AUTOMATIC) ucNoOfControllers;
  /* Element number of pHohConfig */
  VAR(uint16, AUTOMATIC) usNoOfHohs;
  /* Pointer to HWUnit configuration structures */
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pHWUnitInfo;                                                                  /* PRQA S 3432 # JV-01 */
  #endif
  #if (CAN_DEVICE_NAME == CAN_X5X)
  #if (((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)) || \
      ((CAN_CANXL_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_CANXL_SUPPORTED == STD_ON)))
  /* Pointer to gPTP Timer configuration structures */
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pHWgPTPInfo;                                                                  /* PRQA S 3432 # JV-01 */
  /* Element number of pHWgPTPInfo */
  VAR(uint8, AUTOMATIC) ucCanNoOfgPTPTimer;
  #endif
  #endif
  /* Pointer to Controller Pre-compile Configuration structures */
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pControllerPCConfig;                                                          /* PRQA S 3432 # JV-01 */
  /* Pointer to Controller Post-build Configuration structures */
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pControllerPBConfig;                                                          /* PRQA S 3432 # JV-01 */
  /* Pointer to HTH/HRH configuration structures */
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pHohConfig;                                                                   /* PRQA S 3432 # JV-01 */
  #if(CAN_CANXL_SUPPORTED == STD_ON)
  /* Element number of pHohConfig */
  VAR(uint16, AUTOMATIC) usCanXLNoOfHohs;
  /* Pointer to CanXLHWUnit configuration structures */
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pCanXLHWUnitInfo;                                                             /* PRQA S 3432 # JV-01 */
  /* Pointer to HTH/HRH configuration structures */
  P2CONST(void, TYPEDEF, CAN_CONFIG_DATA) pCanXLHohConfig;                                                              /* PRQA S 3432 # JV-01 */
  /* Lookup table to get index of Controller from physical number of Channel */
  P2CONST(uint8, TYPEDEF, CAN_CONFIG_DATA) pCanXLPhysicalControllerToIndex;                                             /* PRQA S 3432 # JV-01 */
  /* Lookup table to get index of Controller from physical number of Channel */
  P2CONST(uint8, TYPEDEF, CAN_CONFIG_DATA) pCanXLSecondPhysicalControllerToIndex;                                       /* PRQA S 3432 # JV-01 */
  #endif 
  /* Lookup table to get index of Controller from physical number of Channel */
  P2CONST(uint8, TYPEDEF, CAN_CONFIG_DATA) pPhysicalControllerToIndex;                                                  /* PRQA S 3432 # JV-01 */
  #if(CAN_RX_OBJECT == STD_ON)
  P2CONST(uint16, TYPEDEF, CAN_CONFIG_DATA) pCanGusHrhIndex2Id;                                                         /* PRQA S 3432 # JV-01 */
  #endif
  #if (CAN_TX_COMFIFO == STD_ON)
  P2CONST(uint16, TYPEDEF, CAN_CONFIG_DATA) pCanGusHthCOMFIFO2Id;                                                       /* PRQA S 3432 # JV-01 */
  #endif
  P2FUNC(boolean, TYPEDEF, pLpduCalloutReceiveFunction)(uint16, Can_IdType, uint8, const uint8*);                       /* PRQA S 3432, 1336 # JV-01, JV-01 */
  #if (((CAN_DEV_ERROR_DETECT == STD_ON) || (CAN_RX_FIFO == STD_ON)) && (CAN_MULTI_CORE_SUPPORT == STD_ON))
  VAR(uint8, CAN_CONFIG_DATA) ucKernelCoreID;
  #endif
  #if ((CAN_RX_COMFIFO == STD_ON) || (CAN_RX_FIFO == STD_ON))
  /* Element total number of HRH RxFIFO */
  VAR(uint16, AUTOMATIC) ucTotalHrhRxFIFO;
  #endif
  #if ((CAN_RX_COMFIFO == STD_ON) || (CAN_RX_BUFFER == STD_ON))
  #if (CAN_NO_OF_UNITS == 2U)
  /* Element total number of HRH RXFIFO and COMFIFO of 1 unit */
  VAR(uint16, AUTOMATIC) ucTotalHrhComFIFO0;
  #endif /* #if (CAN_NO_OF_UNITS == 2U) */
  /* Element total number of HRH RXFIFO and COMFIFO */
  VAR(uint16, AUTOMATIC) ucTotalHrhComFIFO;
  #endif /* #if (CAN_RX_COMFIFO == STD_ON) */
  #if (CAN_RX_BUFFER == STD_ON)
  #if (CAN_NO_OF_UNITS == 2U)
  /* Element total number of HRH 1 unit */
  VAR(uint16, AUTOMATIC) ucTotalHrhBuffer0;
  #endif /* #if (CAN_NO_OF_UNITS == 2U) */
  /* Element total number of HRH */
  VAR(uint16, AUTOMATIC) ucTotalHrhBuffer;
  #endif /* #if (CAN_RX_BUFFER == STD_ON) */
  #if (CAN_TX_COMFIFO == STD_ON)
  /* Element total number of HTH COMFIFO */
  VAR(uint16, AUTOMATIC) ucTotalHthComFIFO;
  #endif
  #if (CAN_ENABLE_DMA_MODE == STD_ON)
  /* Pointer to table including value of DMAToHohIndex */
  P2CONST(uint32, TYPEDEF, CAN_CONFIG_DATA) pDMAToHohIndex;
  #endif
} Can_ConfigType;

#if (STD_ON == CAN_SELFTEST_API)
/* Enum declaration for Can_SelfTest */
typedef enum ETag_Can_SelfTestType
{
  /* Disable self-test */
  CAN_T_SELF_OFF = 0,
  /* Self-test mode 0 (External loopback mode) */
  CAN_T_SELF_EXTERNAL,
  /* Self-test mode 1 (Internal loopback mode) */
  CAN_T_SELF_INTERNAL
} Can_SelfTestType;
#endif

#if (STD_ON == CAN_GLOBAL_TIME_SUPPORT) && (CAN_DEVICE_NAME == CAN_X5X)
typedef enum ETag_Can_TimeStampProtolType
{
  /* Time Stamp is captured in gPTP standard */
  CAN_TIMESTAMP_GPTP = 0,
  /* Time Stamp is captured in AVTP standard */
  CAN_TIMESTAMP_AVTP
} Can_TimeStampProtolType;
#endif
/***********************************************************************************************************************
**                                        Extern declarations for Global Data                                         **
***********************************************************************************************************************/
#define CAN_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Can_MemMap.h"
/* Global array for Config structure */
extern CONST(Can_ConfigType, CAN_CONST) Can_GaaConfig[];                                                                /* PRQA S 3684 # JV-01 */

#define CAN_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Can_MemMap.h"
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define CAN_START_SEC_PUBLIC_CODE
#include "Can_MemMap.h"

/* API for global initialization */
extern FUNC(void, CAN_PUBLIC_CODE) Can_Init(P2CONST(Can_ConfigType, AUTOMATIC, CAN_APPL_DATA) Config);                  /* PRQA S 3432 # JV-01 */

#if (CAN_SET_BAUDRATE_API == STD_ON)
/* API for changing baudrate of the Controller by ID value */
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_SetBaudrate(
  VAR(uint8, AUTOMATIC) Controller,
  VAR(uint16, AUTOMATIC) BaudRateConfigID);
#endif

/* API for set Controller mode */
extern FUNC(Can_CommonReturnType, CAN_PUBLIC_CODE) Can_SetControllerMode(
  VAR(uint8, AUTOMATIC) Controller, VAR(Can_CommonControllerStateType, AUTOMATIC) Transition);

/* API for global de-initialization */
extern FUNC(void, CAN_PUBLIC_CODE) Can_DeInit(void);

/* API for obtaining Controller error state */
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetControllerErrorState(
  VAR(uint8, AUTOMATIC) ControllerId, P2VAR(Can_ErrorStateType, AUTOMATIC, CAN_APPL_DATA) ErrorStatePtr);               /* PRQA S 3432 # JV-01 */

/* API for obtaining Controller mode */
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetControllerMode(
  VAR(uint8, AUTOMATIC) Controller, P2VAR(Can_ControllerStateType, AUTOMATIC, CAN_APPL_DATA) ControllerModePtr);        /* PRQA S 3432 # JV-01 */
  
#if (CAN_GLOBAL_TIME_SUPPORT == STD_ON) 
#if (CAN_DEVICE_NAME == CAN_X5X)
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetCurrentTime(VAR(uint8, AUTOMATIC) ControllerId, 
                                                       P2VAR(Can_TimeStampType, AUTOMATIC, CAN_APPL_DATA) timeStampPtr);/* PRQA S 3432 # JV-01 */

extern FUNC(void, CAN_PUBLIC_CODE) Can_EnableEgressTimeStamp(VAR(Can_HwHandleType, AUTOMATIC) Hth);
#endif

extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetEgressTimeStamp(PduIdType TxPduId,
            VAR(Can_HwHandleType, AUTOMATIC) Hth, P2VAR(Can_TimeStampType, AUTOMATIC, CAN_APPL_DATA) timeStampPtr);     /* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetIngressTimeStamp(VAR(Can_HwHandleType, AUTOMATIC) Hrh,
                                                       P2VAR(Can_TimeStampType, AUTOMATIC, CAN_APPL_DATA) timeStampPtr);/* PRQA S 3432 # JV-01 */
#endif

#if (STD_ON == CAN_SELFTEST_API)
/* API for Self-Test */
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_SelfTestChannel(
  VAR(uint8, AUTOMATIC) Controller,
  VAR(Can_SelfTestType, AUTOMATIC) TestTransition);
#endif

/* API for disabling Controller interrupt */
extern FUNC(void, CAN_PUBLIC_CODE) Can_DisableControllerInterrupts(VAR(uint8, AUTOMATIC) Controller);

/* API for enabling Controller interrupt */
extern FUNC(void, CAN_PUBLIC_CODE) Can_EnableControllerInterrupts(VAR(uint8, AUTOMATIC) Controller);

/* API for Can Write */
extern FUNC(Can_CommonReturnType, CAN_PUBLIC_CODE) Can_Write(
  VAR(Can_HwHandleType, AUTOMATIC) Hth,
  P2CONST(Can_PduType, AUTOMATIC, CAN_APPL_DATA) PduInfo);                                                              /* PRQA S 3432 # JV-01 */

#if (CAN_VERSION_INFO_API == STD_ON)
/* API for getting version information */
extern FUNC(void, CAN_PUBLIC_CODE) Can_GetVersionInfo(
                                                    P2VAR(Std_VersionInfoType, AUTOMATIC, CAN_APPL_DATA) versioninfo);  /* PRQA S 3432 # JV-01 */
#endif

/* API for getting wakeup status of a controller */
extern FUNC(Can_CommonReturnType, CAN_PUBLIC_CODE) Can_CheckWakeup(VAR(uint8, AUTOMATIC) Controller);

#if (CAN_RAMTEST_API == STD_ON)
#if (CAN_RSCANFD_CONFIGURED == STD_ON)
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_RAMTest(uint8 LucUnit, uint16 LusPageID);
#endif
#endif

extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetControllerTxErrorCounter(VAR(uint8, AUTOMATIC) ControllerId,
                                                             P2VAR(uint8, AUTOMATIC, CAN_APPL_DATA) TxErrorCounterPtr); /* PRQA S 3432 # JV-01 */
extern FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetControllerRxErrorCounter(VAR(uint8, AUTOMATIC) ControllerId,
                                                             P2VAR(uint8, AUTOMATIC, CAN_APPL_DATA) RxErrorCounterPtr); /* PRQA S 3432 # JV-01 */

#define CAN_STOP_SEC_PUBLIC_CODE
#include "Can_MemMap.h"

#if (CAN_DEV_ERROR_DETECT == STD_ON)
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"

/* API for common DET validation */
extern FUNC(Can_CommonReturnType, CAN_PRIVATE_CODE)
    Can_CommonDetCheck(CONST(uint8, AUTOMATIC) LucSID, CONST(uint8, AUTOMATIC) LucController);

extern FUNC(boolean, CAN_PRIVATE_CODE) Can_InitDetCheck(P2CONST(Can_ConfigType, AUTOMATIC, CAN_APPL_DATA) Config);      /* PRQA S 3432 # JV-01 */

#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"
#endif


#endif /* CAN_HEADER */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
