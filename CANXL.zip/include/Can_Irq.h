/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_Irq.h                                                                                           */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024 - 2026 Renesas Electronics Corporation. All rights reserved.                                              */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of declaration of ISR.                                                                                   */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.1: 27/03/2026 : Change ISR name and update precompile for CANXL
 *        09/03/2026 : Support interrupt for transmit, receive for CANFD, wake up for CANXL and DMA
 * 1.0.4: 31/12/2025 : Fix QAC message 1753
 * 1.0.3: 24/04/2025 : Remove duplicate macro CAN_PHYIDX_CONTROLLER5
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0841)    : Using '#undef'.                                                                              */
/* Rule                : MISRA C:2012 Rule-20.5, CWE Rule CWE-398, CWE-569                                            */
/* JV-01 Justification : This file compliant AUTOSAR format. So, there is need to use #undef.                         */
/*       Verification  : Incorrect declaration would result in compilation fails.                                     */
/**********************************************************************************************************************/

#ifndef CAN_IRQ_HEADER
#define CAN_IRQ_HEADER


/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for interrupt category definitions */
#include "Os.h"

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define CAN_IRQ_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION
#define CAN_IRQ_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION
#define CAN_IRQ_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION

/* File version information */
#define CAN_IRQ_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION
#define CAN_IRQ_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
/* EICn */
#define CAN_EIC_EIRF_MASK                   (uint16)0x1000U
#define CAN_EIC_EIMK_MASK                   (uint8)0x80U

/* Controller physical index */
#define CAN_PHYIDX_CONTROLLER0              0U
#define CAN_PHYIDX_CONTROLLER1              1U
#define CAN_PHYIDX_CONTROLLER2              2U
#define CAN_PHYIDX_CONTROLLER3              3U
#define CAN_PHYIDX_CONTROLLER4              4U
#define CAN_PHYIDX_CONTROLLER5              5U
#define CAN_PHYIDX_CONTROLLER6              6U
#define CAN_PHYIDX_CONTROLLER7              7U
#define CAN_PHYIDX_CONTROLLER8              8U
#define CAN_PHYIDX_CONTROLLER9              9U
#define CAN_PHYIDX_CONTROLLER10             10U
#define CAN_PHYIDX_CONTROLLER11             11U
#define CAN_PHYIDX_CONTROLLER12             12U
#define CAN_PHYIDX_CONTROLLER13             13U
#define CAN_PHYIDX_CONTROLLER14             14U
#define CAN_PHYIDX_CONTROLLER15             15U

#define CANXL_PHYIDX_CONTROLLER0            0U
#define CANXL_PHYIDX_CONTROLLER1            1U

#define CANXL_PRT_TXEVT_BIT                 (uint32)(1UL << 26UL)
#define CANXL_PRT_RXEVT_BIT                 (uint32)(1UL << 27UL)
#define CANXL_FQ_ISR_BIT                    (uint32)0xFFUL

/* Virtual Machine Channel index */
#define CAN_VM_CH0                   (uint8)0x00U
#define CAN_VM_CH1                   (uint8)0x01U
#define CAN_VM_CH2                   (uint8)0x02U
#define CAN_VM_CH3                   (uint8)0x03U
#define CAN_VM_CH4                   (uint8)0x04U
#define CAN_VM_CH5                   (uint8)0x05U
#define CAN_VM_CH6                   (uint8)0x06U
#define CAN_VM_CH7                   (uint8)0x07U
#define CAN_VM_CH8                   (uint8)0x00U
#define CAN_VM_CH9                   (uint8)0x01U
#define CAN_VM_CH10                  (uint8)0x02U
#define CAN_VM_CH11                  (uint8)0x03U
#define CAN_VM_CH12                  (uint8)0x04U
#define CAN_VM_CH13                  (uint8)0x05U
#define CAN_VM_CH14                  (uint8)0x06U
#define CAN_VM_CH15                  (uint8)0x07U
#define CAN_VM_INVALID               (uint8)0xFFU

#if ((CAN_VIRTUAL_MACHINE_ENABLE == STD_ON) && \
    ((CAN_VM0_RX_INTERRUPT == STD_ON) || \
     (CAN_VM1_RX_INTERRUPT == STD_ON) || \
     (CAN_VM2_RX_INTERRUPT == STD_ON) || \
     (CAN_VM3_RX_INTERRUPT == STD_ON) || \
     (CAN_VM4_RX_INTERRUPT == STD_ON) || \
     (CAN_VM5_RX_INTERRUPT == STD_ON) || \
     (CAN_VM6_RX_INTERRUPT == STD_ON) || \
     (CAN_VM7_RX_INTERRUPT == STD_ON) || \
     (CAN_VM8_RX_INTERRUPT == STD_ON) || \
     (CAN_VM9_RX_INTERRUPT == STD_ON) || \
     (CAN_VM10_RX_INTERRUPT == STD_ON) || \
     (CAN_VM11_RX_INTERRUPT == STD_ON) || \
     (CAN_VM12_RX_INTERRUPT == STD_ON) || \
     (CAN_VM13_RX_INTERRUPT == STD_ON) || \
     (CAN_VM14_RX_INTERRUPT == STD_ON) || \
     (CAN_VM15_RX_INTERRUPT == STD_ON)))
#define CAN_VM_RX_INTERRUPT_ON
#endif

#if ((CAN_VIRTUAL_MACHINE_ENABLE == STD_ON) && \
    ((CAN_VM0_TX_INTERRUPT == STD_ON) || \
     (CAN_VM1_TX_INTERRUPT == STD_ON) || \
     (CAN_VM2_TX_INTERRUPT == STD_ON) || \
     (CAN_VM3_TX_INTERRUPT == STD_ON) || \
     (CAN_VM4_TX_INTERRUPT == STD_ON) || \
     (CAN_VM5_TX_INTERRUPT == STD_ON) || \
     (CAN_VM6_TX_INTERRUPT == STD_ON) || \
     (CAN_VM7_TX_INTERRUPT == STD_ON) || \
     (CAN_VM8_TX_INTERRUPT == STD_ON) || \
     (CAN_VM9_TX_INTERRUPT == STD_ON) || \
     (CAN_VM10_TX_INTERRUPT == STD_ON) || \
     (CAN_VM11_TX_INTERRUPT == STD_ON) || \
     (CAN_VM12_TX_INTERRUPT == STD_ON) || \
     (CAN_VM13_TX_INTERRUPT == STD_ON) || \
     (CAN_VM14_TX_INTERRUPT == STD_ON) || \
     (CAN_VM15_TX_INTERRUPT == STD_ON)))
#define CAN_VM_TX_INTERRUPT_ON
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
#if ((CAN_CANXL_CONTROLLER0_RX_INTERRUPT == STD_ON) || (CAN_CANXL_CONTROLLER1_RX_INTERRUPT == STD_ON)  || \
     (CAN_CANXL_CONTROLLER2_RX_INTERRUPT == STD_ON) || (CAN_CANXL_CONTROLLER3_RX_INTERRUPT == STD_ON))
#define CANXL_CONTROLLER_RX_INTERRUPT_ON
#endif

#if ((CAN_CANXL_CONTROLLER0_TX_INTERRUPT == STD_ON) || (CAN_CANXL_CONTROLLER1_TX_INTERRUPT == STD_ON) || \
     (CAN_CANXL_CONTROLLER2_TX_INTERRUPT == STD_ON) || (CAN_CANXL_CONTROLLER3_TX_INTERRUPT == STD_ON))
#define CANXL_CONTROLLER_TX_INTERRUPT_ON
#endif

#endif
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define CAN_START_SEC_CODE_FAST
#include "Can_MemMap.h"


#if (CAN_CANXL_SUPPORTED == STD_ON)
#if (CAN_CANXL_CONTROLLER0_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER2_FUNC_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER02_FUNC_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 14 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER02_FUNC_ISR(void);
#endif
#endif

#if (CAN_CANXL_CONTROLLER1_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_FUNC_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER13_FUNC_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 15 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER13_FUNC_ISR(void);
#endif
#endif

#if (CAN_CANXL_CONTROLLER0_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER2_ERROR_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER02_ERR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 14 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER02_ERR_ISR(void);
#endif
#endif

#if (CAN_CANXL_CONTROLLER1_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_ERROR_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER13_ERR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 15 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER13_ERR_ISR(void);
#endif
#endif

#endif /* #if (CAN_CANXL_SUPPORTED == STD_ON) */

#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
#if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON)
#if defined(Os_CAN_RSCAN0_RXFIFO_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for global Receive FIFO handler of HW Unit 0*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_RSCAN0_RXFIFO_ISR(void);
#endif
#endif

#if (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)
#if defined(Os_CAN_RSCAN1_RXFIFO_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for global Receive FIFO handler of HW Unit 1*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_RSCAN1_RXFIFO_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER0_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0246_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0246_RX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER1_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER3_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER5_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER7_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1357_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1357_RX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER8_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8101214_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8101214_RX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER9_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER11_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER13_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER15_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9111315_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit Receive FIFO handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9111315_RX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER0_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0246_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0246_TX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER1_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER3_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER5_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER7_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1357_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1357_TX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER8_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8101214_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8101214_TX_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER9_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER11_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER13_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER15_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9111315_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9111315_TX_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER0_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER2_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER4_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER6_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0246_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for BusOff handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0246_ERROR_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER1_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER3_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER5_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER7_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1357_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for BusOff handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1357_ERROR_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER8_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER10_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER12_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER14_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8101214_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for BusOff handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8101214_ERROR_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER9_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER11_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER13_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER15_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9111315_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for BusOff handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9111315_ERROR_ISR(void);
#endif
#endif

#endif /* #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON) */

#if (CAN_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 0 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 1 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER2_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 2 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER2_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER3_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 3 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER3_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER4_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER4_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 4 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER4_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER5_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER5_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 5 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER5_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER6_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER6_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 6 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER6_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER7_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER7_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 7 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER7_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER8_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 8 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER9_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 9 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER10_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER10_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 10 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER10_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER11_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER11_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 11 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER11_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER12_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER12_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 12 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER12_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER13_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER13_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 13 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER13_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER14_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER14_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 14 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER14_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CONTROLLER15_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER15_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 15 */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER15_WAKEUP_ISR(void);
#endif
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON) && (CAN_WAKEUP_SUPPORT == STD_ON) 
#if (CANXL_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER0_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 0 for CANXL */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER0_WAKEUP_ISR(void);
#endif
#endif

#if (CANXL_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER1_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 1 for CANXL */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER1_WAKEUP_ISR(void);
#endif
#endif

#if (CANXL_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER2_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 3 for CANXL */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER2_WAKEUP_ISR(void);
#endif
#endif

#if (CANXL_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER3_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Wakeup handler of controller 3 for CANXL */
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER3_WAKEUP_ISR(void);
#endif
#endif
#endif

#if (CAN_ENABLE_DMA_MODE == STD_ON)
#if (CAN_DMA0_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA0_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA0_0246_ISR(void);
#endif
#endif /* End of (CAN_DMA0_0246_ISR_API == STD_ON) */

#if (CAN_DMA0_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA0_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA0_1357_ISR(void);
#endif
#endif /* End of (CAN_DMA0_1357_ISR_API == STD_ON) */

#if (CAN_DMA1_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA1_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA1_0246_ISR(void);
#endif
#endif /* End of (CAN_DMA1_0246_ISR_API == STD_ON) */

#if (CAN_DMA1_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA1_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA1_1357_ISR(void);
#endif
#endif /* End of (CAN_DMA1_1357_ISR_API == STD_ON) */

/* DMA 2 */


#if (CAN_DMA2_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA2_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA2_0246_ISR(void);
#endif
#endif /* End of (CAN_DMA2_0246_ISR_API == STD_ON) */

#if (CAN_DMA2_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA2_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA2_1357_ISR(void);
#endif
#endif /* End of (CAN_DMA2_1357_ISR_API == STD_ON) */

/* DMA 3 */

#if (CAN_DMA3_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA3_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA3_0246_ISR(void);
#endif
#endif /* End of (CAN_DMA3_0246_ISR_API == STD_ON) */

#if (CAN_DMA3_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA3_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA3_1357_ISR(void);
#endif
#endif /* End of (CAN_DMA3_1357_ISR_API == STD_ON) */


#endif /* (CAN_ENABLE_DMA_MODE == STD_ON) */

#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)
#if ((CAN_CONTROLLER0_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER0_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER0_ERROR_INTERRUPT == STD_ON))
#if defined (Os_CAN_CONTROLLER0_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER1_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER1_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER1_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER2_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER2_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER2_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER2_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER2_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER3_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER3_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER3_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER3_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER4_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER4_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER4_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER4_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER4_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER5_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER5_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER5_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER5_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER6_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER6_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER6_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER6_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER6_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER7_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER7_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER7_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER7_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER8_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER8_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER8_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER8_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER9_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER9_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER9_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER10_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER10_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER10_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER10_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER10_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER11_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER11_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER11_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER11_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER12_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER12_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER12_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER12_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER12_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER13_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER13_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER13_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER13_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER14_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER14_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER14_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER14_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER14_ISR(void);
#endif
#endif

#if ((CAN_CONTROLLER15_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER15_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER15_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for Transmit/Receive/ERROR handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER15_ISR(void);
#endif
#endif

#if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_UNIT0_GLOBAL_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for global Receive handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_UNIT0_GLOBAL_ISR(void);
#endif
#endif

#if (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_UNIT1_GLOBAL_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
/* ISR for global Receive handler of all CAN controllers*/
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_UNIT1_GLOBAL_ISR(void);
#endif
#endif

#if ((CAN_VM0_RX_INTERRUPT == STD_ON) || (CAN_VM0_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM0_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM0_ISR(void);
#endif
#endif

#if ((CAN_VM1_RX_INTERRUPT == STD_ON) || (CAN_VM1_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM1_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM1_ISR(void);
#endif
#endif

#if ((CAN_VM2_RX_INTERRUPT == STD_ON) || (CAN_VM2_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM2_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM2_ISR(void);
#endif
#endif

#if ((CAN_VM3_RX_INTERRUPT == STD_ON) || (CAN_VM3_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM3_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM3_ISR(void);
#endif
#endif

#if ((CAN_VM4_RX_INTERRUPT == STD_ON) || (CAN_VM4_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM4_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM4_ISR(void);
#endif
#endif

#if ((CAN_VM5_RX_INTERRUPT == STD_ON) || (CAN_VM5_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM5_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM5_ISR(void);
#endif
#endif

#if ((CAN_VM6_RX_INTERRUPT == STD_ON) || (CAN_VM6_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM6_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM6_ISR(void);
#endif
#endif

#if ((CAN_VM7_RX_INTERRUPT == STD_ON) || (CAN_VM7_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM7_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM7_ISR(void);
#endif
#endif

#if ((CAN_VM8_RX_INTERRUPT == STD_ON) || (CAN_VM8_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM8_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM8_ISR(void);
#endif
#endif

#if ((CAN_VM9_RX_INTERRUPT == STD_ON) || (CAN_VM9_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM9_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM9_ISR(void);
#endif
#endif

#if ((CAN_VM10_RX_INTERRUPT == STD_ON) || (CAN_VM10_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM10_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM10_ISR(void);
#endif
#endif

#if ((CAN_VM11_RX_INTERRUPT == STD_ON) || (CAN_VM11_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM11_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM11_ISR(void);
#endif
#endif

#if ((CAN_VM12_RX_INTERRUPT == STD_ON) || (CAN_VM12_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM12_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM12_ISR(void);
#endif
#endif

#if ((CAN_VM13_RX_INTERRUPT == STD_ON) || (CAN_VM13_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM13_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM13_ISR(void);
#endif
#endif

#if ((CAN_VM14_RX_INTERRUPT == STD_ON) || (CAN_VM14_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM14_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM14_ISR(void);
#endif
#endif

#if ((CAN_VM15_RX_INTERRUPT == STD_ON) || (CAN_VM15_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM15_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
/* Use ISR() macro from Os.h */
/* Defines the CAT1 interrupt mapping */
#else
extern _INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM15_ISR(void);
#endif
#endif

#endif

#define CAN_STOP_SEC_CODE_FAST
#include "Can_MemMap.h"

#endif /* CAN_IRQ_HEADER */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
