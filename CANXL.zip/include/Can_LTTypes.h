/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_LTTypes.h                                                                                       */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of AUTOSAR CAN Link time parameters.                                                                     */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.1: 06/04/2026 : Update description
 * 1.1.0: 03/10/2025 : Add macro device name, CangPTP_RegisterSetType and extern for CangPTP_GaaRegs  
 *        18/07/2025 : Add macro device name  
 *        10/06/2025 : Remove enum Can_MacroType and element enMacroType in Can_RegisterSetType struct
 *        09/06/2025 : Update Can_SubStatusType
 * 1.0.3: 24/04/2025 : Add message 3630
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/

#ifndef CAN_LTTYPES_HEADER
#define CAN_LTTYPES_HEADER

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#if (CAN_WAKEUP_SUPPORT == STD_ON)
#include "EcuM.h"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3684)    : Array declared with unknown size.                                                            */
/* Rule                : CERTCCM ARR02, MISRA C:2012 Rule-8.11                                                        */
/* JV-01 Justification : Arrays used are verified in the file which are only declarations and size is configuration   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0841)    : Using '#undef'.                                                                              */
/* Rule                : MISRA C:2012 Rule-20.5, CWE Rule CWE-398, CWE-569                                            */
/* JV-01 Justification : This file compliant AUTOSAR format. So, there is need to use #undef.                         */
/*       Verification  : Incorrect declaration would result in compilation fails.                                     */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*                       dependent.                                                                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0791)    : [U] Macro identifier does not differ from other macro identifier(s) (e.g. '%s') within the   */
/*                       specified number of significant characters.                                                  */
/*                       REFERENCE - ISO:C90-6.1.2 Identifiers - Implementation Limits                                */
/* Rule                : MISRA C:2012 Rule 5.4, CERTCCM DCL23                                                         */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule (Symbolic Name or Published Macro's */
/*                       name), so this is accepted.                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3630)    : The implementation of this struct/union type should be hidden.                               */
/* Rule                : MISRA C:2012 Dir-4.8                                                                         */
/* JV-01 Justification : This is accepted. Redundant of struct or union type has no affect to driver operation.       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define CAN_LTTYPES_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION
#define CAN_LTTYPES_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION
#define CAN_LTTYPES_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION

/* File version information */
#define CAN_LTTYPES_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION
#define CAN_LTTYPES_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
/* Flag not set */
#define CAN_FALSE                               (boolean)0
/* Flag set */
#define CAN_TRUE                                (boolean)1
/* The value indicates invalid index */
#define CAN_INVALID_INDEX                       (uint32)0xFFFFFFFFUL
/* Interupt mode or polling mode */
#define CAN_INT_DISABLED                        0x00U
#define CAN_CHECK_INT_TX                        0x01U
#define CAN_CHECK_INT_RX                        0x02U
#define CAN_CHECK_MIXED_RX                      0x10U
#define CAN_CHECK_INT_BUSOFF                    0x04U
#define CAN_CHECK_INT_WAKEUP                    0x08U
/* Can Bus Error Flag */
#define CAN_CHECK_INT_ERROR                     0x20U
/* Macro for controller with no wake up source enabled */
#define CAN_NOWAKEUP                            (uint8)0xFFU

/* Start address of database  */
#define CAN_DBTOC_VALUE\
  (((uint32)CAN_VENDOR_ID_VALUE << 22U) | ((uint32)CAN_MODULE_ID_VALUE << 14U) | \
   ((uint32)CAN_SW_MAJOR_VERSION_VALUE << 8U) | ((uint32)CAN_SW_MINOR_VERSION_VALUE << 3U))

/* The value after reset CAN channel status register */
#define CAN_T_UNINIT (uint32)0x00000005UL
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/

/* Can Controller Type*/
typedef enum ETag_Can_ControllerType
{
  /* This hardware unit is RSCANFD */
  CAN_FD,
  /* This hardware unit is CANXL */
  CAN_XL
} Can_ControllerType;

/* Sub-state during mode transition */
typedef enum ETag_Can_SubStatusType
{
  /* No Pending transitions in mode */
  CAN_NO_PENDING_TRANSITION = 0,

  /* Tentative state for the exclusive control b/w HW trigger and SW trigger */
  CAN_TENTATIVE_TRANSITION,

  /* Pending start mode to wait CHANNEL_RESET after bus-off */
  CAN_PENDING_START_WAIT_RESET,
  /* Pending start mode to wait for CHANNEL_COMMUNICATION */
  CAN_PENDING_START_WAIT_COM,

  /* Pending stop mode to wait for CHANEL_HALT before enter CHANNEL_RESET */
  CAN_PENDING_STOP_WAIT_HALT,
  /* Pending reset mode to wait for CHANNEL_RESET */
  CAN_PENDING_STOP_WAIT_RESET,

  /* Pending sleep mode to wait for CAHNNEL_STOP */
  CAN_PENDING_SLEEP_WAIT_STOP,
  /* Pending sleep mode to wait for GLOBAL_RESET when this is last Channel */
  CAN_PENDING_SLEEP_WAIT_GLOBALRESET,
  /* Pending sleep mode to wait for GLOBAL_STOP when this is last Channel */
  CAN_PENDING_SLEEP_WAIT_GLOBALSTOP,

  /* Wake-up is requested by ISR but not started yet */
  CAN_PENDING_WAKEUP_REQUESTED,
  /* Pending wakeup to wait for previous Global state transition */
  CAN_PENDING_WAKEUP_WAIT_GLOBALCHANGE,
  /* Pending wakeup to wait for GLOBAL_RESET after wakeup from deep sleep */
  CAN_PENDING_WAKEUP_WAIT_GLOBALRESET,
  /* Pending wakeup to wait for GLOBAL_OPERATION after wakeup from deep sleep */
  CAN_PENDING_WAKEUP_WAIT_GLOBALOP,
  /* Pending wakeup to wait for CHANNEL_RESET */
  CAN_PENDING_WAKEUP_WAIT_RESET,
  /* Pending Start to wait for RXQUEUE START */
  CANXL_START_WAIT_RXQUEUE_START,
  /* Pending Start to wait for PRT START */ 
  CANXL_START_WAIT_PRT_START,
  /* Pending Start to wait for BUSOFF RECOVERY */ 
  CANXL_START_WAIT_BUSOFF_RECOVERY,
  /* Pending Start to wait for PRT STOP */  
  CANXL_STOP_WAIT_PRT_STOP,
  /* Pending Start to wait for TXRXQUEUE STOP */  
  CANXL_STOP_WAIT_TXRXQUEUE_STOP,
  /* Pending Start to wait for MH STOP */  
  CANXL_STOP_WAIT_MH_STOP
} Can_SubStatusType;

#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
/* Interrupt Controller Unit Structure */
typedef struct STag_Can_ImfuType                                                                                        /* PRQA S 3630 # JV-01 */
{
  /* IRQ number of the Interrupt Vector Table */
  VAR(IRQn_Type, TYPEDEF) enInterruptID;
  /* 1. RS-CAN FD: bit for IMFULMSK/IMFUPMSK register  */
  /* 2. CAN XL U5Lx: not support interrupt merged function */
  /*    CAN XL U5Mx: support interrupt merged function */
  uint32 ulIMFUMaskVal;
  /* 1. RS-CAN FD: IMFU register address - IMFULFi - IMFU Level Status Register */
  /* 2. CAN XL: NULL_PTR - not support interrupt merged function */
  /*    CAN XL: != NULL_PTR - support interrupt merged function */
  volatile uint32 *pIMFU;
} Can_ImfuType;
#endif



/* Register base address information for each unit */
typedef struct STag_Can_RegisterSetType
{
  /* Pointer to register map that is common between RS-CAN and RS-CANFD */
  P2VAR(volatile Can_CommonRegType, TYPEDEF, REGSPACE) pCmn;                                                            /* PRQA S 3432 # JV-01 */
  /* Pointer to Receive Rule registers */
  P2VAR(volatile Can_RRuleRegType, TYPEDEF, REGSPACE) pRR;                                                              /* PRQA S 3432 # JV-01 */
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  /* Pointer to registers that is specified to RS-CANFD */
  P2VAR(volatile Can_FDRegType, TYPEDEF, REGSPACE) pFD;                                                                 /* PRQA S 3432 # JV-01 */
  #endif
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
  #if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON)
  /* NVIC & IMFU reigster info for RxFIFO interruption */
  P2CONST(Can_ImfuType, TYPEDEF, REGSPACE) pICRxFIFO;
  #endif
  #endif
  #if (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON)
  /* Wake-up factor register address */
  P2VAR(volatile uint32, TYPEDEF, REGSPACE) pWUF0Reg;                                                                   /* PRQA S 3432 # JV-01 */
  /* Wake-up factor clear register address */
  P2VAR(volatile uint32, TYPEDEF, REGSPACE) pWUFC0Reg;                                                                  /* PRQA S 3432 # JV-01 */
  #endif
  #if (CAN_ECC_ERROR_CORRECT == STD_ON)
  /* ECC control register address */
  P2VAR(volatile uint32, TYPEDEF, REGSPACE) pEC710CTLReg;                                                               /* PRQA S 3432 # JV-01 */
  #endif
  #if (CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_DEVICE_NAME == CAN_X5X)
  /* Pointer to register of Can Time Sync Capture unit */
  P2VAR(volatile Can_TSCapCmRegType, TYPEDEF, REGSPACE) pTsCm;                                                          /* PRQA S 3432 # JV-01 */
  #endif
} Can_RegisterSetType;

#if (CAN_DEVICE_NAME == CAN_X5X)
/* Register base address information for gPTP timer */
typedef struct STag_CangPTP_RegisterSetType
{
  /* Pointer to register map of gPTP */
  P2VAR(volatile Can_TSgPTPTimerRegType, AUTOMATIC, REGSPACE) pTSgPTP;                                                  /* PRQA S 3432 # JV-01 */
} CangPTP_RegisterSetType;
#endif

/* CAN Controller Pre-compile Structure */
typedef struct STag_Can_ControllerPCConfigType
{
  #if (CAN_CANXL_SUPPORTED == STD_ON)
  /* Type of Can Controller */
  Can_ControllerType enControllerType;
  #endif
  /* Whether this Controller is used */
  VAR(boolean, AUTOMATIC) blActivation;
  /* Index of Can_GaaRegs which this controller allocated to */
  VAR(uint8, AUTOMATIC) ucUnit;
  /* Index of physical Channel which this controller allocated to */
  VAR(uint8, AUTOMATIC) ucCh;
  /* Polling/Interrupt for each operation */
  VAR(uint8, AUTOMATIC) ucIntEnable;
  /* Value of CmCTR, including error interrupt enable bits (bit 8-16) */
  VAR(uint32, AUTOMATIC) ulCTR;
  /* Value of THLCCm except THLE bit */
  VAR(uint32, AUTOMATIC) ulTHLCC;
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)
  /* Channel EIC ID */
  VAR(uint32, AUTOMATIC) ulChannelEicID;
  #endif
  #if (CAN_VIRTUAL_MACHINE_ENABLE == STD_ON)
  /* Virtual Machine EIC ID */
  VAR(uint32, AUTOMATIC) ulVMEicID;
  #endif
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
  /* NVIC & IMFU reigster info for Rx interruption or XCAN functional relevant */
  P2CONST(Can_ImfuType, TYPEDEF, REGSPACE) pICRec;
  /* NVIC & IMFU reigster info for Tx interruption */
  P2CONST(Can_ImfuType, TYPEDEF, REGSPACE) pICTx;
  /* NVIC & IMFU reigster info for Error interruption or XCAN functional error relevant */
  P2CONST(Can_ImfuType, TYPEDEF, REGSPACE) pICErr;
  #endif
  #if (CAN_WAKEUP_SUPPORT == STD_ON)
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)
  /* Wake up EIC ID */
  VAR(uint32, AUTOMATIC) ulWakeUpEicID;
  #endif
  /* wakeup source ID to indicate upper layer */
  VAR(uint8, AUTOMATIC) ucWakeupSourceId;
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
  /* NVIC & IMFU reigster info for Wakeup interruption */
  P2CONST(Can_ImfuType, TYPEDEF, REGSPACE) pICWakeup;
  #endif
  #ifdef CAN_FILTER_CONTROL_SUPPORT
  /* FCLA register address for setting edge detection */
  P2VAR(volatile uint8, TYPEDEF, REGSPACE) pFCLAReg;
  #endif
  #endif /*  #if (CAN_WAKEUP_SUPPORT == STD_ON) */
  #if (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON)
  /* Mask for Wakeup factor clear register */
  VAR(uint32, AUTOMATIC) ulWUFMask;
  #endif
  #if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) || (CAN_CANXL_GLOBAL_TIME_SUPPORT == STD_ON)) && (CAN_DEVICE_NAME == CAN_X5X)
  /* Mask value for Timestamp Select Configuration Register */
  VAR(uint32, AUTOMATIC) ulTSSELCFG;
  #endif  
} Can_ControllerPCConfigType;

/* This structure includes statuses for each Controller */
typedef struct STag_Can_ControllerStateWrapperType
{
  /* Current Controller mode */
  VAR(Can_CommonControllerStateType, TYPEDEF) enMode;
  /* Sub-state during Controller is in mode transition */
  VAR(Can_SubStatusType, TYPEDEF) enSubState;
  /* Whether Controller is in bus-off state of not */
  VAR(boolean, AUTOMATIC) blBusOff;
  #if (CAN_WAKEUP_SUPPORT == STD_ON)
  /* Whether wakeup event occurred */
  VAR(boolean, AUTOMATIC) blWakeupEventOccurred;
  /* Whether wakeup is triggered by HW or SW */
  VAR(boolean, AUTOMATIC) blWakeupByHW;
  #endif
  /* Index of current baudrate */
  VAR(uint32, AUTOMATIC) ulBaudrateIndex;
  /* Recursive count of Can_DisableControllerInterrupts */
  VAR(uint32, AUTOMATIC) ulIntCount;
} Can_ControllerStateWrapperType;

#if (CAN_RAMTEST_API == STD_ON)
/* Enum deceleration for Can_RamTest */
typedef enum ETag_Can_RamTestWalkType
{
  CAN_RAMTEST_WALK_0 = 0,
  CAN_RAMTEST_WALK_1
} Can_RamTestWalkType;

typedef enum ETag_Can_RamTestFillType
{
  CAN_RAMTEST_FILL_0 = 0,
  CAN_RAMTEST_FILL_1
} Can_RamTestFillType;
#endif /* #if (CAN_RAMTEST_API == STD_ON) */

/*---------------------------------------------------------------------------------------------------------------------
 * CAN XL Specific
 ---------------------------------------------------------------------------------------------------------------------*/
#if (CAN_CANXL_SUPPORTED == STD_ON)
 /* Register base address information for each unit */
typedef struct STag_CanXL_RegisterSetType
{
  /* Pointer to register map that is used for Message Handler     */
  P2VAR(volatile CanXL_MHRegType, TYPEDEF, REGSPACE) pMH;                                                               /* PRQA S 3432 # JV-01 */
  /* Pointer to register map that is used for Protocol Controller */
  P2VAR(volatile CanXL_PRTRegType, TYPEDEF, REGSPACE) pPRT;                                                             /* PRQA S 3432 # JV-01 */
  /* Pointer to registers that is used for Interrupt Controller   */
  P2VAR(volatile CanXL_IRCRegType, TYPEDEF, REGSPACE) pIRC;                                                             /* PRQA S 3432 # JV-01 */
  /* Pointer to registers that is used for Global CANXL register   */
  P2VAR(volatile CanXL_GLBRegType, TYPEDEF, REGSPACE) pGLB;                                                             /* PRQA S 3432 # JV-01 */
#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)
  #if (CAN_CANXL_GLOBAL_TIME_SUPPORT == STD_ON)
  /* Pointer to register of Can Time Sync Capture unit */
  P2VAR(volatile Can_TSCapCmRegType, TYPEDEF, REGSPACE) pTsCm;                                                          /* PRQA S 3432 # JV-01 */
  #endif
#endif
} CanXL_RegisterSetType;

#endif /* #if (CAN_CANXL_SUPPORTED == STD_ON) */
/***********************************************************************************************************************
**                                        Extern declarations for Global Data                                         **
***********************************************************************************************************************/
#define CAN_START_SEC_CONFIG_DATA_PREBUILD_UNSPECIFIED
#include "Can_MemMap.h"
#if (CAN_RSCANFD_CONFIGURED == STD_ON)
/* Registers structure of RSCAN module */
extern CONST(Can_RegisterSetType, CAN_CONST) Can_GaaRegs[];                                                             /* PRQA S 3684 # JV-01 */
#endif
extern CONST(Can_ControllerPCConfigType, CAN_CONST) Can_GaaControllerPCConfig0[];                                       /* PRQA S 3684 # JV-01 */

#if (CAN_DEVICE_NAME == CAN_X5X)
#if (((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)) \
    || ((CAN_CANXL_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_CANXL_SUPPORTED == STD_ON)))
extern CONST(CangPTP_RegisterSetType, CAN_CONST) CangPTP_GaaRegs[];                                                     /* PRQA S 3684 # JV-01 */
#endif
#endif

#define CAN_STOP_SEC_CONFIG_DATA_PREBUILD_UNSPECIFIED
#include "Can_MemMap.h"

#define CAN_START_SEC_CONFIG_DATA_PREBUILD_8                                                                            /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"

extern CONST(uint8, CAN_CONFIG_DATA) Can_GaaPhysicalControllerToIndex0[];                                               /* PRQA S 3684 # JV-01 */
extern CONST(uint8, CAN_CONFIG_DATA) CanXL_GaaPhysicalControllerToIndex0[];                                             /* PRQA S 3684 # JV-01 */
extern CONST(uint8, CAN_CONFIG_DATA) CanXL_GaaSecondPhysicalControllerToIndex0[];                                       /* PRQA S 3684 # JV-01 */

#define CAN_STOP_SEC_CONFIG_DATA_PREBUILD_8                                                                             /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"

/*---------------------------------------------------------------------------------------------------------------------
 * CAN XL Specific
 ---------------------------------------------------------------------------------------------------------------------*/
#if (CAN_CANXL_SUPPORTED == STD_ON)
#define CAN_START_SEC_CONFIG_DATA_PREBUILD_UNSPECIFIED
#include "Can_MemMap.h"
/* Registers structure of XCAN module */
extern CONST(CanXL_RegisterSetType, CAN_CONST) CanXL_GaaRegs[CAN_CANXL_NO_OF_CONTROLLER];
#define CAN_STOP_SEC_CONFIG_DATA_PREBUILD_UNSPECIFIED
#include "Can_MemMap.h"
#endif 

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#endif /* CAN_LTTYPES_HEADER */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
