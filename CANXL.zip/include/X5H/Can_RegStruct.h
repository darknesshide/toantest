/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_RegStruct.h                                                                                     */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024,2025 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Controller register structure                                                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        X5H                                                                                   */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.2: 04/05/2025 : Add macro CAN_MAX_RSCANFD_UNIT, CAN_INVALID_VALUE
 * 1.1.1: 28/11/2025 : Update macro channel Wake-up factor value
 * 1.1.0: 03/10/2025 : Update Can_TSgPTPConfigRegType;Can_TSgPTPTimerRegType
 * 1.0.2: 24/04/2025 : Remove macro CAN_INTERFACE_MODE_SELECTION_LOCATION
 *                   : Add macro CAN_RSCAN_THLEFT
 *        28/03/2025 : Support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 01/10/2024 : Initial Version
 */
/******************************************************************************/
#ifndef CAN_REGSTRUCT_H
#define CAN_REGSTRUCT_H

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/* AUTOSAR release version information */
#define CAN_REGSTRUCT_AR_RELEASE_MAJOR_VERSION                                                                          \
                                                 CAN_AR_RELEASE_MAJOR_VERSION
#define CAN_REGSTRUCT_AR_RELEASE_MINOR_VERSION                                                                          \
                                                 CAN_AR_RELEASE_MINOR_VERSION
#define CAN_REGSTRUCT_AR_RELEASE_REVISION_VERSION                                                                       \
                                                 CAN_AR_RELEASE_REVISION_VERSION

/* File version information */
#define CAN_REGSTRUCT_SW_MAJOR_VERSION    CAN_SW_MAJOR_VERSION
#define CAN_REGSTRUCT_SW_MINOR_VERSION    CAN_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0750)    : A union type specifier has been defined.                                                     */
/* Rule                : MISRA C:2012 Rule-19.2                                                                       */
/* JV-01 Justification : This union type is used for register accessing and there is no issue with this usage.        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3472)    : All toplevel uses of this function-like macro look like they could be replaced by            */
/*                       equivalent function calls.                                                                   */
/* Rule                : MISRA C:2012 Dir-4.9                                                                         */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3630)    : The implementation of this struct/union type should be hidden.                               */
/* Rule                : MISRA C:2012 Dir-4.8                                                                         */
/* JV-01 Justification : This is accepted. Redundant of struct or union type has no affect to driver operation.       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Symbols                                                  **
***********************************************************************************************************************/
/* NVIC support */
#define CAN_INTERRUPT_NVIC_SUPPORT                                                STD_OFF
/* Index of the default baudrate index of Can_BaudrateConfigType array */
#define CAN_DEFAULT_BAUDRATE_INDEX              0U

/* Support common FIFO enhancement register */
#define CAN_COMFIFO_ENHANCEMENT_SUPPORT

/* Support Receive FIFO full interrupt */
#define CAN_RX_FIFO_FULL_INNTERRUPT_SUPPORT

/* Location of label data field */
#define CAN_LABEL_DATA_LOCATION                         CAN_CTR_REG

/* Create a word data from four byte data */
#define CAN_RSCAN_CREATEWORD(byte0, byte1, byte2, byte3)                                                                /* PRQA S 3472 # JV-01 */\
  ((uint32)(byte0) | ((uint32)(byte1) << 8UL) | ((uint32)(byte2) << 16UL) | ((uint32)(byte3) << 24UL))

/* Number of Tx History List entries per controller */
#define CAN_RSCAN_THL_ENTRIES_PER_CH     32UL

/* Number of tx buffers per controller */
#define CAN_RSCAN_TXBUFFER_PER_CH     64UL

/* Number of RxFIFO per unit */
#define CAN_RSCAN_RXFIFO_PER_UNIT     8UL

/* Number of TxRxFIFO per controller */
#define CAN_RSCAN_TXRXFIFO_PER_CH     3UL

/* Number of TxQUEUE per controller */
#define CAN_RSCAN_TXQUEUE_PER_CH     4UL

/* Number of TxQUEUE per controller (enable for GATEWAY mode) */
#define CAN_RSCAN_GW_TXQUEUE_PER_CH  3U

/* Max depth of TxQUEUE */
#define CAN_RSCAN_TXQUEUE_MAX_DEPTH  32UL

/* Number queue depth reserved */
#define CAN_RSCAN_TXQUEUE_RESERVED    32UL

/* Number of CFDRMNDt per unit */
#define CAN_RSCAN_MAX_RMND_PER_UNIT  4UL

/* Max RSCANFD unit*/
#define CAN_MAX_RSCANFD_UNIT    2U

/* Invalid value for ramtest */
#define CAN_INVALID_VALUE       0xFFU

/* Get number of FIFO Buffer Depth (number of messages) */
#define CAN_RSCAN_FIFO_BUFFER_DEPTH_GET(x)                                                                              \
  (uint8)(((uint8)(x) == 1U) ? 4U   : \
         (((uint8)(x) == 2U) ? 8U   : \
         (((uint8)(x) == 3U) ? 16U  : \
         (((uint8)(x) == 4U) ? 32U  : \
         (((uint8)(x) == 5U) ? 48U  : \
         (((uint8)(x) == 6U) ? 64U  : \
         (((uint8)(x) == 7U) ? 128U : 0U )))))))

/* Get number of TX Queue Depth (number of messages) */
#define CAN_RSCAN_TX_QUEUE_DEPTH_GET(x)  (((uint32)(x) > 1UL) ? ((uint32)(x) + 1UL) : ((uint32)(x)))                    /* PRQA S 3472 # JV-01 */

/* GCFG */
#define CAN_RSCAN_GCFG_DEFAULT  0x00000000UL
#define CAN_RSCAN_ITRCP(x)      ((uint32)(x) << 16UL)
#define CAN_RSCAN_CMPOC         0x00000020UL
#define CAN_RSCAN_DCS           0x00000010UL
#define CAN_RSCAN_MME           0x00000008UL
#define CAN_RSCAN_DCE           0x00000002UL
#define CAN_RSCAN_TPRI          0x00000001UL

/* GFDCFG */
#define CAN_RSCAN_GFDCFG_DEFAULT 0x00000000UL

/* GCTR */
#define CAN_RSCAN_GSLPR       0x00000004UL
#define CAN_RSCAN_GMDC_MASK   0x00000003UL
#define CAN_RSCAN_GMDC_OP     0x00000000UL
#define CAN_RSCAN_GMDC_RESET  0x00000001UL
#define CAN_RSCAN_GMDC_TEST   0x00000002UL

/* GSTS */
#define CAN_RSCAN_GRAMINIT    0x00000008UL
#define CAN_RSCAN_GSTSMASK    0x00000007UL
#define CAN_RSCAN_GSLPSTS     0x00000004UL
#define CAN_RSCAN_GHLTSTS     0x00000002UL
#define CAN_RSCAN_GRSTSTS     0x00000001UL
#define CAN_RSCAN_GOPSTS      0x00000000UL

/* GERFL */
#define CAN_RSCAN_GERFL_DEF       0x00000001UL
#define CAN_RSCAN_GERFL_CLEAR     0x00000000UL
/* GAFLCFGw */
#define CAN_RSCAN_GAFLCFG_DEFAULT 0x00000000UL

/* GAFLECTR */
#define CAN_RSCAN_RULES_PER_PAGE 16UL
#define CAN_RSCAN_AFLDAE      0x00000100UL
#define CAN_RSCAN_AFLPN(x)    ((uint32)(x))                                                                             /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_AFLDAE_OFF  0x00000000UL

/* GAFLIDj */
/* GAFLIDr (X5H) */
#define CAN_RSCAN_GAFLID_DEFAULT  0x00000000UL

/* GAFLMj */
/* GAFLMr (X5H) */
#define CAN_RSCAN_GAFLM_DEFAULT   0x00000000UL

/* GAFLP0_j */
/* GAFLP0r (X5H) */
#define CAN_RSCAN_GAFLP0_DEFAULT  0x00000000UL
#define CAN_RSCAN_GAFLP_PAGE0 0U
#define CAN_RSCAN_GAFLP_PAGE1 1U
#define CAN_RSCAN_GAFLDLC_0   0x00000000UL
#define CAN_RSCAN_GAFLDLC_1   0x00000001UL
#define CAN_RSCAN_GAFLDLC_2   0x00000002UL
#define CAN_RSCAN_GAFLDLC_3   0x00000003UL
#define CAN_RSCAN_GAFLDLC_4   0x00000004UL
#define CAN_RSCAN_GAFLDLC_5   0x00000005UL
#define CAN_RSCAN_GAFLDLC_6   0x00000006UL
#define CAN_RSCAN_GAFLDLC_7   0x00000007UL
#define CAN_RSCAN_GAFLDLC_8   0x00000008UL
#define CAN_RSCAN_GAFLDLC_12  0x00000009UL
#define CAN_RSCAN_GAFLDLC_16  0x0000000AUL
#define CAN_RSCAN_GAFLDLC_20  0x0000000BUL
#define CAN_RSCAN_GAFLDLC_24  0x0000000CUL
#define CAN_RSCAN_GAFLDLC_32  0x0000000DUL
#define CAN_RSCAN_GAFLDLC_48  0x0000000EUL
#define CAN_RSCAN_GAFLDLC_64  0x0000000FUL
#define CAN_RSCAN_GAFLSRD_0   0x00000010UL
#define CAN_RSCAN_GAFLSRD_1   0x00000020UL
#define CAN_RSCAN_GAFLSRD_2   0x00000040UL
#define CAN_RSCAN_GAFLRMV     0x00008000UL
#define CAN_RSCAN_GAFLRMDP(x) (uint32)((uint32)(x) << 8U)

/* GAFLP1_j */
/* GAFLP1r (X5H) */
#define CAN_RSCAN_GAFLP1_DEFAULT       0x00000000UL
#define CAN_RSCAN_GAFLFDP_TXRXFIFO(x)  (0x100UL << (uint32)(x))
#define CAN_RSCAN_GAFLFDP_RXFIFO(x)    (1UL << (uint32)(x))
#define CAN_RSCAN_GAFLFDP_TXQUEUE(x)                                                                                    \
  (0x100UL << (uint32)(((((uint32)(x)) / 4UL) * 3UL) + (((uint32)(x)) % 4UL)))

/* RFCCx */
/* RFCCa (X5H) */
#define CAN_RSCAN_RFCC_DEFAULT  0x00000000UL
#define CAN_RSCAN_RFFIE_GET(x) (((uint32)(x) >> 16UL) & 1UL)
#define CAN_RSCAN_RFPLS_GET(x) (((uint32)(x) >> 4UL) & 0x7UL)                                                           /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_RFIE_GET(x) (((uint32)(x) >> 1UL) & 1UL)                                                              /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_RFDC_GET(x) (((uint32)(x) >> 8UL) & 0x7UL)                                                            /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_RFFIE       0x00010000UL
#define CAN_RSCAN_RFIGCV_1_8  0x00000000UL
#define CAN_RSCAN_RFIGCV_2_8  0x00002000UL
#define CAN_RSCAN_RFIGCV_3_8  0x00004000UL
#define CAN_RSCAN_RFIGCV_4_8  0x00006000UL
#define CAN_RSCAN_RFIGCV_5_8  0x00008000UL
#define CAN_RSCAN_RFIGCV_6_8  0x0000A000UL
#define CAN_RSCAN_RFIGCV_7_8  0x0000C000UL
#define CAN_RSCAN_RFIGCV_8_8  0x0000E000UL
#define CAN_RSCAN_RFIM        0x00001000UL
#define CAN_RSCAN_RFDC_0      0x00000000UL
#define CAN_RSCAN_RFDC_4      0x00000100UL
#define CAN_RSCAN_RFDC_8      0x00000200UL
#define CAN_RSCAN_RFDC_16     0x00000300UL
#define CAN_RSCAN_RFDC_32     0x00000400UL
#define CAN_RSCAN_RFDC_48     0x00000500UL
#define CAN_RSCAN_RFDC_64     0x00000600UL
#define CAN_RSCAN_RFDC_128    0x00000700UL
#define CAN_RSCAN_RFPLS_8     0x00000000UL
#define CAN_RSCAN_RFPLS_12    0x00000010UL
#define CAN_RSCAN_RFPLS_16    0x00000020UL
#define CAN_RSCAN_RFPLS_20    0x00000030UL
#define CAN_RSCAN_RFPLS_24    0x00000040UL
#define CAN_RSCAN_RFPLS_32    0x00000050UL
#define CAN_RSCAN_RFPLS_48    0x00000060UL
#define CAN_RSCAN_RFPLS_64    0x00000070UL
#define CAN_RSCAN_RFIE        0x00000002UL
#define CAN_RSCAN_RFE         0x00000001UL

/* RFSTSx */
/* RFSTSa (X5H) */
#define CAN_RSCAN_RFFIF_GET(x) (((uint32)(x) >> 16UL) & 1UL)
#define CAN_RSCAN_RFIF_GET(x) (((uint32)(x) >> 3UL) & 1UL)                                                              /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_RFFIF       0x00010000UL
#define CAN_RSCAN_RFIF        0x00000008UL
#define CAN_RSCAN_RFMLT       0x00000004UL
#define CAN_RSCAN_RFFLL       0x00000002UL
#define CAN_RSCAN_RFEMP       0x00000001UL
#define CAN_RSCAN_CLEAR_RFIF            0x1001FF07UL
#define CAN_RSCAN_CLEAR_RFMLT           0x1001FF0BUL

/* CmCFG */
/* CnCFG (X5H) */
#define CAN_RSCAN_CFG_DEFAULT   0x00000000UL

/* CFDCmDCFG */
/* CFDCnDCFG (X5H) */
#define CAN_RSCAN_DCFG_DEFAULT  0x00000000UL
#define CAN_RSCAN_SJW(x)        (((uint32)(x) - 1UL) << 24UL)
#define CAN_RSCAN_TSEG2(x)      (((uint32)(x) - 1UL) << 16UL)
#define CAN_RSCAN_TSEG1(x)     (((uint32)(x) - 1UL) << 8UL)
#define CAN_RSCAN_BRP(x)        ((uint32)(x))

/* CFDCmNCFG */
/* CFDCnNCFG (X5H) */
#define CAN_RSCAN_NCFG_DEFAULT  0x00000000UL
#define CAN_RSCAN_NTSEG2(x)     (((uint32)(x) - 1UL) << 25UL)
#define CAN_RSCAN_NTSEG1(x)     (((uint32)(x) - 1UL) << 17UL)
#define CAN_RSCAN_NSJW(x)       (((uint32)(x) - 1UL) << 10UL)
#define CAN_RSCAN_NBRP(x)       ((uint32)(x))

/* CmCTR */
/* CnCTR (X5H) */
#define CAN_RSCAN_CTR_DEFAULT           0x00000005UL
#define CAN_RSCAN_GET_EIEBITS(x) (((uint32)(x) >> 8UL) & 0xFFUL)                                                        /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_CTM_MASK    0xF8FFFFFFUL
#define CAN_RSCAN_CTMS_NORMAL 0x00000000UL
#define CAN_RSCAN_CTMS_LISTEN 0x02000000UL
#define CAN_RSCAN_CTMS_SELF0  0x04000000UL
#define CAN_RSCAN_CTMS_SELF1  0x06000000UL
#define CAN_RSCAN_CTME        0x01000000UL
#define CAN_RSCAN_ERRD        0x00800000UL
#define CAN_RSCAN_BOM_ISO     0x00000000UL
#define CAN_RSCAN_BOM_HALT_BUSOFF_ENTRY 0x00200000UL
#define CAN_RSCAN_BOM_HALT_BUSOFF_END   0x00400000UL
#define CAN_RSCAN_BOM_HALT_SOFTWARE     0x00600000UL
#define CAN_RSCAN_TAIE        0x00010000UL
#define CAN_RSCAN_ALIE        0x00008000UL
#define CAN_RSCAN_BLIE        0x00004000UL
#define CAN_RSCAN_CLIE        0x00002000UL
#define CAN_RSCAN_BORIE       0x00001000UL
#define CAN_RSCAN_BOEIE       0x00000800UL
#define CAN_RSCAN_EPIE        0x00000400UL
#define CAN_RSCAN_EWIE        0x00000200UL
#define CAN_RSCAN_BEIE        0x00000100UL
#define CAN_RSCAN_RTBO        0x00000008UL
#define CAN_RSCAN_CHMDC_MASK  0x00000007UL
#define CAN_RSCAN_CSLPR       0x00000004UL
#define CAN_RSCAN_CHMDC_COM   0x00000000UL
#define CAN_RSCAN_CHMDC_RESET 0x00000001UL
#define CAN_RSCAN_CHMDC_HALT  0x00000002UL
#define CAN_RSCAN_CHMDC_KEEP  0x00000003UL
#define CAN_RSCAN_BUS_ERROR_ENABLE      0x0000E500UL

/* CmSTS */
/* CnSTS (X5H) */
#define CAN_RSCAN_COMSTS      0x00000080UL
#define CAN_RSCAN_RECSTS      0x00000040UL
#define CAN_RSCAN_TRMSTS      0x00000020UL
#define CAN_RSCAN_BOSTS       0x00000010UL
#define CAN_RSCAN_EPSTS       0x00000008UL
#define CAN_RSCAN_CSTSMASK    0x00000007UL
#define CAN_RSCAN_CSLPSTS     0x00000004UL
#define CAN_RSCAN_CHLTSTS     0x00000002UL
#define CAN_RSCAN_CRSTSTS     0x00000001UL
#define CAN_RSCAN_COPSTS      0x00000000UL
#define CAN_RSCAN_TEC_MASK    0xFF000000UL
#define CAN_RSCAN_TEC_OFFSET  24U
#define CAN_RSCAN_REC_MASK    0x00FF0000UL
#define CAN_RSCAN_REC_OFFSET  16

/* CmERFL */
/* CnERFL (X5H) */
#define CAN_RSCAN_GET_EFBITS(x)         ((uint32)(x) & 0xFFUL)                                                          /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_BOEF                  0x00000008UL
#define CAN_RSCAN_ERFL_CLEAR            0x00000000UL
#define CAN_RSCAN_BEF                   0x00000001UL
#define CAN_RSCAN_EWF                   0x00000002UL
#define CAN_RSCAN_EPF                   0x00000004UL
#define CAN_RSCAN_BORF                  0x00000010UL
#define CAN_RSCAN_BIT_ERROR_POS(x)      (uint8)((uint8)(x) + 5UL)
#define CAN_RSCAN_CHECK_BIT_SET         0x00000001UL
#define CAN_RSCAN_NUM_OF_BUS_ERROR      10U

/* CmFDCFG */
/* CnFDCFG (X5H) */
#define CAN_RSCAN_FDCFG_DEFAULT   0x00000000UL
#define CAN_RSCAN_CLOE            0x40000000UL
#define CAN_RSCAN_FDOE            0x10000000UL
#define CAN_RSCAN_GWBRS           0x04000000UL
#define CAN_RSCAN_GWFDF           0x02000000UL
#define CAN_RSCAN_GWEN            0x01000000UL
#define CAN_RSCAN_TDCO(x)     ((uint32)(x) << 16UL)
#define CAN_RSCAN_TDCE        0x00000200UL

/* THLCCm */
/* THLCCn (X5H) */
#define CAN_RSCAN_THLCC_DEFAULT   0x00000000UL
#define CAN_RSCAN_THLIE_GET(x) (((uint32)(x) >> 8UL) & 1UL)
#define CAN_RSCAN_THLDTE          0x00000400UL
#define CAN_RSCAN_THLIM           0x00000200UL
#define CAN_RSCAN_THLIE           0x00000100UL
#define CAN_RSCAN_THLE            0x00000001UL

/* THLSTSm */
/* THLSTSn (X5H) */
#define CAN_RSCAN_THLIF_GET(x)      (((uint32)(x) >> 3UL) & 1UL)
#define CAN_RSCAN_THLIF       0x00000008UL
#define CAN_RSCAN_THLELT      0x00000004UL
#define CAN_RSCAN_THLFLL      0x00000002UL
#define CAN_RSCAN_THLEMP      0x00000001UL
#define CAN_RSCAN_CLEAR_THLIF           0x00003F07UL
#define CAN_RSCAN_CLEAR_THLELT          0x00003F0BUL
#define CAN_RSCAN_THLEFT                0x00000004UL

/* THLACC0m */
/* THLACC0n (X5H) */
#define CAN_RSCAN_BN_GET(x)   (uint32)(((uint32)(x) >> 3UL) & 0x7FUL)
#define CAN_RSCAN_BT_GET(x)   (uint32)((uint32)(x) & 0x07UL)
#define CAN_RSCAN_BT_BUFFER   0x00000001UL
#define CAN_RSCAN_BT_TXRXFIFO 0x00000002UL
#define CAN_RSCAN_BT_TXQUEUE  0x00000004UL

/* THLACC1m */
/* THLACC1n (X5H) */
#define CAN_RSCAN_TID_GET(x)  (uint32)((uint32)(x) & 0xFFFFUL)

/* THLPCTRm */
/* THLPCTRn (X5H) */
#define CAN_RSCAN_THLPC_NEXT  0x000000FFUL

/* TMPTRp, CFPTRk */
/* TMPTR, CFPTRd (X5H) */
#define CAN_RSCAN_XXDLC(x)    (uint32)((uint32)(x) << 28UL)
#define CAN_RSCAN_XXDLC_GET(x) (uint32)((uint32)(x) >> 28UL)
#define CAN_RSCAN_XXPTR(x)    (uint32)((uint32)(x) << 16UL)

/* TMFDCTR, CFFDCSTS, RFFDSTS, RMFDSTS */
#define CAN_RSCAN_XXFDF       0x00000004UL
#define CAN_RSCAN_XXBRS       0x00000002UL
#define CAN_RSCAN_XXIESI      0x00000001UL

/* TMCp */
/* TMCi (X5H) */
#define CAN_RSCAN_TMOM        (uint8)0x04U
#define CAN_RSCAN_TMTAR       (uint8)0x02U
#define CAN_RSCAN_TMTR        (uint8)0x01U

/* TMSTSp */
/* TMSTSj (X5H) */
#define CAN_RSCAN_TMARM       (uint8)0x10U
#define CAN_RSCAN_TMTRM       (uint8)0x08U
#define CAN_RSCAN_TMTRF_CMP   (uint8)0x04U
#define CAN_RSCAN_TMTRF_ABT   (uint8)0x02U
#define CAN_RSCAN_TMTRF_NO    (uint8)0x00U
#define CAN_RSCAN_TMTSTS      (uint8)0x01U

/* TMIECy */
/* TMIECf (X5H) */
#define CAN_RSCAN_TMIEC_DEFAULT   0x00000000UL

/* TMIDp, CFIDk */
/* TMID, CFID (X5H) */
#define CAN_RSCAN_THLEN       0x20000000UL

/* CFPCTRk */
/* CFPCTRd (X5H) */
#define CAN_RSCAN_CFPC_NEXT   0x000000FFUL

/* CFCCk */
/* CFCCd (X5H) */
#define CAN_RSCAN_CFCC_DEFAULT  0x00000000UL
#define CAN_RSCAN_CFITT(x)      (uint32)((uint32)(x) << 24U)
#define CAN_RSCAN_CFTML(x)      (uint32)(((uint32)(x) & 0x1FUL) << 16UL)
#define CAN_RSCAN_CFTML_GET(x)  ((((uint32)(x) >> 16UL) & 0x1FUL) | 0x20UL)                                             /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_CFPLS_GET(x)  (((uint32)(x) >> 4UL) & 0x7UL)                                                          /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_CFTXIE_GET(x) (((uint32)(x) >> 2UL) & 1UL)
#define CAN_RSCAN_CFRXIE_GET(x) (((uint32)(x) >> 1UL) & 1UL)                                                            /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_CFDC_GET(x) (((uint32)(x) >> 21UL) & 0x7UL)                                                           /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_CFDC_0      0x00000000UL
#define CAN_RSCAN_CFDC_4      0x00200000UL
#define CAN_RSCAN_CFDC_8      0x00400000UL
#define CAN_RSCAN_CFDC_16     0x00600000UL
#define CAN_RSCAN_CFDC_32     0x00800000UL
#define CAN_RSCAN_CFDC_48     0x00A00000UL
#define CAN_RSCAN_CFDC_64     0x00C00000UL
#define CAN_RSCAN_CFDC_128    0x00E00000UL
#define CAN_RSCAN_CFIGCV_1_8  0x00000000UL
#define CAN_RSCAN_CFIGCV_2_8  0x00002000UL
#define CAN_RSCAN_CFIGCV_3_8  0x00004000UL
#define CAN_RSCAN_CFIGCV_4_8  0x00006000UL
#define CAN_RSCAN_CFIGCV_5_8  0x00008000UL
#define CAN_RSCAN_CFIGCV_6_8  0x0000A000UL
#define CAN_RSCAN_CFIGCV_7_8  0x0000C000UL
#define CAN_RSCAN_CFIGCV_8_8  0x0000E000UL
#define CAN_RSCAN_CFIM        0x00001000UL
#define CAN_RSCAN_CFITR       0x00000800UL
#define CAN_RSCAN_CFITSS      0x00000400UL
#define CAN_RSCAN_CFM_RX      0x00000000UL
#define CAN_RSCAN_CFM_TX      0x00000100UL
#define CAN_RSCAN_CFM_GW      0x00000200UL
#define CAN_RSCAN_CFPLS_8     0x00000000UL
#define CAN_RSCAN_CFPLS_12    0x00000010UL
#define CAN_RSCAN_CFPLS_16    0x00000020UL
#define CAN_RSCAN_CFPLS_20    0x00000030UL
#define CAN_RSCAN_CFPLS_24    0x00000040UL
#define CAN_RSCAN_CFPLS_32    0x00000050UL
#define CAN_RSCAN_CFPLS_48    0x00000060UL
#define CAN_RSCAN_CFPLS_64    0x00000070UL
#define CAN_RSCAN_CFTXIE      0x00000004UL
#define CAN_RSCAN_CFRXIE      0x00000002UL
#define CAN_RSCAN_CFE         0x00000001UL

/* CFCCEk */
/* CFCCEd (X5H) */
#define CAN_RSCAN_CFCCE_DEFAULT   0x00000000UL
#define CAN_RSCAN_CFOFRXIE_GET(x) (((uint32)(x) >> 1UL) & 1UL)
#define CAN_RSCAN_CFFIE_GET(x) (((uint32)(x) >> 0UL) & 1UL)
#define CAN_RSCAN_CFMOWM      0x00000100UL
#define CAN_RSCAN_CFOFTXIE    0x00000004UL
#define CAN_RSCAN_CFOFRXIE    0x00000002UL
#define CAN_RSCAN_CFFIE       0x00000001UL

/* CFSTSk */
/* CFSTSd (X5H) */
#define CAN_RSCAN_CFOFRXIF_GET(x) (((uint32)(x) >> 17UL) & 1UL)
#define CAN_RSCAN_CFFIF_GET(x) (((uint32)(x) >> 16UL) & 1UL)
#define CAN_RSCAN_CFRXIF_GET(x) (((uint32)(x) >> 3UL) & 1UL)                                                            /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_CFMOW       0x01000000UL
#define CAN_RSCAN_CFOFTXIF    0x00040000UL
#define CAN_RSCAN_CFOFRXIF    0x00020000UL
#define CAN_RSCAN_CFFIF       0x00010000UL
#define CAN_RSCAN_CFTXIF      0x00000010UL
#define CAN_RSCAN_CFRXIF      0x00000008UL
#define CAN_RSCAN_CFMLT       0x00000004UL
#define CAN_RSCAN_CFFLL       0x00000002UL
#define CAN_RSCAN_CFEMP       0x00000001UL
#define CAN_RSCAN_CLEAR_CFTXIF          0x1107FF0FUL
#define CAN_RSCAN_CLEAR_CFRXIF          0x1107FF17UL
#define CAN_RSCAN_CLEAR_CFMLT           0x1107FF1BUL

/* TXQPCTRm */
/* TXQPCTRn (X5H) */
#define CAN_RSCAN_TXQPC_NEXT  0x000000FFUL

/* TXQCC0m, TXQCC1m, TXQCC2m, TXQCC3m */
/* TXQCC0n, TXQCC1n, TXQCC2n, TXQCC3n (X5H) */
#define CAN_RSCAN_TXQCC_DEFAULT   0x00000000UL
#define CAN_RSCAN_TXQOFRXIE_GET(x) (((uint32)(x) >> 17UL) & 1UL)
#define CAN_RSCAN_TXQFIE_GET(x) (((uint32)(x) >> 16UL) & 1UL)
#define CAN_RSCAN_TXQDC(x)    (uint32)((uint32)(x) << 8UL)
#define CAN_RSCAN_TXQDC_GET(x)  (((uint32)(x) & 0x1F00UL) >> 8UL)                                                       /* PRQA S 3472 # JV-01 */
#define CAN_RSCAN_TXQOFTXIE   0x00040000UL
#define CAN_RSCAN_TXQOFRXIE   0x00020000UL /* except for TXQCC3m */
#define CAN_RSCAN_TXQFIE      0x00010000UL /* except for TXQCC3m */
#define CAN_RSCAN_TXQIM       0x00000080UL
#define CAN_RSCAN_TXQTXIE     0x00000020UL
#define CAN_RSCAN_TXQOWE      0x00000004UL
#define CAN_RSCAN_TXQGWE      0x00000002UL /* except for TXQCC3m */
#define CAN_RSCAN_TXQE        0x00000001UL

/* TXQSTS0m, TXQSTS1m, TXQSTS2m, TXQSTS3m */
/* TXQSTS0n, TXQSTS1n, TXQSTS2n, TXQSTS3 (X5H) */
#define CAN_RSCAN_TXQOFRXIF_GET(x) (((uint32)(x) >> 17UL) & 1UL)
#define CAN_RSCAN_TXQFIF_GET(x) (((uint32)(x) >> 16UL) & 1UL)
#define CAN_RSCAN_TXQMOW         0x00100000UL
#define CAN_RSCAN_TXQMLT         0x00080000UL /* except for TXQSTS3m */
#define CAN_RSCAN_TXQOFTXIF      0x00040000UL
#define CAN_RSCAN_TXQOFRXIF      0x00020000UL /* except for TXQSTS3m */
#define CAN_RSCAN_TXQFIF         0x00010000UL /* except for TXQSTS3m */
#define CAN_RSCAN_TXQIF          0x00000004UL
#define CAN_RSCAN_TXQFLL         0x00000002UL
#define CAN_RSCAN_TXQEMP         0x00000001UL

/* RMIDq, RFIDx, CFIDk, TMIDp, CFIDk */
/* RMID, RFID, CFIDd, TMID, CFID (X5H) */
#define CAN_RSCAN_IDE         0x80000000UL
#define CAN_RSCAN_RTR         0x40000000UL
#define CAN_RSCAN_IDMASK      0x1FFFFFFFUL

/* RMNB */
#define CAN_RSCAN_RMNB_DEFAULT  0x00000000UL
#define CAN_RSCAN_RMPLS_8       0x00000000UL
#define CAN_RSCAN_RMPLS_12      0x00000100UL
#define CAN_RSCAN_RMPLS_16      0x00000200UL
#define CAN_RSCAN_RMPLS_20      0x00000300UL
#define CAN_RSCAN_RMPLS_24      0x00000400UL
#define CAN_RSCAN_RMPLS_32      0x00000500UL
#define CAN_RSCAN_RMPLS_48      0x00000600UL
#define CAN_RSCAN_RMPLS_64      0x00000700UL
#define CAN_RSCAN_RMPLS_GET(x)  (((uint32)(x) >> 8U) & 0x7UL)                                                           /* PRQA S 3472 # JV-01 */

/* RMNDy */
/* RMNDt (X5H) */
#define CAN_RSCAN_RMND_GET_INDEX(x) (uint32)((uint32)(x) >> 5UL)
#define CAN_RSCAN_RMND_GET_BITMASK(x) (uint32)(1UL << ((uint32)(x) & 0x1FUL))

/*TSSELCFG*/
#define CAN_AVTP0_MODE_BIT             0x00000000UL
#define CAN_AVTP1_MODE_BIT             0x00000001UL
#define CAN_GPT0_MODE_BIT              0x00000002UL
#define CAN_GPT1_MODE_BIT              0x00000003UL
#define CAN_TSRX_CAPTURE_MASK          0x00000100UL
#define CAN_TSTX_CAPTURE_MASK          0x00000200UL
#define CAN_GPT_MODE_BASE              0U
#define CAN_GPT_MODE_OFFSET            1U

/*PTPTMEC*/
#define CAN_PTMEC_MASK                 0x0000FFFFUL

/*EXTSCTR*/
#define CAN_EXTERNALTS_MASK            0x00000001UL

/* FESTS */
#define CAN_RSCAN_FESTS_RXFFIFO_GET_BITMASK(x)     (uint32)(1UL << (uint32)(x))
#define CAN_RSCAN_FESTS_TXRXFFIFO_GET_BITMASK(x)   (uint32)(1UL << (uint32)((x) + 8UL))


/* Calc TxBuffer index to access TxQueue */
#define CAN_RSCAN_TXQUEUE0_WINDOW(x)                                                                                    \
  (uint32)(((x) * CAN_RSCAN_TXBUFFER_PER_CH) +  0UL)
#define CAN_RSCAN_TXQUEUE1_WINDOW(x)                                                                                    \
  (uint32)(((x) * CAN_RSCAN_TXBUFFER_PER_CH) + 31UL)
#define CAN_RSCAN_TXQUEUE2_WINDOW(x)                                                                                    \
  (uint32)(((x) * CAN_RSCAN_TXBUFFER_PER_CH) + 32UL)
#define CAN_RSCAN_TXQUEUE3_WINDOW(x)                                                                                    \
  (uint32)(((x) * CAN_RSCAN_TXBUFFER_PER_CH) + 63UL)

/* Wake-up Edge detection */
#define CAN_RSCAN_FCLA_FALLING_EDGE (uint8) 0x02U
/* Clear the filter control register */
#define CAN_RSCAN_FCLA_DISABLE (uint8) 0x00U

#if (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON)
/* ulWUFMask */
#define CAN_RSCAN_WUF_CHANNEL_0  0x00000040UL
#define CAN_RSCAN_WUF_CHANNEL_1  0x00000080UL
#define CAN_RSCAN_WUF_CHANNEL_2  0x00000100UL
#define CAN_RSCAN_WUF_CHANNEL_3  0x00000200UL
#define CAN_RSCAN_WUF_CHANNEL_4  0x00000400UL
#define CAN_RSCAN_WUF_CHANNEL_5  0x00000800UL
#define CAN_RSCAN_WUF_CHANNEL_6  0x00001000UL
#define CAN_RSCAN_WUF_CHANNEL_7  0x00002000UL
#define CAN_RSCAN_WUF_CHANNEL_8  0x00004000UL
#define CAN_RSCAN_WUF_CHANNEL_9  0x00008000UL
#define CAN_RSCAN_WUF_CHANNEL_10  0x00010000UL
#define CAN_RSCAN_WUF_CHANNEL_11  0x00020000UL
#define CAN_RSCAN_WUF_CHANNEL_12  0x00040000UL
#define CAN_RSCAN_WUF_CHANNEL_13  0x00080000UL
#define CAN_RSCAN_WUF_CHANNEL_14  0x00100000UL
#define CAN_RSCAN_WUF_CHANNEL_15  0x00200000UL

/* ulRxFIFOWUFMask */
#define CAN_RSCAN_WUF_GLOBAL_0  0x00000001UL
#define CAN_RSCAN_WUF_GLOBAL_1  0x00000200UL

#endif

/* Can RAM Test feature  */
#define CAN_RSCAN_GLOCKK_UNLOCK_KEY1            0x00007575UL
#define CAN_RSCAN_GLOCKK_UNLOCK_KEY2            0x00008A8AUL
#define CAN_RSCAN_GTSTCTR_RTME_ENABLE           0x00000004UL
#define CAN_RSCAN_GTSTCTR_RTME_DISABLE          0x00000000UL
#define CAN_RSCAN_GTSTCFG_RTMPS_OFFSET          16
/* RAM Test Page Access Registers */
#define CAN_RSCAN_RAM_PAGE_SIZE_ACCESS_REG      64UL
#define CAN_RSCAN_RAM_TEST_CLEAR_DATA               (uint32)0x00000000UL
/* Macro to set all RAM cells to one */
#define CAN_RSCAN_RAM_TEST_SET_DATA                 (uint32)0xFFFFFFFFUL
/* Data to be written into memory for RAM test */
#define CAN_RSCAN_RAM_TEST_DATA                     (uint32)0xAAAAAAAAUL
#define CAN_RSCAN_RAMTST_CELL_DIVIDER               (uint8)0x05
#define CAN_RSCAN_RAM_TEST_DATA_TYPE            (uint8)0x20

/* Macro for inverting a particular bit */
#define CAN_RSCAN_RAMTST_MASK_BITX(X) ((0x0001UL) << (X))
#define CAN_RSCAN_RAMTST_INVERT_BITX(CELL, X, TYPE) ((CELL) ^= (TYPE)CAN_RSCAN_RAMTST_MASK_BITX(X))
/*******************************************************************************
**                      Pretended Networking Definition                       **
*******************************************************************************/
/* Maximum rule number for each page */
#define CAN_RSCAN_PN_RULES_PER_PAGE      4
/* Pretended Networking feature mask */
#define CAN_RSCAN_PFLDAE_EN              0x00000100UL
#define CAN_RSCAN_PFLPN(x)               ((uint32)(x))
#define CAN_RSCAN_PFLDAE_DIS             0x00000000UL
/* CFDCnFDCFG.RPNMD */
#define CAN_RSCAN_RPNMD_PN_NO_RETURN     0x00003000UL
/* CFDCnFDCTR.KEY */
#define CAN_RSCAN_PNMDC_KEY              0xC4000000UL
/* CFDCnFDCTR.PNMDC bits */
#define CAN_RSCAN_PNMDC_PN_MODE          0x00030000UL
/* GPFLFDP to RX FIFO_0 */
#define CAN_RSCAN_GPFLFDP_BIT_0_RXFIFO   0x00000001UL
/* Extended ID Mask */
#define CAN_RSCAN_GPFLIDE_EN             0x80000000UL
#define CAN_RSCAN_GPFLIDEM_EN            0x80000000UL
/* DLC value */
#define CAN_RSCAN_GPFLDLC_0   0x00000000U
#define CAN_RSCAN_GPFLDLC_1   0x00000001U
#define CAN_RSCAN_GPFLDLC_2   0x00000002U
#define CAN_RSCAN_GPFLDLC_3   0x00000003U
#define CAN_RSCAN_GPFLDLC_4   0x00000004U
#define CAN_RSCAN_GPFLDLC_5   0x00000005U
#define CAN_RSCAN_GPFLDLC_6   0x00000006U
#define CAN_RSCAN_GPFLDLC_7   0x00000007U
#define CAN_RSCAN_GPFLDLC_8   0x00000008U
#define CAN_RSCAN_GPFLDLC_12  0x00000009U
#define CAN_RSCAN_GPFLDLC_16  0x0000000AU
#define CAN_RSCAN_GPFLDLC_20  0x0000000BU
#define CAN_RSCAN_GPFLDLC_24  0x0000000CU
#define CAN_RSCAN_GPFLDLC_32  0x0000000DU
#define CAN_RSCAN_GPFLDLC_48  0x0000000EU
#define CAN_RSCAN_GPFLDLC_64  0x0000000FU
/* RX FIFO MASK */
#define CAN_RSCAN_RFCC_RFIE_EN         0x00000002UL
#define CAN_RSCAN_RFCC_RFIM_EVERY      0x00001000UL
#define CAN_RSCAN_RFCC_RFPLS_64_BYTES  0x00000070UL
#define CAN_RSCAN_RFCC_RFDC_32_MSG     0x00000400UL
#define CAN_RSCAN_RFCC_RFDC_4_MSG      0x00000100UL
#define CAN_RSCAN_RFCC_RFE_EN          0x00000001UL
/* DLC INTERRUPT MASK */
#define CAN_RSCAN_GCTR_DEIE_EN         0x00000100UL
/* Maximum number of CFDGPFLCFGu register */
#define CAN_RSCAN_CFDGPFLCFG_MAX       0x02UL
/* Maximum number of PFL page */
#define CAN_RSCAN_MAX_PFL_PAGE         40
/* Enable IDE/RTR comparision bit */
#define CAN_RSCAN_CFDGPFLM_GPFLIDEM_GPFLRTRM      0xC0000000UL


/* CAN ECC safety mechanism */
/* EC710CTL */
#define CAN_RSCAN_EC710CTL_EN         0x00004058UL

/*----------------- Virtual Machine Definition -----------------*/
/* Virtual Channel Value */
#define CAN_VMN_CH7                     0x17
#define CAN_VMN_CH6                     0x16
#define CAN_VMN_CH5                     0x15
#define CAN_VMN_CH4                     0x14
#define CAN_VMN_CH3                     0x13
#define CAN_VMN_CH2                     0x12
#define CAN_VMN_CH1                     0x11
#define CAN_VMN_CH0                     0x10
#define CAN_VMN_INVALID                 0x00000000UL
/* b8 RFIF CFDRFISTS.RFxIF */
#define CAN_VMISTS_RFIF_MASK         (uint32)(0x01UL << 8UL)
/* b10 CFDRFISTS.CFRXINT */
#define CAN_VMISTS_CFRXINT_MASK      (uint32)(0x01UL << 10UL)
/* b4 THLIF CFDRFISTS */
#define CAN_VMISTS_THLIF_MASK        (uint32)(0x01UL << 4UL)
/* b2 TXQTXIF CFDRFISTS */
#define CAN_VMISTS_TXQTXIF_MASK      (uint32)(0x01UL << 2UL)
/* b0 CFTXINT CFDRFISTS */
#define CAN_VMISTS_CFTXINT_MASK      (uint32)(0x01UL << 0UL)
/* CFDGFFIMC KEY */
#define CAN_CFDGFFIMC_KEY                    (0xC4UL << 8UL)
#define CAN_CFDGFFIMC_FFIEN                   0x01UL
/* Max number of supported virtual machine channel  */
#define CAN_MAX_NO_VM_CH                  8UL
/*******************************************************************************
**                                INTERRUPT SPID                              **
*******************************************************************************/
#ifndef X5H_VDM_PLATFORM_USED
#define CANXL_CONTROLLER00_FUNCISR_SPID  0x034BUL
#define CANXL_CONTROLLER00_ERRISR_SPID   0x034CUL
#define CANXL_CONTROLLER01_FUNCISR_SPID  0x034DUL
#define CANXL_CONTROLLER01_ERRISR_SPID   0x034EUL

#define CAN_UNIT0_ISR_SPID  0x35FUL
#define CAN_UNIT1_ISR_SPID  0x370UL

#define CAN_CONTROLLER00_ISR_SPID  0x360UL
#define CAN_CONTROLLER01_ISR_SPID  0x361UL
#define CAN_CONTROLLER02_ISR_SPID  0x362UL
#define CAN_CONTROLLER03_ISR_SPID  0x363UL
#define CAN_CONTROLLER04_ISR_SPID  0x364UL
#define CAN_CONTROLLER05_ISR_SPID  0x365UL
#define CAN_CONTROLLER06_ISR_SPID  0x366UL
#define CAN_CONTROLLER07_ISR_SPID  0x367UL
#define CAN_CONTROLLER10_ISR_SPID  0x371UL
#define CAN_CONTROLLER11_ISR_SPID  0x372UL
#define CAN_CONTROLLER12_ISR_SPID  0x373UL
#define CAN_CONTROLLER13_ISR_SPID  0x374UL
#define CAN_CONTROLLER14_ISR_SPID  0x375UL
#define CAN_CONTROLLER15_ISR_SPID  0x376UL
#define CAN_CONTROLLER16_ISR_SPID  0x377UL
#define CAN_CONTROLLER17_ISR_SPID  0x378UL

#define CAN_CONTROLLER00_VMISR_SPID    0x368UL
#define CAN_CONTROLLER01_VMISR_SPID    0x369UL
#define CAN_CONTROLLER02_VMISR_SPID    0x36AUL
#define CAN_CONTROLLER03_VMISR_SPID    0x36BUL
#define CAN_CONTROLLER04_VMISR_SPID    0x36CUL
#define CAN_CONTROLLER05_VMISR_SPID    0x36DUL
#define CAN_CONTROLLER06_VMISR_SPID    0x36EUL
#define CAN_CONTROLLER07_VMISR_SPID    0x36FUL
#define CAN_CONTROLLER10_VMISR_SPID    0x379UL
#define CAN_CONTROLLER11_VMISR_SPID    0x37AUL
#define CAN_CONTROLLER12_VMISR_SPID    0x37BUL
#define CAN_CONTROLLER13_VMISR_SPID    0x37CUL
#define CAN_CONTROLLER14_VMISR_SPID    0x37DUL
#define CAN_CONTROLLER15_VMISR_SPID    0x37EUL
#define CAN_CONTROLLER16_VMISR_SPID    0x37FUL
#define CAN_CONTROLLER17_VMISR_SPID    0x380UL

#define CAN_CONTROLLER00_WAKEUPISR_SPID    0x03B9UL
#define CAN_CONTROLLER01_WAKEUPISR_SPID    0x03BAUL
#define CAN_CONTROLLER02_WAKEUPISR_SPID    0x03BBUL
#define CAN_CONTROLLER03_WAKEUPISR_SPID    0x03BCUL
#define CAN_CONTROLLER04_WAKEUPISR_SPID    0x03BDUL
#define CAN_CONTROLLER05_WAKEUPISR_SPID    0x03BEUL
#define CAN_CONTROLLER06_WAKEUPISR_SPID    0x03BFUL
#define CAN_CONTROLLER07_WAKEUPISR_SPID    0x03C0UL
#define CAN_CONTROLLER10_WAKEUPISR_SPID    0x03C1UL
#define CAN_CONTROLLER11_WAKEUPISR_SPID    0x03C2UL
#define CAN_CONTROLLER12_WAKEUPISR_SPID    0x03C3UL
#define CAN_CONTROLLER13_WAKEUPISR_SPID    0x03C4UL
#define CAN_CONTROLLER14_WAKEUPISR_SPID    0x03C5UL
#define CAN_CONTROLLER15_WAKEUPISR_SPID    0x03C6UL
#define CAN_CONTROLLER16_WAKEUPISR_SPID    0x03C7UL
#define CAN_CONTROLLER17_WAKEUPISR_SPID    0x03C8UL
#define CANXL_CONTROLLER0_WAKEUPISR_SPID   0x03C5UL
#define CANXL_CONTROLLER1_WAKEUPISR_SPID   0x03C6UL
#else
#define CANXL_CONTROLLER00_FUNCISR_SPID  0x0300UL
#define CANXL_CONTROLLER00_ERRISR_SPID   0x0301UL
#define CANXL_CONTROLLER01_FUNCISR_SPID  0x0302UL
#define CANXL_CONTROLLER01_ERRISR_SPID   0x0303UL

#define CAN_UNIT0_ISR_SPID  0x348UL
#define CAN_UNIT1_ISR_SPID  0x359UL

#define CAN_CONTROLLER00_ISR_SPID  0x349UL
#define CAN_CONTROLLER01_ISR_SPID  0x34AUL
#define CAN_CONTROLLER02_ISR_SPID  0x34BUL
#define CAN_CONTROLLER03_ISR_SPID  0x34CUL
#define CAN_CONTROLLER04_ISR_SPID  0x34DUL
#define CAN_CONTROLLER05_ISR_SPID  0x34EUL
#define CAN_CONTROLLER06_ISR_SPID  0x34FUL
#define CAN_CONTROLLER07_ISR_SPID  0x350UL
#define CAN_CONTROLLER10_ISR_SPID  0x35AUL
#define CAN_CONTROLLER11_ISR_SPID  0x35BUL
#define CAN_CONTROLLER12_ISR_SPID  0x35CUL
#define CAN_CONTROLLER13_ISR_SPID  0x35DUL
#define CAN_CONTROLLER14_ISR_SPID  0x35EUL
#define CAN_CONTROLLER15_ISR_SPID  0x35FUL
#define CAN_CONTROLLER16_ISR_SPID  0x360UL
#define CAN_CONTROLLER17_ISR_SPID  0x361UL

#define CAN_CONTROLLER00_VMISR_SPID    0x351UL
#define CAN_CONTROLLER01_VMISR_SPID    0x352UL
#define CAN_CONTROLLER02_VMISR_SPID    0x353UL
#define CAN_CONTROLLER03_VMISR_SPID    0x354UL
#define CAN_CONTROLLER04_VMISR_SPID    0x355UL
#define CAN_CONTROLLER05_VMISR_SPID    0x356UL
#define CAN_CONTROLLER06_VMISR_SPID    0x357UL
#define CAN_CONTROLLER07_VMISR_SPID    0x358UL
#define CAN_CONTROLLER10_VMISR_SPID    0x362UL
#define CAN_CONTROLLER11_VMISR_SPID    0x363UL
#define CAN_CONTROLLER12_VMISR_SPID    0x364UL
#define CAN_CONTROLLER13_VMISR_SPID    0x365UL
#define CAN_CONTROLLER14_VMISR_SPID    0x366UL
#define CAN_CONTROLLER15_VMISR_SPID    0x367UL
#define CAN_CONTROLLER16_VMISR_SPID    0x368UL
#define CAN_CONTROLLER17_VMISR_SPID    0x369UL

#define CAN_CONTROLLER00_WAKEUPISR_SPID    0x03A2UL
#define CAN_CONTROLLER01_WAKEUPISR_SPID    0x03A3UL
#define CAN_CONTROLLER02_WAKEUPISR_SPID    0x03A4UL
#define CAN_CONTROLLER03_WAKEUPISR_SPID    0x03A5UL
#define CAN_CONTROLLER04_WAKEUPISR_SPID    0x03A6UL
#define CAN_CONTROLLER05_WAKEUPISR_SPID    0x03A7UL
#define CAN_CONTROLLER06_WAKEUPISR_SPID    0x03A8UL
#define CAN_CONTROLLER07_WAKEUPISR_SPID    0x03A9UL
#define CAN_CONTROLLER10_WAKEUPISR_SPID    0x03AAUL
#define CAN_CONTROLLER11_WAKEUPISR_SPID    0x03ABUL
#define CAN_CONTROLLER12_WAKEUPISR_SPID    0x03ACUL
#define CAN_CONTROLLER13_WAKEUPISR_SPID    0x03ADUL
#define CAN_CONTROLLER14_WAKEUPISR_SPID    0x03AEUL
#define CAN_CONTROLLER15_WAKEUPISR_SPID    0x03AFUL
#define CAN_CONTROLLER16_WAKEUPISR_SPID    0x03B0UL
#define CAN_CONTROLLER17_WAKEUPISR_SPID    0x03B1UL
#endif

/*******************************************************************************
**                      Global Data Types                                     **
*******************************************************************************/
typedef struct STag_Can_ChRegType
{
  uint32 ulCFG;                                  /* +0000H+(n*10H) Cn(N)CFG  */
  uint32 ulCTR;                                  /* +0004H+(n*10H) CnCTR     */
  uint32 ulSTS;                                  /* +0008H+(n*10H) CnSTS     */
  uint32 ulERFL;                                 /* +000CH+(n*10H) CnERFL    */
} Can_ChRegType;

typedef struct STag_Can_FDChRegType
{
  uint32 ulDCFG;                                 /* +1400H+(n*20H) CnDCFG    */
  uint32 ulFDCFG;                                /* +1404H+(n*20H) CnFDCFG   */
  uint32 ulFDCTR;                                /* +1408H+(n*20H) CnFDCTR   */
  uint32 ulFDSTS;                                /* +140CH+(n*20H) CnFDSTS   */
  uint32 ulFDCRC;                                /* +1410H+(n*20H) CnFDCRC   */
  uint32 aaReserved[3];                          /* +1414H+(n*20H) Reserved  */
} Can_FDChRegType;

typedef struct STag_Can_RRuleRegType
{
  uint32 ulGAFLID;                               /* +1800H+(r*10H) GAFLIDr   */
  uint32 ulGAFLM;                                /* +1804H+(r*10H) GAFLMr    */
  uint32 aaGAFLP[2];                             /* +1808H+(r*10H) GAFLPbr   */
} Can_RRuleRegType;


/* Pretended Network Filter Reg Type */
typedef struct Stag_Can_PNFilterType
{
  uint32 CFDGPFLIDs;                              /* +1A00h + (s-1) *0040h */
  uint32 CFDGPFLMs;                               /* +1A04h + (s-1) *0040h */
  uint32 CFDGPFLP0s;                              /* +1A08h + (s-1) *0040h */
  uint32 CFDGPFLP1s;                              /* +1A0Ch + (s-1) *0040h */
  uint32 CFDGPFLPTs;                              /* +1A10h + (s-1) *0040h */
  uint32 CFDGPFLPD0s;                             /* +1A14h + (s-1) *0040h */
  uint32 CFDGPFLPM0s;                             /* +1A18h + (s-1) *0040h */
  uint32 CFDGPFLPD1s;                             /* +1A1Ch + (s-1) *0040h */
  uint32 CFDGPFLPM1s;                             /* +1A20h + (s-1) *0040h */

  uint32 aaReserved[7];                           /* +1A24h  Reserved  */

} Can_PNFilterType;

typedef struct STag_Can_FDHrhRegType
{
  uint32 ulFDRMID;                               /* +2000H+(80H*q) FDRMIDq   */
  uint32 ulFDRMPTR;                              /* +2004H+(80H*q) FDRMPTRq  */
  uint32 ulFDRMFDSTS;                            /* +2008H+(80H*q) FDRMSTSq  */
  uint32 aaFDRMDF[29];                           /* +200CH+(80H*q) FDRMDFbq  */
} Can_FDHrhRegType;

typedef struct STag_Can_FDHRTFIFORegType
{
  uint32 ulFDRFID;                               /* +6000H+(80H*x) FDRFIDx   */
  uint32 ulFDRFPTR;                              /* +6004H+(80H*x) FDRFPTRx  */
  uint32 ulFDRFFDSTS;                            /* +6008H+(80H*x) FDRFFDSTSx*/
  uint32 aaFDRFDF[29];                           /* +600CH+(80H*x) FDRFDFdx  */
} Can_FDHRTFIFORegType;

typedef struct STag_Can_FDCFIFORegType
{
  uint32 ulFDCFID;                               /* +6400H+(80H*k) FDCFIDk   */
  uint32 ulFDCFPTR;                              /* +6404H+(80H*k) FDCFPTRk  */
  uint32 ulFDCSTS;                               /* +6408H+(80H*k) FDCFFDCST */
  uint32 aaFDCFDF[29];                           /* +640CH+(80H*k) FDCFDFdk  */
} Can_FDCFIFORegType;

typedef struct STag_Can_FDHthRegType
{
  uint32 ulFDTMID;                               /* +10000H+(80H*p) FDTMIDp   */
  uint32 ulFDTMPTR;                              /* +10004H+(80H*p) FDTMPTRp  */
  uint32 ulFDTMFDCTR;                            /* +10008H+(80H*p) FDTMFDCTRp*/
  uint32 aaFDTMDF[29];                           /* +1000CH+(80H*p) FDTMDFbp  */
} Can_FDHthRegType;

typedef struct STag_Can_THistRegType
{
  uint32 ulTHLACC0;                              /* +8000H+(8H*n) THLACC0n  */
  uint32 ulTHLACC1;                              /* +8004H+(8H*n) THLACC1n  */
} Can_THistRegType;

typedef struct STag_Can_TQueueRegType
{
  uint32 aaTXQCC[8];                     /* +1000H+(60H*4)+(4H*n) TXQCCxn   */
  uint32 aaTXQSTS[8];                    /* +1020H+(60H*4)+(4H*n) TXQTSTxn  */
  uint32 aaTXQPCTR[8];                   /* +1040H+(60H*4)+(4H*n) TXQPCTRxn */
} Can_TQueueRegType;

typedef struct STag_Can_CommonRegType                                                                                   /* PRQA S 3630 # JV-01 */
{
  Can_ChRegType aaChReg[8];                      /* +0000H+(10H*n) ChRegs    */
  uint32 ulReserved0;                            /* +0080H Reserved          */
  uint32 ulGCFG;                                 /* +0084H GCFG              */
  uint32 ulGCTR;                                 /* +0088H GCTR              */
  uint32 ulGSTS;                                 /* +008CH GSTS              */
  uint32 ulGERFL;                                /* +0090H GERFL             */
  uint32 ulGTSC;                                 /* +0094H GTSC              */
  uint32 ulGAFLECTR;                             /* +0098H GAFLECTR          */
  uint32 aaGAFLCFG[4];                           /* +009CH GAFLCFGw          */
  uint32 ulRMNB;                                 /* +00ACH RMNB              */
  uint32 aaRMND[4];                              /* +00B0H RMNDt             */
  uint32 aaRFCC[8];                              /* +00C0H+(04H*a) RFCCa     */
  uint32 aaRFSTS[8];                             /* +00E0H+(04H*a) RFSTSa    */
  uint32 aaRFPCTR[8];                            /* +0100H+(04H*a) RFPCTRa   */
  uint32 aaCFCC[24];                             /* +0120H+(04H*d) CFCCd     */
  uint32 aaCFCCE[24];                            /* +0180H+(04H*d) CFCCEd     */
  uint32 aaCFSTS[24];                            /* +01E0H+(04H*d) CFSTSd    */
  uint32 aaCFPCTR[24];                           /* +0240H+(04H*d) CFPCTRd   */
  uint32 ulFESTS;                                /* +02A0H FESTS             */
  uint32 ulFFSTS;                                /* +02A4H FFSTS             */
  uint32 ulFMSTS;                                /* +02A8H FMSTS             */
  uint32 ulRFISTS;                               /* +02ACH RFISTS            */
  uint32 ulCFRISTS;                              /* +02B0H CFRISTS           */
  uint32 ulCFTISTS;                              /* +02B4H CRTISTS           */
  uint32 ulCFOFRISTS;                            /* +02B8H CFOFRISTS         */
  uint32 ulCFOFTISTS;                            /* +02BCH CFOFTISTS         */
  uint32 ulCFMOWSTS;                             /* +02C0H CFMOWSTS          */
  uint32 ulFFFSTS;                               /* +02C4H FFFSTS            */
  uint32 aaReserved1[2];                         /* +02C8H Reserved          */
  uint8 aaTMC[1280];                             /* +02D0H+(01H*i) TMCi      */
  uint8 aaTMSTS[1280];                           /* +07D0H+(01H*j) TMSTSj    */
  uint32 aaTMTRSTS[40];                          /* +0CD0H+(04H*f) TMTRSTSf  */
  uint32 aaTMTARSTS[40];                         /* +0D70H+(04H*f) TMTARSTSf */
  uint32 aaTMTCSTS[40];                          /* +0E10H+(04H*f) TMTCSTSf  */
  uint32 aaTMTASTS[40];                          /* +0EB0H+(04H*f) TMTASTSf  */
  uint32 aaTMIEC[40];                            /* +0F50H+(04H*f) TMIECf    */
  uint32 aaReserved2[4];                         /* +0FF0H Reserved          */
  Can_TQueueRegType aaTQueueReg[4];              /* +1000H+(60H*4) TQueueRegs */
  uint32 ulTXQESTS;                              /* +1180H TXQESTS           */
  uint32 ulTXQFISTS;                             /* +1184H TXQFISTS          */
  uint32 ulTXQMSTS;                              /* +1188H TXQMSTS           */
  uint32 ulTXQOWSTS;                             /* +118CH TXQOWSTS          */
  uint32 ulTXQISTS;                              /* +1190H TXQISTS           */
  uint32 ulTXQOFTISTS;                           /* +1194H TXQOFTISTS        */
  uint32 ulTXQOFRISTS;                           /* +1198H TXQOFRISTS        */
  uint32 ulTXQFSTS;                              /* +119CH TXQFSTS           */
  uint32 aaReserved3[24];                        /* +11A0H Reserved          */
  uint32 aaTHLCC[8];                             /* +1200H+(04H*n) THLCCn    */
  uint32 aaTHLSTS[8];                            /* +1220H+(04H*n) THLSTSn   */
  uint32 aaTHLPCTR[8];                           /* +1240H+(04H*n) THLPCTRn  */
  uint32 aaReserved4[40];                        /* +1260H Reserved          */
  union                                          /* +1300H+(04H*v) GTINTSTSv */
  {                                                                                                                     /* PRQA S 0750 # JV-01 */
    uint32 aaGTINTSTS[2];                        /* for 32bit access         */
    uint8  aaGTINTSTSb[8];                       /* for 8bit access          */
  } unGTINTSTS;
  uint32 ulGTSTCFG;                              /* +1308H GTSTCFG           */
  uint32 ulGTSTCTR;                              /* +130CH GTSTCTR           */
  uint32 ulReserved5;                            /* +1310H Reserved          */
  uint32 ulGFDCFG;                               /* +1314H GFDCFG            */
  uint32 ulReserved6;                            /* +1318H Reserved          */
  uint32 ulGLOCKK;                               /* +131CH GLOCKK            */
  uint32 aaReserved7[4];                         /* +1320H Reserved          */
  uint32 ulCDTCT;                                /* +1330H CDTCT             */
  uint32 ulCDTSTS;                               /* +1334H CDTSTS            */
  uint32 aaReserved8[2];                         /* +1338H Reserved          */
  uint32 ulCDTTCT;                               /* +1340H CDTTCT            */
  uint32 ulCDTTSTS;                              /* +1344H CDTTSTS           */
  uint32 aaReserved9[10/*46*/];                  /* +1348H Reserved          */

  /* Pretended Network Filter List Entry control Register */
  uint32 CFDGPFLECTR;                            /* +1370h                   */
  /* Pretended Network Filter List Entry Configuration Register w */
  uint32 CFDGPFLCFGw[2];                         /* +1374h + w*0004h         */

  uint32 aaReserved14[5];                       /* +137Ch Reserved          */
  /* Global Virtual Machine Mode configuration Register */
  uint32 ulGFFIMC;                              /* +1390h GFFIMC */
  /* Global Virtual Machine Error Interrupt Select Register */
  uint32 ulGVMEIS;                              /* +1394h GVMEIS */

  uint32 aaReserved16[2];                        /* +1398h Reserved          */
  /* Global Virtual Machine Common FIFO TXQ configuration Register n */
  uint32 aaVMCFGn[8];                           /* +13A0h + n*0004h VMCFGn */
  /* Global Virtual Machine RX FIFO configuration Register */
  uint32 ulVMRFCFG;                             /* +13C0h VMRFCFG */

  uint32 aaReserved17[7];                        /* +13C4h Reserved          */
  /* Global Virtual Machine Interrupt Status Register n */
  uint32 aaVMISTSn[8];                          /* +13E0h + n*0004h VMISTSn */

  Can_FDChRegType aaFDChReg[8];                  /* +1400H+(20H*n)           */

  uint32 aaReserved10[192];                      /* +1500H Reserved          */

  Can_RRuleRegType aaRRReg[16];                  /* +1800H+(10H*r)           */

  uint32 aaReserved11[64];                       /* +1900H Reserved          */

  /* Pretended Network Filter Entry's Registers (64) */
  Can_PNFilterType aaPNFilterReg[4];             /* +1A00h + (s-1)*0040h     */

  uint32 aaReserved15[320];                      /* +1B00H Reserved          */

  Can_FDHrhRegType aaHrhReg[128];                /* +2000H+(80H*q)           */
  Can_FDHRTFIFORegType aaRFReg[8];               /* +6000H+(80H*x)           */
  Can_FDCFIFORegType aaCFReg[24];                /* +6400H+(80H*k)           */

  uint32 aaReserved12[1024];                     /* +7000H Reserved          */

  Can_THistRegType aaTHistReg[8];                /* +8000H+(08H*n)           */

  uint32 aaReserved13[240];                      /* +8040H Reserved          */
  uint32 aaRPGACC[64];                           /* +8400H+(04H*k)           */
} Can_CommonRegType;

typedef struct STag_Can_FDRegType                                                                                       /* PRQA S 3630 # JV-01 */
{
  Can_FDChRegType aaFDChReg[8];                  /* +1400H+(20H*n)           */
  uint32 aaReserved0[192];                       /* +1500H Reserved          */
  Can_RRuleRegType aaRRReg[16];                  /* +1800H+(10H*r)           */
  uint32 aaReserved1[64];                        /* +1900H Reserved          */

  /* Pretended Network Filter Entry's Registers (64) */
  Can_PNFilterType aaPNFilterReg[4];              /* +1A00h + (s-1)*0040h     */

  uint32 aaReserved5[320];                       /* +1B00H Reserved          */

  Can_FDHrhRegType aaHrhReg[128];                /* +2000H+(80H*q)           */
  Can_FDHRTFIFORegType aaRFReg[8];               /* +6000H+(80H*x)           */
  Can_FDCFIFORegType aaCFReg[24];                /* +6400H+(80H*k)           */
  uint32 aaReserved2[1024];                      /* +7000H Reserved          */
  Can_THistRegType aaTHistReg[8];                /* +8000H+(08H*n)           */
  uint32 aaReserved3[240];                       /* +8040H Reserved          */
  uint32 aaRPGACC[64];                           /* +8400H+(04H*k)           */
  uint32 aaReserved4[7872];                       /* +8500H Reserved          */
  Can_FDHthRegType aaHthReg[128];                /* +10000H+(80H*p)          */
} Can_FDRegType;

/* Timestamp ID i Register structure structure */
typedef struct STag_Can_TSCapTimeStampIdRegType
{
  /* Channel n Timestamp ID i Low side Registers n=[0..7] i=[0..511]  */
  uint32 ulCFDCnIDL;                             /* 0000h + i*8 + n*1000h */
  /* Channel n Timestamp ID i High side Registers n=[0..7] i=[0..511]  */
  uint32 ulCFDCnIDH;                             /* 0004h + i*8 + n*1000h */
} Can_TSCapTimeStampIdRegType;

/* Can Time Sync Capture Channel Register structure */
typedef struct STag_Can_TSCapChRegType
{
  /* Channel n External Timestamp Control Register  */
  uint32 ulEXTSCTR;                                   /* 8800h + n*40h */
  /* Channel n Timestamp Select Configuration Register  */
  uint32 ulTSSELCFG;                                  /* 8804h + n*40h */
  /* Channel n Timestamp Overwrite Flag Register  */
  uint32 ulCFDCnTSOWFLG;                                   /* 8808h + n*40h */
  /* Channel n Timestamp Overwrite Interrupt Enable Register  */
  uint32 ulTSOWINTEN;                                 /* 880Ch + n*40h */
  /* Channel n Timestamp ID Counter Status Register  */
  uint32 ulCFDCnTSIDCNTSTS;                                /* 8810h + n*40h */
  /* Channel n Timestamp ID Counter Flag Register  */
  uint32 ulCFDCnTSIDCNTFLG;                                /* 8814h + n*40h */
  /* Channel n Timestamp ID Counter Interrupt Enable Register  */
  uint32 ulTSIDCNTINTEN;                              /* 8818h + n*40h */
  /* Reserved register */
  uint32 Reserved[9];                                      /* 881Ch */
} Can_TSCapChRegType;

/* Can Time Sync Capture Unit register structure */
typedef struct STag_Can_TSCapCmRegType                                                                                  /* PRQA S 3630 # JV-01 */
{
  /* Channel n Timestamp ID i Low side Registers n=[0..7] i=[0..511]  */
  Can_TSCapTimeStampIdRegType aaTimeStampId[8][512];          /* 0000h + i*8 + n*1000h */
  /* Reserved register */
  uint32 Reserved0[512];                                      /* 8000 */
  /* Channel n Controller Register */
  Can_TSCapChRegType  aaChRegType[8];                         /* 8800h + n*40h */
  /* Global Timestamp Status Register  */
  uint32 ulCFDGTSSTS;                                         /* 8A00h */
  /* Global Timestamp Sleep Control Register  */
  uint32 ulGTSSLCTR;                                       /* 8A04h */
  /* Global Timestamp Lock Key Register  */
  uint32 ulCFDGTSLOCKK;                                       /* 8A08h */
  /* Global Timestamp RAM Test Control Register  */
  uint32 ulCFDGTSRTCTR;                                       /* 8A0Ch */
  /* Global Timestamp IP Version Register  */
  uint32 ulCFDGTSIPV;                                         /* 8A10h */
  /* Reserved register */
  uint32 Reserved1[6523];                                     /* 8A14h */
} Can_TSCapCmRegType;

/* Can Global Timer Register */
typedef struct STag_Can_TSgPTPConfigRegType
{
  /* gPTP Timer Increment Value Configuration t (t=0..1) *1  */
  uint32 ulPTPTIVCt;                                          /* F020h + t*40h */
  /* Reserved registers */
  uint32 Resereved[3];                                        /* F024h */
  /* gPTP Timer Offset Value Configuration 0 t (t=0..1) *1  */
  uint32 ulPTPTOVC0t;                                         /* F030h + t*40h */
  /* gPTP Timer Offset Value Configuration 1 t (t=0..1) *1  */
  uint32 ulPTPTOVC1t;                                         /* F034h + t*40h */
  /* gPTP Timer Offset Value Configuration 2 t (t=0..1) *1  */
  uint32 ulPTPTOVC2t;                                         /* F038h + t*40h */
  /* Reserved registers */
  uint32 Resereved1;                                          /* F03Ch */
  /* gPTP AVTP Timer Monitoring 0 t (t=0..1) *1  */
  uint32 ulPTPAVTPTM0t;                                       /* F040h + t*40h */
  /* gPTP AVTP Timer Monitoring 1 t (t=0..1) *1  */
  uint32 ulPTPAVTPTM1t;                                       /* F044h + t*40h */
  /* Reserved registers */
  uint32 Resereved2[2];                                       /* F048h */
  /* gPTP gPTP Timer Monitoring 0 t (t=0..1) *1  */
  uint32 ulPTPGPTPTM0t;                                       /* F050h + t*40h */
  /* gPTP gPTP Timer Monitoring 1 t (t=0..1) *1  */
  uint32 ulPTPGPTPTM1t;                                       /* F054h + t*40h */
  /* gPTP gPTP Timer Monitoring 2 t (t=0..1) *1  */
  uint32 ulPTPGPTPTM2t;                                       /* F058h + t*40h */
  /* Reserved registers */
  uint32 Resereved3;                                          /* F05Ch */
} Can_TSgPTPConfigRegType;

typedef struct STag_Can_TSgPTPTimerRegType                                                                                   /* PRQA S 3630 # JV-01 */
{
  /* gPTP IP Version *1  */
  uint32 ulPTPIPV;                                            /* F000h */
  /* Reserved register */
  uint32 Reserved2;                                           /* F004h */
  /* gPTP TiMer Output Synchronization Configuration *1  */
  uint32 ulPTPTMOSC;                                          /* F008h */
  /* Reserved register */
  uint32 Reserved3;                                           /* F00Ch */
  /* gPTP Timer Enable Configuration *1  */
  uint32 ulPTPTMEC;                                           /* F010h */
  /* gPTP Timer Disable Configuration *1  */
  uint32 ulPTPTMDC;                                           /* F014h */
  /* Reserved register */
  uint32 Reserved4[2];                                        /* F018h */
  /* gPTP timer registers */
  Can_TSgPTPConfigRegType aaTSgPTPTimerReg[2];                 /* F020h + t*40h */
  /* Reserved register */
  uint32 Reserved5[408];                                      /* F0A0h */
  /* gPTP Interrupt Status *1  */
  uint32 ulPTPIS;                                             /* F700h */
  /* gPTP Interrupt Enable *1  */
  uint32 ulPTPIE;                                             /* F704h */
  /* gPTP Interrupt Disable *1  */
  uint32 ulPTPID;                                             /* F708h */
} Can_TSgPTPTimerRegType;
  
/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/

#endif /* CAN_REGSTRUCT_H */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
