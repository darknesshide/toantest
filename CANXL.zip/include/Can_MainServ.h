/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_MainServ.h                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024 - 2026 Renesas Electronics Corporation. All rights reserved.                                              */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* C header file for Can_MainServ.c                                                                                   */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.1: 09/03/2026 : Add macro CAN_MAINFUNCTION_INSTANCE_18 and CAN_MAINFUNCTION_INSTANCE_19
 * 1.0.3: 24/04/2025 : Add macro CAN_MAINFUNCTION_INSTANCE_16 and CAN_MAINFUNCTION_INSTANCE_17
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/

#ifndef CAN_MAINSERV_HEADER
#define CAN_MAINSERV_HEADER

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/* AUTOSAR Release version information */
#define CAN_MAINSERV_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION
#define CAN_MAINSERV_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION
#define CAN_MAINSERV_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION

/* File version information */
#define CAN_MAINSERV_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION
#define CAN_MAINSERV_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3472)    : All toplevel uses of this function-like macro look like they could be replaced by            */
/*                       equivalent function calls.                                                                   */
/* Rule                : MISRA C:2012 Dir-4.9                                                                         */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there                  */
/**********************************************************************************************************************/
/* Message (2:0841)    : Using '#undef'.                                                                              */
/* Rule                : MISRA C:2012 Rule-20.5, CWE Rule CWE-398, CWE-569                                            */
/* JV-01 Justification : This file compliant AUTOSAR format. So, there is need to use #undef.                         */
/*       Verification  : Incorrect declaration would result in compilation fails.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
/* 4byte align */
#define CAN_ALIGN_4(value)                       (((uint32)(value) + 3UL) & (uint32)(~3UL))                             /* PRQA S 3472 # JV-01 */

/* Instance indexes of MainFunctions */
#define CAN_MAINFUNCTION_INSTANCE_0              0U
#define CAN_MAINFUNCTION_INSTANCE_1              1U
#define CAN_MAINFUNCTION_INSTANCE_2              2U
#define CAN_MAINFUNCTION_INSTANCE_3              3U
#define CAN_MAINFUNCTION_INSTANCE_4              4U
#define CAN_MAINFUNCTION_INSTANCE_5              5U
#define CAN_MAINFUNCTION_INSTANCE_6              6U
#define CAN_MAINFUNCTION_INSTANCE_7              7U
#define CAN_MAINFUNCTION_INSTANCE_8              8U
#define CAN_MAINFUNCTION_INSTANCE_9              9U
#define CAN_MAINFUNCTION_INSTANCE_10             10U
#define CAN_MAINFUNCTION_INSTANCE_11             11U
#define CAN_MAINFUNCTION_INSTANCE_12             12U
#define CAN_MAINFUNCTION_INSTANCE_13             13U
#define CAN_MAINFUNCTION_INSTANCE_14             14U
#define CAN_MAINFUNCTION_INSTANCE_15             15U
#define CAN_MAINFUNCTION_INSTANCE_16             16U
#define CAN_MAINFUNCTION_INSTANCE_17             17U
#define CAN_MAINFUNCTION_INSTANCE_18             18U
#define CAN_MAINFUNCTION_INSTANCE_19             19U

/* size of the local buffer */
#if ((CAN_RSCANFD_CONFIGURED == STD_ON) || (CANFD_ON_XL_BUS_SUPPORT == STD_ON))
#define CAN_LOCALBUFFER_SIZE_32 (CAN_CANFD_MAX_PAYLOAD / sizeof(uint32))
#else
#define CAN_LOCALBUFFER_SIZE_32 (CAN_STD_MAX_PAYLOAD / sizeof(uint32))
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
/* Maximum payload length for CAN-XL */
#define CAN_CANXL_MAX_PAYLOAD     2048U
#define CANXL_LOCALBUFFER_SIZE_32 (CAN_CANXL_MAX_PAYLOAD / sizeof(uint32))
#endif

/* Inform Can_RxProcessing of target buffers */
#define CAN_RXPROC_BUFFER         0x00000001UL
#define CAN_RXPROC_TXRXFIFO(cntl) (0x00000010UL << (cntl))                                                              /* PRQA S 3472 # JV-01 */
#define CAN_RXPROC_TXRXFIFO_ALL   0x000FFFF0UL
#define CAN_RXPROC_RXFIFO(unit)   (0x00100000UL << (unit))                                                              /* PRQA S 3472 # JV-01 */
#define CAN_RXPROC_RXFIFO_ALL     0x00F00000UL

/* Format flags in Can_IdType to inform CanIf */
#ifdef CAN_CANTYPE_DECLARATION_UINT16
#define CAN_EXTENDED_FORMAT (Can_IdType)0x8000U
#define CAN_FD_FRAME_FORMAT (Can_IdType)0x4000U
#define CAN_ID_TYPE_IDMASK  (Can_IdType)0x07FFU
#else
#define CAN_EXTENDED_FORMAT (Can_IdType)0x80000000UL
#define CAN_FD_FRAME_FORMAT (Can_IdType)0x40000000UL
#define CAN_ID_TYPE_IDMASK  (Can_IdType)0x1FFFFFFFUL
#define CAN_ID_STANDARDTYPE_IDMASK  (Can_IdType)0x7FFUL
#define CANXL_PRIORITY_IDMASK       (Can_IdType)0x7FFUL
#endif

#define CAN_FD_FRAME_OFFSET       30U   

/* Maximum payload length for standard(non-FD) CAN */
/* Maximum payload length for standard(non-FD) CAN */

#define CAN_FD_BASEID_OFFSET      18U   
/* Maximum payload length for standard(non-FD) CAN */
#define CAN_STD_MAX_PAYLOAD       8U          

/* Maximum payload length for CAN-FD */
#define CAN_CANFD_MAX_PAYLOAD     64U

/* Maximum retry count for reading receive buffer
   This is just for guarantee to avoid infinite loop.
   Actually, since reading speed is enough fast than message arival interval,
   reading loop will finish within two times. */
#define CAN_RECBUFFER_RETRY_COUNT 10UL        

/* TX/RX message lost flag */
#define CAN_FIFO_MSG_LOST_MASK    (uint32)0x00000004UL

#define CAN_ONE                   1UL         
#define CAN_TWO                   2UL         
#define CAN_THREE                 3UL         

#define CAN_RX_FIFO_TYPE                   0UL
#define CAN_RX_COMFIFO_TYPE                1UL
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
#define CAN_START_SEC_CONST_8
#include "Can_MemMap.h"

#if (CAN_RSCANFD_CONFIGURED == STD_ON) || (CAN_CANXL_SUPPORTED == STD_ON)
/* The LUT to acquire DLC register value from payload size */
extern CONST(uint8, CAN_CONST) Can_GaaDLCFromPayloadTable[65];
/* The LUT to acquire payload size from DLC register value */
extern CONST(uint8, CAN_CONST) Can_GaaPayloadFromDLCTable[16];
#endif

#define CAN_STOP_SEC_CONST_8
#include "Can_MemMap.h"

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"

#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
extern FUNC(void, CAN_PRIVATE_CODE) Can_InterruptProcessing(const Can_ImfuType *IntImfuPtr, boolean blIsEnable);
#endif /*#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)*/

#if ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON))
extern FUNC(void, CAN_PRIVATE_CODE) Can_TxConfirmationProcessing(CONST(uint8, AUTOMATIC) LucCtrlIndex);
#endif

#if (CAN_RX_FIFO == STD_ON)
extern FUNC(void, CAN_PRIVATE_CODE)
    Can_RxProcessingRxFIFO(CONST(uint32, AUTOMATIC) LulBufferBits, CONST(uint32, AUTOMATIC) LulMode, 
    CONST(uint32, AUTOMATIC) LulIndex
    #if(CAN_VIRTUAL_MACHINE_ENABLE == STD_ON)
    , CONST(uint8, AUTOMATIC) LucVMChannel
    #endif
    );
#endif

#if (CAN_RX_COMFIFO == STD_ON)
extern FUNC(void, CAN_PRIVATE_CODE)
    Can_RxProcessingTxRxFIFO(CONST(uint32, AUTOMATIC) LulBufferBits, CONST(uint32, AUTOMATIC) LulMode,
    CONST(uint32, AUTOMATIC) LulIndex
    #if(CAN_VIRTUAL_MACHINE_ENABLE == STD_ON)
    , CONST(uint8, AUTOMATIC) LucVMChannel
    #endif
    );
#endif

#if (CAN_RX_BUFFER == STD_ON) 
extern FUNC(void, CAN_PRIVATE_CODE) Can_RxProcessingBuffer(CONST(uint32, AUTOMATIC) LulIndex,
                                                           VAR(uint8, AUTOMATIC) LucCtrlIndex);
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
extern FUNC(void, CAN_PRIVATE_CODE) Can_CanXLTxConfirmation(CONST(uint8, AUTOMATIC) LucCtrlIndex);
extern FUNC(void, CAN_PRIVATE_CODE) CanXL_RxProcessing(const uint8 LucController, const uint32 LulMode, 
                                                                                const uint32 LulIndex);
#endif

#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"
#endif /* CAN_MAINSERV_H */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
