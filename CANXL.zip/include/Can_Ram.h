/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_Ram.h                                                                                           */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024,2025 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* C header file for Can_Ram.c                                                                                        */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.0: 19/06/2025 : Update Memory section
 * 1.0.3: 24/04/2025 : Remove CanXL_GaaErrorSignaling
 * 1.0.2: 28/03/2025 : Support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/

#ifndef CAN_RAM_HEADER
#define CAN_RAM_HEADER

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Can_LTTypes.h"
#include "Can_MainServ.h"
#include "Can_ModeCntrl.h"
#include "Can_PBTypes.h"
#if (CAN_CANXL_SUPPORTED == STD_ON)
#include "CanXL.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define CAN_RAM_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION
#define CAN_RAM_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION
#define CAN_RAM_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define CAN_RAM_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION
#define CAN_RAM_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
#define CAN_START_SEC_VAR_INIT_BOOLEAN
#include "Can_MemMap.h"

/* Global variable to store initialization status of CAN Driver */
extern volatile VAR(boolean, CAN_VAR_INIT) Can_GblInitialized;

#define CAN_STOP_SEC_VAR_INIT_BOOLEAN
#include "Can_MemMap.h"

#define CAN_START_SEC_VAR_NO_INIT_BOOLEAN
#include "Can_MemMap.h"

#if (CAN_CANXL_SUPPORTED == STD_ON)
#if (CAN_CANXL_NO_OF_HOHS > CANXL_ZERO)
/* Flags which indicates HOH is being accessed by a CanXL_Write */
extern volatile VAR(boolean, CAN_VAR_NO_INIT) CanXL_GaaHwAccessFlag[CAN_CANXL_NO_OF_HOHS];
#endif
#endif

#if (CAN_WAKEUP_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)
/* Global state transition is on-going when sleep or wakeup */
extern volatile VAR(boolean, CAN_VAR_NO_INIT) Can_GaaGlobalStateTransition[CAN_NO_OF_UNITS];
#endif

#if ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON) || \
    (CANFD_ON_XL_BUS_SUPPORT == STD_ON))
/* Flags which indicates HOH is being accessed by a Can_Write */
extern volatile VAR(boolean, CAN_VAR_NO_INIT) Can_GaaHwAccessFlag[CAN_NO_OF_HOHS];
#endif

#define CAN_STOP_SEC_VAR_NO_INIT_BOOLEAN
#include "Can_MemMap.h"

#if (CAN_CANXL_SUPPORTED == STD_ON)
#define CAN_START_SEC_VAR_INIT_32
#include "Can_MemMap.h"

extern VAR(uint32, CAN_VAR_NO_INIT) CanXL_GaaTxBufferTotal[CANXL_MAX_CONTROLLER];
extern VAR(uint32, CAN_VAR_INIT) CanXL_GaaRamSize[CANXL_MAX_CONTROLLER];

#define CAN_STOP_SEC_VAR_INIT_32
#include "Can_MemMap.h"
#endif

#define CAN_START_SEC_VAR_NO_INIT_32
#include "Can_MemMap.h"

#if (CAN_WAKEUP_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)
/* Flags which indicates active (not slept) Controllers */
extern volatile VAR(uint32, CAN_VAR_NO_INIT) Can_GaaActiveControllers[CAN_NO_OF_UNITS];
#endif

#if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) || (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)
/* Interrupt disable count for Global interruption */
extern volatile VAR(uint32, CAN_VAR_NO_INIT) Can_GaaGlobalIntCount[CAN_NO_OF_UNITS];
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
extern VAR(uint32, CAN_VAR_NO_INIT) CanXL_GaaTxAllocCnt[CAN_CANXL_NO_OF_CONTROLLER][CANXL_MAX_TXQUEUE];
extern VAR(CanXL_RxFrameType, CAN_VAR_NO_INIT) CanXL_GaaRxFrame[CAN_CANXL_NO_OF_CONTROLLER];
#endif

#define CAN_STOP_SEC_VAR_NO_INIT_32
#include "Can_MemMap.h"


#define CAN_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Can_MemMap.h"

/* Global variable to controller status */
extern volatile VAR(Can_ControllerStateWrapperType, CAN_VAR_NO_INIT) Can_GaaCtrlState[CAN_MAX_NUMBER_OF_CONTROLLER];
#if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
/* Global variable to time stamp value */
extern VAR(Can_TimeStampType, CAN_VAR_NO_INIT) Can_GaaHohTSBufffer[CAN_NO_OF_HOHS];
#endif
#if (CAN_CANXL_SUPPORTED == STD_ON)
extern VAR(CanXL_MacFilterMng, CAN_VAR_NO_INIT) CanXL_GaaMacFilterMng[CAN_CANXL_NO_OF_CONTROLLER];
extern volatile VAR(CanXL_ControllerStatusType, CAN_VAR_NO_INIT) CanXL_GaaCtrlStat[CAN_CANXL_NO_OF_CONTROLLER];
#endif

#define CAN_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Can_MemMap.h"

#if (CAN_CANXL_SUPPORTED == STD_ON)
#define CAN_START_SEC_VAR_INIT_PTR
#include "Can_MemMap.h"

extern P2VAR(CanXL_TxBufferType, AUTOMATIC, CAN_VAR_INIT) CanXL_GaaTxBufferMgrTable[CANXL_MAX_CONTROLLER];              /* PRQA S 3432 # JV-01 */
extern P2VAR(uint8, AUTOMATIC, CAN_VAR_INIT) CanXL_GaaMemPoolBufferTable[CANXL_MAX_CONTROLLER];                         /* PRQA S 3432 # JV-01 */

#define CAN_STOP_SEC_VAR_INIT_PTR
#include "Can_MemMap.h"
#endif

#define CAN_START_SEC_VAR_NO_INIT_PTR
#include "Can_MemMap.h"

/* Global variable to store pointer to Config structure */
extern P2CONST(Can_ConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpConfig;                                 /* PRQA S 3432 # JV-01 */
extern P2CONST(Can_ControllerPCConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpPCController;               /* PRQA S 3432 # JV-01 */
extern P2CONST(Can_ControllerPBConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpPBController;               /* PRQA S 3432 # JV-01 */
extern P2CONST(Can_HohConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpHohConfig;                           /* PRQA S 3432 # JV-01 */
#if (CAN_ENABLE_DMA_MODE == STD_ON)
extern P2CONST(uint32, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpDMAToHohIndex;
#endif
#if (CAN_CANXL_SUPPORTED == STD_ON)
extern P2CONST(Can_HohConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile CanXL_GpHohConfig;                         /* PRQA S 3432 # JV-01 */
extern P2VAR(CanXL_MemManagerType, CAN_VAR_NO_INIT, CAN_VAR_NO_INIT) CanXL_GpRamManager[CAN_CANXL_NO_OF_CONTROLLER];    /* PRQA S 3432 # JV-01 */
#endif

#define CAN_STOP_SEC_VAR_NO_INIT_PTR
#include "Can_MemMap.h"

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#if (CAN_CANXL_SUPPORTED == STD_ON)
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"
extern FUNC(void, CAN_PRIVATE_CODE) CanXL_HwTxConfirmation(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(CanXL_ExtRxStatusType, CAN_PRIVATE_CODE) CanXL_RxQueueProcess(
       CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx);

extern FUNC(uint16, CAN_PRIVATE_CODE) CanXL_ComputeCRC(P2CONST(uint32, AUTOMATIC, RECAN_APPL_DATAGSPACE)                /* PRQA S 3432 # JV-01 */
                                                Descriptor, uint8 DescType);

extern FUNC(boolean, CAN_PRIVATE_CODE) Can_CanXLInit (CONST(uint8, AUTOMATIC) LucControllerID);

extern FUNC(boolean, CAN_PRIVATE_CODE) CanXL_DeInitController (uint8 LucController);

extern FUNC(Std_ReturnType, CAN_PRIVATE_CODE) CanXL_ConsistentCheck(CONST(uint8, AUTOMATIC) LucCtrlIndex,
           P2CONST(volatile uint32, AUTOMATIC, CAN_APPL_DATA) LpTargetData, CONST(uint8, AUTOMATIC) LucSdtType);        /* PRQA S 3432 # JV-01 */

extern FUNC(void, CAN_PRIVATE_CODE) CanXL_TECEmulator(CONST(uint8, AUTOMATIC) LulCtrlIdx, 
                            P2VAR(Can_TxDescriptorsType, AUTOMATIC, CAN_CONFIG_DATA) Descriptor);                       /* PRQA S 3432 # JV-01 */

extern FUNC(Can_CommonReturnType, CAN_PRIVATE_CODE) CanXL_CheckBusyQueue(
       P2VAR(Can_TxDescriptorsType *, AUTOMATIC, ETH_APPL_DATA) LpTargetDesc,                                           /* PRQA S 3432 # JV-01 */
       P2CONST(Can_HohConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpHoh);                                                   /* PRQA S 3432 # JV-01 */
extern FUNC(void, CAN_PRIVATE_CODE) CanXL_ReleaseTxBuffer(
       CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);

extern FUNC(void, CAN_PRIVATE_CODE) CanXL_WriteRxData(CONST(uint8, AUTOMATIC) LucCtrlInfoIndex, 
  VAR(uint32, AUTOMATIC) LulQueueIndex, P2VAR(Can_RxDescriptorsType, AUTOMATIC, CAN_CONFIG_DATA) Descriptor,            /* PRQA S 3432 # JV-01 */
  P2VAR(uint32, AUTOMATIC, CAN_VAR_NO_INIT) LpCanSdu);                                                                  /* PRQA S 3432 # JV-01 */
#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"
#endif /* #if (CAN_CANXL_SUPPORTED == STD_ON) */

#endif /* CAN_RAM_HEADER */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
