/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_TSCapture.c                                                                                     */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024 - 2026 Renesas Electronics Corporation. All rights reserved.                                              */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Timestamp Capture                                                                                     */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        X5H                                                                                   */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.1: 07/04/2026 : Add Version Information, Version Check
          17/03/2026 : Update Can_HwGetEgressTimeStamp, Can_HwGetIngressTimeStamp
 * 1.1.2: 27/10/2025 : Update Can_TSCapUnitInit, Can_TSCapUnitDeInit, Can_HwGetCurrentTime
 * 1.1.1: 03/10/2025 : Update Can_TSCapUnitInit, Can_TSCapUnitDeInit, Can_HwGetCurrentTime, Can_TSCapChStart
 * 1.1.0: 22/07/2025 : Update Can_TSCapUnitInit, Can_HwGetIngressTimeStamp, Can_HwGetEngressTimeStamp
                     : Add QAC message 3384
 *        18/07/2025 : Add macro device name, update Can_HwGetEgressTimeStamp
 * 1.0.3: 24/04/2025 : Change Can_TimeStampType to TimeStampType
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Can.h"
#include "Can_ModeCntrl.h"
#include "Can_PBTypes.h"
#include "Can_LTTypes.h"
#include "Can_TSCapture.h"
#include "Can_Ram.h"
#include "Dem.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/* AUTOSAR release version information */
#define CAN_TSCAPTURE_C_AR_RELEASE_MAJOR_VERSION     CAN_AR_RELEASE_MAJOR_VERSION_VALUE
#define CAN_TSCAPTURE_C_AR_RELEASE_MINOR_VERSION     CAN_AR_RELEASE_MINOR_VERSION_VALUE
#define CAN_TSCAPTURE_C_AR_RELEASE_REVISION_VERSION  CAN_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define CAN_TSCAPTURE_C_SW_MAJOR_VERSION    CAN_SW_MAJOR_VERSION_VALUE
#define CAN_TSCAPTURE_C_SW_MINOR_VERSION    CAN_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (CAN_TSCAPTURE_C_AR_RELEASE_MAJOR_VERSION != CAN_AR_RELEASE_MAJOR_VERSION)
  #error "Can_TSCapture.c : Mismatch in Release Major Version"
#endif
#if (CAN_TSCAPTURE_C_AR_RELEASE_MINOR_VERSION != CAN_AR_RELEASE_MINOR_VERSION)
  #error "Can_TSCapture.c : Mismatch in Release Minor Version"
#endif
#if (CAN_TSCAPTURE_C_AR_RELEASE_REVISION_VERSION != CAN_AR_RELEASE_REVISION_VERSION)
  #error "Can_TSCapture.c : Mismatch in Release Revision Version"
#endif

#if (CAN_TSCAPTURE_C_SW_MAJOR_VERSION  != CAN_SW_MAJOR_VERSION)
  #error "Can_TSCapture.c : Mismatch in Software Major Version"
#endif

#if (CAN_TSCAPTURE_C_SW_MINOR_VERSION != CAN_SW_MINOR_VERSION)
  #error "Can_TSCapture.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0303)    : Cast between a pointer to volatile object and an integral type.                              */
/* Rule                : CERTCCM INT36, MISRA C:2012 Rule-11.4                                                        */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, MISRA C:2012 Rule-11.4                                                        */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : MISRA C:2012 Rule-11.5                                                                       */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0857)    : Number of macro definitions exceeds 1024 - program does not conform strictly to ISO:C90.     */
/* Rule                : MISRA C:2012 Dir-1.1                                                                         */
/* JV-01 Justification : The number of macro depend on module code size. There is no issue when number of macro is    */
/*                       over 1024                                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Rule-2.1                                                         */
/* JV-01 Justification : This is accepted, Because only the module's API is exported for user's usage.                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1532)    : The function '%1s' is only referenced in one translation unit - but not the one in which it  */
/*                       is defined.                                                                                  */
/* Rule                : CERTCCM DCL19, MISRA C:2012 Rule-8.7                                                         */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule  (Symbolic Name or Published        */
/*                       Macro's name), so this is accepted                                                           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2814)    : Possible: Dereference of NULL pointer.                                                       */
/* Rule                : CERTCCM EXP34                                                                                */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification or it was    */
/*                       checked or do not dereference to NULL pointer.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2824)    : Possible: Arithmetic operation on NULL pointer.                                              */
/* Rule                : CERTCCM EXP34                                                                                */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2844)    : Possible: Dereference of an invalid pointer value.                                           */
/* Rule                : CERTCCM ARR30                                                                                */
/* JV-01 Justification : It is specific for device register accessing and confirmed has no issue in software behavior.*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : For readability, The value of macro is generate based on hardware user's manual              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30                                                                                */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30                                                                                */
/* JV-01 Justification : The max */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45                                                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                : MISRA C:2012 Rule-20.1                                                                       */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2877)    : This loop will never be executed more than once.                                             */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Dir-4.1                                                          */
/* JV-01 Justification : This loop will only be executed at least once, depends on user configuration.                */
/*       Verification  : This is Hardware Specification, X2x only provides 1 Unit. So it is not having any impact.    */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/

#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"

#if (((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)) \
    || ((CAN_CANXL_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_CANXL_SUPPORTED == STD_ON)))
/***********************************************************************************************************************
** Function Name         : Can_TSCapUnitInit
**
** Service ID            : None
**
** Description           : To init the global register of Can Time Sync Capture
**                         unit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucNoOfUnits: No of HW unit
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : When any error occurred CAN_TRUE, otherwise CAN_FALSE
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GaaRegs
**
** Functions Invoked     : Can_WaitRegisterChange, CAN_DEM_REPORT_ERROR
**
** Registers Used        : CFDGTSSTS, CFDGTSSLCTR, PTPTMEC, PTPTMOSC, CFDGFDCFG
** Registers Used        : PTPTOVC0t, PTPTOVC1t, PTPTOVC2t, PTPTIVCt
**
** Reference ID          : CAN_DUD_ACT_119, CAN_DUD_ACT_119_ERR001
** Reference ID          : CAN_DUD_ACT_119_REG001, CAN_DUD_ACT_119_REG002
** Reference ID          : CAN_DUD_ACT_119_REG003, CAN_DUD_ACT_119_REG004
** Reference ID          : CAN_DUD_ACT_119_REG005, CAN_DUD_ACT_119_REG006
** Reference ID          : CAN_DUD_ACT_119_REG007, CAN_DUD_ACT_119_REG008
** Reference ID          : CAN_DUD_ACT_119_REG009, CAN_DUD_ACT_119_GBL001
** Reference ID          : CAN_DUD_ACT_119_GBL002, CAN_DUD_ACT_119_GBL003
***********************************************************************************************************************/
FUNC(boolean, CAN_PRIVATE_CODE) Can_TSCapUnitInit(CONST(uint8, AUTOMATIC)
  LucNoOfUnits)
{
  #if (CAN_DEVICE_NAME == CAN_X5X)
  P2CONST(Can_HWgPTPInfoType, AUTOMATIC, CAN_CONFIG_DATA) LpHWgPTPInfo;                                                 /* PRQA S 3432 # JV-01 */
  VAR(uint8, AUTOMATIC) LucCount;
  VAR(uint8, AUTOMATIC) LucgPTPUnit;
  #if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(uint8, AUTOMATIC) LucTimeoutResult;
  VAR(uint8, AUTOMATIC) LucCtrlId;
  #endif
  #endif
  #if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
  VAR(uint8, AUTOMATIC) LucIndex;
  VAR(uint32, AUTOMATIC) LucHoh;
  #endif
  VAR(boolean, AUTOMATIC) LblErrFlag;
  
  LblErrFlag = CAN_FALSE;
  #if ((CAN_DEVICE_NAME == CAN_X5X) && (CAN_GLOBAL_TIME_SUPPORT == STD_ON) \
      && (CAN_RSCANFD_CONFIGURED == STD_ON))
  /* init 1st value */
  LucTimeoutResult = E_OK;                                                                                              /* PRQA S 2982 # JV-01 */
  /* Checking if CAN Time Sync RAM is initialized successfully */
  /* 1b0: RAM initialisation is finished */
  /* Wait until GRAMINIT flag is set */
  LulTimeoutDuration = CAN_TIMEOUT_COUNT;

  for (LucIndex = 0U;
      (LucIndex < LucNoOfUnits) && (CAN_FALSE == LblErrFlag); LucIndex++)
  {
      LucTimeoutResult = Can_WaitRegisterChange(
        &Can_GaaRegs[LucIndex].pTsCm->ulCFDGTSSTS,
                                            0x01UL, 0x0UL, &LulTimeoutDuration);
    if (E_OK != LucTimeoutResult)
    {
      LblErrFlag = CAN_TRUE;
    } /* Else: No action required */
  }

  /* Checking if RAM is not inited */
  if (CAN_TRUE == LblErrFlag)
  {
   #if defined(CAN_E_TIMEOUT_FAILURE)
    CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);
   #endif
  }
  else
  #endif
  {
    #if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
    for (LucIndex = 0U; LucIndex < LucNoOfUnits; LucIndex++)
    { 
      /* Set mode: TSCCFG = 01 when Can Time Sync Capture is enable */
      Can_GaaRegs[LucIndex].pCmn->ulGFDCFG |=
      (uint32)CAN_GFDCFG_TSCCFG_VALID_INDICATION;
      /* Inital value for Can_GaaHohTSBufffer*/
      for (LucHoh = 0U; LucHoh < CAN_NO_OF_HOHS; LucHoh++)
      {
        Can_GaaHohTSBufffer[LucHoh].nanoseconds = 0UL;
        Can_GaaHohTSBufffer[LucHoh].seconds = 0UL;
      }
      #if (CAN_DEVICE_NAME == CAN_X5X)
      /* Change the CAN Global Time Stamp to Operation Mode */
      /* Clear CFDGTSSLCTRL.SLEEP bit */
      Can_GaaRegs[LucIndex].pTsCm->ulGTSSLCTR &= ~(CAN_GTSSLCTRL_SLEEP_SET);
      /**
       *  Set up gPTP/gPTP AVTP Timer Configuration
       **/
      for (LucCtrlId = 0U; LucCtrlId < CAN_MAX_NUMBER_OF_CONTROLLER; LucCtrlId++)
      {
        /* Get PCConfig data for this RSCAN(FD) unit */
        LpPCController = &Can_GpPCController[LucCtrlId];
        if((LpPCController->ucUnit == LucIndex)
        #if (CAN_CANXL_SUPPORTED == STD_ON)
        && (CAN_XL != LpPCController->enControllerType)
        #endif
        )
        {
          /* Enable Can Time Sync Capture Channel */
          /* Set the CFDCnEXTSCTR.EXTSEN Bit */
          Can_GaaRegs[LucIndex].pTsCm->aaChRegType[LpPCController->ucCh].ulEXTSCTR |= CAN_EXTSCTR_EXTSEN_SET;
          /* 2. Set TSSELCFG register */
          Can_GaaRegs[LucIndex].pTsCm->aaChRegType[LpPCController->ucCh].ulTSSELCFG = (LpPCController->ulTSSELCFG |
                                                                                  CAN_TSSELCFG_TXMASK_SET);
        }
      }
      #endif
    }
    #else
    (void)LucNoOfUnits;
    #endif

    #if (CAN_DEVICE_NAME == CAN_X5X)
    LpHWgPTPInfo = (P2CONST(Can_HWgPTPInfoType, AUTOMATIC, CAN_CONFIG_DATA))Can_GpConfig->pHWgPTPInfo;                  /* PRQA S 0316, 3432 # JV-01, JV-01 */
    for (LucCount = 0U; LucCount < (uint8)Can_GpConfig->ucCanNoOfgPTPTimer; LucCount++)                                 /* PRQA S 3416 # JV-01 */
    {
      /* When apply Internal Timer mode:
        Users should set an offset value as PTPTOVC2t first.
        Users should set an offset value to PTPTOVC1t next.
        Finally users should set an offset value to PTPTOVC0t. */
      LucgPTPUnit = LpHWgPTPInfo[LucCount].ucgPTPTimerUnit;
      CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[LucgPTPUnit].ulPTPTOVC2t = LpHWgPTPInfo[LucCount].ulPTPTOVC2t;
      CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[LucgPTPUnit].ulPTPTOVC1t = LpHWgPTPInfo[LucCount].ulPTPTOVC1t;
      CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[LucgPTPUnit].ulPTPTOVC0t = LpHWgPTPInfo[LucCount].ulPTPTOVC0t;
      /* 2. Set PTPTIVCt register */
      CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[LucgPTPUnit].ulPTPTIVCt = LpHWgPTPInfo[LucCount].ulPTPTIVCt;
    }
    /* Enable timer q (0/1) TE - 0:1 */
    CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->ulPTPTMEC |= CAN_PTPTMEC_TE_SET;
    #endif
  }
  /* end function */
  return LblErrFlag;
}
#if (CAN_DEVICE_NAME == CAN_X5X) 
/***********************************************************************************************************************
** Function Name         : Can_TSCapUnitDeInit
**
** Service ID            : None
**
** Description           : To Deinit the Gloable Timer registers of Can Time
**                         Sync Capture Unit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucUnit :index of hw unit
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GaaRegs
**
** Functions Invoked     : None
**
** Registers Used        : CFDGTSSLCTRL
**
** Reference ID          : CAN_DUD_ACT_120,
** Reference ID          : CAN_DUD_ACT_120_GBL001, CAN_DUD_ACT_120_REG001, CAN_DUD_ACT_120_REG002
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_TSCapUnitDeInit(CONST(uint8, AUTOMATIC)
  LucUnit)
{
  #if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
  VAR(uint8, AUTOMATIC) LucCh;
  #endif

  #if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
  /* Clear the CFDCnEXTSCTR.EXTSEN Bit */
  for (LucCh = 0U; LucCh < Can_GpConfig->ucNoOfControllers; LucCh++)                                                    /* PRQA S 3416 # JV-01 */
  {
    Can_GaaRegs[LucUnit].pTsCm->aaChRegType[LucCh].ulEXTSCTR &= ~(CAN_EXTSCTR_EXTSEN_SET);
  }
  /* Change the CAN Global Time Stamp to Sleep Mode */
  /* Set CFDGTSSLCTRL.SLEEP bit */
  Can_GaaRegs[LucUnit].pTsCm->ulGTSSLCTR = CAN_GTSSLCTRL_SLEEP_SET;
  #else
  (void)LucUnit;
  #endif
  /* Disable timer q (0/1) TE - 0:1 */
  CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->ulPTPTMDC = CAN_PTPTMDC_DISABLE;
}
#if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
/***********************************************************************************************************************
** Function Name         : Can_HwGetCurrentTime
**
** Service ID            : None
**
** Description           : To start the Can Time Sync Capture channel if active
**                         by configuration
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucChannel: index of channel
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GpPCController, Can_GaaRegs
**
** Functions Invoked     : None
**
** Registers Used        : PTPGPTPTMn, CFDCTSSELCFG
**
** Reference ID          : CAN_DUD_ACT_191
** Reference ID          : CAN_DUD_ACT_191_REG001, CAN_DUD_ACT_191_REG002,
** Reference ID          : CAN_DUD_ACT_191_REG003, CAN_DUD_ACT_191_REG004,
** Reference ID          : CAN_DUD_ACT_191_GBL001,
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_HwGetCurrentTime(
  uint8 LucControllerId, P2VAR(Can_TimeStampType, AUTOMATIC, CAN_APPL_DATA) LpTimeStampPtr)                             /* PRQA S 3432 # JV-01 */
{
  switch ((Can_GpPCController[LucControllerId].ulTSSELCFG) & CAN_GPT1_MODE_BIT)
  {
    case CAN_GPT0_MODE_BIT:
    /* Get the nanosecond part of the GPTP timer */
    LpTimeStampPtr->nanoseconds = CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[CAN_GPT_MODE_BASE].ulPTPGPTPTM0t;
    /* Get the lower 32 bit of second part of the GPTP timer */
    LpTimeStampPtr->seconds = CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[CAN_GPT_MODE_BASE].ulPTPGPTPTM1t;
    break;
    case CAN_GPT1_MODE_BIT:
    /* Get the nanosecond part of the GPTP timer */
    LpTimeStampPtr->nanoseconds = CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[CAN_GPT_MODE_OFFSET].ulPTPGPTPTM0t;
    /* Get the lower 32 bit of second part of the GPTP timer */
    LpTimeStampPtr->seconds = CangPTP_GaaRegs[CAN_ZERO].pTSgPTP->aaTSgPTPTimerReg[CAN_GPT_MODE_OFFSET].ulPTPGPTPTM1t;
    break;
    default:
    /* Nothing to do */
    break;
  }
}
/***********************************************************************************************************************
** Function Name         : Can_TSCapChStart
**
** Service ID            : None
**
** Description           : To start the Can Time Sync Capture channel if active
**                         by configuration
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucChannel: index of channel
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GpPCController, Can_GaaRegs
**
** Functions Invoked     : None
**
** Registers Used        : CFDCnEXTSCTR, CFDCTSSELCFG
**
** Reference ID          : CAN_DUD_ACT_121, CAN_DUD_ACT_121_REG001
** Reference ID          : CAN_DUD_ACT_121_GBL001
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_TSCapChStart(CONST(uint8, AUTOMATIC)
  LucChannel)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA)                                                       /* PRQA S 3432 # JV-01 */
    LpPCController;
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;
  /* Get value of P Controller configuration value */
  LpPCController = &Can_GpPCController[LucChannel];
  /* Get physical Channel id  and hw unit */
  LucCh = LpPCController->ucCh;
  LucUnit = LpPCController->ucUnit;
  /* Enable Chanel Time Stamp */
  /* Enable Receive Time Stamp capture: clear RXMASK - 8 */
  Can_GaaRegs[LucUnit].pTsCm->aaChRegType[LucCh].ulTSSELCFG &= ~(CAN_TSSELCFG_RXMASK_SET);
}
#endif /* #if (CAN_GLOBAL_TIME_SUPPORT == STD_ON)  */
#endif /* #if (X5X == STD_ON)  */
#if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
/***********************************************************************************************************************
** Function Name         : Can_HwGetEgressTimeStamp
**
** Service ID            : None
**
** Description           : To read the stored captured Time Stamp value and
**                         inform to upper layer
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucHthId : Physical number of Hth
**                         LucController : Physical number of Controller
**                         LulHistoryData0 : TSRAM address
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GpPCController, Can_GaaRegs
**
** Functions Invoked     : None
**
** Registers Used        : CFDCnIDLi, CFDCnIDHi
**
** Reference ID          : CAN_DUD_ACT_189
** Reference ID          : CAN_DUD_ACT_189_GBL001, CAN_DUD_ACT_189_GBL002
** Reference ID          : CAN_DUD_ACT_189_GBL003, CAN_DUD_ACT_189_REG001
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_HwGetEgressTimeStamp(                                                                  /* PRQA S 1503 # JV-01 */
  CONST(uint16, AUTOMATIC) LucHthId,
  CONST(uint8, AUTOMATIC) LucController,
  CONST(uint32, AUTOMATIC) LulTSRAMOffset)
{
  VAR(uint32, AUTOMATIC) LulTSRAM;
  VAR(uint32, AUTOMATIC) Lulnanoseconds;
  VAR(uint32, AUTOMATIC) Lulseconds;
  VAR(uint8, AUTOMATIC) LucUnit;
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  #if (CAN_DEVICE_NAME == CAN_U5X)
  P2CONST(Can_HWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA) LpHWInfo;                                                     /* PRQA S 3432 # JV-01 */
  #endif
  /* Get value of P Controller configuration value */
  LpPCController = &Can_GpPCController[LucController];
  LucUnit = LpPCController->ucUnit;
  #if (CAN_DEVICE_NAME == CAN_X5X)
  /* Get the base address of hw unit ts */
  LulTSRAM = (uint32)Can_GaaRegs[LucUnit].pTsCm;                                                                        /* PRQA S 0303 # JV-01 */
  /* Get the stored TimeStamp address of Low rank  */
  LulTSRAM = LulTSRAM + LulTSRAMOffset;                                                                                 /* PRQA S 3383 # JV-01 */
  /* Read the captured Time Stamp value */
  Lulnanoseconds = (*((uint32 *)LulTSRAM));                                                                             /* PRQA S 0306 # JV-01 */
  /* Store value of time stamp into array*/
  Can_GaaHohTSBufffer[LucHthId].nanoseconds = Lulnanoseconds;
  /* Get the stored TimeStamp address of High rank */
  LulTSRAM = LulTSRAM + CAN_TIME_STAMP_ID_OFFSET;                                                                       /* PRQA S 3383 # JV-01 */
  /* Read the captured Time Stamp value */
  Lulseconds = (*((uint32 *)LulTSRAM));                                                                                 /* PRQA S 0306 # JV-01 */
  Can_GaaHohTSBufffer[LucHthId].seconds = Lulseconds;
  #else 
  
  LpHWInfo = (P2CONST(Can_HWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA))Can_GpConfig->pHWUnitInfo;                        /* PRQA S 0316, 3432 # JV-01, JV-01 */
  LpHWInfo = &LpHWInfo[LucUnit];
  /* caculator time value */
  LulTSRAM = (uint32)LulTSRAMOffset * (uint32)(LpHWInfo->usTimestampsScale);                                            /* PRQA S 3384, 2985 # JV-01, JV-01 */
  /* Caculator seconds and nanoseconds */
  Lulseconds = (uint32)(LulTSRAM / CAN_PERIPHERAL_CLOCK);
  Lulnanoseconds = (uint32)(((LulTSRAM * 1000000000UL) / CAN_PERIPHERAL_CLOCK) % 1000000000UL);                         /* PRQA S 3383 # JV-01 */
  /* Assign to global var */
  Can_GaaHohTSBufffer[LucHthId].nanoseconds = Lulnanoseconds;
  Can_GaaHohTSBufffer[LucHthId].seconds = Lulseconds;
  #endif
}
/***********************************************************************************************************************
** Function Name         : Can_HwGetIngressTimeStamp
**
** Service ID            : None
**
** Description           : To read the stored captured Time Stamp value and inform to
**                         upper layer
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucHohId : Physical number of Hoh
**                         LucController  : Physical number of Controller
**                         LulTSRAMOffset : TSRAM offset
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GpPCController, Can_GaaRegs
**
** Functions Invoked     : None
**
** Registers Used        : CFDCnIDLi, CFDCnIDHi
**
** Reference ID          : CAN_DUD_ACT_190
** Reference ID          : CAN_DUD_ACT_190_GBL001, CAN_DUD_ACT_190_GBL002
** Reference ID          : CAN_DUD_ACT_190_GBL003, CAN_DUD_ACT_190_REG001
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_HwGetIngressTimeStamp(
  CONST(uint16, AUTOMATIC) LucHohId,
  CONST(uint8, AUTOMATIC) LucController,
  CONST(uint32, AUTOMATIC) LulTSRAMOffset)
{
  VAR(uint32, AUTOMATIC) LulTSRAM;
  VAR(uint32, AUTOMATIC) Lulnanoseconds;
  VAR(uint32, AUTOMATIC) Lulseconds;
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_APPL_CONST) LpPCController;                                        /* PRQA S 3432 # JV-01 */
  VAR(uint8, AUTOMATIC) LucUnit;
  #if (CAN_DEVICE_NAME == CAN_U5X)
  P2CONST(Can_HWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA) LpHWInfo;                                                     /* PRQA S 3432 # JV-01 */
  #endif
  /* Pointer to configuration data */
  LpPCController = &Can_GpPCController[LucController];
  LucUnit = LpPCController->ucUnit;
  #if (CAN_DEVICE_NAME == CAN_X5X)
  /* Get the base address of hw unit ts */
  LulTSRAM = (uint32)Can_GaaRegs[LucUnit].pTsCm;                                                                        /* PRQA S 0303 # JV-01 */
  /* Get the stored TimeStamp address of Low rank  */
  LulTSRAM = LulTSRAM + LulTSRAMOffset;                                                                                 /* PRQA S 3383 # JV-01 */
  /* Read the captured Time Stamp value */
  Lulnanoseconds = (*((uint32 *)LulTSRAM));                                                                             /* PRQA S 0306 # JV-01 */
  /* Store value of time stamp into array*/
  Can_GaaHohTSBufffer[LucHohId].nanoseconds = Lulnanoseconds;
  /* Get the stored TimeStamp address of High rank */
  LulTSRAM = LulTSRAM + CAN_TIME_STAMP_ID_OFFSET;                                                                       /* PRQA S 3383 # JV-01 */
  /* Read the captured Time Stamp value */
  Lulseconds = (*((uint32 *)LulTSRAM));                                                                                 /* PRQA S 0306 # JV-01 */
  /* Store value of time stamp into array*/
  Can_GaaHohTSBufffer[LucHohId].seconds = Lulseconds;
  #else 
  LpHWInfo = (P2CONST(Can_HWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA))Can_GpConfig->pHWUnitInfo;                        /* PRQA S 0316, 3432 # JV-01, JV-01 */
  LpHWInfo = &LpHWInfo[LucUnit];
  /* caculator time value */
  LulTSRAM = (uint32)LulTSRAMOffset * (uint32)(LpHWInfo->usTimestampsScale);                                                    /* PRQA S 3384, 2985 # JV-01, JV-01 */
  /* Caculator seconds and nanoseconds */
  Lulseconds = (uint32)(LulTSRAM / CAN_PERIPHERAL_CLOCK);
  Lulnanoseconds = (uint32)(((LulTSRAM * 1000000000UL) / CAN_PERIPHERAL_CLOCK) % 1000000000UL);                         /* PRQA S 3383 # JV-01 */
  /* Assign to global var */
  Can_GaaHohTSBufffer[LucHohId].nanoseconds = Lulnanoseconds;
  Can_GaaHohTSBufffer[LucHohId].seconds = Lulseconds;
  #endif
}
#endif /* #if (CAN_GLOBAL_TIME_SUPPORT == STD_ON)  */
#endif
#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
