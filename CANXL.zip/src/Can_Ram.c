/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_Ram.c                                                                                           */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of initialized and uninitialized global variables and constants.                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.1: 09/03/2026 : Update variable CanXL_GaaTxBufferTotal, CanXL_GaaRamSize, CanXL_GaaTxBufferMgrTable
                       CanXL_GaaMemPoolBufferTable support CANXL 
 * 1.1.0: 19/06/2025 : Update Memory section, update QAC messages
 * 1.0.3: 24/04/2025 : Change Can_TimeStampType to TimeStampType
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Can.h"
#include "Can_Ram.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define CAN_RAM_C_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION_VALUE
#define CAN_RAM_C_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION_VALUE
#define CAN_RAM_C_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION_VALUE
/* File version information */
#define CAN_RAM_C_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION_VALUE
#define CAN_RAM_C_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (CAN_RAM_AR_RELEASE_MAJOR_VERSION != CAN_RAM_C_AR_RELEASE_MAJOR_VERSION)
  #error "Can_Ram.c : Mismatch in Release Major Version"
#endif
#if (CAN_RAM_AR_RELEASE_MINOR_VERSION != CAN_RAM_C_AR_RELEASE_MINOR_VERSION)
  #error "Can_Ram.c : Mismatch in Release Minor Version"
#endif
#if (CAN_RAM_AR_RELEASE_REVISION_VERSION != CAN_RAM_C_AR_RELEASE_REVISION_VERSION)
  #error "Can_Ram.c : Mismatch in Release Revision Version"
#endif

#if (CAN_RAM_SW_MAJOR_VERSION != CAN_RAM_C_SW_MAJOR_VERSION)
  #error "Can_Ram.c : Mismatch in Software Major Version"
#endif
#if (CAN_RAM_SW_MINOR_VERSION != CAN_RAM_C_SW_MINOR_VERSION)
  #error "Can_Ram.c : Mismatch in Software Minor Version"
#endif

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                : MISRA C:2012 Rule-20.1                                                                       */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1533)    : The object '%1s' is only referenced by function '%2s'.                                       */
/* Rule                : MISRA C:2012 Rule-8.9                                                                        */
/* JV-01 Justification : This is accepted, due to the object is defined in separated source C file to followed        */
/*                       coding rule                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0791)    : Macro identifier does not differ from other macro identifier(s) (e.g. '%s') within the       */
/*                       specified number of significant characters.                                                  */
/* Rule                : CERTCCM DCL23, MISRA C:2012 Rule-5.4                                                         */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule (Symbolic Name or Published         */
/*                       Macro's name), so this is accepted.                                                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1502)    : The object 'name' is defined but is not used within this project.                            */
/* Rule                : MISRA C:2012 Rule-2.8, CWE Rule CWE-398, CWE-569, CERTC Rule MSC13                           */
/* JV-01 Justification : Array is used in another part of driver code. There is no problem in use                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/
#define CAN_START_SEC_VAR_INIT_BOOLEAN
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Global variable to store initialization status of CAN Driver */
volatile VAR(boolean, CAN_VAR_INIT) Can_GblInitialized = CAN_FALSE;

#define CAN_STOP_SEC_VAR_INIT_BOOLEAN
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define CAN_START_SEC_VAR_NO_INIT_BOOLEAN
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if (CAN_WAKEUP_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)
/* Global state transition is on-going when sleep or wakeup */
volatile VAR(boolean, CAN_VAR_NO_INIT) Can_GaaGlobalStateTransition[CAN_NO_OF_UNITS];
#endif

#if ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON) || \
      (CANFD_ON_XL_BUS_SUPPORT == STD_ON))
/* Flags which indicates HOH is being accessed by a Can_Write */
volatile VAR(boolean, CAN_VAR_NO_INIT) Can_GaaHwAccessFlag[CAN_NO_OF_HOHS];
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
#if (CAN_CANXL_NO_OF_HOHS > CANXL_ZERO)
/* Flags which indicates HOH is being accessed by a CanXL_Write */
volatile VAR(boolean, CAN_VAR_NO_INIT) CanXL_GaaHwAccessFlag[CAN_CANXL_NO_OF_HOHS];
#endif
#endif

#define CAN_STOP_SEC_VAR_NO_INIT_BOOLEAN
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if (CAN_CANXL_SUPPORTED == STD_ON)
#define CAN_START_SEC_VAR_INIT_32
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

VAR(uint32, CAN_VAR_INIT) CanXL_GaaTxBufferTotal[CANXL_MAX_CONTROLLER] =
{
#if defined(CANXL_TX_BUF_TOTAL_0)
  CANXL_TX_BUF_TOTAL_0,
#else
  0,
#endif
#if defined(CANXL_TX_BUF_TOTAL_1)
  CANXL_TX_BUF_TOTAL_1,
#else
  0,
#endif
#if (CANXL_MAX_CONTROLLER > 2)
#if defined(CANXL_TX_BUF_TOTAL_2)
  CANXL_TX_BUF_TOTAL_2,
#else
  0,
#endif
#if defined(CANXL_TX_BUF_TOTAL_3)
  CANXL_TX_BUF_TOTAL_3
#else
  0
#endif
#endif /* #if (CANXL_MAX_CONTROLLER > 2) */
};

VAR(uint32, CAN_VAR_INIT) CanXL_GaaRamSize[CANXL_MAX_CONTROLLER] =                                                      /* PRQA S 1533 # JV-01 */
{
#if defined(CANXL_RAM_SIZE_0)
  CANXL_RAM_SIZE_0,
#else
  0,
#endif /* CANXL_RAM_SIZE_0 */
#if defined(CANXL_RAM_SIZE_1)
  CANXL_RAM_SIZE_1,
#else
  0,
#endif
#if (CANXL_MAX_CONTROLLER > 2)
#if defined(CANXL_RAM_SIZE_2)
  CANXL_RAM_SIZE_2,
#else
  0,
#endif
#if defined(CANXL_RAM_SIZE_3)
  CANXL_RAM_SIZE_3,
#else
  0
#endif
#endif /* #if (CANXL_MAX_CONTROLLER > 2) */
};

#define CAN_STOP_SEC_VAR_INIT_32
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#define CAN_START_SEC_VAR_NO_INIT_32
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if (CAN_WAKEUP_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON)
/* Flags which indicates active (not slept) Controllers */
volatile VAR(uint32, CAN_VAR_NO_INIT) Can_GaaActiveControllers[CAN_NO_OF_UNITS];
#endif

#if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) || (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)
/* Interrupt disable count for Global interruption */
volatile VAR(uint32, CAN_VAR_NO_INIT) Can_GaaGlobalIntCount[CAN_NO_OF_UNITS];
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)

VAR(uint32, CAN_VAR_NO_INIT) CanXL_GaaTxAllocCnt[CAN_CANXL_NO_OF_CONTROLLER][CANXL_MAX_TXQUEUE];
VAR(CanXL_RxFrameType, CAN_VAR_NO_INIT) CanXL_GaaRxFrame[CAN_CANXL_NO_OF_CONTROLLER];
#endif
#define CAN_STOP_SEC_VAR_NO_INIT_32
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */



#if (CAN_CANXL_SUPPORTED == STD_ON)
#if defined(CANXL_RAM_SIZE_0)
#define CAN_START_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT0_8
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */                                                                                            
STATIC VAR(uint8, CAN_VAR_NO_INIT)CanXL_GaaMemPoolBuffer_0[CANXL_RAM_SIZE_0];
#define CAN_STOP_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT0_8
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */                                                                                               
#endif /* CANXL_RAM_SIZE_0 */

#if defined(CANXL_RAM_SIZE_1)
#define CAN_START_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT1_8                                                                  /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */                                                                                         
STATIC VAR(uint8, CAN_VAR_NO_INIT)CanXL_GaaMemPoolBuffer_1[CANXL_RAM_SIZE_1];                                      
#define CAN_STOP_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT1_8                                                                   /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */ 
#endif /* CANXL_RAM_SIZE_1 */

#if defined(CANXL_RAM_SIZE_2)
#define CAN_START_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT2_8                                                                  /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */                                                                                         
STATIC VAR(uint8, CAN_VAR_NO_INIT)CanXL_GaaMemPoolBuffer_2[CANXL_RAM_SIZE_2];                                      
#define CAN_STOP_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT2_8                                                                   /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */ 
#endif /* CANXL_RAM_SIZE_2 */

#if defined(CANXL_RAM_SIZE_3)
#define CAN_START_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT3_8                                                                  /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */                                                                                         
STATIC VAR(uint8, CAN_VAR_NO_INIT)CanXL_GaaMemPoolBuffer_3[CANXL_RAM_SIZE_3];                                      
#define CAN_STOP_SEC_VAR_DATA_CONTAINER_S_MEM_UNIT3_8                                                                   /* PRQA S 0791 # JV-01 */
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */ 
#endif /* CANXL_RAM_SIZE_3 */
#endif /* #if (CAN_CANXL_SUPPORTED == STD_ON) */

#define CAN_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Global variable to controller status */
volatile VAR(Can_ControllerStateWrapperType, CAN_VAR_NO_INIT)  Can_GaaCtrlState[CAN_MAX_NUMBER_OF_CONTROLLER];
#if ((CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
/* Global variable to store time stamp value */
VAR(Can_TimeStampType, CAN_VAR_NO_INIT) Can_GaaHohTSBufffer[CAN_NO_OF_HOHS];
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
VAR(CanXL_MacFilterMng, CAN_VAR_NO_INIT) CanXL_GaaMacFilterMng[CAN_CANXL_NO_OF_CONTROLLER];
volatile VAR(CanXL_ControllerStatusType, CAN_VAR_NO_INIT) CanXL_GaaCtrlStat[CAN_CANXL_NO_OF_CONTROLLER];

#if defined(CANXL_TX_BUF_TOTAL_0)
STATIC VAR(CanXL_TxBufferType, CAN_VAR_NO_INIT) CanXL_GaaTxBufferMgr_0[CANXL_TX_BUF_TOTAL_0];
#endif /* CANXL_TX_BUF_TOTAL_0 */
#if defined(CANXL_TX_BUF_TOTAL_1)
STATIC VAR(CanXL_TxBufferType, CAN_VAR_NO_INIT) CanXL_GaaTxBufferMgr_1[CANXL_TX_BUF_TOTAL_1];
#endif /* CANXL_TX_BUF_TOTAL_1 */
#if defined(CANXL_TX_BUF_TOTAL_2)
STATIC VAR(CanXL_TxBufferType, CAN_VAR_NO_INIT) CanXL_GaaTxBufferMgr_2[CANXL_TX_BUF_TOTAL_2];
#endif /* CANXL_TX_BUF_TOTAL_2 */
#if defined(CANXL_TX_BUF_TOTAL_3)
STATIC VAR(CanXL_TxBufferType, CAN_VAR_NO_INIT) CanXL_GaaTxBufferMgr_3[CANXL_TX_BUF_TOTAL_3];
#endif /* CANXL_TX_BUF_TOTAL_3 */
#endif 

#define CAN_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if (CAN_CANXL_SUPPORTED == STD_ON)
#define CAN_START_SEC_VAR_INIT_PTR
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

P2VAR(CanXL_TxBufferType, AUTOMATIC, CAN_VAR_INIT) CanXL_GaaTxBufferMgrTable[CANXL_MAX_CONTROLLER] =                    /* PRQA S 3432 # JV-01 */
{
#if defined(CANXL_TX_BUF_TOTAL_0)
  CanXL_GaaTxBufferMgr_0, 
#else
  NULL_PTR,
#endif /* CANXL_TX_BUF_TOTAL_0 */
#if defined(CANXL_TX_BUF_TOTAL_1)
  CanXL_GaaTxBufferMgr_1, 
#else
  NULL_PTR,
#endif
#if (CANXL_MAX_CONTROLLER > 2)
#if defined(CANXL_TX_BUF_TOTAL_2)
  CanXL_GaaTxBufferMgr_2, 
#else
  NULL_PTR,
#endif
#if defined(CANXL_TX_BUF_TOTAL_3)
  CanXL_GaaTxBufferMgr_3
#else
  NULL_PTR
#endif
#endif /* #if (CANXL_MAX_CONTROLLER > 2) */
};

P2VAR(uint8, AUTOMATIC, CAN_VAR_INIT) CanXL_GaaMemPoolBufferTable[CANXL_MAX_CONTROLLER] =                               /* PRQA S 3432, 1533 # JV-01, JV-01 */
{
#if defined(CANXL_RAM_SIZE_0)
  CanXL_GaaMemPoolBuffer_0, /* Tx FIFO Queue + Priority Queue */
#else
  NULL_PTR,
#endif
#if defined(CANXL_RAM_SIZE_1)
  CanXL_GaaMemPoolBuffer_1,  /* Tx FIFO Queue + Priority Queue */
#else
  NULL_PTR,
#endif
#if (CANXL_MAX_CONTROLLER > 2)
#if defined(CANXL_RAM_SIZE_2)
  CanXL_GaaMemPoolBuffer_2,  /* Tx FIFO Queue + Priority Queue */
#else
  NULL_PTR,
#endif
#if defined(CANXL_RAM_SIZE_3)
  CanXL_GaaMemPoolBuffer_3  /* Tx FIFO Queue + Priority Queue */
#else
  NULL_PTR
#endif
#endif /* #if (CANXL_MAX_CONTROLLER > 2) */
};

#define CAN_STOP_SEC_VAR_INIT_PTR
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#define CAN_START_SEC_VAR_NO_INIT_PTR
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Global variable to store pointer to Config structure */
P2CONST(Can_ConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpConfig;                                        /* PRQA S 3432 # JV-01 */
P2CONST(Can_ControllerPCConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpPCController;                      /* PRQA S 3432 # JV-01 */
P2CONST(Can_ControllerPBConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpPBController;                      /* PRQA S 3432 # JV-01 */
P2CONST(Can_HohConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpHohConfig;                                  /* PRQA S 3432, 1502, 1533 # JV-01, JV-01, JV-01 */
#if (CAN_ENABLE_DMA_MODE == STD_ON)
P2CONST(uint32, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile Can_GpDMAToHohIndex;                                         /* PRQA S 1533 # JV-01 */
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
P2CONST(Can_HohConfigType, CAN_VAR_NO_INIT, CAN_CONFIG_DATA) volatile CanXL_GpHohConfig;                                /* PRQA S 3432 # JV-01 */
P2VAR(CanXL_MemManagerType, CAN_VAR_NO_INIT, CAN_VAR_NO_INIT) CanXL_GpRamManager[CAN_CANXL_NO_OF_CONTROLLER];           /* PRQA S 3432 # JV-01 */

#endif
#define CAN_STOP_SEC_VAR_NO_INIT_PTR
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
