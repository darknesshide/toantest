/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_ModeCntrl.c                                                                                     */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Controller Mode Control Functionality.                                                                */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.1: 06/04/2026 : Update Can_SetControllerMode, Can_SleepMode, Can_WakeupMode
 * 1.1.1: 29/09/2025 : Add QAC message 3384
 *        25/09/2025 : Update pre-compile condition Can_SelfTestChannel
 *                   : Split calculator variable in Can_WaitRegisterChange
 * 1.1.0: 22/07/2025 : Update Can_EnableTxBuffers, Can_StartMode
 *        18/07/2025 : Add macro device name  
 *        27/06/2025 : Update QAC message
 *        18/06/2025 : Add CANXL loopback  
 * 1.0.3: 24/04/2025 : Update Can_SetControllerMode, Can_WakeupMode
 *                   : Update retun result E_NOT_OK when wait for GLOBAL_RESET in Can_WakeupMode
 *                   : Update input argument when call Can_ChannelModeChange in Can_SelfTestChannel
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* CAN module header file */

/* CANXL module header file */
#include "Can.h"

#include "CanXL.h"
/* Included for RAM variable declarations */
#include "Can_Ram.h"

#include "Can_Irq.h"

/* CAN Interface call-back Header File */
#include "CanIf_Can.h"

#if (CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_DEVICE_NAME == CAN_X5X)
#include "Can_TSCapture.h"
#endif
/*
 * OS Header File to have the prototype of GetCounterValue() for getting current
 * tick of OS
 */
#include "Os.h"
/* including DEM header file */
#if (STD_ON == CAN_SELFTEST_API)
#include "Dem.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define CAN_MODECNTRL_C_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION_VALUE
#define CAN_MODECNTRL_C_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION_VALUE
#define CAN_MODECNTRL_C_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define CAN_MODECNTRL_C_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION_VALUE
#define CAN_MODECNTRL_C_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (CAN_MODECNTRL_C_AR_RELEASE_MAJOR_VERSION != CAN_MODECNTRL_AR_RELEASE_MAJOR_VERSION)
  #error "Can_ModeCntrl.c : Mismatch in Release Major Version"
#endif
#if (CAN_MODECNTRL_C_AR_RELEASE_MINOR_VERSION != CAN_MODECNTRL_AR_RELEASE_MINOR_VERSION)
  #error "Can_ModeCntrl.c : Mismatch in Release Minor Version"
#endif
#if (CAN_MODECNTRL_C_AR_RELEASE_REVISION_VERSION != CAN_MODECNTRL_AR_RELEASE_REVISION_VERSION)
  #error "Can_ModeCntrl.c : Mismatch in Release Revision Version"
#endif

#if (CAN_MODECNTRL_C_SW_MAJOR_VERSION != CAN_MODECNTRL_SW_MAJOR_VERSION)
  #error "Can_ModeCntrl.c : Mismatch in Software Major Version"
#endif

#if (CAN_MODECNTRL_C_SW_MINOR_VERSION != CAN_MODECNTRL_SW_MINOR_VERSION)
  #error "Can_ModeCntrl.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, MISRA C:2012 Rule-8.7, CWE Rule CWE-398, CWE-569                              */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1006)    : [E] This in-line assembler construct is a language extension. The code has been ignored.     */
/* Rule                : MISRA-C:2012 Dir-1.1, Rule-1.2, Dir-4.2, CERTC 1.2.4 MSC14                                   */
/* JV-01 Justification : Inline assembler support for syncp instruction.                                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30                                                                                */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:2004)    : No concluding 'else' exists in this 'if'-'else'-'if' statement.                              */
/* Rule                : CERTCCM EXP02, MISRA C:2012 Rule-15.7, CWE Rule CWE-398, CWE-569                             */
/* JV-01 Justification : The "else"statement with empty content is removed to improve readability.                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                : MISRA C:2012 Rule-20.1                                                                       */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Rule-2.1, CWE Rule CWE-398, CWE-569                              */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30                                                                                */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0751)    : Casting to char pointer type.                                                                */
/* Rule                : CERTCCM EXP11, EXP39, CWE Rule CWE-188, CWE-398, CWE-468, CWE-588, CWE-465, CWE-569, CWE-737 */
/* JV-01 Justification : Using void due to specific requirement of input parameter. So, this can be skipped           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7, CWE Rule CWE-398, CWE-569                                            */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3006)    : This function contains a mixture of in-line assembler statements and C statements.           */
/* Rule                : MISRA C:2012 Dir-4.3                                                                         */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-398, CWE-569, CWE-737                                            */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifiers. There is no impact on the functionality    */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%s' is not modified and so the pointer        */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, MISRA C:2012 Rule-8.13                                                 */
/* JV-01 Justification : Pointer variable is used to modify the value at the address so the pointer cannot be         */
/*                       declared as 'pointer to const' type.                                                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2983)    : This assignment is redundant. The value of this object is never subsequently used.           */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : The value is to increment the pointer to the next item.                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2995)    : The result of this logical operation is always 'true'.                                       */
/* Rule                : MISRA C:2012 Rule-2.2, CWE-561, CWE-633                                                      */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2991)    : The value of this 'if' controlling expression is always 'true'.                              */
/* Rule                : MISRA C:2012 Rule-14.3                                                                       */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2880)    : This code is unreachable.                                                                    */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Rule-2.1                                                         */
/* JV-01 Justification : Part of the code is manually check and confirmed to be executable depending on the           */
/*                       configuration                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2962)    : Apparent: Using value of uninitialized automatic object '%s'.                                */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-457, CWE-824, CWE-908, CWE-452, CWE-465, CWE-737                 */
/* JV-01 Justification : It will be initialized based on scope of 'if' statements where at least an 'if' statement    */
/*                       will be executed that will initialize the variable in question.                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"

#if ((CAN_RX_OBJECT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
STATIC FUNC(void, CAN_PRIVATE_CODE)
                            Can_ClearRxBuffers(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucCtrlIndex);
#endif

#if ((CAN_TX_COMFIFO == STD_ON) || (CAN_GATEWAY_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON) || \
     (CAN_GATEWAY_QUEUE == STD_ON))
STATIC FUNC(void, CAN_PRIVATE_CODE)
                            Can_EnableTxBuffers(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucCtrlIndex);
#endif
#if (CAN_ENABLE_DMA_MODE == STD_ON)
STATIC FUNC(void, CAN_PRIVATE_CODE) Can_DmaStart(uint16 LusHohIndex, uint8 LucUnit);
#endif

#if (STD_ON == CAN_SELFTEST_API)
static FUNC(void, CAN_PRIVATE_CODE) Can_SelfTestModeProcessing(
  VAR(Can_SelfTestType, AUTOMATIC) LenTestTransition,
  VAR(uint8, AUTOMATIC) LucUnit,
  VAR(uint8, AUTOMATIC) LucCh);
#endif
#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Can_SetControllerMode
**
** Service ID            : 0x03
**
** Description           : This function calls the corresponding CAN Driver
**                         service for changing the CAN Controller Mode. It
**                         initiates a transition to the requested CAN
**                         Controller Mode.
**
** Sync/Async            : Asynchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : Controller : Controller ID
**                         Transition : Target state
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Can_CommonReturnType
**
** Preconditions         : The CAN Driver must be initialized and during the
**                         function executes the Wake-up interrupt must be
**                         disabled so that the Wake-up status can be checked
**                         inside this function.
**
** Global Variables Used : Can_GaaCtrlState, Can_GpPCController
**
** Function(s) invoked   : Can_CommonDetCheck, Det_ReportError, Can_SleepMode,
**                         Can_StartMode, Can_StopMode, Can_WakeupMode,
**                         CanXL_StartMode, CanXL_StopMode
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_003
** Reference ID          : CAN_DUD_ACT_003_CRT001, CAN_DUD_ACT_003_CRT002,
** Reference ID          : CAN_DUD_ACT_003_CRT003, CAN_DUD_ACT_003_CRT004,
** Reference ID          : CAN_DUD_ACT_003_ERR001, CAN_DUD_ACT_003_ERR002,
** Reference ID          : CAN_DUD_ACT_003_GBL001, CAN_DUD_ACT_003_GBL002,
** Reference ID          : CAN_DUD_ACT_003_GBL003, CAN_DUD_ACT_003_REG001
***********************************************************************************************************************/
#define CAN_START_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(Can_CommonReturnType, CAN_PUBLIC_CODE) Can_SetControllerMode(                                                      /* PRQA S 1503 # JV-01 */
  VAR(uint8, AUTOMATIC) Controller,
  VAR(Can_CommonControllerStateType, AUTOMATIC) Transition)
{
  VAR(Can_CommonControllerStateType, AUTOMATIC) LenCurrentMode;
  VAR(Can_CommonReturnType, AUTOMATIC) LenReturnValue;
  #if (CAN_WAKEUP_SUPPORT == STD_ON)
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */

  #endif
  /* Get the current mode of the Controller */
  LenCurrentMode = Can_GaaCtrlState[Controller].enMode;

  #if (CAN_DEV_ERROR_DETECT == STD_ON)
  LenReturnValue = Can_CommonDetCheck(CAN_SET_MODECNTRL_SID, Controller);
  if (CAN_COMMON_OK != LenReturnValue)
  {
    /* Return LenReturnValue as is */
  }
  /* Report to DET, if the transition is out of range */
  else if ((uint32)CAN_MAX_VALID_STATE_TRANSITION < (uint32)Transition)
  {
    (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_SET_MODECNTRL_SID, CAN_E_TRANSITION);
    LenReturnValue = CAN_COMMON_NOT_OK;
  }
  /* Report to DET, if the transition is not valid */
  else if (((CAN_COMMON_STATE_SLEEP == LenCurrentMode) && (CAN_COMMON_STATE_STARTED == Transition)) ||
      ((CAN_COMMON_STATE_STARTED == LenCurrentMode) && (CAN_COMMON_STATE_SLEEP == Transition)))
  {
    (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_SET_MODECNTRL_SID, CAN_E_TRANSITION);
    LenReturnValue = CAN_COMMON_NOT_OK;
  }
  else
  #endif /* #if (CAN_DEV_ERROR_DETECT == STD_ON) */
  {
    LenReturnValue = CAN_COMMON_OK;
    /* If Transition is to the Same State */
    if (LenCurrentMode == Transition)
    {
      /* Indicate mode change to CanIf, if Transition is to the Same State */
      if (CAN_COMMON_STATE_STARTED == Transition)
      {
        /* Indicate mode change to CanIf */
        CanIf_ControllerModeIndication((uint8)(Controller + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_STARTED);       /* PRQA S 3383, 2985 # JV-01, JV-01 */
      }
      else if (CAN_COMMON_STATE_STOPPED == Transition)
      {
        /* Indicate mode change to CanIf */
        CanIf_ControllerModeIndication((uint8)(Controller + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_STOPPED);       /* PRQA S 3383, 2985 # JV-01, JV-01 */
      }
      else if (CAN_COMMON_STATE_SLEEP == Transition)                                                                    /* PRQA S 2004 # JV-01 */
      {
        /* Indicate mode change to CanIf */
        CanIf_ControllerModeIndication((uint8)(Controller + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_SLEEP);         /* PRQA S 3383, 2985 # JV-01, JV-01 */
      } /* else No action required */
    }
    else
    {
      /* Invoke corresponding function based on the transition */
      switch (Transition)
      {
      case CAN_COMMON_STATE_STARTED:
        #if (CAN_CANXL_SUPPORTED == STD_ON)
        if(CAN_XL == Can_GpPCController[Controller].enControllerType)                                                   /* PRQA S 3416 # JV-01 */
        {
          CanXL_StartMode(Controller);
        }
        else
        #endif
        {
          Can_StartMode(Controller);
        }
        break;
      case CAN_COMMON_STATE_STOPPED:
        if (CAN_COMMON_STATE_STARTED == LenCurrentMode)
        {
          /*
          * The transition START to STOP is done by the following triggers:
          *  - Can_SetControllerMode(CAN_COMMON_STATE_STOPPED)
          *  - Busoff
          * To avoid the state transition is done twice by both of triggers,
          * the exclusive control is required.
          */
          CAN_ENTER_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION);
          if (CAN_NO_PENDING_TRANSITION == Can_GaaCtrlState[Controller].enSubState)
          {
            /* Mark subState as "TENTATIVE" to block the transition by ISR */
            Can_GaaCtrlState[Controller].enSubState = CAN_TENTATIVE_TRANSITION;
          } /* else No action required */
          CAN_EXIT_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION);
          if (CAN_FALSE == Can_GaaCtrlState[Controller].blBusOff)
          {
            /* Start the transition to STOP state */
            #if (CAN_CANXL_SUPPORTED == STD_ON)
            if(CAN_XL == Can_GpPCController[Controller].enControllerType)                                               /* PRQA S 3416 # JV-01 */
            {
              CanXL_StopMode(Controller);
            }
            else
            #endif
            {
              Can_StopMode(Controller);
            }
          } /* else No action required */
        }
        else
        {
          #if (CAN_WAKEUP_SUPPORT == STD_ON)
          LpPCController = &Can_GpPCController[Controller];
          /*
          * The transition SLEEP to STOP is done by the following triggers:
          *  - Can_SetControllerMode(CAN_COMMON_STATE_WAKEUP) (AR422)
          *  - Can_SetControllerMode(CAN_COMMON_STATE_STOPPED) (AR431)
          *  - Wake-up trigger by the HW
          * To avoid the state transition is done twice by both of triggers,
          * the exclusive control is required.
          * This critical section must be INTERRUPT_CONTROL_PROTECTION,
          * because EIC register is manipulated and the exclusive control is
          * also required against Can_EnableControllerInterrupts.
          */
          CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
          if ((CAN_COMMON_STATE_SLEEP == Can_GaaCtrlState[Controller].enMode) &&
              (CAN_NO_PENDING_TRANSITION == Can_GaaCtrlState[Controller].enSubState))
          {
            /* Mark subState as "TENTATIVE" to block the transition by ISR */
            Can_GaaCtrlState[Controller].enSubState = CAN_TENTATIVE_TRANSITION;
            /* Wakeup is triggered by SW */
            Can_GaaCtrlState[Controller].blWakeupByHW = CAN_FALSE;
            /* Disable Wake-up ISR */
            #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
            if (NULL_PTR != LpPCController->pICWakeup)
            {
              Can_InterruptProcessing(LpPCController->pICWakeup, CAN_FALSE);                                            /* PRQA S 0751 # JV-01 */
            } /* else No action required */
            #else
            if (0UL != LpPCController->ulWakeUpEicID)
            {
              GIC_DisableIRQ(LpPCController->ulWakeUpEicID);
            }/* else No action required */
            #endif
          } /* else No action required. The transition to CAN_COMMON_STATE_STOPPED by ISR has been started */
          CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
          if (CAN_TENTATIVE_TRANSITION != Can_GaaCtrlState[Controller].enSubState)
          {
            /* The state transition has been started by the ISR.
              Return CAN_COMMON_NOT_OK according to SWS_Can_00048. */
            LenReturnValue = CAN_COMMON_NOT_OK;
          }
          else
          #endif /* (CAN_WAKEUP_SUPPORT == STD_ON) */
          {
            /* Start the transition to STOP sate */
            Can_WakeupMode(Controller);
          }
        }
        break;
        default: /* CAN_COMMON_STATE_SLEEP */
        Can_SleepMode(Controller);
        break;
      } /* end of switch(Transition) */
    } /* end of if (LenCurrentMode == Transition) */
  }
  /* Return LenCanReturnType */
  return (LenReturnValue);
}
#define CAN_STOP_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Can_GetControllerErrorState
**
** Service ID            : 0x11
**
** Description           : This function calls the corresponding CAN Driver
**                         service for getting the CAN Controller error state.
**                         It returns the error state of corresponding inputted
**                         ID of CAN Controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant for the same ControllerId
**
** Input Parameters      : ControllerID : Controller ID
**
** InOut Parameters      : None
**
** Output Parameters     : ErrorStatePtr : Pointer to the location storing
**                         the current error state of Controller
**
** Return parameter      : Std_ReturnType(E_OK/E_NOT_OK)
**
** Preconditions         : CanSetBaudrateApi is configured as true.
**                         CAN Driver must be initialized.
**
** Global Variables Used : Can_GpPCController, Can_GaaRegs, Can_GpConfig
**
** Function(s) invoked   : Can_CommonDetCheck, Det_ReportError
**
** Registers Used        : CFDCmSTS
**
** Reference ID          : CAN_DUD_ACT_016
** Reference ID          : CAN_DUD_ACT_016_ERR001, CAN_DUD_ACT_016_GLB001
***********************************************************************************************************************/
#define CAN_START_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetControllerErrorState(VAR(uint8, AUTOMATIC) ControllerId,                   /* PRQA S 1503 # JV-01 */
                                                    P2VAR(Can_ErrorStateType, AUTOMATIC, CAN_APPL_DATA) ErrorStatePtr)  /* PRQA S 3432 # JV-01 */
{
  VAR(Std_ReturnType, AUTOMATIC) LenReturnValue;
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  VAR(uint8, AUTOMATIC) LucUnit;
  #endif
  VAR(uint8, AUTOMATIC) LucCh;
  #if (CAN_CANXL_SUPPORTED == STD_ON)
  VAR(uint8, AUTOMATIC) LucCtrlInfoIndex;
  #endif /* (CAN_CANXL_SUPPORTED == STD_ON) */

  #if (CAN_DEV_ERROR_DETECT == STD_ON)
  LenReturnValue = Can_CommonDetCheck(CAN_GET_ERRSTATECNTRL_SID, ControllerId);
  if (E_OK != LenReturnValue)
  {
    /* Return LenReturnValue as it is */
  }
  /* Check if parameter passed is equal to Null pointer */
  else if (NULL_PTR == ErrorStatePtr)
  {
    /* Report to DET  */
    (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_GET_ERRSTATECNTRL_SID, CAN_E_PARAM_POINTER);
    LenReturnValue = E_NOT_OK;
  }
  else
  #endif /* #if (CAN_DEV_ERROR_DETECT == STD_ON) */
  {
    LenReturnValue = E_OK;
    LpPCController = &Can_GpPCController[ControllerId];
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    LucUnit = LpPCController->ucUnit;
    #endif
    LucCh = LpPCController->ucCh;
    #if (CAN_CANXL_SUPPORTED == STD_ON)
    if(CAN_FD == LpPCController->enControllerType)
    #endif
    {
      #if (CAN_RSCANFD_CONFIGURED == STD_ON)
      /* Get the current error state of the Controller */
      if (0UL != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_BOSTS))
      {
        *ErrorStatePtr = CAN_ERRORSTATE_BUSOFF;
      }
      else if (0UL != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_EPSTS))
      {
        *ErrorStatePtr = CAN_ERRORSTATE_PASSIVE;
      }
      else
      {
        *ErrorStatePtr = CAN_ERRORSTATE_ACTIVE;
      }
      #endif
    }
    #if (CAN_CANXL_SUPPORTED == STD_ON)
    else
    {
      LucCtrlInfoIndex = Can_GpConfig->pCanXLSecondPhysicalControllerToIndex[LucCh];
      if (CAN_TRUE == CanXL_GaaCtrlStat[LucCtrlInfoIndex].blErrorSignaling)
      {
        /* Get the current error state of the Controller */
        if (0UL != (CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulSTAT & CAN_CANXL_BOEF))
        {
          *ErrorStatePtr = CAN_ERRORSTATE_BUSOFF;
        }
        else if (0UL != (CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulSTAT & CAN_CANXL_EPEF))
        {
          *ErrorStatePtr = CAN_ERRORSTATE_PASSIVE;
        }
        else
        {
          *ErrorStatePtr = CAN_ERRORSTATE_ACTIVE;
        }
      }
      else
      {
        /* Get the current error state of the Controller */
        if (CAN_TRUE == Can_GaaCtrlState[ControllerId].blBusOff)
        {
          *ErrorStatePtr = CAN_ERRORSTATE_BUSOFF;
        }
        else if ((CanXL_GaaCtrlStat[LucCtrlInfoIndex].ulTEC >= 128UL) || 
                (CanXL_GaaCtrlStat[LucCtrlInfoIndex].ulREC >= 128UL))
        {
          *ErrorStatePtr = CAN_ERRORSTATE_PASSIVE;
        }
        else
        {
          *ErrorStatePtr = CAN_ERRORSTATE_ACTIVE;
        }
      }
    }
    #endif
  }
  /* Return LenReturnValue */
  return (LenReturnValue);
}
#define CAN_STOP_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Can_GetControllerMode
**
** Service ID            : 0x12
**
** Description           : This function calls the corresponding CAN Driver
**                         service for getting the CAN Controller Mode. It
**                         returns the state of corresponding inputted ID of
**                         CAN Controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : Controller : Controller ID
**
** InOut Parameters      : None
**
** Output Parameters     : ControllerModePtr : Pointer to the location storing
**                         the current mode of Controller
**
** Return parameter      : Std_ReturnType(E_OK/E_NOT_OK)
**
** Preconditions         : The CAN Driver must be initialized.
**
** Global Variables Used : Can_GaaCtrlState
**
** Function(s) invoked   : Can_CommonDetCheck, Det_ReportError
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_017
** Reference ID          : CAN_DUD_ACT_017_ERR001
***********************************************************************************************************************/
#define CAN_START_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_GetControllerMode(VAR(uint8, AUTOMATIC) Controller,                           /* PRQA S 1503 # JV-01 */
                                            P2VAR(Can_ControllerStateType, AUTOMATIC, CAN_APPL_DATA) ControllerModePtr) /* PRQA S 3432 # JV-01 */
{
  VAR(Std_ReturnType, AUTOMATIC) LenReturnValue;

  #if (CAN_DEV_ERROR_DETECT == STD_ON)
  LenReturnValue = Can_CommonDetCheck(CAN_GET_MODECNTRL_SID, Controller);
  if (E_OK != LenReturnValue)
  {
    /* Return LenReturnValue as it is */
  }
  /* Check if parameter passed is equal to Null pointer */
  else if (NULL_PTR == ControllerModePtr)
  {
    /* Report to DET  */
    (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_GET_MODECNTRL_SID, CAN_E_PARAM_POINTER);
    LenReturnValue = E_NOT_OK;
  }
  else
  #endif /* #if (CAN_DEV_ERROR_DETECT == STD_ON) */
  {
    LenReturnValue = E_OK;
    /* Get the current mode of the Controller */
    *ControllerModePtr = Can_GaaCtrlState[Controller].enMode;
  }
  /* Return LenReturnValue */
  return (LenReturnValue);
}
#define CAN_STOP_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
** Function Name         : Can_SleepMode
**
** Service ID            : Not Applicable
**
** Description           : This function initiates a transition to sleep mode.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant from Can_SetControllerMode and
**                         Can_MainFunction_Mode.
**                         Non-reentrant from same API.
**
** Input Parameters      : LucController
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index and state transition
**                         must be guaranteed by the upper layer.
**
** Global Variables Used : Can_GpPCController, Can_GaaCtrlState,
**                         Can_GaaRegs, Can_GaaActiveControllers,
**                         Can_GaaGlobalStateTransition
**
** Function(s) invoked   : Can_GlobalModeChange, Can_ChannelModeChange,
**                         CanIf_ControllerModeIndication
**
** Registers Used        : (CFD)GSTS, (CFD)CmSTS
**
** Reference ID          : CAN_DUD_ACT_035
** Reference ID          : CAN_DUD_ACT_035_CRT001, CAN_DUD_ACT_035_CRT002,
** Reference ID          : CAN_DUD_ACT_035_CRT003, CAN_DUD_ACT_035_CRT004,
** Reference ID          : CAN_DUD_ACT_035_GBL001, CAN_DUD_ACT_035_GBL002,
** Reference ID          : CAN_DUD_ACT_035_GBL003, CAN_DUD_ACT_035_GBL005,
** Reference ID          : CAN_DUD_ACT_035_GBL006, CAN_DUD_ACT_035_GBL007,
** Reference ID          : CAN_DUD_ACT_035_GBL008, CAN_DUD_ACT_035_GBL009,
** Reference ID          : CAN_DUD_ACT_035_REG001, CAN_DUD_ACT_035_REG002
** Reference ID          : CAN_DUD_ACT_035_REG003, CAN_DUD_ACT_035_CRT005
** Reference ID          : CAN_DUD_ACT_035_CRT006 
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_SleepMode(CONST(uint8, AUTOMATIC) LucCtrlIndex)                                        /* PRQA S 1505 # JV-01 */
{
  #if (CAN_WAKEUP_SUPPORT == STD_ON)
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  VAR(Std_ReturnType, AUTOMATIC) LucResult;
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;
  VAR(boolean, AUTOMATIC) LblGlobalTransitionRequired;
  #endif
  VAR(Can_SubStatusType, AUTOMATIC) LenSubState;
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  LulTimeoutDuration = CAN_TIMEOUT_COUNT;
  LucUnit = LpPCController->ucUnit;
  LucCh = LpPCController->ucCh;
  #endif
  LenSubState = Can_GaaCtrlState[LucCtrlIndex].enSubState;                                                              /* PRQA S 2983 # JV-01 */
  LucResult = E_OK;

  /*
   * STEP 1:
   * Start to change to CHANNEL_STOP.
   * At this time, global state transition is never on-going.
   * Because:
   * - While GLOBAL_STOP -> GLOBAL_OPERATION is on-going, it means that all
   *   Controllers are CAN_COMMON_STATE_SLEEP or during transition to
   *   CAN_COMMON_STATE_STOPPED.
   * - While GLOBAL_OPERATION -> GLOBAL_STOP is on-going, it means that one
   *   Controller is during transition to CAN_COMMON_STATE_SLEEP and other
   *   Controllers are CAN_COMMON_STATE_SLEEP.
   * - When Can_SetControllerMode(CAN_COMMON_STATE_SLEEP) is invoked for a
   *   Controller which is CAN_COMMON_STATE_SLEEP already, Can_SetControllerMode
   *   returns immediately.
   * - When Can_SetControllerMode(CAN_COMMON_STATE_SLEEP) is invoked for a
   *   Controller which is during state transition, it causes the DET error.
   */
  #if (CAN_CANXL_SUPPORTED == STD_ON)
  if(CAN_XL != LpPCController->enControllerType)
  #endif
  {
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    if (CAN_NO_PENDING_TRANSITION == LenSubState)
    {
      LenSubState = CAN_PENDING_SLEEP_WAIT_STOP;
      LucResult = Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CSLPR | CAN_RSCAN_CHMDC_RESET, &LulTimeoutDuration);
      /* Continue to STEP 3 */
    }
    /*
    * STEP 2:
    * If necessary, wait for CHANNEL_STOP.
    */
    else if ((CAN_PENDING_SLEEP_WAIT_STOP == LenSubState) &&                                                            /* PRQA S 2004 # JV-01 */
            (0UL == (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_CSLPSTS)))
    {
      /* Continue to pending */
      LucResult = E_NOT_OK;
    } /* else No action required */
    /*
    * STEP 3:
    * If all Controllers slept, change global state to GLOBAL_RESET.
    */

    if ((E_OK == LucResult) && (CAN_PENDING_SLEEP_WAIT_STOP == LenSubState))
    {
    /* Critical section is required in case entering to sleep and waking up occur on different channels at same time */
      CAN_ENTER_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION_GLOBAL);
      /* Clear active bit of this Controller */
      Can_GaaActiveControllers[LucUnit] &= ~(1UL << LucCtrlIndex);
      if (0UL == Can_GaaActiveControllers[LucUnit])
      {
        /* If all Controllers have been entered to CANNEL_STOP, start the global state change:
        GLOBAL_OPERATION -> GLOBAL_STOP */
        Can_GaaGlobalStateTransition[LucUnit] = CAN_TRUE;
        LblGlobalTransitionRequired = CAN_TRUE;
      }
      else
      {
        LblGlobalTransitionRequired = CAN_FALSE;
      }
      CAN_EXIT_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION_GLOBAL);
      /* If all controllers stopped, enter GLOBAL_STOP mode */
      if (CAN_TRUE == LblGlobalTransitionRequired)
      {
        /* At first, change to GLOBAL_RESET mode. This takes 2 CAN bits. */
        LenSubState = CAN_PENDING_SLEEP_WAIT_GLOBALRESET;
        LucResult = Can_GlobalModeChange(LucUnit, CAN_RSCAN_GMDC_RESET, &LulTimeoutDuration);
        /* Continue to STEP 5 */
      } /* else No action required. Continue to STEP 7 */
    }
    /*
    * STEP 4:
    * If necessary, wait for GLOBAL_RESET.
    */
    else if ((E_OK == LucResult) && (CAN_PENDING_SLEEP_WAIT_GLOBALRESET == LenSubState) &&                              /* PRQA S 2004 # JV-01 */
            (CAN_RSCAN_GRSTSTS != (Can_GaaRegs[LucUnit].pCmn->ulGSTS & CAN_RSCAN_GSTSMASK)))
    {
      /* Continue to pending */
      LucResult = E_NOT_OK;
    } /* else No action required */

    /*
    * STEP 5:
    * If necessary, enter GLOBAL_STOP.
    */
    if ((E_OK == LucResult) && (CAN_PENDING_SLEEP_WAIT_GLOBALRESET == LenSubState))
    {
      LenSubState = CAN_PENDING_SLEEP_WAIT_GLOBALSTOP;
      LucResult = Can_GlobalModeChange(LucUnit, CAN_RSCAN_GSLPR | CAN_RSCAN_GMDC_RESET, &LulTimeoutDuration);
      /* Continue to STEP 7 */
    }
    /*
    * STEP 6:
    * If necessary, wait for GLOBAL_STOP.
    */
    else if ((E_OK == LucResult) && (CAN_PENDING_SLEEP_WAIT_GLOBALSTOP == LenSubState) &&                               /* PRQA S 2004 # JV-01 */
            (0UL != (Can_GaaRegs[LucUnit].pCmn->ulGSTS & CAN_RSCAN_GSLPSTS)))
    {
      /* Continue to pending */
      LucResult = E_NOT_OK;
    } /* else No action required */
    #endif
  }
  /*
   * STEP 7:
   * Finish transition.
   */
  if (E_OK == LucResult)                                                                                                /* PRQA S 2991, 2995 # JV-01, JV-01 */
  {
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    #if (CAN_CANXL_SUPPORTED == STD_ON)
    if (CAN_XL != LpPCController->enControllerType)
    #endif
    {
      /* Clear Global transition on-going flag */
      if (CAN_PENDING_SLEEP_WAIT_GLOBALSTOP == LenSubState)
      {
        /* No critical section is required because this can be done atomically */
        Can_GaaGlobalStateTransition[LucUnit] = CAN_FALSE;
      } /* else No action required */
    }
    #endif
    /* Critical section is required to avoid confliction with
       Can_DisableControllerInterrupts */
    CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_SLEEP;
    Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;
    #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
    if (NULL_PTR != LpPCController->pICWakeup)
    {
      /* Clear interrupt flag */
      NVIC_ClearPendingIRQ(LpPCController->pICWakeup->enInterruptID);
    #else
    if (0UL != LpPCController->ulWakeUpEicID)
    {
      /* Clear interrupt flag */
      GIC_ClearPendingIRQ(LpPCController->ulWakeUpEicID);
    #endif
          /* Enable wakeup interrupt */
      if ((0U != (LpPCController->ucIntEnable & CAN_CHECK_INT_WAKEUP)) &&
          (0UL == Can_GaaCtrlState[LucCtrlIndex].ulIntCount))
      {
    #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
        Can_InterruptProcessing(LpPCController->pICWakeup, CAN_TRUE);
    #else
        GIC_EnableIRQ(LpPCController->ulWakeUpEicID);
    #endif
      } /* else No action required */
      #ifdef CAN_FILTER_CONTROL_SUPPORT
      if (NULL_PTR != LpPCController->pFCLAReg)
      {
        /* Setting the filter control register for falling edge detection */
        *(LpPCController->pFCLAReg) = CAN_RSCAN_FCLA_FALLING_EDGE;
      } /* else No action required */
      #endif
    } /* else No action required. Wakeup is not available on this Controller, nothing to do */

    CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    /* Notify CanIf of completion of transition to SLEEP state */
    CanIf_ControllerModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_SLEEP);           /* PRQA S 2985, 3383 # JV-01, JV-01 */
  }
  else
  {
    /* If timeout occurred, update the pending status.
    This should be done at the end of this function once to avoid reentrant
    call from Can_SetControllerMode and Can_MainFunction_Mode. */
    Can_GaaCtrlState[LucCtrlIndex].enSubState = LenSubState;                                                            /* PRQA S 2880 # JV-01 */
  }
  #else /* (CAN_WAKEUP_SUPPORT == STD_ON) */
  /* Set the Controller to sleep mode */
  Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_SLEEP;
  Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;
  /* Indicate mode change to CanIf */
  CanIf_ControllerModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_SLEEP);             /* PRQA S 3383, 2985 # JV-01, JV-01 */
  #endif /* (CAN_WAKEUP_SUPPORT == STD_ON) */
}

/***********************************************************************************************************************
** Function Name         : Can_WakeupMode
**
** Service ID            : Not Applicable
**
** Description           : This function initiates the transition to wakeup from
**                         sleep Mode.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant from Can_SetControllerMode and
**                         Can_MainFunction_Mode.
**                         Non-reentrant from same API.
**
** Input Parameters      : LucCtrlIndex      : Index of a Controller
**                         LulTimeoutDuration : Timer count which is allowed
**                         to be spent in this function.
**                         When this function is invoked from ISRs,
**                         this parameter must be zero.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index and state transition
**                         must beguaranteed by the upper layer.
**
** Global Variables Used : Can_GpPCController, Can_GaaCtrlState,
**                         Can_GaaGlobalStateTransition,
**                         Can_GaaActiveControllers, Can_GaaRegs
**
** Function(s) invoked   : Can_GlobalModeChange, Can_ChannelModeChange,
**                         CanIf_ControllerModeIndication
**
** Registers Used        : (CFD)GSTS, (CFD)CmSTS
**
** Reference ID          : CAN_DUD_ACT_036
** Reference ID          : CAN_DUD_ACT_036_CRT001, CAN_DUD_ACT_036_CRT002,
** Reference ID          : CAN_DUD_ACT_036_GBL001, CAN_DUD_ACT_036_GBL002,
** Reference ID          : CAN_DUD_ACT_036_GBL003, CAN_DUD_ACT_036_GBL004,
** Reference ID          : CAN_DUD_ACT_036_GBL005, CAN_DUD_ACT_036_GBL006,
** Reference ID          : CAN_DUD_ACT_036_GBL007, CAN_DUD_ACT_036_GBL008
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_WakeupMode(CONST(uint8, AUTOMATIC) LucCtrlIndex)                                       /* PRQA S 1505 # JV-01 */
{
  #if (CAN_WAKEUP_SUPPORT == STD_ON)
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  VAR(Std_ReturnType, AUTOMATIC) LucResult;
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;
  VAR(boolean, AUTOMATIC) LblGlobalTransitionRequired;
  #endif
  VAR(Can_SubStatusType, AUTOMATIC) LenSubState;
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  LucUnit = LpPCController->ucUnit;
  LucCh = LpPCController->ucCh;
  LblGlobalTransitionRequired = CAN_FALSE;
  LulTimeoutDuration = CAN_TIMEOUT_COUNT;
  #endif
  LucResult = E_OK;
  LenSubState = Can_GaaCtrlState[LucCtrlIndex].enSubState;                                                              /* PRQA S 2983 # JV-01 */

  /*
   * STEP 1:
   * If Global state transition is on-going,
   * hold to start the state transition of a Controller.
   * If wakeup was invoked from Can_SetControllerMode,
   * the first subState is CAN_TENTATIVE_TRANSITION.
   * If wakeup was invoked from the wakeup interrupt,
   * the first subState is CAN_PENDING_WAKEUP_REQUESTED.
   */
  #if (CAN_CANXL_SUPPORTED == STD_ON)
  if(CAN_XL != LpPCController->enControllerType)
  #endif
  {
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    if ((CAN_TENTATIVE_TRANSITION == LenSubState) || (CAN_PENDING_WAKEUP_REQUESTED == LenSubState) ||
        (CAN_PENDING_WAKEUP_WAIT_GLOBALCHANGE == LenSubState))
    {
      /* Critical section is required in case entering to sleep and
        waking up occur on different channels at same time */
     CAN_ENTER_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION_GLOBAL);
      if (CAN_TRUE == Can_GaaGlobalStateTransition[LucUnit])
      {
        /* If any global state transition is on-going now on this RS-CAN unit,
          hold to start the state transition of Controllers */
        LenSubState = CAN_PENDING_WAKEUP_WAIT_GLOBALCHANGE;
        LucResult = E_NOT_OK;
      }
      else
      {
        if (0UL == Can_GaaActiveControllers[LucUnit])
        {
          /* If this is the first wake-up on the Unit,
            start the global state change: GLOBAL_STOP -> GLOBAL_OPERATION */
          Can_GaaGlobalStateTransition[LucUnit] = CAN_TRUE;
          LblGlobalTransitionRequired = CAN_TRUE;
        } /* else No action required */
        /* Set the active (not sleep) bit of this Controller */
        Can_GaaActiveControllers[LucUnit] |= (1UL << LucCtrlIndex);
      }
      CAN_EXIT_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION_GLOBAL);
      if (CAN_TRUE == LblGlobalTransitionRequired)
      {
        /* At first, GLOBAL_STOP -> GLOBAL_RESET */
        LenSubState = CAN_PENDING_WAKEUP_WAIT_GLOBALRESET;
        LucResult = Can_GlobalModeChange(LucUnit, CAN_RSCAN_GMDC_RESET, &LulTimeoutDuration);
        /* Continue to STEP 3 */
      } /* else No action required */
    }
    /*
    * STEP 2:
    * If necessary, wait for GLOBAL_RESET.
    */
    else if ((CAN_PENDING_WAKEUP_WAIT_GLOBALRESET == LenSubState) &&                                                    /* PRQA S 2004 # JV-01 */
            (0UL == (Can_GaaRegs[LucUnit].pCmn->ulGSTS & CAN_RSCAN_GRSTSTS)))
    {
      /* Continue pending */
      LucResult = E_NOT_OK;
    } /* else No action required */

    /*
    * STEP 3:
    * After GLOBAL_RESET, change to GLOBAL_OPEARTION.
    */
    if ((E_OK == LucResult) && (CAN_PENDING_WAKEUP_WAIT_GLOBALRESET == LenSubState))
    {
      LenSubState = CAN_PENDING_WAKEUP_WAIT_GLOBALOP;
      LucResult = Can_GlobalModeChange(LucUnit, CAN_RSCAN_GMDC_OP, &LulTimeoutDuration);
    }
    /*
    * STEP 4:
    * If necessary, wait for GLOBAL_OPERATION.
    */
    else if ((E_OK == LucResult) && (CAN_PENDING_WAKEUP_WAIT_GLOBALOP == LenSubState) &&                                /* PRQA S 2004 # JV-01 */
            (CAN_RSCAN_GOPSTS != Can_GaaRegs[LucUnit].pCmn->ulGSTS))
    {
      /* Continue pending */
      LucResult = E_NOT_OK;
    } /* else No action required */
    /*
    * STEP 5:
    * Change to CHANNEL_RESET.
    */
    if ((E_OK == LucResult) && (CAN_PENDING_WAKEUP_WAIT_RESET != LenSubState))
    {
      /* Clear Global transition on-going flag */
      if (CAN_PENDING_WAKEUP_WAIT_GLOBALOP == LenSubState)
      {
        /* No critical section is required because this can be done atomically */
        Can_GaaGlobalStateTransition[LucUnit] = CAN_FALSE;
      } /* else No action required */

      LenSubState = CAN_PENDING_WAKEUP_WAIT_RESET;
      LucResult = Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_RESET, &LulTimeoutDuration);
      /* Continue to STEP 7 */
    }
    /*
    * STEP 6:
    * Wait for CHANNEL_RESET.
    */
    else if ((E_OK == LucResult) &&                                                                                     /* PRQA S 2004 # JV-01 */
            (CAN_RSCAN_CRSTSTS != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_CSTSMASK)))
    {
      LucResult = E_NOT_OK;
    } /* else No action required.  Continue to STEP 7 */
    #endif
  }
  /*
   * STEP 7:
   * Finish transition.
   */
  if (E_OK == LucResult)                                                                                                /* PRQA S 2995, 2991 # JV-01, JV-01 */
  {
    Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_STOPPED;
    Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;
    /* Indicate mode change to CanIf */
    if (CAN_TRUE == Can_GaaCtrlState[LucCtrlIndex].blWakeupByHW)
    {
      /* If the wakeup transition was triggered by HW, don't call CanIf */
    }
    else
    {
      CanIf_ControllerModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_STOPPED);       /* PRQA S 2985, 3383 # JV-01, JV-01 */
    }
  }
  else
  {
    /* If timeout occurred, update the pending status.
    This should be done at the end of this function once to avoid reentrant
    call from Can_SetControllerMode and Can_MainFunction_Mode. */
    Can_GaaCtrlState[LucCtrlIndex].enSubState = LenSubState;                                                            /* PRQA S 2880 # JV-01 */
  }
  #else /* (CAN_WAKEUP_SUPPORT == STD_ON) */
  /* If the wakeup feature is not supported, just change the logical state */
  Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_STOPPED;
  Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;
  /* Indicate mode change to CanIf */
  CanIf_ControllerModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_STOPPED);           /* PRQA S 2985, 3383 # JV-01, JV-01 */
  #endif /* (CAN_WAKEUP_SUPPORT == STD_ON) */
}

/***********************************************************************************************************************
** Function Name         : Can_StartMode
**
** Service ID            : Not Applicable
**
** Description           : This function initiates the transition to the normal
**                         operating mode with complete functionality.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant from Can_SetControllerMode and
**                         Can_MainFunction_Mode.
**                         Non-reentrant from same API.
**
** Input Parameters      : LucCtrlIndex : Index of Controller config table
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The CAN Driver must be initialized and
**                         Controller state must be CAN_T_STOP (AR422),
**                         CAN_T_WAKEUP (AR422) or CAN_CS_STOPPED (AR431)
**
** Global Variables Used : Can_GaaCtrlState, Can_GpPCController,
**                         Can_GaaRegs
**
** Function(s) invoked   : Can_ClearRxBuffers, Can_EnableTxBuffers,
**                         CanIf_ControllerModeIndication
**
** Registers Used        : (CFD)CmSTS, (CFD)CmERFL, (CFD)THLCCm
**
** Reference ID          : CAN_DUD_ACT_037, CAN_DUD_ACT_037_REG003
** Reference ID          : CAN_DUD_ACT_037_GBL001, CAN_DUD_ACT_037_GBL002,
** Reference ID          : CAN_DUD_ACT_037_GBL003, CAN_DUD_ACT_037_GBL004,
** Reference ID          : CAN_DUD_ACT_037_REG001, CAN_DUD_ACT_037_REG002
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_StartMode(CONST(uint8, AUTOMATIC) LucCtrlIndex)
{
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(Can_SubStatusType, AUTOMATIC) LenSubState;
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  VAR(Std_ReturnType, AUTOMATIC) LucResult;

  LulTimeoutDuration = CAN_TIMEOUT_COUNT;
  LucResult = E_OK;
  LenSubState = Can_GaaCtrlState[LucCtrlIndex].enSubState;
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  LucUnit = LpPCController->ucUnit;
  LucCh = LpPCController->ucCh;

  /*
   * STEP 1:
   * If current state is BusOff, Controller should be CHANNEL_HALT.
   * Change to CHANNEL_RESET to clear tx buffers before start.
   */
  if ((CAN_NO_PENDING_TRANSITION == LenSubState) && (CAN_TRUE == Can_GaaCtrlState[LucCtrlIndex].blBusOff))
  {
    /* Clear error flags */
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL = CAN_RSCAN_ERFL_CLEAR;
    #endif
    Can_GaaCtrlState[LucCtrlIndex].blBusOff = CAN_FALSE;
    /* Change to CHANNEL_RESET mode */
    LenSubState = CAN_PENDING_START_WAIT_RESET;
    LucResult = Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_RESET, &LulTimeoutDuration);
  }
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  /*
   * STEP 2:
   * If necessary, wait for CHANNEL_RESET.
   */
  else if ((CAN_PENDING_START_WAIT_RESET == LenSubState) &&                                                             /* PRQA S 2004 # JV-01 */
           (0UL == (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_CRSTSTS)))
  {
    LucResult = E_NOT_OK;
  } /* else No action required. Continue to STEP 3 */
  #endif
  /*
   * STEP 3:
   * Change to CHANNEL_COMMUNICATION mode.
   */
  if ((E_OK == LucResult) &&
      ((CAN_NO_PENDING_TRANSITION == LenSubState) || (CAN_PENDING_START_WAIT_RESET == LenSubState)))
  {
    #if ((CAN_RX_OBJECT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
    /*
     * Clear all buffers
     * TX_BUFFER, TX_QUEUE and TXRX_FIFO(TxMode) are cleared automatically
     * in CHANNEL_RESET mode.
     * RX_BUFFER, RX_FIFO, TXRX_FIFO(RxMode) must be cleared by software.
     */
    Can_ClearRxBuffers(LucUnit, LucCtrlIndex);
    #endif /* (CAN_RX_OBJECT == STD_ON) */

    /* Change Channel Mode to Communication Mode */
    LenSubState = CAN_PENDING_START_WAIT_COM;
    LucResult = Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_COM, &LulTimeoutDuration);
  }
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  /*
   * STEP 4:
   * Wait for CHANNEL_COMMUNICATION.
   */
  else if ((E_OK == LucResult) && (CAN_PENDING_START_WAIT_COM == LenSubState) &&                                        /* PRQA S 2004 # JV-01 */
           (CAN_RSCAN_COPSTS != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_CSTSMASK)))
  {
    /* Continue pending */
    LucResult = E_NOT_OK;
  } /* else No action required */
  #endif
  /*
   * STEP 5:
   * Finish transition.
   */
  if (E_OK == LucResult)
  {
    #if ((CAN_TX_COMFIFO == STD_ON) || (CAN_GATEWAY_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON) || \
        (CAN_GATEWAY_QUEUE == STD_ON))
    /* Re-enable CFCC.CFE and TXQCC.TXQE
       since these registers are cleared in CHANNEL_RESET */
    Can_EnableTxBuffers(LucUnit, LucCtrlIndex);
    #endif
    #if (CAN_GLOBAL_TIME_SUPPORT == STD_ON) && (CAN_DEVICE_NAME == CAN_X5X) && (CAN_RSCANFD_CONFIGURED == STD_ON)
      /* Setting Can Time Sync for Controller */
      Can_TSCapChStart(LucCtrlIndex);
    #endif /* endif if (CAN_GLOBAL_TIME_SUPPORT == STD_ON) */
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    /* Enable transmit history buffer */
    Can_GaaRegs[LucUnit].pCmn->aaTHLCC[LucCh] = LpPCController->ulTHLCC | CAN_RSCAN_THLE;
    #endif
    /* Inform the upper layer */
    Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_STARTED;
    Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;
    CanIf_ControllerModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_STARTED);         /* PRQA S 3383, 2985 # JV-01, JV-01 */
  }
  else
  {
    /* If timeout occurred, update the pending status.
      This should be done at the end of this function once to avoid reentrant
      call from Can_SetControllerMode and Can_MainFunction_Mode. */
    Can_GaaCtrlState[LucCtrlIndex].enSubState = LenSubState;
  }
}

/***********************************************************************************************************************
** Function Name         : Can_ClearRxBuffers
**
** Service ID            : Not Applicable
**
** Description           : This function clears rx buffers when a Controller
**                         enters CHANNEL_RESET mode.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LucUnit      : RS-CAN(FD) unit index
**                         LucCtrlIndex : Controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of ID must be guaranteed
*                          by the upper layer.
**
** Global Variables Used : Can_GpConfig, Can_GpHohConfig,
**                         Can_GaaRegs
**
** Function(s) invoked   : None
**
** Registers Used        : (CFD)CFCCk, (CFD)RFCCx, (CFD)RMNDy
**
** Reference ID          : CAN_DUD_ACT_051
** Reference ID          : CAN_DUD_ACT_051_REG001, CAN_DUD_ACT_051_REG002,
** Reference ID          : CAN_DUD_ACT_051_REG003, CAN_DUD_ACT_051_REG004
** Reference ID          : CAN_DUD_ACT_051_REG005, CAN_DUD_ACT_051_REG006
** Reference ID          : CAN_DUD_ACT_051_REG007, CAN_DUD_ACT_051_REG008
** Reference ID          : CAN_DUD_ACT_051_REG009
***********************************************************************************************************************/
#if ((CAN_RX_OBJECT == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_ON))
STATIC FUNC(void, CAN_PRIVATE_CODE)
                              Can_ClearRxBuffers(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucCtrlIndex)
{
  P2CONST(Can_HohConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpHoh;                                                         /* PRQA S 3432 # JV-01 */
  VAR(uint16, AUTOMATIC) LusHohIndex;
  #if (CAN_RX_BUFFER == STD_ON)
  VAR(uint32, AUTOMATIC) LulRMNDIndex;
  VAR(uint32, AUTOMATIC) LulRMNDMask;
  #endif

  /* Scan all HOH objects */
  for (LusHohIndex = 0U; LusHohIndex < Can_GpConfig->usNoOfHohs; LusHohIndex++)                                         /* PRQA S 3416 # JV-01 */
  {
    LpHoh = &Can_GpHohConfig[LusHohIndex];
    /* If ths HOH is HRH and belongs to this Controller, process it */
    if ((LpHoh->ucController == LucCtrlIndex) && (CAN_HOH_HRH == LpHoh->enHoh))
    {
      switch (LpHoh->enBufferType)
      {
      #if (CAN_RX_COMFIFO == STD_ON)
      case CAN_BUFFERTYPE_TXRXFIFO:      
        /* Disable TxRxFIFO(RxMode) */
        Can_GaaRegs[LucUnit].pCmn->aaCFCC[LpHoh->usBufferIndex] = LpHoh->ulXXCCRegValue;
        /* Re-Enable TxRxFIFO(RxMode) */
        Can_GaaRegs[LucUnit].pCmn->aaCFCC[LpHoh->usBufferIndex] = LpHoh->ulXXCCRegValue | CAN_RSCAN_CFE;
        #if (CAN_ENABLE_DMA_MODE == STD_ON)
        if (LpHoh->blDmaEnable == CAN_TRUE)
        {
          Can_DmaStart(LusHohIndex,LucUnit);
        }/* Else no action required */
        #endif
        break;
      #endif
      #if (CAN_RX_FIFO == STD_ON)
      case CAN_BUFFERTYPE_RXFIFO:    
        /* Disable Rx FIFO */
        Can_GaaRegs[LucUnit].pCmn->aaRFCC[LpHoh->usBufferIndex] = LpHoh->ulXXCCRegValue;
        /* Re-Enable Rx FIFO */
        Can_GaaRegs[LucUnit].pCmn->aaRFCC[LpHoh->usBufferIndex] = LpHoh->ulXXCCRegValue | CAN_RSCAN_RFE;
        #if (CAN_ENABLE_DMA_MODE == STD_ON)
        if (LpHoh->blDmaEnable == CAN_TRUE)
        {
          Can_DmaStart(LusHohIndex,LucUnit);
        }/* Else no action required */
        #endif
        break;
      #endif
      #if (CAN_RX_BUFFER == STD_ON)
      case CAN_BUFFERTYPE_BUFFER:
        /* Get index and bit position of RMND registers for this buffer */
        LulRMNDIndex = CAN_RSCAN_RMND_GET_INDEX(LpHoh->usBufferIndex);
        LulRMNDMask = CAN_RSCAN_RMND_GET_BITMASK(LpHoh->usBufferIndex);
        /* Clear receive flag */
        Can_GaaRegs[LucUnit].pCmn->aaRMND[LulRMNDIndex] = ~LulRMNDMask;
        break;
      #endif
      default:
        /* Never executed */
        break;
      } /* switch (LpHoh->enBufferType) */
    } /* else No action required */
  }
}
#endif

/***********************************************************************************************************************
** Function Name         : Can_EnableTxBuffers
**
** Service ID            : Not Applicable
**
** Description           : This function enables Tx buffers when
**                         a Controller is re-started.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LucUnit      : RS-CAN(FD) unit index
**                         LucCtrlIndex : Controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of ID must be guaranteed
*                          by the upper layer.
**
** Global Variables Used : Can_GpConfig, Can_GpHohConfig,
**                         Can_GaaRegs
**
** Function(s) invoked   : None
**
** Registers Used        : (CFD)CFCCk, (CFD)TXQCCm
**
** Reference ID          : CAN_DUD_ACT_052
** Reference ID          : CAN_DUD_ACT_052_REG001, CAN_DUD_ACT_052_REG002
** Reference ID          : CAN_DUD_ACT_052_REG003, CAN_DUD_ACT_052_REG004
***********************************************************************************************************************/
#if ((CAN_TX_COMFIFO == STD_ON) || (CAN_GATEWAY_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON) || \
     (CAN_GATEWAY_QUEUE == STD_ON))
STATIC FUNC(void, CAN_PRIVATE_CODE)
                              Can_EnableTxBuffers(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucCtrlIndex)
{
  P2CONST(Can_HohConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpHoh;                                                         /* PRQA S 3432 # JV-01 */
  VAR(uint16, AUTOMATIC) LusHohIndex;
  #if ((CAN_TX_QUEUE == STD_ON) || (CAN_GATEWAY_QUEUE == STD_ON))
  VAR(uint32, AUTOMATIC) LulTxQCh;
  VAR(uint32, AUTOMATIC) LulTxQIdx;
  #endif

  /* Scan all HOH objects */
  for (LusHohIndex = 0U; LusHohIndex < Can_GpConfig->usNoOfHohs; LusHohIndex++)                                         /* PRQA S 3416 # JV-01 */
  {
    LpHoh = &Can_GpHohConfig[LusHohIndex];
    /* If this HOH belongs to this Controller, process it according to a type */
    if (LpHoh->ucController == LucCtrlIndex)
    {
      #if ((CAN_TX_COMFIFO == STD_ON) || (CAN_GATEWAY_COMFIFO == STD_ON))
      if (((CAN_BUFFERTYPE_TXRXFIFO == LpHoh->enBufferType) && (CAN_HOH_HTH == LpHoh->enHoh)) ||
          (CAN_BUFFERTYPE_GATEWAY == LpHoh->enBufferType))
      {
        Can_GaaRegs[LucUnit].pCmn->aaCFCC[LpHoh->usBufferIndex] = LpHoh->ulXXCCRegValue | CAN_RSCAN_CFE;
        #if (CAN_ENABLE_DMA_MODE == STD_ON)
        if (LpHoh->blDmaEnable == CAN_TRUE)
        {
          Can_DmaStart(LusHohIndex,LucUnit);
        }/* Else no action required */
        #endif
      } /* else No action required if (CAN_TX_QUEUE == STD_OFF) && (CAN_GATEWAY_QUEUE == STD_OFF*/
      #endif
      #if ((CAN_TX_QUEUE == STD_ON) || (CAN_GATEWAY_QUEUE == STD_ON))
      if (CAN_BUFFERTYPE_TXQUEUE == LpHoh->enBufferType)
      {
        LulTxQCh = (uint32)LpHoh->usBufferIndex / CAN_RSCAN_TXQUEUE_PER_CH;
        LulTxQIdx = (uint32)LpHoh->usBufferIndex % CAN_RSCAN_TXQUEUE_PER_CH;
        Can_GaaRegs[LucUnit].pCmn->aaTQueueReg[LulTxQIdx].aaTXQCC[LulTxQCh] = LpHoh->ulXXCCRegValue | CAN_RSCAN_TXQE;
      } /* else No action required */
      #endif
    } /* else No action required */
  }
}
#endif /* ((CAN_TX_COMFIFO == STD_ON) || (CAN_GATEWAY_COMFIFO == STD_ON) || \
      (CAN_TX_QUEUE == STD_ON) || (CAN_GATEWAY_QUEUE == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : Can_StopMode
**
** Service ID            : Not Applicable
**
** Description           : This function initiates the transition to stop mode.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant from Can_SetControllerMode and
**                         Can_MainFunction_Mode.
**                         Non-reentrant from same API.
**
** Input Parameters      : LucCtrlIndex : Index of Controller config table
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The CAN Driver must be initialized.
**
** Global Variables Used : Can_GaaCtrlState, Can_GpPCController,
**                         Can_GaaRegs
**
** Function(s) invoked   : Can_ChannelModeChange,
**                         CanIf_ControllerModeIndication
**
** Registers Used        : (CFD)CmSTS
**
** Reference ID          : CAN_DUD_ACT_038
** Reference ID          : CAN_DUD_ACT_038_GBL001, CAN_DUD_ACT_038_GBL002
** Reference ID          : CAN_DUD_ACT_038_GBL003
***********************************************************************************************************************/
FUNC(void, CAN_PRIVATE_CODE) Can_StopMode(CONST(uint8, AUTOMATIC) LucCtrlIndex)
{
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(Can_SubStatusType, AUTOMATIC) LenSubState;
  VAR(Std_ReturnType, AUTOMATIC) LucResult;
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;

  LucResult = E_OK;
  LulTimeoutDuration = CAN_TIMEOUT_COUNT;
  LenSubState = Can_GaaCtrlState[LucCtrlIndex].enSubState;
  LucUnit = Can_GpPCController[LucCtrlIndex].ucUnit;
  LucCh = Can_GpPCController[LucCtrlIndex].ucCh;

  /*
   * STEP 1:
   * If the current state is START, change to HALT mode before RESET mode
   * to wait the completion of on-going transmission or reception.
   * If the STOP transition is invoked from Can_SetControlerMode,
   * the first subState is CAN_TENTATIVE_TRANSITION.
   * If the STOP transition is invoked from BusOff,
   * the state transition is done immediately and this function is not invoked.
   */
  if (CAN_TENTATIVE_TRANSITION == LenSubState)
  {
    LenSubState = CAN_PENDING_STOP_WAIT_HALT;
    LucResult = Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_HALT, &LulTimeoutDuration);
  }
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  /*
   * STEP 2:
   * If necessary, wait for the completion to change to CHANNEL_HALT mode.
   */
  else if ((CAN_PENDING_STOP_WAIT_HALT == LenSubState) &&                                                               /* PRQA S 2004 # JV-01 */
           (0UL == (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_CHLTSTS)))
  {
    LucResult = E_NOT_OK;
  } /* else No action required */
  #endif
  /*
   * STEP 3:
   * Change the controller to CHANNEL_RESET mode.
   */
  if ((E_OK == LucResult) && (CAN_PENDING_STOP_WAIT_RESET != LenSubState))
  {
    LenSubState = CAN_PENDING_STOP_WAIT_RESET;
    LucResult = Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_RESET, &LulTimeoutDuration);
  }
  /*
   * STEP 4:
   * Wait for the completion to change to CHANNEL_RESET mode.
   */
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  else if ((E_OK == LucResult) && (0UL == (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS & CAN_RSCAN_CRSTSTS)))       /* PRQA S 2004 # JV-01 */
  {
    /* Continue to pending */
    LucResult = E_NOT_OK;
  } /* else No action required */
  #endif
  /*
   * STEP 5:
   * Clear all received data and notify CanIf.
   */
  if (E_OK == LucResult)
  {
    /* Set the Controller to stop mode */
    Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_STOPPED;
    Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;

    /* Indicate mode change to CanIf */
    CanIf_ControllerModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CAN_COMMON_IF_STATE_STOPPED);         /* PRQA S 3383, 2985 # JV-01, JV-01 */
  }
  else
  {
    /* If timeout occurred, update the pending status.
    This should be done at the end of this function once to avoid reentrant
    call from Can_SetControllerMode and Can_MainFunction_Mode. */
    Can_GaaCtrlState[LucCtrlIndex].enSubState = LenSubState;
  }
}

/***********************************************************************************************************************
** Function Name         : Can_GlobalModeChange
**
** Service ID            : Not Applicable
**
** Description           : Perform global mode change of RACAN.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LucUnit   : Module number of RSCANn
**                         LulMdBits : Mode bits of GCTR register
**
** InOut Parameters      : LpTimeoutDuration  Timeout counts with OsCounter,
**                                  actual elapsed time is subtracted from this.
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**
** Preconditions         : None
**
** Global Variables Used : Can_GaaRegs
**
** Function(s) invoked   : Can_WaitRegisterChange
**
** Registers Used        : (CFD)GCTR, (CFD)GSTS
**
** Reference ID          : CAN_DUD_ACT_039
** Reference ID          : CAN_DUD_ACT_039_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, CAN_PRIVATE_CODE) Can_GlobalModeChange(CONST(uint8, AUTOMATIC) LucUnit,                            /* PRQA S 1503 # JV-01 */
 CONST(uint32, AUTOMATIC) LulMdBits, CONSTP2VAR(uint32, AUTOMATIC, CAN_APPL_DATA) LpTimeoutDuration)                    /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  VAR(Std_ReturnType, AUTOMATIC) LucResult;
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  Can_GaaRegs[LucUnit].pCmn->ulGCTR = LulMdBits;
  LucResult =
      Can_WaitRegisterChange(&Can_GaaRegs[LucUnit].pCmn->ulGSTS, CAN_RSCAN_GSTSMASK, LulMdBits, LpTimeoutDuration);
  #else
  (void) LucUnit;
  (void) LulMdBits;
  (void) LpTimeoutDuration;
  LucResult = E_NOT_OK;
  #endif
  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Can_ChannelModeChange
**
** Service ID            : Not Applicable
**
** Description           : Perform channel mode change of RACAN.
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LucUnit   : Module number of RSCANn
**                         LucCh     : Channel number
**                         LulMdBits : Mode bits of CmCTR register
**
** InOut Parameters      : LpTimeoutDuration  Timeout counts with OsCounter,
**                                  actual elapsed time is subtracted from this.
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**
** Preconditions         : None
**
** Global Variables Used : Can_GaaRegs
**
** Function(s) invoked   : Can_WaitRegisterChange
**
** Registers Used        : (CFD)CmCTR, (CFD)CmSTS
**
** Reference ID          : CAN_DUD_ACT_040
** Reference ID          : CAN_DUD_ACT_040_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, CAN_PRIVATE_CODE) Can_ChannelModeChange(CONST(uint8, AUTOMATIC) LucUnit,                           /* PRQA S 1505 # JV-01 */
  CONST(uint8, AUTOMATIC) LucCh,CONST(uint32, AUTOMATIC) LulMdBits,
  CONSTP2VAR(uint32, AUTOMATIC, CAN_APPL_DATA) LpTimeoutDuration)                                                       /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  VAR(Std_ReturnType, AUTOMATIC) LucResult;
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  P2CONST(volatile uint32, AUTOMATIC, REGSPACE) LpSTSReg;                                                               /* PRQA S 3432 # JV-01 */

  Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR =
                                (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR & ~CAN_RSCAN_CHMDC_MASK) | LulMdBits;

  LpSTSReg = &Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS;
  LucResult = Can_WaitRegisterChange(LpSTSReg, CAN_RSCAN_CSTSMASK, LulMdBits, LpTimeoutDuration);
  #else
  (void)LucUnit;
  (void)LucCh;
  (void)LulMdBits;
  (void)LpTimeoutDuration;
  LucResult = E_NOT_OK;
  #endif
  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Can_WaitRegisterChange
**
** Service ID            : Not Applicable
**
** Description           : Wait for change of status register
**
** Sync/Async            : None
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LpReg   : Address of status register
**                         LulMask : Mask bits to be compared
**                         LulBits : Comparition bits
**
** InOut Parameters      : LpTimeoutDuration  Timeout counts with OsCounter,
**                                  actual elapsed time is subtracted from this.
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**
** Preconditions         : The availability of parameters must be guaranteed
**                         by the upper layer.
**
** Global Variables Used : None
**
** Function(s) invoked   : GetCounterValue()
**
** Registers Used        : Depend on LpReg
**
** Reference ID          : CAN_DUD_ACT_041
***********************************************************************************************************************/
FUNC(Std_ReturnType, CAN_PRIVATE_CODE)
Can_WaitRegisterChange(volatile CONSTP2CONST(uint32, AUTOMATIC, REGSPACE) LpReg, CONST(uint32, AUTOMATIC) LulMask,
                      CONST(uint32, AUTOMATIC) LulBits, CONSTP2VAR(uint32, AUTOMATIC, CAN_APPL_DATA) LpTimeoutDuration) /* PRQA S 3432 # JV-01 */
{
  VAR(Std_ReturnType, AUTOMATIC) LucResult;
  #if (CAN_WAKEUP_SUPPORT == STD_OFF)
  VAR(TickType, AUTOMATIC) LddPrevTime;
  VAR(TickType, AUTOMATIC) LddCurrentTime;
  VAR(uint32, AUTOMATIC) LulTimeLapse;
  #endif
#if (CAN_WAKEUP_SUPPORT == STD_ON)
  /* Gen4 supported only */
  LucResult = E_OK;
  /* Wait until mode change completion or timeout */
  while (((*LpReg & LulMask) != LulBits) && ((uint32)0 < *LpTimeoutDuration))
  {
    *LpTimeoutDuration = *LpTimeoutDuration - (uint32)1;
  }

  if ((*LpReg & LulMask) != LulBits)
  {
    LucResult = E_NOT_OK;
  } /* else No action required */
#else

  LulTimeLapse = 0UL;
  LucResult = E_OK;

  /* Get initial count */
  (void)GetCounterValue(CAN_OS_COUNTER_ID, &LddPrevTime);

  /* Wait until mode change completion or timeout */
  while (((*LpReg & LulMask) != LulBits) && (E_OK == LucResult))
  {
    /* Get current count */
    (void)GetCounterValue(CAN_OS_COUNTER_ID, &LddCurrentTime);
    /* Check whether timer lapped */
    if (LddPrevTime > LddCurrentTime)
    {
      /* When timer lapped, add remained counts from previous value to lapping.
         '1UL' means extra one count when lapping (MAX -> 0). */
      LulTimeLapse += (uint32)((TickType)CAN_OS_COUNTER_MAX_VALUE - LddPrevTime);                                       /* PRQA S 3384 # JV-01 */
      LulTimeLapse += (uint32)(LddCurrentTime + 1UL);                                                                   /* PRQA S 3384 # JV-01 */
    }
    else
    {
      /* Otherwise, accumulate the delta counts simply. */
      LulTimeLapse = LulTimeLapse + (uint32)(LddCurrentTime - LddPrevTime);                                             /* PRQA S 3383 # JV-01 */
    }
    /* Update the previous count */
    LddPrevTime = LddCurrentTime;
    /* Check timeout */
    if (*LpTimeoutDuration <= LulTimeLapse)
    {
      /* Set error and break wait loop */
      LucResult = E_NOT_OK;
    } /* else No action required */
  }
  /* Subtruct actual elapsed time from the parameter */
  *LpTimeoutDuration = *LpTimeoutDuration - LulTimeLapse;                                                               /* PRQA S 3383 # JV-01 */
#endif /* #if (CAN_WAKEUP_SUPPORT == STD_ON)*/
  return LucResult;
}
#if (CAN_ENABLE_DMA_MODE == STD_ON)
/***********************************************************************************************************************
** Function Name        : Can_DmaStart
**
** Service ID           : NA
**
** Description          : This internal function configures DMA transfer in DMA channel register for requested group.
**
** Sync/Async           : Synchronous
**
** Re-entrancy          : Reentrant for different DMA channels, Non-Reentrant for the same DMA channel
**
** Input Parameters     : LusHohIndex, LucUnit
**
** InOut Parameters     : None
**
** Output Parameters    : None
**
** Return Parameter     : None
**
** Preconditions        : None
**
** Global Variables     : Can_GpHohConfig, Can_GaaRegs
**
** Functions invoked    : None
**
** Registers Used       : PDMAjDCSTCn, PDMAjDSAn, PDMAjDDAn, PDMAjDTCn, PDMAjDTCTn, PDMAjDRSAn, PDMAjDRDAn, PDMAjDRTCn,
**                        PDMAjDCENn
**
** Reference ID         : CAN_DUD_ACT_193
** Reference ID         : CAN_DUD_ACT_193_GBL001, CAN_DUD_ACT_193_REG001
** Reference ID         : CAN_DUD_ACT_193_REG002, CAN_DUD_ACT_193_REG003
** Reference ID         : CAN_DUD_ACT_193_REG004, CAN_DUD_ACT_193_REG005
***********************************************************************************************************************/
STATIC FUNC(void, CAN_PRIVATE_CODE) Can_DmaStart(uint16 LusHohIndex, uint8 LucUnit)                                     /* PRQA S 3006 # JV-01 */
{
  P2CONST(Can_HohConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpHoh;
  P2CONST(Can_DmaConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpDmaConfig;
  uint32 LulRFPLS;
  uint32 LulTC;
  uint8 LucController;
  uint32 const LaaCanRFPLStoPayloadLength[8] = {8,12,16,20,24,32,48,64};

  LpHoh = &Can_GpHohConfig[LusHohIndex];
  LpDmaConfig = LpHoh->pDMAConfig;
  LucController = Can_GpPCController[LpHoh->ucController].ucCh;
  if (LpHoh->enHoh == CAN_HOH_HRH)
  {
    /* Enable DMA transfer request for RX FIFIO */
    if (LpHoh->enBufferType == CAN_BUFFERTYPE_RXFIFO)
    {
      Can_GaaRegs[LucUnit].pCmn->ulCDTCT |= (uint32)(CAN_ONE << LpHoh->usBufferIndex);
    }
    else 
    {
      /* Enable DMA transfer request for COM FIFIO Rx*/
      Can_GaaRegs[LucUnit].pCmn->ulCDTCT |= (uint32)(CAN_DMA_CFDMAE_RX << LucController);
    }
    LulRFPLS = (LpHoh->ulXXCCRegValue & CAN_DMA_RFPLS_MASK) >> 4;
    LulRFPLS = (uint32)LaaCanRFPLStoPayloadLength[LulRFPLS];

    LulTC = (LulRFPLS >> 2) + CAN_THREE;                                                                                /* PRQA S 3383, 3416 # JV-01, JV-01 */

    /* Setup value of transfer count per hardware request */
    LpDmaConfig->pDmaRegs->ulPDMAjDTCn &= (uint32)(~CAN_DMA_TRC_MASK);
    LpDmaConfig->pDmaRegs->ulPDMAjDTCn |= LulTC & CAN_DMA_TRC_MASK;
    /* Setup Reload value of transfer count per hardware request */
    LpDmaConfig->pDmaRegs->ulPDMAjDRTCn = LulTC;
    /* Start DMA */
    LpDmaConfig->pDmaRegs->ulPDMAjDCENn = CAN_DMA_DTE;
    /* Perform dummy read and synchronization for PDMAjDCENn */
    (void)LpDmaConfig->pDmaRegs->ulPDMAjDCENn;
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
  }
  /* (LpHoh->enHoh == CAN_HOH_HTH) */
  else
  {
    /* Enable DMA transfer request for COM FIFO Tx*/
    /* TX QUEUE is not supported yet due to no DMA transfer request correspoding */
    Can_GaaRegs[LucUnit].pCmn->ulCDTTCT |= (uint32)(CAN_DMA_CFDMAE_TX << LucController);

    LulRFPLS = (LpHoh->ulXXCCRegValue & CAN_DMA_RFPLS_MASK) >> 4;
    LulRFPLS = (uint32)LaaCanRFPLStoPayloadLength[LulRFPLS];
    LulTC = (LulRFPLS >> 2); // can_data_payload_length /4

    /* Setup value of transfer count per hardware request */
    LpDmaConfig->pDmaRegs->ulPDMAjDTCn &= ~CAN_DMA_TRC_MASK;
    LpDmaConfig->pDmaRegs->ulPDMAjDTCn |= LulTC & CAN_DMA_TRC_MASK;
    /* Setup Reload value of transfer count per hardware request */
    LpDmaConfig->pDmaRegs->ulPDMAjDRTCn = LulTC;
  }
}
#endif /*(CAN_ENABLE_DMA_MODE == STD_ON)*/
#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Can_SelfTestChannel
**
** Service ID            : 0x23
**
** Description           : This service initiates the transition of mode
**                         to execute a self test in internal or external
**                         loop back mode.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : Controller : Controller ID
**                         TestTransition : Target state
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType(E_OK/E_NOT_OK)
**
** Preconditions         : The CAN Driver must be initialized and the
**                         controller must be in CAN_T_START state.
**
** Global Variables Used : Can_GpPCController.
**
** Function(s) invoked   : Det_ReportError, Can_CommonDetCheck
**                         Can_ChannelModeChange, CAN_DEM_REPORT_ERROR.
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_117, CAN_DUD_ACT_117_ERR001
** Reference ID          : CAN_DUD_ACT_117_ERR002, CAN_DUD_ACT_117_ERR003, CAN_DUD_ACT_117_ERR004
***********************************************************************************************************************/
#if (STD_ON == CAN_SELFTEST_API)
#define CAN_START_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_SelfTestChannel(                                                              /* PRQA S 1503 # JV-01 */
  VAR(uint8, AUTOMATIC) Controller,
  VAR(Can_SelfTestType, AUTOMATIC) TestTransition)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  /* Variable to hold the return value */
  VAR(Std_ReturnType, AUTOMATIC) LucReturnValue;
  VAR(uint8, AUTOMATIC) LucCh;
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(uint8, AUTOMATIC) LucUnit;
  #endif

  #if ((CAN_CANXL_SUPPORTED == STD_ON) && (CAN_DEV_ERROR_DETECT == STD_OFF))
  LucReturnValue = E_OK;
  #endif

#if (CAN_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Can_CommonDetCheck(CAN_SELFTEST_CHANNEL_SID, Controller);
  if (E_OK != LucReturnValue)
  {
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* Report to DET, if the TestTransition is out of range. */
    if (CAN_T_SELF_INTERNAL < TestTransition)
    {
      /* Report to DET */
      (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_SELFTEST_CHANNEL_SID, CAN_E_TRANSITION);
      /* Set the error status flag to true */
      LucReturnValue = E_NOT_OK;
    } /* else No action required */
  }
  /* Check whether any development error occurred. */
  if (E_NOT_OK != LucReturnValue)
#endif
  {
    LpPCController = &Can_GpPCController[Controller];
    #if (CAN_RSCANFD_CONFIGURED == STD_ON)
    LucUnit = LpPCController->ucUnit;
    #endif
    LucCh = LpPCController->ucCh;                                                                                       /* PRQA S 2983 # JV-01 */
    #if (CAN_CANXL_SUPPORTED == STD_ON)
    if(CAN_XL != Can_GpPCController[LucCh].enControllerType)                                                            /* PRQA S 3416 # JV-01 */
    {
    #endif
      /* Transition to Channel HALT mode */
      #if (CAN_RSCANFD_CONFIGURED == STD_ON)
      LulTimeoutDuration = CAN_TIMEOUT_COUNT;
      LucReturnValue =
      Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_HALT, &LulTimeoutDuration);

      /* Check whether status of channel is in HALT mode. */
      if (E_OK != LucReturnValue)                                                                                       /* PRQA S 2991, 2995 # JV-01, JV-01 */
      {
  #ifdef CAN_E_TIMEOUT_FAILURE
        /* Report to DEM if timeout occurs */
        CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);
  #endif
      }
      else
      {
        /* Invoke internal function to execute self test processing. */
        Can_SelfTestModeProcessing(TestTransition, LucUnit, LucCh);
        /* Transition to Channel COMMUNICATION mode */
        LucReturnValue =
        Can_ChannelModeChange(LucUnit, LucCh, CAN_RSCAN_CHMDC_COM, &LulTimeoutDuration);
  #ifdef CAN_E_TIMEOUT_FAILURE
        if (E_OK != LucReturnValue)
        {
          /* Report to DEM if timeout occurs */
          CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);
        } /* else No action required */
  #endif
      }
    #endif /*CAN_RSCANFD_CONFIGURED == STD_ON*/
    #if (CAN_CANXL_SUPPORTED == STD_ON)
    }
    else 
    {
      LucCh = Can_GpConfig->pCanXLSecondPhysicalControllerToIndex[Controller];
      if (CAN_COMMON_STATE_STOPPED != Can_GaaCtrlState[Controller].enMode) 
      {
        #if (CAN_DEV_ERROR_DETECT == STD_ON)
        /* Set the error status flag to true */
        (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_SELFTEST_CHANNEL_SID, CAN_E_INV_MODE);
        #endif
        LucReturnValue = E_NOT_OK;
      }
      if (E_OK == LucReturnValue)                                                                                       /* PRQA S 2962 # JV-01 */
      {
        Can_SelfTestModeProcessing(TestTransition, 0U, LucCh);
      }
    }
    #endif /* #if (CAN_CANXL_SUPPORTED == STD_ON)*/
  } /* else No action required */
  return LucReturnValue;                                                                                                /* PRQA S 2962 # JV-01 */
}
#define CAN_STOP_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* #if (STD_ON == CAN_SELFTEST_API) */

/***********************************************************************************************************************
** Function Name         : Can_SelfTestModeProcessing
**
** Service ID            : Not Applicable
**
** Description           : This service execute a self test in internal or
**                         external loop back mode.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LenTestTransition : Target loop back mode.
**                         LucUnit : Module number of RSCANn.
**                         LucCh : Channel number.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The CAN Driver must be initialized and the controller
**                         must be in CAN_T_START state.
**
** Global Variables Used : Can_GaaRegs.
**
** Function(s) invoked   : None
**
** Registers Used        : (CFD)CmCTR
**
** Reference ID          : CAN_DUD_ACT_118, CAN_DUD_ACT_118_REG001
** Reference ID          : CAN_DUD_ACT_118_REG002, CAN_DUD_ACT_118_REG003
** Reference ID          : CAN_DUD_ACT_118_REG004, CAN_DUD_ACT_118_REG005
** Reference ID          : CAN_DUD_ACT_118_REG006, CAN_DUD_ACT_118_REG007
** Reference ID          : CAN_DUD_ACT_118_REG008, CAN_DUD_ACT_118_REG009
** Reference ID          : CAN_DUD_ACT_118_REG010, CAN_DUD_ACT_118_REG011
** Reference ID          : CAN_DUD_ACT_118_REG012
***********************************************************************************************************************/
#if (STD_ON == CAN_SELFTEST_API)
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
static FUNC(void, CAN_PRIVATE_CODE) Can_SelfTestModeProcessing(
  VAR(Can_SelfTestType, AUTOMATIC) LenTestTransition,
  VAR(uint8, AUTOMATIC) LucUnit,
  VAR(uint8, AUTOMATIC) LucCh)
{

  #if (CAN_CANXL_SUPPORTED == STD_ON) && (CAN_RSCANFD_CONFIGURED == STD_OFF)
  (void)LucUnit;
  #endif
  #if (CAN_CANXL_SUPPORTED == STD_ON)
  if(CAN_XL == Can_GpPCController[LucCh].enControllerType)                                                              /* PRQA S 3416 # JV-01 */
  {
    /* unlock test mode register */ 
    CanXL_GaaRegs[LucCh].pPRT->ulLOCK = CANXL_TESTMODE_KEY_0;
    CanXL_GaaRegs[LucCh].pPRT->ulLOCK = CANXL_TESTMODE_KEY_1;
  }
  #endif
  switch (LenTestTransition)
  {
  case CAN_T_SELF_OFF:
      #if (CAN_CANXL_SUPPORTED == STD_ON)
      if(CAN_XL != Can_GpPCController[LucCh].enControllerType)                                                          /* PRQA S 3416 # JV-01 */
      #endif
      {
      #if (CAN_RSCANFD_CONFIGURED == STD_ON)
      /* Setting CTME and CTMS[1:0] bits in the (CFD)CmCTR register to 0 */
        Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR &= CAN_RSCAN_CTM_MASK;
      #endif /*#if (CAN_RSCANFD_CONFIGURED == STD_ON)*/
      }

      #if (CAN_CANXL_SUPPORTED == STD_ON)
      else
      {
      /* Disable LBCK test mode  */ 
        CanXL_GaaRegs[LucCh].pPRT->ulTEST = CANXL_DISABLE_LBCK_TXRXNOMAL;
      /* Disable testmode register  */ 
        CanXL_GaaRegs[LucCh].pPRT->ulCTRL = CANXL_DISABLE_TESTMODE;
      }
      #endif
  break;
  case CAN_T_SELF_EXTERNAL:
      #if (CAN_CANXL_SUPPORTED == STD_ON)
      if(CAN_XL != Can_GpPCController[LucCh].enControllerType)                                                          /* PRQA S 3416 # JV-01 */
      #endif
      {
        #if (CAN_RSCANFD_CONFIGURED == STD_ON)
        /* Set CTME bit in the (CFD)CmCTR register to 1 */
        Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR |= CAN_RSCAN_CTME;
        /* Clear CTMS[1:0] bit in the (CFD)CmCTR register to B'00 */
        Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR &= (CAN_RSCAN_CTM_MASK | CAN_RSCAN_CTME);
        /* Set CTMS[1:0] bit in the (CFD)CmCTR register to B'10 */
        Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR |= CAN_RSCAN_CTMS_SELF0;
        #endif
      }
      #if (CAN_CANXL_SUPPORTED == STD_ON)
      else 
      {
     /* Enable CTRL test mode */
        CanXL_GaaRegs[LucCh].pPRT->ulCTRL = CANXL_ENABLE_TESTMODE;
     /* Enable LBCK test mode */
        CanXL_GaaRegs[LucCh].pPRT->ulTEST = CANXL_ENABLE_LBCK_TXRXNOMAL;
      }
      #endif
  break;
  #if (CAN_RSCANFD_CONFIGURED == STD_ON)
  case CAN_T_SELF_INTERNAL:
      #if (CAN_CANXL_SUPPORTED == STD_ON)
      if(CAN_XL != Can_GpPCController[LucCh].enControllerType)                                                          /* PRQA S 3416 # JV-01 */
      #endif
      {
        /* Set CTME and bit in the (CFD)CmCTR register to 1 */
        Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR |= CAN_RSCAN_CTME;
        /* Set CTMS[1:0] bit in the (CFD)CmCTR register to B'11 */
        Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR |= CAN_RSCAN_CTMS_SELF1;
      }
  break;
  #endif
  default:
      /* No action required */
  break;
  }
}
#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* #if (STD_ON == CAN_SELFTEST_API) */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
