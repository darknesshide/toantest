/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_RamTest.c                                                                                       */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Pretended Networking Functionality                                                                    */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.2: 04/05/2026 : Update Can_RAMTest to fix max rampages and unit index issue
 * 1.3.1: 09/03/2026 : Update Can_RAMTest and Add QAC 2983
 * 1.3.0: 20/01/2026 : Add QAC message 1710
 * 1.1.2: 31/12/2025 : Add QAC message 1710
 * 1.1.1: 25/09/2025 : Update Can_RAMTest
 * 1.1.0: 05/06/2025 : Remove else do not thing
 *                     Add QAC message 2004
 * 1.0.3: 07/05/2025 : Update pre-compile condition for Can_RAMTest
 *        24/04/2025 : Update Project name and devices name
 * 1.0.2: 28/03/2025 : Support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/**********************************************************************************************************************/
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* CAN module header file */
#include "Can.h"
/* Included for RAM variable declarations */
#include "Can_Ram.h"
/* including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define CAN_RAMTEST_C_AR_RELEASE_MAJOR_VERSION     CAN_AR_RELEASE_MAJOR_VERSION_VALUE
#define CAN_RAMTEST_C_AR_RELEASE_MINOR_VERSION     CAN_AR_RELEASE_MINOR_VERSION_VALUE
#define CAN_RAMTEST_C_AR_RELEASE_REVISION_VERSION  CAN_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define CAN_RAMTEST_C_SW_MAJOR_VERSION    CAN_SW_MAJOR_VERSION_VALUE
#define CAN_RAMTEST_C_SW_MINOR_VERSION    CAN_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (CAN_RAMTEST_C_AR_RELEASE_MAJOR_VERSION != CAN_AR_RELEASE_MAJOR_VERSION)
  #error "Can_RamTest.c : Mismatch in Release Major Version"
#endif
#if (CAN_RAMTEST_C_AR_RELEASE_MINOR_VERSION != CAN_AR_RELEASE_MINOR_VERSION)
  #error "Can_RamTest.c : Mismatch in Release Minor Version"
#endif
#if (CAN_RAMTEST_C_AR_RELEASE_REVISION_VERSION != CAN_AR_RELEASE_REVISION_VERSION)
  #error "Can_RamTest.c : Mismatch in Release Revision Version"
#endif

#if (CAN_RAMTEST_C_SW_MAJOR_VERSION  != CAN_SW_MAJOR_VERSION)
  #error "Can_RamTest.c : Mismatch in Software Major Version"
#endif

#if (CAN_RAMTEST_C_SW_MINOR_VERSION != CAN_SW_MINOR_VERSION)
  #error "Can_RamTest.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:2983)    : This assignment is redundant. The value of this object is never subsequently used.           */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : The value is to increment the pointer to the next item.                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, MISRA C:2012 Rule-18.4                                                        */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0857)    : Number of macro definitions exceeds 1024 - program does not conform strictly to ISO:C90.     */
/* Rule                : MISRA C:2012 Dir-1.1                                                                         */
/* JV-01 Justification : The number of macro depend on module code size. There is no issue when number of macro is    */
/*                       over 1024                                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Rule-2.1                                                         */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2814)    : Possible: Dereference of NULL pointer.                                                       */
/* Rule                : CERTCCM EXP34                                                                                */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification or it was    */
/*                       checked or do not dereference to NULL pointer.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2824)    : Possible: Arithmetic operation on NULL pointer.                                              */
/* Rule                : CERTCCM EXP34                                                                                */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2844)    : Possible: Dereference of an invalid pointer value.                                           */
/* Rule                : CERTCCM ARR30                                                                                */
/* JV-01 Justification : It is specific for device register accessing and confirmed has no issue in software behavior.*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45                                                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                : MISRA C:2012 Rule-20.1                                                                       */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message(6:2996)     : The result of this logical operation is always 'false'.                                      */
/* Rule                : No MISRA-C:2012 Rules applicable to message 2996, CWE-561, CWE-633                           */
/* JV-01 Justification : Depending on device status, there is case where the 'if' will return 'true'.                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message(6:2992)     : The value of this 'if' controlling expression is always 'false'.                             */
/* Rule                : No MISRA-C:2012 Rules applicable to message 2992                                             */
/* JV-01 Justification : This is to support different configuration, macro value can be generated so that such        */
/*                       conditional statement can beeither true or false.                                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2880)    : This code is unreachable.                                                                    */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Rule-2.1                                                         */
/* JV-01 Justification : Part of the code is manually check and confirmed to be executable depending on the           */
/*                       configuration                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:2004)    : No concluding 'else' exists in this 'if'-'else'-'if' statement.                              */
/* Rule                : CERTCCM EXP02, MISRA C:2012 Rule-15.7, CWE Rule CWE-398, CWE-569                             */
/* JV-01 Justification : The "else"statement with empty content is removed to improve readability.                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions.                                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : MISRA C:2012 Rule-11.5                                                                       */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/

#if (CAN_RAMTEST_API == STD_ON)
/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#if (CAN_RSCANFD_CONFIGURED == STD_ON)
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"

static FUNC(void, CAN_PRIVATE_CODE) Can_RamSetData(uint8 LucUnit,
                                          Can_RamTestFillType LenRAMFillType);

static FUNC(Std_ReturnType, CAN_PRIVATE_CODE) Can_RamWalkPathAlgorithm (
                                          uint8 LucUnit,
                                          Can_RamTestWalkType LenWalkPathType);

static FUNC(Std_ReturnType, CAN_PRIVATE_CODE) Can_RamCheckAlgorithm (
                                          uint8 LucUnit);

#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
** Function Name         : Can_RAMTest
**
** Service ID            : 0x22
**
** Description           : This API used for testing one RAM page in
**                         the foreground.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucUnit: Index of Hardware unit
**                         LusPageID: Page Index of RAM
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType(E_OK/E_NOT_OK)
**
** Preconditions         : The CAN Driver must be in Global stop state.
**
** Global Variables Used : Can_GblInitialized, Can_GpGlobalConfig.
**
** Function(s) invoked   : Can_GlobalModeChange, Det_ReportError,
**                         Can_RamSetData, Can_RamCheckAlgorithm,
**                         Can_RamWalkPathAlgorithm, Can_WaitRegisterChange,
**                         Dem_SetEventStatus.
**
** Registers Used        : RSCFDnCFDGCTR, RSCFDnCFDGSTS, RSCFDnCFDRPGACCr,
**                         RSCFDnCFDGTSTCTR, RSCFDnCFDGTSTCFG, RSCFDnCFDGLOCKK,
**                         RSCFDnCFDGSTS.
**
** Reference ID          : CAN_DUD_ACT_113
** Reference ID          : CAN_DUD_ACT_113_ERR001, CAN_DUD_ACT_113_ERR002
** Reference ID          : CAN_DUD_ACT_113_ERR003, CAN_DUD_ACT_113_ERR004
** Reference ID          : CAN_DUD_ACT_113_ERR005, CAN_DUD_ACT_113_ERR015
** Reference ID          : CAN_DUD_ACT_113_ERR016, CAN_DUD_ACT_113_REG001
** Reference ID          : CAN_DUD_ACT_113_REG002, CAN_DUD_ACT_113_REG003
** Reference ID          : CAN_DUD_ACT_113_REG004
***********************************************************************************************************************/

#define CAN_START_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(Std_ReturnType, CAN_PUBLIC_CODE) Can_RAMTest(uint8 LucUnit, uint16 LusPageID)                                      /* PRQA S 1503 # JV-01 */
{
  /* Number of tested RAM cells */
  VAR(uint8, AUTOMATIC) LucUnitIndex;
  VAR(uint32, AUTOMATIC) LulTimeoutDuration;
  VAR(Std_ReturnType, AUTOMATIC) LenResult;
  /* Variable to store the Result of RAM Test in each cycle */
  VAR(Std_ReturnType, AUTOMATIC) LenRamTestResult;
  #if (CAN_DEV_ERROR_DETECT == STD_ON)
  VAR(uint16, AUTOMATIC) LusMaxPageID;
  LusMaxPageID = 0U;                                                                                                    /* PRQA S 2982 # JV-01 */
  LenResult = E_OK;
  #endif
  /* initial local unit */
  LucUnitIndex = CAN_INVALID_VALUE;                                                                                     /* PRQA S 2982 # JV-01 */
  
  if (0U == LucUnit)
  {
    /* Covert from unit physical to index */
    #ifdef CAN_PHYIDX_UNIT0
    LucUnitIndex = CAN_PHYIDX_UNIT0;
    #endif
    /* Get Rampage for unit */
    #if (CAN_DEV_ERROR_DETECT == STD_ON)
    #if (CAN_DEVICE_NAME == CAN_X5X)
    LusMaxPageID = CAN_MAX_RAMPAGES_HARDWARE;
    #else 
    LusMaxPageID = CAN_MAX_RAMPAGES_HARDWARE_UNIT0;
    #endif
    #endif
  }
  else if (1U == LucUnit)                                                                                               /* PRQA S 2004 # JV-01 */
  {
    /* Covert from unit physical to index */
    #ifdef CAN_PHYIDX_UNIT1
    LucUnitIndex = CAN_PHYIDX_UNIT1;
    #endif
    /* Get Rampage for unit */
    #if (CAN_DEV_ERROR_DETECT == STD_ON)
    #if (CAN_DEVICE_NAME == CAN_X5X)
    LusMaxPageID = CAN_MAX_RAMPAGES_HARDWARE;
    #else 
    LusMaxPageID = CAN_MAX_RAMPAGES_HARDWARE_UNIT1;
    #endif
    #endif
  } /* else do not thing */

#if (CAN_DEV_ERROR_DETECT == STD_ON)
  if (CAN_TRUE == Can_GblInitialized)                                                                                   /* PRQA S 3416 # JV-01 */
  {
    /* Report to DET, if module is already initialized */
    (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_RAMTEST_SID, CAN_RAMTEST_E_INITIALIZED);
    LenResult = E_NOT_OK;
  }
  else
  {
    /* if Unit index is out of configured value */
    if (CAN_INVALID_VALUE == LucUnitIndex)                                                                              /* PRQA S 2992, 2996 # JV-01, JV-01 */
    {
      /* Report to DET */
      (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_RAMTEST_SID, CAN_RAMTEST_E_OUT_OF_RANGE);               /* PRQA S 2880 # JV-01 */
      LenResult = E_NOT_OK;
    }
    else
    {
      /* Check if the parameter "LusPageID" is out of range */
      if (LusMaxPageID < LusPageID)
      {
        /* Report to DET */
        (void)Det_ReportError(CAN_MODULE_ID, CAN_INSTANCE_ID, CAN_RAMTEST_SID, CAN_RAMTEST_E_OUT_OF_RANGE);
        LenResult = E_NOT_OK;
      } /* else No action required */
    }
  }
  if (E_NOT_OK != LenResult)
#endif /* End of if (CAN_DEV_ERROR_DETECT == STD_ON) */
  {
    /***********************************************************************
    *                  Checking if RAM Is INITIALIZED                      *
    ***********************************************************************/
    /* Wait until GRAMINIT flag is set */
    LulTimeoutDuration = CAN_TIMEOUT_COUNT;                                                                             /* PRQA S 2982 # JV-01 */
    LenResult = Can_WaitRegisterChange(&Can_GaaRegs[LucUnitIndex].pCmn->ulGSTS,
                            CAN_RSCAN_GRAMINIT, 0UL, &LulTimeoutDuration);
    /* If GRAMINIT flag was not set, report error */
    if (E_OK != LenResult)                                                                                              /* PRQA S 2992, 2996 # JV-01, JV-01 */
    {
      #if defined(CAN_E_TIMEOUT_FAILURE)
      CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);                                             /* PRQA S 2880 # JV-01 */
      #endif
    }
    else
    {
      /***********************************************************************
      *                  ENTER GLOBAL_RESET MODE                             *
      ***********************************************************************/
      /* Change to GLOBAL_RESET mode */
      LulTimeoutDuration = CAN_TIMEOUT_COUNT;
      LenResult = Can_GlobalModeChange(LucUnitIndex, CAN_RSCAN_GMDC_RESET, &LulTimeoutDuration);
      /* If mode changed was not finished, report error */
      if (E_OK != LenResult)
      {
         #if defined(CAN_E_TIMEOUT_FAILURE)
         CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);
         #endif
      }
      else
      {
        /***********************************************************************
        *                  ENTER GLOBAL_TEST MODE                              *
        ***********************************************************************/
        /* Change to GLOBAL_TEST mode */
        LulTimeoutDuration = CAN_TIMEOUT_COUNT;
        LenResult = Can_GlobalModeChange(LucUnitIndex, CAN_RSCAN_GMDC_TEST, &LulTimeoutDuration);
        /* If mode changed was not finished, report error */
        if (E_OK != LenResult)
        {
           #if defined(CAN_E_TIMEOUT_FAILURE)
           CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);
           #endif
        }
        else
        {
          /* Write protection data to LOCKK register (LpRSCFDnLOCKKReg) */
          Can_GaaRegs[LucUnitIndex].pCmn->ulGLOCKK = CAN_RSCAN_GLOCKK_UNLOCK_KEY1;
          Can_GaaRegs[LucUnitIndex].pCmn->ulGLOCKK = CAN_RSCAN_GLOCKK_UNLOCK_KEY2;
          /* Enable RAM Test mode in Global Test Status Control register */
          Can_GaaRegs[LucUnitIndex].pCmn->ulGTSTCTR = CAN_RSCAN_GTSTCTR_RTME_ENABLE;
          /* Select the page for Ram Test */
          /* Cast to uint32 for compatible in calculation and storage */
          Can_GaaRegs[LucUnitIndex].pCmn->ulGTSTCFG = ((uint32)LusPageID << (uint32)CAN_RSCAN_GTSTCFG_RTMPS_OFFSET);
          /* Fill all cells with zero */
          Can_RamSetData(LucUnitIndex, CAN_RAMTEST_FILL_0);
          /* RAM test using checker algorithm */
          LenRamTestResult = Can_RamCheckAlgorithm(LucUnitIndex);
          /* Check if RAM test using checker algorithm is success */
          if (E_OK == LenRamTestResult)
          {
            /* RAM test using walk path algorithm - 0 */
            LenRamTestResult = Can_RamWalkPathAlgorithm(LucUnitIndex, CAN_RAMTEST_WALK_0);
            /* Check if RAM test using walk path algorithm - 0 is success */
            if (E_OK == LenRamTestResult)
            {
              /* RAM test using walk path algorithm - 1 */
              LenRamTestResult = Can_RamWalkPathAlgorithm(LucUnitIndex, CAN_RAMTEST_WALK_1);                                        /* PRQA S 2982 # JV-01 */
            } /* else No action required */
          } /* else No action required */
          /* Fill all cells with zero */
          Can_RamSetData(LucUnitIndex, CAN_RAMTEST_FILL_0);
          /* Disable Ram Test */
          Can_GaaRegs[LucUnitIndex].pCmn->ulGTSTCTR = CAN_RSCAN_GTSTCTR_RTME_DISABLE;
          /***********************************************************************
          *                  ENTER GLOBAL_RESET MODE                             *
          ***********************************************************************/
          LulTimeoutDuration = CAN_TIMEOUT_COUNT;
          LenResult = Can_GlobalModeChange(LucUnitIndex, CAN_RSCAN_GMDC_RESET, &LulTimeoutDuration);
          /* If mode changed was not finished, report error */
          if (E_OK != LenResult)
          {
             #if defined(CAN_E_TIMEOUT_FAILURE)
             CAN_DEM_REPORT_ERROR(CAN_E_TIMEOUT_FAILURE, DEM_EVENT_STATUS_FAILED);
             #endif
          } /* else No action required */
          if (E_NOT_OK == LenRamTestResult)
          {
            LenResult = E_NOT_OK;
          }
        }
      }
    }
  }
  /* */
  return LenResult;
}
#define CAN_STOP_SEC_PUBLIC_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Can_RamCheckAlgorithm
**
** Service ID            : Not Applicable
**
** Description           : Function for RAM testing using the CheckerBoard
**                         Algorithm.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucUnit: Index of Hardware Unit
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**
** Preconditions         : The CAN Driver must be in Global stop state.
**
** Global Variables Used : None
**
** Function(s) invoked   : None
**
** Registers Used        : RSCFDnCFDRPGACCr
**
** Reference ID          : CAN_DUD_ACT_114
***********************************************************************************************************************/
#define CAN_START_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
static FUNC(Std_ReturnType, CAN_PRIVATE_CODE) Can_RamCheckAlgorithm (uint8 LucUnit)
{
  VAR(Std_ReturnType, AUTOMATIC) LucReturnVal;
  VAR(uint8, AUTOMATIC) LucTestRun;
  VAR(uint8, AUTOMATIC) LucIndex;
  P2VAR(volatile uint32, AUTOMATIC, REGSPACE)LpRSCFDnPGACC0Reg0;                                                        /* PRQA S 3432 # JV-01 */
  VAR(uint32, AUTOMATIC) LulValue;
  /* LulValue needed for the algorithm */
  LulValue = CAN_RSCAN_RAM_TEST_DATA;
  LucReturnVal = E_OK;
  LpRSCFDnPGACC0Reg0 = &(Can_GaaRegs[LucUnit].pCmn->aaRPGACC[0]);
  /* Write 0 and 1 in consecutive locations */
  for (LucTestRun = 0U; (LucTestRun < CAN_TWO) && (E_OK == LucReturnVal);
    LucTestRun++)
  {
    /* Write 0 and 1 in consecutive locations */
    for (LucIndex = 0U; LucIndex < CAN_RSCAN_RAM_PAGE_SIZE_ACCESS_REG; LucIndex++)
    {
      *(LpRSCFDnPGACC0Reg0 + LucIndex) =  LulValue;                                                                     /* PRQA S 0488 # JV-01 */
      /* Swaping the writen value */
      LulValue = ~LulValue;
    }
    /* Read 0 and 1 in consecutive locations */
    for (LucIndex = 0U; (LucIndex < CAN_RSCAN_RAM_PAGE_SIZE_ACCESS_REG) &&
      (E_OK == LucReturnVal); LucIndex++)
    {
      /* Check whether the data are correct */
      if (*(LpRSCFDnPGACC0Reg0 + LucIndex)  != LulValue)                                                                /* PRQA S 0488 # JV-01 */
      {
        LucReturnVal = E_NOT_OK;
      } /* else No action required */
      LulValue = ~LulValue;
    }
    LulValue = ~CAN_RSCAN_RAM_TEST_DATA;
  } /* End of for (LucTestRun = 0U; (LucTestRun < CAN_TWO)
                && (E_OK == LucReturnVal); LucTestRun++) */

  return LucReturnVal;
}

/***********************************************************************************************************************
** Function Name         : Can_RamWalkPathAlgorithm
**
** Service ID            : Not Applicable
**
** Description           : Function for RAM testing using the WalkPath
**                         Algorithm.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucUnit, LenWalkPathType.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**
** Preconditions         : The CAN Driver must be in Global stop state.
**
** Global Variables Used : None
**
** Function(s) invoked   : Can_RamSetData()
**
** Registers Used        : RSCFDnCFDRPGACCr
**
** Reference ID          : CAN_DUD_ACT_115
***********************************************************************************************************************/
static FUNC(Std_ReturnType,CAN_PRIVATE_CODE) Can_RamWalkPathAlgorithm(uint8 LucUnit,Can_RamTestWalkType LenWalkPathType)
{
  /* LulIndex of the cells */
  VAR(uint8, AUTOMATIC) LucCellnumber;
  /* Cell to be tested */
  VAR(uint8, AUTOMATIC) LucBaseCell;
  /* Bit to be tested in the cell */
  VAR(uint8, AUTOMATIC) LucBaseBit;
  /* Total number of bits */
  VAR(uint32, AUTOMATIC) LulTotalbits;
  /* Bit numbering */
  VAR(uint32, AUTOMATIC) LulIndex;
  /* RAM test fill type */
  VAR(Can_RamTestFillType, AUTOMATIC) LenRamFillType;                                                                   /* PRQA S 1710 # JV-01 */
  /* Pointers for RAM Test registers */
  P2VAR(volatile uint32, AUTOMATIC, REGSPACE) LulCellAddress;                                                           /* PRQA S 3432 # JV-01 */
  VAR(uint32, AUTOMATIC) LulBackGroundVariable;
  VAR(Std_ReturnType, AUTOMATIC) LucReturnVal;

  LucReturnVal = E_OK;

  /* Determine the RAM test type */
  if (CAN_RAMTEST_WALK_0 == LenWalkPathType)
  {
    LulBackGroundVariable = CAN_RSCAN_RAM_TEST_SET_DATA;
    LenRamFillType = CAN_RAMTEST_FILL_1;
  }
  else
  {
    LulBackGroundVariable = CAN_RSCAN_RAM_TEST_CLEAR_DATA;
    LenRamFillType = CAN_RAMTEST_FILL_0;
  }
  /* Fill all cells with either zero or one */
  Can_RamSetData(LucUnit, LenRamFillType);
  /* Cast to uint32 to compatible with size of storage variable */
  LulTotalbits = ((uint32)CAN_RSCAN_RAM_PAGE_SIZE_ACCESS_REG << (uint32)CAN_RSCAN_RAMTST_CELL_DIVIDER);
   /* Select the base bit to be tested in the ascending order. (LSB to MSB) */
  for (LulIndex = 0U; (LulIndex < LulTotalbits) &&
    (E_OK == LucReturnVal); LulIndex++)
  {
    /* Cast from uint32 to uint8 type to match with size of storage variable
    This cast doesn't cause losing data due to LucTestedCellNumber is uint8 type */
    LucBaseCell = (uint8)(LulIndex >> (uint32)CAN_RSCAN_RAMTST_CELL_DIVIDER);
    /* Cast from uint32 to uint8 type to match with size of storage variable
    This cast doesn't cause losing data because store value already & with
    mask value 0x1F */
    LucBaseBit = (uint8)(LulIndex & (CAN_RSCAN_RAM_TEST_DATA_TYPE - CAN_ONE));
    LulCellAddress = &(Can_GaaRegs[LucUnit].pCmn->aaRPGACC[0]);
    /* Invert the base bit */
    CAN_RSCAN_RAMTST_INVERT_BITX (*(LulCellAddress + LucBaseCell), LucBaseBit, uint32);                                 /* PRQA S 0488 # JV-01 */
    /* Read and check all other bits in the tested cells (LSB to MSB) */
    for (LucCellnumber = 0U; (LucCellnumber < CAN_RSCAN_RAM_PAGE_SIZE_ACCESS_REG) &&
      (E_OK == LucReturnVal); LucCellnumber++)
    {
      /* Check for the base cell */
      if (LucCellnumber == LucBaseCell)
      {
        /* Cast from type uint8 to uint32 for compatible in calculation */
        if (*(LulCellAddress + LucBaseCell) != (LulBackGroundVariable ^ ((uint32)CAN_ONE << LucBaseBit)))               /* PRQA S 0488 # JV-01 */
        {
          LucReturnVal = E_NOT_OK;
        } /* else No action required */
      }
      /* Check the content of all other cells excluding the base cell */
      else if (*(LulCellAddress + LucCellnumber) != LulBackGroundVariable)                                              /* PRQA S 0488, 2004 # JV-01, JV-01 */
      {
        LucReturnVal = E_NOT_OK;
      } /* else No action required */
    }
    /* Re-invert the base cell */
    CAN_RSCAN_RAMTST_INVERT_BITX(*(LulCellAddress + LucBaseCell), LucBaseBit, uint32);                                  /* PRQA S 0488 # JV-01 */
  } /* End of for (LulIndex = CAN_DEFAULT_ZERO; (LulIndex < LulTotalbits) && */
    /* (E_OK == LucReturnVal); LulIndex++) */
  return LucReturnVal;
}

/***********************************************************************************************************************
** Function Name         : Can_RamSetData
**
** Service ID            : Not Applicable
**
** Description           : Function for setting all cells of RAM to zero or one
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucUnit, LenRAMFillType.
**
** InOut Parameters      : None
**
** Global Variables Used : None
**
** Function(s) invoked   : None
**
** Registers Used        : RSCFDnCFDRPGACCr
**
** Reference ID          : CAN_DUD_ACT_116
***********************************************************************************************************************/
static FUNC(void, CAN_PRIVATE_CODE) Can_RamSetData(uint8 LucUnit, Can_RamTestFillType LenRAMFillType)                   /* PRQA S 1710 # JV-01 */
{
  /* Pointers for RAM Test registers */
  P2VAR(volatile uint32, AUTOMATIC, CAN_APPL_DATA) LulCellAddress;                                                      /* PRQA S 3432 # JV-01 */
  VAR(uint32, AUTOMATIC) LulRamInitData;
  VAR(uint8, AUTOMATIC) LucCellnumber;

  /* Determine which data to be initialized in RAM */
  if (CAN_RAMTEST_FILL_1 == LenRAMFillType)
  {
    LulRamInitData = CAN_RSCAN_RAM_TEST_SET_DATA;
  }
  else
  {
    LulRamInitData = CAN_RSCAN_RAM_TEST_CLEAR_DATA;
  }
  LulCellAddress = &(Can_GaaRegs[LucUnit].pCmn->aaRPGACC[0]);
  /* Fill all bits with RAM init data */
  for (LucCellnumber = 0; LucCellnumber < CAN_RSCAN_RAM_PAGE_SIZE_ACCESS_REG; LucCellnumber++)
  {
    /* Cast to uint32 to match the size of register in compare operation */
    *(LulCellAddress + LucCellnumber) = LulRamInitData;                                                                 /* PRQA S 0488 # JV-01 */
  }
}

#define CAN_STOP_SEC_PRIVATE_CODE
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif
#endif /* #if (CAN_RAMTEST_API == STD_ON) */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
