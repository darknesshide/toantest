/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Can_Irq.c                                                                                           */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* (c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                                */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Interrupt Service Routines Functionality.                                                             */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:        U5x/X5H                                                                               */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                                  Revision History                                                  **
***********************************************************************************************************************/
/*
 * 1.3.1: 03/04/2026 : Add QAC message 2004, 2877, 2986
 *        27/03/2026 : Change ISR name for CANXL and update precompile. Add Can_ImfuCanXLFuncIsr, Can_ImfuCanXLErrIsr
          09/03/2026 : Support interrupt for transmit, receive for CANFD, wake up for CANXL and DMA
                     : Update CanXL_ErrIsr, Add macro transmit, receive and error interrupt
 * 1.1.3: 29/12/2025 : Update Can_ChannelIsr
 * 1.1.2: 28/11/2025 : Add dummy read in CanXL_FuncIsr, CanXL_ErrIsr for X5H
 * 1.1.1: 12/10/2025 : Update CanXL_FuncIsr, CanXL_ErrIsr, Can_RxGlobalIsr, Can_RxIsr, Can_ErrorIsr  
 *                     to fix warning of compiler
 *        25/09/2025 : Remove unuse code in Can_RxIsr
 * 1.1.0: 04/09/2025 : Update Can_DmaIsr.
 *        11/08/2025 : Update CanXL_FuncIsr, Can_VMIsr.
 * 1.0.6: 07/08/2025 : Support safety interrupt consistency.
 *        18/07/2025 : Improve Can_ImfuTxIsr.
 *        27/06/2025 : Update QAC message
 *        18/06/2025 : Add dummy read and synccp.
 * 1.0.5: 26/05/2025 : Update Can_VMIsr
 * 1.0.4: 04/06/2025 : Update CanXL_FuncIsr, CanXL_ErrIsr
 * 1.0.3: 07/05/2025 : Update Can_ImfuRxIsr, Can_ImfuTxIsr, Can_ImfuErrorIsr as safety requirement.
 *        24/04/2025 : Update Can_RxGlobalIsr to using common
 *                   : Change CAN_UNINTENDED_INTERRUPT_CHECK to CAN_INTERRUPT_CONSISTENCY_CHECK
 *                   : Change CAN_E_INTERRUPT_CONTROLLER_FAILURE to CAN_E_INT_INCONSISTENT
 *                   : Update CanXL_FuncIsr, CanXL_ErrIsr, Can_RxIsr, Can_ImfuTxIsr, Can_TxIsr, 
 *                   : Can_ImfuErrorIsr, Can_ErrorIsr, Can_DmaIsr, Can_WakeupIsr
 * 1.0.2: 28/03/2025 : Merge last code and support QAC version 11.6.0
 * 1.0.1: 19/02/2025 : Merge latest code
 * 1.0.0: 03/10/2024 : Initial Version
 */
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* CAN module header file */
#include "Can.h"
/* Included for RAM variable declarations */
#include "Can_Ram.h"
#if (CAN_CANXL_SUPPORTED == STD_ON)
#include "CanXLTrcv.h"
#endif
#include "CanIf_Can.h"
#include "Can_Irq.h"
#include "Dem.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/* AUTOSAR release version information */
#define CAN_IRQ_C_AR_RELEASE_MAJOR_VERSION    CAN_AR_RELEASE_MAJOR_VERSION_VALUE
#define CAN_IRQ_C_AR_RELEASE_MINOR_VERSION    CAN_AR_RELEASE_MINOR_VERSION_VALUE
#define CAN_IRQ_C_AR_RELEASE_REVISION_VERSION CAN_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define CAN_IRQ_C_SW_MAJOR_VERSION            CAN_SW_MAJOR_VERSION_VALUE
#define CAN_IRQ_C_SW_MINOR_VERSION            CAN_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (CAN_IRQ_C_AR_RELEASE_MAJOR_VERSION != CAN_IRQ_AR_RELEASE_MAJOR_VERSION)
  #error "Can_Irq.c : Mismatch in Release Major Version"
#endif
#if (CAN_IRQ_C_AR_RELEASE_MINOR_VERSION != CAN_IRQ_AR_RELEASE_MINOR_VERSION)
  #error "Can_Irq.c : Mismatch in Release Minor Version"
#endif
#if (CAN_IRQ_C_AR_RELEASE_REVISION_VERSION != CAN_IRQ_AR_RELEASE_REVISION_VERSION)
  #error "Can_Irq.c : Mismatch in Release Revision Version"
#endif
#if (CAN_IRQ_SW_MAJOR_VERSION != CAN_IRQ_C_SW_MAJOR_VERSION)
  #error "Can_Irq.c : Mismatch in Software Major Version"
#endif
#if (CAN_IRQ_SW_MINOR_VERSION != CAN_IRQ_C_SW_MINOR_VERSION)
  #error "Can_Irq.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (4:2986)    : This operation is redundant. The value of the result is always that of the right-hand        */
/*                       operand.                                                                                     */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : This operation is an important operation for calculating the decrement value as the          */
/*                       increment value, so it is necessary and not redundant.                                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2877)    : This loop will never be executed more than once.                                             */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Dir-4.1, CWE Rule CWE-670                                        */
/* JV-01 Justification : This loop will only be executed at least once, depends on user configuration.                */
/*       Verification  : This is Hardware Specification, X2x only provides 1 Unit. So it is not having any impact.    */
/**********************************************************************************************************************/
/* Message (2:0310)    : Casting to different object pointer type.                                                    */
/* Rule                : CERTCCM EXP11, EXP39, MISRA C:2012 Rule-11.3                                                 */
/* JV-01 Justification : For accessing 8-bit and 16-bit PNOT and JPNOT register respectively, the 32-bit pointer is   */
/*                       typecasted.                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : MISRA C:2012 Rule-11.5                                                                       */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0751)    : Casting to char pointer type.                                                                */
/* Rule                : CERTCCM EXP11, EXP39                                                                         */
/* JV-01 Justification : Using void due to specific requirement of input parameter. So, this can be skipped           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0857)    : Number of macro definitions exceeds 1024 - program does not conform strictly to ISO:C90.     */
/* Rule                : MISRA C:2012 Dir-1.1                                                                         */
/* JV-01 Justification : The number of macro depend on module code size. There is no issue when number of macro is    */
/*                       over 1024                                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1006)    : This in-line assembler construct is a language extension. The code has been ignored.         */
/* Rule                : CERTCCM MSC14, MISRA C:2012 Dir-1.1, Rule-1.2, Dir-4.2                                       */
/* JV-01 Justification : This is accepted, due to the Synchronization Processing Instruction is following hardware    */
/*                       specification.                                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC07, MISRA C:2012 Rule-2.1                                                         */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2814)    : Possible: Dereference of NULL pointer.                                                       */
/* Rule                : CERTCCM EXP34                                                                                */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification or it was    */
/*                       checked or do not dereference to NULL pointer.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2824)    : Possible: Arithmetic operation on NULL pointer.                                              */
/* Rule                : CERTCCM EXP34                                                                                */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2844)    : Possible: Dereference of an invalid pointer value.                                           */
/* Rule                : CERTCCM ARR30                                                                                */
/* JV-01 Justification : It is specific for device register accessing and confirmed has no issue in software behavior.*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2983)    : This assignment is redundant. The value of this object is never subsequently used.           */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : The value is to increment the pointer to the next item.                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:3305)    : Pointer cast to stricter alignment.                                                          */
/* Rule                : CERTCCM EXP36, EXP39, MISRA C:2012 Rule-11.3                                                 */
/* JV-01 Justification : Pointer alignment is changed by casting, but it's necessary for embedded programming         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30                                                                                */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3408)    : %s' has external linkage and is being defined without any previous declaration.              */
/* Rule                : CERTCCM DCL07, MISRA C:2012 Rule-8.4                                                         */
/* JV-01 Justification : It is accepted, due to the declaration will be taken care by Os                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45                                                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : MISRA C:2012 Rule-20.7                                                                       */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3464)    : Argument to macro '%s' contains a side effect that will be evaluated more than once.         */
/* Rule                : CERTCCM PRE31                                                                                */
/* JV-01 Justification : This message is only emitted for expressions expanded from argument tokens written out at    */
/*                       the top level, that did not themselves originate from a macro expansion.                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                : MISRA C:2012 Dir-4.9                                                                         */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4461)    : A non-constant expression of 'essentially unsigned' type (%1s) is being converted to         */
/*                       narrower unsigned type, '%2s' on assignment.                                                 */
/* Rule                : CERTCCM INT02, MISRA C:2012 Rule-10.3                                                        */
/* JV-01 Justification : This operation is necessary to offset a 32-bit address on RAM to a 16-bit buffer address.    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                : MISRA C:2012 Rule-20.1                                                                       */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0404)    : More than one read access to volatile objects between sequence points.                       */
/* Rule                : MISRA C:2012 Rule-1.3, Rule-13.2, CERTCCM EXP30, EXP10, CWE Rule CWE-682, CWE-758, CWE-737   */
/* JV-01 Justification : This is to get an element in the array of struct, volatile of the counter variable of 'for'  */
/*                       loop is used to ensure no optimization. It is accepted                                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3415)    : Right hand operand of '&&' or '||' is an expression with persistent side effects.            */
/* Rule                : MISRA C:2012 Rule-13.5, CERTCCM EXP02, CWE Rule CWE-398, CWE-768, CWE-569                    */
/* JV-01 Justification : Although it is a volatile object, it does not have direct access to the HW register, and     */
/*                       there is no side effect.                                                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30                                                                                */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:0311)    : Dangerous pointer cast results in loss of const qualification.                               */
/* Rule                : MISRA C:2012 Rule-11.8, CERTCCM EXP05                                                        */
/* JV-01 Justification : This is to achieve throughput in the code.                                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3006)    : This function contains a mixture of in-line assembler statements and C statements.           */
/* Rule                : MISRA C:2012 Dir-4.3                                                                         */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:2004)    : No concluding 'else' exists in this 'if'-'else'-'if' statement.                              */
/* Rule                : CERTCCM EXP02, MISRA C:2012 Rule-15.7, CWE Rule CWE-398, CWE-569                             */
/* JV-01 Justification : The "else"statement with empty content is removed to improve readability.                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (5:2976)    : Definite: Passing address of partially initialized object '%s' to a function parameter       */
/*                       declared as a pointer to const.                                                              */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-456, CWE-908, CWE-452, CWE-737                                   */
/* JV-01 Justification : The message propose that address should be initialized before passed to function             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/

#define CAN_START_SEC_CODE_FAST
#include "Can_MemMap.h"

#if ((CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) || (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON))
STATIC FUNC(void, CAN_CODE_FAST) Can_RxGlobalIsr(CONST(uint8, AUTOMATIC) LucUnit);
#endif

#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)

#if ((CAN_CONTROLLER0_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER2_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER4_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER6_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER8_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER10_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER12_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_RX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER14_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_RX_INTERRUPT == STD_ON))
#define CAN_CONTROLLER_RX_INTERRUPT_ON
#endif

#if ((CAN_CONTROLLER0_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER2_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER4_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER6_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER8_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER10_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER12_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_TX_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER14_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_TX_INTERRUPT == STD_ON))
#define CAN_CONTROLLER_TX_INTERRUPT_ON
#endif

#if ((CAN_CONTROLLER0_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER2_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER4_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER6_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER8_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER10_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER12_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_ERROR_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER14_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_ERROR_INTERRUPT == STD_ON))
#define CAN_CONTROLLER_ERROR_INTERRUPT_ON
#endif

#if ((defined CAN_CONTROLLER_TX_INTERRUPT_ON) || (defined CAN_CONTROLLER_RX_INTERRUPT_ON) || \
 (defined CAN_CONTROLLER_ERROR_INTERRUPT_ON))
STATIC FUNC(void, CAN_CODE_FAST) Can_ChannelIsr(CONST(uint8, AUTOMATIC) LucController);
#endif

#if ((defined CAN_VM_RX_INTERRUPT_ON) || (defined CAN_VM_TX_INTERRUPT_ON))
STATIC FUNC(void, CAN_CODE_FAST) Can_VMIsr(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucVMChannel);
#endif

#if ((CAN_WAKEUP_SUPPORT == STD_ON) && \
    ((CAN_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER4_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER6_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER8_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER10_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER12_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_WAKEUP_INTERRUPT == STD_ON) || \
    (CAN_CONTROLLER14_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_WAKEUP_INTERRUPT == STD_ON)||  \
    (CANXL_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON) || (CANXL_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON)||  \
    (CANXL_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON) || (CANXL_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON)))
#define CAN_CONTROLLER_WAKEUP_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_WakeupIsr(CONST(uint8, AUTOMATIC) LucController,
                                                                      Can_ControllerType LenControllerType);
#endif

#else

#if ((CAN_CONTROLLER0_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER8_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_RX_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_RX_INTERRUPT == STD_ON))
#define CAN_CONTROLLER_RX_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_RxIsr(CONST(uint8, AUTOMATIC) LucCtrlIndex);
#endif

#if (CAN_CONTROLLER0_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER8_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_TX_INTERRUPT == STD_ON)
#define CAN_CONTROLLER_TX_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_TxIsr(CONST(uint8, AUTOMATIC) LucCtrlIndex);
#endif

#if (CAN_CONTROLLER0_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER8_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_ERROR_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_ERROR_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_ERROR_INTERRUPT == STD_ON)
#define CAN_CONTROLLER_ERROR_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_ErrorIsr(CONST(uint8, AUTOMATIC) LucCtrlIndex);
#endif

#if ((CAN_WAKEUP_SUPPORT == STD_ON) &&                                                                  \
     ((CAN_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER4_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER6_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER8_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER10_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER12_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CAN_CONTROLLER14_WAKEUP_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_WAKEUP_INTERRUPT == STD_ON) ||   \
      (CANXL_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON) || (CANXL_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON)||   \
      (CANXL_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON) || (CANXL_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON)))   
#define CAN_CONTROLLER_WAKEUP_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_WakeupIsr(CONST(uint8, AUTOMATIC) LucController, 
                                                                   Can_ControllerType LenControllerType);
#endif


#endif

#if defined (CAN_CONTROLLER_ERROR_INTERRUPT_ON) && (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
STATIC FUNC(uint32, CAN_CODE_FAST) Can_SubErrorIsr(VAR(uint8, AUTOMATIC) LucCtrlIndex, VAR(uint8, AUTOMATIC) LucUnit, 
                                                   VAR(uint8, AUTOMATIC) LucCh, VAR(uint32, AUTOMATIC) LulRegERFLMask);
#endif
/* Prototypes for internal functions */
#if (CAN_ENABLE_DMA_MODE == STD_ON)
#if ((CAN_DMA0_0246_FUNC_ISR == STD_ON) || (CAN_DMA0_1357_FUNC_ISR == STD_ON) || \
     (CAN_DMA1_0246_FUNC_ISR == STD_ON) || (CAN_DMA1_1357_FUNC_ISR == STD_ON) || \
     (CAN_DMA2_0246_FUNC_ISR == STD_ON) || (CAN_DMA2_1357_FUNC_ISR == STD_ON) || \
     (CAN_DMA3_0246_FUNC_ISR == STD_ON) || (CAN_DMA3_1357_FUNC_ISR == STD_ON))
#define CAN_DMA_FUNC_INTERRUPT_ON     
STATIC FUNC(void, CAN_CODE_FAST) Can_DmaIsr(CONST(uint8, AUTOMATIC) LucDmaUnit, CONST(uint8, AUTOMATIC) LucGroupChannel);
#endif
#endif

#if ((defined CAN_VM_RX_INTERRUPT_ON) || (defined CAN_VM_TX_INTERRUPT_ON))
STATIC FUNC(void, CAN_CODE_FAST) Can_VMIsr(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucVMChannel);
#endif

#if (CAN_CANXL_SUPPORTED == STD_ON)
#if ((CAN_CANXL_CONTROLLER0_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER1_FUNC_ISR == STD_ON) || \
      (CAN_CANXL_CONTROLLER2_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_FUNC_ISR == STD_ON))
STATIC FUNC(void, CAN_CODE_FAST) CanXL_FuncIsr(CONST(uint8, AUTOMATIC) LucPhysController);
#endif

#if ((CAN_CANXL_CONTROLLER0_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER1_ERROR_ISR == STD_ON) || \
      (CAN_CANXL_CONTROLLER2_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_ERROR_ISR == STD_ON) )
STATIC FUNC(void, CAN_CODE_FAST) CanXL_ErrIsr(CONST(uint8, AUTOMATIC) LucPhysController);
#endif

/***********************************************************************************************************************
** Function Name         : CanXL_FuncIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each RX_ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucController : Physical number of Controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController,
**                         Can_GaaRegs
**
** Functions Invoked     : Can_RxProcessing
**
** Registers Used        : (CFD)CFSTSk, (CFD)CFCCk, EICn
**                         (CFD)GSTS (for dummy read only)
**
** Reference ID          : CAN_DUD_ACT_182
** Reference ID          : CAN_DUD_ACT_182_ERR001, CAN_DUD_ACT_182_REG001
** Reference ID          : CAN_DUD_ACT_182_REG002, CAN_DUD_ACT_182_REG003
** Reference ID          : CAN_DUD_ACT_182_REG004, CAN_DUD_ACT_182_REG005
***********************************************************************************************************************/
#if ((CAN_CANXL_CONTROLLER0_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER1_FUNC_ISR == STD_ON) || \
    (CAN_CANXL_CONTROLLER2_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_FUNC_ISR == STD_ON))
STATIC FUNC(void, CAN_CODE_FAST) CanXL_FuncIsr(CONST(uint8, AUTOMATIC) LucPhysController)                               /* PRQA S 3006 # JV-01 */
{
  VAR(uint8, AUTOMATIC) LucCtrlInfoIndex;
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  #if (defined CANXL_CONTROLLER_RX_INTERRUPT_ON) || (defined CANXL_CONTROLLER_TX_INTERRUPT_ON)
  #ifdef CANXL_CONTROLLER_TX_INTERRUPT_ON
  VAR(uint32, AUTOMATIC) LulTxFFIRQ;
  VAR(uint32, AUTOMATIC) LulTxPQIRQ;
  #endif

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(uint32, AUTOMATIC) LulFUNCENA;
  #endif

  #ifdef CANXL_CONTROLLER_RX_INTERRUPT_ON
  CanXL_ExtRxStatusType LenRetValue;
  VAR(uint32, AUTOMATIC) LulRxFFIRQ;
  VAR(uint8, AUTOMATIC) LucQueueId;
  volatile VAR(uint32, AUTOMATIC) LulFuncRaw;
  LenRetValue = CANXL_EXT_NOT_RECEIVED;
  #endif
  #endif /* CANXL_CONTROLLER_RX_INTERRUPT_ON || CANXL_CONTROLLER_TX_INTERRUPT_ON */
  #if ((CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF) && (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  P2CONST(Can_CanXLHWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA) LpCanXLHWInfo;                                           /* PRQA S 3432 # JV-01 */
  LpCanXLHWInfo = (P2CONST(Can_CanXLHWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA))Can_GpConfig->pCanXLHWUnitInfo;         /* PRQA S 0316, 3432 # JV-01, JV-01 */
  #endif

  /* Convert the physical Controller index to the config index */
  LucCtrlIndex = Can_GpConfig->pCanXLPhysicalControllerToIndex[LucPhysController];
  LpPCController = &Can_GpPCController[LucCtrlIndex];                                                                   /* PRQA S 2983 # JV-01 */
  LucCtrlInfoIndex = Can_GpConfig->pCanXLSecondPhysicalControllerToIndex[LucPhysController];
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* If no irq exists, this interrupt is wrong */
  LulFUNCENA = CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulFUNCENA;
  if ((0UL == ( LulFUNCENA &                                                                                            /* PRQA S 0404 # JV-01 */
                (CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulFUNCRAW))) ||
                #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON) 
                (0U == NVIC_GetActive(LpPCController->pICRec->enInterruptID))                                           /* PRQA S 3415, 3416 # JV-01, JV-01 */
                #else
                (0U == GIC_GetEnableIRQ(LpCanXLHWInfo[LucCtrlInfoIndex].ulFuncEicID))                                   /* PRQA S 3415, 3416 # JV-01, JV-01 */
                #endif 
              )
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED); 
  }
  else
  #endif
  {
  #if (defined CANXL_CONTROLLER_RX_INTERRUPT_ON) || (defined CANXL_CONTROLLER_TX_INTERRUPT_ON)
    #ifdef CANXL_CONTROLLER_RX_INTERRUPT_ON
    LulFuncRaw = CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulFUNCRAW;
    LulRxFFIRQ = CanXL_GaaRegs[LucCtrlInfoIndex].pMH->ulRXFQINSTS;
    #endif
    #ifdef CANXL_CONTROLLER_TX_INTERRUPT_ON
    LulTxFFIRQ =  CanXL_GaaRegs[LucCtrlInfoIndex].pMH->ulTXFQINSTS;
    LulTxPQIRQ =  CanXL_GaaRegs[LucCtrlInfoIndex].pMH->ulTXPQINSTS0;
    #endif
    #if defined CANXL_CONTROLLER_RX_INTERRUPT_ON
    if((0UL != ((uint32)LpPCController->ucIntEnable & (uint32)CAN_CHECK_INT_RX)) && (     
      #if (STD_ON == CAN_SELFTEST_API)
        ( 0UL !=(CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulTEST & CANXL_ENABLE_LBCK_TXRXNOMAL)) || 
      #endif
                           (0UL != (LulFuncRaw & CANXL_PRT_RXEVT_BIT))))                                                /* PRQA S 3415, 3416 # JV-01, JV-01 */
    {
      /* Get Queue index */
      for(LucQueueId = 0U; LucQueueId < CANXL_MAX_RXFIFOQUEUE; LucQueueId++)
      {
        if (0UL != (LulRxFFIRQ & (uint32)(1UL << (LucQueueId))))
        {
          /* Receive the specified queue */
          do
          {
            /* process receiption for CANXL Frame with SDT = 05 */
            LenRetValue = CanXL_RxQueueProcess(LucCtrlIndex, LucQueueId);
          } while ((CANXL_EXT_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue) || \
                   (CANXL_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue));
        } /* else no action required*/
      }
      /* Check if that Queue is not ETH Frame, then process CANXL Frame 01,03 */
      if (CANXL_EXT_NOT_RECEIVED == LenRetValue)
      {
        /* process receiption for CANXL Frame with SDT ={ 01, 03 } */
        CanXL_RxProcessing(LucCtrlIndex, CAN_CHECK_INT_RX, CAN_MAINFUNCTION_INSTANCE_0);
      } /* else no action required*/
    } /* else no action required*/
    #endif
    #if defined CANXL_CONTROLLER_TX_INTERRUPT_ON
    if((0UL != ((uint32)LpPCController->ucIntEnable & (uint32)CAN_CHECK_INT_TX)) && \
                    ((0UL != (LulTxFFIRQ & CANXL_FQ_ISR_BIT)) || (0UL != LulTxPQIRQ )))
    {
      /* Tx Confirmation Eth STD 05
       * Get Tx FIFO Queue index */
      CanXL_HwTxConfirmation(LucCtrlInfoIndex);
      /* Tx Confirmation Can STD 01,03 */
      Can_CanXLTxConfirmation(LucCtrlIndex);
    } /* else no action required*/
    #endif /* CANXL_CONTROLLER_TX_INTERRUPT_ON */
    #endif /* CANXL_CONTROLLER_RX_INTERRUPT_ON || CANXL_CONTROLLER_TX_INTERRUPT_ON */
    CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulFUNCCLR = 0xFFFFFFFFUL;
    /* Dummy read */
    (void)(CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulFUNCRAW);
    #if (CAN_DEVICE_NAME == CAN_U5X)
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
    #endif
  }

}

/***********************************************************************************************************************
** Function Name         : Can_ImfuCanXLFuncIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each FuncIsr IMFU Level
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucGroupChannel : IMFUL  channel Group Number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController
**
** Functions Invoked     : Can_RxIsr, CAN_DEM_REPORT_ERROR
**
** Registers Used        : IMFULFi
**
** Reference ID          : CAN_DUD_ACT_079
** Reference ID          : CAN_DUD_ACT_079_ERR001, CAN_DUD_ACT_079_REG001
** Reference ID          : CAN_DUD_ACT_079_GBL001
***********************************************************************************************************************/
#if (CAN_DEVICE_NAME == CAN_U5X)
STATIC FUNC(void, CAN_CODE_FAST) Can_ImfuCanXLFuncIsr(CONST(uint8, AUTOMATIC) LucGroupChannel)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  VAR(uint8, AUTOMATIC) LucPhyController;
  VAR(uint8, AUTOMATIC) LucIntMergeIndex;
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  VAR(boolean, AUTOMATIC) LucIsrhandler;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIsConsistency;

  /* Interrupt is not consistency */
  LblIsConsistency = CAN_FALSE;
  #endif

  /* 
    49 - IMFUL Group No 2 - CAN0/2/4/6 transmit/receive FIFO receive completion interrupt
    50 - IMFUL Group No 3 - CAN1/3/5/7 transmit/receive FIFO receive completion interrupt
  */
  /* Get started ctrl base index 0 or 1 */
  /* Loop for call controllers */
  for (LucIntMergeIndex = 0U; LucIntMergeIndex < (CANXL_MAX_CONTROLLER/2U); LucIntMergeIndex++)                         /* PRQA S 2877 # JV-01 */
  {
    /* init LucIsrhandler for each controller */
    LucIsrhandler = CAN_FALSE;
    /* if IMFU is 0/2/4/6 or 1/3/5/7 */
    LucPhyController = (uint8)((uint8)(LucIntMergeIndex * 2U) + (uint8)(LucGroupChannel % 2U));                         /* PRQA S 3383, 2986 # JV-01, JV-01 */
    /* Convert the physical Controller index to the config index */
    /* Queery: Can_GaaPhysicalControllerToIndex0 shoul be generated with default value is 0xFF */
    LucCtrlIndex = Can_GpConfig->pCanXLPhysicalControllerToIndex[LucPhyController];
    /* Get controller PC configuration value */
    /* if each LIFF bit (0->2) of IMFULFi (IMFU Level Status Register) is set */
    if (LucCtrlIndex != (uint8)0xFFU)
    {
      LpPCController = &Can_GpPCController[LucCtrlIndex];
       
      /* Check interrupt no mege group U5Lx */
      if (NULL_PTR == LpPCController->pICRec->pIMFU)
      {
        LucIsrhandler = CAN_TRUE;
      } 
      /* Check interrupt mege group U5Mx */
      else if ((*(LpPCController->pICRec->pIMFU) & (uint32)((uint32)1U << LucIntMergeIndex)) != (uint32)0U)             /* PRQA S 2004 # JV-01 */
      {
        LucIsrhandler = CAN_TRUE;
      } /* else do not thing */

      if (CAN_TRUE == LucIsrhandler)
      {
        /* Intput to Isr handler */
        CanXL_FuncIsr(LucPhyController);
        #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
        /* ISR is consistency */
        LblIsConsistency = CAN_TRUE;
        #endif
      } /* else do not thing */
    }
  }
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* Check consistency */
  if (CAN_FALSE == LblIsConsistency)
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  #endif
}
#endif /* #if (CAN_DEVICE_NAME == CAN_U5X) */
#endif /* End of #if ((CAN_CANXL_CONTROLLER0_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER1_FUNC_ISR == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : CANXL_CONTROLLER<02/13>_FUNC_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is Functional Interrupt Service routines for the CanXL
**                         controller n.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : CanXL_FuncIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_077
** Reference ID          : CAN_DUD_ACT_078
***********************************************************************************************************************/
#if (CAN_CANXL_CONTROLLER0_FUNC_ISR == STD_ON) ||  (CAN_CANXL_CONTROLLER2_FUNC_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER02_FUNC_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)

ISR(CANXL_CONTROLLER02_FUNC_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER02_FUNC_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  #if (CAN_DEVICE_NAME == CAN_U5X)
  Can_ImfuCanXLFuncIsr(0x00U);
  #else
  CanXL_FuncIsr(CANXL_PHYIDX_CONTROLLER0);
  #endif
}
#endif

#if (CAN_CANXL_CONTROLLER1_FUNC_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_FUNC_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER13_FUNC_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)

ISR(CANXL_CONTROLLER13_FUNC_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER13_FUNC_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  #if (CAN_DEVICE_NAME == CAN_U5X)
  Can_ImfuCanXLFuncIsr(0x01U);
  #else
  CanXL_FuncIsr(CANXL_PHYIDX_CONTROLLER1);
  #endif
}
#endif

/***********************************************************************************************************************
** Function Name         : CanXL_ErrIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each ERR_ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucPhysController : Physical number of Controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController,
**                         Can_GaaRegs
**
** Functions Invoked     : Can_RxProcessing
**
** Registers Used        : (CFD)CFSTSk, (CFD)CFCCk, EICn
**                         (CFD)GSTS (for dummy read only)
**
** Reference ID          : CAN_DUD_ACT_192, CAN_DUD_ACT_192_REG004
** Reference ID          : CAN_DUD_ACT_192_ERR001, CAN_DUD_ACT_192_REG003
** Reference ID          : CAN_DUD_ACT_192_REG002, CAN_DUD_ACT_192_REG001
** Reference ID          : CAN_DUD_ACT_192_REG005, CAN_DUD_ACT_192_GBL001
** Reference ID          : CAN_DUD_ACT_192_GBL002, CAN_DUD_ACT_192_GBL003
** Reference ID          : CAN_DUD_ACT_192_GBL004, CAN_DUD_ACT_192_GBL005
** Reference ID          : CAN_DUD_ACT_192_GBL006, CAN_DUD_ACT_192_GBL007
***********************************************************************************************************************/
#if ((CAN_CANXL_CONTROLLER0_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER1_ERROR_ISR == STD_ON) || \
     (CAN_CANXL_CONTROLLER2_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER3_ERROR_ISR == STD_ON))
STATIC FUNC(void, CAN_CODE_FAST) CanXL_ErrIsr(CONST(uint8, AUTOMATIC) LucPhysController)                                /* PRQA S 3006 # JV-01 */
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  VAR(uint8, AUTOMATIC) LucCtrlInfoIndex;
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  VAR(uint8, AUTOMATIC) LucCh;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(uint32, AUTOMATIC) LulERRENA;
  #endif
  #if (CAN_BUSOFF_INTERRUPT == STD_ON) || (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  VAR(uint8, AUTOMATIC) LucSubCtrlIndex;
  VAR(uint8, AUTOMATIC) LucTransceiverID;
  #endif
  #if (CAN_BUSOFF_INTERRUPT == STD_ON)
  VAR(uint32, AUTOMATIC) LulCounter;
  P2CONST(CanXL_BufHandlerType, AUTOMATIC, CAN_APPL_DATA) LpBufHandlerPtr;                                              /* PRQA S 3432 # JV-01 */
  VAR(boolean, AUTOMATIC) LblNotificationRequired;
  #endif
  #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  VAR(uint16, AUTOMATIC) LusTxErrorCounter;
  VAR(uint16, AUTOMATIC) LusRxErrorCounter;
  VAR(uint32, AUTOMATIC) LulRegEVNTMask;
  VAR(uint8, AUTOMATIC) LucFormIndex;
  const Can_ErrorType LaaErrorForm[CANXL_NUM_OF_BUS_ERROR] = 
  {
    CAN_ERROR_CHECK_CRC_FAILED,
    CAN_ERROR_BIT_MONITORING0,
    CAN_ERROR_BIT_MONITORING1,
    CAN_ERROR_CHECK_ACK_FAILED,
    CAN_ERROR_CHECK_FORM_FAILED,
    CAN_ERROR_CHECK_STUFFING_FAILED,
  };
  #endif
  #if ((CAN_BUSOFF_INTERRUPT == STD_ON) || (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON) || \
      ((CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) && (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)))
  P2CONST(Can_CanXLHWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA) LpCanXLHWInfo;                                           /* PRQA S 3432 # JV-01 */
  #endif
  LucCtrlIndex = Can_GpConfig->pCanXLPhysicalControllerToIndex[LucPhysController];
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  LucCh = LpPCController->ucCh;
  LucCtrlInfoIndex = Can_GpConfig->pCanXLSecondPhysicalControllerToIndex[LucCh];
  #if ((CAN_BUSOFF_INTERRUPT == STD_ON) || (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON) || \
      ((CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) && (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)))
  LpCanXLHWInfo = (P2CONST(Can_CanXLHWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA))Can_GpConfig->pCanXLHWUnitInfo;         /* PRQA S 0316, 3432 # JV-01, JV-01 */
  #endif
  #if ((CAN_BUSOFF_INTERRUPT == STD_ON) || (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON))
  LucSubCtrlIndex = LucCtrlIndex + (uint8)CAN_CONTROLLER_OFFSET;                                                        /* PRQA S 2985 # JV-01 */
  LucTransceiverID = LpCanXLHWInfo[LucCtrlInfoIndex].ucTransceiverID;
  #endif
  #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  LulRegEVNTMask = 0UL;
  LucFormIndex = 0U;
  #endif
  #if (CAN_BUSOFF_INTERRUPT == STD_ON)
  LblNotificationRequired = CAN_FALSE;
  #endif
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LulERRENA = CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulERRENA;
  /* If no irq exists, this interrupt is wrong */
  if ((0UL == ((LulERRENA) & (CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulERRRAW))) ||
                #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON) 
                (0U == NVIC_GetActive(LpPCController->pICErr->enInterruptID))                                           /* PRQA S 3415, 3416 # JV-01, JV-01 */
                #else
                (0U == GIC_GetEnableIRQ(LpCanXLHWInfo[LucCtrlInfoIndex].ulErrEicID))                                    /* PRQA S 3415, 3416 # JV-01, JV-01 */
                #endif 
     )
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    #if (CAN_BUSOFF_INTERRUPT == STD_ON)
    /* Check whether Busoff event is occurred or not */
    if(0UL != ((uint32)LpPCController->ucIntEnable & (uint32)CAN_CHECK_INT_BUSOFF))
    {
      if (0UL != (CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulSTAT & CAN_CANXL_BOEF))
      {
        if (CAN_TRUE == LpCanXLHWInfo[LucCtrlInfoIndex].blEthStackConfigured)
        {
          for(LulCounter = 0UL; LulCounter < CanXL_GaaTxBufferTotal[LucCh]; LulCounter++)
          {
            LpBufHandlerPtr = CanXL_GaaTxBufferMgrTable[LucCh][LulCounter].pBufferHdr;
            /* Check Buffer handler is not NULL */
            if (NULL_PTR != LpBufHandlerPtr)
            {
              /* Release all Tx buffer */
              CanXL_ReleaseTxBuffer(LucCtrlInfoIndex, LulCounter);
            } /* else no action required*/
          }
          if (ETH_MODE_ACTIVE == CanXL_GaaCtrlStat[LucCtrlInfoIndex].enMode)
          {
            CanXL_GaaCtrlStat[LucCtrlInfoIndex].enMode = ETH_MODE_DOWN;
            EthIf_CtrlModeIndication((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), ETH_MODE_DOWN);                     /* PRQA S 3383, 2985 # JV-01, JV-01 */
            EthIf_TxConfirmation((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET), CANXL_BUSOFF_BUFFER_ID, E_NOT_OK);      /* PRQA S 3383, 2985 # JV-01, JV-01 */
          }
        }
        CAN_ENTER_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION);
        if ((CAN_COMMON_STATE_STARTED == Can_GaaCtrlState[LucCtrlIndex].enMode) &&
            (CAN_NO_PENDING_TRANSITION == Can_GaaCtrlState[LucCtrlIndex].enSubState))
        {
          /* Set bus-off flag */
          Can_GaaCtrlState[LucCtrlIndex].blBusOff = CAN_TRUE;
          /* XCAN IP use SW to stop controller completely */
          Can_GaaCtrlState[LucCtrlIndex].enSubState = CANXL_STOP_WAIT_TXRXQUEUE_STOP;
          /* Notification for CanIf is required */
          LblNotificationRequired = CAN_TRUE;
        } /* else no action required*/
        CAN_EXIT_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION);
        if (CAN_TRUE == LblNotificationRequired)
        {
          CanIf_ControllerBusOff((uint8)LucSubCtrlIndex);
          (void)(CanXLTrcv_ReportErrorState(LucTransceiverID, CAN_ERRORSTATE_BUSOFF));
          (void)CanXL_StopMode(LucCtrlIndex);
        } /* else No action required */
      }
    } /*else No action required */
    #endif
    #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
    /* Check if Error Passive flag is set or not*/
    if(0UL != (CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulSTAT & CAN_CANXL_EPEF))
    {
      LusRxErrorCounter = (uint16)((CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulSTAT
                                     & CANXL_REC_MASK) >> CANXL_REC_OFFSET);
      LusTxErrorCounter = (uint16)((CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulSTAT
                                     & CANXL_TEC_MASK) >> CANXL_TEC_OFFSET);
      CanIf_ControllerErrorStatePassive(LucSubCtrlIndex, LusRxErrorCounter, LusTxErrorCounter);
      (void)(CanXLTrcv_ReportErrorState(LucTransceiverID, CAN_ERRORSTATE_PASSIVE));
    }/*else No action required */
    /* Check whether Can Bus Error event is occurred or not */
    
    while(CANXL_NUM_OF_BUS_ERROR > LucFormIndex)
    {
      /* Check if error bit is set or not*/
      if(0UL != ((CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulEVNT >> LucFormIndex) & CANXL_CHECK_BIT_SET))
      {
        CanIf_ErrorNotification(LucSubCtrlIndex, LaaErrorForm[LucFormIndex]);
        /* Mask Error bit to clear error flag */
        LulRegEVNTMask = LulRegEVNTMask | (CANXL_CHECK_BIT_SET << LucFormIndex);
      }
      LucFormIndex++;  
    }
    /* Clear all error flags */
    #if (CAN_DEVICE_NAME == CAN_U5X)
    MCAL_SV_MODE_REG_AND(32, &CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulEVNT, ~LulRegEVNTMask);                           /* PRQA S 3464 # JV-01 */
    #else
    CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulEVNT &= ~LulRegEVNTMask;
    #endif
    #else
    CanXL_GaaRegs[LucCtrlInfoIndex].pPRT->ulEVNT &= ~(CANXL_BUS_ERROR_MASK);
    #endif 
    CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulERRCLR = 0xFFFFFFFFUL;
    /* Dummy read */
    (void)(CanXL_GaaRegs[LucCtrlInfoIndex].pIRC->ulERRRAW);
    #if (CAN_DEVICE_NAME == CAN_U5X)
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
    #endif
  }
}

/***********************************************************************************************************************
** Function Name         : Can_ImfuCanXLErrIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each RX_ISR IMFU Level
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucGroupChannel : Group channel Number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController
**
** Functions Invoked     : CanXL_ErrIsr, CAN_DEM_REPORT_ERROR
**
** Registers Used        : IMFULFi
**
** Reference ID          : CAN_DUD_ACT_080
** Reference ID          : CAN_DUD_ACT_080_ERR001, CAN_DUD_ACT_080_REG001
** Reference ID          : CAN_DUD_ACT_080_GBL001
***********************************************************************************************************************/
#if (CAN_DEVICE_NAME == CAN_U5X)
STATIC FUNC(void, CAN_CODE_FAST) Can_ImfuCanXLErrIsr(CONST(uint8, AUTOMATIC) LucGroupChannel)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  VAR(uint8, AUTOMATIC) LucPhyController;
  VAR(uint8, AUTOMATIC) LucIntMergeIndex;
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  VAR(boolean, AUTOMATIC) LucIsrhandler;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIsConsistency;

  /* Interrupt is not consistency */
  LblIsConsistency = CAN_FALSE;
  #endif
  /* 
    49 - IMFUL Group No 2 - CAN0/2/4/6 transmit/receive FIFO receive completion interrupt
    50 - IMFUL Group No 3 - CAN1/3/5/7 transmit/receive FIFO receive completion interrupt
  */
  /* Get started ctrl base index 0 or 1 */
  /* Loop for call controllers */
  for (LucIntMergeIndex = 0U; LucIntMergeIndex < (CANXL_MAX_CONTROLLER/2U); LucIntMergeIndex++)                         /* PRQA S 2877 # JV-01 */
  {
    /* init LucIsrhandler for each controller */
    LucIsrhandler = CAN_FALSE;
    /* if IMFU is 0/2/4/6 or 1/3/5/7 */
    LucPhyController = (uint8)((uint8)(LucIntMergeIndex * 2U) + (uint8)(LucGroupChannel % 2U));                         /* PRQA S 3383, 2986 # JV-01, JV-01 */
    /* Convert the physical Controller index to the config index */
    /* Queery: Can_GaaPhysicalControllerToIndex0 shoul be generated with default value is 0xFF */
    LucCtrlIndex = Can_GpConfig->pCanXLPhysicalControllerToIndex[LucPhyController];
    /* Get controller PC configuration value */
    /* if each LIFF bit (0->2) of IMFULFi (IMFU Level Status Register) is set */
    if (LucCtrlIndex != (uint8)0xFFU)
    {
      LpPCController = &Can_GpPCController[LucCtrlIndex];
      
      /* Check interrupt mege group or not */
      if (NULL_PTR == LpPCController->pICRec->pIMFU)
      {
        LucIsrhandler = CAN_TRUE;
      } 
      else if ((*(LpPCController->pICErr->pIMFU) & (uint32)((uint32)1U << LucIntMergeIndex)) != (uint32)0U)             /* PRQA S 2004 # JV-01 */
      {
        LucIsrhandler = CAN_TRUE;
      } /* else do not thing */
    }
    if (CAN_TRUE == LucIsrhandler)
    {
      /* Intput to Isr handler */
      CanXL_ErrIsr(LucPhyController);
      #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
      /* ISR is consistency */
      LblIsConsistency = CAN_TRUE;
      #endif
    }
  }
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* Check consistency */
  if (CAN_FALSE == LblIsConsistency)
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  #endif
}
#endif /* #if (CAN_DEVICE_NAME == CAN_U5X) */
#endif /* ((CAN_CANXL_CONTROLLER0_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER1_ERROR_ISR == STD_ON)) */
/***********************************************************************************************************************
** Function Name         : CANXL_CONTROLLERn_ERR_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is Error Interrupt Service routines for the CanXL
**                         controller n.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : CanXL_ErrIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_200
** Reference ID          : CAN_DUD_ACT_201
***********************************************************************************************************************/
#if (CAN_CANXL_CONTROLLER0_ERROR_ISR == STD_ON) || (CAN_CANXL_CONTROLLER2_ERROR_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER02_FUNC_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)

ISR(CANXL_CONTROLLER02_ERR_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER02_ERR_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  #if (CAN_DEVICE_NAME == CAN_U5X)
  Can_ImfuCanXLErrIsr(0x00U);
  #else
  CanXL_ErrIsr(CANXL_PHYIDX_CONTROLLER0);
  #endif
}
#endif

#if (CAN_CANXL_CONTROLLER1_ERROR_ISR == STD_ON) ||  (CAN_CANXL_CONTROLLER3_ERROR_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER1_ERR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)

ISR(CANXL_CONTROLLER13_ERR_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER13_ERR_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  #if (CAN_DEVICE_NAME == CAN_U5X)
  Can_ImfuCanXLErrIsr(0x01U);
  #else
  CanXL_ErrIsr(CANXL_PHYIDX_CONTROLLER1);
  #endif
}
#endif
#endif /* #if (CAN_CANXL_SUPPORTED == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Can_RxGlobalIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each RXFIFO_ISR.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucUnit: Physical number of Unit
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Global Variables Used : Can_GaaRegs, Can_GpConfig
**
** Functions Invoked     : Can_RxProcessingRxFIFO, CAN_DEM_REPORT_ERROR
**
** Registers Used        : (CFD)RFCC, (CFD)RFSTS, EICn
**                         (CFD)GSTS (for dummy read only)
**
** Reference ID          : CAN_DUD_ACT_065
** Reference ID          : CAN_DUD_ACT_065_REG001, CAN_DUD_ACT_065_REG002
** Reference ID          : CAN_DUD_ACT_065_ERR001
***********************************************************************************************************************/
#if ((CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) || (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON))
STATIC FUNC(void, CAN_CODE_FAST) Can_RxGlobalIsr(CONST(uint8, AUTOMATIC) LucUnit)                                       /* PRQA S 3006 # JV-01 */
{
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(uint32, AUTOMATIC) LulRxFIFOIndex;
  VAR(uint32, AUTOMATIC) LulIrqExist;
  VAR(uint32, AUTOMATIC) LulRFIFGet;
  VAR(uint32, AUTOMATIC) LulRFIEGet;
  #endif

  #if (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON)
  VAR(uint32, AUTOMATIC) LulWUFMask;
  #endif

  #if (((CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) && (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)) || \
      (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON))
  P2CONST(Can_HWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA) LpHWInfo;                                                     /* PRQA S 3432 # JV-01 */
  LpHWInfo = (P2CONST(Can_HWUnitInfoType, AUTOMATIC, CAN_CONFIG_DATA))Can_GpConfig->pHWUnitInfo;                        /* PRQA S 0316, 3432 # JV-01, JV-01 */
  LpHWInfo = &LpHWInfo[LucUnit];
  #endif

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LulIrqExist = 0U;
  /* Accumurate all interrupt request flags of all RxFIFO */
  for (LulRxFIFOIndex = 0UL; LulRxFIFOIndex < CAN_RSCAN_RXFIFO_PER_UNIT; LulRxFIFOIndex++)
  {
    /* if (RFCCk.RFIE && RFSTSk.RFIF), it means that irq exists */
    LulRFIFGet = CAN_RSCAN_RFIF_GET(Can_GaaRegs[LucUnit].pCmn->aaRFSTS[LulRxFIFOIndex]);                                /* PRQA S 3469 # JV-01 */
    LulRFIEGet = CAN_RSCAN_RFIE_GET(Can_GaaRegs[LucUnit].pCmn->aaRFCC[LulRxFIFOIndex]);                                 /* PRQA S 3469 # JV-01 */
    LulIrqExist = LulIrqExist | (LulRFIFGet & LulRFIEGet);
  }
  /* If no irq from RS-CAN, note: interrupt merge function is not applicable for Rx FIFO */
  if ((0UL == LulIrqExist) ||
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
      (0U == NVIC_GetActive(Can_GaaRegs[LucUnit].pICRxFIFO->enInterruptID)))                                            /* PRQA S 3416, 3415 # JV-01, JV-01 */
  #else
      (0U == GIC_GetEnableIRQ(LpHWInfo->ulGICRxFIFO)))                                                                  /* PRQA S 3416, 3415 # JV-01, JV-01 */
  #endif
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    /* pWUF0Reg of U5x not used currently, keep it for futher use */
    #if (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON)
    LulWUFMask = LpHWInfo->ulRxFIFOWUFMask;
    if (LulWUFMask == (uint32)(*Can_GaaRegs[LucUnit].pWUF0Reg & LulWUFMask))
    {
      *Can_GaaRegs[LucUnit].pWUFC0Reg = LulWUFMask;
    } /* else No action required */
    #endif /* #if (CAN_WAKE_UP_FACTOR_CLEAR_ISR == STD_ON) */
    #if (CAN_RX_FIFO == STD_ON)
    /* Invoke Can_RxProcessing internal function for receive processing */
    Can_RxProcessingRxFIFO(CAN_RXPROC_RXFIFO(LucUnit), CAN_CHECK_INT_RX, CAN_MAINFUNCTION_INSTANCE_0                    /* PRQA S 3469 # JV-01 */
    #if(CAN_VIRTUAL_MACHINE_ENABLE == STD_ON)
    , CAN_VM_INVALID
    #endif
    );
    #endif
    #if (CAN_DEVICE_NAME == CAN_U5X)
    CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    /* DummyRead & SYNCP */
    MCAL_SET_IOREG_SYNCP(32, &Can_GaaRegs[LucUnit].pCmn->ulGSTS, 0UL);                                                  /* PRQA S 1006, 2814, 3464 # JV-01, JV-01, JV-01 */
    CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    #endif
  }
}
#endif /* #if ((CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) || (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)) */

#if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : CAN_RSCANn_RXFIFO_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is RXFIFO Interrupt Service routines for the Can
**                         hardware unit n.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_RxGlobalIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_020
** Reference ID          : CAN_DUD_ACT_044
***********************************************************************************************************************/
#if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(CAN_RSCAN0_RXFIFO_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_RSCAN0_RXFIFO_CAT2_ISR)                                                                                         /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_RSCAN0_RXFIFO_ISR(void)                                                       /* PRQA S 1503 # JV-01 */
#endif
{
  Can_RxGlobalIsr(CAN_PHYIDX_UNIT0);
}
#endif /* (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) */

#if (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(CAN_RSCAN1_RXFIFO_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_RSCAN1_RXFIFO_CAT2_ISR)                                                                                         /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_RSCAN1_RXFIFO_ISR(void)                                                       /* PRQA S 1503 # JV-01 */
#endif
{
  Can_RxGlobalIsr(CAN_PHYIDX_UNIT1);
}
#endif /* (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) */
/***********************************************************************************************************************
** Function Name         : Can_ImfuRxIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each RX_ISR IMFU Level
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucImfuGrpId : IMFUL Group Number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController
**
** Functions Invoked     : Can_RxIsr, CAN_DEM_REPORT_ERROR
**
** Registers Used        : IMFULFi
**
** Reference ID          : CAN_DUD_ACT_068
** Reference ID          : CAN_DUD_ACT_068_ERR001, CAN_DUD_ACT_068_REG001
** Reference ID          : CAN_DUD_ACT_068_GBL001, CAN_DUD_ACT_068_GBL002
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_RX_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_ImfuRxIsr(CONST(uint8, AUTOMATIC) LucImfuGrpId)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  VAR(uint8, AUTOMATIC) LucPhyController;
  VAR(uint8, AUTOMATIC) LucIntMergeIndex;
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIsConsistency;

  /* Interrupt is not consistency */
  LblIsConsistency = CAN_FALSE;
  #endif
  /* 
    49 - IMFUL Group No 2 - CAN0/2/4/6 transmit/receive FIFO receive completion interrupt
    50 - IMFUL Group No 3 - CAN1/3/5/7 transmit/receive FIFO receive completion interrupt
  */
  /* Get started ctrl base index 0 or 1 */
  /* Loop for call controllers */
  for (LucIntMergeIndex = 0U; LucIntMergeIndex < CAN_MAX_INT_MERGE_PER_GRP; LucIntMergeIndex++)
  {
    /* if IMFU is 0/2/4/6 or 1/3/5 */
    LucPhyController = (uint8)((uint8)(LucIntMergeIndex * 2U) + (uint8)(LucImfuGrpId % 2U));                            /* PRQA S 3383 # JV-01 */
    /* Convert the physical Controller index to the config index */
    /* Queery: Can_GaaPhysicalControllerToIndex0 shoul be generated with default value is 0xFF */
    LucCtrlIndex = Can_GpConfig->pPhysicalControllerToIndex[LucPhyController];
    /* Get controller PC configuration value */
    /* if each LIFF bit (0->2) of IMFULFi (IMFU Level Status Register) is set */
    if (LucCtrlIndex != (uint8)0xFFU)
    {
      LpPCController = &Can_GpPCController[LucCtrlIndex];
      if ((*(LpPCController->pICRec->pIMFU) & (0x01UL << (uint32)LucIntMergeIndex)) 
                                                                == (0x01UL << (uint32)LucIntMergeIndex))
      {
        /* Intput to Isr handler */
        Can_RxIsr(LucCtrlIndex);
        #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
        /* ISR is consistency */
        LblIsConsistency = CAN_TRUE;
        #endif
      } /* else do not thing */
    }
  }
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* Check consistency */
  if ((0U == NVIC_GetActive((&Can_GpPCController[(LucImfuGrpId % 2U)])->pICRec->enInterruptID))                         /* PRQA S 3416 # JV-01 */
                                                                                  || (CAN_FALSE == LblIsConsistency))
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  #endif
}
#endif /* #ifdef CAN_CONTROLLER_RX_INTERRUPT_ON */

/***********************************************************************************************************************
** Function Name         : Can_RxIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each RX_ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucCtrlIndex : SW number of Controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController,
**                         Can_GaaRegs
**
** Functions Invoked     : Can_RxProcessingTxRxFIFO, CAN_DEM_REPORT_ERROR
**
** Registers Used        : (CFD)CFSTSk, (CFD)CFCCk, (CFD)GSTS (for dummy read only)
**
** Reference ID          : CAN_DUD_ACT_028
** Reference ID          : CAN_DUD_ACT_028_ERR001, CAN_DUD_ACT_028_REG001
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_RX_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_RxIsr(CONST(uint8, AUTOMATIC) LucCtrlIndex)                                        /* PRQA S 3006 # JV-01 */
{
  VAR(uint8, AUTOMATIC) LucUnit;
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(uint32, AUTOMATIC) LulTxRxFIFOIndex;
  VAR(uint32, AUTOMATIC) LulLoop;
  VAR(uint32, AUTOMATIC) LulIrqExist;
  VAR(uint32, AUTOMATIC) LulCFRXIFGet;
  VAR(uint32, AUTOMATIC) LulCFRXIEGet;
  #endif /*#if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)*/

  LpPCController = &Can_GpPCController[LucCtrlIndex];
  LucUnit = LpPCController->ucUnit;

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LulIrqExist = 0U;
  /* Accumurate all interrupt request flags of all TxRxFIFO */
  LulTxRxFIFOIndex = (uint32)LpPCController->ucCh * CAN_RSCAN_TXRXFIFO_PER_CH;                                          /* PRQA S 3384 # JV-01 */
  for (LulLoop = 0U; LulLoop < CAN_RSCAN_TXRXFIFO_PER_CH; LulLoop++)
  {
    /* if (CFCCk.CFRXIE && CFSTSk.CFRXIF), it means that irq exists */
    LulCFRXIEGet = CAN_RSCAN_CFRXIE_GET(Can_GaaRegs[LucUnit].pCmn->aaCFCC[LulTxRxFIFOIndex]);                           /* PRQA S 3469 # JV-01 */
    LulCFRXIFGet = CAN_RSCAN_CFRXIF_GET(Can_GaaRegs[LucUnit].pCmn->aaCFSTS[LulTxRxFIFOIndex]);                          /* PRQA S 3469 # JV-01 */
    LulIrqExist = LulIrqExist | ( LulCFRXIEGet & LulCFRXIFGet);
    LulTxRxFIFOIndex++;                                                                                                 /* PRQA S 3383 # JV-01 */
  }
  /* If no irq exists from RS-CAN or EIC is masked, this interrupt is wrong */
  if (0UL == LulIrqExist)                                                                                               /* PRQA S 3415, 3416 # JV-01, JV-01 */
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    #if (CAN_RX_COMFIFO == STD_ON)
    /* Invoke Can_RxProcessing internal function for receive processing */
    Can_RxProcessingTxRxFIFO(CAN_RXPROC_TXRXFIFO(LucCtrlIndex), CAN_CHECK_INT_RX, CAN_MAINFUNCTION_INSTANCE_0);         /* PRQA S 3469 # JV-01 */
    
    #endif
    CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    /* DummyRead & SYNCP */
    MCAL_SET_IOREG_SYNCP(32, &Can_GaaRegs[LucUnit].pCmn->ulGSTS, 0UL);                                                  /* PRQA S 3464, 1006 # JV-01, JV-01 */
    CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
  }
}
#endif /* End of #ifdef CAN_CONTROLLER_RX_INTERRUPT_ON */

/***********************************************************************************************************************
** Function Name         : CAN_CONTROLLER<mmmm>_RX_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is RX Interrupt Service routines for the Can controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_ImfuRxIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_069
** Reference ID          : CAN_DUD_ACT_043
***********************************************************************************************************************/
#if ((CAN_CONTROLLER0_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0246_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER0246_RX_CAT2_ISR)                                                                                     /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0246_RX_ISR(void)                                                   /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 2 */
  Can_ImfuRxIsr(0x02U);
}
#endif

#if ((CAN_CONTROLLER1_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER3_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER5_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER7_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1357_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER1357_RX_CAT2_ISR)                                                                                     /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1357_RX_ISR(void)                                                   /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 3 */
  Can_ImfuRxIsr(0x03U);
}
#endif

#if ((CAN_CONTROLLER8_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8101214_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER8101214_RX_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8101214_RX_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 37 */
  Can_ImfuRxIsr(0x25U);
}
#endif

#if ((CAN_CONTROLLER9_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER11_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER13_RX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER15_RX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9111315_RX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER9111315_RX_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9111315_RX_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 38 */
  Can_ImfuRxIsr(0x26U);
}
#endif

/***********************************************************************************************************************
** Function Name         : Can_ImfuTxIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each TX_ISR IMFU Level
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucImfuGrpId : IMFUL Group Number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController
**
** Functions Invoked     : Can_TxIsr, CAN_DEM_REPORT_ERROR
**
** Registers Used        : IMFULFi
**
** Reference ID          : CAN_DUD_ACT_070
** Reference ID          : CAN_DUD_ACT_070_ERR001, CAN_DUD_ACT_070_REG001
** Reference ID          : CAN_DUD_ACT_070_GBL001, CAN_DUD_ACT_070_GBL002
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_TX_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_ImfuTxIsr(CONST(uint8, AUTOMATIC) LucImfuGrpId)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  VAR(uint8, AUTOMATIC) LucIntMergeIndex;
  VAR(uint8, AUTOMATIC) LucPhyController;
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIsConsistency;

  /* Interrupt is not consistency */
  LblIsConsistency = CAN_FALSE;
  #endif
  /*
  51 - IMFUL Group No 4 - CAN0/2/4/6 transmit interrupt
  51 - IMFUL Group No 5 - CAN1/3/5/7 transmit interrupt
  */
  /* Get started ctrl base index */
  /* Loop for call controllers */

  for (LucIntMergeIndex = 0U; LucIntMergeIndex < CAN_MAX_INT_MERGE_PER_GRP; LucIntMergeIndex++)
  {
    /* if IMFU is 0/2/4/6 or 1/3/5 */
    LucPhyController = (uint8)((uint8)(LucIntMergeIndex * 2U) + (uint8)(LucImfuGrpId % 2U));                            /* PRQA S 3383 # JV-01 */
    /* Convert the physical Controller index to the config index */
    /* Queery: Can_GaaPhysicalControllerToIndex0 shoul be generated with default value is 0xFF */
    LucCtrlIndex = Can_GpConfig->pPhysicalControllerToIndex[LucPhyController];
    /* if each LIFF bit (0->2) of IMFULFi (IMFU Level Status Register) is set */
    if (LucCtrlIndex != (uint8)0xFFU)
    {
      /* Get controller PC configuration value */
      LpPCController = &Can_GpPCController[LucCtrlIndex];
      if((*(LpPCController->pICTx->pIMFU) & (0x01UL << (uint32)LucIntMergeIndex)) 
                                                                           == (0x01UL << (uint32)LucIntMergeIndex))
      {
        /* Intput to Isr handler */
        Can_TxIsr(LucCtrlIndex);
        #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
        /* ISR is consistency */
        LblIsConsistency = CAN_TRUE;
        #endif
      }
    }
  }
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* Check consistency */
  if ((0U == NVIC_GetActive((&Can_GpPCController[(LucImfuGrpId % 2U)])->pICTx->enInterruptID))                          /* PRQA S 3416 # JV-01 */
                                                                                  || (CAN_FALSE == LblIsConsistency))
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  #endif
}
#endif /* #ifdef CAN_CONTROLLER_TX_INTERRUPT_ON*/

/***********************************************************************************************************************
** Function Name         : Can_TxIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each TX_ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucCtrlIndex : SW number of Controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Global Variables Used : Can_GpPCController, Can_GaaRegs
**
** Functions Invoked     : Can_TxConfirmationProcessing, CAN_DEM_REPORT_ERROR
**
** Registers Used        : (CFD)GTINTSTSx, (CFD)GSTS (for dummy read only)
**
** Reference ID          : CAN_DUD_ACT_029
** Reference ID          : CAN_DUD_ACT_029_ERR001, CAN_DUD_ACT_029_REG001
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_TX_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_TxIsr(CONST(uint8, AUTOMATIC) LucCtrlIndex)                                        /* PRQA S 3006 # JV-01 */
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;

  /* Convert the physical Controller index to the config index */
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  /* If no irq exists from RS-CAN or EIC is masked, this interrupt is wrong */

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* If no irq exists from RS-CAN or EIC is masked, this interrupt is wrong */
  if (0U == Can_GaaRegs[LpPCController->ucUnit].pCmn->unGTINTSTS.aaGTINTSTSb[LpPCController->ucCh])                     /* PRQA S 3415, 3416 # JV-01, JV-01 */
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    #if ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON))
    Can_TxConfirmationProcessing(LucCtrlIndex);
    /* DummyRead & SYNCP */
    CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    MCAL_SET_IOREG_SYNCP(32, &Can_GaaRegs[LpPCController->ucUnit].pCmn->ulGSTS, 0UL);                                   /* PRQA S 3464, 1006 # JV-01, JV-01 */
    CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    #endif
  }
}
#endif /* (CAN_CONTROLLERn_TX_INTERRUPT == STD_ON) */

/***********************************************************************************************************************
** Function Name         : CAN_CONTROLLER<mmmm>_TX_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is TX Interrupt Service routines for the Can Controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_ImfuTxIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_021
** Reference ID          : CAN_DUD_ACT_058
***********************************************************************************************************************/
#if (CAN_CONTROLLER0_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER2_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER4_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER6_TX_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0246_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER0246_TX_CAT2_ISR)                                                                                     /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0246_TX_ISR(void)                                                   /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 4 - CAN0/2/4/6 transmit interrupt */
  Can_ImfuTxIsr(0x04U);
}
#endif

#if (CAN_CONTROLLER1_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER3_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER5_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER7_TX_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1357_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER1357_TX_CAT2_ISR)                                                                                     /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1357_TX_ISR(void)                                                   /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 5 - CAN1/3/5/7 transmit interrupt */
  Can_ImfuTxIsr(0x05U);
}
#endif

#if (CAN_CONTROLLER8_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER10_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER12_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER14_TX_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8101214_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER8101214_TX_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8101214_TX_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 39 - CAN8/10/12/14 transmit interrupt */
  Can_ImfuTxIsr(0x27U);
}
#endif

#if (CAN_CONTROLLER9_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER11_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER13_TX_INTERRUPT == STD_ON) ||   \
     (CAN_CONTROLLER15_TX_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9111315_TX_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER9111315_TX_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9111315_TX_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 40 - CAN9/11/13/15 transmit interrupt */
  Can_ImfuTxIsr(0x28U);
}
#endif

/***********************************************************************************************************************
** Function Name         : Can_ImfuErrorIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each ERROR_ISR IMFU Level
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucInterruptSelId : Physical number of interrupt selection
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController
**
** Functions Invoked     : Can_ErrorIsr, CAN_DEM_REPORT_ERROR
**
** Registers Used        : IMFULFi
**
** Reference ID          : CAN_DUD_ACT_072
** Reference ID          : CAN_DUD_ACT_072_ERR001, CAN_DUD_ACT_072_REG001
** Reference ID          : CAN_DUD_ACT_072_GBL001
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_ERROR_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_ImfuErrorIsr(CONST(uint8, AUTOMATIC) LucImfuGrpId)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  uint8 LucPhyController;
  uint8 LucIntMergeIndex;
  uint8 LucCtrlIndex;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIsConsistency;

  /* Interrupt is not consistency */
  LblIsConsistency = CAN_FALSE;
  #endif

/* grp 0 - CAN0/2/4/6 error interrupt
   grp 1 - CAN1/3/5/7 error interrupt 
   */
  /* Get started ctrl base index 0 or 1 */
  /* Loop for call controllers */

  for (LucIntMergeIndex = 0U; LucIntMergeIndex < CAN_MAX_INT_MERGE_PER_GRP; LucIntMergeIndex++)
  {
    /* if IMFU is 0/2/4/6 or 1/3/5 */
    LucPhyController = (uint8)((uint8)(LucIntMergeIndex * 2U) + (uint8)(LucImfuGrpId % 2U));                            /* PRQA S 3383 # JV-01 */
    /* Convert the physical Controller index to the config index */
    /* Queery: Can_GaaPhysicalControllerToIndex0 shoul be generated with default value is 0xFF */
    LucCtrlIndex = Can_GpConfig->pPhysicalControllerToIndex[LucPhyController];
    /* Get controller PC configuration value */
    if (LucCtrlIndex != (uint8)0xFFU)
    {
      LpPCController = &Can_GpPCController[LucCtrlIndex];
    /* if each LIFF bit (0->2) of IMFULFi (IMFU Level Status Register) is set */
     if((*(LpPCController->pICErr->pIMFU) & (0x01UL << (uint32)LucIntMergeIndex)) 
                                                                          == (0x01UL << (uint32)LucIntMergeIndex))
      {
        /* Intput to Isr handler */
        Can_ErrorIsr(LucCtrlIndex);
        #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
        /* ISR is consistency */
        LblIsConsistency = CAN_TRUE;
        #endif
      }
    }
  }

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  if ((0U == NVIC_GetActive((&Can_GpPCController[(LucImfuGrpId % 2U)])->pICErr->enInterruptID))                         /* PRQA S 3416 # JV-01 */
                                                                                || (CAN_FALSE == LblIsConsistency))
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  #endif                                                                                  
}
#endif /* #ifdef CAN_CONTROLLER_ERROR_INTERRUPT_ON */

/***********************************************************************************************************************
** Function Name         : Can_ErrorIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each BUS_ERROR_ISR.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucCtrlIndex : SW number of Controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Global Variables Used : Can_GpConfig, Can_GpPCController,
**                         Can_GaaRegs, Can_GaaCtrlState
**
** Functions Invoked     : CanIf_ControllerBusOff, Can_SubErrorIsr, CAN_DEM_REPORT_ERROR
**
** Registers Used        : (CFD)CmCTR, (CFD)ERFL, (CFD)GSTS (for dummy read only)
**
** Reference ID          : CAN_DUD_ACT_030
** Reference ID          : CAN_DUD_ACT_030_ERR001, CAN_DUD_ACT_030_GBL001,
** Reference ID          : CAN_DUD_ACT_030_GBL002, CAN_DUD_ACT_030_GBL003,
** Reference ID          : CAN_DUD_ACT_030_REG001, CAN_DUD_ACT_030_REG002,
** Reference ID          : CAN_DUD_ACT_030_CRT001, CAN_DUD_ACT_030_CRT002
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_ERROR_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_ErrorIsr(CONST(uint8, AUTOMATIC) LucCtrlIndex)                                     /* PRQA S 3006 # JV-01 */
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;
  #if (CAN_BUSOFF_INTERRUPT == STD_ON)
  VAR(boolean, AUTOMATIC) LblNotificationRequired;
  #endif
  #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  VAR(uint32, AUTOMATIC) LulRegERFLMask;
  #endif

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) 
  VAR(uint32, AUTOMATIC) LulEIEBITSGet;
  #endif

  /* Convert the physical Controller index to the config index */
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  LucUnit = LpPCController->ucUnit;
  LucCh = LpPCController->ucCh;
  #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  LulRegERFLMask = 0UL;
  #endif
  #if (CAN_BUSOFF_INTERRUPT == STD_ON)
  LblNotificationRequired = CAN_FALSE;
  #endif
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) 
  /* If no irq exists from RS-CAN, this interrupt is wrong */
  LulEIEBITSGet = CAN_RSCAN_GET_EIEBITS(Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR);                               /* PRQA S 3469 # JV-01 */
  if (0UL == (LulEIEBITSGet & CAN_RSCAN_GET_EFBITS(Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL)))                  /* PRQA S 3469 # JV-01 */
  {
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    #if (CAN_BUSOFF_INTERRUPT == STD_ON)
    /* Check whether Busoff event is occurred or not */
    if(0UL != ((uint32)LpPCController->ucIntEnable & (uint32)CAN_CHECK_INT_BUSOFF))
    {
      if (0UL != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL & CAN_RSCAN_BOEF))
      {
        /*
         * The transition START to STOP is done by the following triggers:
         *  - Can_SetControllerMode(CAN_COMMON_STATE_STOPPED)
         *  - Busoff
         * To avoid the state transition is done twice by both of triggers,
         * the exclusive control is required.
         */
        CAN_ENTER_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION);
        if ((CAN_COMMON_STATE_STARTED == Can_GaaCtrlState[LucCtrlIndex].enMode) &&
            (CAN_NO_PENDING_TRANSITION == Can_GaaCtrlState[LucCtrlIndex].enSubState))
        {
          /* Set bus-off flag */
          Can_GaaCtrlState[LucCtrlIndex].blBusOff = CAN_TRUE;
          /* When busoff has been occured, HW is CHANNLE_HALT mode already.
              So no additional operation is required, just set the mode. */
          Can_GaaCtrlState[LucCtrlIndex].enMode = CAN_COMMON_STATE_STOPPED;
          Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_NO_PENDING_TRANSITION;
          /* Notification for CanIf is required */
          LblNotificationRequired = CAN_TRUE;
        }
        else
        {
          /* No action required */
        } 
        CAN_EXIT_CRITICAL_SECTION(CAN_RAM_DATA_PROTECTION);
        if (CAN_TRUE == LblNotificationRequired)
        {
          CanIf_ControllerBusOff((uint8)(LucCtrlIndex + CAN_CONTROLLER_OFFSET));                                        /* PRQA S 3383, 2985 # JV-01, JV-01 */
        } /* else No action required */
        /* Mask bus off error flag */
        #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
        LulRegERFLMask = LulRegERFLMask | CAN_RSCAN_BOEF;
        #endif
      }  
    } /*else No action required */
    #endif
    /* Check whether Can Bus Error event is occurred or not */
    #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
    LulRegERFLMask = Can_SubErrorIsr(LucCtrlIndex, LucUnit, LucCh, LulRegERFLMask);
    /* Clear all error flags */
    Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL =  ~LulRegERFLMask;
    #else
    Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL = CAN_RSCAN_ERFL_CLEAR;
    #endif
    #if (CAN_DEVICE_NAME == CAN_U5X)
    /* Dummy read */
    (void)Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL;                                                             /* PRQA S 0404 # JV-01 */
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
    #endif
    /* DummyRead & SYNCP */
    CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    MCAL_SET_IOREG_SYNCP(32, &Can_GaaRegs[LucUnit].pCmn->ulGSTS, 0UL);                                                  /* PRQA S 3464, 1006 # JV-01, JV-01 */
    CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
  }
}
#endif /* (CAN_CONTROLLER_BUS_ERROR_INTERRUPT_ON) */

/***********************************************************************************************************************
** Function Name         : CAN_CONTROLLER<mmmm>_ERROR_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is BUS ERROR Interrupt Service routines for the Can Controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_ImfuErrorIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_059, CAN_DUD_ACT_022
***********************************************************************************************************************/
#if (CAN_CONTROLLER0_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER2_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER4_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER6_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0246_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER0246_ERROR_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0246_ERROR_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  /* IMFUL Group No 0 - CAN0/2/4/6 error interrupt */
  Can_ImfuErrorIsr(0x00);
}
#endif

#if (CAN_CONTROLLER1_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER3_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER5_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER7_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1357_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER1357_ERROR_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1357_ERROR_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  /*IMFUL Group No 1 - CAN1/3/5/7 error interrupt */
  Can_ImfuErrorIsr(0x01);
}
#endif


#if (CAN_CONTROLLER8_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER10_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER12_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER14_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8101214_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER8101214_ERROR_CAT2_ISR)                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8101214_ERROR_ISR(void)                                             /* PRQA S 1503 # JV-01 */
#endif
{
  /*IMFUL Group No 35 - CAN8/10/12/14 error interrupt */
  Can_ImfuErrorIsr(0x23);
}
#endif


#if (CAN_CONTROLLER9_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER11_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER13_ERROR_INTERRUPT == STD_ON) ||   \
    (CAN_CONTROLLER15_ERROR_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9111315_ERROR_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER9111315_ERROR_CAT2_ISR)                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9111315_ERROR_ISR(void)                                             /* PRQA S 1503 # JV-01 */
#endif
{
  /*IMFUL Group No 36 - CAN9/11/13/15 error interrupt */
  Can_ImfuErrorIsr(0x24);
}
#endif

#else
#if ((defined CAN_CONTROLLER_TX_INTERRUPT_ON) || (defined CAN_CONTROLLER_RX_INTERRUPT_ON) || \
 (defined CAN_CONTROLLER_ERROR_INTERRUPT_ON))
/***********************************************************************************************************************
** Function Name         : Can_ChannelIsr
**
** Service ID            : Not Applicable
**
** Description           : This is channel interrupt Service routines for the CAN
**                         hardware unit.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpPCController, Can_GaaRegs,
**                         Can_GaaCtrlState
**
** Functions Invoked     : Can_TxConfirmationProcessing, Can_RxProcessing,
**                         CanIf_ControllerBusOff, CAN_DEM_REPORT_ERROR
**
** Registers Used        : (CFD)GTINTSTSv, (CFD)CFSTSd, (CFD)CFCCd,
**                         (CFD)CmCTR, (CFD)ERFL
**
** Reference ID          : CAN_DUD_ACT_063, CAN_DUD_ACT_063_GBL001,
** Reference ID          : CAN_DUD_ACT_063_GBL002, CAN_DUD_ACT_063_REG001,
** Reference ID          : CAN_DUD_ACT_063_ERR001
***********************************************************************************************************************/
STATIC FUNC(void, CAN_CODE_FAST) Can_ChannelIsr(CONST(uint8, AUTOMATIC) LucController)
{
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  VAR(uint8, AUTOMATIC) LucUnit;
  VAR(uint8, AUTOMATIC) LucCh;
  #if ((CAN_BUSOFF_INTERRUPT == STD_ON) && (defined CAN_CONTROLLER_ERROR_INTERRUPT_ON))
  VAR(boolean, AUTOMATIC) LblNotificationRequired;
  #endif

  #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  VAR(uint32, AUTOMATIC) LulRegERFLMask;
  #endif

  #if ((defined CAN_CONTROLLER_RX_INTERRUPT_ON) && (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  VAR(uint32, AUTOMATIC) LulTxRxFIFOIndex;
  VAR(uint32, AUTOMATIC) LulLoop;
  VAR(uint32, AUTOMATIC) LulIrqExist;
  #endif

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIrqSrcFlag;
  #endif

  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */
  /* Initialize Interrupt Source Flag check */
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LblIrqSrcFlag = CAN_FALSE;
  #endif
  /* Get pointer to configuration table */
  LucCtrlIndex = Can_GpConfig->pPhysicalControllerToIndex[LucController];
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  LucUnit = LpPCController->ucUnit;                                                                                     /* PRQA S 2983 # JV-01 */
  LucCh = LpPCController->ucCh;                                                                                         /* PRQA S 2983 # JV-01 */

  #ifdef CAN_CONTROLLER_ERROR_INTERRUPT_ON
  /***************************************************************************
  * Check whether the Interrupt is CANm BusOff                               *
  ***************************************************************************/
  #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
  LulRegERFLMask = 0UL;
  #endif
  #if (CAN_BUSOFF_INTERRUPT == STD_ON)
  LblNotificationRequired = CAN_FALSE;
  #endif

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  if (0UL == (                                                                                                          /* PRQA S 0404 # JV-01 */
    CAN_RSCAN_GET_EIEBITS(Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulCTR) &                                            /* PRQA S 3469 # JV-01 */
    CAN_RSCAN_GET_EFBITS(Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL)))                                            /* PRQA S 3469 # JV-01 */
  {
    /* No Action Required */
  }
  else
  #endif /* #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
  {
  /* Set Interrupt Source Flag check */
    #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
    LblIrqSrcFlag = CAN_TRUE;
    #endif
    #if (CAN_BUSOFF_INTERRUPT == STD_ON) 
    /* Check whether Busoff event is occurred or not */
    if (0UL != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL & CAN_RSCAN_BOEF))
    {
      /*
        * The transition START to STOP is done by the following triggers:
        *  - Can_SetControllerMode(CAN_COMMON_STATE_STOPPED)
        *  - Busoff
        */
      if ((CAN_COMMON_STATE_STARTED == Can_GaaCtrlState[LucController].enMode) &&
          (CAN_NO_PENDING_TRANSITION == Can_GaaCtrlState[LucController].enSubState))
      {
        /* Set bus-off flag */
        Can_GaaCtrlState[LucController].blBusOff = CAN_TRUE;
        /* When busoff has been occured, HW is CHANNLE_HALT mode already.
            So no additional operation is required, just set the mode. */
        Can_GaaCtrlState[LucController].enMode = CAN_COMMON_STATE_STOPPED;
        /* Notification for CanIf is required */
        LblNotificationRequired = CAN_TRUE;
      } /* else No action required */
      if (CAN_TRUE == LblNotificationRequired)
      {
        CanIf_ControllerBusOff((uint8)(LucController + CAN_CONTROLLER_OFFSET));                                         /* PRQA S 2985, 3383 # JV-01, JV-01 */
      } /* else No action required */
      /* Mask bus off error flag */
      #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
      LulRegERFLMask = LulRegERFLMask | CAN_RSCAN_BOEF;
      #endif
    } /* else No action required */
    #endif
    #if (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
    LulRegERFLMask = Can_SubErrorIsr(LucController, LucUnit, LucCh, LulRegERFLMask);
    /* Clear all error flags */
    Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL =
            ((Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL)&(~LulRegERFLMask));
    #else
    /* Clear all error flags */
    Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL = CAN_RSCAN_ERFL_CLEAR;
    #endif
    /* Dummy read */
    (void)Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL;
  }
  #endif /* #ifdef CAN_CONTROLLER_ERROR_INTERRUPT_ON */
  #ifdef CAN_CONTROLLER_TX_INTERRUPT_ON
  /***************************************************************************
  * Check whether the Interrupt is CANm Transmit                             *
  ***************************************************************************/
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  if (0U == Can_GaaRegs[LucUnit].pCmn->unGTINTSTS.aaGTINTSTSb[LucCh])
  {
    /* No Action Required */
  }
  else
  #endif /* #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
  {
    #if ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON))
    #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
    /* Set Interrupt Source Flag check */
    LblIrqSrcFlag = CAN_TRUE;
    #endif
    Can_TxConfirmationProcessing(LucCtrlIndex);
    #endif  /* ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON)) */
  }
  #endif /* #ifdef CAN_CONTROLLER_TX_INTERRUPT_ON */
  #ifdef CAN_CONTROLLER_RX_INTERRUPT_ON
  /***************************************************************************
  * Check whether the Interrupt is CANm  TX/RX FIFO receive complete         *
  ***************************************************************************/
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LulIrqExist = 0U;
  /* Accumurate all interrupt request flags of all TxRxFIFO */
  LulTxRxFIFOIndex = (uint32)LucCh * CAN_RSCAN_TXRXFIFO_PER_CH;                                                         /* PRQA S 3384 # JV-01 */
  for (LulLoop = 0U; LulLoop < CAN_RSCAN_TXRXFIFO_PER_CH; LulLoop++)
  {
    /* if (CFCCd.CFRXIE && CFSTSd.CFRXIF), it means that irq exists */
    LulIrqExist = LulIrqExist | (                                                                                       /* PRQA S 0404 # JV-01 */
      CAN_RSCAN_CFRXIE_GET(                                                                                             /* PRQA S 3469 # JV-01 */
        Can_GaaRegs[LucUnit].pCmn->aaCFCC[LulTxRxFIFOIndex])
      &
      CAN_RSCAN_CFRXIF_GET(                                                                                             /* PRQA S 3469 # JV-01 */
        Can_GaaRegs[LucUnit].pCmn->aaCFSTS[LulTxRxFIFOIndex])
      );
    LulTxRxFIFOIndex++;                                                                                                 /* PRQA S 3383 # JV-01 */
  }
  /* If no irq exists from RS-CAN, this interrupt is wrong */
  if (0UL == LulIrqExist)
  {
    /* No Action Required */
  }
  else
  #endif /*#if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
  {
    /* Set Interrupt Source Flag check */
    #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
    LblIrqSrcFlag = CAN_TRUE;
    #endif
    #if (CAN_RX_COMFIFO == STD_ON)
    /* Invoke Can_RxProcessing internal function for receive processing */
    Can_RxProcessingTxRxFIFO(CAN_RXPROC_TXRXFIFO(LucCtrlIndex), CAN_CHECK_INT_RX, CAN_MAINFUNCTION_INSTANCE_0           /* PRQA S 3469 # JV-01 */
    #if(CAN_VIRTUAL_MACHINE_ENABLE == STD_ON)
    , CAN_VM_INVALID
    #endif
    );
    #endif
  }
  #endif /* #ifdef CAN_CONTROLLER_RX_INTERRUPT_ON */
  /***************************************************************************
  * Safety requirement for Consistency interrupt check                       *
  ***************************************************************************/
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  if (CAN_FALSE == LblIrqSrcFlag)
  {
    /* Report to DEM */
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  } /* else No action required */
  #endif
}
#endif /* if ((define CAN_CONTROLLER_TX_INTERRUPT_ON) || \
              (define CAN_CONTROLLER_RX_INTERRUPT_ON) || \
              (define CAN_CONTROLLER_ERROR_INTERRUPT_ON) */
/***********************************************************************************************************************
** Function Name         : CAN_CONTROLLER<n>_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is channel interrupt Service routines for the CAN
**                         hardware unit.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : None
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_076
** Reference ID          : CAN_DUD_ACT_210
***********************************************************************************************************************/
#if ((CAN_CONTROLLER0_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER0_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER0_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER0_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER0_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER0);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER1_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER1_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER1_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER1_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER1_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER1);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER2_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER2_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER2_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER2_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER2_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER2_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER2);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER3_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER3_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER3_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER3_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER3_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER3_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER3);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER4_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER4_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER4_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER4_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER4_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER4_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER4);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER5_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER5_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER5_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER5_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER5_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER5_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER5);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER6_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER6_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER6_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER6_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER6_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER6_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER6);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER7_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER7_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER7_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER7_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER7_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER7_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER7);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER8_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER8_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER8_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER8_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER8_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER8);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER9_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER9_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER9_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER9_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER9_CAT2_ISR)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9_ISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER9);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER10_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER10_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER10_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER10_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER10_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER10_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER10);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER11_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER11_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER11_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER11_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER11_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER11_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER11);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER12_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER12_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER12_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER12_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER12_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER12_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER12);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER13_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER13_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER13_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER13_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER13_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER13_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER13);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER14_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER14_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER14_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER14_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER14_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER14_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER14);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

#if ((CAN_CONTROLLER15_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER15_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER15_ERROR_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_CONTROLLER15_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER15_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER15_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
  Can_ChannelIsr(CAN_PHYIDX_CONTROLLER15);
}
#endif /* #if ((CAN_CONTROLLER_TX_INTERRUPT == STD_ON) || (CAN_CONTROLLER_RX_INTERRUPT == STD_ON) || \
     (CAN_CONTROLLER_ERROR_INTERRUPT == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : CAN_UNIT<n>_GLOBAL_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is Global Interrupt Service routines for the
**                         Can hardware unit.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_RxProcessing, CAN_DEM_REPORT_ERROR
**                         Can_IcomRxProcessing, CAN_ICOM_CALLOUT_FUNCTION
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_074, CAN_DUD_ACT_073
***********************************************************************************************************************/
#if (CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_UNIT0_GLOBAL_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_UNIT0_GLOBAL_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_UNIT0_GLOBAL_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
 Can_RxGlobalIsr(CAN_PHYIDX_UNIT0);
}
#endif /* #if ((CAN_RSCAN0_RXFIFO_INTERRUPT == STD_ON) || (CAN_PUBLIC_ICOM_SUPPORT == STD_ON)) */

#if (CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_UNIT1_GLOBAL_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_UNIT1_GLOBAL_CAT2_ISR)                                                                                          /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_UNIT1_GLOBAL_ISR(void)                                                        /* PRQA S 1503 # JV-01 */
#endif
{
 Can_RxGlobalIsr(CAN_PHYIDX_UNIT1);
}
#endif /* #if ((CAN_RSCAN1_RXFIFO_INTERRUPT == STD_ON) || (CAN_PUBLIC_ICOM_SUPPORT == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : Can_VMIsr
**
** Service ID            : Not Applicable
**
** Description           : Common function of each CAN_VMm_ISR handler
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucVMChannel : Channel number of Virtual Machine
**                         LucUnit: Hardware Unit number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Preconditions         : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GaaRegs, Can_GpConfig
**
** Functions Invoked     : Can_RxProcessing, Can_TxConfirmationProcessing, CAN_DEM_REPORT_ERROR
**
** Registers Used        : CFDVMISTSn
**
** Reference ID          : CAN_DUD_ACT_211
** Reference ID          : CAN_DUD_ACT_211_REG001, CAN_DUD_ACT_211_ERR001
***********************************************************************************************************************/
#if ((defined CAN_VM_RX_INTERRUPT_ON) || (defined CAN_VM_TX_INTERRUPT_ON))
STATIC FUNC(void, CAN_CODE_FAST) Can_VMIsr(CONST(uint8, AUTOMATIC) LucUnit, CONST(uint8, AUTOMATIC) LucVMChannel)
{
  VAR(uint32, AUTOMATIC) LulVMISTSn;
  VAR(uint8, AUTOMATIC) LucController;
  VAR(uint8, AUTOMATIC) LucCtrlIndex;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIrqSrcFlag;
  #endif
  /* Read value from Global Virtual Machine Interrupt Status Register */
  LulVMISTSn = Can_GaaRegs[LucUnit].pCmn->aaVMISTSn[LucVMChannel];

  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LblIrqSrcFlag = CAN_FALSE;
  #endif
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpPCController;                                       /* PRQA S 3432 # JV-01 */

  LucController = (LucUnit * (uint8)CAN_MAX_NO_VM_CH) + LucVMChannel;
  /* Convert the physical Controller index to the config index */
  LucCtrlIndex = Can_GpConfig->pPhysicalControllerToIndex[LucController];
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  
  #ifdef CAN_VM_TX_INTERRUPT_ON
  /***************************************************************************
  * Check whether the Interrupt is CAN Transmit                              *
  ***************************************************************************/
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* If no irq exists from CFDVMISTSn, this interrupt is wrong */
  if ((CAN_VMISTS_TXQTXIF_MASK != (CAN_VMISTS_TXQTXIF_MASK & LulVMISTSn)) &&
      (CAN_VMISTS_CFTXINT_MASK != (CAN_VMISTS_CFTXINT_MASK & LulVMISTSn)) &&
      (CAN_VMISTS_THLIF_MASK  != (CAN_VMISTS_THLIF_MASK & LulVMISTSn)))
  {
    /* No Action Required */
  }
  else
  #endif /* End of #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
  {
    /* To check if b0 CFTXINT is true */
    /* Process the transmit confirmation for TxRx FIFO */
    /* To check if b2 TXQTXIF is true */
    /* Process the transmit confirmation for Tx Queue */
    /* Convert the Virtual Machine Channel to Physical channel */
    #if ((CAN_TX_BUFFER == STD_ON) || (CAN_TX_COMFIFO == STD_ON) || (CAN_TX_QUEUE == STD_ON))
    #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
    LblIrqSrcFlag = CAN_TRUE;
    #endif
    /* Processing Confirmation */
    Can_TxConfirmationProcessing(LucCtrlIndex);
  #endif
  }
  #endif /* End of #ifdef CAN_VM_TX_INTERRUPT_ON */

  #ifdef CAN_VM_RX_INTERRUPT_ON
  /***************************************************************************
  * Check whether the Interrupt is CAN Receive                               *
  ***************************************************************************/
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  /* If no irq exists from CFDVMISTSn, this interrupt is wrong */
  if ((CAN_VMISTS_RFIF_MASK != (CAN_VMISTS_RFIF_MASK & LulVMISTSn)) &&
      (CAN_VMISTS_CFRXINT_MASK != (CAN_VMISTS_CFRXINT_MASK & LulVMISTSn)))
  {
    /* No Action Required */
  }
  else
  #endif /* End of #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
  {
    /* To check if b8-RFIF CFDRFISTS.RFxIF is true */
    /* Process the receive data for Rx FIFO */
    if (CAN_VMISTS_RFIF_MASK == (CAN_VMISTS_RFIF_MASK & LulVMISTSn))
    {
      #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
      LblIrqSrcFlag = CAN_TRUE;
      #endif
      #if (CAN_RX_FIFO == STD_ON)
      /* Invoke Can_RxProcessing internal function for receive processing */
      Can_RxProcessingRxFIFO(CAN_RXPROC_RXFIFO(LucUnit), CAN_CHECK_INT_RX, CAN_MAINFUNCTION_INSTANCE_0 ,LucVMChannel);  /* PRQA S 3469 # JV-01 */ 
      #endif
    } /* else No action required */

    /* To check if b10-CFRXINT CFDRFISTS.CFRXINT is true */
    /* Process the receive data for TxRx FIFO */
    if (CAN_VMISTS_CFRXINT_MASK == (CAN_VMISTS_CFRXINT_MASK & LulVMISTSn))
    {
      #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
      LblIrqSrcFlag = CAN_TRUE;
      #endif
      #if (CAN_RX_COMFIFO == STD_ON)
      /* Invoke Can_RxProcessing internal function for receive processing */
      Can_RxProcessingTxRxFIFO(CAN_RXPROC_TXRXFIFO_ALL, CAN_CHECK_INT_RX, CAN_MAINFUNCTION_INSTANCE_0, LucVMChannel);
      #endif
    } /* else No action required */
  }
  #endif /* End of #ifdef CAN_VM_RX_INTERRUPT_ON */
  /***************************************************************************
  * Safety requirement for Consistency interrupt check                       *
  ***************************************************************************/
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  if (CAN_FALSE == LblIrqSrcFlag)
  {
    /* Report to DEM */
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  } /* else No action required */
  #endif
  if (0UL == (Can_GaaRegs[LucUnit].pCmn->aaVMISTSn[LucVMChannel] &
    (CAN_VMISTS_TXQTXIF_MASK | CAN_VMISTS_CFTXINT_MASK | 
    CAN_VMISTS_THLIF_MASK | CAN_VMISTS_CFRXINT_MASK |
    CAN_VMISTS_RFIF_MASK)))
  {
    GIC_ClearPendingIRQ(LpPCController->ulVMEicID);
  }
  
}
#endif

/***********************************************************************************************************************
** Function Name         : CAN_VMm_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is TX, RX Interrupt Service routines for the Can
**                         hardware unit.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_VMIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_071
***********************************************************************************************************************/
#if ((CAN_VM0_RX_INTERRUPT == STD_ON) || (CAN_VM0_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM0_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM0_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM0_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH0);
}
#endif

#if ((CAN_VM1_RX_INTERRUPT == STD_ON) || (CAN_VM1_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM1_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM1_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM1_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH1);
}
#endif

#if ((CAN_VM2_RX_INTERRUPT == STD_ON) || (CAN_VM2_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM2_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM2_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM2_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH2);
}
#endif

#if ((CAN_VM3_RX_INTERRUPT == STD_ON) || (CAN_VM3_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM3_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM3_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM3_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH3);
}
#endif

#if ((CAN_VM4_RX_INTERRUPT == STD_ON) || (CAN_VM4_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM4_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM4_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM4_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH4);
}
#endif

#if ((CAN_VM5_RX_INTERRUPT == STD_ON) || (CAN_VM5_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM5_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM5_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM5_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH5);
}
#endif

#if ((CAN_VM6_RX_INTERRUPT == STD_ON) || (CAN_VM6_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM6_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM6_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM6_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH6);
}
#endif

#if ((CAN_VM7_RX_INTERRUPT == STD_ON) || (CAN_VM7_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM7_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM7_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM7_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT0, CAN_VM_CH7);
}
#endif

#if ((CAN_VM8_RX_INTERRUPT == STD_ON) || (CAN_VM8_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM8_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM8_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM8_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH8);
}
#endif

#if ((CAN_VM9_RX_INTERRUPT == STD_ON) || (CAN_VM9_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM9_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM9_CAT2_ISR)                                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM9_ISR(void)                                                                 /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH9);
}
#endif

#if ((CAN_VM10_RX_INTERRUPT == STD_ON) || (CAN_VM10_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM10_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM10_CAT2_ISR)                                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM10_ISR(void)                                                                /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH10);
}
#endif

#if ((CAN_VM11_RX_INTERRUPT == STD_ON) || (CAN_VM11_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM11_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM11_CAT2_ISR)                                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM11_ISR(void)                                                                /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH11);
}
#endif

#if ((CAN_VM12_RX_INTERRUPT == STD_ON) || (CAN_VM12_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_CAN_VM12_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM12_CAT2_ISR)                                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM12_ISR(void)                                                                /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH12);
}
#endif

#if ((CAN_VM13_RX_INTERRUPT == STD_ON) || (CAN_VM13_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM13_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM13_CAT2_ISR)                                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM13_ISR(void)                                                                /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH13);
}
#endif

#if ((CAN_VM14_RX_INTERRUPT == STD_ON) || (CAN_VM14_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM14_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM14_CAT2_ISR)                                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM14_ISR(void)                                                                /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH14);
}
#endif

#if ((CAN_VM15_RX_INTERRUPT == STD_ON) || (CAN_VM15_TX_INTERRUPT == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined  (Os_CAN_VM15_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_VM15_CAT2_ISR)                                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else

_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_VM15_ISR(void)                                                                /* PRQA S 1503 # JV-01 */

#endif
{
  Can_VMIsr(CAN_PHYIDX_UNIT1, CAN_VM_CH15);
}
#endif
#endif 

/***********************************************************************************************************************
** Function Name         : Can_SubErrorIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each Can_ErrorIsr.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucCtrlIndex, LucUnit, LucCh
**
** InOut Parameters      : LulRegERFLMask
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : CanEnableSecurityEventReporting is configured as true
**
** Global Variables Used : Can_GpConfig, Can_GpPCController,
**                         Can_GaaRegs, Can_GaaCtrlState
**
** Functions Invoked     : CanIf_ControllerErrorStatePassive, CanIf_ErrorNotification
**
** Registers Used        : (CFD)CmSTS, (CFD)CmERFL
**
** Reference ID          : CAN_DUD_ACT_175
***********************************************************************************************************************/
#if defined (CAN_CONTROLLER_ERROR_INTERRUPT_ON) && (CAN_CHECK_SECURITY_EVENT_REPORTING == STD_ON)
STATIC FUNC(uint32, CAN_CODE_FAST) Can_SubErrorIsr(VAR(uint8, AUTOMATIC) LucCtrlIndex, VAR(uint8, AUTOMATIC) LucUnit, 
                                                   VAR(uint8, AUTOMATIC) LucCh, VAR(uint32, AUTOMATIC) LulRegERFLMask)
{
  VAR(uint16, AUTOMATIC) LusTxErrorCounter;
  VAR(uint16, AUTOMATIC) LusRxErrorCounter;
  VAR(uint8, AUTOMATIC) LucFormIndex;
  VAR(uint32, AUTOMATIC) LusCheckErrBit;
  VAR(uint8, AUTOMATIC) LucSubCtrlIndex;
  VAR(uint32, AUTOMATIC) LulSubRegERFLMask;
  
  const Can_ErrorType LaaErrorForm[CAN_RSCAN_NUM_OF_BUS_ERROR] = 
  {
    CAN_ERROR_OVERLOAD, 
    CAN_ERROR_BUS_LOCK,
    CAN_ERROR_ARBITRATION_LOST,
    CAN_ERROR_CHECK_STUFFING_FAILED,
    CAN_ERROR_CHECK_FORM_FAILED,
    CAN_ERROR_CHECK_ACK_FAILED,
    CAN_ERROR_CHECK_CRC_FAILED,
    CAN_ERROR_BIT_MONITORING1,
    CAN_ERROR_BIT_MONITORING0,
    CAN_ERROR_ACK_DELIMITER
  };
  
  LucSubCtrlIndex = LucCtrlIndex;
  LulSubRegERFLMask = LulRegERFLMask;
  LucFormIndex = 0U;

  LucSubCtrlIndex = LucSubCtrlIndex + (uint8)CAN_CONTROLLER_OFFSET;                                                     /* PRQA S 2985 # JV-01 */

  /* Check if Error Passive flag is set or not*/
  if(0UL != (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL & CAN_RSCAN_EPF))
  {
    LusRxErrorCounter = (uint16)((Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS
                        & CAN_RSCAN_REC_MASK) >> CAN_RSCAN_REC_OFFSET);
    LusTxErrorCounter = (uint16)((Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulSTS
                        & CAN_RSCAN_TEC_MASK) >> CAN_RSCAN_TEC_OFFSET);
    CanIf_ControllerErrorStatePassive(LucSubCtrlIndex, LusRxErrorCounter, LusTxErrorCounter);
    LulSubRegERFLMask = LulSubRegERFLMask | CAN_RSCAN_EPF;
  }/*else No action required */
  
  /* Check if Bus Error Flag is set or not */
  LusCheckErrBit = Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL & CAN_RSCAN_BEF;
  LulSubRegERFLMask = LulSubRegERFLMask | LusCheckErrBit;

  while(CAN_RSCAN_NUM_OF_BUS_ERROR > LucFormIndex)
  {
    /* Check if error bit is set or not*/
    LusCheckErrBit = (Can_GaaRegs[LucUnit].pCmn->aaChReg[LucCh].ulERFL >> CAN_RSCAN_BIT_ERROR_POS(LucFormIndex))        /* PRQA S 3383 # JV-01 */
                                                                                        & CAN_RSCAN_CHECK_BIT_SET;

    if(0UL != LusCheckErrBit)
    {
      CanIf_ErrorNotification(LucSubCtrlIndex, LaaErrorForm[LucFormIndex]);
      /* Mask Error bit to clear error flag */
      LulSubRegERFLMask = LulSubRegERFLMask | (LusCheckErrBit << CAN_RSCAN_BIT_ERROR_POS(LucFormIndex));                /* PRQA S 3383 # JV-01 */
    }
    LucFormIndex++;  
  }
  /* Mask Error Warning Flag and Bus-Off Recovery Flag */ 
  LulSubRegERFLMask = LulSubRegERFLMask | (CAN_RSCAN_EWF | CAN_RSCAN_BORF);
  return (LulSubRegERFLMask);
}
#endif

#if (CAN_ENABLE_DMA_MODE == STD_ON)
/***********************************************************************************************************************
** Function Name         : Can_DMAIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each DMA ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant 
**
** Input Parameters      : LucDmaUnit, LucImfuGrpId
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Can_GpConfig, Can_GpHohConfig, Can_GpDMAToHohIndex, Can_GaaPayloadFromDLCTable                         
**
** Functions Invoked     : CanIf_RxIndication
**
** Registers Used        : PDMAjDCSTCn, PDMAjDCENn
**
** Reference ID          : CAN_DUD_ACT_195
** Reference ID          : CAN_DUD_ACT_195_REG001, CAN_DUD_ACT_195_GBL002
** Reference ID          : CAN_DUD_ACT_195_ERR001, CAN_DUD_ACT_195_REG002
** Reference ID          : CAN_DUD_ACT_195_GBL001, CAN_DUD_ACT_195_GBL003
***********************************************************************************************************************/
#ifdef CAN_DMA_FUNC_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_DmaIsr(CONST(uint8, AUTOMATIC) LucDmaUnit,                                         /* PRQA S 3006 # JV-01 */
                                 CONST(uint8, AUTOMATIC) LucGroupChannel)
{
  VAR(uint32, AUTOMATIC) LulHohIndex;
  VAR(uint8, AUTOMATIC) LucPhyDMAIdx;
  VAR(uint8, AUTOMATIC) LucPhyDMAMergeIdx;
  P2CONST(Can_HohConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpHoh;
  P2CONST(uint32, AUTOMATIC, CAN_VAR_NO_INIT) LpDataReg; 
  P2CONST(Can_DmaConfigType, AUTOMATIC, CAN_CONFIG_DATA) LpDmaConfig;
  P2CONST(uint32, AUTOMATIC, CAN_CONFIG_DATA) LpGaaCanDMASdu;
  VAR(uint32, AUTOMATIC) LulMessageDlc;
  VAR(uint32, AUTOMATIC) LulFDSts;
  VAR(uint32, AUTOMATIC) LulIDRegValue;
  Can_HwType LstMailbox;
  PduInfoType LstPduInfo;
  boolean LblCalloutOK;
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  VAR(boolean, AUTOMATIC) LblIsConsistency;
  LblIsConsistency = CAN_FALSE;
  #endif /* #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */

  LblCalloutOK = CAN_TRUE;
  /* Get the started the Physical Hw Unit */
  LucPhyDMAIdx = (uint8)((uint8)(LucGroupChannel % 2U) + (uint8)(LucDmaUnit * 8U));                         /* PRQA S 3383 # JV-01 */

  /* Expected replace "4" to CAN_MAX_DEVICE_HW = Max unit of each devcie */
  for (LucPhyDMAMergeIdx = CAN_ZERO; LucPhyDMAMergeIdx < CAN_FOUR; LucPhyDMAMergeIdx++)
  {
    /* Get the index of LucPhyDMAIdx in the config */
    LulHohIndex = Can_GpDMAToHohIndex[LucPhyDMAIdx];
    /* Check if HW Unit is configured or not */
    if (0xFFU != LulHohIndex)
    {
      /* Update struct of DMA */
      LpHoh = &Can_GpHohConfig[LulHohIndex];
      LpDmaConfig = LpHoh->pDMAConfig;
      #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
      if (0U != NVIC_GetActive(LpDmaConfig->enDMAInterruptID))                                                          /* PRQA S 3416 # JV-01 */
      #endif
      {
        /* Check bit PIFF[3:0] - IMFUPFj IMFU Pulse Status Register */
        if (((*(LpDmaConfig->pIMFU) & (0x01UL << (uint32)LucPhyDMAMergeIdx)) == (0x01UL << (uint32)LucPhyDMAMergeIdx))
         &&  (CAN_DMA_TC == (LpDmaConfig->pDmaRegs->ulPDMAjDCSTn & CAN_DMA_TC)))
        {
          /* Clear IMFU Pulse */
          SetIORegSyncpDummyRead(32, &(LpDmaConfig->pIMFU[2]), (0x01UL << (uint32)LucPhyDMAMergeIdx));                  /* PRQA S 3464, 1006 # JV-01, JV-01 */

          #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
          LblIsConsistency = CAN_TRUE;
          #endif /* #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
          /* Clear error and transfer complete flag status */
          LpDmaConfig->pDmaRegs->ulPDMAjDCSTCn = (uint32)(CAN_DMA_ERC | CAN_DMA_TCC);
          /* Get Rx array address */
          LpGaaCanDMASdu = LpDmaConfig->pGaaCanDMASdu;
          /* Get status and data register address accroding to each buffer mode */
          LulFDSts = LpGaaCanDMASdu[2];
          LulIDRegValue = LpGaaCanDMASdu[0];
          LulMessageDlc = LpGaaCanDMASdu[1];
          LpDataReg = &(LpGaaCanDMASdu[3]);

          /* Convert DLC value to actual byte length */
          LulMessageDlc = (uint32)Can_GaaPayloadFromDLCTable[CAN_RSCAN_XXDLC_GET(LulMessageDlc)];
          /* If this is CANFD message, set FD flag */
          #if (CAN_RSCANFD_CONFIGURED == STD_ON)
          if (0UL != (LulFDSts & CAN_RSCAN_XXFDF))
          {
          LstMailbox.CanId = CAN_FD_FRAME_FORMAT;
          }
          else
          #endif
          {
          LstMailbox.CanId = 0U;
          }

          /* Extracting extended can id and storing it */
          if (0UL != (LulIDRegValue & CAN_RSCAN_IDE))
          {
            LstMailbox.CanId =
            LstMailbox.CanId | (Can_IdType)((LulIDRegValue & (uint32)CAN_ID_TYPE_IDMASK) | (uint32)CAN_EXTENDED_FORMAT);
          }
          else
          {
            LstMailbox.CanId = LstMailbox.CanId | (Can_IdType)(LulIDRegValue & (uint32)CAN_ID_TYPE_IDMASK);
          }

          /* This is the second redundant path function provided for legacy
          * safety relevant ECUs */
          /* CanObjectId is uint16 but 1st param of call-out func is uint8. */
          if(NULL_PTR != Can_GpConfig->pLpduCalloutReceiveFunction)                                                     /* PRQA S 3416 # JV-01 */
          {
            LblCalloutOK = Can_GpConfig->pLpduCalloutReceiveFunction(LpHoh->usHohId,
              LstMailbox.CanId, (uint8)LulMessageDlc, (P2CONST(uint8, AUTOMATIC, CAN_CONFIG_DATA)) LpDataReg);          /* PRQA S 0751 # JV-01 */
          }/* Else no action required */
          if (CAN_FALSE == LblCalloutOK)
          {
            /* If callout function returns false, nothing to do */
          }
          else
          {
            LstMailbox.Hoh = (Can_HwHandleType)LpHoh->usHohId;
            LstMailbox.ControllerId = (uint8)(LpHoh->ucController + CAN_CONTROLLER_OFFSET);                             /* PRQA S 2985, 3383 # JV-01, JV-01 */
            LstPduInfo.SduDataPtr = (P2VAR(uint8, AUTOMATIC, CAN_CONFIG_DATA)) LpDataReg;                               /* PRQA S 0751, 3432, 0311 # JV-01, JV-01, JV-01 */
            LstPduInfo.SduLength = (PduLengthType)LulMessageDlc;

            /* Invoke CanIf_RxIndication call-back function to give
            receive indication */
            CanIf_RxIndication(&LstMailbox, &LstPduInfo);                                                               /* PRQA S 2976 # JV-01 */
          }
          /* Re enable DMA for Rx path */
          LpDmaConfig->pDmaRegs->ulPDMAjDCENn = CAN_DMA_DTE;
        } /* else No action required */

        if ((*(LpDmaConfig->pIMFU)) == 0U)
        {
          /* Clear interrupt flag */
          NVIC_ClearPendingIRQ(LpDmaConfig->enDMAInterruptID);
        }  /* else No action required */
      } /* else No action required */
    } /* else No action required */
    LucPhyDMAIdx = (uint8)(LucPhyDMAIdx + 2U);                                                                          /* PRQA S 3383 # JV-01 */
  }
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  if (CAN_FALSE == LblIsConsistency)
  { 
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
  } /* else No action required */
  #endif /* #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON) */
}
#endif // CAN_DMA_FUNC_INTERRUPT_ON

/***********************************************************************************************************************
** Function Name         : CAN_DMAm_nnnn_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is DMA Interrupt Service routines for the DMA channel
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_DmaIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_197
** Reference ID          : CAN_DUD_ACT_198
***********************************************************************************************************************/
#if (CAN_DMA0_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA0_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA0_0246_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA0_0246_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x00U, 0x00U);
}
#endif /* End of (CAN_DMA0_0246_ISR_API == STD_ON) */

#if (CAN_DMA0_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA0_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA0_1357_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA0_1357_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x00U, 0x01U);
}
#endif /* End of (CAN_DMA0_1357_ISR_API == STD_ON) */

#if (CAN_DMA1_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA1_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA1_0246_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA1_0246_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x01U, 0x00U);
}
#endif /* End of (CAN_DMA1_0246_ISR_API == STD_ON) */

#if (CAN_DMA1_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA1_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA1_1357_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA1_1357_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x01U, 0x01U);
}
#endif /* End of (CAN_DMA1_1357_ISR_API == STD_ON) */


#if (CAN_DMA2_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA2_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA2_0246_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA2_0246_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x02U, 0x00U);
}
#endif /* End of (CAN_DMA2_0246_ISR_API == STD_ON) */

#if (CAN_DMA2_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA2_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA2_1357_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA2_1357_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x02U, 0x01U);
}
#endif /* End of (CAN_DMA2_1357_ISR_API == STD_ON) */

#if (CAN_DMA3_0246_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA3_0246_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA3_0246_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA3_0246_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x03U, 0x00U);
}
#endif /* End of (CAN_DMA3_0246_ISR_API == STD_ON) */

#if (CAN_DMA3_1357_FUNC_ISR == STD_ON)
/* Defines the CAT2interrupt mapping */
#if defined(Os_CAN_DMA3_1357_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_DMA3_1357_CAT2_ISR)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_DMA3_1357_ISR(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Can_DmaIsr(0x03U, 0x01U);
}
#endif /* End of (CAN_DMA3_1357_ISR_API == STD_ON) */

#endif /*(CAN_ENABLE_DMA_MODE == STD_ON)*/

#if (CAN_WAKEUP_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Can_WakeupIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each WAKEUP_ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different HW, Non-Reentrant for same HW
**
** Input Parameters      : LucController
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index must be guaranteed by
**                         the upper layer.
**
** Global Variables Used : Can_GpConfig, Can_GpPCController,
**                         Can_GaaCtrlState
**
** Functions Invoked     : EcuM_CheckWakeup(), Can_WakeupMode(), CAN_DEM_REPORT_ERROR
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_031
** Reference ID          : CAN_DUD_ACT_031_CRT001, CAN_DUD_ACT_031_CRT002,
** Reference ID          : CAN_DUD_ACT_031_ERR001, CAN_DUD_ACT_031_GBL001,
** Reference ID          : CAN_DUD_ACT_031_GBL002, CAN_DUD_ACT_031_REG001,
** Reference ID          : CAN_DUD_ACT_031_REG002
***********************************************************************************************************************/
#ifdef CAN_CONTROLLER_WAKEUP_INTERRUPT_ON
STATIC FUNC(void, CAN_CODE_FAST) Can_WakeupIsr(CONST(uint8, AUTOMATIC) LucController, 
                                               Can_ControllerType LenControllerType)
{
  P2CONST(Can_ControllerPCConfigType, AUTOMATIC, CAN_APPL_DATA) LpPCController;                                         /* PRQA S 3432 # JV-01 */
  VAR(uint32, AUTOMATIC) LucCtrlIndex;
  VAR(boolean, AUTOMATIC) LblCheckWakeupRequired;

  /* Convert the physical Controller index to the config index */
  #if (CAN_CANXL_SUPPORTED == STD_ON)
  if(CAN_XL == LenControllerType)
  {
    LucCtrlIndex = Can_GpConfig->pCanXLPhysicalControllerToIndex[LucController];
  }
  else
  #else
  (void) LenControllerType;
  #endif
  {
    LucCtrlIndex = Can_GpConfig->pPhysicalControllerToIndex[LucController];
  }
  /* Getting the pointer to pre-compile controller structure*/
  LpPCController = &Can_GpPCController[LucCtrlIndex];
  #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_ON)
  /* If the interrupt is masked, this interrupt is wrong */
  if ((NULL_PTR == LpPCController->pICWakeup) ||
      (0U == NVIC_GetActive(LpPCController->pICWakeup->enInterruptID)))                                                 /* PRQA S 3415, 3416 # JV-01, JV-01 */
  #else
  /* If the interrupt is disabled, this interrupt is wrong */
  if ((0UL == LpPCController->ulWakeUpEicID) ||
      (0U == GIC_GetEnableIRQ(LpPCController->ulWakeUpEicID)))                                                          /* PRQA S 3415, 3416 # JV-01, JV-01 */
  #endif
  {
    #if (CAN_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
    CAN_DEM_REPORT_ERROR(CAN_E_INT_INCONSISTENT, DEM_EVENT_STATUS_FAILED);
    #endif
  }
  else
  #endif
  {
    /* Critical section is required to avoid the conflict with
       Can_EnableControllerInterrupt and Can_SetControllerMode */
    CAN_ENTER_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);
    /*Disabling the interrupt*/
    #if (CAN_INTERRUPT_NVIC_SUPPORT == STD_OFF)
    GIC_DisableIRQ(LpPCController->ulWakeUpEicID);
    #else
    Can_InterruptProcessing(LpPCController->pICWakeup, CAN_FALSE);
    #ifdef CAN_FILTER_CONTROL_SUPPORT
    if (NULL_PTR != LpPCController->pFCLAReg)
    {
      /* Clear the filter control register to reset value */
      *LpPCController->pFCLAReg = CAN_RSCAN_FCLA_DISABLE;
    } /* else No action required */
    #endif
    #endif
    /* Confirm that state transition is not on-going by Can_SetControllerMode */
    if ((CAN_COMMON_STATE_SLEEP == Can_GaaCtrlState[LucCtrlIndex].enMode) &&
        (CAN_NO_PENDING_TRANSITION == Can_GaaCtrlState[LucCtrlIndex].enSubState))
    {
      /* The state transition takes a long time,
         the subsequent operation will be done in Can_MainFunction_Mode */
      Can_GaaCtrlState[LucCtrlIndex].enSubState = CAN_PENDING_WAKEUP_REQUESTED; 
      /* Store the wakeup event */
      Can_GaaCtrlState[LucCtrlIndex].blWakeupEventOccurred = CAN_TRUE;
      Can_GaaCtrlState[LucCtrlIndex].blWakeupByHW = CAN_TRUE;
      LblCheckWakeupRequired = CAN_TRUE;
    }
    else
    {
      /* If the state transition is already on-going, nothing to do */
      LblCheckWakeupRequired = CAN_FALSE;
    }
    CAN_EXIT_CRITICAL_SECTION(CAN_INTERRUPT_CONTROL_PROTECTION_GLOBAL);

    if (CAN_TRUE == LblCheckWakeupRequired)
    {
      Can_WakeupMode((uint8)LucCtrlIndex);
      /* Invoke EcuM_CheckWakeup call-back function to give wakeup */
      /* notification */
      EcuM_CheckWakeup((EcuM_WakeupSourceType)(CAN_ONE << LpPCController->ucWakeupSourceId));
    } /* else No action required */
  }
}
#endif /* (CAN_CONTROLLERn_WAKEUP_INTERRUPT == STD_ON) */

/***********************************************************************************************************************
** Function Name         : CAN_CONTROLLERn_WAKEUP_ISR
**
** Service ID            : Not Applicable
**
** Description           :This is WAKEUPx Interrupt Service routines for the Can
**                         hardware unit.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_WakeupIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_023
** Reference ID          : CAN_DUD_ACT_060
***********************************************************************************************************************/
#if (CAN_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER0_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER0_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER0_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER0, CAN_FD);
}
#endif

#if (CAN_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER1_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER1_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER1_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER1, CAN_FD);
}
#endif

#if (CAN_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER2_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER2_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER2_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER2, CAN_FD);
}
#endif

#if (CAN_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER3_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER3_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER3_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER3, CAN_FD);
}
#endif

#if (CAN_CONTROLLER4_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER4_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER4_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER4_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER4, CAN_FD);
}
#endif

#if (CAN_CONTROLLER5_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER5_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER5_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER5_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER5, CAN_FD);
}
#endif

#if (CAN_CONTROLLER6_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER6_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER6_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER6_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER6, CAN_FD);
}
#endif

#if (CAN_CONTROLLER7_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER7_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER7_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER7_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER7, CAN_FD);
}
#endif

#if (CAN_CONTROLLER8_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER8_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER8_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER8_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER8, CAN_FD);
}
#endif

#if (CAN_CONTROLLER9_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER9_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER9_WAKEUP_CAT2_ISR)                                                                                    /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER9_WAKEUP_ISR(void)                                                  /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER9, CAN_FD);
}
#endif

#if (CAN_CONTROLLER10_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER10_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER10_WAKEUP_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER10_WAKEUP_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER10, CAN_FD);
}
#endif

#if (CAN_CONTROLLER11_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER11_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER11_WAKEUP_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER11_WAKEUP_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER11, CAN_FD);
}
#endif

#if (CAN_CONTROLLER12_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER12_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER12_WAKEUP_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER12_WAKEUP_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER12, CAN_FD);
}
#endif

#if (CAN_CONTROLLER13_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER13_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER13_WAKEUP_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER13_WAKEUP_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER13, CAN_FD);
}
#endif

#if (CAN_CONTROLLER14_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER14_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER14_WAKEUP_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER14_WAKEUP_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER14, CAN_FD);
}
#endif

#if (CAN_CONTROLLER15_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CAN_CONTROLLER15_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CAN_CONTROLLER15_WAKEUP_CAT2_ISR)                                                                                   /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CAN_CONTROLLER15_WAKEUP_ISR(void)                                                 /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER15, CAN_FD);
}
#endif


#if (CAN_CANXL_SUPPORTED == STD_ON)
/***********************************************************************************************************************
** Function Name         : CANXL_CONTROLLERn_WAKEUP_ISR
**
** Service ID            : Not Applicable
**
** Description           : This is WAKEUPx Interrupt Service routines for the CanXL
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Functions Invoked     : Can_WakeupIsr
**
** Registers Used        : None
**
** Reference ID          : CAN_DUD_ACT_205
** Reference ID          : CAN_DUD_ACT_204
***********************************************************************************************************************/
#if (CANXL_CONTROLLER0_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER0_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CANXL_CONTROLLER0_WAKEUP_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER0_WAKEUP_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER0, CAN_XL);
}
#endif

#if (CANXL_CONTROLLER1_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER1_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CANXL_CONTROLLER1_WAKEUP_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER1_WAKEUP_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER1 ,CAN_XL);
}
#endif

#if (CANXL_CONTROLLER2_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER2_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CANXL_CONTROLLER2_WAKEUP_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER2_WAKEUP_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER2 ,CAN_XL);
}
#endif

#if (CANXL_CONTROLLER3_WAKEUP_INTERRUPT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined(Os_CANXL_CONTROLLER3_WAKEUP_CAT2_ISR) || (CAN_ISR_CATEGORY_2 == STD_ON)
ISR(CANXL_CONTROLLER3_WAKEUP_CAT2_ISR)                                                                                  /* PRQA S 1503, 3408 # JV-01, JV-01 */
/* Defines the CAT1 interrupt mapping */
#else
_INTERRUPT_ FUNC(void, CAN_CODE_FAST) CANXL_CONTROLLER3_WAKEUP_ISR(void)                                                /* PRQA S 1503 # JV-01 */
#endif
{
  Can_WakeupIsr(CAN_PHYIDX_CONTROLLER3 ,CAN_XL);
}
#endif
#endif /* CAN_CANXL_SUPPORTED */

#endif /* (CAN_WAKEUP_SUPPORT == STD_ON) */

#define CAN_STOP_SEC_CODE_FAST
#include "Can_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
