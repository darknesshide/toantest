/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.23.0
* Description  : This file contains API function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_EthSwtCont_api.h"
#include "CDD_EthSwtCont_init.h"
#include "CDD_EthSwtCont_hwrout.h"
#include "CDD_EthSwtCont_common.h"
#include "CDD_EthSwtCont_stat.h"
#include "CDD_EthSwtCont_hwsec.h"
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define ETHSWTCONT_START_SEC_VAR_INIT_8
#include "EthSwtCont_MemMap.h"

static VAR(uint8, ETHSWTCONT_VAR_INIT) EthSwtCont_GucStatStatus = ETHSWTCONT_STS_STOP;

static VAR(uint8, ETHSWTCONT_VAR_INIT) EthSwtCont_GucSettingStatFlag = ETHSWTCONT_FLAG_CLR;

VAR(uint8, ETHSWTCONT_VAR_INIT) EthSwtCont_GucInitStatus = ETHSWTCONT_STS_UNINIT;

#define ETHSWTCONT_STOP_SEC_VAR_INIT_8
#include "EthSwtCont_MemMap.h"

#define ETHSWTCONT_START_SEC_PUBLIC_CODE
#include "EthSwtCont_MemMap.h"

/*******************************************************************************
Private global variables and functions
*******************************************************************************/

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_001]:[Gen5GW_EthSwtCont_UD_01_001]
* Function Name: R_EthSwtCont_Init
* Description  : Ethernet Switch Control SW Initialization.
* Arguments    : pConfig -
*                    Initialization Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_Init(const R_EthSwtCont_CfgType *pConfig)
{
    uint8 LucRetVal;
    if (NULL_PTR != pConfig)
    {
        LucRetVal = EthSwtCont_Init(pConfig);
        if ((uint32)E_OK == LucRetVal)
        {
            EthSwtCont_GucInitStatus = ETHSWTCONT_STS_INIT;
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_PARAM_POINTER);
        #endif
        LucRetVal = E_NOT_OK;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_002]:[Gen5GW_EthSwtCont_UD_01_002]
* Function Name: R_EthSwtCont_UpdateRoutTbl
* Description  : Update Routing Table in Ethernet Switch.
* Arguments    : pConfig -
*                    Configuration for update
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_UpdateRoutTbl(const R_EthSwtCont_CfgType *pConfig)
{
    uint8 LucRetVal;

    /* Initialized state check */
    if ((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus)
    {
        if (NULL_PTR != pConfig)
        {
            LucRetVal = EthSwtCont_UpdateRoutTbl(pConfig);
            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                           R_ETHSWTCONT_UPDATEROUTTBL_SID, ETHSWTCONT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Uninitialized Error */
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                               R_ETHSWTCONT_UPDATEROUTTBL_SID, ETHSWTCONT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_003]:[Gen5GW_EthSwtCont_UD_01_003]
* Function Name: R_EthSwtCont_MainFunction
* Description  : Statistical main function API.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_MainFunction(void)
{
    if (((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus) &&
        ((uint32)ETHSWTCONT_STS_START == (uint32)EthSwtCont_GucStatStatus) &&
        ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GucSettingStatFlag))
    {
        EthSwtCont_StatMain();
    }
    else
    {
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                 R_ETHSWTCONT_MAINFUNCTION_SID, ETHSWTCONT_E_UNINIT);
        #endif
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_004]:[Gen5GW_EthSwtCont_UD_01_004]
* Function Name: R_EthSwtCont_SetStatCfg
* Description  : Set Statistical function config API.
* Arguments    : pStatConfig -
*                    Configuration for Statistical function
*                pStatCbFunc -
*                    Statistical call-back function pointer
*                pStatNotifyCbFunc -
*                    Notification call-back function pointer
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_SetStatCfg(const R_EthSwtCont_StatCfgType *pStatConfig,
                            R_EthSwtCont_StatFuncPtrType pStatCbFunc, R_EthSwtCont_NotifyFuncPtrType pStatNotifyCbFunc)
{
    uint8 LucRetVal;

    /* Initialized state check */
    if (((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus) &&
        ((uint32)ETHSWTCONT_STS_STOP == (uint32)EthSwtCont_GucStatStatus))
    {
        if ((NULL_PTR != pStatConfig) &&
            (NULL_PTR != pStatCbFunc)  &&
            (NULL_PTR != pStatNotifyCbFunc))
        {
            LucRetVal = EthSwtCont_SetStatCfg(pStatConfig, pStatCbFunc, pStatNotifyCbFunc);
            if ((uint32)E_OK == LucRetVal)
            {
                EthSwtCont_GucSettingStatFlag = ETHSWTCONT_FLAG_SET;
            }
            else
            {
                 /* Do nothing */
            }
        }
        else
        {
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                              R_ETHSWTCONT_SETSTATCFG_SID, ETHSWTCONT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Uninitialized Error */
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                              R_ETHSWTCONT_SETSTATCFG_SID, ETHSWTCONT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_005]:[Gen5GW_EthSwtCont_UD_01_005]
* Function Name: R_EthSwtCont_GetStatCfg
* Description  : Get Statistical function config API.
* Arguments    : pStatConfig -
*                    Configuration for Statistical function
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_GetStatCfg(R_EthSwtCont_StatCfgType *pStatConfig)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;
    /* Initialized state check */
    if (((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus) &&
        ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GucSettingStatFlag))
    {
        if (NULL_PTR != pStatConfig)
        {
            EthSwtCont_GetStatCfg(pStatConfig);
        }
        else
        {
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                          R_ETHSWTCONT_GETSTATCFG_SID, ETHSWTCONT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Uninitialized Error */
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                               R_ETHSWTCONT_GETSTATCFG_SID, ETHSWTCONT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_006]:[Gen5GW_EthSwtCont_UD_01_006]
* Function Name: R_EthSwtCont_StatStart
* Description  : Start Statistical function API.
* Arguments    : N/A
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_StatStart(void)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;
    /* Initialized state check */
    if (((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus) &&
        ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GucSettingStatFlag))
    {
        EthSwtCont_ClearStatAll();
        EthSwtCont_GucStatStatus = ETHSWTCONT_STS_START;
    }
    else
    {
        /* Uninitialized Error */
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_STATSTART_SID, ETHSWTCONT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_007]:[Gen5GW_EthSwtCont_UD_01_007]
* Function Name: R_EthSwtCont_StatEnd
* Description  : End Statistical function API.
* Arguments    : N/A
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_StatEnd(void)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;
    /* Initialized state check */
    if (((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus) &&
        ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GucSettingStatFlag))
    {
        EthSwtCont_GucStatStatus = ETHSWTCONT_STS_STOP;
    }
    else
    {
        /* Uninitialized Error */
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                      R_ETHSWTCONT_STATEND_SID, ETHSWTCONT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_01_008]:[Gen5GW_EthSwtCont_UD_01_008]
* Function Name: R_EthSwtCont_ClearStatAll
* Description  : Clear All Statistical information API.
* Arguments    : N/A
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_ClearStatAll(void)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;
    /* Initialized state check */
    if ((uint32)ETHSWTCONT_STS_INIT == (uint32)EthSwtCont_GucInitStatus)
    {
        EthSwtCont_ClearStatAll();
    }
    else
    {
        /* Uninitialized Error */
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                R_ETHSWTCONT_CLEARSTATALL_SID, ETHSWTCONT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_011]:[Gen5GW_EthSwtCont_UD_27_011]
* Function Name: R_EthSwtCont_SetSecureReg
* Description  : Set Security function.
* Arguments    : N/A
* Return Value : E_OK -
*                    Success
*                E_NOT_OK
*                    Unsuccess
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_SetSecureReg(const R_EthSwtCont_MFWDSecGeneralCfgType *pSecConfig)
{
    uint8 LucRetVal;

    if (NULL_PTR != pSecConfig)
        {
            LucRetVal = EthSwtCont_SetSecureReg(pSecConfig);
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_POINTER);
            #endif
        }

    return LucRetVal;
}

#define ETHSWTCONT_STOP_SEC_PUBLIC_CODE
#include "EthSwtCont_MemMap.h"

/***********************************************************************************************************************
**                      End of File                                                                                   **
***********************************************************************************************************************/
