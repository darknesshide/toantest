/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains the process to access registers used in the Ethernet TSN function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_EthSwtCont_hwtsn.h"
#include "CDD_EthSwtCont_regMFWD.h"
#include "CDD_EthSwtCont_common.h"
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "Dem.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define PSFP_GENTRY_N          16U
#define GATE_TIME_MAX          0x0FFFFFFFUL
#define MTR_ATS_THROTTLE_MODE  3U
#define FRM_TPL_W_MASK         0x3FFFFU
#define MTR_CIR_MAX            0xFFFFFU
#define MTR_EIR_MAX            0xFFFFFU

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/* Filter Set status in PSFP Filter */
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetMsdufilter(const R_EthSwtCont_MsduCfgType *pMsduConfig, const uint32 ulEntryNum);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckMsduCfg(const R_EthSwtCont_MsduCfgType *pMsduConfig, const uint32 ulEntryNum
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetGatefilter(const R_EthSwtCont_GateCfgType *pGateConfig, const uint32 ulEntryNum);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetGateEntry(const R_EthSwtCont_GateFCfgType *pGateConfig, const uint32 ulEntryIdx);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckGateCfg(const R_EthSwtCont_GateCfgType *pGateConfig, const uint32 ulEntryNum
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetMeterfilter(const R_EthSwtCont_MeterCfgType *pMeterConfig, const uint32 ulEntryNum);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckMeterCfg(const R_EthSwtCont_MeterCfgType *pMeterConfig, const uint32 ulEntryNum
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetGateRAM(void);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetFilterPriority(const R_EthSwtCont_FilterPrioType *pFilterPrioCfg);

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_050]:[Gen5GW_EthSwtCont_UD_10_050]
* Function Name: EthSwtCont_SetPsfpCfg
* Description  : R-Switch2 PSFP configuration setting
* Arguments    : pPsfpConfig -
*                    PSFP Configuration
* Return Value : E_OK
*                    Success
*                E_TIMEOUT -
*                    Timeout Error
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetPsfpCfg(const R_EthSwtCont_PsfpCfgType *pPsfpConfig)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    if (ETHSWTCONT_STS_UNINIT == EthSwtCont_GucInitStatus)
    {
        /* Gate RAM reset flow */
        LucRetVal = ResetGateRAM();
    }
    else
    {
        /* Skip Gate RAM reset flow */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        if (pPsfpConfig->ulMsduFilterNum > (uint32)NUM0)
        {
            /* MSDU filter i setting flow */
            SetMsdufilter(pPsfpConfig->pMsduCfg, pPsfpConfig->ulMsduFilterNum);
        }
        else
        {
            /* Skip MSDU filter i setting flow*/
        }

        if (pPsfpConfig->ulGateFilterNum > (uint32)NUM0)
        {
            /* Gate i setting flow */
            LucRetVal = SetGatefilter(pPsfpConfig->pGateCfg, pPsfpConfig->ulGateFilterNum);
        }
        else
        {
            /* Skip Gate i setting flow */
        }

        if ((uint32)E_OK == LucRetVal)
        {
            if (pPsfpConfig->ulMeterFilterNum > (uint32)NUM0)
            {
                /* Meter i setting flow */
                LucRetVal = SetMeterfilter(pPsfpConfig->pMeterCfg, pPsfpConfig->ulMeterFilterNum);
            }
            else
            {
                /* Skip Meter i setting flow */
            }
        }
        else
        {
            /* Do nothing */
        }
        
        if ((uint32)E_OK == LucRetVal)
        {
            /* Per port i and IPV j filtering setting flow */
            SetFilterPriority(pPsfpConfig->pFilterPrioCfg);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }
    
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_051]:[Gen5GW_EthSwtCont_UD_10_051]
* Function Name: EthSwtCont_CheckPsfpCfg
* Description  : R-Switch2 PSFP configuration check
* Arguments    : pPsfpConfig -
*                    PSFP Configuration
* Return Value : E_OK -
*                    Success
*                E_CFG_PARAM -
*                    Config NULL Error
*                E_CFG_MSDU
*                    MSDU Configuration Error
*                E_CFG_GATE
*                    Gate Configuration Error
*                E_CFG_METER
*                    Meter Configuration Error
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckPsfpCfg(const R_EthSwtCont_PsfpCfgType *pPsfpConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    /* NULL check for pPsfpConfig pointer member. Skip check if entry number is zero. */
    if ((((uint32)NUM0 == pPsfpConfig->ulMsduFilterNum) || (NULL_PTR != pPsfpConfig->pMsduCfg)) &&
        (((uint32)NUM0 == pPsfpConfig->ulGateFilterNum) || (NULL_PTR != pPsfpConfig->pGateCfg)) &&
        (((uint32)NUM0 == pPsfpConfig->ulMeterFilterNum) || (NULL_PTR != pPsfpConfig->pMeterCfg)))
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_PARAM_CONFIG);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        if (pPsfpConfig->ulMsduFilterNum > (uint32)NUM0)
        {
            LucRetVal = CheckMsduCfg(pPsfpConfig->pMsduCfg, pPsfpConfig->ulMsduFilterNum
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                , ucSID
            #endif
            );
        }
        else
        {
            /* Skip MSDU config check */
        }

        if ((uint32)E_OK == LucRetVal)
        {
            if (pPsfpConfig->ulGateFilterNum > (uint32)NUM0)
            {
                LucRetVal = CheckGateCfg(pPsfpConfig->pGateCfg, pPsfpConfig->ulGateFilterNum
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    , ucSID
                #endif
                );
            }
            else
            {
                /* Skip Gate config check */
            }

            if ((uint32)E_OK == LucRetVal)
            {
                if (pPsfpConfig->ulMeterFilterNum > (uint32)NUM0)
                {
                    LucRetVal = CheckMeterCfg(pPsfpConfig->pMeterCfg, pPsfpConfig->ulMeterFilterNum
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        , ucSID
                    #endif
                    );
                }
                else
                {
                    /* Skip Meter config check */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_052]:[Gen5GW_EthSwtCont_UD_10_052]
* Function Name: SetMsdufilter
* Description  : R-Switch2 MSDU Filter setting
* Arguments    : pMsduConfig -
*                    MSDU Filter Configuration
*                ulEntryNum -
*                    The Number of MSDU Filter Entry
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetMsdufilter(const R_EthSwtCont_MsduCfgType *pMsduConfig, const uint32 ulEntryNum)
{
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;

    for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
    {
        /* FWPMFGCi.MFMi and FWEIS2.PMFS[i] are set? */
        LulRegisterVal = (((uint32)pMsduConfig[LulEntryIdx].ucFilterMode << SHIFT_31BIT)|
                          (uint32)pMsduConfig[LulEntryIdx].usValue);
        EthSwtCont_GpMfwdReg->FWPMFGCi[LulEntryIdx] = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_054]:[Gen5GW_EthSwtCont_UD_10_054]
* Function Name: SetGatefilter
* Description  : R-Switch2 Gate Filter setting
* Arguments    : pGateConfig -
*                    Gate Filter Configuration
*                ulEntryNum -
*                    The Number of Gate Filter Entry
* Return Value : E_OK -
*                    Success
*                E_TIMEOUT -
*                    Timeout Error
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetGatefilter(const R_EthSwtCont_GateCfgType *pGateConfig, const uint32 ulEntryNum)
{
    uint8 LucRetVal;
    uint32 LulLoopCnt;
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;
    uint32 LulGateCfgAddr;
    uint32 LulAddEntryIdx;
    uint32 LulFilterEntryIdx;
    const R_EthSwtCont_GateGenCfgType *LpGateGenCfg;

    LucRetVal = E_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
    {
        LpGateGenCfg = pGateConfig[LulEntryIdx].pGateGenCfg;
        LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
        /* Read Gate i status */
        do
        {
            if (LulLoopCnt > (uint32)NUM0)
            {
                LulLoopCnt--;
            }
            else
            {
                /* Timeout */
                LucRetVal = E_NOT_OK;
                #ifdef ETHSWTCONT_E_TIMEOUT
                /* Report to DET */
                (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
                #endif
                break;
            }
            LulRegisterVal = ((EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC >> SHIFT_2BIT) & MASK_1BIT);
        } while (ETHSWTCONT_REG_SET == LulRegisterVal);

        if ((uint32)E_OK == LucRetVal)
        {
            /* Save Gate config address in j variable */
            LulGateCfgAddr = ((EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC >> SHIFT_16BIT) & MASK_8BIT);

            if (ETHSWTCONT_REG_SET != (EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC & MASK_1BIT))
            {
                /* Set initial gate state */
                LulRegisterVal = (((uint32)LpGateGenCfg->ucInitIpv << SHIFT_1BIT)|
                    (uint32)LpGateGenCfg->ucInitGateState);
                EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFIGSC = LulRegisterVal;
                /* Set jitter */
                LulRegisterVal = ((uint32)LpGateGenCfg->usJitter);
                EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFHCC = LulRegisterVal;
                /* Set Gate i modes */
                LulRegisterVal = (((uint32)LpGateGenCfg->ucIpvUpdateEnable << SHIFT_1BIT)|
                    (uint32)LpGateGenCfg->ucFilterMode);
                EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFGC = LulRegisterVal;
            }
            else
            {
                /* Do Nothing */
            }
            /* Set gate entry number */
            LulRegisterVal = ((uint32)LpGateGenCfg->ucEntryNum);
            EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFENC = LulRegisterVal;
            /* Set cycle start time */
            LulRegisterVal = LpGateGenCfg->ulCycleStartTime0;
            EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFCSTC0 = LulRegisterVal;
            LulRegisterVal = LpGateGenCfg->ulCycleStartTime1;
            EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFCSTC1 = LulRegisterVal;
            /* Set cycle time */
            LulRegisterVal = LpGateGenCfg->ulCycleTime;
            EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFCTC = LulRegisterVal;

            LulFilterEntryIdx = NUM0;
            for (LulAddEntryIdx = LulGateCfgAddr;
                LulAddEntryIdx < (LulGateCfgAddr + pGateConfig[LulEntryIdx].ulGateFilterEntryNum); LulAddEntryIdx++)
            {
                /* Gate entry j learn flow */
                LucRetVal = SetGateEntry(&pGateConfig[LulEntryIdx].pGateFilter[LulFilterEntryIdx], LulAddEntryIdx);
                if ((uint32)E_OK == LucRetVal)
                {
                    LulFilterEntryIdx++;
                }
                else
                {
                    break;
                }
            }
        }
        else
        {
            /* Do nothing */
        }

        if ((uint32)E_OK == LucRetVal)
        {
            if (ETHSWTCONT_REG_SET == ((EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC) & MASK_1BIT))
            {
                /* Apply Gate i settings */
                LulRegisterVal = EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC;
                /* Set FWPGFC GFCC bit to 1. FWPGFC GFE bit is 1. */
                LulRegisterVal = LulRegisterVal | (ETHSWTCONT_REG_SET << SHIFT_1BIT);
                EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC = LulRegisterVal;
            }
            else
            {
                LulRegisterVal = EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC;
                /* Set FWPGFC GFE bit to 1 */
                LulRegisterVal = LulRegisterVal | ETHSWTCONT_REG_SET;
                /* Set FWPGFC GFCC bit to 0 */
                LulRegisterVal = LulRegisterVal & (~(ETHSWTCONT_REG_SET << SHIFT_1BIT));
                EthSwtCont_GpMfwdReg->stFWPGi[LulEntryIdx].FWPGFC = LulRegisterVal;
            }
        }
        else
        {
            /* Do nothing */
        }

        if ((uint32)E_OK == LucRetVal)
        {
            /* Next Entry */
        }
        else
        {
            /* Exit Loop */
            break;
        }
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_055]:[Gen5GW_EthSwtCont_UD_10_055]
* Function Name: SetGateEntry
* Description  : R-Switch2 Gate Filter Entry setting
* Arguments    : pGateConfig -
*                    Gate Filter Configuration
*                ulEntryIdx -
*                    Gate Filter Entry Index
* Return Value : E_OK -
*                    Success
*                E_TIMEOUT -
*                    Timeout Error
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetGateEntry(const R_EthSwtCont_GateFCfgType *pGateConfig, const uint32 ulEntryIdx)
{
    uint8 LucRetVal;
    uint32 LulLoopCnt;
    uint32 LulRegisterVal;

    LucRetVal = E_OK;
    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;

    /* Set address to be learnt to i */
    EthSwtCont_GpMfwdReg->FWPGFGL0 = ulEntryIdx;
    /* Set entry to be learnt */
    LulRegisterVal = (((uint32)pGateConfig->ucIPV << SHIFT_29BIT) |
        ((uint32)pGateConfig->ucGateState << SHIFT_28BIT) |
        pGateConfig->ulTime);
    EthSwtCont_GpMfwdReg->FWPGFGL1 = LulRegisterVal;

    /* FWPGFGLR.GL == 0? */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = (EthSwtCont_GpMfwdReg->FWPGFGLR >> SHIFT_31BIT);
    } while (ETHSWTCONT_REG_CLR != LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_057]:[Gen5GW_EthSwtCont_UD_10_057]
* Function Name: SetMeterfilter
* Description  : R-Switch2 Meter Filter setting
* Arguments    : pMeterConfig -
*                    Meter Filter Configuration
*                ulEntryNum -
*                    The Number of Meter Filter Entry
* Return Value : E_OK -
*                    Success
*                E_TIMEOUT -
*                    Timeout Error
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetMeterfilter(const R_EthSwtCont_MeterCfgType *pMeterConfig, const uint32 ulEntryNum)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;
    uint32 LulLoopCnt;

    LucRetVal = E_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
    {
        /* Meter i disabling flow */
        EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTRFC = (uint32)NUM0;
        LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
        
        /* FWPMTRFMi.MTRARDNi == 0? */
        do
        {
            if (LulLoopCnt > (uint32)NUM0)
            {
                LulLoopCnt--;
            }
            else
            {
                /* Timeout */
                LucRetVal = E_NOT_OK;
                #ifdef ETHSWTCONT_E_TIMEOUT
                /* Report to DET */
                (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
                #endif
                break;
            }
            LulRegisterVal = (EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTRFM & MASK_5BIT);
        } while (ETHSWTCONT_REG_CLR != LulRegisterVal);

        /* Set green bucket CBS value */
        LulRegisterVal = (uint32)pMeterConfig[LulEntryIdx].ulCbs;
        EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTRCBSC = LulRegisterVal;
        /* Set green bucket CIR value */
        LulRegisterVal = (uint32)pMeterConfig[LulEntryIdx].ulCir;
        EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTRCIRC = LulRegisterVal;

        if (LulEntryIdx < (uint32)ETHSWTCONT_PSFP_DMTR_N)
        {
            /* Set yellow bucket EBS value */
            LulRegisterVal = (uint32)pMeterConfig[LulEntryIdx].ulEbs;
            EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTREBSC = LulRegisterVal;
            /* Set yellow bucket EIR value */
            LulRegisterVal = (uint32)pMeterConfig[LulEntryIdx].ulEir;
            EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTREIRC = LulRegisterVal;
        }
        else
        {
            /* Do nothing */
        }

        /* Set meter i modes */
        LulRegisterVal = (((uint32)pMeterConfig[LulEntryIdx].usColorMode << SHIFT_16BIT) |
            ((uint32)pMeterConfig[LulEntryIdx].ucCouplingFlag << SHIFT_4BIT) |
            ((uint32)pMeterConfig[LulEntryIdx].ucRedFrameDrop << SHIFT_3BIT) |
            ((uint32)pMeterConfig[LulEntryIdx].ucFilterMode << SHIFT_1BIT) |
            ((uint32)pMeterConfig[LulEntryIdx].ucFilterEnable));
        EthSwtCont_GpMfwdReg->stFWPMTRi[LulEntryIdx].FWPMTRFC = LulRegisterVal;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_053]:[Gen5GW_EthSwtCont_UD_10_053]
* Function Name: CheckMsduCfg
* Description  : Check MSDU configuration
* Arguments    : pMsduConfig -
*                    MSDU Configuration
*              : ulEntryNum -
*                    The number of MSDU filter Entry
* Return Value : E_OK -
*                    Success
*                E_CFG_MSDU -
*                    Config Error
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckMsduCfg(const R_EthSwtCont_MsduCfgType *pMsduConfig, const uint32 ulEntryNum
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;

    LucRetVal = E_OK;

    if (ulEntryNum <= ETHSWTCONT_PSFP_MSDU_NUM)
    {
        for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
        {
            /* MSDU Configuration check  */
            if ((uint32)pMsduConfig[LulEntryIdx].ucFilterMode <= ETHSWTCONT_REG_SET)
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_MSDU);
                #endif
                break;
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_MSDU);
        #endif
        
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_056]:[Gen5GW_EthSwtCont_UD_10_056]
* Function Name: CheckGateCfg
* Description  : Check Gate configuration
* Arguments    : pGateConfig -
*                    Gater Configuration
*              : ulEntryNum -
*                    The number of GATE filter Entry
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckGateCfg(const R_EthSwtCont_GateCfgType *pGateConfig, const uint32 ulEntryNum
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulGateFilterEntryIdx;
    const R_EthSwtCont_GateGenCfgType *LpGateGenCfg;

    LucRetVal = E_OK;

    if (ulEntryNum <= (uint32)ETHSWTCONT_PSFP_GATE_NUM)
    {
        for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
        {
            /* NULL check for pGateConfig pointer member */
            if ((NULL_PTR != pGateConfig[LulEntryIdx].pGateFilter) &&
                (NULL_PTR != pGateConfig[LulEntryIdx].pGateGenCfg))
            {
                LpGateGenCfg = pGateConfig[LulEntryIdx].pGateGenCfg;
                /* Gate Gen Configuration check  */
                if (((uint32)LpGateGenCfg->ucInitGateState <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpGateGenCfg->ucInitIpv < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                    ((uint32)LpGateGenCfg->ucIpvUpdateEnable <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpGateGenCfg->ucFilterMode <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpGateGenCfg->ucEntryNum < (uint32)PSFP_GENTRY_N) &&
                    ((uint32)pGateConfig[LulEntryIdx].ulGateFilterEntryNum <= (uint32)PSFP_GENTRY_N))
                {
                    /* Check passed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_GATE);
                    #endif
                }
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_PARAM_CONFIG);
                #endif
            }

            if ((uint32)E_OK == LucRetVal)
            {
                for (LulGateFilterEntryIdx = IDX_0;
                    LulGateFilterEntryIdx < pGateConfig[LulEntryIdx].ulGateFilterEntryNum; LulGateFilterEntryIdx++)
                {
                    /* Gate Filter Configuration check  */
                    if (((uint32)pGateConfig[LulEntryIdx].pGateFilter[LulGateFilterEntryIdx].ucGateState <=
                        ETHSWTCONT_REG_SET) &&
                       ((uint32)pGateConfig[LulEntryIdx].pGateFilter[LulGateFilterEntryIdx].ucIPV <
                        (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                       ((uint32)pGateConfig[LulEntryIdx].pGateFilter[LulGateFilterEntryIdx].ulTime <= GATE_TIME_MAX))
                    {
                        /* Check passed */
                    }
                    else
                    {
                        LucRetVal = E_NOT_OK;
                        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, 
                                                                                                ETHSWTCONT_E_CFG_GATE);
                        #endif
                        break;
                    }
                }
            }
            else
            {
                /* Do nothing */
            }

            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_GATE);
        #endif
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_058]:[Gen5GW_EthSwtCont_UD_10_058]
* Function Name: CheckMeterCfg
* Description  : Check Meter configuration
* Arguments    : pMeterConfig -
*                    Meter Configuration
*              : ulEntryNum -
*                    The number of Meter filter Entry
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckMeterCfg(const R_EthSwtCont_MeterCfgType *pMeterConfig, const uint32 ulEntryNum 
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;

    LucRetVal = E_OK;

    if (ulEntryNum <= (uint32)ETHSWTCONT_PSFP_MTR_NUM)
    {
        for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
        {
            /* Meter Configuration check */
            if (((uint32)pMeterConfig[LulEntryIdx].ucCouplingFlag <= ETHSWTCONT_REG_SET) &&
                ((uint32)pMeterConfig[LulEntryIdx].ucRedFrameDrop <= ETHSWTCONT_REG_SET) &&
                ((uint32)pMeterConfig[LulEntryIdx].ucFilterMode <= (uint32)MTR_ATS_THROTTLE_MODE) &&
                ((uint32)pMeterConfig[LulEntryIdx].ucFilterEnable <= ETHSWTCONT_REG_SET) &&
                ((uint32)pMeterConfig[LulEntryIdx].ulCbs <= (uint32)FRM_TPL_W_MASK) &&
                ((uint32)pMeterConfig[LulEntryIdx].ulCir <= (uint32)MTR_CIR_MAX) &&
                ((uint32)pMeterConfig[LulEntryIdx].ulEbs <= (uint32)FRM_TPL_W_MASK) &&
                ((uint32)pMeterConfig[LulEntryIdx].ulEir <= (uint32)MTR_EIR_MAX))
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_METER);
                #endif
                break;
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_METER);
        #endif
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_059]:[Gen5GW_EthSwtCont_UD_10_059]
* Function Name: ResetGateRAM
* Description  : Reset Gate RAM
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetGateRAM(void)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulLoopCnt;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    LucRetVal = E_OK;

    /* Gate RAM reset flow */
    EthSwtCont_GpMfwdReg->FWPGFRIM = ETHSWTCONT_REG_SET;

    /* Wait for Gate RAM reset is complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = ((EthSwtCont_GpMfwdReg->FWPGFRIM >> SHIFT_1BIT) & MASK_1BIT);
    } while (ETHSWTCONT_REG_CLR == LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_078]:[Gen5GW_EthSwtCont_UD_23_078]
* Function Name: SetFilterPriority
* Description  : Set filter priority
* Arguments    : pFilterPrioCfg -
*                    Filter Priority Configuration
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetFilterPriority(const R_EthSwtCont_FilterPrioType *pFilterPrioCfg)
{
    uint32 LulPort;
    uint32 LulPriority;
    uint32 LulRegisterVal;
    
    for (LulPort = IDX_0; LulPort < ETHSWTCONT_PORT_NUM; LulPort++)
    {
        for (LulPriority = IDX_0; LulPriority < ETHSWTCONT_FRAME_PRIORITY_NUM; LulPriority++)
        {
            LulRegisterVal = (((uint32)pFilterPrioCfg[LulPort].ucFilterPriority[LulPriority] << SHIFT_28BIT) |
                ((uint32)pFilterPrioCfg[LulPort].ucSecLv[LulPriority] << SHIFT_24BIT) |
                ((uint32)pFilterPrioCfg[LulPort].ucGateValid[LulPriority] << SHIFT_23BIT) |
                ((uint32)pFilterPrioCfg[LulPort].ucGateNo[LulPriority] << SHIFT_16BIT) |
                ((uint32)pFilterPrioCfg[LulPort].ucMsduValid[LulPriority] << SHIFT_15BIT) |
                ((uint32)pFilterPrioCfg[LulPort].ucMsduNo[LulPriority] << SHIFT_8BIT) |
                ((uint32)pFilterPrioCfg[LulPort].ucMeterValid[LulPriority] << SHIFT_7BIT) |
                (uint32)pFilterPrioCfg[LulPort].ucMeterNo[LulPriority]);
            EthSwtCont_GpMfwdReg->FWPIFPIij[LulPort][LulPriority] = LulRegisterVal;
        }
    }
}
#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/***********************************************************************************************************************
**                      End of File                                                                                   **
***********************************************************************************************************************/
