/***********************************************************************************************************************
* Copyright [2023-2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.27.0
* Description  : This file contains the process to access registers used in the Initialization function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_EthSwtCont_hwctl.h"
#include "CDD_EthSwtCont_regMFWD.h"
#include "CDD_EthSwtCont_regCOMA.h"
#include "CDD_EthSwtCont_reg.h"
#include "CDD_EthSwtCont_common.h"
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "Dem.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define RF_RANGESUM_MAX     255U
#define RF_RANGE_MAX        15U
#define UNITMODE_EXPAND     1U
#define UNITMODE_PRECISE    2U
#define FILTERMODE_OFFSET   0U
#define FILTERMODE_VLANTAG  1U
#define VLANMODE_NOVLAN     0U
#define VLANMODE_CTAG       1U
#define VLANMODE_SCTAG      2U
#define IPOFFSET_MAX        12U
/* Perfect Filter Max Num */
#define PFL_2BF_NUM         512U
#define PFL_3BF_NUM         128U
#define PFL_4BF_NUM         512U
#define PFL_RF_NUM          128U
#define PFL_CF_NUM          255U
#define PFL_TOTAL_NUM       (PFL_2BF_NUM + PFL_3BF_NUM + PFL_4BF_NUM + PFL_RF_NUM)
#define STREAM_ENTRY_NUM    255U
/* Routing Table Entry Max Num */
#define MAC_TBLENTRY_NUM        2048U
#define VLAN_TBLENTRY_NUM       4096U
#define L2L3UP_TBLENTRY_NUM     2048U
#define L2L3UP_REMAPRULE_NUM    32U
/* Bit shift definition */
#define SHIFT_BIT_IPVL      16U
#define SHIFT_BIT_IPUL      19U
#define SHIFT_BIT_EMEL      20U
#define SHIFT_BIT_CMEL      21U
/* Perfect Filter Offset value definition */
#define OFFSET_STAG_BYTE0   0U
#define OFFSET_CTAG_BYTE0   2U
#define OFFSET_CTAG_BYTE1   3U
/* Frame format vector mask */
#define FFV_MASK_PF         0x01
#define FFV_MASK_IPV4       0x0E
#define FFV_MASK_IPV4_NONE  0x02
#define FFV_MASK_IPV4_TCP   0x04
#define FFV_MASK_IPV4_UDP   0x08
#define FFV_MASK_IPV6       0x70
#define FFV_MASK_IPV6_NONE  0x10
#define FFV_MASK_IPV6_TCP   0x20
#define FFV_MASK_IPV6_UDP   0x40
#define FFV_MASK_L2         0x80

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define ETHSWTCONT_START_SEC_VAR_NO_INIT_8
#include "EthSwtCont_MemMap.h"
/* Ethernet Switch VLAN mode status */
VAR(uint8, ETHSWTCONT_VAR_NO_INIT) EthSwtCont_GucVlanMode;
static VAR(uint8, ETHSWTCONT_VAR_NO_INIT)  EthSwtCont_GaaFilterSetStatus[PFL_TOTAL_NUM];

#define ETHSWTCONT_STOP_SEC_VAR_NO_INIT_8
#include "EthSwtCont_MemMap.h"

#define ETHSWTCONT_START_SEC_VAR_INIT_UNSPECIFIED
#include "EthSwtCont_MemMap.h"
CONSTP2VAR(volatile EthSwtCont_MfwdRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpMfwdReg = (EthSwtCont_MfwdRegType *)ETHSWTCONT_MFWD_BASEADDR; 

static CONSTP2VAR(volatile EthSwtCont_ComaRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpComaReg = (EthSwtCont_ComaRegType *)ETHSWTCONT_COMA_BASEADDR;
static CONSTP2VAR(volatile EthSwtCont_GwcaRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpGwcaReg[ETHSWTCONT_PORT_GWCA_NUM] =
{
    (EthSwtCont_GwcaRegType *)ETHSWTCONT_GWCA0_BASEADDR,
    (EthSwtCont_GwcaRegType *)ETHSWTCONT_GWCA1_BASEADDR,
};
static CONSTP2VAR(volatile EthSwtCont_TsnaRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpTsnaReg[ETHSWTCONT_PORT_TSNA_NUM] =
{
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA0_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA1_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA2_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA3_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA4_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA5_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA6_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA7_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA8_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA9_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA10_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA11_BASEADDR,
    (EthSwtCont_TsnaRegType *)ETHSWTCONT_TSNA12_BASEADDR,
};
#define ETHSWTCONT_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "EthSwtCont_MemMap.h"

#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/* Register pointer */
/*******************************************************************************
Private global variables and functions
*******************************************************************************/
/* Filter Set status in Perfect Filter */
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL3RuleTbl(const R_EthSwtCont_L3CfgType *pL3Config);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetPerfectFilter(const R_EthSwtCont_PFCfgType *pPfConfig);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetCascadeFilter(const R_EthSwtCont_PFCfgType *pPfConfig, const uint32 ulEntryIdx);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetTwoByteFilter(const R_EthSwtCont_2BFCfgType *p2BFEntry, const uint32 ulEntryIdx);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetThreeByteFilter(const R_EthSwtCont_3BFCfgType *p3BFEntry, const uint32 ulEntryIdx);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetFourByteFilter(const R_EthSwtCont_4BFCfgType *p4BFEntry, const uint32 ulEntryIdx);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetRangeFilter(const R_EthSwtCont_RFCfgType *pRFEntry, const uint32 ulEntryIdx);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL3Tbl(const R_EthSwtCont_L3CfgType *pL3Config);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL3TblEntry(const R_EthSwtCont_L3TblCfgType *pL3TblEntry,
    const uint8 ucFrameFormat, const uint32 *aaStreamId);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckPerfectFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckCascadeFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig, const uint32 ulEntryIdx 
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckTwoByteFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckThreeByteFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckFourByteFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckRangeFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckPerfectFilterOffset(const uint8 ucFilter, const uint8 ucFilterMode, const uint8 ucOffset
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL2RuleTbl(const R_EthSwtCont_L2CfgType *pL2Config);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetMacTbl(const R_EthSwtCont_L2CfgType *pL2Config);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckMacTblCfg(const R_EthSwtCont_L2CfgType *pL2Config
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetVlanTbl(const R_EthSwtCont_L2CfgType *pL2Config);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckVlanTblCfg(const R_EthSwtCont_L2CfgType *pL2Config
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetStreamFilterSetting(const R_EthSwtCont_StreamGenCfgType *pStreamGenConfig);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckStreamFilterCfg(const R_EthSwtCont_StreamCfgType *pStreamConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckStreamFilterGenCfg(const R_EthSwtCont_StreamGenCfgType *pStreamGenConfig);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL2L3UpRuleTbl (const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL2L3UpTbl (const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetL2L3UpRemapTbl(const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckL2L3UpCfg(const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetL3Tbl(void);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetMacTbl(void);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetVlanTbl(void);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetL2L3UpTbl(void);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) GenerateStreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) GetIpv4StreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) GetIpv6StreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   GetL2StreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CalcHwHash(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
                                                                                                uint16 *usHashResult);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   SetPortBased(const R_EthSwtCont_PortBasedCfgType *pPortBasedConfig);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckPortBasedCfg(const R_EthSwtCont_PortBasedCfgType *pPortBasedConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) TransitGwcaMode(const uint8 ucGwcaIdx, const uint8 ucNextMode);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) TransitTsnaMode(const uint8 ucPortIdx, const uint8 ucNextMode);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   EnableAgentClock(const uint8 ucPortIdx);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   DisableAgentClock(const uint8 ucPortIdx);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   GetAgentClockStatus(const uint8 ucPortIdx, uint32 *pClockStatus);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE)   ResetEthSwt(void);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckMACLearnFail(const uint8 ucCheckLearnReg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckVLANLearnFail(const uint8 ucCheckLearnReg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckL3LearnFail(const uint8 ucCheckLearnReg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckL2L3LearnFail(const uint8 ucCheckLearnReg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckFrameFormatVec(const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_001]:[Gen5GW_EthSwtCont_UD_10_001]
* Function Name: EthSwtCont_InitMfwd
* Description  : R-Switch3 MFWD Initializatio
* Arguments    : pMfwdConfig -
*                    MFWD Configuration
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_InitMfwd(const R_EthSwtCont_MfwdCfgType *pMfwdConfig)
{
    uint32 LulRegisterVal;
    uint8 LucPortIdx;

    /* Set VLAN mode */
    LulRegisterVal = (((uint32)pMfwdConfig->ucFilteringPriorityMode << SHIFT_31BIT) |
        ((uint32)pMfwdConfig->ucL2UnknownFRPriority << SHIFT_20BIT) |
        ((uint32)pMfwdConfig->ucL3UnknownFRPriority << SHIFT_16BIT) |
        (uint32)pMfwdConfig->ucSVlanMode);
    EthSwtCont_GpMfwdReg->FWGC = LulRegisterVal;
    /* Set TPIDs */
    LulRegisterVal = (((uint32)pMfwdConfig->usSTagTPID << SHIFT_16BIT) | (uint32)pMfwdConfig->usCTagTPID);
    EthSwtCont_GpMfwdReg->FWTTC0 = LulRegisterVal;
    EthSwtCont_GpMfwdReg->FWTTC1 = (uint32)pMfwdConfig->usRTagTPID;
    /* Set CPU Exceptional Path */
    LulRegisterVal = (((uint32)pMfwdConfig->stCpuExPathCfg.ucSecLv << SHIFT_24BIT) |
        ((uint32)pMfwdConfig->stCpuExPathCfg.ucCpuSel << SHIFT_16BIT) |
        ((uint32)pMfwdConfig->stCpuExPathCfg.ucIpvVal << SHIFT_12BIT) |
        (uint32)pMfwdConfig->stCpuExPathCfg.ucCpuSubDest);
    EthSwtCont_GpMfwdReg->FWCEPTC = LulRegisterVal;
    /* Set CPU Exceptional Path Reason */
    EthSwtCont_GpMfwdReg->FWCEPRC0 = pMfwdConfig->stCpuExPathCfg.ulExceptFlag0;
    EthSwtCont_GpMfwdReg->FWCEPRC1 = pMfwdConfig->stCpuExPathCfg.ulExceptFlag1;
    EthSwtCont_GpMfwdReg->FWCEPRC2 = pMfwdConfig->stCpuExPathCfg.ulExceptFlag2;
    /* Set CPU Learning Path */
    LulRegisterVal = (((uint32)pMfwdConfig->stCpuLrnPathCfg.ucSecLv << SHIFT_24BIT) |
        ((uint32)pMfwdConfig->stCpuLrnPathCfg.ucCpuSel << SHIFT_16BIT) |
        ((uint32)pMfwdConfig->stCpuLrnPathCfg.ucIpvVal << SHIFT_12BIT) |
        (uint32)pMfwdConfig->stCpuLrnPathCfg.ucCpuSubDest);
    EthSwtCont_GpMfwdReg->FWCLPTC = LulRegisterVal;
    /* Set CPU Learning Path Reason */
    EthSwtCont_GpMfwdReg->FWCLPRC = pMfwdConfig->stCpuLrnPathCfg.ulLrnFlag;
    /* Set CPU Mirroring Path */
    LulRegisterVal = (((uint32)pMfwdConfig->stCpuMrrPathCfg.ucSecLv << SHIFT_24BIT) |
        ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucCpuSel << SHIFT_16BIT) |
        ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucIpvUpdate << SHIFT_15BIT) |
        ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucIpvVal << SHIFT_12BIT) |
        (uint32)pMfwdConfig->stCpuMrrPathCfg.ucCpuSubDest);
    EthSwtCont_GpMfwdReg->FWCMPTC = LulRegisterVal;

    LulRegisterVal = (((uint32)pMfwdConfig->stCpuMrrPathCfg.ucRoutValid << SHIFT_14BIT) |
        (uint32)pMfwdConfig->stCpuMrrPathCfg.usRoutNo);
    EthSwtCont_GpMfwdReg->FWCMPL23URC = LulRegisterVal;

    /* Set Ethernet Mirroring Path */
    LulRegisterVal = (((uint32)pMfwdConfig->stEthMrrPathCfg.ucSecLv << SHIFT_24BIT) |
        ((uint32)pMfwdConfig->stEthMrrPathCfg.ucPortSel << SHIFT_16BIT) |
        ((uint32)pMfwdConfig->stEthMrrPathCfg.ucIpvUpdate << SHIFT_15BIT) |
        ((uint32)pMfwdConfig->stEthMrrPathCfg.ucIpvVal << SHIFT_12BIT));
    EthSwtCont_GpMfwdReg->FWEMPTC = LulRegisterVal;

    LulRegisterVal = (((uint32)pMfwdConfig->stEthMrrPathCfg.ucRoutValid << SHIFT_14BIT) |
        (uint32)pMfwdConfig->stEthMrrPathCfg.usRoutNo);
    EthSwtCont_GpMfwdReg->FWEMPL23URC = LulRegisterVal;

    /* Set Source-Destination Mirroring Path */
    LulRegisterVal = (((uint32)pMfwdConfig->stSDMrrPathCfg.ucSecLv << SHIFT_24BIT) |
        ((uint32)pMfwdConfig->stSDMrrPathCfg.ucPortSel << SHIFT_16BIT) |
        ((uint32)pMfwdConfig->stSDMrrPathCfg.ucIpvUpdate << SHIFT_15BIT) |
        ((uint32)pMfwdConfig->stSDMrrPathCfg.ucIpvVal << SHIFT_12BIT) |
        (uint32)pMfwdConfig->stSDMrrPathCfg.ucCpuSubDest);
    EthSwtCont_GpMfwdReg->FWSDMPTC = LulRegisterVal;

    LulRegisterVal = (((uint32)pMfwdConfig->stSDMrrPathCfg.ucRoutValid << SHIFT_14BIT) |
        (uint32)pMfwdConfig->stSDMrrPathCfg.usRoutNo);
    EthSwtCont_GpMfwdReg->FWSDMPL23URC = LulRegisterVal;

    /* Set Source Mirroring Path */
    LulRegisterVal = (((uint32)pMfwdConfig->stSrcMrrPathCfg.ucSecLv << SHIFT_24BIT) |
        ((uint32)pMfwdConfig->stSrcMrrPathCfg.ucPortSel << SHIFT_16BIT) |
        ((uint32)pMfwdConfig->stSrcMrrPathCfg.ucIpvUpdate << SHIFT_15BIT) |
        ((uint32)pMfwdConfig->stSrcMrrPathCfg.ucIpvVal << SHIFT_12BIT) |
        (uint32)pMfwdConfig->stSrcMrrPathCfg.ucCpuSubDest);
    EthSwtCont_GpMfwdReg->FWSMPTC = LulRegisterVal;

    LulRegisterVal = (((uint32)pMfwdConfig->stSrcMrrPathCfg.ucRoutValid << SHIFT_14BIT) |
        (uint32)pMfwdConfig->stSrcMrrPathCfg.usRoutNo);
    EthSwtCont_GpMfwdReg->FWSMPL23URC = LulRegisterVal;

    /* Set Source-Destination Mirroring Path enables */
    LulRegisterVal = (((uint32)pMfwdConfig->stSDMrrPathCfg.usSrcVec << SHIFT_16BIT) |
        (uint32)pMfwdConfig->stSDMrrPathCfg.usDestVec);
    EthSwtCont_GpMfwdReg->FWSDMPVC = LulRegisterVal;

    /* Set Source Mirroring Path enables */
    LulRegisterVal = ((uint32)pMfwdConfig->stSrcMrrPathCfg.usSrcVec << SHIFT_16BIT);
    EthSwtCont_GpMfwdReg->FWSMPVC = LulRegisterVal;

    /* IPV Based WaterMark Configuration */
    LulRegisterVal = (((uint32)pMfwdConfig->usSecIPVWMReject << SHIFT_16BIT) |
            ((uint32)pMfwdConfig->usUnsecIPVWMReject));
    EthSwtCont_GpMfwdReg->FWIBWMC = LulRegisterVal;

    /* Set Watermark rejected priorities */
    for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_NUM; LucPortIdx++)
    {
        LulRegisterVal = (((uint32)pMfwdConfig->usWatermarkFlushPriority[LucPortIdx] << SHIFT_16BIT) |
            ((uint32)pMfwdConfig->usWatermarkCriticalPriority[LucPortIdx]));
        EthSwtCont_GpMfwdReg->FWLBWMCi[LucPortIdx] = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_002]:[Gen5GW_EthSwtCont_UD_10_002]
* Function Name: EthSwtCont_SetMfwdPort
* Description  : R-Switch3 MFWD port Initialization
* Arguments    : pMfwdPortConfig -
*                    MFWD port Configuration
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetMfwdPort(const R_EthSwtCont_MfwdPortCfgType *pMfwdPortConfig)
{
    uint8 LucPortIdx;
    uint32 LulRegisterVal;

    for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_NUM; LucPortIdx++)
    {
        /* Port i setting flow */
        EthSwtCont_GpMfwdReg->stFWPCi[LucPortIdx].FWPC0 =
            pMfwdPortConfig->aaPortFlags[LucPortIdx];

        LulRegisterVal = (((uint32)pMfwdPortConfig->aaL3FwdMask[LucPortIdx] << SHIFT_16BIT) |
                          ((uint32)pMfwdPortConfig->aaBLSecLvDisable[LucPortIdx] << SHIFT_13BIT)  |
                          ((uint32)pMfwdPortConfig->aaBLEnable[LucPortIdx] << SHIFT_12BIT)  |
                          ((uint32)pMfwdPortConfig->aaPFALSecLvDisable[LucPortIdx] << SHIFT_10BIT)  |
                          ((uint32)pMfwdPortConfig->aaPFALEnable[LucPortIdx] << SHIFT_8BIT));
        EthSwtCont_GpMfwdReg->stFWPCi[LucPortIdx].FWPC1 = LulRegisterVal;

        LulRegisterVal = ((uint32)pMfwdPortConfig->aaL2FwdMask[LucPortIdx] << SHIFT_16BIT);
        EthSwtCont_GpMfwdReg->stFWPCi[LucPortIdx].FWPC2 = LulRegisterVal;
        
        LulRegisterVal = (((uint32)pMfwdPortConfig->aaL23UpdateOverwriteEnable[LucPortIdx] << SHIFT_16BIT) |
                           (uint32)pMfwdPortConfig->aaL3FwdMaskDisable[LucPortIdx]);
        EthSwtCont_GpMfwdReg->stFWPCi[LucPortIdx].FWPC3 = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_003]:[Gen5GW_EthSwtCont_UD_10_003]
* Function Name: EthSwtCont_SetRoutTbl
* Description  : R-Switch3 Routing table setting
* Arguments    : pRoutConfig -
*                    Routing Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetRoutTbl(const R_EthSwtCont_RoutCfgType *pRoutConfig)
{
    uint8 LucRetVal;

    LucRetVal = SetL3RuleTbl(&pRoutConfig->stL3Cfg);
    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = SetL2RuleTbl(&pRoutConfig->stL2Cfg);
        if ((uint32)E_OK == LucRetVal)
        {
            (void)SetPortBased(pRoutConfig->pPortBasedCfg);
            LucRetVal = SetL2L3UpRuleTbl(&pRoutConfig->stL2L3UpCfg);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_044]:[Gen5GW_EthSwtCont_UD_10_044]
* Function Name: EthSwtCont_LearnRoutTbl
* Description  : R-Switch3 Routing table update setting
* Arguments    : pRoutConfig -
*                    Routing Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_LearnRoutTbl(const R_EthSwtCont_RoutCfgType *pRoutConfig)
{
    uint8 LucRetVal;

    SetPerfectFilter(&pRoutConfig->stL3Cfg.stPFCfg);

    /* Set L3 Table and Stream Filter */
    LucRetVal = SetL3Tbl(&pRoutConfig->stL3Cfg);
    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = SetMacTbl(&pRoutConfig->stL2Cfg);
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = SetVlanTbl(&pRoutConfig->stL2Cfg);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* Set L2/L3 Update Table */
        LucRetVal = SetL2L3UpTbl(&pRoutConfig->stL2L3UpCfg);
        if ((uint32)E_OK == LucRetVal)
        {
            SetL2L3UpRemapTbl(&pRoutConfig->stL2L3UpCfg);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_004]:[Gen5GW_EthSwtCont_UD_10_004]
* Function Name: EthSwtCont_CheckMfwdCfg
* Description  : R-Switch3 MFWD Configuration Check
* Arguments    : pMfwdConfig -
*                    MFWD Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckMfwdCfg(const R_EthSwtCont_MfwdCfgType *pMfwdConfig)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    /* Configuration check */
    /* TPID does not need check */
    if (((uint32)pMfwdConfig->ucSVlanMode <= (uint32)VLANMODE_SCTAG) &&
        ((uint32)pMfwdConfig->stCpuExPathCfg.ucSecLv <= ETHSWTCONT_REG_SET) &&
        ((uint32)pMfwdConfig->stCpuExPathCfg.ucCpuSel < (uint32)ETHSWTCONT_PORT_GWCA_NUM) &&
        ((uint32)pMfwdConfig->stCpuExPathCfg.ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
        ((uint32)pMfwdConfig->stCpuExPathCfg.ucCpuSubDest < (uint32)AXI_CHAIN_NUM) &&
        ((uint32)NUM0 == (pMfwdConfig->stCpuExPathCfg.ulExceptFlag0 & MASK_RSVFWCEPRC0)) &&
        ((uint32)NUM0 == (pMfwdConfig->stCpuExPathCfg.ulExceptFlag1 & MASK_RSVFWCEPRC1)) &&
        ((uint32)NUM0 == (pMfwdConfig->stCpuExPathCfg.ulExceptFlag2 & MASK_RSVFWCEPRC2)) &&
        ((uint32)pMfwdConfig->stCpuLrnPathCfg.ucSecLv <= ETHSWTCONT_REG_SET) &&
        ((uint32)pMfwdConfig->stCpuLrnPathCfg.ucCpuSel < (uint32)ETHSWTCONT_PORT_GWCA_NUM) &&
        ((uint32)pMfwdConfig->stCpuLrnPathCfg.ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
        ((uint32)pMfwdConfig->stCpuLrnPathCfg.ucCpuSubDest < (uint32)AXI_CHAIN_NUM) &&
        ((uint32)NUM0 == (pMfwdConfig->stCpuLrnPathCfg.ulLrnFlag & MASK_RSVFWCLPRC)))
    {
        if (((uint32)pMfwdConfig->stCpuMrrPathCfg.ucSecLv <= ETHSWTCONT_REG_SET) &&
            ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucCpuSel < (uint32)ETHSWTCONT_PORT_GWCA_NUM) &&
            ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
            ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
            ((uint32)pMfwdConfig->stCpuMrrPathCfg.ucCpuSubDest < (uint32)AXI_CHAIN_NUM) &&
            ((uint32)pMfwdConfig->stEthMrrPathCfg.ucSecLv <= ETHSWTCONT_REG_SET) &&
            ((uint32)pMfwdConfig->stEthMrrPathCfg.ucPortSel < (uint32)ETHSWTCONT_PORT_TSNA_NUM) &&
            ((uint32)pMfwdConfig->stEthMrrPathCfg.ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
            ((uint32)pMfwdConfig->stEthMrrPathCfg.ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.ucSecLv <= ETHSWTCONT_REG_SET) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.ucPortSel < (uint32)ETHSWTCONT_PORT_NUM) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.ucCpuSubDest < (uint32)AXI_CHAIN_NUM) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.usSrcVec <= ETHSWTCONT_PORT_MASK) &&
            ((uint32)pMfwdConfig->stSDMrrPathCfg.usDestVec <= ETHSWTCONT_PORT_MASK))
        {
            /* TPID Configuration Check */
            if (((uint32)pMfwdConfig->usSTagTPID >= (uint32)TPID_MIN) &&
                ((uint32)pMfwdConfig->usSTagTPID != (uint32)ETHERTYPE_IPV4) &&
                ((uint32)pMfwdConfig->usSTagTPID != (uint32)ETHERTYPE_IPV6) &&
                ((uint32)pMfwdConfig->usCTagTPID >= (uint32)TPID_MIN) &&
                ((uint32)pMfwdConfig->usCTagTPID != (uint32)ETHERTYPE_IPV4) &&
                ((uint32)pMfwdConfig->usCTagTPID != (uint32)ETHERTYPE_IPV6) &&
                ((uint32)pMfwdConfig->usRTagTPID >= (uint32)TPID_MIN) &&
                ((uint32)pMfwdConfig->usRTagTPID != (uint32)ETHERTYPE_IPV4) &&
                ((uint32)pMfwdConfig->usRTagTPID != (uint32)ETHERTYPE_IPV6) &&
                ((uint32)pMfwdConfig->usSTagTPID != (uint32)pMfwdConfig->usCTagTPID) &&
                ((uint32)pMfwdConfig->usSTagTPID != (uint32)pMfwdConfig->usRTagTPID) &&
                ((uint32)pMfwdConfig->usCTagTPID != (uint32)pMfwdConfig->usRTagTPID))
            {
                /* Configuration check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, 
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_MFWD);
                #endif
            }
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, 
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_MFWD);
            #endif
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, 
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_MFWD);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_005]:[Gen5GW_EthSwtCont_UD_10_005]
* Function Name: EthSwtCont_CheckMfwdPortCfg
* Description  : R-Switch3 MFWD port Configuration Check
* Arguments    : pMfwdPortConfig -
*                    MFWD port Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckMfwdPortCfg(const R_EthSwtCont_MfwdPortCfgType *pMfwdPortConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint8 LucPortIdx;

    LucRetVal = E_OK;

    for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_NUM; LucPortIdx++)
    {
        /* MFWD Port Configuration Check */
        if (((uint32)pMfwdPortConfig->aaL3FwdMask[LucPortIdx] <= ETHSWTCONT_PORT_MASK) &&
            ((uint32)pMfwdPortConfig->aaL2FwdMask[LucPortIdx] <= ETHSWTCONT_PORT_MASK))
        {
            if ((uint32)VLANMODE_NOVLAN == (uint32)EthSwtCont_GucVlanMode)
            {
                /* If NOVLAN mode, VLAN related bit should be 0. */
                if ((uint32)NUM0 == ((uint32)pMfwdPortConfig->aaPortFlags[LucPortIdx] & MASK_RSVFWPC0_NOVLAN))
                {
                    /* Config check Passed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, 
                                                                                            ETHSWTCONT_E_CFG_MFWDPORT);
                    #endif
                }
            }
            else
            {
                if ((uint32)NUM0 == ((uint32)pMfwdPortConfig->aaPortFlags[LucPortIdx] & MASK_RSVFWPC0))
                {
                    /* Config check Passed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, 
                                                                                            ETHSWTCONT_E_CFG_MFWDPORT);
                    #endif
                }
            }
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_MFWDPORT);
            #endif
        }

        if ((uint32)E_OK == LucRetVal)
        {
            /* Config check Passed */
        }
        else
        {
            /* Config check failed. Exit loop. */
            break;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_006]:[Gen5GW_EthSwtCont_UD_10_006]
* Function Name: EthSwtCont_CheckRoutCfg
* Description  : R-Switch3 Routing table configuration check
* Arguments    : pRoutConfig -
*                    Routing Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckRoutCfg(const R_EthSwtCont_RoutCfgType *pRoutConfig)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    /* NULL check for pRoutConfig pointer member */
    if ((NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pTwoBF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pThreeBF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pFourBF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pRF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pCF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stStreamCfg.pStreamFilter) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stStreamCfg.pStreamGenCfg) &&
        (NULL_PTR != pRoutConfig->stL2Cfg.pMacTable) &&
        (NULL_PTR != pRoutConfig->stL2Cfg.pVlanTable) &&
        (NULL_PTR != pRoutConfig->stL2L3UpCfg.pL2L3UpTblCfg) &&
        (NULL_PTR != pRoutConfig->stL2L3UpCfg.pL2L3UpRemapCfg) &&
        (NULL_PTR != pRoutConfig->pPortBasedCfg)
        )
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_PARAM_CONFIG);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = CheckPerfectFilterCfg(&pRoutConfig->stL3Cfg.stPFCfg
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        , R_ETHSWTCONT_INIT_SID
        #endif
        );
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = CheckStreamFilterGenCfg(pRoutConfig->stL3Cfg.stStreamCfg.pStreamGenCfg);
            if ((uint32)E_OK == LucRetVal)
            {
                LucRetVal = CheckStreamFilterCfg(&pRoutConfig->stL3Cfg.stStreamCfg
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                , R_ETHSWTCONT_INIT_SID
                #endif
                );
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        if ((uint32)pRoutConfig->stL2Cfg.usVlanMaxUnsecEntry <= (uint32)VLAN_TBLENTRY_NUM)
        {
            /* Do nothing */
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_VLANTBL);
            #endif
        }

        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = CheckMacTblCfg(&pRoutConfig->stL2Cfg
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            , R_ETHSWTCONT_INIT_SID
            #endif
            );
            if ((uint32)E_OK == LucRetVal)
            {
                LucRetVal = CheckVlanTblCfg(&pRoutConfig->stL2Cfg
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                , R_ETHSWTCONT_INIT_SID
                #endif
                );
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = CheckPortBasedCfg(pRoutConfig->pPortBasedCfg
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        , R_ETHSWTCONT_INIT_SID
        #endif
        );
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = CheckL2L3UpCfg(&pRoutConfig->stL2L3UpCfg
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            , R_ETHSWTCONT_INIT_SID
            #endif
            );
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_045]:[Gen5GW_EthSwtCont_UD_10_045]
* Function Name: EthSwtCont_CheckUpdateRoutCfg
* Description  : R-Switch3 Routing table update configuration check
* Arguments    : pRoutConfig -
*                    Routing Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckUpdateRoutCfg(const R_EthSwtCont_RoutCfgType *pRoutConfig)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    /* NULL check for pRoutConfig pointer member */
    if ((NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pTwoBF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pThreeBF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pFourBF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pRF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stPFCfg.pCF) &&
        (NULL_PTR != pRoutConfig->stL3Cfg.stStreamCfg.pStreamFilter) &&
        (NULL_PTR != pRoutConfig->stL2Cfg.pMacTable) &&
        (NULL_PTR != pRoutConfig->stL2Cfg.pVlanTable) &&
        (NULL_PTR != pRoutConfig->stL2L3UpCfg.pL2L3UpTblCfg) &&
        (NULL_PTR != pRoutConfig->stL2L3UpCfg.pL2L3UpRemapCfg)
        )
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_UPDATEROUTTBL_SID, 
                                                                                            ETHSWTCONT_E_PARAM_CONFIG);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = CheckPerfectFilterCfg(&pRoutConfig->stL3Cfg.stPFCfg
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        , R_ETHSWTCONT_UPDATEROUTTBL_SID
        #endif
        );
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = CheckStreamFilterCfg(&pRoutConfig->stL3Cfg.stStreamCfg
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            , R_ETHSWTCONT_UPDATEROUTTBL_SID
            #endif
            );
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = CheckMacTblCfg(&pRoutConfig->stL2Cfg
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        , R_ETHSWTCONT_UPDATEROUTTBL_SID
        #endif
        );
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = CheckVlanTblCfg(&pRoutConfig->stL2Cfg
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            , R_ETHSWTCONT_UPDATEROUTTBL_SID
            #endif
            );
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = CheckL2L3UpCfg(&pRoutConfig->stL2L3UpCfg
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        , R_ETHSWTCONT_UPDATEROUTTBL_SID
        #endif
        );
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_007]:[Gen5GW_EthSwtCont_UD_10_007]
* Function Name: EthSwtCont_EnableClock
* Description  : R-Switch3 Clock Enable
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_EnableClock(void)
{
    /* R-Switch Clock Enable */
    EthSwtCont_GpComaReg->RCEC = (ETHSWTCONT_REG_SET << SHIFT_16BIT);
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_008]:[Gen5GW_EthSwtCont_UD_10_008]
* Function Name: EthSwtCont_InitBuffPool
* Description  : R-Switch3 Buffer pool initialization
* Arguments    : pWatermarkCfg -
*                    Watermark Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_InitBuffPool(const R_EthSwtCont_WatermarkCfgType *pWatermarkCfg)
{
    uint8 LucRetVal;
    uint32 LulLoopCnt;
    uint32 LulIdx;
    uint32 LulRegisterVal;

    LucRetVal = E_OK;
    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;

    /* Set IPV-based watermark */
    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM; LulIdx++)
    {
        LulRegisterVal = (((uint32)pWatermarkCfg->aaIpvSecure[LulIdx] << SHIFT_16BIT)|
                          (uint32)pWatermarkCfg->aaIpvUnsecure[LulIdx]);
        EthSwtCont_GpComaReg->CABPIBWMCi[LulIdx] = LulRegisterVal;
    }
    /* Set Global level-based watermark */
    LulRegisterVal = (((uint32)pWatermarkCfg->usCriticalLevel << SHIFT_16BIT)|
                          (uint32)pWatermarkCfg->usFlushLevel);
    EthSwtCont_GpComaReg->CABPWMLC = LulRegisterVal;
    /* Skip Global pause function setting */

    /* Set Per-port level-based watermark */
    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_PORT_NUM; LulIdx++)
    {
        LulRegisterVal = (((uint32)pWatermarkCfg->aaPerPortCriticalLevel[LulIdx] << SHIFT_16BIT)|
                          (uint32)pWatermarkCfg->aaPerPortFlushLevel[LulIdx]);
        EthSwtCont_GpComaReg->CABPPWMLCi[LulIdx] = LulRegisterVal;
    }
    /* Skip Per-port pause function setting */

    /* Set memory allocation */
    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_PORT_NUM; LulIdx++)
    {
        LulRegisterVal = (((uint32)pWatermarkCfg->aaMinPointerNum[LulIdx] << SHIFT_16BIT)|
                          (uint32)pWatermarkCfg->aaMaxPointerNum[LulIdx]);
        EthSwtCont_GpComaReg->CABPULCi[LulIdx] = LulRegisterVal;
    }
    /* Start buffer pool reset */
    EthSwtCont_GpComaReg->CABPIRM = ETHSWTCONT_REG_SET;

    /* Wait until buffer pool reset finished */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = ((EthSwtCont_GpComaReg->CABPIRM >> SHIFT_1BIT) & MASK_1BIT);
    } while (ETHSWTCONT_REG_CLR == LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_069]:[Gen5GW_EthSwtCont_UD_10_069]
* Function Name: EthSwtCont_CheckBuffPool
* Description  : R-Switch3 Buffer pool initialization configuration check
* Arguments    : pWatermarkCfg -
*                    Watermark Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckBuffPool(const R_EthSwtCont_WatermarkCfgType *pWatermarkCfg)
{
    uint8 LucRetVal;
    uint32 LulIdx;
    uint32 LulMinPointerNum;

    LucRetVal = E_OK;
    LulMinPointerNum = NUM0;

    /* Check IPV-based watermark Configuration*/
    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM; LulIdx++)
    {
        if (LulIdx < (ETHSWTCONT_FRAME_PRIORITY_NUM - NUM1))
        {
            if (((uint32)pWatermarkCfg->aaIpvSecure[LulIdx] <= (uint32)LCL_PTR_N) &&
                ((uint32)pWatermarkCfg->aaIpvSecure[LulIdx] <=
                (uint32)pWatermarkCfg->aaIpvSecure[LulIdx + (uint32)NUM1]) &&
                ((uint32)pWatermarkCfg->aaIpvUnsecure[LulIdx] <= (uint32)LCL_PTR_N) &&
                ((uint32)pWatermarkCfg->aaIpvUnsecure[LulIdx] <=
                (uint32)pWatermarkCfg->aaIpvUnsecure[LulIdx + (uint32)NUM1])
                )
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                        ETHSWTCONT_E_CFG_WATERMARK);
                #endif
            }

        }
        else
        {
            if (((uint32)pWatermarkCfg->aaIpvSecure[LulIdx] <= (uint32)LCL_PTR_N) &&
                ((uint32)pWatermarkCfg->aaIpvUnsecure[LulIdx] <= (uint32)LCL_PTR_N))
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                        ETHSWTCONT_E_CFG_WATERMARK);
                #endif
            }
        }
        if ((uint32)E_OK == LucRetVal)
        {
            /* Do Nothing*/
        }
        else
        {
            break;
        }
    }

    /* Check Global level-based watermark Configuration */
    if ((uint32)E_OK == LucRetVal)
    {
        if (((uint32)pWatermarkCfg->usCriticalLevel <= (uint32)LCL_PTR_N) &&
            ((uint32)pWatermarkCfg->usFlushLevel <= (uint32)LCL_PTR_N) &&
            ((uint32)pWatermarkCfg->usCriticalLevel <= (uint32)pWatermarkCfg->usFlushLevel))
        {
            /* Check passed */
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                        ETHSWTCONT_E_CFG_WATERMARK);
            #endif
        }
    }
    else
    {
        /* Do Nothing*/
    }

    if ((uint32)E_OK == LucRetVal)
    {
        for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_PORT_NUM; LulIdx++)
        {
            LulMinPointerNum += (uint32)pWatermarkCfg->aaMinPointerNum[LulIdx];
            if (((uint32)pWatermarkCfg->aaPerPortCriticalLevel[LulIdx] <= (uint32)LCL_PTR_N) &&
                ((uint32)pWatermarkCfg->aaPerPortFlushLevel[LulIdx] <= (uint32)LCL_PTR_N) &&
                ((uint32)pWatermarkCfg->aaMaxPointerNum[LulIdx] <= (uint32)LCL_PTR_N) &&
                (LulMinPointerNum <= (uint32)LCL_PTR_N) &&
                ((uint32)pWatermarkCfg->aaPerPortCriticalLevel[LulIdx] <=
                (uint32)pWatermarkCfg->aaPerPortFlushLevel[LulIdx]) &&
                ((uint32)pWatermarkCfg->aaMinPointerNum[LulIdx] <= (uint32)pWatermarkCfg->aaMaxPointerNum[LulIdx]))
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                        ETHSWTCONT_E_CFG_WATERMARK);
                #endif
                break;
            }
        }
    }
    else
    {
        /* Do Nothing*/
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_060]:[Gen5GW_EthSwtCont_UD_10_060]
* Function Name: EthSwtCont_ResetEthSwt
* Description  : Reset Ethernet Switch
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_ResetEthSwt(void)
{
    uint8 LucRetVal;
    uint8 LucPortIdx;

    /* For all Agents, Mode transition flow to DISABLE [GWCA] */
    for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_GWCA_NUM; LucPortIdx++)
    {
        LucRetVal = TransitGwcaMode(LucPortIdx, ETHSWTCONT_MODE_DISABLE);
        if ((uint32)E_OK == LucRetVal)
        {
            /* Next port */
        }
        else
        {
            /* Exit Loop */
            break;
        }
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* For all Agents, Mode transition flow to DISABLE [TSNA] */
        for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_TSNA_NUM; LucPortIdx++)
        {
            LucRetVal = TransitTsnaMode(LucPortIdx, ETHSWTCONT_MODE_DISABLE);
            if ((uint32)E_OK == LucRetVal)
            {
                /* Next port */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* Common agent R-Switch reset flow */
        ResetEthSwt();
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_069]:[Gen5GW_EthSwtCont_UD_23_069]
* Function Name: EthSwtCont_SetCutThrough
* Description  : Set CutThrough Filter
* Arguments    : pCTCfg
*                ulEntryNum
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetCutThrough(const R_EthSwtCont_CTCfgType *pCTCfg, const uint32 ulEntryNum)
{
    uint32 LulIdx;

    for (LulIdx = IDX_0; LulIdx < ulEntryNum; LulIdx++)
    {
        /* Cut-Through General Configuration */
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTGC0i  = (((uint32)pCTCfg[LulIdx].ucRTagIn << SHIFT_14BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucVlanCtrl << SHIFT_12BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucFCSIn << SHIFT_11BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucEtherTypeEnable << SHIFT_8BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucSTagDeiEnable << SHIFT_7BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucSTagPcpEnable << SHIFT_6BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucSTagVlanIdEnable << SHIFT_5BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucCTagDeiEnable << SHIFT_4BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucCTagPcpEnable << SHIFT_3BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucCTagVlanIdEnable << SHIFT_2BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucSrcMacAddrEnable << SHIFT_1BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucDestMacAddrEnable));
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTGC1i = pCTCfg[LulIdx].ulMaxTime;
    }

    for (LulIdx = IDX_0; LulIdx < ulEntryNum; LulIdx++)
    {
        /* Cut-through rule i disable flow */
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTTC0i = NUM0;

        /* Set Cut-through rule i target */
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTTC1i = (((uint32)pCTCfg[LulIdx].ucEthMrrEnable << SHIFT_17BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucCpuMrrEnable << SHIFT_16BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucIpvUpdate << SHIFT_15BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucIpvVal << SHIFT_12BIT));
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTTC2ji[IDX_0] = (uint32)pCTCfg[LulIdx].aaCpuSubDest[IDX_0];
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTTC2ji[IDX_1] = (uint32)pCTCfg[LulIdx].aaCpuSubDest[IDX_1];

        /* Set Cut-through rule i filter */
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTSC0i = (((uint32)pCTCfg[LulIdx].aaDestMacAddr[IDX_0] << SHIFT_16BIT) |
                                                        ((uint32)pCTCfg[LulIdx].aaDestMacAddr[IDX_1] >> SHIFT_16BIT));
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTSC1i = (((uint32)pCTCfg[LulIdx].aaDestMacAddr[IDX_1] << SHIFT_16BIT) |
                                                        (uint32)pCTCfg[LulIdx].aaSrcMacAddr[IDX_0]);
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTSC2i = (uint32)pCTCfg[LulIdx].aaSrcMacAddr[IDX_1];
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTSC3i = (((uint32)pCTCfg[LulIdx].ucSTagDei << SHIFT_31BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucSTagPcp << SHIFT_28BIT) |
                                                        ((uint32)pCTCfg[LulIdx].usSTagVlanId << SHIFT_16BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucCTagDei << SHIFT_15BIT) |
                                                        ((uint32)pCTCfg[LulIdx].ucCTagPcp << SHIFT_12BIT) |
                                                        (uint32)pCTCfg[LulIdx].usCTagVlanId);
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTSC4i = (((uint32)pCTCfg[LulIdx].ucSrcPortNo << SHIFT_16BIT) |
                                                        (uint32)pCTCfg[LulIdx].usEtherType);

        /* Enable Cut-through rule i */
        EthSwtCont_GpMfwdReg->stFWCTi[LulIdx].FWCTTC0i = (((uint32)pCTCfg[LulIdx].usDestFwdMode << SHIFT_16BIT) |
                                                        (uint32)pCTCfg[LulIdx].usDestVec);
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_070]:[Gen5GW_EthSwtCont_UD_23_070]
* Function Name: EthSwtCont_CheckCutThrough
* Description  : Check CutThrough Filter Config
* Arguments    : pCTCfg
*                ulEntryNum
* Return Value : E_OK
                 E_NOT_OK
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckCutThrough(const R_EthSwtCont_CTCfgType *pCTCfg, const uint32 ulEntryNum)
{
    uint8 LucRetVal;
    uint32 LulIdx;

    LucRetVal = E_OK;

    for (LulIdx = IDX_0; LulIdx < ulEntryNum; LulIdx++)
    {
        if (((uint32)pCTCfg[LulIdx].ucRTagIn <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucVlanCtrl <= MASK_2BIT) &&
            ((uint32)pCTCfg[LulIdx].ucFCSIn <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucEtherTypeEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucSTagDeiEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucSTagPcpEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucSTagVlanIdEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucCTagDeiEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucCTagPcpEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucCTagVlanIdEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucSrcMacAddrEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucDestMacAddrEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ulMaxTime <= MASK_26BIT) &&
            ((uint32)pCTCfg[LulIdx].ucEthMrrEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pCTCfg[LulIdx].ucCpuMrrEnable <= ETHSWTCONT_REG_SET))
        {
            if (((uint32)pCTCfg[LulIdx].ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
                ((uint32)pCTCfg[LulIdx].ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)pCTCfg[LulIdx].aaCpuSubDest[IDX_0] < (uint32)AXI_CHAIN_NUM) &&
                ((uint32)pCTCfg[LulIdx].aaCpuSubDest[IDX_1] < (uint32)AXI_CHAIN_NUM) &&
                ((uint32)pCTCfg[LulIdx].aaDestMacAddr[IDX_0] <= MASK_16BIT) &&
                ((uint32)pCTCfg[LulIdx].aaSrcMacAddr[IDX_0] <= MASK_16BIT) &&
                ((uint32)pCTCfg[LulIdx].ucSTagDei <= ETHSWTCONT_REG_SET) &&
                ((uint32)pCTCfg[LulIdx].ucSTagPcp < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)pCTCfg[LulIdx].usSTagVlanId < (uint32)VLANID_NUM) &&
                ((uint32)pCTCfg[LulIdx].ucCTagDei <= ETHSWTCONT_REG_SET) &&
                ((uint32)pCTCfg[LulIdx].ucCTagPcp < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)pCTCfg[LulIdx].usCTagVlanId < (uint32)VLANID_NUM) &&
                ((uint32)pCTCfg[LulIdx].ucSrcPortNo < (uint32)ETHSWTCONT_PORT_TSNA_NUM) &&
                ((uint32)pCTCfg[LulIdx].usDestFwdMode <= (uint32)ETHSWTCONT_PORT_ETHA_MASK) &&
                ((uint32)pCTCfg[LulIdx].usDestVec <= (uint32)ETHSWTCONT_PORT_MASK))
            {
                /* Do nothing */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                        ETHSWTCONT_E_CFG_CUTTHROUGH);
                #endif
            }
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                        ETHSWTCONT_E_CFG_CUTTHROUGH);
            #endif
        }
        
        if ((uint32)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            /* Exit Loop */
            break;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_071]:[Gen5GW_EthSwtCont_UD_23_071]
* Function Name: EthSwtCont_SetIntegrityCheck
* Description  : Set Integrity Check
* Arguments    : pICCfg
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetIntegrityCheck(const R_EthSwtCont_ICCfgType *pICCfg)
{
    uint32 LulRegisterVal;
    uint32 LulPortIdx;

    /* Integrity check setting flow */
    for (LulPortIdx = IDX_0; LulPortIdx < ETHSWTCONT_PORT_NUM; LulPortIdx++)
    {
        /* Integrity check port i setting flow */
        /* Set Ethernet type integrity check */
        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].ucIntgCheckDisableMode << SHIFT_31BIT) |
                                                                                  pICCfg[LulPortIdx].ulEtherTypeCfg);
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWICETC1i = LulRegisterVal;

        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICETC2i = pICCfg[LulPortIdx].ucDirectFilterEnable;

        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_0 * NUM2) + NUM1] << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_0 * NUM2)]);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICETC3ij[IDX_0] = LulRegisterVal;
        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_1 * NUM2) + NUM1] << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_1 * NUM2)]);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICETC3ij[IDX_1] = LulRegisterVal;
        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_2 * NUM2) + NUM1] << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_2 * NUM2)]);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICETC3ij[IDX_2] = LulRegisterVal;
        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_3 * NUM2) + NUM1] << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].usDirectFilterVal[(IDX_3 * NUM2)]);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICETC3ij[IDX_3] = LulRegisterVal;

        /* Set IPv4 Integrity Check */
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWICIP4Ci = pICCfg[LulPortIdx].ulIpv4Cfg;
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP4ACi = pICCfg[LulPortIdx].ulIpv4Addr;
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP4APCi = (uint32)pICCfg[LulPortIdx].ucIpv4Prefix;
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP4FACij[IDX_0] =
                                                                    pICCfg[LulPortIdx].stICIpSpFilter.ulIpv4FilterAddr;

        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].stICIpSpFilter.ucIpv4FilterAddrPrefix << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].stICIpSpFilter.ucIpv4SpecifiedFilterCfg);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP4SFCij[IDX_0] = LulRegisterVal;

        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usIpv4TotalLenMax << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].usIpv4TotalLenMin);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP4TLCCi = LulRegisterVal;

        /* Set IPv6 Integrity Check */
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWICIP6Ci = pICCfg[LulPortIdx].ulIpv6Cfg;
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP6AC0i = pICCfg[LulPortIdx].ulIpv6Addr[IDX_0];
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP6AC1i = pICCfg[LulPortIdx].ulIpv6Addr[IDX_1];
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP6AC2i = pICCfg[LulPortIdx].ulIpv6Addr[IDX_2];
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP6AC3i = pICCfg[LulPortIdx].ulIpv6Addr[IDX_3];
        EthSwtCont_GpMfwdReg->stFWICIPi[LulPortIdx].FWIP6APCi = (uint32)pICCfg[LulPortIdx].ucIpv6Prefix;
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP6FAC0ij[IDX_0] =
                                                              pICCfg[LulPortIdx].stICIpSpFilter.ulIpv6FilterAddr[IDX_0];
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP6FAC1ij[IDX_0] =
                                                              pICCfg[LulPortIdx].stICIpSpFilter.ulIpv6FilterAddr[IDX_1];
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP6FAC2ij[IDX_0] =
                                                              pICCfg[LulPortIdx].stICIpSpFilter.ulIpv6FilterAddr[IDX_2];
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP6FAC3ij[IDX_0] =
                                                              pICCfg[LulPortIdx].stICIpSpFilter.ulIpv6FilterAddr[IDX_3];

        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].stICIpSpFilter.ucIpv6FilterAddrPrefix << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].stICIpSpFilter.ucIpv6SpecifiedFilterCfg);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP6SFCij[IDX_0] = LulRegisterVal;

        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usIpv6PayloadLenMax << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].usIpv6PayloadLenMin);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWIP6PLCCi = LulRegisterVal;

        /* Set Layer 4 Integrity Check */
        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].usICMPPayloadLen << SHIFT_16BIT) |
            ((uint32)pICCfg[LulPortIdx].ucTCPHeaderLen << SHIFT_12BIT) |
            (uint32)pICCfg->usL4FilterEnable);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICL4Ci = LulRegisterVal;
        LulRegisterVal = (((uint32)pICCfg[LulPortIdx].ucTCPHeaderLenMax << SHIFT_16BIT) |
            (uint32)pICCfg[LulPortIdx].ucTCPHeaderLenMin);
        EthSwtCont_GpMfwdReg->stFWICi[LulPortIdx].FWICL4THLCi = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_072]:[Gen5GW_EthSwtCont_UD_23_072]
* Function Name: EthSwtCont_CheckIntegrityCheck
* Description  : Check Integrity Check Config
* Arguments    : pICCfg
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckIntegrityCheck(const R_EthSwtCont_ICCfgType *pICCfg)
{
    uint8 LucRetVal;
    uint32 LulPortIdx;
    uint32 LulIdx;

    LucRetVal = E_OK;

    for (LulPortIdx = IDX_0; LulPortIdx < ETHSWTCONT_PORT_NUM; LulPortIdx++)
    {
        if (((uint32)pICCfg[LulPortIdx].ulEtherTypeCfg <= MASK_17BIT) &&
            ((uint32)pICCfg[LulPortIdx].ucIntgCheckDisableMode <= ETHSWTCONT_REG_SET) &&
            ((uint32)pICCfg[LulPortIdx].ulIpv4Cfg <= MASK_31BIT) &&
            ((uint32)pICCfg[LulPortIdx].ucIpv4Prefix <= MASK_6BIT) &&
            ((uint32)pICCfg[LulPortIdx].ulIpv6Cfg <= MASK_24BIT) &&
            ((uint32)pICCfg[LulPortIdx].usL4FilterEnable <= MASK_10BIT) &&
            ((uint32)pICCfg[LulPortIdx].ucTCPHeaderLen <= MASK_4BIT) &&
            ((uint32)pICCfg[LulPortIdx].ucTCPHeaderLenMin <= MASK_4BIT) &&
            ((uint32)pICCfg[LulPortIdx].ucTCPHeaderLenMax <= MASK_4BIT) &&
            ((uint32)pICCfg[LulPortIdx].stICIpSpFilter.ucIpv4FilterAddrPrefix <= MASK_6BIT))
        {
            for (LulIdx = IDX_0; LulIdx < ETHSWTCONT_INTG_ETYPE_N; LulIdx++)
            {
                if (((uint32)pICCfg[LulPortIdx].usDirectFilterVal[LulIdx] != ETHERTYPE_IPV4) &&
                    ((uint32)pICCfg[LulPortIdx].usDirectFilterVal[LulIdx] != ETHERTYPE_IPV6))
                {
                    /* Do nothing */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                            ETHSWTCONT_E_CFG_ICCHECK);
                    #endif
                    break;
                }
            }
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_INIT_SID, 
                                                                                            ETHSWTCONT_E_CFG_ICCHECK);
            #endif
            
        }

        if (E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            break;
        }
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_009]:[Gen5GW_EthSwtCont_UD_10_009]
* Function Name: SetL3RuleTbl
* Description  : R-Switch3 L3 Rule table setting
* Arguments    : pL3Config -
*                    L3 Rule Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL3RuleTbl(const R_EthSwtCont_L3CfgType *pL3Config)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;

    LucRetVal = ResetL3Tbl();
    if ((uint32)E_OK == LucRetVal)
    {
        /* Set L3 Table entry configuration */
        LulRegisterVal = (((uint32)pL3Config->ucPFAcceptListAreaAll << SHIFT_9BIT) | pL3Config->usPFAcceptListArea);
        EthSwtCont_GpMfwdReg->FWLTHTEC0 = LulRegisterVal;

        EthSwtCont_GpMfwdReg->FWLTHTEC1 = (uint32)pL3Config->usStreamUnsecEntry;

        SetPerfectFilter(&pL3Config->stPFCfg);

        LucRetVal = SetL3Tbl(pL3Config);
        if ((uint32)E_OK == LucRetVal)
        {
            SetStreamFilterSetting(pL3Config->stStreamCfg.pStreamGenCfg);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_010]:[Gen5GW_EthSwtCont_UD_10_010]
* Function Name: SetPerfectFilter
* Description  : R-Switch3 Perfect Filter setting
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetPerfectFilter(const R_EthSwtCont_PFCfgType *pPfConfig)
{
    uint32 LulEntryIdx;
    uint32 LulRegisterVal;

    /* Initialize Perfect Filter Set Status */
    for (LulEntryIdx = IDX_0; LulEntryIdx < PFL_TOTAL_NUM; LulEntryIdx++)
    {
        EthSwtCont_GaaFilterSetStatus[LulEntryIdx] = ETHSWTCONT_FLAG_CLR;
    }

    /* Set Perfect Filter for all entries */
    for (LulEntryIdx = IDX_0; LulEntryIdx < pPfConfig->ulCFEntryNum; LulEntryIdx++)
    {
        if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)pPfConfig->pCF[LulEntryIdx].ucCfgFlag)
        {
            /* Perfect filter i disable flow */
            EthSwtCont_GpMfwdReg->stFWCFi[LulEntryIdx].FWCFCi = (uint32)NUM0;

            SetCascadeFilter(pPfConfig, LulEntryIdx);

            /* Set Perfect filter i enable */
            LulRegisterVal = (((uint32)pPfConfig->pCF[LulEntryIdx].ucMatchMode << SHIFT_31BIT) |
                ((uint32)pPfConfig->pCF[LulEntryIdx].usPFrameValid << SHIFT_16BIT) |
                (uint32)pPfConfig->pCF[LulEntryIdx].usEFrameValid);
            EthSwtCont_GpMfwdReg->stFWCFi[LulEntryIdx].FWCFCi = LulRegisterVal;
        }
        else
        {
            /* Skip this entry */
        }
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_011]:[Gen5GW_EthSwtCont_UD_10_011]
* Function Name: SetCascadeFilter
* Description  : R-Switch3 Cascade Filter setting
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
*                ulEntryIdx -
*                    Cascade Filter Entry Index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetCascadeFilter(const R_EthSwtCont_PFCfgType *pPfConfig, const uint32 ulEntryIdx)
{
    uint32 LulPfMapIdx;
    uint32 LulMappedFilterIdx;
    uint32 LulFilterIdx;
    uint32 LulRegisterVal;
    const R_EthSwtCont_CFCfgType *LpCascadeFilterEntry;

    for (LulPfMapIdx = IDX_0; LulPfMapIdx < (uint32)ETHSWTCONT_PFL_CFMF_NUM; LulPfMapIdx++)
    {
        LpCascadeFilterEntry = &pPfConfig->pCF[ulEntryIdx];
        LulMappedFilterIdx = (uint16)(LpCascadeFilterEntry->aaCFFilterNumber[LulPfMapIdx] / (uint8)NUM2);

        /* Check Filter set status */
        if ((uint32)ETHSWTCONT_FLAG_CLR == (uint32)EthSwtCont_GaaFilterSetStatus[LulMappedFilterIdx])
        {
            if ((uint32)LulMappedFilterIdx < PFL_2BF_NUM)
            {
                /* Index convert */
                LulFilterIdx = LulMappedFilterIdx;
                SetTwoByteFilter(&pPfConfig->pTwoBF[LulFilterIdx], LulFilterIdx);
            }
            else if ((uint32)LulMappedFilterIdx < (PFL_2BF_NUM + PFL_3BF_NUM))
            {
                /* Index convert */
                LulFilterIdx = LulMappedFilterIdx - PFL_2BF_NUM;
                SetThreeByteFilter(&pPfConfig->pThreeBF[LulFilterIdx], LulFilterIdx);
            }
            else if ((uint32)LulMappedFilterIdx < (PFL_2BF_NUM + PFL_3BF_NUM + PFL_4BF_NUM))
            {
                /* Index convert */
                LulFilterIdx = LulMappedFilterIdx - (PFL_2BF_NUM + PFL_3BF_NUM);
                SetFourByteFilter(&pPfConfig->pFourBF[LulFilterIdx], LulFilterIdx);
            }
            else
            {
                /* Index convert */
                LulFilterIdx = LulMappedFilterIdx - (PFL_2BF_NUM + PFL_3BF_NUM + PFL_4BF_NUM);
                SetRangeFilter(&pPfConfig->pRF[LulFilterIdx], LulFilterIdx);
            }

            /* Filter set status update */
            EthSwtCont_GaaFilterSetStatus[LulMappedFilterIdx] = ETHSWTCONT_FLAG_SET;
        }
        else
        {
            /* Skip because this filter is already set. */
        }

        /* Set Cascade Filter Mapping */
        LulRegisterVal = (((uint32)(LpCascadeFilterEntry->aaCFValid[LulPfMapIdx]) << SHIFT_15BIT) |
            (uint32)LpCascadeFilterEntry->aaCFFilterNumber[LulPfMapIdx]);
        EthSwtCont_GpMfwdReg->stFWCFi[ulEntryIdx].FWCFMCij[LulPfMapIdx] = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_025]:[Gen5GW_EthSwtCont_UD_10_025]
* Function Name: SetTwoByteFilter
* Description  : R-Switch3 2 Byte Filter setting
* Arguments    : p2BFEntry -
*                    2 Byte Filter Configuration
*                ulEntryIdx -
*                    2 Byte Filter Entry Index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetTwoByteFilter(const R_EthSwtCont_2BFCfgType *p2BFEntry, const uint32 ulEntryIdx)
{
    uint32 LulRegisterVal;

    if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)p2BFEntry->ucCfgFlag)
    {
        /* 2 Byte Filter Setting */
        /* 2 Byte Filter Value Configuration */
        LulRegisterVal = (((uint32)p2BFEntry->aaFilterVal[IDX_1] << SHIFT_16BIT) |
            (uint32)p2BFEntry->aaFilterVal[IDX_0]);
        EthSwtCont_GpMfwdReg->stFWTWBFi[ulEntryIdx].FWTWBFVCi = LulRegisterVal;
        /* 2 Byte Filter Configuration */
        LulRegisterVal = (((uint32)p2BFEntry->ucOffset << SHIFT_16BIT) |
            ((uint32)p2BFEntry->ucFilterMode << SHIFT_8BIT) |
            (uint32)p2BFEntry->ucUnitMode);
        EthSwtCont_GpMfwdReg->stFWTWBFi[ulEntryIdx].FWTWBFCi = LulRegisterVal;
    }
    else
    {
        /* Skip this entry */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_026]:[Gen5GW_EthSwtCont_UD_10_026]
* Function Name: SetThreeByteFilter
* Description  : R-Switch3 3 Byte Filter setting
* Arguments    : p3BFEntry -
*                    3 Byte Filter Configuration
*                ulEntryIdx -
*                    3 Byte Filter Entry Index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetThreeByteFilter(const R_EthSwtCont_3BFCfgType *p3BFEntry, const uint32 ulEntryIdx)
{
    uint32 LulRegisterVal;

    if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)p3BFEntry->ucCfgFlag)
    {
        /* 3 Byte Filter Setting */
        /* 3 Byte Filter Value Configuration */
        EthSwtCont_GpMfwdReg->stFWTHBFi[ulEntryIdx].FWTHBFV0Ci = p3BFEntry->aaFilterVal[IDX_0];
        EthSwtCont_GpMfwdReg->stFWTHBFi[ulEntryIdx].FWTHBFV1Ci = p3BFEntry->aaFilterVal[IDX_1];
        /* 3 Byte Filter Configuration */
        LulRegisterVal = (((uint32)p3BFEntry->ucOffset << SHIFT_16BIT) |
            (uint32)p3BFEntry->ucUnitMode);
        EthSwtCont_GpMfwdReg->stFWTHBFi[ulEntryIdx].FWTHBFCi = LulRegisterVal;
    }
    else
    {
        /* Skip this entry */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_027]:[Gen5GW_EthSwtCont_UD_10_027]
* Function Name: SetFourByteFilter
* Description  : R-Switch3 4 Byte Filter setting
* Arguments    : p4BFEntry -
*                    4 Byte Filter Configuration
*                ulEntryIdx -
*                    4 Byte Filter Entry Index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetFourByteFilter(const R_EthSwtCont_4BFCfgType *p4BFEntry, const uint32 ulEntryIdx)
{
    uint32 LulRegisterVal;

    if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)p4BFEntry->ucCfgFlag)
    {
        /* 4 Byte Filter Setting */
        /* 4 Byte Filter Value Configuration */
        EthSwtCont_GpMfwdReg->stFWFOBFi[ulEntryIdx].FWFOBFV0Ci = p4BFEntry->aaFilterVal[IDX_0];
        EthSwtCont_GpMfwdReg->stFWFOBFi[ulEntryIdx].FWFOBFV1Ci = p4BFEntry->aaFilterVal[IDX_1];
        /* 4 Byte Filter Configuration */
        LulRegisterVal = (((uint32)p4BFEntry->ucOffset << SHIFT_16BIT) |
            (uint32)p4BFEntry->ucUnitMode);
        EthSwtCont_GpMfwdReg->stFWFOBFi[ulEntryIdx].FWFOBFCi = LulRegisterVal;
    }
    else
    {
        /* Skip this entry */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_028]:[Gen5GW_EthSwtCont_UD_10_028]
* Function Name: SetRangeFilter
* Description  : R-Switch3 Range Filter setting
* Arguments    : pRFEntry -
*                    Range Filter Configuration
*                ulEntryIdx -
*                    Range Filter Entry Index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetRangeFilter(const R_EthSwtCont_RFCfgType *pRFEntry, const uint32 ulEntryIdx)
{
    uint32 LulRegisterVal;

    if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)pRFEntry->ucCfgFlag)
    {
        /* Range Filter Setting */
        /* Range Filter Start Value Configuration */
        LulRegisterVal = ((uint32)pRFEntry->aaStartVal[IDX_1] << SHIFT_16BIT) |
            (uint32)pRFEntry->aaStartVal[IDX_0];
        EthSwtCont_GpMfwdReg->stFWRFi[ulEntryIdx].FWRFSVCi = LulRegisterVal;

        /* Range Filter End Value Configuration */
        LulRegisterVal = ((uint32)pRFEntry->aaEndVal[IDX_1] << SHIFT_16BIT) |
            (uint32)pRFEntry->aaEndVal[IDX_0];
        EthSwtCont_GpMfwdReg->stFWRFi[ulEntryIdx].FWRFEVCi = LulRegisterVal;

        /* Range Filter Configuration */
        LulRegisterVal = (((uint32)pRFEntry->ucOffset << SHIFT_16BIT) |
            ((uint32)pRFEntry->ucExtensionMode << SHIFT_9BIT) |
            ((uint32)pRFEntry->ucOffsetMode << SHIFT_8BIT));
        EthSwtCont_GpMfwdReg->stFWRFi[ulEntryIdx].FWRFCi = LulRegisterVal;
    }
    else
    {
        /* Skip this entry */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_012]:[Gen5GW_EthSwtCont_UD_10_012]
* Function Name: SetL3Tbl
* Description  : R-Switch3 L3 Table setting
* Arguments    : pL3Config -
*                    L3 Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL3Tbl(const R_EthSwtCont_L3CfgType *pL3Config)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    uint32 LaaStreamId[ETHSWTCONT_STREAMID_WORD_SIZE];
    const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry;

    LucRetVal = E_OK;

    /* L3 Table Setting */
    for (LulEntryIdx = IDX_0; LulEntryIdx < pL3Config->stPFCfg.ulCFEntryNum; LulEntryIdx++)
    {
        if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)pL3Config->stPFCfg.pCF[LulEntryIdx].ucCfgFlag)
        {
            LaaStreamId[IDX_0] = NUM0;
            LaaStreamId[IDX_1] = NUM0;
            LaaStreamId[IDX_2] = NUM0;
            LaaStreamId[IDX_3] = LulEntryIdx;
            LucRetVal = SetL3TblEntry(&pL3Config->stPFCfg.pCF[LulEntryIdx].stL3TblCfg, ETHSWTCONT_FMT_PERFECTFILTER,
                &LaaStreamId[IDX_0]);
            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
        else
        {
            /* Skip this entry */
        }
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* L3 Table Setting */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pL3Config->stStreamCfg.ulStreamFilterEntryNum; LulEntryIdx++)
        {
            LpStreamFilterEntry = &pL3Config->stStreamCfg.pStreamFilter[LulEntryIdx];
            LucRetVal = GenerateStreamId(&pL3Config->stStreamCfg, LulEntryIdx, &LaaStreamId[IDX_0]);
            if ((uint32)E_OK == LucRetVal)
            {
                LucRetVal = SetL3TblEntry(&LpStreamFilterEntry->stL3TblCfg,
                    LpStreamFilterEntry->ucFrameFormatVec, &LaaStreamId[IDX_0]);
            }
            else
            {
                /* Do nothing */
            }

            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_029]:[Gen5GW_EthSwtCont_UD_10_029]
* Function Name: SetL3TblEntry
* Description  : R-Switch3 L3 Table Entry setting
* Arguments    : pL3TblEntry -
*                    L3 Table Entry Configuration
*                ucFrameFormat -
*                    Frame Format Vector
*                aaStreamId -
*                    Stream ID
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL3TblEntry(const R_EthSwtCont_L3TblCfgType *pL3TblEntry,
    const uint8 ucFrameFormat, const uint32 *aaStreamId)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulLearnResult;
    uint32 LulLoopCnt;

    LucRetVal = E_OK;

    /* Set L3 Table Entry */
    EthSwtCont_GpMfwdReg->FWLTHTL0 = (uint32)pL3TblEntry->usEntryAddress;

    LulRegisterVal = (((uint32)pL3TblEntry->ucEntryDel << SHIFT_31BIT) |
        ((uint32)pL3TblEntry->ucFilterPriority << SHIFT_20BIT) |
        ((uint32)pL3TblEntry->ucRoutPriority << SHIFT_16BIT) |
        ((uint32)pL3TblEntry->ucBL << SHIFT_12BIT) |
        ((uint32)pL3TblEntry->ucHwLearnDisable << SHIFT_10BIT) |
        (uint32)ucFrameFormat);
    EthSwtCont_GpMfwdReg->FWLTHTL1 = LulRegisterVal;
    /* Set Stream ID to entry */
    EthSwtCont_GpMfwdReg->FWLTHTL2 = aaStreamId[IDX_0];
    EthSwtCont_GpMfwdReg->FWLTHTL3 = aaStreamId[IDX_1];
    EthSwtCont_GpMfwdReg->FWLTHTL4 = aaStreamId[IDX_2];
    EthSwtCont_GpMfwdReg->FWLTHTL5 = aaStreamId[IDX_3];
    /* Set Stream ID Mask to entry */
    EthSwtCont_GpMfwdReg->FWLTHTL6 = pL3TblEntry->aaStreamMask[IDX_0];
    EthSwtCont_GpMfwdReg->FWLTHTL7 = pL3TblEntry->aaStreamMask[IDX_1];
    EthSwtCont_GpMfwdReg->FWLTHTL8 = pL3TblEntry->aaStreamMask[IDX_2];
    EthSwtCont_GpMfwdReg->FWLTHTL9 = pL3TblEntry->aaStreamMask[IDX_3];
    /* Set MSDU and Gate to entry */
    LulRegisterVal = (((uint32)pL3TblEntry->ucMsduValid << SHIFT_31BIT) |
        ((uint32)pL3TblEntry->ucMsduNo << SHIFT_16BIT) |
        ((uint32)pL3TblEntry->ucGateValid << SHIFT_15BIT) |
        (uint32)pL3TblEntry->ucGateNo);
    EthSwtCont_GpMfwdReg->FWLTHTL10 = LulRegisterVal;
    /* Set Meter and FRER to entry */
    LulRegisterVal = (((uint32)pL3TblEntry->ucMeterValid << SHIFT_31BIT) |
        ((uint32)pL3TblEntry->ucMeterNo << SHIFT_16BIT) |
        ((uint32)pL3TblEntry->ucFrerValid << SHIFT_15BIT) |
        (uint32)pL3TblEntry->ucFrerNo);
    EthSwtCont_GpMfwdReg->FWLTHTL11 = LulRegisterVal;
    /* Set Source Lock Vector and Routing Rule to entry */
    LulRegisterVal = (((uint32)pL3TblEntry->usSrcLockVec << SHIFT_16BIT) |
        ((uint32)pL3TblEntry->ucRoutValid << SHIFT_15BIT) |
        (uint32)pL3TblEntry->usRoutNo);
    EthSwtCont_GpMfwdReg->FWLTHTL12 = LulRegisterVal;
    /* Set CPU Sub-destination to entry */
    EthSwtCont_GpMfwdReg->FWLTHTL13i[ETHSWTCONT_SEC_CPU] =
        (uint32)pL3TblEntry->aaCpuSubDest[ETHSWTCONT_SEC_CPU];
    EthSwtCont_GpMfwdReg->FWLTHTL13i[ETHSWTCONT_UNSEC_CPU] =
        (uint32)pL3TblEntry->aaCpuSubDest[ETHSWTCONT_UNSEC_CPU];

    /* FWLTHTL9 is trigger of learning */
    LulRegisterVal = (((uint32)pL3TblEntry->ucCpuMrrEnable << SHIFT_BIT_CMEL) |
        ((uint32)pL3TblEntry->ucEthMrrEnable << SHIFT_BIT_EMEL) |
        ((uint32)pL3TblEntry->ucIpvUpdate << SHIFT_BIT_IPUL) |
        ((uint32)pL3TblEntry->ucIpvVal << SHIFT_BIT_IPVL) |
        (uint32)pL3TblEntry->usDestVec);
    EthSwtCont_GpMfwdReg->FWLTHTL14 = LulRegisterVal;

    EthSwtCont_GpMfwdReg->FWLTHTL15 = (uint32)pL3TblEntry->usDestLockVec;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    /* Wait for learning entry complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DEM */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = (EthSwtCont_GpMfwdReg->FWLTHTLR >> SHIFT_31BIT);
    } while (ETHSWTCONT_REG_SET == LulRegisterVal);

    if ((uint32)E_OK == LucRetVal)
    {
        LulLearnResult = ((EthSwtCont_GpMfwdReg->FWLTHTLR) & MASK_4BIT);
        if ((uint32)NUM0 == LulLearnResult)
        {
            /* Learning Success */
        }
        else
        {
            LucRetVal = DEMCheckL3LearnFail((uint8)LulLearnResult);
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_013]:[Gen5GW_EthSwtCont_UD_10_013]
* Function Name: CheckPerfectFilterCfg
* Description  : R-Switch3 Perfect Filter Configuration Check
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckPerfectFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;

    LucRetVal = E_OK;

    if (pPfConfig->ulCFEntryNum <= (uint32)PFL_CF_NUM)
    {
        /* Cascade Filter Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pPfConfig->ulCFEntryNum; LulEntryIdx++)
        {
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)pPfConfig->pCF[LulEntryIdx].ucCfgFlag)
            {
                LucRetVal = CheckCascadeFilterCfg(pPfConfig, LulEntryIdx
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON) 
                    , ucSID 
                #endif
                );
                if ((uint32)E_OK == LucRetVal)
                {
                    /* Configuration Check passed */
                }
                else
                {
                    /* Exit Loop */
                    break;
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
    }

    /* 2/3/4/Range Filter Configuration check */
    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = CheckTwoByteFilterCfg(pPfConfig
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
        #endif
        );
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = CheckThreeByteFilterCfg(pPfConfig
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                , ucSID
            #endif
            );
            if ((uint32)E_OK == LucRetVal)
            {
                LucRetVal = CheckFourByteFilterCfg(pPfConfig
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    , ucSID
                #endif
                );
                if ((uint32)E_OK == LucRetVal)
                {
                    LucRetVal = CheckRangeFilterCfg(pPfConfig
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        , ucSID
                    #endif
                    );
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_014]:[Gen5GW_EthSwtCont_UD_10_014]
* Function Name: CheckCascadeFilterCfg
* Description  : R-Switch3 Cascade Filter Configuration Check
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
*                ulEntryIdx -
*                    Cascade Filter Entry Index
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckCascadeFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig, const uint32 ulEntryIdx
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulPfMapIdx;
    const R_EthSwtCont_L3TblCfgType *LpL3TblEntry;

    LucRetVal = E_OK;
    LpL3TblEntry = &pPfConfig->pCF[ulEntryIdx].stL3TblCfg;

    if (((uint32)pPfConfig->pCF[ulEntryIdx].usPFrameValid <= ETHSWTCONT_PORT_ETHA_MASK) &&
        ((uint32)pPfConfig->pCF[ulEntryIdx].usEFrameValid <= ETHSWTCONT_PORT_MASK) &&
        ((uint32)LpL3TblEntry->ucEntryDel <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucGateNo < (uint32)ETHSWTCONT_PSFP_GATE_NUM) &&
        ((uint32)LpL3TblEntry->ucGateValid <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucMsduNo < (uint32)ETHSWTCONT_PSFP_MSDU_NUM) &&
        ((uint32)LpL3TblEntry->ucMsduValid <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucFrerNo < (uint32)ETHSWTCONT_PSFP_RECE_NUM) &&
        ((uint32)LpL3TblEntry->ucFrerValid <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucMeterNo < (uint32)ETHSWTCONT_PSFP_MTR_NUM) &&
        ((uint32)LpL3TblEntry->ucMeterValid <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucRoutValid <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->usSrcLockVec <= ETHSWTCONT_PORT_MASK) &&
        ((uint32)LpL3TblEntry->aaCpuSubDest[ETHSWTCONT_SEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
        ((uint32)LpL3TblEntry->aaCpuSubDest[ETHSWTCONT_UNSEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
        ((uint32)LpL3TblEntry->usDestVec <= ETHSWTCONT_PORT_MASK) &&
        ((uint32)LpL3TblEntry->ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
        ((uint32)LpL3TblEntry->ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucEthMrrEnable <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpL3TblEntry->ucCpuMrrEnable <= ETHSWTCONT_REG_SET))
    {
        for (LulPfMapIdx = IDX_0; LulPfMapIdx < (uint32)ETHSWTCONT_PFL_CFMF_NUM; LulPfMapIdx++)
        {
            if ((uint32)pPfConfig->pCF[ulEntryIdx].aaCFValid[LulPfMapIdx] <= ETHSWTCONT_REG_SET)
            {
                /* ucCFFilter is always true now, so check is skip */
                /* Do nothing */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                                ucSID, ETHSWTCONT_E_CFG_PF);
                #endif
                break;
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_015]:[Gen5GW_EthSwtCont_UD_10_015]
* Function Name: CheckTwoByteFilterCfg
* Description  : R-Switch3 2 Byte Filter Configuration Check
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckTwoByteFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_2BFCfgType *Lp2BFEntry;

    LucRetVal = E_OK;

    if (pPfConfig->ulTwoBFEntryNum <= (uint32)PFL_2BF_NUM)
    {
        /* 2 Byte Filter Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pPfConfig->ulTwoBFEntryNum; LulEntryIdx++)
        {
            Lp2BFEntry = &pPfConfig->pTwoBF[LulEntryIdx];
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)Lp2BFEntry->ucCfgFlag)
            {
                if ((uint32)Lp2BFEntry->ucUnitMode <= (uint32)UNITMODE_PRECISE)
                {
                    if (((uint32)UNITMODE_EXPAND == (uint32)Lp2BFEntry->ucUnitMode) &&
                        ((uint32)FILTERMODE_VLANTAG == (uint32)Lp2BFEntry->ucFilterMode))
                    {
                        /* HW restriction */
                        LucRetVal = E_NOT_OK;
                        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                        #endif
                    }
                    else
                    {
                        LucRetVal = CheckPerfectFilterOffset((uint8)ETHSWTCONT_REG_CLR, Lp2BFEntry->ucFilterMode,
                            Lp2BFEntry->ucOffset
                        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                            , ucSID
                        #endif
                        );
                    }
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                }

                if ((uint32)E_OK == LucRetVal)
                {
                    /* Next entry */
                }
                else
                {
                    /* Exit loop */
                    break;
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_016]:[Gen5GW_EthSwtCont_UD_10_016]
* Function Name: CheckThreeByteFilterCfg
* Description  : R-Switch3 3 Byte Filter Configuration Check
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckThreeByteFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig    
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_3BFCfgType *Lp3BFEntry;

    LucRetVal = E_OK;

    if (pPfConfig->ulThreeBFEntryNum <= (uint32)PFL_3BF_NUM)
    {
        /* 3 Byte Filter Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pPfConfig->ulThreeBFEntryNum; LulEntryIdx++)
        {
            Lp3BFEntry = &pPfConfig->pThreeBF[LulEntryIdx];
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)Lp3BFEntry->ucCfgFlag)
            {
                if (((uint32)Lp3BFEntry->ucUnitMode <= (uint32)UNITMODE_PRECISE) &&
                    (Lp3BFEntry->aaFilterVal[IDX_0] <= MASK_24BIT) &&
                    (Lp3BFEntry->aaFilterVal[IDX_1] <= MASK_24BIT))
                {
                    /* Offset value range check is not needed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                    break;
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_017]:[Gen5GW_EthSwtCont_UD_10_017]
* Function Name: CheckFourByteFilterCfg
* Description  : R-Switch3 4 Byte Filter Configuration Check
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckFourByteFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_4BFCfgType *Lp4BFEntry;

    LucRetVal = E_OK;

    if (pPfConfig->ulFourBFEntryNum <= (uint32)PFL_4BF_NUM)
    {
        /* 4 Byte Filter Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pPfConfig->ulFourBFEntryNum; LulEntryIdx++)
        {
            Lp4BFEntry = &pPfConfig->pFourBF[LulEntryIdx];
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)Lp4BFEntry->ucCfgFlag)
            {
                if ((uint32)Lp4BFEntry->ucUnitMode <= (uint32)UNITMODE_PRECISE)
                {
                    /* Offset value range check is not needed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                    break;
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_018]:[Gen5GW_EthSwtCont_UD_10_018]
* Function Name: CheckRangeByteFilterCfg
* Description  : R-Switch3 Range Filter Configuration Check
* Arguments    : pPfConfig -
*                    Perfect Filter Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckRangeFilterCfg(const R_EthSwtCont_PFCfgType *pPfConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_RFCfgType *LpRFEntry;

    LucRetVal = E_OK;

    if (pPfConfig->ulRFEntryNum <= (uint32)PFL_RF_NUM)
    {
        /* Range Filter Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pPfConfig->ulRFEntryNum; LulEntryIdx++)
        {
            LpRFEntry = &pPfConfig->pRF[LulEntryIdx];
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)LpRFEntry->ucCfgFlag)
            {
                /* TODO: Check Start Value and End Value < 4096 when Offset mode is VLAN TAG */

                LucRetVal = CheckPerfectFilterOffset((uint8)ETHSWTCONT_REG_SET, LpRFEntry->ucOffsetMode,
                    LpRFEntry->ucOffset 
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        , ucSID
                    #endif
                    );

                if ((uint32)E_OK == LucRetVal)
                {
                    /* Next entry */
                }
                else
                {
                    /* Exit loop */
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                    break;
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_049]:[Gen5GW_EthSwtCont_UD_10_049]
* Function Name: CheckPerfectFilterOffset
* Description  : R-Switch3 Perfect Filter filter mode and offset value Check
* Arguments    : ucFilter -
*                    Perfect Filter filter type
*                ucFilterMode -
*                    Perfect Filter filter mode
*                ucOffset -
*                    Perfect Filter offset value
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckPerfectFilterOffset(const uint8 ucFilter, const uint8 ucFilterMode, const uint8 ucOffset 
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    switch ((uint32)ucFilterMode)
    {
    case FILTERMODE_OFFSET:
        /* In Offset mode, Offset value range check is not needed */
        break;
    case FILTERMODE_VLANTAG:
        switch ((uint32)EthSwtCont_GucVlanMode)
        {
        case VLANMODE_CTAG:
            if (ETHSWTCONT_REG_SET == (uint32)ucFilter)
            {
                /* Range Filter Offset check */
                if (((uint32)OFFSET_CTAG_BYTE0 == (uint32)ucOffset) ||
                    ((uint32)OFFSET_CTAG_BYTE1 == (uint32)ucOffset))
                {
                    /* Do nothing */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                }
            }
            else
            {
                /* 2 Byte Filter Offset check */
                if ((uint32)OFFSET_CTAG_BYTE0 == (uint32)ucOffset)
                {
                    /* Do nothing */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                }
            }
            break;
        case VLANMODE_SCTAG:
            if (ETHSWTCONT_REG_SET == (uint32)ucFilter)
            {
                /* Range Filter Offset check */
                if ((uint32)ucOffset <= (uint32)OFFSET_CTAG_BYTE1)
                {
                    /* Do nothing */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                }
            }
            else
            {
                /* 2 Byte Filter Offset check */
                if (((uint32)OFFSET_STAG_BYTE0 == (uint32)ucOffset) ||
                    ((uint32)OFFSET_CTAG_BYTE0 == (uint32)ucOffset))
                {
                    /* Do nothing */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
                    #endif
                }
            }
            break;
        default:
            /* VLANMODE_NOVLAN case */
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
            #endif
            break;
        }
        break;
    default:
        /* Invalid filter mode */
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_PF);
        #endif
        break;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_020]:[Gen5GW_EthSwtCont_UD_10_020]
* Function Name: SetL2RuleTbl
* Description  : R-Switch3 L2 Table setting
* Arguments    : pL2Config -
*                    L2 Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL2RuleTbl(const R_EthSwtCont_L2CfgType *pL2Config)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulIdx;

    /* MAC Table reset flow */
    LucRetVal = ResetMacTbl();
    if ((uint32)E_OK == LucRetVal)
    {
        /* VLAN Table reset flow */
        LucRetVal = ResetVlanTbl();
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* Set MAC entry configurations */
        EthSwtCont_GpMfwdReg->FWMACTEC0 = pL2Config->usMacUnsecEntry;

        /* Set MAC entry HW learning */
        LulRegisterVal = (((uint32)pL2Config->ucHwLearnFilter3 << SHIFT_31BIT)|
                          ((uint32)pL2Config->ucHwLearnFilter2 << SHIFT_30BIT)|
                          ((uint32)pL2Config->usHwLearnEndAddr << SHIFT_16BIT)|
                          ((uint32)pL2Config->ucHwLearnFilter1 << SHIFT_15BIT)|
                          ((uint32)pL2Config->ucHwLearnFilter0 << SHIFT_14BIT)|
                          (uint32)pL2Config->usHwLearnStartAddr);
        EthSwtCont_GpMfwdReg->FWMACHWLC0 = LulRegisterVal;

        /* FWMACHWLC1 and FWMACHWLC2i.MACDENPPi is read only register. So not setting */
        /* FFS is hang up to access FWMACHWLC2i (i = 13, 14) */
        for (LulIdx = IDX_0; LulIdx < (uint32)13U; LulIdx++)
        {
            EthSwtCont_GpMfwdReg->FWMACHWLC2i[LulIdx] = (uint32)pL2Config->aaPerPortDynamicEntryLimitNum[LulIdx];
        }

        /* VLAN Table Max unsecure entry setting */
        LulRegisterVal = ((uint32)pL2Config->usVlanMaxUnsecEntry << SHIFT_16BIT);
        EthSwtCont_GpMfwdReg->FWVLANTEC = LulRegisterVal;

        LucRetVal = SetMacTbl(pL2Config);
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = SetVlanTbl(pL2Config);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_021]:[Gen5GW_EthSwtCont_UD_10_021]
* Function Name: SetMacTbl
* Description  : R-Switch3 MAC Table setting
* Arguments    : pL2Config -
*                    L2 Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetMacTbl(const R_EthSwtCont_L2CfgType *pL2Config)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;
    uint32 LulLearnResult;
    const R_EthSwtCont_MacTblCfgType *LpMacTblEntry;
    uint32 LulLoopCnt;

    LucRetVal = E_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < pL2Config->ulMacTblEntryNum; LulEntryIdx++)
    {
        LpMacTblEntry = &pL2Config->pMacTable[LulEntryIdx];
        if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)LpMacTblEntry->ucCfgFlag)
        {
            EthSwtCont_GpMfwdReg->FWMACTL0 = (uint32)LpMacTblEntry->usEntryAddress;

            LulRegisterVal = (((uint32)LpMacTblEntry->ucEntryDel << SHIFT_31BIT) |
                ((uint32)LpMacTblEntry->ucFilterPriority << SHIFT_20BIT) |
                ((uint32)LpMacTblEntry->ucRoutPriority << SHIFT_16BIT) |
                ((uint32)LpMacTblEntry->ucSrcMacBL << SHIFT_13BIT) |
                ((uint32)LpMacTblEntry->ucDestMacBL << SHIFT_12BIT) |
                ((uint32)LpMacTblEntry->ucHwLearnDisable << SHIFT_10BIT) |
                ((uint32)LpMacTblEntry->ucDynamicEntry << SHIFT_9BIT));
            EthSwtCont_GpMfwdReg->FWMACTL1 = LulRegisterVal;

            /* Set MSDU and Gate to entry */
            LulRegisterVal = (((uint32)LpMacTblEntry->ucMsduValid << SHIFT_31BIT) |
                ((uint32)LpMacTblEntry->ucMsduNo << SHIFT_16BIT) |
                ((uint32)LpMacTblEntry->ucGateValid << SHIFT_15BIT) |
                (uint32)LpMacTblEntry->ucGateNo);
            EthSwtCont_GpMfwdReg->FWMACTL2 = LulRegisterVal;

            /* Set Meter and FRER to entry */
            LulRegisterVal = (((uint32)LpMacTblEntry->ucMeterValid << SHIFT_31BIT) |
                ((uint32)LpMacTblEntry->ucMeterNo << SHIFT_16BIT) |
                ((uint32)LpMacTblEntry->ucFrerValid << SHIFT_15BIT) |
                (uint32)LpMacTblEntry->ucFrerNo);
            EthSwtCont_GpMfwdReg->FWMACTL3 = LulRegisterVal;

            /* Set Source/Destination Source Lock Vector to entry */
            LulRegisterVal = (((uint32)LpMacTblEntry->usDestSrcLockVec << SHIFT_16BIT) |
                (uint32)LpMacTblEntry->usSrcSrcLockVec);
            EthSwtCont_GpMfwdReg->FWMACTL4 = LulRegisterVal;

            /* Set MAC Address to entry */
            EthSwtCont_GpMfwdReg->FWMACTL5 =
                LpMacTblEntry->aaMacAddr[ETHSWTCONT_MACADDR_UPPER];
            EthSwtCont_GpMfwdReg->FWMACTL6 =
                LpMacTblEntry->aaMacAddr[ETHSWTCONT_MACADDR_DOWNER];

            /* Set CPU Sub-destination to entry */
            EthSwtCont_GpMfwdReg->FWMACTL7i[ETHSWTCONT_SEC_CPU] =
                (uint32)LpMacTblEntry->aaCpuSubDest[ETHSWTCONT_SEC_CPU];
            EthSwtCont_GpMfwdReg->FWMACTL7i[ETHSWTCONT_UNSEC_CPU] =
                (uint32)LpMacTblEntry->aaCpuSubDest[ETHSWTCONT_UNSEC_CPU];

            /* FWMACTL8 is trigger of learning */
            LulRegisterVal = (((uint32)LpMacTblEntry->ucCpuMrrEnable << SHIFT_BIT_CMEL) |
                ((uint32)LpMacTblEntry->ucEthMrrEnable << SHIFT_BIT_EMEL) |
                ((uint32)LpMacTblEntry->ucIpvUpdate << SHIFT_BIT_IPUL) |
                ((uint32)LpMacTblEntry->ucIpvVal << SHIFT_BIT_IPVL) |
                (uint32)LpMacTblEntry->usDestVec);
            EthSwtCont_GpMfwdReg->FWMACTL8 = LulRegisterVal;

            LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
            /* Wait for learning entry complete */
            do
            {
                if (LulLoopCnt > (uint32)NUM0)
                {
                    LulLoopCnt--;
                }
                else
                {
                    /* Timeout */
                    LucRetVal = E_NOT_OK;
                    #ifdef ETHSWTCONT_E_TIMEOUT
                    /* Report to DET */
                    (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
                    #endif
                    break;
                }
                LulRegisterVal = (EthSwtCont_GpMfwdReg->FWMACTLR >> SHIFT_31BIT);
            } while (ETHSWTCONT_REG_SET == LulRegisterVal);

            if ((uint32)E_OK == LucRetVal)
            {
                LulLearnResult = ((EthSwtCont_GpMfwdReg->FWMACTLR) & MASK_6BIT);
                if ((uint32)NUM0 == LulLearnResult)
                {
                    /* Learning Success */
                }
                else
                {
                    LucRetVal = DEMCheckMACLearnFail((uint8)LulLearnResult);
                }

            }
            else
            {
                /* Do nothing */
            }
            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
        else
        {
            /* Skip this entry */
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_022]:[Gen5GW_EthSwtCont_UD_10_022]
* Function Name: CheckMacTblCfg
* Description  : R-Switch3 MAC Table Configuration Check
* Arguments    : pL2Config -
*                    L2 Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckMacTblCfg(const R_EthSwtCont_L2CfgType *pL2Config
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_MacTblCfgType *LpMacTblEntry;

    LucRetVal = E_OK;

    if (pL2Config->ulMacTblEntryNum <= (uint32)MAC_TBLENTRY_NUM)
    {
        /* MAC Table Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pL2Config->ulMacTblEntryNum; LulEntryIdx++)
        {
            LpMacTblEntry = &pL2Config->pMacTable[LulEntryIdx];
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)LpMacTblEntry->ucCfgFlag)
            {
                if (((uint32)LpMacTblEntry->ucDynamicEntry <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpMacTblEntry->ucHwLearnDisable <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpMacTblEntry->ucEntryDel <= ETHSWTCONT_REG_SET) &&
                    (LpMacTblEntry->aaMacAddr[IDX_0] <= MASK_16BIT) &&
                    ((uint32)LpMacTblEntry->usDestSrcLockVec <= ETHSWTCONT_PORT_MASK) &&
                    ((uint32)LpMacTblEntry->usSrcSrcLockVec <= ETHSWTCONT_PORT_MASK) &&
                    ((uint32)LpMacTblEntry->aaCpuSubDest[ETHSWTCONT_SEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
                    ((uint32)LpMacTblEntry->aaCpuSubDest[ETHSWTCONT_UNSEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
                    ((uint32)LpMacTblEntry->usDestVec <= ETHSWTCONT_PORT_MASK) &&
                    ((uint32)LpMacTblEntry->ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                    ((uint32)LpMacTblEntry->ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpMacTblEntry->ucEthMrrEnable <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpMacTblEntry->ucCpuMrrEnable <= ETHSWTCONT_REG_SET))
                {
                    /* Configuration check passed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                                ucSID, ETHSWTCONT_E_CFG_MACTBL);
                    #endif
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_MACTBL);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_023]:[Gen5GW_EthSwtCont_UD_10_023]
* Function Name: SetVlanTbl
* Description  : R-Switch3 VLAN Table setting
* Arguments    : pL2Config -
*                    L2 Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetVlanTbl(const R_EthSwtCont_L2CfgType *pL2Config)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;
    uint32 LulLearnResult;
    const R_EthSwtCont_VlanTblCfgType *LpVlanTblEntry;
    uint32 LulLoopCnt;

    LucRetVal = E_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < pL2Config->ulVlanTblEntryNum; LulEntryIdx++)
    {
        LpVlanTblEntry = &pL2Config->pVlanTable[LulEntryIdx];
        if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)LpVlanTblEntry->ucCfgFlag)
        {
            LulRegisterVal = (((uint32)LpVlanTblEntry->ucEntryDel << SHIFT_31BIT) |
                ((uint32)LpVlanTblEntry->ucFilterPriority << SHIFT_20BIT) |
                ((uint32)LpVlanTblEntry->ucRoutPriority << SHIFT_16BIT) |
                ((uint32)LpVlanTblEntry->ucBL << SHIFT_12BIT) |
                ((uint32)LpVlanTblEntry->ucHwLearnDisable << SHIFT_10BIT) |
                ((uint32)LpVlanTblEntry->ucSecLv << SHIFT_8BIT));
            EthSwtCont_GpMfwdReg->FWVLANTL0 = LulRegisterVal;
            /* Set VLAN ID to entry */
            EthSwtCont_GpMfwdReg->FWVLANTL1 = LpVlanTblEntry->usVlanId;

            /* Set MSDU and Gate to entry */
            LulRegisterVal = (((uint32)LpVlanTblEntry->ucMsduValid << SHIFT_31BIT) |
                ((uint32)LpVlanTblEntry->ucMsduNo << SHIFT_16BIT) |
                ((uint32)LpVlanTblEntry->ucGateValid << SHIFT_15BIT) |
                (uint32)LpVlanTblEntry->ucGateNo);
            EthSwtCont_GpMfwdReg->FWVLANTL2 = LulRegisterVal;

            /* Set Meter and FRER to entry */
            LulRegisterVal = (((uint32)LpVlanTblEntry->ucMeterValid << SHIFT_31BIT) |
                ((uint32)LpVlanTblEntry->ucMeterNo << SHIFT_16BIT) |
                ((uint32)LpVlanTblEntry->ucFrerValid << SHIFT_15BIT) |
                (uint32)LpVlanTblEntry->ucFrerNo);
            EthSwtCont_GpMfwdReg->FWVLANTL3 = LulRegisterVal;

            /* Set Source Lock Vector to entry */
            EthSwtCont_GpMfwdReg->FWVLANTL4 = ((uint32)LpVlanTblEntry->usSrcLockVec << SHIFT_16BIT) |
                                               ((uint32)LpVlanTblEntry->ucRoutValid << SHIFT_15BIT) |
                                               ((uint32)LpVlanTblEntry->usRoutNo);

            /* Set Forwarding Mask Vector to entry */
            EthSwtCont_GpMfwdReg->FWVLANTL5 = LpVlanTblEntry->usFwdMaskVec;

            /* Set CPU Sub-destination to entry */
            EthSwtCont_GpMfwdReg->FWVLANTL6i[ETHSWTCONT_SEC_CPU] =
                (uint32)LpVlanTblEntry->aaCpuSubDest[ETHSWTCONT_SEC_CPU];
            EthSwtCont_GpMfwdReg->FWVLANTL6i[ETHSWTCONT_UNSEC_CPU] =
                (uint32)LpVlanTblEntry->aaCpuSubDest[ETHSWTCONT_UNSEC_CPU];

            /* FWVLANTL4 is trigger of learning */
            LulRegisterVal = (((uint32)LpVlanTblEntry->ucCpuMrrEnable << SHIFT_BIT_CMEL) |
                ((uint32)LpVlanTblEntry->ucEthMrrEnable << SHIFT_BIT_EMEL) |
                ((uint32)LpVlanTblEntry->ucIpvUpdate << SHIFT_BIT_IPUL) |
                ((uint32)LpVlanTblEntry->ucIpvVal << SHIFT_BIT_IPVL) |
                (uint32)LpVlanTblEntry->usDestVec);
            EthSwtCont_GpMfwdReg->FWVLANTL7 = LulRegisterVal;

            LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
            /* Wait for learning entry complete */
            do
            {
                if (LulLoopCnt > (uint32)NUM0)
                {
                    LulLoopCnt--;
                }
                else
                {
                    /* Timeout */
                    LucRetVal = E_NOT_OK;
                    #ifdef ETHSWTCONT_E_TIMEOUT
                    /* Report to DET */
                    (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
                    #endif
                    break;
                }
                LulRegisterVal = (EthSwtCont_GpMfwdReg->FWVLANTLR >> SHIFT_31BIT);
            } while ((uint32)ETHSWTCONT_REG_SET == LulRegisterVal);

            if ((uint32)E_OK == LucRetVal)
            {
                LulLearnResult = ((EthSwtCont_GpMfwdReg->FWVLANTLR) & MASK_4BIT);
                if ((uint32)NUM0 == LulLearnResult)
                {
                    /* Learning Success */
                }
                else
                {
                    LucRetVal = DEMCheckVLANLearnFail((uint8)LulLearnResult);
                }

            }
            else
            {
                /* Do nothing */
            }
            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
        else
        {
            /* Skip this entry */
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_024]:[Gen5GW_EthSwtCont_UD_10_024]
* Function Name: CheckVlanTblCfg
* Description  : R-Switch3 VLAN Table Configuration Check
* Arguments    : pL2Config -
*                    L2 Table Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckVlanTblCfg(const R_EthSwtCont_L2CfgType *pL2Config
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_VlanTblCfgType *LpVlanTblEntry;

    LucRetVal = E_OK;

    if (pL2Config->ulVlanTblEntryNum <= (uint32)VLAN_TBLENTRY_NUM)
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_VLANTBL);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* VLAN Table Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pL2Config->ulVlanTblEntryNum; LulEntryIdx++)
        {
            LpVlanTblEntry = &pL2Config->pVlanTable[LulEntryIdx];
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)LpVlanTblEntry->ucCfgFlag)
            {
                if (((uint32)LpVlanTblEntry->ucSecLv <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpVlanTblEntry->ucHwLearnDisable <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpVlanTblEntry->ucEntryDel <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpVlanTblEntry->usVlanId < (uint32)VLANID_NUM) &&
                    ((uint32)LpVlanTblEntry->usSrcLockVec <= ETHSWTCONT_PORT_MASK) &&
                    ((uint32)LpVlanTblEntry->aaCpuSubDest[ETHSWTCONT_SEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
                    ((uint32)LpVlanTblEntry->aaCpuSubDest[ETHSWTCONT_UNSEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
                    ((uint32)LpVlanTblEntry->usDestVec <= ETHSWTCONT_PORT_MASK) &&
                    ((uint32)LpVlanTblEntry->ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                    ((uint32)LpVlanTblEntry->ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpVlanTblEntry->ucEthMrrEnable <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpVlanTblEntry->ucCpuMrrEnable <= ETHSWTCONT_REG_SET))
                {
                    /* Configuration check passed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, 
                                                                                ucSID, ETHSWTCONT_E_CFG_VLANTBL);
                    #endif
                }
            }
            else
            {
                /* Skip this entry */
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_030]:[Gen5GW_EthSwtCont_UD_10_030]
* Function Name: SetStreamFilterSetting
* Description  : Stream Filter setting
* Arguments    : pStreamGenConfig -
*                    Stream Filter General Configuration
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetStreamFilterSetting(const R_EthSwtCont_StreamGenCfgType *pStreamGenConfig)
{
    uint32 LulRegisterVal;
    const R_EthSwtCont_StreamFlagType *LpStreamFlags;
    const R_EthSwtCont_HashFlagType *LpHashFlags;
    const R_EthSwtCont_L2StreamFlagType *LpL2StreamFlags;

    LpStreamFlags = &pStreamGenConfig->stIpv4InStreamFlags;
    LpHashFlags = &pStreamGenConfig->stIpv4InHashFlags;
    LulRegisterVal = (((uint32)LpStreamFlags->ucDestPortFlag << SHIFT_24BIT) |
        ((uint32)LpStreamFlags->ucIpPart1Flag << SHIFT_23BIT) |
        ((uint32)LpStreamFlags->ucIpPart0Flag << SHIFT_22BIT) |
        ((uint32)LpStreamFlags->ucCTagDeiFlag << SHIFT_21BIT) |
        ((uint32)LpStreamFlags->ucCTagPcpFlag << SHIFT_20BIT) |
        ((uint32)LpStreamFlags->ucCTagVlanIdFlag << SHIFT_19BIT) |
        ((uint32)LpStreamFlags->ucSTagDeiFlag << SHIFT_18BIT) |
        ((uint32)LpStreamFlags->ucSTagPcpFlag << SHIFT_17BIT) |
        ((uint32)LpStreamFlags->ucSTagVlanIdFlag << SHIFT_16BIT) |
        ((uint32)LpHashFlags->ucDestPortFlag << SHIFT_12BIT) |
        ((uint32)LpHashFlags->ucSrcPortFlag << SHIFT_11BIT) |
        ((uint32)LpHashFlags->ucProtocolFlag << SHIFT_10BIT) |
        ((uint32)LpHashFlags->ucDestIpFlag << SHIFT_9BIT) |
        ((uint32)LpHashFlags->ucSrcIpFlag << SHIFT_8BIT) |
        ((uint32)LpHashFlags->ucCTagDeiFlag << SHIFT_7BIT) |
        ((uint32)LpHashFlags->ucCTagPcpFlag << SHIFT_6BIT) |
        ((uint32)LpHashFlags->ucCTagVlanIdFlag << SHIFT_5BIT) |
        ((uint32)LpHashFlags->ucSTagDeiFlag << SHIFT_4BIT) |
        ((uint32)LpHashFlags->ucSTagPcpFlag << SHIFT_3BIT) |
        ((uint32)LpHashFlags->ucSTagVlanIdFlag << SHIFT_2BIT) |
        ((uint32)LpHashFlags->ucSrcMacFlag << SHIFT_1BIT) |
        ((uint32)LpHashFlags->ucDestMacFlag));
    EthSwtCont_GpMfwdReg->FWIP4SC = LulRegisterVal;

    LpStreamFlags = &pStreamGenConfig->stIpv6InStreamFlags;
    LpHashFlags = &pStreamGenConfig->stIpv6InHashFlags;
    LulRegisterVal = (((uint32)LpStreamFlags->ucDestPortFlag << SHIFT_24BIT) |
        ((uint32)LpStreamFlags->ucIpPart1Flag << SHIFT_23BIT) |
        ((uint32)LpStreamFlags->ucIpPart0Flag << SHIFT_22BIT) |
        ((uint32)LpStreamFlags->ucCTagDeiFlag << SHIFT_21BIT) |
        ((uint32)LpStreamFlags->ucCTagPcpFlag << SHIFT_20BIT) |
        ((uint32)LpStreamFlags->ucCTagVlanIdFlag << SHIFT_19BIT) |
        ((uint32)LpStreamFlags->ucSTagDeiFlag << SHIFT_18BIT) |
        ((uint32)LpStreamFlags->ucSTagPcpFlag << SHIFT_17BIT) |
        ((uint32)LpStreamFlags->ucSTagVlanIdFlag << SHIFT_16BIT) |
        ((uint32)LpHashFlags->ucDestPortFlag << SHIFT_12BIT) |
        ((uint32)LpHashFlags->ucSrcPortFlag << SHIFT_11BIT) |
        ((uint32)LpHashFlags->ucProtocolFlag << SHIFT_10BIT) |
        ((uint32)LpHashFlags->ucDestIpFlag << SHIFT_9BIT) |
        ((uint32)LpHashFlags->ucSrcIpFlag << SHIFT_8BIT) |
        ((uint32)LpHashFlags->ucCTagDeiFlag << SHIFT_7BIT) |
        ((uint32)LpHashFlags->ucCTagPcpFlag << SHIFT_6BIT) |
        ((uint32)LpHashFlags->ucCTagVlanIdFlag << SHIFT_5BIT) |
        ((uint32)LpHashFlags->ucSTagDeiFlag << SHIFT_4BIT) |
        ((uint32)LpHashFlags->ucSTagPcpFlag << SHIFT_3BIT) |
        ((uint32)LpHashFlags->ucSTagVlanIdFlag << SHIFT_2BIT) |
        ((uint32)LpHashFlags->ucSrcMacFlag << SHIFT_1BIT) |
        ((uint32)LpHashFlags->ucDestMacFlag));
    EthSwtCont_GpMfwdReg->FWIP6SC = LulRegisterVal;

    LulRegisterVal =
        (((uint32)pStreamGenConfig->aaIpv6Offset[IDX_1] << SHIFT_20BIT) |
        ((uint32)pStreamGenConfig->aaIpv6OffsetMode[IDX_1] << SHIFT_16BIT) |
        ((uint32)pStreamGenConfig->aaIpv6Offset[IDX_0] << SHIFT_4BIT) |
        ((uint32)pStreamGenConfig->aaIpv6OffsetMode[IDX_0]));
    EthSwtCont_GpMfwdReg->FWIP6OC = LulRegisterVal;

    LpL2StreamFlags = &pStreamGenConfig->stL2InStreamFlags;
    LulRegisterVal = (((uint32)LpL2StreamFlags->ucCTagDeiFlag << SHIFT_7BIT) |
        ((uint32)LpL2StreamFlags->ucCTagPcpFlag << SHIFT_6BIT) |
        ((uint32)LpL2StreamFlags->ucCTagVlanIdFlag << SHIFT_5BIT) |
        ((uint32)LpL2StreamFlags->ucSTagDeiFlag << SHIFT_4BIT) |
        ((uint32)LpL2StreamFlags->ucSTagPcpFlag << SHIFT_3BIT) |
        ((uint32)LpL2StreamFlags->ucSTagVlanIdFlag << SHIFT_2BIT) |
        ((uint32)LpL2StreamFlags->ucSrcMacFlag << SHIFT_1BIT) |
        ((uint32)LpL2StreamFlags->ucDestMacFlag));
    EthSwtCont_GpMfwdReg->FWL2SC = LulRegisterVal;

    LulRegisterVal = (((uint32)pStreamGenConfig->usIpv6HashEquat << SHIFT_16BIT) |
        ((uint32)pStreamGenConfig->usIpv4HashEquat));
    EthSwtCont_GpMfwdReg->FWSFHEC = LulRegisterVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_031]:[Gen5GW_EthSwtCont_UD_10_031]
* Function Name: CheckStreamFilterCfg
* Description  : Stream Filter Configuration Check
* Arguments    : pStreamConfig -
*                    Stream Filter Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckStreamFilterCfg(const R_EthSwtCont_StreamCfgType *pStreamConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry;

    LucRetVal = E_OK;

    /* L3 Table Entry number check */
    if (pStreamConfig->ulStreamFilterEntryNum <= (uint32)STREAM_ENTRY_NUM)
    {
        /* Stream Filter Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pStreamConfig->ulStreamFilterEntryNum; LulEntryIdx++)
        {
            LpStreamFilterEntry = &pStreamConfig->pStreamFilter[LulEntryIdx];
            if (((uint32)LpStreamFilterEntry->aaDestMacAddr[IDX_0] <= MASK_16BIT) &&
                ((uint32)LpStreamFilterEntry->aaSrcMacAddr[IDX_0] <= MASK_16BIT) &&
                ((uint32)LpStreamFilterEntry->ucSTagDei <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->ucSTagPcp < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)LpStreamFilterEntry->usSTagVlanId < (uint32)VLANID_NUM) &&
                ((uint32)LpStreamFilterEntry->ucCTagDei <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->ucCTagPcp < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)LpStreamFilterEntry->usCTagVlanId < (uint32)VLANID_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucEntryDel <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucGateNo < (uint32)ETHSWTCONT_PSFP_GATE_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucGateValid <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucMsduNo < (uint32)ETHSWTCONT_PSFP_MSDU_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucMsduValid <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucFrerNo < (uint32)ETHSWTCONT_PSFP_RECE_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucFrerValid <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucMeterNo < (uint32)ETHSWTCONT_PSFP_MTR_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucMeterValid <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucRoutValid <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.usSrcLockVec <= ETHSWTCONT_PORT_MASK) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.aaCpuSubDest[ETHSWTCONT_SEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.aaCpuSubDest[ETHSWTCONT_UNSEC_CPU] < (uint32)AXI_CHAIN_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.usDestVec <= ETHSWTCONT_PORT_MASK) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucEthMrrEnable <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpStreamFilterEntry->stL3TblCfg.ucCpuMrrEnable <= ETHSWTCONT_REG_SET))
            {
                LucRetVal = CheckFrameFormatVec(LpStreamFilterEntry
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    ,ucSID
                    #endif
                    );
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                                  ucSID, ETHSWTCONT_E_CFG_STREAM);
                        #endif
            }

            if ((uint32)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /* Exit Loop */
                break;
            }
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                  ucSID, ETHSWTCONT_E_CFG_STREAM);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_046]:[Gen5GW_EthSwtCont_UD_10_046]
* Function Name: CheckStreamFilterGenCfg
* Description  : Stream Filter General Configuration Check
* Arguments    : pStreamGenConfig -
*                    Stream Filter General Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckStreamFilterGenCfg(const R_EthSwtCont_StreamGenCfgType *pStreamGenConfig)
{
    uint8 LucRetVal;
    const R_EthSwtCont_StreamFlagType *LpIpv4StreamFlags;
    const R_EthSwtCont_StreamFlagType *LpIpv6StreamFlags;
    const R_EthSwtCont_L2StreamFlagType *LpL2StreamFlags;
    const R_EthSwtCont_HashFlagType *LpIpv4HashFlags;
    const R_EthSwtCont_HashFlagType *LpIpv6HashFlags;

    LucRetVal = E_OK;
    LpIpv4StreamFlags = &pStreamGenConfig->stIpv4InStreamFlags;
    LpIpv6StreamFlags = &pStreamGenConfig->stIpv6InStreamFlags;
    LpIpv4HashFlags = &pStreamGenConfig->stIpv4InHashFlags;
    LpIpv6HashFlags = &pStreamGenConfig->stIpv6InHashFlags;
    LpL2StreamFlags = &pStreamGenConfig->stL2InStreamFlags;

    /* IPv4/IPv6/L2 Stream Filter General Configuration check */
    if (((uint32)LpIpv4StreamFlags->ucIpPart0Flag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4StreamFlags->ucIpPart1Flag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4StreamFlags->ucDestPortFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucDestMacFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucSrcMacFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucDestIpFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucSrcIpFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucDestPortFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucSrcPortFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv4HashFlags->ucProtocolFlag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv6StreamFlags->ucIpPart0Flag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv6StreamFlags->ucIpPart1Flag <= ETHSWTCONT_REG_SET) &&
        ((uint32)LpIpv6StreamFlags->ucDestPortFlag <= ETHSWTCONT_REG_SET))
    {    
        if (((uint32)LpIpv6HashFlags->ucDestMacFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpIpv6HashFlags->ucSrcMacFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpIpv6HashFlags->ucDestIpFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpIpv6HashFlags->ucSrcIpFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpIpv6HashFlags->ucDestPortFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpIpv6HashFlags->ucSrcPortFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpIpv6HashFlags->ucProtocolFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)pStreamGenConfig->aaIpv6OffsetMode[IDX_0] <= (uint32)ETHSWTCONT_IPOFFSET_DEST) &&
            ((uint32)pStreamGenConfig->aaIpv6OffsetMode[IDX_1] <= (uint32)ETHSWTCONT_IPOFFSET_DEST) &&
            ((uint32)pStreamGenConfig->aaIpv6Offset[IDX_0] <= (uint32)IPOFFSET_MAX) &&
            ((uint32)pStreamGenConfig->aaIpv6Offset[IDX_1] <= (uint32)IPOFFSET_MAX) &&
            ((uint32)LpL2StreamFlags->ucDestMacFlag <= ETHSWTCONT_REG_SET) &&
            ((uint32)LpL2StreamFlags->ucSrcMacFlag <= ETHSWTCONT_REG_SET))
        {
            /* Do nothing */
            switch ((uint32)EthSwtCont_GucVlanMode)
            {
            case VLANMODE_CTAG:
                /* VLAN mode C-TAG case. S-TAG VLAN related flag should be Clear. */
                if ((ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucSTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucSTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucSTagVlanIdFlag) &&
                    ((uint32)LpIpv4StreamFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucSTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucSTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucSTagVlanIdFlag) &&
                    ((uint32)LpIpv4HashFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucSTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucSTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucSTagVlanIdFlag))
                {
                    if (((uint32)LpIpv6StreamFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6StreamFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6StreamFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucSTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucSTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucSTagVlanIdFlag) &&
                        ((uint32)LpIpv6HashFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucSTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucSTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucSTagVlanIdFlag) &&
                        ((uint32)LpL2StreamFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET))
                    {
                        /* Configuration check passed */
                    }
                    else
                    {
                        LucRetVal = E_NOT_OK;
                        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
                        #endif
                    }
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
                    #endif
                }
                break;
            case VLANMODE_SCTAG:
                /* VLAN mode S-TAG case. Flag should be SET or CLR. */
                if (((uint32)LpIpv4StreamFlags->ucSTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucSTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucSTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4StreamFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucSTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucSTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucSTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv4HashFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv6StreamFlags->ucSTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv6StreamFlags->ucSTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                    ((uint32)LpIpv6StreamFlags->ucSTagVlanIdFlag <= ETHSWTCONT_REG_SET))
                {
                    if (((uint32)LpIpv6StreamFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6StreamFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6StreamFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucSTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucSTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucSTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpIpv6HashFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucSTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucSTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucSTagVlanIdFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucCTagDeiFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucCTagPcpFlag <= ETHSWTCONT_REG_SET) &&
                        ((uint32)LpL2StreamFlags->ucCTagVlanIdFlag <= ETHSWTCONT_REG_SET))
                    {
                        /* Configuration check passed */
                    }
                    else
                    {
                        LucRetVal = E_NOT_OK;
                        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
                        #endif
                    }
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
                    #endif
                }
                break;
            default:
                /* VLAN mode NOVLAN case. VLAN related flag should be Clear. */
                if ((ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucSTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucSTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucSTagVlanIdFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucCTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucCTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4StreamFlags->ucCTagVlanIdFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucSTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucSTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucSTagVlanIdFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucCTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucCTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv4HashFlags->ucCTagVlanIdFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucSTagDeiFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucSTagPcpFlag) &&
                    (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucSTagVlanIdFlag))
                {
                     if((ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucCTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucCTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6StreamFlags->ucCTagVlanIdFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucSTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucSTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucSTagVlanIdFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucCTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucCTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpIpv6HashFlags->ucCTagVlanIdFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucSTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucSTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucSTagVlanIdFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucCTagDeiFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucCTagPcpFlag) &&
                        (ETHSWTCONT_REG_CLR == (uint32)LpL2StreamFlags->ucCTagVlanIdFlag))
                    {
                        /* Configuration check passed */
                    }
                    else
                    {
                        LucRetVal = E_NOT_OK;
                        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
                        #endif
                    }
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
                    #endif
                }
                break;
            }
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
            #endif
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                  R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG_STREAM);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_032]:[Gen5GW_EthSwtCont_UD_10_032]
* Function Name: SetL2L3UpRuleTbl
* Description  : L2/L3 Update Table Setting
* Arguments    : pL2L3UpConfig -
*                    L2/L3 Update Table Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL2L3UpRuleTbl(const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig)
{
    uint8 LucRetVal;

    LucRetVal = ResetL2L3UpTbl();
    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = SetL2L3UpTbl(pL2L3UpConfig);
        if ((uint32)E_OK == LucRetVal)
        {
            SetL2L3UpRemapTbl(pL2L3UpConfig);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_033]:[Gen5GW_EthSwtCont_UD_10_033]
* Function Name: SetL2L3UpTbl
* Description  : L2/L3 Update Table Entry Setting
* Arguments    : pL2L3UpConfig -
*                    L2/L3 Update Table Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetL2L3UpTbl(const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;
    uint32 LulLearnResult;
    const R_EthSwtCont_L2L3UpTblCfgType *LpL2L3UpTblEntry;
    uint32 LulLoopCnt;

    LucRetVal = E_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < pL2L3UpConfig->ulL2L3UpTblEntryNum; LulEntryIdx++)
    {
        LpL2L3UpTblEntry = &pL2L3UpConfig->pL2L3UpTblCfg[LulEntryIdx];

        /* Set Routing Port Varid Flag and Routing Number to entry */
        LulRegisterVal = (((uint32)LpL2L3UpTblEntry->usRoutPortValid << SHIFT_16BIT) |
            (uint32)LpL2L3UpTblEntry->usRoutNo);
        EthSwtCont_GpMfwdReg->FWL23URL0 = LulRegisterVal;
        /* Set Update Flags and Dest MAC Addr to entry */
        LulRegisterVal = (((uint32)LpL2L3UpTblEntry->usFieldUpdateFlags << SHIFT_16BIT) |
            (uint32)LpL2L3UpTblEntry->aaDestMacAddr[ETHSWTCONT_MACADDR_UPPER]);
        EthSwtCont_GpMfwdReg->FWL23URL1 = LulRegisterVal;
        /* Set Dest MAC Addr to entry */
        EthSwtCont_GpMfwdReg->FWL23URL2 = LpL2L3UpTblEntry->aaDestMacAddr[ETHSWTCONT_MACADDR_DOWNER];
        /* Set VLAN Tag to entry */
        LulRegisterVal = (((uint32)LpL2L3UpTblEntry->ucSTagDei << SHIFT_31BIT) |
            ((uint32)LpL2L3UpTblEntry->ucSTagPcp << SHIFT_28BIT) |
            ((uint32)LpL2L3UpTblEntry->usSTagVlanId << SHIFT_16BIT) |
            ((uint32)LpL2L3UpTblEntry->ucCTagDei << SHIFT_15BIT) |
            ((uint32)LpL2L3UpTblEntry->ucCTagPcp << SHIFT_12BIT) |
            ((uint32)LpL2L3UpTblEntry->usCTagVlanId));
        /* FWL23URL3 is trigger of learning */
        EthSwtCont_GpMfwdReg->FWL23URL3 = LulRegisterVal;

        LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
        /* Wait for learning entry complete */
        do
        {
            if (LulLoopCnt > (uint32)NUM0)
            {
                LulLoopCnt--;
            }
            else
            {
                /* Timeout */
                LucRetVal = E_NOT_OK;
                #ifdef ETHSWTCONT_E_TIMEOUT
                /* Report to DET */
                (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
                #endif
                break;
            }
            LulRegisterVal = (EthSwtCont_GpMfwdReg->FWL23URLR >> SHIFT_31BIT);
        } while (ETHSWTCONT_REG_SET == LulRegisterVal);

        if ((uint32)E_OK == LucRetVal)
        {
            /* L2L3 does not have learning ECC fail so result masks with 2bit */
            LulLearnResult = ((EthSwtCont_GpMfwdReg->FWL23URLR) & MASK_2BIT);
            if ((uint32)NUM0 == LulLearnResult)
            {
                /* Learning Success */
            }
            else
            {
                LucRetVal = DEMCheckL2L3LearnFail((uint8)LulLearnResult);
            }
        }
        else
        {
            /* Do nothing */
        }
        if ((uint32)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            /* Exit Loop */
            break;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_047]:[Gen5GW_EthSwtCont_UD_10_047]
* Function Name: SetL2L3UpRemapTbl
* Description  : L2/L3 Update Remap Table Setting
* Arguments    : pL2L3UpConfig -
*                    L2/L3 Update Table Configuration
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetL2L3UpRemapTbl(const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig)
{
    uint32 LulRegisterVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_L2L3UpRemapCfgType *LpL2L3UpRemapEntry;

    for (LulEntryIdx = IDX_0; LulEntryIdx < pL2L3UpConfig->ulL2L3UpRemapEntryNum; LulEntryIdx++)
    {
        LpL2L3UpRemapEntry = &pL2L3UpConfig->pL2L3UpRemapCfg[LulEntryIdx];
        LulRegisterVal = (((uint32)LpL2L3UpRemapEntry->ucRemapEnable << SHIFT_28BIT) |
            ((uint32)LpL2L3UpRemapEntry->usRemapNewRuleNo << SHIFT_16BIT) |
            ((uint32)LpL2L3UpRemapEntry->ucRemapSrcPort << SHIFT_12BIT) |
            (uint32)LpL2L3UpRemapEntry->usRemapRuleNo);
        EthSwtCont_GpMfwdReg->FWL23URMCi[LulEntryIdx] = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_034]:[Gen5GW_EthSwtCont_UD_10_034]
* Function Name: CheckL2L3UpCfg
* Description  : L2/L3 Update Table Configuration Check
* Arguments    : pL2L3UpConfig -
*                    L2/L3 Update Table Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckL2L3UpCfg(const R_EthSwtCont_L2L3UpCfgType *pL2L3UpConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint32 LulEntryIdx;
    const R_EthSwtCont_L2L3UpTblCfgType *LpL2L3UpTblEntry;
    const R_EthSwtCont_L2L3UpRemapCfgType *LpL2L3UpRemapEntry;

    LucRetVal = E_OK;

    if ((pL2L3UpConfig->ulL2L3UpTblEntryNum <= (uint32)L2L3UP_TBLENTRY_NUM) &&
        (pL2L3UpConfig->ulL2L3UpRemapEntryNum <= (uint32)L2L3UP_REMAPRULE_NUM))
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, ucSID, ETHSWTCONT_E_CFG_L2L3UPTBL);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* L2/L3 Update Table Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pL2L3UpConfig->ulL2L3UpTblEntryNum; LulEntryIdx++)
        {
            LpL2L3UpTblEntry = &pL2L3UpConfig->pL2L3UpTblCfg[LulEntryIdx];

            if (((uint32)LpL2L3UpTblEntry->usRoutNo < (uint32)L2L3UP_TBLENTRY_NUM) &&
                ((uint32)LpL2L3UpTblEntry->usFieldUpdateFlags <= MASK_14BIT) &&
                ((uint32)LpL2L3UpTblEntry->usRoutPortValid <= ETHSWTCONT_PORT_MASK) &&
                ((uint32)LpL2L3UpTblEntry->aaDestMacAddr[IDX_0] <= MASK_16BIT) &&
                ((uint32)LpL2L3UpTblEntry->ucSTagDei <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpL2L3UpTblEntry->ucSTagPcp < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)LpL2L3UpTblEntry->usSTagVlanId < (uint32)VLANID_NUM) &&
                ((uint32)LpL2L3UpTblEntry->ucCTagDei <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpL2L3UpTblEntry->ucCTagPcp < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
                ((uint32)LpL2L3UpTblEntry->usCTagVlanId < (uint32)VLANID_NUM))
            {
                /* Configuration check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            ucSID, ETHSWTCONT_E_CFG_L2L3UPTBL);
                #endif
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* L2/L3 Update Remap Table Configuration check for all entries */
        for (LulEntryIdx = IDX_0; LulEntryIdx < pL2L3UpConfig->ulL2L3UpRemapEntryNum; LulEntryIdx++)
        {
            LpL2L3UpRemapEntry = &pL2L3UpConfig->pL2L3UpRemapCfg[LulEntryIdx];

            if (((uint32)LpL2L3UpRemapEntry->ucRemapEnable <= ETHSWTCONT_REG_SET) &&
                ((uint32)LpL2L3UpRemapEntry->ucRemapSrcPort < (uint32)ETHSWTCONT_PORT_NUM))
            {
                /* Configuration check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            ucSID, ETHSWTCONT_E_CFG_L2L3UPTBL);
                #endif
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_035]:[Gen5GW_EthSwtCont_UD_10_035]
* Function Name: ResetL3Tbl
* Description  : Reset L3 Table
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetL3Tbl(void)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulLoopCnt;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    LucRetVal = E_OK;

    /* Layer 3 table reset flow */
    EthSwtCont_GpMfwdReg->FWLTHTIM = ETHSWTCONT_REG_SET;

    /* Wait for L3 Table reset is complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = ((EthSwtCont_GpMfwdReg->FWLTHTIM >> SHIFT_1BIT) & MASK_1BIT);
    } while (ETHSWTCONT_REG_CLR == LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_036]:[Gen5GW_EthSwtCont_UD_10_036]
* Function Name: ResetMacTbl
* Description  : Reset MAC Table
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetMacTbl(void)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulLoopCnt;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    LucRetVal = E_OK;
    /* MAC Table reset flow */
    EthSwtCont_GpMfwdReg->FWMACTIM = ETHSWTCONT_REG_SET;

    /* Wait for MAC Table reset is complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = ((EthSwtCont_GpMfwdReg->FWMACTIM >> SHIFT_1BIT) & MASK_1BIT);
    } while (ETHSWTCONT_REG_CLR == LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_037]:[Gen5GW_EthSwtCont_UD_10_037]
* Function Name: ResetVlanTbl
* Description  : Reset VLAN Table
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetVlanTbl(void)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulLoopCnt;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    LucRetVal = E_OK;
    /* VLAN Table Reset flow */
    EthSwtCont_GpMfwdReg->FWVLANTIM = ETHSWTCONT_REG_SET;

    /* Wait for VLAN Table reset is complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = ((EthSwtCont_GpMfwdReg->FWVLANTIM >> SHIFT_1BIT) & MASK_1BIT);
    } while (ETHSWTCONT_REG_CLR == LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_038]:[Gen5GW_EthSwtCont_UD_10_038]
* Function Name: ResetL2L3UpTbl
* Description  : Reset L2/L3 Update Table
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) ResetL2L3UpTbl(void)
{
    uint8 LucRetVal;
    uint32 LulRegisterVal;
    uint32 LulLoopCnt;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    LucRetVal = E_OK;
    /* L2/L3 Update Table Reset flow */
    EthSwtCont_GpMfwdReg->FWL23UTIM = ETHSWTCONT_REG_SET;

    /* Wait for L2/L3 Update Table reset is complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        LulRegisterVal = ((EthSwtCont_GpMfwdReg->FWL23UTIM >> SHIFT_1BIT) & MASK_1BIT);
    } while (ETHSWTCONT_REG_CLR == LulRegisterVal);

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_039]:[Gen5GW_EthSwtCont_UD_10_039]
* Function Name: GenerateStreamId
* Description  : Generate Stream ID
* Arguments    : pStreamCfg -
*                    Stream Configuration
*                ulEntryIdx -
*                    Stream Filter entry index
*                aaStreamId -
*                    Stream ID
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) GenerateStreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId)
{
    uint8 LucRetVal;
    LucRetVal = E_OK;

    /* Select Stream ID Generation by Frame Format Vector */
    if ((pStreamCfg->pStreamFilter[ulEntryIdx].ucFrameFormatVec & FFV_MASK_IPV4) != NUM0)
    {
        LucRetVal = GetIpv4StreamId(pStreamCfg, ulEntryIdx, &aaStreamId[IDX_0]);
    }
    else if ((pStreamCfg->pStreamFilter[ulEntryIdx].ucFrameFormatVec & FFV_MASK_IPV6) != NUM0)
    {
        LucRetVal = GetIpv6StreamId(pStreamCfg, ulEntryIdx, &aaStreamId[IDX_0]);
    }
    else
    {
        GetL2StreamId(pStreamCfg, ulEntryIdx, &aaStreamId[IDX_0]);
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_040]:[Gen5GW_EthSwtCont_UD_10_040]
* Function Name: GetIpv4StreamId
* Description  : Get Stream ID for IPv4
* Arguments    : pStreamCfg -
*                    Stream Configuration
*                ulEntryIdx -
*                    Stream Filter entry index
*                aaStreamId -
*                    Stream ID
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) GetIpv4StreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId)
{
    uint8 LucRetVal;
    uint16 LusHashId;
    const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry;
    const R_EthSwtCont_StreamFlagType *LpStreamFlags;
    EthSwtCont_VlanTagType LstSTag;
    EthSwtCont_VlanTagType LstCTag;
    uint16 LusDestPort;

    /* Set Local Pointer */
    LpStreamFilterEntry = &pStreamCfg->pStreamFilter[ulEntryIdx];
    LpStreamFlags = &pStreamCfg->pStreamGenCfg->stIpv4InStreamFlags;

    /* Calculate Hash ID */
    LucRetVal = CalcHwHash(pStreamCfg, ulEntryIdx, &LusHashId);

    if ((uint32)E_OK == LucRetVal)
    {
        /* Set VLAN Tag valuable temporary */
        LstSTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagPcpFlag) ?
            LpStreamFilterEntry->ucSTagPcp : (uint8)NUM0;
        LstSTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagDeiFlag) ?
            LpStreamFilterEntry->ucSTagDei : (uint8)NUM0;
        LstSTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagVlanIdFlag) ?
            LpStreamFilterEntry->usSTagVlanId : (uint16)NUM0;
        LstCTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagPcpFlag) ?
            LpStreamFilterEntry->ucCTagPcp : (uint8)NUM0;
        LstCTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagDeiFlag) ?
            LpStreamFilterEntry->ucCTagDei : (uint8)NUM0;
        LstCTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagVlanIdFlag) ?
            LpStreamFilterEntry->usCTagVlanId : (uint16)NUM0;
        LusDestPort = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucDestPortFlag) ?
            LpStreamFilterEntry->usDestPort : (uint16)NUM0;

        /* Set Stream ID */
        aaStreamId[IDX_0] = (((uint32)LstSTag.ucPcp << SHIFT_29BIT) |
            ((uint32)LstSTag.ucDei << SHIFT_28BIT) |
            ((uint32)LstSTag.usVlanId << SHIFT_16BIT) |
            ((uint32)LstCTag.ucPcp << SHIFT_13BIT) |
            ((uint32)LstCTag.ucDei << SHIFT_12BIT) |
            (uint32)LstCTag.usVlanId);
        aaStreamId[IDX_1] = (((uint32)LusDestPort << SHIFT_16BIT) | (uint32)LusHashId);
        aaStreamId[IDX_2] = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucIpPart0Flag) ?
            LpStreamFilterEntry->aaSrcIpAddr[IDX_0] : (uint32)NUM0;
        aaStreamId[IDX_3] = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucIpPart1Flag) ?
            LpStreamFilterEntry->aaDestIpAddr[IDX_0] : (uint32)NUM0;
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_041]:[Gen5GW_EthSwtCont_UD_10_041]
* Function Name: GetIpv6StreamId
* Description  : Get Stream ID for IPv6
* Arguments    : pStreamCfg -
*                    Stream Configuration
*                ulEntryIdx -
*                    Stream Filter entry index
*                aaStreamId -
*                    Stream ID
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) GetIpv6StreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
    uint32 *aaStreamId)
{
    uint8 LucRetVal;
    uint16 LusHashId;
    const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry;
    const R_EthSwtCont_StreamFlagType *LpStreamFlags;
    EthSwtCont_VlanTagType LstSTag;
    EthSwtCont_VlanTagType LstCTag;
    uint32 LulIpVal[ETHSWTCONT_IPV6PART_NUM];
    uint16 LusDestPort;
    uint8 LucShiftCase;
    uint8 LucIpIdx;
    uint8 LucIpPartIdx;

    LpStreamFilterEntry = &pStreamCfg->pStreamFilter[ulEntryIdx];
    LpStreamFlags = &pStreamCfg->pStreamGenCfg->stIpv6InStreamFlags;

    LucRetVal = CalcHwHash(pStreamCfg, ulEntryIdx, &LusHashId);

    if ((uint32)E_OK == LucRetVal)
    {
        /* Set VLAN Tag valuable temporary */
        LstSTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagPcpFlag) ?
            LpStreamFilterEntry->ucSTagPcp : (uint8)NUM0;
        LstSTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagDeiFlag) ?
            LpStreamFilterEntry->ucSTagDei : (uint8)NUM0;
        LstSTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagVlanIdFlag) ?
            LpStreamFilterEntry->usSTagVlanId : (uint16)NUM0;
        LstCTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagPcpFlag) ?
            LpStreamFilterEntry->ucCTagPcp : (uint8)NUM0;
        LstCTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagDeiFlag) ?
            LpStreamFilterEntry->ucCTagDei : (uint8)NUM0;
        LstCTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagVlanIdFlag) ?
            LpStreamFilterEntry->usCTagVlanId : (uint16)NUM0;
        LusDestPort = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucDestPortFlag) ?
            LpStreamFilterEntry->usDestPort : (uint16)NUM0;

        /* Set Stream ID */
        aaStreamId[IDX_0] = (((uint32)LstSTag.ucPcp << SHIFT_29BIT) |
            ((uint32)LstSTag.ucDei << SHIFT_28BIT) |
            ((uint32)LstSTag.usVlanId << SHIFT_16BIT) |
            ((uint32)LstCTag.ucPcp << SHIFT_13BIT) |
            ((uint32)LstCTag.ucDei << SHIFT_12BIT) |
            (uint32)LstCTag.usVlanId);
        aaStreamId[IDX_1] = (((uint32)LusDestPort << SHIFT_16BIT) | (uint32)LusHashId);

        /* Calculate IPv6 Part 0/1 value */
        for (LucIpPartIdx = IDX_0; LucIpPartIdx < (uint32)ETHSWTCONT_IPV6PART_NUM; LucIpPartIdx++)
        {
            LucIpIdx = (uint8)(pStreamCfg->pStreamGenCfg->aaIpv6Offset[LucIpPartIdx] / (uint8)REGSIZE_IN_BYTE);
            LucShiftCase = (uint8)(pStreamCfg->pStreamGenCfg->aaIpv6Offset[LucIpPartIdx] % (uint8)REGSIZE_IN_BYTE);

            if ((uint32)NUM0 == (uint32)LucShiftCase)
            {
                if (ETHSWTCONT_IPOFFSET_SRC == pStreamCfg->pStreamGenCfg->aaIpv6OffsetMode[LucIpPartIdx])
                {
                    LulIpVal[LucIpPartIdx] = LpStreamFilterEntry->aaSrcIpAddr[LucIpIdx];
                }
                else
                {
                    LulIpVal[LucIpPartIdx] = LpStreamFilterEntry->aaDestIpAddr[LucIpIdx];
                }
            }
            else
            {
                if (ETHSWTCONT_IPOFFSET_SRC == pStreamCfg->pStreamGenCfg->aaIpv6OffsetMode[LucIpPartIdx])
                {
                    LulIpVal[LucIpPartIdx] =
                        (LpStreamFilterEntry->aaSrcIpAddr[LucIpIdx] << ((uint32)LucShiftCase * SHIFT_8BIT));
                    LulIpVal[LucIpPartIdx] = LulIpVal[LucIpPartIdx] |
                        (LpStreamFilterEntry->aaSrcIpAddr[LucIpIdx + (uint8)NUM1] >>
                        ((uint32)REGSIZE_IN_BIT - ((uint32)LucShiftCase * SHIFT_8BIT)));
                }
                else
                {
                    LulIpVal[LucIpPartIdx] =
                        (LpStreamFilterEntry->aaDestIpAddr[LucIpIdx] << ((uint32)LucShiftCase * SHIFT_8BIT));
                    LulIpVal[LucIpPartIdx] = LulIpVal[LucIpPartIdx] |
                        (LpStreamFilterEntry->aaDestIpAddr[LucIpIdx + (uint8)NUM1] >>
                        ((uint32)REGSIZE_IN_BIT - ((uint32)LucShiftCase * SHIFT_8BIT)));
                }
            }
        }

        /* Set IPv6 Part 0/1 value to Stream ID 2/3 */
        aaStreamId[IDX_2] =
            (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucIpPart0Flag) ? LulIpVal[IDX_0] : (uint32)NUM0;
        aaStreamId[IDX_3] =
            (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucIpPart1Flag) ? LulIpVal[IDX_1] : (uint32)NUM0;
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_042]:[Gen5GW_EthSwtCont_UD_10_042]
* Function Name: GetL2StreamId
* Description  : Get Stream ID for L2
* Arguments    : pStreamCfg -
*                    Stream Configuration
*                ulEntryIdx -
*                    Stream Filter entry index
*                aaStreamId -
*                    Stream ID
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) GetL2StreamId(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx, uint32 *aaStreamId)
{
    uint32 LulSetVal;
    const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry;
    const R_EthSwtCont_L2StreamFlagType *LpStreamFlags;
    EthSwtCont_VlanTagType LstSTag;
    EthSwtCont_VlanTagType LstCTag;

    LpStreamFilterEntry = &pStreamCfg->pStreamFilter[ulEntryIdx];
    LpStreamFlags = &pStreamCfg->pStreamGenCfg->stL2InStreamFlags;

    /* Set VLAN Tag valuable temporary */
    LstSTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagPcpFlag) ?
        LpStreamFilterEntry->ucSTagPcp : (uint8)NUM0;
    LstSTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagDeiFlag) ?
        LpStreamFilterEntry->ucSTagDei : (uint8)NUM0;
    LstSTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSTagVlanIdFlag) ?
        LpStreamFilterEntry->usSTagVlanId : (uint16)NUM0;
    LstCTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagPcpFlag) ?
        LpStreamFilterEntry->ucCTagPcp : (uint8)NUM0;
    LstCTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagDeiFlag) ?
        LpStreamFilterEntry->ucCTagDei : (uint8)NUM0;
    LstCTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucCTagVlanIdFlag) ?
        LpStreamFilterEntry->usCTagVlanId : (uint16)NUM0;

    /* Set Stream ID */
    aaStreamId[IDX_0] = (((uint32)LstSTag.ucPcp << SHIFT_29BIT) |
        ((uint32)LstSTag.ucDei << SHIFT_28BIT) |
        ((uint32)LstSTag.usVlanId << SHIFT_16BIT) |
        ((uint32)LstCTag.ucPcp << SHIFT_13BIT) |
        ((uint32)LstCTag.ucDei << SHIFT_12BIT) |
        (uint32)LstCTag.usVlanId);
    /* Set Dest MAC Addr(Upper 32 bit) if flag is set */
    LulSetVal = ((LpStreamFilterEntry->aaDestMacAddr[IDX_0] << SHIFT_16BIT) |
        (LpStreamFilterEntry->aaDestMacAddr[IDX_1] >> SHIFT_16BIT));
    aaStreamId[IDX_1] = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucDestMacFlag) ?
        LulSetVal : NUM0;
    /* Set Dest MAC Addr(Lower 16 bit) if flag is set */
    LulSetVal = (ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucDestMacFlag) ?
        (LpStreamFilterEntry->aaDestMacAddr[IDX_1] << SHIFT_16BIT) : NUM0;
    /* Set Source MAC Addr(Upper 16 bit) if flag is set */
    LulSetVal = LulSetVal | ((ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSrcMacFlag) ?
        LpStreamFilterEntry->aaSrcMacAddr[IDX_0] : (uint32)NUM0);
    aaStreamId[IDX_2] = LulSetVal;
    /* Set Source MAC Addr(Lower 32 bit) if flag is set */
    aaStreamId[IDX_3] = ((ETHSWTCONT_REG_SET == (uint32)LpStreamFlags->ucSrcMacFlag) ?
        LpStreamFilterEntry->aaSrcMacAddr[IDX_1] : (uint32)NUM0);
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_043]:[Gen5GW_EthSwtCont_UD_10_043]
* Function Name: CalcHwHash
* Description  : Get Hash calcuration result
* Arguments    : pStreamCfg -
*                    Stream Configuration
*                ulEntryIdx -
*                    Stream Filter entry index
*                usHashResult -
*                    Hash ID
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CalcHwHash(const R_EthSwtCont_StreamCfgType* pStreamCfg, const uint32 ulEntryIdx,
                                                                                                  uint16 *usHashResult)
{
    uint8 LucRetVal;
    const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry;
    const R_EthSwtCont_HashFlagType *LpHashFlags;
    uint8 LucIpTypeFlag;
    uint32 LulRegisterVal;
    uint32 LulSetVal;
    EthSwtCont_VlanTagType LstSTag;
    EthSwtCont_VlanTagType LstCTag;
    uint8 LucProtocol;
    uint16 LusSrcPort;
    uint16 LusDestPort;
    uint32 LulLoopCnt;

    LucRetVal = E_OK;
    LpStreamFilterEntry = &pStreamCfg->pStreamFilter[ulEntryIdx];

    if ((LpStreamFilterEntry->ucFrameFormatVec & FFV_MASK_IPV4) != NUM0)
    {
        LucIpTypeFlag = ETHSWTCONT_FLAG_IPV4;
        LpHashFlags = &pStreamCfg->pStreamGenCfg->stIpv4InHashFlags;
    }
    else
    {
        LucIpTypeFlag = ETHSWTCONT_FLAG_IPV6;
        LpHashFlags = &pStreamCfg->pStreamGenCfg->stIpv6InHashFlags;
    }

    /* Set VLAN Tag valuable temporary */
    LstSTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSTagPcpFlag) ?
        LpStreamFilterEntry->ucSTagPcp : (uint8)NUM0;
    LstSTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSTagDeiFlag) ?
        LpStreamFilterEntry->ucSTagDei : (uint8)NUM0;
    LstSTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSTagVlanIdFlag) ?
        LpStreamFilterEntry->usSTagVlanId : (uint16)NUM0;
    LstCTag.ucPcp = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucCTagPcpFlag) ?
        LpStreamFilterEntry->ucCTagPcp : (uint8)NUM0;
    LstCTag.ucDei = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucCTagDeiFlag) ?
        LpStreamFilterEntry->ucCTagDei : (uint8)NUM0;
    LstCTag.usVlanId = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucCTagVlanIdFlag) ?
        LpStreamFilterEntry->usCTagVlanId : (uint16)NUM0;
    LucProtocol = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucProtocolFlag) ?
        LpStreamFilterEntry->ucProtocol : (uint8)NUM0;
    LusSrcPort = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSrcPortFlag) ?
        LpStreamFilterEntry->usSrcPort : (uint16)NUM0;
    LusDestPort = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucDestPortFlag) ?
        LpStreamFilterEntry->usDestPort : (uint16)NUM0;

    /* Set FWSHCR0 to 13 register to use hash calculation function */
    LulSetVal = ((LpStreamFilterEntry->aaDestMacAddr[IDX_0] << SHIFT_16BIT) |
        (LpStreamFilterEntry->aaDestMacAddr[IDX_1] >> SHIFT_16BIT));
    LulRegisterVal = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucDestMacFlag) ?
        LulSetVal : NUM0;
    EthSwtCont_GpMfwdReg->FWSHCR0 = LulRegisterVal;

    /* Set Dest MAC Addr(Lower 16 bit) if flag is set */
    LulSetVal = (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucDestMacFlag) ?
        (LpStreamFilterEntry->aaDestMacAddr[IDX_1] << SHIFT_16BIT) : NUM0;
    /* Set Source MAC Addr(Upper 16 bit) if flag is set */
    LulRegisterVal = LulSetVal | ((ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSrcMacFlag) ?
        LpStreamFilterEntry->aaSrcMacAddr[IDX_0] : NUM0);
    EthSwtCont_GpMfwdReg->FWSHCR1 = LulRegisterVal;

    /* Set Source MAC Addr(Lower 32 bit) if flag is set */
    LulRegisterVal = ((ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSrcMacFlag) ?
        LpStreamFilterEntry->aaSrcMacAddr[IDX_1] : NUM0);
    EthSwtCont_GpMfwdReg->FWSHCR2 = LulRegisterVal;

    LulRegisterVal = (((uint32)LstSTag.ucPcp << SHIFT_29BIT) |
        ((uint32)LstSTag.ucDei << SHIFT_28BIT) |
        ((uint32)LstSTag.usVlanId << SHIFT_16BIT) |
        ((uint32)LstCTag.ucPcp << SHIFT_13BIT) |
        ((uint32)LstCTag.ucDei << SHIFT_12BIT) |
        (uint32)LstCTag.usVlanId);
    EthSwtCont_GpMfwdReg->FWSHCR3 = LulRegisterVal;

    LulRegisterVal = (((uint32)LucIpTypeFlag << SHIFT_16BIT) |
        (uint32)LucProtocol);
    EthSwtCont_GpMfwdReg->FWSHCR4 = LulRegisterVal;

    if (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucSrcIpFlag)
    {
        if ((uint32)ETHSWTCONT_FLAG_IPV4 == (uint32)LucIpTypeFlag)
        {
            EthSwtCont_GpMfwdReg->FWSHCR5 = NUM0;
            EthSwtCont_GpMfwdReg->FWSHCR6 = NUM0;
            EthSwtCont_GpMfwdReg->FWSHCR7 = NUM0;
            EthSwtCont_GpMfwdReg->FWSHCR8 = LpStreamFilterEntry->aaSrcIpAddr[IDX_0];
        }
        else
        {
            EthSwtCont_GpMfwdReg->FWSHCR5 = LpStreamFilterEntry->aaSrcIpAddr[IDX_0];
            EthSwtCont_GpMfwdReg->FWSHCR6 = LpStreamFilterEntry->aaSrcIpAddr[IDX_1];
            EthSwtCont_GpMfwdReg->FWSHCR7 = LpStreamFilterEntry->aaSrcIpAddr[IDX_2];
            EthSwtCont_GpMfwdReg->FWSHCR8 = LpStreamFilterEntry->aaSrcIpAddr[IDX_3];
        }
    }
    else
    {
        EthSwtCont_GpMfwdReg->FWSHCR5 = NUM0;
        EthSwtCont_GpMfwdReg->FWSHCR6 = NUM0;
        EthSwtCont_GpMfwdReg->FWSHCR7 = NUM0;
        EthSwtCont_GpMfwdReg->FWSHCR8 = NUM0;
    }

    if (ETHSWTCONT_REG_SET == (uint32)LpHashFlags->ucDestIpFlag)
    {
        if ((uint32)ETHSWTCONT_FLAG_IPV4 == (uint32)LucIpTypeFlag)
        {
            EthSwtCont_GpMfwdReg->FWSHCR9 = NUM0;
            EthSwtCont_GpMfwdReg->FWSHCR10 = NUM0;
            EthSwtCont_GpMfwdReg->FWSHCR11 = NUM0;
            EthSwtCont_GpMfwdReg->FWSHCR12 = LpStreamFilterEntry->aaDestIpAddr[IDX_0];
        }
        else
        {
            EthSwtCont_GpMfwdReg->FWSHCR9 = LpStreamFilterEntry->aaDestIpAddr[IDX_0];
            EthSwtCont_GpMfwdReg->FWSHCR10 = LpStreamFilterEntry->aaDestIpAddr[IDX_1];
            EthSwtCont_GpMfwdReg->FWSHCR11 = LpStreamFilterEntry->aaDestIpAddr[IDX_2];
            EthSwtCont_GpMfwdReg->FWSHCR12 = LpStreamFilterEntry->aaDestIpAddr[IDX_3];
        }
    }
    else
    {
        EthSwtCont_GpMfwdReg->FWSHCR9 = NUM0;
        EthSwtCont_GpMfwdReg->FWSHCR10 = NUM0;
        EthSwtCont_GpMfwdReg->FWSHCR11 = NUM0;
        EthSwtCont_GpMfwdReg->FWSHCR12 = NUM0;
    }

    LulRegisterVal = (((uint32)LusSrcPort << SHIFT_16BIT) |
        (uint32)LusDestPort);
    EthSwtCont_GpMfwdReg->FWSHCR13 = LulRegisterVal;

    LulLoopCnt = ETHSWTCONT_LOOP_COUNT;
    /* Wait for Hash calculation entry complete */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        /* Read FWSHCRR.SHCR */
        LulRegisterVal = (EthSwtCont_GpMfwdReg->FWSHCRR >> SHIFT_31BIT);
    } while (ETHSWTCONT_REG_SET == LulRegisterVal);

    if ((uint32)E_OK == LucRetVal)
    {
        /* Read Hash calculation result */
        *usHashResult = (uint16)(EthSwtCont_GpMfwdReg->FWSHCRR & MASK_16BIT);
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_067]:[Gen5GW_EthSwtCont_UD_10_067]
* Function Name: SetPortBased
* Description  : Set Port based forwarding configuration
* Arguments    : pPortBasedConfig -
*                    Port based forwarding Configuration
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) SetPortBased(const R_EthSwtCont_PortBasedCfgType *pPortBasedConfig)
{
    uint32 LulRegisterVal;
    uint8 LucPortIdx;

    /* Port i port-based setting flow for each port */
    for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_NUM; LucPortIdx++)
    {
        /* Port i port-based disable flow */
        EthSwtCont_GpMfwdReg->stFWPBi[LucPortIdx].FWPBFC0i = NUM0;
        /* Set CPU sub destinations to zero */
        EthSwtCont_GpMfwdReg->stFWPBFCSDCji[LucPortIdx].FWPBFCSDCji[IDX_0] = NUM0;
        EthSwtCont_GpMfwdReg->stFWPBFCSDCji[LucPortIdx].FWPBFCSDCji[IDX_1] = NUM0;
        /* Set port based forwarding */
        LulRegisterVal = (((uint32)pPortBasedConfig[LucPortIdx].ucAllInputPriorityEnable << SHIFT_26BIT) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucIPv6PriorityDecodeEnable << SHIFT_25BIT) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucIPv4PriorityDecodeMode << SHIFT_24BIT) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucIPv4PriorityDecodeEnable << SHIFT_23BIT) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucSecLv << SHIFT_22BIT) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucCpuMrrEnable << SHIFT_BIT_CMEL) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucEthMrrEnable << SHIFT_BIT_EMEL) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucIpvUpdate << SHIFT_BIT_IPUL) |
                        ((uint32)pPortBasedConfig[LucPortIdx].ucIpvVal << SHIFT_BIT_IPVL));
        EthSwtCont_GpMfwdReg->stFWPBi[LucPortIdx].FWPBFC0i = LulRegisterVal;
        
        /* Set port based forwarding for register FWPBFC1i */
        EthSwtCont_GpMfwdReg->stFWPBi[LucPortIdx].FWPBFC1i = NUM0;
        LulRegisterVal = (((uint32)pPortBasedConfig[LucPortIdx].ucRoutPriority << SHIFT_16BIT) |
                         ((uint32)pPortBasedConfig[LucPortIdx].ucHwLearnDisable << SHIFT_10BIT));
        EthSwtCont_GpMfwdReg->stFWPBi[LucPortIdx].FWPBFC1i = LulRegisterVal;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_068]:[Gen5GW_EthSwtCont_UD_10_068]
* Function Name: CheckPortBasedCfg
* Description  : Check Port based forwarding configuration
* Arguments    : pPortBasedConfig -
*                    Port based forwarding Configuration
* Return Value : E_OK
                 E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckPortBasedCfg(const R_EthSwtCont_PortBasedCfgType *pPortBasedConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;
    uint8 LucPortIdx;

    LucRetVal = E_OK;

    /* Check port-based forwarding configuration for each port */
    for (LucPortIdx = IDX_0; (uint32)LucPortIdx < (uint32)ETHSWTCONT_PORT_NUM; LucPortIdx++)
    {
        if (((uint32)pPortBasedConfig[LucPortIdx].ucAllInputPriorityEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucIPv6PriorityDecodeEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucIPv4PriorityDecodeMode <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucIPv4PriorityDecodeEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucSecLv <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucCpuMrrEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucEthMrrEnable <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucIpvUpdate <= ETHSWTCONT_REG_SET) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucIpvVal < (uint32)ETHSWTCONT_FRAME_PRIORITY_NUM) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucRoutPriority <= MASK_4BIT) &&
            ((uint32)pPortBasedConfig[LucPortIdx].ucHwLearnDisable <= (uint32)ETHSWTCONT_REG_SET))
        {
            /* Configuration check passed */
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            ucSID, ETHSWTCONT_E_CFG_PORTBASED);
            #endif
            break;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_061]:[Gen5GW_EthSwtCont_UD_10_061]
* Function Name: TransitGwcaMode
* Description  : State transition for GWCA Agent
* Arguments    : ucGwcaIdx -
*                    GWCA port index
*                ucNextMode -
*                    Next transition mode
* Return Value : E_OK
                 E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) TransitGwcaMode(const uint8 ucGwcaIdx, const uint8 ucNextMode)
{
    uint8 LucRetVal;
    uint32 LulLoopCnt;
    uint32 LulClockStatus;
    uint32 LulRegisterVal;
    const uint8 LucPortIdx = ucGwcaIdx + ETHSWTCONT_PORT_TSNA_NUM;

    LucRetVal = E_OK;
    LulLoopCnt = ETHSWTCONT_TIMEOUT_COUNT;


    /* Agent i clock status check flow */
    GetAgentClockStatus(LucPortIdx, &LulClockStatus);
    if ((uint32)ETHSWTCONT_ENABLE == LulClockStatus)
    {
        /* Clock is already enable */
    }
    else
    {
        /* Agent i clock enable flow */
        EnableAgentClock(LucPortIdx);
    }

    /* Set to next mode */
    EthSwtCont_GpGwcaReg[ucGwcaIdx]->GWMC = ucNextMode;

    /* GWMS.OPS == next_mode? */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        /* Read GWMS.OPS */
        LulRegisterVal = (EthSwtCont_GpGwcaReg[ucGwcaIdx]->GWMS & MASK_2BIT);
    } while ((uint32)ucNextMode != LulRegisterVal);

    if ((uint32)E_OK == LucRetVal)
    {
        if ((uint32)ETHSWTCONT_MODE_DISABLE == (uint32)ucNextMode)
        {
            /* Agent i clock disable flow */
            DisableAgentClock(LucPortIdx);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_062]:[Gen5GW_EthSwtCont_UD_10_062]
* Function Name: TransitTsnaMode
* Description  : State transition for TSNA Agent
* Arguments    : ucPortIdx -
*                    Port index
*                ucNextMode -
*                    Next transition mode
* Return Value : E_OK
                 E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) TransitTsnaMode(const uint8 ucPortIdx, const uint8 ucNextMode)
{
    uint8 LucRetVal;
    uint32 LulLoopCnt;
    uint32 LulClockStatus;
    uint32 LulRegisterVal;

    LucRetVal = E_OK;
    LulLoopCnt =  ETHSWTCONT_TIMEOUT_COUNT;

    /* Agent i clock status check flow */
    GetAgentClockStatus(ucPortIdx, &LulClockStatus);
    if ((uint32)ETHSWTCONT_ENABLE == LulClockStatus)
    {
        /* Clock is already enable */
    }
    else
    {
        /* Agent i clock enable flow */
        EnableAgentClock(ucPortIdx);
    }

    /* Set to next mode */
    EthSwtCont_GpTsnaReg[ucPortIdx]->EAMC = ucNextMode;

    /* EAMS.OPS == next_mode? */
    do
    {
        if (LulLoopCnt > (uint32)NUM0)
        {
            LulLoopCnt--;
        }
        else
        {
            /* Timeout */
            LucRetVal = E_NOT_OK;
            #ifdef ETHSWTCONT_E_TIMEOUT
            /* Report to DET */
            (void)Dem_SetEventStatus(ETHSWTCONT_E_TIMEOUT, DEM_EVENT_STATUS_FAILED);
            #endif
            break;
        }
        /* Read EAMS.OPS */
        LulRegisterVal = (EthSwtCont_GpTsnaReg[ucPortIdx]->EAMS & MASK_2BIT);
    } while ((uint32)ucNextMode != LulRegisterVal);

    if ((uint32)E_OK == LucRetVal)
    {
        if ((uint32)ETHSWTCONT_MODE_DISABLE == (uint32)ucNextMode)
        {
            /* Agent i clock disable flow */
            DisableAgentClock(ucPortIdx);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_063]:[Gen5GW_EthSwtCont_UD_10_063]
* Function Name: EnableAgentClock
* Description  : Enable Agent Clock
* Arguments    : ucPortIdx -
*                    Port index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) EnableAgentClock(const uint8 ucPortIdx)
{
    uint32 LulRegisterVal;

    LulRegisterVal = EthSwtCont_GpComaReg->RCEC;
    LulRegisterVal = (LulRegisterVal | ETHSWTCONT_COMA_RCEC_RCE | (ETHSWTCONT_REG_SET << (uint32)ucPortIdx));
    /* Enable Agent i clock */
    EthSwtCont_GpComaReg->RCEC = LulRegisterVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_064]:[Gen5GW_EthSwtCont_UD_10_064]
* Function Name: DisableAgentClock
* Description  : Disable Agent Clock
* Arguments    : ucPortIdx -
*                    Port index
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) DisableAgentClock(const uint8 ucPortIdx)
{
    const uint32 LulRegisterVal = (ETHSWTCONT_REG_SET << (uint32)ucPortIdx);
    /* Disable Agent i clock */
    EthSwtCont_GpComaReg->RCDC = LulRegisterVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_065]:[Gen5GW_EthSwtCont_UD_10_065]
* Function Name: GetAgentClockStatus
* Description  : Get Agent Clock status
* Arguments    : ucPortIdx -
*                    Port index
*                pClockStatus -
*                    Clock status
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) GetAgentClockStatus(const uint8 ucPortIdx, uint32 *pClockStatus)
{
    uint32 LulRegisterVal;
    const uint32 LulPortRegVal = (ETHSWTCONT_REG_SET << (uint32)ucPortIdx);

    /* Read clock status */
    LulRegisterVal = EthSwtCont_GpComaReg->RCEC;

    if ((LulRegisterVal & (ETHSWTCONT_COMA_RCEC_RCE | LulPortRegVal)) ==
        (ETHSWTCONT_COMA_RCEC_RCE | LulPortRegVal))
    {
        /* Agent i clock is enabled*/
        *pClockStatus = ETHSWTCONT_ENABLE;
    }
    else
    {
        /* Agent i clock is disabled */
        *pClockStatus = ETHSWTCONT_DISABLE;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_10_066]:[Gen5GW_EthSwtCont_UD_10_066]
* Function Name: ResetEthSwt
* Description  : Reset Ethernet Switch
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ResetEthSwt(void)
{
    /* Switch reset flow */
    EthSwtCont_GpComaReg->RRC = ETHSWTCONT_REG_SET;
    EthSwtCont_GpComaReg->RRC = ETHSWTCONT_REG_CLR;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_073]:[Gen5GW_EthSwtCont_UD_23_073]
* Function Name: DEMCheckMACLearnFail
* Description  : Check Learning Result for MAC
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckMACLearnFail(const uint8 ucCheckLearnReg)
{
    uint8 LucRetVal;
    LucRetVal = E_OK;
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_5BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_MAC_DYN_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_MAC_DYN_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_3BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_MAC_OVR_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_MAC_OVR_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_1BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_MAC_SEC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_MAC_SEC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == (ucCheckLearnReg & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_MAC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_MAC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_074]:[Gen5GW_EthSwtCont_UD_23_074]
* Function Name: DEMCheckVLANLearnFail
* Description  : Check Learning Result for VLAN
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckVLANLearnFail(const uint8 ucCheckLearnReg)
{
    uint8 LucRetVal;
    LucRetVal = E_OK;
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_3BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_VLAN_OVR_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_VLAN_OVR_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_2BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_VLAN_ECC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_VLAN_ECC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_1BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_VLAN_SEC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_VLAN_SEC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == (ucCheckLearnReg & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_VLAN_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_VLAN_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_075]:[Gen5GW_EthSwtCont_UD_23_075]
* Function Name: DEMCheckL3LearnFail
* Description  : Check Learning Result for L3
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckL3LearnFail(const uint8 ucCheckLearnReg)
{
    uint8 LucRetVal;
    LucRetVal = E_OK;
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_3BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_L3_OVR_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_L3_OVR_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_2BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_L3_ECC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_L3_ECC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_1BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_L3_SEC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_L3_SEC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == (ucCheckLearnReg & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_L3_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_L3_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_076]:[Gen5GW_EthSwtCont_UD_23_076]
* Function Name: DEMCheckL2L3LearnFail
* Description  : Check Learning Result for L2L3
* Arguments    : N/A
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) DEMCheckL2L3LearnFail(const uint8 ucCheckLearnReg)
{
    uint8 LucRetVal;
    LucRetVal = E_OK;
    if(ETHSWTCONT_REG_SET == ((ucCheckLearnReg >> SHIFT_1BIT) & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_L2L3_SEC_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_L2L3_SEC_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    if(ETHSWTCONT_REG_SET == (ucCheckLearnReg & MASK_1BIT))
    {
        #ifdef ETHSWTCONT_E_LEARN_L2L3_FAIL
        (void)Dem_SetEventStatus(ETHSWTCONT_E_LEARN_L2L3_FAIL, DEM_EVENT_STATUS_FAILED);
        #endif
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /*Do Notthing*/
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_077]:[Gen5GW_EthSwtCont_UD_23_077]
* Function Name: CheckFrameFormatVec
* Description  : Check Frame Format Vector
* Arguments    : LpStreamFilterEntry -
*                    Stream Filter Entry Configuration
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) CheckFrameFormatVec(const R_EthSwtCont_StreamFCfgType *LpStreamFilterEntry
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    switch (LpStreamFilterEntry->ucFrameFormatVec)
        {
            case FFV_MASK_PF:
                /* Perfect Filter is set. This is not stream filter */
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                            ucSID, ETHSWTCONT_E_CFG_STREAM);
                #endif
                break;
            case FFV_MASK_IPV4_NONE:
            case FFV_MASK_IPV4_TCP:
            case FFV_MASK_IPV4_UDP:
                /* IP addr element 1 - 3 should be zero if Frame Format Code is IPv4 */
                if (((uint32)NUM0 == (uint32)LpStreamFilterEntry->aaDestIpAddr[IDX_1]) &&
                    ((uint32)NUM0 == (uint32)LpStreamFilterEntry->aaDestIpAddr[IDX_2]) &&
                    ((uint32)NUM0 == (uint32)LpStreamFilterEntry->aaDestIpAddr[IDX_3]) &&
                    ((uint32)NUM0 == (uint32)LpStreamFilterEntry->aaSrcIpAddr[IDX_1]) &&
                    ((uint32)NUM0 == (uint32)LpStreamFilterEntry->aaSrcIpAddr[IDX_2]) &&
                    ((uint32)NUM0 == (uint32)LpStreamFilterEntry->aaSrcIpAddr[IDX_3]))
                {
                    /* Configuration check passed */
                }
                else
                {
                    LucRetVal = E_NOT_OK;
                    #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                          ucSID, ETHSWTCONT_E_CFG_STREAM);
                    #endif
                }
                break;
            case FFV_MASK_IPV6_NONE:
            case FFV_MASK_IPV6_TCP:
            case FFV_MASK_IPV6_UDP:
            case FFV_MASK_L2:
                /* Check Passed */
                break;
            default:
                /* Frame format Vector is invalid value. */
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                              ucSID, ETHSWTCONT_E_CFG_STREAM);
                #endif
                break;
        }

        return LucRetVal;
}
#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/***********************************************************************************************************************
**                      End of File                                                                                   **
***********************************************************************************************************************/
