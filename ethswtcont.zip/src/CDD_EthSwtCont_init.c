/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains initialization function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_EthSwtCont_init.h"
#include "CDD_EthSwtCont_hwctl.h"
#include "CDD_EthSwtCont_hwtsn.h"
#include "CDD_EthSwtCont_common.h"
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"

static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckConfiguration(const R_EthSwtCont_CfgType *pConfig);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckCutThroughAndIntegrity(const R_EthSwtCont_CfgType *pConfig);

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_02_001]:[Gen5GW_EthSwtCont_UD_02_001]
* Function Name: EthSwtCont_Init
* Description  : Ethernet Switch Control SW Initialization.
* Arguments    : pConfig -
*                    Initialization Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_Init(const R_EthSwtCont_CfgType *pConfig)
{
    uint8 LucRetVal;

    LucRetVal = E_OK;

    if (ETHSWTCONT_CHECK_CODE == pConfig->ulIntegrityCheck)
    {
        if ((NULL_PTR != pConfig->pMfwdCfg) &&
            (NULL_PTR != pConfig->pMfwdPortCfg) &&
            (NULL_PTR != pConfig->pRoutCfg) &&
            (NULL_PTR != pConfig->pPsfpConfig) &&
            (NULL_PTR != pConfig->pWatermarkCfg))
        {
            /* Do nothing */
        }
        else
        {
            LucRetVal = E_NOT_OK;
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                        R_ETHSWTCONT_INIT_SID, ETHSWTCONT_E_CFG);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* Check Configuration */
        LucRetVal = EthSwtCont_CheckConfiguration(pConfig);
        
        /* Check Cut Through and Integrity */
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = EthSwtCont_CheckCutThroughAndIntegrity(pConfig);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* Switch reset flow */
        LucRetVal = EthSwtCont_ResetEthSwt();
        /* Switch initialization flow */
        if ((uint32)E_OK == LucRetVal)
        {
            /* Common agent Switch clock enable flow */
            EthSwtCont_EnableClock();

            /* Common agent Buffer pool initialization flow */
            LucRetVal = EthSwtCont_InitBuffPool(pConfig->pWatermarkCfg);
        }
        else
        {
            /* Do nothing */
        }

        if ((uint32)E_OK == LucRetVal)
        {
            /* General function setting flow */
            EthSwtCont_InitMfwd(pConfig->pMfwdCfg);

            /* Cut-through setting flow */
            EthSwtCont_SetCutThrough(pConfig->pCTCfg, pConfig->ulCTEntryNum);
            /* Integrity Check setting flow */
            EthSwtCont_SetIntegrityCheck(pConfig->pICCfg);

            LucRetVal = EthSwtCont_SetRoutTbl(pConfig->pRoutCfg);
            if ((uint32)E_OK == LucRetVal)
            {
                /* PSFP setting flow */
                LucRetVal = EthSwtCont_SetPsfpCfg(pConfig->pPsfpConfig);
                if ((uint32)E_OK == LucRetVal)
                {
                    /* Port i setting flow */
                    EthSwtCont_SetMfwdPort(pConfig->pMfwdPortCfg);

                    /* TODO: Port i and IPVj setting flow */
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_079]:[Gen5GW_EthSwtCont_UD_23_079]
* Function Name: EthSwtCont_CheckConfiguration
* Description  : R-Switch3 Configuration Check
* Arguments    : pConfig -
*                    Initialization Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckConfiguration(const R_EthSwtCont_CfgType *pConfig)
{
    uint8 LucRetVal;

    LucRetVal = EthSwtCont_CheckMfwdCfg(pConfig->pMfwdCfg);
    if ((uint32)E_OK == LucRetVal)
    {
        EthSwtCont_GucVlanMode = pConfig->pMfwdCfg->ucSVlanMode;
        LucRetVal = EthSwtCont_CheckRoutCfg(pConfig->pRoutCfg);
        if ((uint32)E_OK == LucRetVal)
        {
            LucRetVal = EthSwtCont_CheckMfwdPortCfg(pConfig->pMfwdPortCfg
            #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            , R_ETHSWTCONT_INIT_SID
            #endif
            );
            if ((uint32)E_OK == LucRetVal)
            {
                LucRetVal = EthSwtCont_CheckPsfpCfg(pConfig->pPsfpConfig
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                , R_ETHSWTCONT_INIT_SID
                #endif
                );
                if ((uint32)E_OK == LucRetVal)
                {
                    LucRetVal = EthSwtCont_CheckBuffPool(pConfig->pWatermarkCfg);
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_23_080]:[Gen5GW_EthSwtCont_UD_23_080]
* Function Name: EthSwtCont_CheckCutThroughAndIntegrity
* Description  : Check CutThrough Filter Config and Integrity Check Config
* Arguments    : pConfig -
*                    Initialization Configuration
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckCutThroughAndIntegrity(const R_EthSwtCont_CfgType *pConfig)
{
    uint8 LucRetVal;

    LucRetVal = EthSwtCont_CheckCutThrough(pConfig->pCTCfg, pConfig->ulCTEntryNum);
    if ((uint32)E_OK == LucRetVal)
    {
        LucRetVal = EthSwtCont_CheckIntegrityCheck(pConfig->pICCfg);
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}
#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/***********************************************************************************************************************
**                      End of File                                                                                   **
***********************************************************************************************************************/
