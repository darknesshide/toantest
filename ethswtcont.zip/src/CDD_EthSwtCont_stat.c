/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.23.0
* Description  : This file contains statistical function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_EthSwtCont_stat.h"
#include "CDD_EthSwtCont_common.h"
#include "CDD_EthSwtCont_regMFWD.h"
#include "CDD_EthSwtCont_reg.h"
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define ETHSWTCONT_START_SEC_VAR_INIT_32
#include "EthSwtCont_MemMap.h"

static VAR(uint32, ETHSWTCONT_VAR_NO_INIT) EthSwtCont_GulRefreshTime = NUM0;

#define ETHSWTCONT_STOP_SEC_VAR_INIT_32
#include "EthSwtCont_MemMap.h"

#define ETHSWTCONT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "EthSwtCont_MemMap.h"

static VAR(R_EthSwtCont_StatType, ETHSWTCONT_VAR_NO_INIT) EthSwtCont_GstStatCount;
static CONST(R_EthSwtCont_StatCfgType *, ETHSWTCONT_CONFIG_DATA) EthSwtCont_GpStatConfig;
static VAR(R_EthSwtCont_StatFuncPtrType, ETHSWTCONT_VAR_NO_INIT) EthSwtCont_GpStatCbFunc;
static VAR(R_EthSwtCont_NotifyFuncPtrType, ETHSWTCONT_VAR_NO_INIT) EthSwtCont_GpStatNotifyCbFunc;

static CONSTP2VAR(volatile EthSwtCont_RmacRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpRmacReg[ETHSWTCONT_PORT_TSNA_NUM] =
{
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC0_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC1_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC2_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC3_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC4_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC5_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC6_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC7_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC8_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC9_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC10_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC11_BASEADDR,
    (EthSwtCont_RmacRegType *)ETHSWTCONT_RMAC12_BASEADDR
};

#define ETHSWTCONT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "EthSwtCont_MemMap.h"

#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadPsfpCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulStatEntryIdx,
    uint32 *pRegisterVal);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadMFWDCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx, 
    uint32 *pRegisterVal);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadRMACPauseCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadRMACPFCCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadRMACTxRxCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) GetPortStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) GetStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ClearStat(uint32 *aaStat, uint32 *aaStatOverflow, const uint32 ulStatRegNum);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) NotifyPortStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) NotifyStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum);
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadMFWDCounter2Reg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal);
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_001]:[Gen5GW_EthSwtCont_UD_04_001]
* Function Name: EthSwtCont_SetStatCfg
* Description  : Config Statistical function.
* Arguments    : pStatConfig -
*                    Statistical function configuration
*                pStatCbFunc -
*                    Statistical callback function pointer
*                pStatNotifyCbFunc -
*                    Statistical notify callback function pointer
* Return Value : E_OK
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetStatCfg(const R_EthSwtCont_StatCfgType *pStatConfig,
                            R_EthSwtCont_StatFuncPtrType pStatCbFunc, R_EthSwtCont_NotifyFuncPtrType pStatNotifyCbFunc)
{
    uint8 LucRetVal;
    uint32 LulStatIdx;
    uint32 LulPortIdx;

    LucRetVal = E_OK;

    if (NULL_PTR != pStatConfig->pStatElemCfg)
    {
        /* NULL Check passed */
    }
    else
    {
        LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_SETSTATCFG_SID, 
                                                                                            ETHSWTCONT_E_PARAM_CONFIG);
        #endif
    }

    if ((uint32)E_OK == LucRetVal)
    {
        for (LulPortIdx = IDX_0; LulPortIdx < (uint32)ETHSWTCONT_PORT_NUM; LulPortIdx++)
        {
            if ((uint32)pStatConfig->aaPortEnable[LulPortIdx] <= (uint32)ETHSWTCONT_FLAG_SET)
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_SETSTATCFG_SID, 
                                                                                                ETHSWTCONT_E_CFG_STAT);
                #endif
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        for (LulStatIdx = IDX_0; LulStatIdx < (uint32)ETHSWTCONT_STAT_NUM; LulStatIdx++)
        {
            if (((uint32)pStatConfig->pStatElemCfg[LulStatIdx].ucGetEnable <= (uint32)ETHSWTCONT_FLAG_SET) &&
                ((uint32)pStatConfig->pStatElemCfg[LulStatIdx].ucNotifyEnable <= (uint32)ETHSWTCONT_FLAG_SET) &&
                (pStatConfig->pStatElemCfg[LulStatIdx].ulNotifyThreshold <= (uint32)MASK_31BIT))
            {
                /* Check passed */
            }
            else
            {
                LucRetVal = E_NOT_OK;
                #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID, R_ETHSWTCONT_SETSTATCFG_SID, 
                                                                                                ETHSWTCONT_E_CFG_STAT);
                #endif
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint32)E_OK == LucRetVal)
    {
        /* Save statistical configuration pointer */
        EthSwtCont_GpStatConfig = pStatConfig;
        /* Save callback function pointer */
        EthSwtCont_GpStatCbFunc = pStatCbFunc;
        EthSwtCont_GpStatNotifyCbFunc = pStatNotifyCbFunc;
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_002]:[Gen5GW_EthSwtCont_UD_04_002]
* Function Name: EthSwtCont_GetStatCfg
* Description  : Get Statistical function Config.
* Arguments    : pStatConfig -
*                    Statistical function configuration
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_GetStatCfg(R_EthSwtCont_StatCfgType *pStatConfig)
{
    *pStatConfig = *EthSwtCont_GpStatConfig;
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_003]:[Gen5GW_EthSwtCont_UD_04_003]
* Function Name: EthSwtCont_StatMain
* Description  : Statistical Main function.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_StatMain(void)
{
    uint32 LulStatIdx;
    uint32 LulIdx;

    if (EthSwtCont_GulRefreshTime >= EthSwtCont_GpStatConfig->ulRefreshInterval)
    {
        EthSwtCont_GulRefreshTime = NUM0;

        /* Read statistical information */
        for (LulStatIdx = IDX_0; LulStatIdx < (uint32)ETHSWTCONT_STAT_FILTERMSDU; LulStatIdx++)
        {
            GetPortStat((R_EthSwtCont_StatIdType)LulStatIdx,
                &EthSwtCont_GstStatCount.aaMFWDPortStat[LulStatIdx][IDX_0],
                &EthSwtCont_GstStatCount.aaMFWDPortStatOverflow[LulStatIdx][IDX_0],
                ETHSWTCONT_PORT_NUM);
        }

        GetStat(ETHSWTCONT_STAT_FILTERMSDU,
            &EthSwtCont_GstStatCount.aaMsduStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMsduStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_MSDU_NUM);
        GetStat(ETHSWTCONT_STAT_FILTERGATE,
            &EthSwtCont_GstStatCount.aaGateStat[IDX_0],
            &EthSwtCont_GstStatCount.aaGateStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_GATE_NUM);
        GetStat(ETHSWTCONT_STAT_METERGREEN,
            &EthSwtCont_GstStatCount.aaMeterGreenStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMeterGreenStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_MTR_NUM);
        GetStat(ETHSWTCONT_STAT_METERYELLOW,
            &EthSwtCont_GstStatCount.aaMeterYellowStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMeterYellowStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_DMTR_N);
        GetStat(ETHSWTCONT_STAT_METERRED,
            &EthSwtCont_GstStatCount.aaMeterRedStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMeterRedStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_MTR_NUM);

        for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_RMACPORTSTAT_NUM; LulIdx++)
        {
            /* Calculate statistical information ID */
            LulStatIdx = LulIdx + (uint32)ETHSWTCONT_STAT_MANUALPAUSETX;
            GetPortStat((R_EthSwtCont_StatIdType)LulStatIdx,
                &EthSwtCont_GstStatCount.aaRMACPortStat[LulIdx][IDX_0],
                &EthSwtCont_GstStatCount.aaRMACPortStatOverflow[LulIdx][IDX_0],
                ETHSWTCONT_PORT_TSNA_NUM);
        }

        /* Notify over threshold */
        for (LulStatIdx = IDX_0; LulStatIdx < (uint32)ETHSWTCONT_STAT_FILTERMSDU; LulStatIdx++)
        {
            NotifyPortStat((R_EthSwtCont_StatIdType)LulStatIdx,
                &EthSwtCont_GstStatCount.aaMFWDPortStat[LulStatIdx][IDX_0],
                &EthSwtCont_GstStatCount.aaMFWDPortStatOverflow[LulStatIdx][IDX_0],
                ETHSWTCONT_PORT_NUM);
        }

        NotifyStat(ETHSWTCONT_STAT_FILTERMSDU,
            &EthSwtCont_GstStatCount.aaMsduStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMsduStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_MSDU_NUM);
        NotifyStat(ETHSWTCONT_STAT_FILTERGATE,
            &EthSwtCont_GstStatCount.aaGateStat[IDX_0],
            &EthSwtCont_GstStatCount.aaGateStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_GATE_NUM);
        NotifyStat(ETHSWTCONT_STAT_METERGREEN,
            &EthSwtCont_GstStatCount.aaMeterGreenStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMeterGreenStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_MTR_NUM);
        NotifyStat(ETHSWTCONT_STAT_METERYELLOW,
            &EthSwtCont_GstStatCount.aaMeterYellowStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMeterYellowStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_DMTR_N);
        NotifyStat(ETHSWTCONT_STAT_METERRED,
            &EthSwtCont_GstStatCount.aaMeterRedStat[IDX_0],
            &EthSwtCont_GstStatCount.aaMeterRedStatOverflow[IDX_0],
            ETHSWTCONT_PSFP_MTR_NUM);

        for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_RMACPORTSTAT_NUM; LulIdx++)
        {
            /* Calculate statistical information ID */
            LulStatIdx = LulIdx + (uint32)ETHSWTCONT_STAT_MANUALPAUSETX;
            NotifyPortStat((R_EthSwtCont_StatIdType)LulStatIdx,
                &EthSwtCont_GstStatCount.aaRMACPortStat[LulIdx][IDX_0],
                &EthSwtCont_GstStatCount.aaRMACPortStatOverflow[LulIdx][IDX_0],
                ETHSWTCONT_PORT_TSNA_NUM);
        }

        /* Call periodic callback function */
        EthSwtCont_GpStatCbFunc(&EthSwtCont_GstStatCount);
    }
    else
    {
        EthSwtCont_GulRefreshTime++;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_004]:[Gen5GW_EthSwtCont_UD_04_004]
* Function Name: EthSwtCont_ClearStatAll
* Description  : Clear All Statistical information.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_ClearStatAll(void)
{
    uint32 LulStatIdx;

    for (LulStatIdx = IDX_0; LulStatIdx < (uint32)ETHSWTCONT_MFWDPORTSTAT_NUM; LulStatIdx++)
    {
        ClearStat(&EthSwtCont_GstStatCount.aaMFWDPortStat[LulStatIdx][IDX_0],
            &EthSwtCont_GstStatCount.aaMFWDPortStatOverflow[LulStatIdx][IDX_0],
            ETHSWTCONT_PORT_NUM);
    }

    ClearStat(&EthSwtCont_GstStatCount.aaMsduStat[IDX_0],
        &EthSwtCont_GstStatCount.aaMsduStatOverflow[IDX_0],
        ETHSWTCONT_PSFP_MSDU_NUM);
    ClearStat(&EthSwtCont_GstStatCount.aaGateStat[IDX_0],
        &EthSwtCont_GstStatCount.aaGateStatOverflow[IDX_0],
        ETHSWTCONT_PSFP_GATE_NUM);
    ClearStat(&EthSwtCont_GstStatCount.aaMeterGreenStat[IDX_0],
        &EthSwtCont_GstStatCount.aaMeterGreenStatOverflow[IDX_0],
        ETHSWTCONT_PSFP_MTR_NUM);
    ClearStat(&EthSwtCont_GstStatCount.aaMeterYellowStat[IDX_0],
        &EthSwtCont_GstStatCount.aaMeterYellowStatOverflow[IDX_0],
        ETHSWTCONT_PSFP_DMTR_N);
    ClearStat(&EthSwtCont_GstStatCount.aaMeterRedStat[IDX_0],
        &EthSwtCont_GstStatCount.aaMeterRedStatOverflow[IDX_0],
        ETHSWTCONT_PSFP_MTR_NUM);

    for (LulStatIdx = IDX_0; LulStatIdx < (uint32)ETHSWTCONT_RMACPORTSTAT_NUM; LulStatIdx++)
    {
        ClearStat(&EthSwtCont_GstStatCount.aaRMACPortStat[LulStatIdx][IDX_0],
            &EthSwtCont_GstStatCount.aaRMACPortStatOverflow[LulStatIdx][IDX_0],
            ETHSWTCONT_PORT_TSNA_NUM);
    }
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_005]:[Gen5GW_EthSwtCont_UD_04_005]
* Function Name: ReadPsfpCounterReg
* Description  : Read PSFP counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulStatEntryIdx -
*                    Statistical information register index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadPsfpCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulStatEntryIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    switch (enStatIdx)
    {
    case ETHSWTCONT_STAT_FILTERMSDU:
        if (ulStatEntryIdx < (uint32)ETHSWTCONT_PSFP_MSDU_NUM)
        {
            *pRegisterVal = EthSwtCont_GpMfwdReg->FWPMFDCNi[ulStatEntryIdx];
        }
        else
        {
            /* Do nothing */
        }
        break;
    case ETHSWTCONT_STAT_FILTERGATE:
        if (ulStatEntryIdx < (uint32)ETHSWTCONT_PSFP_GATE_NUM)
        {
            *pRegisterVal = EthSwtCont_GpMfwdReg->FWPGFDCNi[ulStatEntryIdx];
        }
        else
        {
            /* Do nothing */
        }
        break;
    case ETHSWTCONT_STAT_METERGREEN:
        if (ulStatEntryIdx < (uint32)ETHSWTCONT_PSFP_MTR_NUM)
        {
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMeterCounterReg[ulStatEntryIdx].FWPMGDCNi;
        }
        else
        {
            /* Do nothing */
        }
        break;
    case ETHSWTCONT_STAT_METERYELLOW:
        if (ulStatEntryIdx < (uint32)ETHSWTCONT_PSFP_DMTR_N)
        {
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMeterCounterReg[ulStatEntryIdx].FWPMYDCNi;
        }
        else
        {
            /* Do nothing */
        }
        break;
    case ETHSWTCONT_STAT_METERRED:
        if (ulStatEntryIdx < (uint32)ETHSWTCONT_PSFP_MTR_NUM)
        {
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMeterCounterReg[ulStatEntryIdx].FWPMRDCNi;
        }
        else
        {
            /* Do nothing */
        }
        break;
    default:
        /* Do nothing */
        break;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_006]:[Gen5GW_EthSwtCont_UD_04_006]
* Function Name: ReadMFWDCounterReg
* Description  : Read MFWD counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulPortIdx -
*                    Ethernet Switch Port index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadMFWDCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    if (ulPortIdx < (uint32)ETHSWTCONT_PORT_NUM)
    {
        /* Read statistical information from counter register */
        switch (enStatIdx)
        {
        case ETHSWTCONT_STAT_FWDDIRECTDESC:
            if (ulPortIdx >= (uint32)ETHSWTCONT_PORT_TSNA_NUM)
            {
                *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDCounterReg[ulPortIdx].FWDDFDCNi;
            }
            else
            {
                /* Do nothing */
            }
            break;
        case ETHSWTCONT_STAT_FWDL3:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDCounterReg[ulPortIdx].FWLTHFDCNi;
            break;
        case ETHSWTCONT_STAT_FWDL2:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDCounterReg[ulPortIdx].FWLTWFDCNi;
            break;
        case ETHSWTCONT_STAT_FWDPORTBASED:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDCounterReg[ulPortIdx].FWPBFDCNi;
            break;
        case ETHSWTCONT_STAT_MACHWLEARN:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDCounterReg[ulPortIdx].FWMHLCNi;
            break;
        case ETHSWTCONT_STAT_REJECTWATERMARK:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDRejectCounterReg[ulPortIdx].FWWMRDCNi;
            break;
        case ETHSWTCONT_STAT_REJECTDIRECTDESC:
            if (ulPortIdx >= (uint32)ETHSWTCONT_PORT_TSNA_NUM)
            {
                *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDRejectCounterReg[ulPortIdx].FWDDRDCNi;
            }
            else
            {
                /* Do nothing */
            }
            break;
        case ETHSWTCONT_STAT_REJECTL3:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDRejectCounterReg[ulPortIdx].FWLTHRDCNi;
            break;
        case ETHSWTCONT_STAT_REJECTL2:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDRejectCounterReg[ulPortIdx].FWLTWRDCNi;
            break;
        case ETHSWTCONT_STAT_REJECTPORTBASED:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDRejectCounterReg[ulPortIdx].FWPBRDCNi;
            break;
        default:
            /* Do nothing */
            break;
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_007]:[Gen5GW_EthSwtCont_UD_04_007]
* Function Name: ReadRMACPauseCounterReg
* Description  : Read RMAC Pause counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulPortIdx -
*                    Ethernet Switch Port index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadRMACPauseCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    if (ulPortIdx < (uint32)ETHSWTCONT_PORT_TSNA_NUM)
    {
        /* Read statistical information from counter register */
        switch (enStatIdx)
        {
        case ETHSWTCONT_STAT_MANUALPAUSETX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MMPFTCT;
            break;
        case ETHSWTCONT_STAT_AUTOPAUSETX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MAPFTCT;
            break;
        case ETHSWTCONT_STAT_PAUSERX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPFRCT;
            break;
        case ETHSWTCONT_STAT_FALSECARRIER:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MFCICT;
            break;
        case ETHSWTCONT_STAT_ENERGYETH:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MEEECT;
            break;
        default:
            /* Do nothing */
            break;
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_008]:[Gen5GW_EthSwtCont_UD_04_008]
* Function Name: ReadRMACPFCCounterReg
* Description  : Read RMAC PFC counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulPortIdx -
*                    Ethernet Switch Port index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadRMACPFCCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    if (ulPortIdx < (uint32)ETHSWTCONT_PORT_TSNA_NUM)
    {
        /* Read statistical information from counter register */
        switch (enStatIdx)
        {
        case ETHSWTCONT_STAT_MANUALPFCTX0:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MMPCFTCTt[IDX_0];
            break;
        case ETHSWTCONT_STAT_MANUALPFCTX1:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MMPCFTCTt[IDX_1];
            break;
        case ETHSWTCONT_STAT_AUTOPFCTX0:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MAPCFTCTt[IDX_0];
            break;
        case ETHSWTCONT_STAT_AUTOPFCTX1:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MAPCFTCTt[IDX_1];
            break;
        case ETHSWTCONT_STAT_PFCRX0:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_0];
            break;
        case ETHSWTCONT_STAT_PFCRX1:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_1];
            break;
        case ETHSWTCONT_STAT_PFCRX2:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_2];
            break;
        case ETHSWTCONT_STAT_PFCRX3:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_3];
            break;
        case ETHSWTCONT_STAT_PFCRX4:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_4];
            break;
        case ETHSWTCONT_STAT_PFCRX5:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_5];
            break;
        case ETHSWTCONT_STAT_PFCRX6:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_6];
            break;
        case ETHSWTCONT_STAT_PFCRX7:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MPCFRCTt[IDX_7];
            break;
        default:
            /* Do nothing */
            break;
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_009]:[Gen5GW_EthSwtCont_UD_04_009]
* Function Name: ReadRMACTxRxCounterReg
* Description  : Read RMAC Tx/Rx counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulPortIdx -
*                    Ethernet Switch Port index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadRMACTxRxCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    if (ulPortIdx < (uint32)ETHSWTCONT_PORT_TSNA_NUM)
    {
        /* Read statistical information from counter register */
        switch (enStatIdx)
        {
        case ETHSWTCONT_STAT_HEADCRCERRRX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MRHCRCEC;
            break;
        case ETHSWTCONT_STAT_GOODEFRAMERX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MRGFCE;
            break;
        case ETHSWTCONT_STAT_GOODPFRAMERX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MRGFCP;
            break;
        case ETHSWTCONT_STAT_FINALFLAGERRRX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MRFFMEFC;
            break;
        case ETHSWTCONT_STAT_CFLAGERRRX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MRCFCEFC;
            break;
        case ETHSWTCONT_STAT_RMACFILTERRRX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MRRCFEFC;
            break;
        case ETHSWTCONT_STAT_GOODEFRAMETX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MTGFCE;
            break;
        case ETHSWTCONT_STAT_GOODPFRAMETX:
            *pRegisterVal = EthSwtCont_GpRmacReg[ulPortIdx]->MTGFCP;
            break;
        default:
            /* Do nothing */
            break;
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_010]:[Gen5GW_EthSwtCont_UD_04_010]
* Function Name: ReadCounterReg
* Description  : Read counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulPortIdx -
*                    Ethernet Switch Port index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadCounterReg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    if (ulPortIdx < (uint32)ETHSWTCONT_PORT_NUM)
    {
        /* Change the function to be executed according to the statistical information ID. */
        if ((ETHSWTCONT_STAT_REJECTPORTBASED < enStatIdx) && (enStatIdx <= ETHSWTCONT_STAT_FWDAL))
        {
            ReadMFWDCounter2Reg(enStatIdx, ulPortIdx, pRegisterVal);
        }
        else
        {
            /* Do nothing */
        }

        if (enStatIdx <= ETHSWTCONT_STAT_REJECTPORTBASED)
        {
            ReadMFWDCounterReg(enStatIdx, ulPortIdx, pRegisterVal);
        }
        else if (enStatIdx <= ETHSWTCONT_STAT_METERRED)
        {
            /* The number of PSFP counter register is not port number. Read by another function */
        }
        else if (enStatIdx <= ETHSWTCONT_STAT_ENERGYETH)
        {
            ReadRMACPauseCounterReg(enStatIdx, ulPortIdx, pRegisterVal);
        }
        else if (enStatIdx <= ETHSWTCONT_STAT_PFCRX7)
        {
            ReadRMACPFCCounterReg(enStatIdx, ulPortIdx, pRegisterVal);
        }
        else if (enStatIdx <= ETHSWTCONT_STAT_GOODPFRAMETX)
        {
            ReadRMACTxRxCounterReg(enStatIdx, ulPortIdx, pRegisterVal);
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_011]:[Gen5GW_EthSwtCont_UD_04_011]
* Function Name: GetPortStat
* Description  : Get each port statistics function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                aaStat -
*                    Statistical information value
*                aaStatOverflow -
*                    Statistical information overflow value
*                ulStatRegNum -
*                    Counter register number
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) GetPortStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum)
{
    uint32 LulStatVal;
    uint32 LulRegisterVal;
    uint32 LulPortIdx;

    if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ucGetEnable)
    {
        for (LulPortIdx = IDX_0; LulPortIdx < (uint32)ulStatRegNum; LulPortIdx++)
        {
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->aaPortEnable[LulPortIdx])
            {
                LulStatVal = aaStat[LulPortIdx];
                ReadCounterReg(enStatIdx, LulPortIdx, &LulRegisterVal);

                /* Check overflow */
                if ((MASK_32BIT - LulStatVal) >= LulRegisterVal)
                {
                    /* Not over flow case. Save the statistical information */
                    aaStat[LulPortIdx] = LulStatVal + LulRegisterVal;
                    aaStatOverflow[LulPortIdx] = NUM0;
                }
                else
                {
                    /* Overflow case. Save the statistical information to max value */
                    aaStat[LulPortIdx] = MASK_32BIT;
                    /* Save the overflow information */
                    aaStatOverflow[LulPortIdx] = LulRegisterVal - (MASK_32BIT - LulStatVal);
                }
            }
            else
            {
                /* Disable Port Skip */
            }
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_012]:[Gen5GW_EthSwtCont_UD_04_012]
* Function Name: GetStat
* Description  : Get statistics function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                aaStat -
*                    Statistical information value
*                aaStatOverflow -
*                    Statistical information overflow value
*                ulStatRegNum -
*                    Counter register number
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) GetStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum)
{
    uint32 LulStatVal;
    uint32 LulRegisterVal;
    uint32 LulIdx;
    
    if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ucGetEnable)
    {
        for (LulIdx = IDX_0; LulIdx < ulStatRegNum; LulIdx++)
        {
            LulStatVal = aaStat[LulIdx];
            ReadPsfpCounterReg(enStatIdx, LulIdx, &LulRegisterVal);

            if ((MASK_32BIT - LulStatVal) >= LulRegisterVal)
            {
                /* Not over flow case. Save the statistical information */
                aaStat[LulIdx] = LulStatVal + LulRegisterVal;
                aaStatOverflow[LulIdx] = NUM0;
            }
            else
            {
                /* Overflow case. Save the statistical information to max value */
                aaStat[LulIdx] = MASK_32BIT;
                /* Save the overflow information */
                aaStatOverflow[LulIdx] = LulRegisterVal - (MASK_32BIT - LulStatVal);
            }
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_013]:[Gen5GW_EthSwtCont_UD_04_013]
* Function Name: ClearStat
* Description  : Clear statistics function.
* Arguments    : aaStat -
*                    Statistical information value
*                aaStatOverflow -
*                    Statistical information overflow value
*                ulStatRegNum -
*                    Counter register number
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ClearStat(uint32 *aaStat, uint32 *aaStatOverflow, const uint32 ulStatRegNum)
{
    uint32 LulIdx;
    
    for (LulIdx = IDX_0; LulIdx < ulStatRegNum; LulIdx++)
    {
        aaStat[LulIdx] = NUM0;
        aaStatOverflow[LulIdx] = NUM0;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_014]:[Gen5GW_EthSwtCont_UD_04_014]
* Function Name: NotifyPortStat
* Description  : Notify each port statistics function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                aaStat -
*                    Statistical information value
*                aaStatOverflow -
*                    Statistical information overflow value
*                ulStatRegNum -
*                    Counter register number
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) NotifyPortStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum)
{
    uint32 LulStatValue;
    uint32 LulOverflowValue;
    uint32 LulPortIdx;

    if (((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ucGetEnable) &&
        ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ucNotifyEnable))
    {
        for (LulPortIdx = IDX_0; LulPortIdx < (uint32)ulStatRegNum; LulPortIdx++)
        {
            if ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->aaPortEnable[LulPortIdx])
            {
                LulStatValue = aaStat[LulPortIdx];

                if (LulStatValue > EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ulNotifyThreshold)
                {
                    LulOverflowValue = aaStatOverflow[LulPortIdx];
                    EthSwtCont_GpStatNotifyCbFunc(enStatIdx, LulPortIdx, LulStatValue, LulOverflowValue);
                    /* Clear the statistical information after notified */
                    aaStat[LulPortIdx] = NUM0;
                    aaStatOverflow[LulPortIdx] = NUM0;
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Disable Port Skip */
            }
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_015]:[Gen5GW_EthSwtCont_UD_04_015]
* Function Name: NotifyStat
* Description  : Notify statistics function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                aaStat -
*                    Statistical information value
*                aaStatOverflow -
*                    Statistical information overflow value
*                ulStatRegNum -
*                    Counter register number
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) NotifyStat(const R_EthSwtCont_StatIdType enStatIdx, uint32 *aaStat, uint32 *aaStatOverflow,
    const uint32 ulStatRegNum)
{
    uint32 LulStatValue;
    uint32 LulOverflowValue;
    uint32 LulIdx;

    if (((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ucGetEnable) &&
        ((uint32)ETHSWTCONT_FLAG_SET == (uint32)EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ucNotifyEnable))
    {
        for (LulIdx = IDX_0; LulIdx < ulStatRegNum; LulIdx++)
        {
            LulStatValue = aaStat[LulIdx];

            if (LulStatValue > EthSwtCont_GpStatConfig->pStatElemCfg[enStatIdx].ulNotifyThreshold)
            {
                LulOverflowValue = aaStatOverflow[LulIdx];
                EthSwtCont_GpStatNotifyCbFunc(enStatIdx, LulIdx, LulStatValue, LulOverflowValue);
                /* Clear the statistical information after notified */
                aaStat[LulIdx] = NUM0;
                aaStatOverflow[LulIdx] = NUM0;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_04_016]:[Gen5GW_EthSwtCont_UD_04_016]
* Function Name: ReadMFWDCounter2Reg
* Description  : Read MFWD counter register function.
* Arguments    : enStatIdx -
*                    Statistical information index
*                ulPortIdx -
*                    Ethernet Switch Port index
*                pRegisterVal -
*                    Counter Register value
* Return Value : N/A
*******************************************************************************/
static FUNC(void, ETHSWTCONT_PRIVATE_CODE) ReadMFWDCounter2Reg(const R_EthSwtCont_StatIdType enStatIdx, const uint32 ulPortIdx,
    uint32 *pRegisterVal)
{
    *pRegisterVal = NUM0;

    if (ulPortIdx < (uint32)ETHSWTCONT_PORT_NUM)
    {
        /* Read statistical information from counter register */
        switch (enStatIdx)
        {
        case ETHSWTCONT_STAT_FWDBL:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDListFilterCounterReg[ulPortIdx].FWBLFCNi;
            break;
        case ETHSWTCONT_STAT_FWDAL:
            *pRegisterVal = EthSwtCont_GpMfwdReg->stMFWDListFilterCounterReg[ulPortIdx].FWALFCNi;
            break;
        default:
            /* Do nothing */
            break;
        }
    }
    else
    {
        /* Do nothing */
    }
}
#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/***********************************************************************************************************************
**                      End of File                                                                                   **
***********************************************************************************************************************/
