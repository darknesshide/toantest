/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.23.0
* Description  : This file contains HW Secure function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_EthSwtCont_hwrout.h"
#include "CDD_EthSwtCont_hwctl.h"
#include "CDD_EthSwtCont_hwtsn.h"
#include "CDD_EthSwtCont_common.h"
#include "CDD_EthSwtCont_regMFWD.h"
#include "CDD_EthSwtCont_regCOMA.h"
#include "CDD_EthSwtCont_reg.h"
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define ETHSWTCONT_START_SEC_VAR_INIT_UNSPECIFIED
#include "EthSwtCont_MemMap.h"
/* Register pointer */
static CONSTP2VAR(volatile EthSwtCont_ComaRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpComaSecReg = (EthSwtCont_ComaRegType *)ETHSWTCONT_COMA_BASEADDR;
CONSTP2VAR(volatile EthSwtCont_MfwdRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpMfwdSecReg = (EthSwtCont_MfwdRegType *)ETHSWTCONT_MFWD_BASEADDR;
#define ETHSWTCONT_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "EthSwtCont_MemMap.h"

#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/*******************************************************************************
Private global variables and functions
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecICConfiguration(const R_EthSwtCont_MFWDSecICCfgType *pSecICCfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecConfiguration(const R_EthSwtCont_MFWDSecCfgType *pSecCfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecPortConfiguration(const R_EthSwtCont_MFWDSecPortCfgType *pSecPortCfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecL2TblConfiguration(const R_EthSwtCont_MFWDSecL2TblCfgType *pSecL2Cfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecPFConfiguration(const R_EthSwtCont_MFWDSecPFCfgType *pSecPFCfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecL2L3StreamConfiguration(const R_EthSwtCont_MFWDSecL2L3StreamCfgType *pSecL2L3Cfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecL2L3UpConfiguration(const R_EthSwtCont_MFWDSecL2L3UpCfgType *pSecL2L3UpCfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecPSFPConfiguration(const R_EthSwtCont_MFWDSecPSFPCfgType *pSecPSFPCfg);
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecCOMAConfiguration(const uint8 ucSecCfg);

/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_010]:[Gen5GW_EthSwtCont_UD_27_010]
* Function Name: EthSwtCont_SetSecureReg
* Description  : Function setting access right security
* Arguments    : pSecConfig -
*                    Configuration for update
* Return Value : E_OK -
*                    Success
*                E_NOT_OK -
*                    Not Success
*******************************************************************************/
FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecureReg(const R_EthSwtCont_MFWDSecGeneralCfgType *pSecConfig)
{
    uint8 LucRetVal;

    LucRetVal = SetSecICConfiguration(&pSecConfig->stFWSecICCfg);              
    if (E_OK == LucRetVal)
    {
        LucRetVal = SetSecConfiguration(&pSecConfig->stFWSecCfg);   
        if (E_OK == LucRetVal)
        {
            LucRetVal = SetSecPortConfiguration(&pSecConfig->stFWSecPortCfg);     
            if (E_OK == LucRetVal)
            {
                LucRetVal = SetSecL2TblConfiguration(&pSecConfig->stFWSecL2TblCfg);
            }
            else
            {
                /* Do Nothing */
            }
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }
    
    if (E_OK == LucRetVal)
    {
        LucRetVal = SetSecPFConfiguration(&pSecConfig->stFWSecPFCfg);
        if (E_OK == LucRetVal)
        {
            LucRetVal = SetSecL2L3StreamConfiguration(&pSecConfig->stFWSecL2L3StreamCfg);
            if (E_OK == LucRetVal)
            {
                LucRetVal = SetSecL2L3UpConfiguration(&pSecConfig->stFWSecL2L3UpCfg);
            }
            else
            {
                /* Do Nothing */
            }
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        
    }

    if (E_OK == LucRetVal)
    {
        LucRetVal = SetSecPSFPConfiguration(&pSecConfig->stFWSecPSFP);
        if (E_OK == LucRetVal)
        {
            LucRetVal = SetSecCOMAConfiguration(pSecConfig->ucCOMASecEnable);
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }
        
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_001]:[Gen5GW_EthSwtCont_UD_27_001]
* Function Name: EthSwtCont_SetSecICConfiguration
* Description  : Function setting access right secure for integrity check
* Arguments    : pSecICCfg -
*                    Configuration for secure integrity check function
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecICConfiguration(const R_EthSwtCont_MFWDSecICCfgType *pSecICCfg){
    
    uint32 LulRegisterVal;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecICCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    LulRegisterVal = (((uint32)pSecICCfg->ulSecIC << (uint32)SHIFT_16BIT) |
                       pSecICCfg->ulSecPortBased);
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR26 = LulRegisterVal;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_002]:[Gen5GW_EthSwtCont_UD_27_002]
* Function Name: EthSwtCont_SetSecConfiguration
* Description  : Function setting access right secure
* Arguments    : pSecCfg -
*                    Configuration for secure function
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecConfiguration(const R_EthSwtCont_MFWDSecCfgType *pSecCfg){
    
    uint32 LulRegisterVal;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    
    LulRegisterVal =(((uint32)pSecCfg->ucSecCounter << (uint32)SHIFT_10BIT) |
                    ((uint32)pSecCfg->ucSecMonitorInt << (uint32)SHIFT_9BIT)|
                    ((uint32)pSecCfg->ucSecErrorInt << (uint32)SHIFT_8BIT)  |
                    ((uint32)pSecCfg->ucSecWaterMark << (uint32)SHIFT_7BIT) |
                    ((uint32)pSecCfg->ucSecSDMrrPath << (uint32)SHIFT_6BIT) |
                    ((uint32)pSecCfg->ucSecEthMrrPath << (uint32)SHIFT_5BIT)|
                    ((uint32)pSecCfg->ucSecCpuMrrPath << (uint32)SHIFT_4BIT)|
                    ((uint32)pSecCfg->ucSecCpuLrnPath << (uint32)SHIFT_3BIT)|
                    ((uint32)pSecCfg->ucSecCpuExPath << (uint32)SHIFT_2BIT) |
                    ((uint32)pSecCfg->ucSecTAGTPID << (uint32)SHIFT_1BIT)   |
                    ((uint32)pSecCfg->ucSecMode));

    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR0 = LulRegisterVal;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_003]:[Gen5GW_EthSwtCont_UD_27_003]
* Function Name: EthSwtCont_SetSecPortConfiguration
* Description  : Function setting access right secure port config
* Arguments    : pSecPortCfg -
*                    Port index
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecPortConfiguration(const R_EthSwtCont_MFWDSecPortCfgType *pSecPortCfg){
    
    uint32 LulRegisterVal;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecPortCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    
    LulRegisterVal =((uint32)pSecPortCfg->ulSecL2L3FwdMask << (uint32)SHIFT_16BIT);
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR0 = LulRegisterVal;
    
    LulRegisterVal =((uint32)pSecPortCfg->ulSecDirectDesc << (uint32)SHIFT_16BIT);
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR1 = LulRegisterVal;
    
    LulRegisterVal =(((uint32)pSecPortCfg->ulSecBlockList << (uint32)SHIFT_16BIT) |
                     ((uint32)pSecPortCfg->ulSecAcceptList));
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR2 = LulRegisterVal;
    
    LulRegisterVal = pSecPortCfg->ulSecL2L3Up;
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR3 = LulRegisterVal;
    
    LulRegisterVal = pSecPortCfg->ulSecPortandIPVFilter;
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR4 = LulRegisterVal;
    
    LulRegisterVal = (((uint32)pSecPortCfg->ulSecIPv4 << (uint32)SHIFT_16BIT) |
                       pSecPortCfg->ulSecIPv6);
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR21 = LulRegisterVal;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_004]:[Gen5GW_EthSwtCont_UD_27_004]
* Function Name: EthSwtCont_SetSecL2TblConfiguration
* Description  : Function setting access right secure for layer 2 table config
* Arguments    : pSecL2Cfg -
*                    Port index
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecL2TblConfiguration(const R_EthSwtCont_MFWDSecL2TblCfgType *pSecL2Cfg){
    
    uint32 LulRegisterVal;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecL2Cfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    
    LulRegisterVal = (((uint32)pSecL2Cfg->ucL2HWLearn << (uint32)SHIFT_16BIT) |
                       (pSecL2Cfg->ulL2HWLearnPerPort));
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR24 = LulRegisterVal;
    
    LulRegisterVal = (((uint32)pSecL2Cfg->ucSecL2Aging << (uint32)SHIFT_17BIT) |
                       ((uint32)pSecL2Cfg->ucSecL2Monitor << (uint32)SHIFT_16BIT) |
                       (pSecL2Cfg->ulSecL2Tbl));
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR25 = LulRegisterVal;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_005]:[Gen5GW_EthSwtCont_UD_27_005]
* Function Name: EthSwtCont_SetSecPFConfiguration
* Description  : Function setting access right secure for perfect filter
* Arguments    : pSecPFCfg -
*                    Port index
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecPFConfiguration(const R_EthSwtCont_MFWDSecPFCfgType *pSecPFCfg){

    uint32 LulIdx;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecPFCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{

    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FWSCRTO_NUM; LulIdx++)
        {
            EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCRTOi[LulIdx] = (uint32)pSecPFCfg->ulSec2BF[LulIdx];
        }

    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FWSCRTH_NUM; LulIdx++)
        {
            EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCRTHi[LulIdx] = (uint32)pSecPFCfg->ulSec3BF[LulIdx];
        }

    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FWSCRFO_NUM; LulIdx++)
        {
            EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCRFOi[LulIdx] = (uint32)pSecPFCfg->ulSec4BF[LulIdx];
        }

    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FWSCRRA_NUM; LulIdx++)
        {
            EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCRRAi[LulIdx] = (uint32)pSecPFCfg->ulSecRF[LulIdx];
        }

    for (LulIdx = IDX_0; LulIdx < (uint32)ETHSWTCONT_FWSCRCA_NUM; LulIdx++)
        {
            EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCRCAi[LulIdx] = (uint32)pSecPFCfg->ulSecCF[LulIdx];
        }
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_006]:[Gen5GW_EthSwtCont_UD_27_006]
* Function Name: EthSwtCont_SetSecL3L3StreamConfiguration
* Description  : Function setting access right secure stream filter
* Arguments    : pSecL2L3Cfg -
*                    Port index
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecL2L3StreamConfiguration(const R_EthSwtCont_MFWDSecL2L3StreamCfgType *pSecL2L3Cfg){
    
    uint32 LulRegisterVal;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecL2L3Cfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    
    LulRegisterVal = (((uint32)pSecL2L3Cfg->ucL2StreamCfg << (uint32)SHIFT_18BIT)  |
                      ((uint32)pSecL2L3Cfg->ucIPv6StreamCfg << (uint32)SHIFT_17BIT) |
                      ((uint32)pSecL2L3Cfg->ucIPv4StreamCfg << (uint32)SHIFT_16BIT) |
                       pSecL2L3Cfg->ulL2Stream);
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR22 = LulRegisterVal;
    
    LulRegisterVal = (((uint32)pSecL2L3Cfg->ucSecL3TblMonitor << (uint32)SHIFT_16BIT) |
                       pSecL2L3Cfg->ulSecL3Tbl);
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR23 = LulRegisterVal;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_007]:[Gen5GW_EthSwtCont_UD_27_007]
* Function Name: EthSwtCont_SetSecL2L3UpConfiguration
* Description  : Function setting access right secure for layer2 layer3 update
* Arguments    : pSecL2L3UpCfg -
*                    Port index
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecL2L3UpConfiguration(const R_EthSwtCont_MFWDSecL2L3UpCfgType *pSecL2L3UpCfg){
        
    uint8 LucRetVal;

    LucRetVal = E_OK;

    if (NULL_PTR == pSecL2L3UpCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR27 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_7];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR28 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_6];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR29 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_5];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR30 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_4];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR31 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_3];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR32 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_2];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR33 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_1];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR34 = pSecL2L3UpCfg->ulSecL2L3Up[IDX_0];
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR36 = pSecL2L3UpCfg->ulSecL2L3UpRemap;
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR37 = pSecL2L3UpCfg->ulSecL2L3UpMonitor;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_008]:[Gen5GW_EthSwtCont_UD_27_008]
* Function Name: EthSwtCont_SetSecPSFPConfiguration
* Description  : Function setting access right secure for PSFP
* Arguments    : pSecPSFPCfg -
*                    Port index
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecPSFPConfiguration(const R_EthSwtCont_MFWDSecPSFPCfgType *pSecPSFPCfg){
    
    uint32 LulRegisterVal;
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (NULL_PTR == pSecPSFPCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR38 = pSecPSFPCfg->ulSecPSFPMSDU;
    
    LulRegisterVal = (((uint32)pSecPSFPCfg->ucSecPSFPGateRAM << (uint32)SHIFT_16BIT) |
                      (pSecPSFPCfg->ulSecPSFPGate));
                      
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR39 = LulRegisterVal;
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR43 = pSecPSFPCfg->ulSecMeter[IDX_0];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR42 = pSecPSFPCfg->ulSecMeter[IDX_1];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR41 = pSecPSFPCfg->ulSecMeter[IDX_2];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR40 = pSecPSFPCfg->ulSecMeter[IDX_3];
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR47 = pSecPSFPCfg->ulSecFRER[IDX_0];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR46 = pSecPSFPCfg->ulSecFRER[IDX_1];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR45 = pSecPSFPCfg->ulSecFRER[IDX_2];
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR44 = pSecPSFPCfg->ulSecFRER[IDX_3];
    
    LulRegisterVal = (((uint32)pSecPSFPCfg->ucSecFRERTimeout << (uint32)SHIFT_1BIT) |
                      (pSecPSFPCfg->ucSecFRERMonitor));
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR48 = LulRegisterVal;
    
    EthSwtCont_GpMfwdSecReg->stMFWDSecurityReg.FWSCR49 = pSecPSFPCfg->ulSecSEQGen;
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_EthSwtCont_CD_27_009]:[Gen5GW_EthSwtCont_UD_27_009]
* Function Name: SetSecCOMAConfiguration
* Description  : Function access rigth for security register COMA
* Arguments    : ucSecCfg -
*                    Secure config 
* Return Value : E_OK
*                E_NOT_OK
*******************************************************************************/
static FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) SetSecCOMAConfiguration(const uint8 ucSecCfg)
{
    uint8 LucRetVal;
    
    LucRetVal = E_OK;
    
    if (ETHSWTCONT_REG_SET < ucSecCfg)
    {
         LucRetVal = E_NOT_OK;
        #if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(ETHSWTCONT_MODULE_ID, ETHSWTCONT_INSTANCE_ID,
                                                                    R_ETHSWTCONT_SETSEC_SID, ETHSWTCONT_E_PARAM_CONFIG);
            #endif
    }
    else{
    uint32 LulRegisterVal;
    LulRegisterVal = (uint32)ucSecCfg << (uint32)SHIFT_1BIT;
    EthSwtCont_GpComaSecReg->CASCR = LulRegisterVal;
    }
    return LucRetVal;
}
#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/***********************************************************************************************************************
**                      End of File                                                                                   **
***********************************************************************************************************************/
