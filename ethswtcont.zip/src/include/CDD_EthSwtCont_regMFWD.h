/***********************************************************************************************************************
* Copyright [2023-2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.26.0
* Description  : R-Switch3 MFWD register definition.
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_REGMFWD_H
#define CDD_ETHSWTCONT_REGMFWD_H

#include "rcar-xos/ethswtcont/CDD_EthSwtCont.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* R-Switch3 Register Configuration */
/* Do not change these definition without reserve area modification */
#define REG_PORT_NUM        15U /* TSNA:13 */
#define REG_PORT_GWCA_NUM   2U

#define REG_PFL_2BF_NUM     512U
#define REG_PFL_3BF_NUM     128U
#define REG_PFL_4BF_NUM     512U
#define REG_PFL_RF_N        128U
#define REG_PFL_CFMF_N      7U
#define REG_PFL_CF_N        512U
#define REG_LTH_REMAP_NUM   32U

#define REG_ETHSWTCONT_PSFP_MSDU_NUM   16U /* PSFP MSDU filer number */
#define REG_ETHSWTCONT_PSFP_GATE_NUM   8U  /* PSFP gate number */
#define REG_ETHSWTCONT_PSFP_MTR_NUM    104U /* PSFP meter number */
#define REG_LTH_SEQGN_NUM   32U /* L3 sequence generation rule number */

#define REG_CT_CRULE_NUM    8U
#define REG_INTG_ETYPE_N    8U
#define REG_INTG_FILT_SIPA_N    1U

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/* Register group for Register address map */
typedef struct
{
    uint32 FWPC0;
    uint32 FWPC1;
    uint32 FWPC2;
    uint32 FWPC3;
} FWPCi_RegGrpType;

typedef struct
{
    /* 0x4A00 - */
    uint32 FWPBFC0i;
    uint32 FWPBFC1i;
    uint32 reserved0[2];
    /* - 0x4A10 */
} FWPBi_RegGrpType;

typedef struct
{
    uint32 FWPBFCSDCji[REG_PORT_GWCA_NUM];
    uint32 reserved0[6];
} FWPBFCSDCji_RegGrpType;

/* Layer 3 forwarding/routing perfect filter function registers */

/* Register group for Register address map */
typedef struct
{
    /* 0x1000 - */
    uint32 FWTWBFCi;
    uint32 FWTWBFVCi;
    uint32 reserved0[2];
    /* - 0x1010 */
} FWTWBFi_RegGrpType;


/* Register group for Register address map */
typedef struct
{
    /* 0x1400 - */
    uint32 FWTHBFCi;
    uint32 FWTHBFV0Ci;
    uint32 FWTHBFV1Ci;
    uint32 reserved0;
    /* - 0x1410 */
} FWTHBFi_RegGrpType;


/* Register group for Register address map */
typedef struct
{
    /* 0x1800 - */
    uint32 FWFOBFCi;
    uint32 FWFOBFV0Ci;
    uint32 FWFOBFV1Ci;
    uint32 reserved0;
    /* - 0x1810 */
} FWFOBFi_RegGrpType;

/* Register group for Register address map */
typedef struct
{
    /* 0x1C00 - */
    uint32 FWRFCi;
    uint32 FWRFSVCi;
    uint32 FWRFEVCi;
    uint32 reserved0;
    /* - 0x1C10 */
} FWRFi_RegGrpType;

/* Register group for Register address map */
typedef struct
{
    /* 0x2000 - */
    uint32 FWCFCi;
    uint32 FWCFMCij[REG_PFL_CFMF_N];
    uint32 reserved0[8];
    /* - 0x2040 */
} FWCFi_RegGrpType;

typedef struct
{
    uint32 FWPGFC;
    uint32 FWPGFIGSC;
    uint32 FWPGFENC;
    uint32 FWPGFENM;
    uint32 FWPGFCSTC0;
    uint32 FWPGFCSTC1;
    uint32 FWPGFCSTM0;
    uint32 FWPGFCSTM1;
    uint32 FWPGFCTC;
    uint32 FWPGFCTM;
    uint32 FWPGFHCC;
    uint32 FWPGFSM;
    uint32 FWPGFGC;
    uint32 reserved0[3];
} FWPGi_RegGrpType;

typedef struct
{
    uint32 FWPMTRFC;
    uint32 FWPMTRCBSC;
    uint32 FWPMTRCIRC;
    uint32 FWPMTREBSC;
    uint32 FWPMTREIRC;
    uint32 FWPMTRFM;
    uint32 reserved0[2];
} FWPMTRi_RegGrpType;

typedef struct
{
    uint32 FWSEQNGC;
    uint32 FWSEQNGM;
} FWSEQi_RegGrpType;

typedef struct
{
    uint32 FWDDFDCNi;
    uint32 FWLTHFDCNi;
    uint32 reserved0;
    uint32 FWLTWFDCNi;
    uint32 FWPBFDCNi;
    uint32 FWMHLCNi;
    uint32 reserved1[2];
} MFWDCounter_RegGrpType;

typedef struct
{
    uint32 reserved0;
    uint32 FWWMRDCNi;
    uint32 FWDDRDCNi;
    uint32 FWLTHRDCNi;
    uint32 reserved1;
    uint32 FWLTWRDCNi;
    uint32 FWPBRDCNi;
    uint32 reserved2;
} MFWDRejectCounter_RegGrpType;

typedef struct
{
    uint32 FWPMGDCNi;
    uint32 FWPMYDCNi;
    uint32 FWPMRDCNi;
    uint32 reserved0[5];
} MeterCounter_RegGrpType;

typedef struct
{
    /* 0x0400 - */
    uint32 FWCTGC0i;
    uint32 FWCTGC1i;
    uint32 FWCTTC0i;
    uint32 FWCTTC1i;
    /* 0x0410 - */
    uint32 FWCTTC2ji[REG_PORT_GWCA_NUM];
    uint32 reserved0[14];
    /* 0x0450 - */
    uint32 FWCTSC0i;
    uint32 FWCTSC1i;
    uint32 FWCTSC2i;
    uint32 FWCTSC3i;
    /* 0x0460 - */
    uint32 FWCTSC4i;
    uint32 reserved1[3];
} CT_RegGrpType;

typedef struct
{
    uint32 FWICETC1i;
    uint32 FWICIP4Ci;
    uint32 FWIP4ACi;
    uint32 FWICIP6Ci;
    uint32 FWIP6AC0i;
    uint32 FWIP6AC1i;
    uint32 FWIP6AC2i;
    uint32 FWIP6AC3i;
    uint32 FWIP4APCi;
    uint32 FWIP6APCi;
    uint32 reserved0[6];
} IntegrityCheckIPCfg_RegGrpType;

typedef struct
{
    uint32 FWBLFCNi;
    uint32 reserved0[2];
    uint32 FWALFCNi;
    uint32 reserved1[4];
} MFWDListFilterCounter_RegGrpType;

typedef struct
{
    uint32 FWICETC2i;
    uint32 reserved0[3];
    /* 0x1010 - */
    uint32 FWICETC3ij[REG_INTG_ETYPE_N/2];
    uint32 reserved1[12];
    /* 0x1050 - */
    uint32 FWIP4FACij[REG_INTG_FILT_SIPA_N];
    uint32 reserved2[7];
    /* 0x1070 - */
    uint32 FWIP4SFCij[REG_INTG_FILT_SIPA_N];
    uint32 reserved3[7];
    /* 0x1090 - */
    uint32 FWIP6FAC0ij[REG_INTG_FILT_SIPA_N];
    uint32 reserved4[7];
    /* 0x10B0 - */
    uint32 FWIP6FAC1ij[REG_INTG_FILT_SIPA_N];
    uint32 reserved5[7];
    /* 0x10D0 - */
    uint32 FWIP6FAC2ij[REG_INTG_FILT_SIPA_N];
    uint32 reserved6[7];
    /* 0x10F0 - */
    uint32 FWIP6FAC3ij[REG_INTG_FILT_SIPA_N];
    uint32 reserved7[7];
    /* 0x1110 - */
    uint32 FWIP6SFCij[REG_INTG_FILT_SIPA_N];
    uint32 reserved8[7];
    /* 0x1130 - */
    uint32 FWIP4TLCCi;
    uint32 FWIP6PLCCi;
    uint32 reserved9[2];
    /* 0x1140 - */
    uint32 FWICL4Ci;
    uint32 FWICL4THLCi;
    uint32 reserved10[2];
    /* 0x1150 - */
    uint32 reserved11[44];
    /* 0x1200 - */
} IntegrityCheckCfg_RegGrpType;

typedef struct
{
    /* 0x7D00H - */
    /* Forwarding Engine Security Configuration Register 0 */
    uint32 FWSCR0;
    /* 0x7D04H - */
    /* Forwarding Engine Security Configuration Register 1 */
    uint32 FWSCR1;
    /* 0x7D08H - */
    /* Forwarding Engine Security Configuration Register 2 */
    uint32 FWSCR2;
    /* 0x7D0CH - */
    /* Forwarding Engine Security Configuration Register 3 */
    uint32 FWSCR3;
    /* 0x7D10H - */
    /* Forwarding Engine Security Configuration Register 4 */
    uint32 FWSCR4;
    /* 0x7D14H - */
    uint32 reserved1[16];
    /* 0x7D54H - */
    /* Forwarding Engine Security Configuration Register 21 */
    uint32 FWSCR21;
    /* 0x7D58H - */
    /* Forwarding Engine Security Configuration Register 22 */
    uint32 FWSCR22;
    /* 0x7D5CH - */
    /* Forwarding Engine Security Configuration Register 23 */
    uint32 FWSCR23;
    /* 0x7D60H - */
    /* Forwarding Engine Security Configuration Register 24 */
    uint32 FWSCR24;
    /* 0x7D64H - */
    /* Forwarding Engine Security Configuration Register 25 */
    uint32 FWSCR25;
    /* 0x7D68H - */
    /* Forwarding Engine Security Configuration Register 26 */
    uint32 FWSCR26;
    /* 0x7D6CH - */
    /* Forwarding Engine Security Configuration Register 27 */
    uint32 FWSCR27;
    /* 0x7D70H - */
    /* Forwarding Engine Security Configuration Register 28 */
    uint32 FWSCR28;
    /* 0x7D74H - */
    /* Forwarding Engine Security Configuration Register 29 */
    uint32 FWSCR29;
    /* 0x7D78H - */
    /* Forwarding Engine Security Configuration Register 30 */
    uint32 FWSCR30;
    /* 0x7D7CH - */
    /* Forwarding Engine Security Configuration Register 31 */
    uint32 FWSCR31;
    /* 0x7D80H - */
    /* Forwarding Engine Security Configuration Register 32 */
    uint32 FWSCR32;
    /* 0x7D84H - */
    /* Forwarding Engine Security Configuration Register 33 */
    uint32 FWSCR33;
    /* 0x7D88H - */
    /* Forwarding Engine Security Configuration Register 34 */
    uint32 FWSCR34;
    /* 0x7D8CH - */
    /* Forwarding Engine Security Configuration Register 35 */
    uint32 FWSCR35;
    /* 0x7D90H - */
    /* Forwarding Engine Security Configuration Register 36 */
    uint32 FWSCR36;
    /* 0x7D94H - */
    /* Forwarding Engine Security Configuration Register 37 */
    uint32 FWSCR37;
    /* 0x7D98H - */
    /* Forwarding Engine Security Configuration Register 38 */
    uint32 FWSCR38;
    /* 0x7D9CH - */
    /* Forwarding Engine Security Configuration Register 39 */
    uint32 FWSCR39;
    /* 0x7DA0H - */
    /* Forwarding Engine Security Configuration Register 40 */
    uint32 FWSCR40;
    /* 0x7DA4H - */
    /* Forwarding Engine Security Configuration Register 41 */
    uint32 FWSCR41;
    /* 0x7DA8H - */
    /* Forwarding Engine Security Configuration Register 42 */
    uint32 FWSCR42;
    /* 0x7DACH - */
    /* Forwarding Engine Security Configuration Register 43 */
    uint32 FWSCR43;
    /* 0x7DB0H - */
    /* Forwarding Engine Security Configuration Register 44 */
    uint32 FWSCR44;
    /* 0x7DB4H - */
    /* Forwarding Engine Security Configuration Register 45 */
    uint32 FWSCR45;
    /* 0x7DB8H - */
    /* Forwarding Engine Security Configuration Register 46 */
    uint32 FWSCR46;
    /* 0x7DBCH - */
    /* Forwarding Engine Security Configuration Register 47 */
    uint32 FWSCR47;
    /* 0x7DC0H - */
    /* Forwarding Engine Security Configuration Register 48 */
    uint32 FWSCR48;
    /* 0x7DC4H - */
    /* Forwarding Engine Security Configuration Register 49 */
    uint32 FWSCR49;
    /* 0x7DC8H - */
    uint32 reserved2[14];
    /* 0x7E00H + 4H*i - */
    /* Forwarding Engine Security Configuration Register Two byte filter */
    uint32 FWSCRTOi[16];
    /* 0x7E40H + 4H*i - */
    /* Forwarding Engine Security Configuration Register Three byte filter */
    uint32 FWSCRTHi[4];
    /* 0x7E50H - */
    uint32 reserved3[12];
    /* 0x7E80H + 4H*i - */
    /* Forwarding Engine Security Configuration Register Four byte filter */
    uint32 FWSCRFOi[16];
    /* 0x7EC0H + 4H*i - */
    /* Forwarding Engine Security Configuration Register Range filter */
    uint32 FWSCRRAi[4];
    /* 0x7ED0H - */
    uint32 reserved[12];
    /* 0x7F00H + 4H*i - */
    /* Forwarding Engine Security Configuration Register Cascade filter */
    uint32 FWSCRCAi[16];
    /* 0x7F40H + 4H*i - 0x8000H*/
    uint32 reserved4[48];
} FWSecurity_RegGrpType;

typedef struct
{
    /* 0x0000 - */
    /* General Configuration */
    uint32 FWGC;
    uint32 reserved0[3];

    /* 0x0010 - */
    /* TAG TPID Configuration */
    uint32 FWTTC0;
    uint32 FWTTC1;
    uint32 reserved1[2];

    /* 0x0020 - */
    /* CPU Exceptional Path Configuration */
    uint32 FWCEPTC;
    uint32 FWCEPRC0;
    uint32 FWCEPRC1;
    uint32 FWCEPRC2;

    /* 0x0030 - */
    /* CPU Learning Path Configuration */
    uint32 FWCLPTC;
    uint32 FWCLPRC;
    uint32 reserved2[2];

    /* 0x0040 - */
    /* CPU/Ethernet Mirroring Path Configuration */
    uint32 FWCMPTC;
    uint32 FWCMPL23URC;
    uint32 FWEMPTC;
    uint32 FWEMPL23URC;

    /* 0x0050 - */
    /* Source-Destination Mirroring Path Configuration */
    uint32 FWSDMPTC;
    uint32 FWSDMPVC;
    uint32 FWSDMPL23URC;
    uint32 reserved3;
    /* 0x0060 - */
    uint32 FWSMPTC;
    uint32 FWSMPVC;
    uint32 FWSMPL23URC;
    uint32 reserved4[5];

    /* 0x0080 - */
    /* Level Based WaterMark Configuration */
    uint32 FWLBWMCi[REG_PORT_NUM];
    uint32 reserved10[1];

    /* 0x00C0 - */
    uint32 FWIBWMC;
    uint32 reserved11[15];

    /* 0x0100 - */
    /* Port Configuration */
    FWPCi_RegGrpType stFWPCi[REG_PORT_NUM];
    uint32 reserved20[4];

    /* 0x0200 - */
    uint32 FWPIFPIij[REG_PORT_NUM][ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint32 reserved21[8];

    /* 0x0400 - */
    /* Cut-Through Configuration registers */
    CT_RegGrpType stFWCTi[REG_CT_CRULE_NUM];

    /* 0x0780 - */
    uint32 reserved30[32];

    /* 0x0800 - */
    /* Integrity Check Configuration registers */
    IntegrityCheckIPCfg_RegGrpType stFWICIPi[REG_PORT_NUM];
    uint32 reserved40[16];
    /* 0x0C00 - */
    uint32 reserved41[256];
    /* 0x1000 - */
    IntegrityCheckCfg_RegGrpType stFWICi[REG_PORT_NUM];
    /* 0x2E00 - */
    uint32 reserved42[128];
    /* 0x3000 - */
    uint32 reserved43[1024];

    /* 0x4000 - */
    /* Layer 3 forwarding/routing L2 Stream/Hash filter function registers */
    uint32 reserved50[2];
    uint32 FWIP4SC;
    uint32 reserved51[3];
    uint32 FWIP6SC;
    uint32 FWIP6OC;
    uint32 FWL2SC;
    uint32 reserved52[3];

    /* 0x4030 - */
    uint32 FWSFHEC;
    uint32 reserved53[3];
    /* 0x4040 - */
    uint32 FWSHCR0;
    uint32 FWSHCR1;
    uint32 FWSHCR2;
    uint32 FWSHCR3;
    uint32 FWSHCR4;
    uint32 FWSHCR5;
    uint32 FWSHCR6;
    uint32 FWSHCR7;
    uint32 FWSHCR8;
    uint32 FWSHCR9;
    uint32 FWSHCR10;
    uint32 FWSHCR11;
    uint32 FWSHCR12;
    uint32 FWSHCR13;
    uint32 FWSHCRR;
    uint32 reserved54[5];

    /* 0x4090 - */
    /* Layer 3/4 forwarding/routing hash function registers */
    uint32 FWLTHTEC0;
    uint32 FWLTHTEC1;
    uint32 reserved60[2];
    /* 0x40A0 - */
    uint32 FWLTHTL0;
    uint32 FWLTHTL1;
    uint32 FWLTHTL2;
    uint32 FWLTHTL3;
    /* 0x40B0 - */
    uint32 FWLTHTL4;
    uint32 FWLTHTL5;
    uint32 FWLTHTL6;
    uint32 FWLTHTL7;
    /* 0x40C0 - */
    uint32 FWLTHTL8;
    uint32 FWLTHTL9;
    uint32 FWLTHTL10;
    uint32 FWLTHTL11;
    /* 0x40D0 - */
    uint32 FWLTHTL12;
    uint32 FWLTHTL13i[REG_PORT_GWCA_NUM];
    uint32 reserved61[9];
    /* 0x4100 - */
    uint32 reserved62[4];
    /* 0x4110 - */
    uint32 reserved63[1];
    uint32 FWLTHTL14;
    uint32 FWLTHTL15;
    uint32 FWLTHTLR;
    /* 0x4120 - */
    uint32 FWLTHTIM;
    uint32 FWLTHTEM0;
    uint32 FWLTHTEM1;
    uint32 reserved64[1];
    /* 0x4130 - */
    uint32 FWLTHTS0;
    uint32 FWLTHTS1;
    uint32 FWLTHTS2;
    uint32 FWLTHTS3;
    uint32 FWLTHTS4;
    uint32 FWLTHTS5;
    uint32 FWLTHTS6;
    uint32 reserved65[1];
    /* 0x4150 - */
    uint32 FWLTHTSR0;
    uint32 FWLTHTSR1;
    uint32 FWLTHTSR2;
    uint32 FWLTHTSR3;
    /* 0x4160 - */
    uint32 FWLTHTSR4i[REG_PORT_GWCA_NUM];
    uint32 reserved66[14];
    /* 0x41A0 - */
    uint32 FWLTHTSR5;
    uint32 FWLTHTSR6;
    uint32 FWLTHTSR7;
    uint32 reserved67[1];
    /* 0x41B0 - */
    uint32 FWLTHTR;
    uint32 FWLTHTRR0;
    uint32 FWLTHTRR1;
    uint32 FWLTHTRR2;
    /* 0x41C0 - */
    uint32 FWLTHTRR3;
    uint32 FWLTHTRR4;
    uint32 FWLTHTRR5;
    uint32 FWLTHTRR6;
    /* 0x41D0 - */
    uint32 FWLTHTRR7;
    uint32 FWLTHTRR8;
    uint32 FWLTHTRR9;
    uint32 FWLTHTRR10;
    /* 0x41E0 - */
    uint32 FWLTHTRR11;
    uint32 FWLTHTRR12;
    uint32 FWLTHTRR13i[REG_PORT_GWCA_NUM];
    /* 0x41F0 - */
    uint32 reserved68[8];
    /* 0x4210 - */
    uint32 reserved69[2];
    uint32 FWLTHTRR14;
    uint32 FWLTHTRR15;
    /* 0x4220 - */
    uint32 reserved70[56];
    /* 0x4300 - */
    uint32 FWLTHREUSPC;
    uint32 FWLTHREC;
    uint32 FWLTHREM;
    uint32 reserved71[1];

    /* 0x4310 - */
    uint32 reserved72[188];

    /* Layer 2 forwarding function registers */
    /* MAC Table related registers */
    /* 0x4600 - */
    uint32 FWMACTEC0;
    uint32 reserved80[3];
    /* 0x4610 - */
    uint32 FWMACTL0;
    uint32 FWMACTL1;
    uint32 FWMACTL2;
    uint32 FWMACTL3;
    /* 0x4620 - */
    uint32 FWMACTL4;
    uint32 FWMACTL5;
    uint32 FWMACTL6;
    uint32 FWMACTL7i[REG_PORT_GWCA_NUM];
    uint32 reserved81[3];
    /* 0x4640 - */
    uint32 reserved82[11];
    uint32 FWMACTL8;
    /* 0x4670 - */
    uint32 FWMACTLR;
    uint32 reserved83[3];
    /* 0x4680 - */
    uint32 FWMACTIM;
    uint32 FWMACTEM;
    uint32 reserved84[2];
    /* 0x4690 - */
    uint32 FWMACTS0;
    uint32 FWMACTS1;
    uint32 FWMACTS2;
    uint32 FWMACTS3;
    /* 0x46A0 - */
    uint32 FWMACTSR0;
    uint32 FWMACTSR1;
    uint32 FWMACTSR2i[REG_PORT_GWCA_NUM];
    /* 0x46B0 - */
    uint32 reserved85[12];
    /* 0x46E0 - */
    uint32 reserved86[2];
    uint32 FWMACTSR3;
    uint32 reserved87[1];
    /* 0x46F0 - */
    uint32 FWMACTSR4;
    uint32 FWMACTSR5;
    uint32 FWMACTSR6;
    uint32 reserved88[1];
    /* 0x4700 - */
    uint32 FWMACTR;
    uint32 reserved89[3];
    /* 0x4710 - */
    uint32 FWMACTRR0;
    uint32 FWMACTRR1;
    uint32 FWMACTRR2;
    uint32 FWMACTRR3;
    /* 0x4720 - */
    uint32 FWMACTRR4;
    uint32 FWMACTRR5;
    uint32 FWMACTRR6;
    uint32 FWMACTRR7i[REG_PORT_GWCA_NUM];
    uint32 reserved90[3];
    /* 0x4740 - */
    uint32 reserved91[8];
    /* 0x4760 - */
    uint32 reserved92[3];
    uint32 FWMACTRR8;
    /* 0x4770 - */
    uint32 reserved93[36];
    /* 0x4800 - */
    uint32 FWMACHWLC0;
    uint32 FWMACHWLC1;
    uint32 reserved94[2];
    /* 0x4810 - */
    uint32 FWMACHWLC2i[REG_PORT_NUM];
    uint32 reserved95[1];
    /* 0x4850 - */
    uint32 reserved96[12];
    /* 0x4880 - */
    uint32 FWMACAGUSPC;
    uint32 FWMACAGC;
    uint32 FWMACAGM0;
    uint32 FWMACAGM1;
    /* 0x4890 - */
    uint32 FWMACREUSPC;
    uint32 FWMACREC;
    uint32 FWMACREM;
    uint32 reserved97[25];

    /* 0x4900 - */
    /* VLAN Table related registers */
    uint32 FWVLANTEC;
    uint32 reserved100[3];
    /* 0x4910 - */
    uint32 FWVLANTL0;
    uint32 FWVLANTL1;
    uint32 FWVLANTL2;
    uint32 FWVLANTL3;
    /* 0x4920 - */
    uint32 FWVLANTL4;
    uint32 FWVLANTL5;
    uint32 FWVLANTL6i[REG_PORT_GWCA_NUM];
    /* 0x4930 - */
    uint32 reserved101[12];
    /* 0x4960 - */
    uint32 reserved102[2];
    uint32 FWVLANTL7;
    uint32 FWVLANTLR;
    /* 0x4970 - */
    uint32 FWVLANTIM;
    uint32 FWVLANTEM;
    uint32 reserved103[2];
    /* 0x4980 - */
    uint32 FWVLANTS;
    uint32 FWVLANTSR0;
    uint32 FWVLANTSR1;
    uint32 FWVLANTSR2;
    /* 0x4990 - */
    uint32 FWVLANTSR3;
    uint32 FWVLANTSR4;
    uint32 FWVLANTSR5i[REG_PORT_GWCA_NUM];
    /* 0x49A0 - */
    uint32 reserved104[8];
    /* 0x49C0 - */
    uint32 reserved105[2];
    uint32 FWVLANTSR6;
    uint32 reserved106[13];

    /* 0x4A00 - */
    /* Port based forwarding function registers */
    FWPBi_RegGrpType stFWPBi[REG_PORT_NUM];
    uint32 reserved110[4];
    /* 0x4B00 - */
    FWPBFCSDCji_RegGrpType stFWPBFCSDCji[REG_PORT_NUM];
    uint32 reserved111[8];
    /* 0x4D00 - */
    uint32 reserved112[64];

    /* 0x4E00 - */
    /* Layer 2/Layer 3 update function registers */
    uint32 FWL23URL0;
    uint32 FWL23URL1;
    uint32 FWL23URL2;
    uint32 FWL23URL3;
    /* 0x4E10 - */
    uint32 FWL23URLR;
    uint32 reserved120[3];
    /* 0x4E20 - */
    uint32 FWL23UTIM;
    uint32 reserved121[3];
    /* 0x4E30 - */
    uint32 FWL23URR;
    uint32 FWL23URRR0;
    uint32 FWL23URRR1;
    uint32 FWL23URRR2;
    /* 0x4E40 - */
    uint32 FWL23URRR3;
    uint32 reserved122[47];
    /* 0x4F00 - */
    uint32 FWL23URMCi[REG_LTH_REMAP_NUM];
    uint32 reserved123[32];

    /* 0x5000 - */
    /* PSFP (Per Stream Filtering and Policing) [802.1Qci] */
    uint32 FWPMFGCi[REG_ETHSWTCONT_PSFP_MSDU_NUM];
    uint32 reserved124[48];
    /* 0x5100 - */
    FWPGi_RegGrpType stFWPGi[REG_ETHSWTCONT_PSFP_GATE_NUM];
    uint32 reserved125[128];
    /* 0x5500 - */
    uint32 FWPGFGL0;
    uint32 FWPGFGL1;
    uint32 FWPGFGLR;
    uint32 reserved126;
    /* 0x5510 - */
    uint32 FWPGFGR;
    uint32 FWPGFGRR0;
    uint32 FWPGFGRR1;
    uint32 reserved127;
    /* 0x5520 - */
    uint32 FWPGFRIM;
    uint32 reserved128[695];

    /* 0x6000 - */
    /* FRER (Frame Replication and Elimination for Reliability) [802.1CB] */
    uint32 FWFTL0;
    uint32 FWFTL1;
    uint32 FWFTLR;
    uint32 reserved130;
    /* 0x6010 - */
    uint32 FWFTOC;
    uint32 FWFTOPC;
    uint32 reserved131[2];
    /* 0x6020 - */
    uint32 FWFTIM;
    uint32 reserved132[3];
    /* 0x6030 - */
    uint32 FWFTR;
    uint32 FWFTRR0;
    uint32 FWFTRR1;
    uint32 FWFTRR2;
    uint32 reserved133[48];
    /* 0x6100 - */
    FWSEQi_RegGrpType stFWSEQi[REG_LTH_SEQGN_NUM];
    /* 0x6200 - */
    uint32 FWSEQNRC;
    uint32 reserved134[63];

    /* 0x6300 - */
    /* Forwarding Engine Counter registers */
    MFWDCounter_RegGrpType stMFWDCounterReg[REG_PORT_NUM];
    uint32 reserved140[8];
    /* 0x6500 - */
    /* Forwarding Engine Reject Counter registers */
    MFWDRejectCounter_RegGrpType stMFWDRejectCounterReg[REG_PORT_NUM];
    uint32 reserved141[8];
    /* 0x6700 - */
    /* Forwarding Engine MSDU Counter registers */
    uint32 FWPMFDCNi[REG_ETHSWTCONT_PSFP_MSDU_NUM];
    uint32 reserved142[16];
    /* 0x6780 - */
    /* Forwarding Engine Gate Counter registers */
    uint32 FWPGFDCNi[REG_ETHSWTCONT_PSFP_GATE_NUM];
    uint32 reserved143[24];
    /* 0x6800 - */
    uint32 reserved150[128];
    /* 0x6A00 - */
    /* Forwarding Engine FRER Counter registers */
    uint32 reserved160[960];
    /* 0x7900 - */
    /* Forwarding Engine Error Interrupt registers */
    uint32 reserved170[256];
    /* 0x7D00 - */
    /* Forwarding Engine Security Configuration registers */
    FWSecurity_RegGrpType stMFWDSecurityReg;
    /* Perfect Filter related registers */
    /* 0x8000 - */
    FWTWBFi_RegGrpType stFWTWBFi[REG_PFL_2BF_NUM];
    /* 0xA000 - */
    FWTHBFi_RegGrpType stFWTHBFi[REG_PFL_3BF_NUM];
    uint32 reserved200[512];
    /* 0xB000 - */
    FWFOBFi_RegGrpType stFWFOBFi[REG_PFL_4BF_NUM];
    /* 0xD000 - */
    FWRFi_RegGrpType stFWRFi[REG_PFL_RF_N];
    uint32 reserved201[512];
    /* 0xE000 - */
    FWCFi_RegGrpType stFWCFi[REG_PFL_CF_N];

    /* 0x16000 - */
    /* Forwarding Engine Block/Acceptance List Counter registers */
    MFWDListFilterCounter_RegGrpType stMFWDListFilterCounterReg[REG_PORT_NUM];
    uint32 reserved210[1928];

    /* 0x18000 - */
    FWPMTRi_RegGrpType stFWPMTRi[REG_ETHSWTCONT_PSFP_MTR_NUM];
    uint32 reserved220[192];

    /* 0x19000 - */
    /* Forwarding Engine Meter Counter registers */
    MeterCounter_RegGrpType stMeterCounterReg[REG_ETHSWTCONT_PSFP_MTR_NUM];
} EthSwtCont_MfwdRegType;


/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"

extern CONSTP2VAR(volatile EthSwtCont_MfwdRegType, AUTOMATIC, REGSPACE) EthSwtCont_GpMfwdReg;

#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
#endif /* CDD_ETHSWTCONT_REGMFWD_H */
