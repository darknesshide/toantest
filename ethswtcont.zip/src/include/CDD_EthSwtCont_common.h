/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : The common definition used in Ethernet Switch Control.
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_COMMON_H
#define CDD_ETHSWTCONT_COMMON_H

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* R-Switch Configuration */
#define AXI_CHAIN_NUM               128U
#define VLANID_NUM                  4096UL
#define ETHERTYPE_IPV4              0x0800U
#define ETHERTYPE_IPV6              0x86DDU
#define TPID_MIN                    0x0600U
#define ETHSWTCONT_PORT_SLOW_NUM    2U
/* Port number mask */
#define ETHSWTCONT_PORT_MASK        0x7FFFUL
#define ETHSWTCONT_PORT_ETHA_MASK   0x1FFFUL
/* FWPC0i register reserve bit mask */
#define MASK_RSVFWPC0               0x000EFC00UL
/* FWPC0i register reserve bit mask in No VLAN mode */
#define MASK_RSVFWPC0_NOVLAN        0xF00EFC00UL
/* FWCEPRC0 register reserve bit mask */
#define MASK_RSVFWCEPRC0            0x8888000UL
/* FWCEPRC1 register reserve bit mask */
#define MASK_RSVFWCEPRC1            0xFFFCFCF8UL
/* FWCEPRC2 register reserve bit mask */
#define MASK_RSVFWCEPRC2            0xE2C6E4C6UL
/* FWCLPRC register reserve bit mask */
#define MASK_RSVFWCLPRC             0xFFFFFF0EUL
/* R-Switch Base Address */
#define ETHSWTCONT_RSWITCH_BASEADDR 0xC9B80000UL
/* R-Switch Base Address (Module) */
#define ETHSWTCONT_MFWD_BASEADDR    (ETHSWTCONT_RSWITCH_BASEADDR + 0x00000000UL)
#define ETHSWTCONT_COMA_BASEADDR    (ETHSWTCONT_RSWITCH_BASEADDR + 0x0001C000UL)
#define ETHSWTCONT_TSNA0_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0001D000UL)
#define ETHSWTCONT_RMAC0_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0001E000UL)
#define ETHSWTCONT_TSNA1_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0001F000UL)
#define ETHSWTCONT_RMAC1_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00020000UL)
#define ETHSWTCONT_TSNA2_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00021000UL)
#define ETHSWTCONT_RMAC2_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00022000UL)
#define ETHSWTCONT_TSNA3_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00023000UL)
#define ETHSWTCONT_RMAC3_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00024000UL)
#define ETHSWTCONT_TSNA4_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00025000UL)
#define ETHSWTCONT_RMAC4_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00026000UL)
#define ETHSWTCONT_TSNA5_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00027000UL)
#define ETHSWTCONT_RMAC5_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00028000UL)
#define ETHSWTCONT_TSNA6_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00029000UL)
#define ETHSWTCONT_RMAC6_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0002A000UL)
#define ETHSWTCONT_TSNA7_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0002B000UL)
#define ETHSWTCONT_RMAC7_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0002C000UL)
#define ETHSWTCONT_TSNA8_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0002D000UL)
#define ETHSWTCONT_RMAC8_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0002E000UL)
#define ETHSWTCONT_TSNA9_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x0002F000UL)
#define ETHSWTCONT_RMAC9_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00030000UL)
#define ETHSWTCONT_TSNA10_BASEADDR  (ETHSWTCONT_RSWITCH_BASEADDR + 0x00031000UL)
#define ETHSWTCONT_RMAC10_BASEADDR  (ETHSWTCONT_RSWITCH_BASEADDR + 0x00032000UL)
#define ETHSWTCONT_TSNA11_BASEADDR  (ETHSWTCONT_RSWITCH_BASEADDR + 0x00033000UL)
#define ETHSWTCONT_RMAC11_BASEADDR  (ETHSWTCONT_RSWITCH_BASEADDR + 0x00034000UL)
#define ETHSWTCONT_TSNA12_BASEADDR  (ETHSWTCONT_RSWITCH_BASEADDR + 0x00035000UL)
#define ETHSWTCONT_RMAC12_BASEADDR  (ETHSWTCONT_RSWITCH_BASEADDR + 0x00036000UL)
#define ETHSWTCONT_GWCA0_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00037000UL)
#define ETHSWTCONT_GWCA1_BASEADDR   (ETHSWTCONT_RSWITCH_BASEADDR + 0x00039000UL)

/* Register Set/Clear */
#define ETHSWTCONT_REG_CLR          0UL
#define ETHSWTCONT_REG_SET          1UL
/* CPU Sec/Unsec status */
#define ETHSWTCONT_SEC_CPU          0U
#define ETHSWTCONT_UNSEC_CPU        1U
/* Flag Set/Clear */
#define ETHSWTCONT_FLAG_CLR         0U
#define ETHSWTCONT_FLAG_SET         1U
/* Flag IPv4/IPv6 */
#define ETHSWTCONT_FLAG_IPV4        0U
#define ETHSWTCONT_FLAG_IPV6        1U
/* Flag ENABLE/DISABLE */
#define ETHSWTCONT_DISABLE          0U
#define ETHSWTCONT_ENABLE           1U
/* Agent mode */
#define ETHSWTCONT_MODE_RESET       0U
#define ETHSWTCONT_MODE_DISABLE     1U
/* Status Init/Uninit */
#define ETHSWTCONT_STS_UNINIT 0U
#define ETHSWTCONT_STS_INIT   1U
/* Status Statistical function */
#define ETHSWTCONT_STS_STOP   0U
#define ETHSWTCONT_STS_START  1U
/* Register Size definition */
#define REGSIZE_IN_BYTE             4U
#define REGSIZE_IN_BIT              32U
/* RCEC RCE bit */
#define ETHSWTCONT_COMA_RCEC_RCE    0x00010000UL
/* Address Array element definition */
#define ETHSWTCONT_MACADDR_UPPER    0U
#define ETHSWTCONT_MACADDR_DOWNER   1U
#define ETHSWTCONT_DESCADDR_UPPER   0U
#define ETHSWTCONT_DESCADDR_DOWNER  1U
/* Timeout time */
#define ETHSWTCONT_LOOP_COUNT       100000UL
#define ETHSWTCONT_TIMEOUT_COUNT    5376000UL
/* Bit Mask */
#define MASK_1BIT   0x00000001UL
#define MASK_2BIT   0x00000003UL
#define MASK_3BIT   0x00000007UL
#define MASK_4BIT   0x0000000FUL
#define MASK_5BIT   0x0000001FUL
#define MASK_6BIT   0x0000003FUL
#define MASK_8BIT   0x000000FFUL
#define MASK_9BIT   0x000001FFUL
#define MASK_10BIT  0x000003FFUL
#define MASK_11BIT  0x000007FFUL
#define MASK_13BIT  0x00001FFFUL
#define MASK_14BIT  0x00003FFFUL
#define MASK_16BIT  0x0000FFFFUL
#define MASK_17BIT  0x0001FFFFUL
#define MASK_24BIT  0x00FFFFFFUL
#define MASK_26BIT  0x03FFFFFFUL
#define MASK_31BIT  0x7FFFFFFFUL
#define MASK_32BIT  0xFFFFFFFFUL
/* Bit Shift */
#define SHIFT_1BIT  1UL
#define SHIFT_2BIT  2UL
#define SHIFT_3BIT  3UL
#define SHIFT_4BIT  4UL
#define SHIFT_5BIT  5UL
#define SHIFT_6BIT  6UL
#define SHIFT_7BIT  7UL
#define SHIFT_8BIT  8UL
#define SHIFT_9BIT  9UL
#define SHIFT_10BIT 10UL
#define SHIFT_11BIT 11UL
#define SHIFT_12BIT 12UL
#define SHIFT_13BIT 13UL
#define SHIFT_14BIT 14UL
#define SHIFT_15BIT 15UL
#define SHIFT_16BIT 16UL
#define SHIFT_17BIT 17UL
#define SHIFT_18BIT 18UL
#define SHIFT_19BIT 19UL
#define SHIFT_20BIT 20UL
#define SHIFT_21BIT 21UL
#define SHIFT_22BIT 22UL
#define SHIFT_23BIT 23UL
#define SHIFT_24BIT 24UL
#define SHIFT_25BIT 25UL
#define SHIFT_26BIT 26UL
#define SHIFT_28BIT 28UL
#define SHIFT_29BIT 29UL
#define SHIFT_30BIT 30UL
#define SHIFT_31BIT 31UL

/* Constants definition */
#define NUM0        0U
#define NUM1        1U
#define NUM2        2U
#define NUM8        8U

/* Array index definition */
#define IDX_0       0U
#define IDX_1       1U
#define IDX_2       2U
#define IDX_3       3U
#define IDX_4       4U
#define IDX_5       5U
#define IDX_6       6U
#define IDX_7       7U

/* Watermark number definition */
#define LCL_PTR_N        8192U

/*******************************************************************************
Typedef definitions
*******************************************************************************/
typedef struct
{
    uint8 ucDei;
    uint8 ucPcp;
    uint16 usVlanId;
} EthSwtCont_VlanTagType;

/******************************************************************************
General Configuration
******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define ETHSWTCONT_START_SEC_VAR_INIT_8
#include "EthSwtCont_MemMap.h"

extern VAR(uint8, ETHSWTCONT_VAR_INIT) EthSwtCont_GucInitStatus;

#define ETHSWTCONT_STOP_SEC_VAR_INIT_8
#include "EthSwtCont_MemMap.h"
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_ETHSWTCONT_COMMON_H */
