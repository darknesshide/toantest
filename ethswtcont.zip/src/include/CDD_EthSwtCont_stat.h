/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains prototypes of functions and the data used only in the same module "stat".
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_STAT_H
#define CDD_ETHSWTCONT_STAT_H

#include "rcar-xos/ethswtcont/CDD_EthSwtCont.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"

extern FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_StatMain(void);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetStatCfg(const R_EthSwtCont_StatCfgType *pStatConfig, 
    R_EthSwtCont_StatFuncPtrType pStatCbFunc, R_EthSwtCont_NotifyFuncPtrType pStatNotifyCbFunc);
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_GetStatCfg(R_EthSwtCont_StatCfgType *pStatConfig);
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_ClearStatAll(void);

#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
#endif /* CDD_ETHSWTCONT_STAT_H */
