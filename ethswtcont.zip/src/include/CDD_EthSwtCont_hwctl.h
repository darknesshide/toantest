/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : HW Control Function header.
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_HWCTL_H
#define CDD_ETHSWTCONT_HWCTL_H

#include "rcar-xos/ethswtcont/CDD_EthSwtCont.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define ETHSWTCONT_START_SEC_VAR_NO_INIT_8
#include "EthSwtCont_MemMap.h" 

extern VAR(uint8, ETHSWTCONT_VAR_NO_INIT) EthSwtCont_GucVlanMode;

#define ETHSWTCONT_STOP_SEC_VAR_NO_INIT_8
#include "EthSwtCont_MemMap.h" 

#define ETHSWTCONT_START_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_InitMfwd(const R_EthSwtCont_MfwdCfgType *pMfwdConfig);
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetMfwdPort(const R_EthSwtCont_MfwdPortCfgType *pMfwdPortConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetRoutTbl(const R_EthSwtCont_RoutCfgType *pRoutConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_LearnRoutTbl(const R_EthSwtCont_RoutCfgType *pRoutConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckMfwdCfg(const R_EthSwtCont_MfwdCfgType *pMfwdConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckMfwdPortCfg(const R_EthSwtCont_MfwdPortCfgType *pMfwdPortConfig
#if (ETHSWTCONT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckRoutCfg(const R_EthSwtCont_RoutCfgType *pRoutConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckUpdateRoutCfg(const R_EthSwtCont_RoutCfgType *pRoutConfig);
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE)   EthSwtCont_EnableClock(void);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_InitBuffPool(const R_EthSwtCont_WatermarkCfgType *pWatermarkCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckBuffPool(const R_EthSwtCont_WatermarkCfgType *pWatermarkCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_ResetEthSwt(void);
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE)   EthSwtCont_SetCutThrough(const R_EthSwtCont_CTCfgType *pCTCfg, const uint32 ulEntryNum);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckCutThrough(const R_EthSwtCont_CTCfgType *pCTCfg, const uint32 ulEntryNum);
extern FUNC(void, ETHSWTCONT_PRIVATE_CODE)   EthSwtCont_SetIntegrityCheck(const R_EthSwtCont_ICCfgType *pICCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_CheckIntegrityCheck(const R_EthSwtCont_ICCfgType *pICCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecICConfiguration(const R_EthSwtCont_MFWDSecICCfgType *pSecICCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecConfiguration(const R_EthSwtCont_MFWDSecCfgType *pSecCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecPortConfiguration(const R_EthSwtCont_MFWDSecPortCfgType *pSecPortCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecL2TblConfiguration(const R_EthSwtCont_MFWDSecL2TblCfgType *pSecL2Cfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecPFConfiguration(const R_EthSwtCont_MFWDSecPFCfgType *pSecPFCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecL2L3StreamConfiguration(const R_EthSwtCont_MFWDSecL2L3StreamCfgType *pSecL2L3Cfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecL2L3UpConfiguration(const R_EthSwtCont_MFWDSecL2L3UpCfgType *pSecL2L3UpCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecPSFPConfiguration(const R_EthSwtCont_MFWDSecPSFPCfgType *pSecPSFPCfg);
extern FUNC(Std_ReturnType, ETHSWTCONT_PRIVATE_CODE) EthSwtCont_SetSecCOMAConfiguration(const uint8 ucSecCfg);

#define ETHSWTCONT_STOP_SEC_PRIVATE_CODE
#include "EthSwtCont_MemMap.h"

#endif /* CDD_ETHSWTCONT_HWCTL_H */
