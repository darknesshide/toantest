/***********************************************************************************************************************
* Copyright [2023] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.3.0
* Description  : R-Switch3 GWCA/TSNA/RMAC register definition.
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_REG_H
#define CDD_ETHSWTCONT_REG_H

#include "rcar-xos/ethswtcont/CDD_EthSwtCont.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* Register definition for GWCA module */
typedef struct
{
    /* 0x0000 - */
    uint32 GWMC;
    uint32 GWMS;
} EthSwtCont_GwcaRegType;

/* Register definition for TSNA module */
typedef struct
{
    /* 0x0000 - */
    uint32 EAMC;
    uint32 EAMS;
} EthSwtCont_TsnaRegType;

/* Register definition for RMAC module */
typedef struct
{
    /* 0x0000 - */
    /* Used only counter registers. */
    uint32 reserved0[192];
    /* 0x0300 - */
    uint32 MMPFTCT;
    uint32 MAPFTCT;
    uint32 MPFRCT;
    uint32 MFCICT;
    /* 0x0310 - */
    uint32 MEEECT;
    uint32 reserved1[3];
    /* 0x0320 - */
    uint32 MMPCFTCTt[ETHSWTCONT_PAS_LVL_N];
    uint32 reserved2[2];
    /* 0x0330 - */
    uint32 MAPCFTCTt[ETHSWTCONT_PAS_LVL_N];
    uint32 reserved3[2];
    /* 0x0340 - */
    uint32 MPCFRCTt[ETHSWTCONT_FRAME_PRIORITY_NUM];
    /* 0x0360 - */
    uint32 MROVFC;
    uint32 MRHCRCEC;
    uint32 reserved4[38];
    /* 0x0400 - */
    uint32 reserved5[2];
    uint32 MRGFCE;
    uint32 MRGFCP;
    /* 0x0410 - */
    uint32 MRBFC;
    uint32 MRMFC;
    uint32 MRUFC;
    uint32 MRPEFC;
    /* 0x0420 - */
    uint32 MRNEFC;
    uint32 MRFMEFC;
    uint32 MRFFMEFC;
    uint32 MRCFCEFC;
    /* 0x0430 - */
    uint32 MRFCEFC;
    uint32 MRRCFEFC;
    uint32 MRFC;
    uint32 MRGUEFC;
    /* 0x0440 - */
    uint32 MRBUEFC;
    uint32 MRGOEFC;
    uint32 MRBOEFC;
    uint32 MRXBCEU;
    /* 0x0450 - */
    uint32 MRXBCEL;
    uint32 MRXBCPU;
    uint32 MRXBCPL;
    uint32 reserved6[41];
    /* 0x0500 - */
    uint32 reserved7[2];
    uint32 MTGFCE;
    uint32 MTGFCP;
    /* 0x0510 - */
    uint32 MTBFC;
    uint32 MTMFC;
    uint32 MTUFC;
    uint32 MTEFC;
    /* 0x0520 - */
    uint32 MTXBCEU;
    uint32 MTXBCEL;
    uint32 MTXBCPU;
    uint32 MTXBCPL;
} EthSwtCont_RmacRegType;

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_ETHSWTCONT_REG_H */
