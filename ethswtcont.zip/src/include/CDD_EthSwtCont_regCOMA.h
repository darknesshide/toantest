/***********************************************************************************************************************
* Copyright [2023] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.3.0
* Description  : R-Switch3 COMA register definition.
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_REGCOMA_H
#define CDD_ETHSWTCONT_REGCOMA_H

#include "rcar-xos/ethswtcont/CDD_EthSwtCont.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* Register definition for COMA module */
typedef struct
{
    /* 0x0000 - */
    uint32 RIPV;
    /* 0x0004 - */
    uint32 RRC;
    /* 0x0008 - */
    uint32 RCEC;
    /* 0x000C - */
    uint32 RCDC;
    /* 0x0010 - */
    uint32 RSSIS;
    /* 0x0014 - */
    uint32 RSSIE;
    /* 0x0018 - */
    uint32 RSSID;
    /* 0x001C - */
    uint32 reserved0;
    /* 0x0020 - 0x0024 - 0x0028 - 0x002C - 0x0030 - 0x0034 - 0x0038 - 0x003C*/
    uint32 CABPIBWMCi[ETHSWTCONT_FRAME_PRIORITY_NUM];
    /* 0x0040 - */
    uint32 CABPWMLC;
    /* 0x0044 - */
    uint32 reserved1[3];
    /* 0x0050 - 0x0054*/
    uint32 CABPPFLCi[ETHSWTCONT_PAS_LVL_N];
    /* 0x0058 - 0x005C*/
    uint32 reserved2[2];
    /* 0x0060 - 0x0070 - 0x0080 - 0x0090 - 0x0098 */
    uint32 CABPPWMLCi[ETHSWTCONT_PORT_NUM];
    /* 0x009C */
    uint32 reserved3;
    /* 0x00A0 - 0x00B0 - 0x00C0 - 0x00D0 - 0x00E0 - 0x00F0 - 0x0100 - 0x0110 - 0x0114 */
    uint32 CABPPPFLCij[ETHSWTCONT_PORT_NUM][ETHSWTCONT_PAS_LVL_N];
    /* 0x0118 - 0x011C */
    uint32 reserved4[2];
    /* 0x0120 - 0x0130 - 0x0140 - 0x0150 - 0x0158*/
    uint32 CABPULCi[ETHSWTCONT_PORT_NUM];
    /* 0x015C */
    uint32 reserved5;
    /* 0x0160 - */
    uint32 CABPIRM;
    /* 0x0164 - */
    uint32 CABPPCM;
    /* 0x0168 - */
    uint32 CABPLCM;
    /* 0x016C - */
    uint32 reserved6[5];
    /* 0x0180 - 0x0190 - 0x01A0 - 0x01B0 - 0x01B8 */
    uint32 CABPCPMi[ETHSWTCONT_PORT_NUM];
    /* 0x01BC - 0x01C0 - */
    uint32 reserved7[17];
    /* 0x0200 - 0x0210 - 0x0220 - 0x0230 -*/
    uint32 CABPMCPMi[ETHSWTCONT_PORT_NUM];
    /* 0x023C - 0x0240 - */
    uint32 reserved8[49];
    /* 0x0300 - */
    uint32 CARDNM;
    /* 0x0304 - */
    uint32 CARDMNM;
    /* 0x0308 - */
    uint32 reserved9[2];
    /* 0x0310 - */
    uint32 CARDCN;
    /* 0x0314 - */
    uint32 reserved10[59];
    /* 0x0400 - */
    uint32 CAEIS0;
    /* 0x0404 - */
    uint32 CAEIE0;
    /* 0x0408 - */
    uint32 CAEID0;
    /* 0x040C - */
    uint32 reserved11;
    /* 0x0410 - */
    uint32 CAEIS1;
    /* 0x0414 - */
    uint32 CAEIE1;
    /* 0x0418 - */
    uint32 CAEID1;
    /* 0x041C - */
    uint32 reserved12[9];
    /* 0x0440 - */
    uint32 CAMIS0;
    /* 0x0444 - */
    uint32 CAMIE0;
    /* 0x0448 - */
    uint32 CAMID0;
    /* 0x044C - */
    uint32 reserved13;
    /* 0x0450 - */
    uint32 CAMIS1;
    /* 0x0454 - */
    uint32 CAMIE1;
    /* 0x0458 - */
    uint32 CAMID1;
    /* 0x045C - */
    uint32 reserved14[9];
    /* 0x0480 - */
    uint32 CASCR;
    
} EthSwtCont_ComaRegType;

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_ETHSWTCONT_REGCOMA_H */
