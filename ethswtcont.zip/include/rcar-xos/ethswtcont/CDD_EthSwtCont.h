/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file defines the Ethernet Switch Control Interface and type definitions.
***********************************************************************************************************************/
#ifndef CDD_ETHSWTCONT_H
#define CDD_ETHSWTCONT_H

#include "Std_Types.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Module Define */
#define ETHSWTCONT_VENDOR_ID           ETHSWTCONT_VENDOR_ID_VALUE
#define ETHSWTCONT_MODULE_ID           ETHSWTCONT_MODULE_ID_VALUE
#define ETHSWTCONT_INSTANCE_ID         ETHSWTCONT_INSTANCE_ID_VALUE

/* Service ID for Ethswtcont */
#define R_ETHSWTCONT_INIT_SID              (uint8)0x00U
#define R_ETHSWTCONT_UPDATEROUTTBL_SID     (uint8)0x01U
#define R_ETHSWTCONT_MAINFUNCTION_SID      (uint8)0x02U
#define R_ETHSWTCONT_SETSTATCFG_SID        (uint8)0x03U
#define R_ETHSWTCONT_GETSTATCFG_SID        (uint8)0x04U
#define R_ETHSWTCONT_STATSTART_SID         (uint8)0x05U
#define R_ETHSWTCONT_STATEND_SID           (uint8)0x06U
#define R_ETHSWTCONT_CLEARSTATALL_SID      (uint8)0x07U
#define R_ETHSWTCONT_SETSEC_SID            (uint8)0x08U
/* Error ID for Ethswtcont */
#define ETHSWTCONT_E_UNINIT             (uint8)0x02U
#define ETHSWTCONT_E_PARAM_POINTER      (uint8)0x03U
#define ETHSWTCONT_E_CFG                (uint8)0x04U
#define ETHSWTCONT_E_CFG_MFWD           (uint8)0x05U
#define ETHSWTCONT_E_CFG_PF             (uint8)0x06U
#define ETHSWTCONT_E_CFG_STREAM         (uint8)0x07U
#define ETHSWTCONT_E_CFG_MACTBL         (uint8)0x09U
#define ETHSWTCONT_E_CFG_VLANTBL        (uint8)0x0AU
#define ETHSWTCONT_E_CFG_PORTBASED      (uint8)0x0BU
#define ETHSWTCONT_E_CFG_L2L3UPTBL      (uint8)0x0CU
#define ETHSWTCONT_E_CFG_MFWDPORT       (uint8)0x0DU
#define ETHSWTCONT_E_CFG_MSDU           (uint8)0x0EU
#define ETHSWTCONT_E_CFG_GATE           (uint8)0x0FU
#define ETHSWTCONT_E_CFG_METER          (uint8)0x10U
#define ETHSWTCONT_E_CFG_WATERMARK      (uint8)0x11U
#define ETHSWTCONT_E_CFG_STAT           (uint8)0x13U
#define ETHSWTCONT_E_PARAM_CONFIG       (uint8)0x14U
#define ETHSWTCONT_E_CFG_CUTTHROUGH     (uint8)0x15U
#define ETHSWTCONT_E_CFG_ICCHECK        (uint8)0x16U

/* Integrity check code */
#define ETHSWTCONT_CHECK_CODE           0x12345678UL
/* Port number */
#define ETHSWTCONT_PORT_NUM             15U
#define ETHSWTCONT_PORT_GWCA_NUM        2U
#define ETHSWTCONT_PORT_TSNA_NUM        13U
/* Address length */
#define ETHSWTCONT_MACADDR_WORD_SIZE    2U
#define ETHSWTCONT_IPADDR_WORD_SIZE     4U
#define ETHSWTCONT_STREAMID_WORD_SIZE   4U
/* Number of Cascade Filter mapped filter */
#define ETHSWTCONT_PFL_CFMF_NUM         7U
/* 2/3/4 Byte and Range Filter set value number */
#define ETHSWTCONT_BYTEFILTER_NUM       2U
/* IPv6 Address part number */
#define ETHSWTCONT_IPV6PART_NUM       2U
/* Ethernet frame priority number */
#define ETHSWTCONT_FRAME_PRIORITY_NUM    8U
/* Pause level number */
#define ETHSWTCONT_PAS_LVL_N       2U
/* PSFP number definition */
#define ETHSWTCONT_PSFP_GATE_NUM       8U
#define ETHSWTCONT_PSFP_MSDU_NUM       16U
#define ETHSWTCONT_PSFP_RECE_NUM       128U
#define ETHSWTCONT_PSFP_MTR_NUM        104U
#define ETHSWTCONT_PSFP_DMTR_N         104U
/* Statistical info number */
#define ETHSWTCONT_STAT_NUM 42U
#define ETHSWTCONT_MFWDPORTSTAT_NUM  12U
#define ETHSWTCONT_RMACPORTSTAT_NUM  25U

#define ETHSWTCONT_INTG_ETYPE_N 8U

#define ETHSWTCONT_FMT_PERFECTFILTER 1U
/* Security info number */
#define ETHSWTCONT_FRERRSL_NUM 4U
#define ETHSWTCONT_PMTRRSL_NUM 4U
#define ETHSWTCONT_FWSCRCA_NUM 16U
#define ETHSWTCONT_FWSCRRA_NUM 4U
#define ETHSWTCONT_FWSCRFO_NUM 16U
#define ETHSWTCONT_FWSCRTH_NUM 4U
#define ETHSWTCONT_FWSCRTO_NUM 16U
#define ETHSWTCONT_L23URSL_NUM 8U

/*******************************************************************************
Typedef definitions
*******************************************************************************/
typedef enum
{
    ETHSWTCONT_IPOFFSET_SRC,
    ETHSWTCONT_IPOFFSET_DEST
} R_EthSwtCont_IPOffsetType;

typedef enum
{
    ETHSWTCONT_STAT_FWDDIRECTDESC,
    ETHSWTCONT_STAT_FWDL3,
    ETHSWTCONT_STAT_FWDL2,
    ETHSWTCONT_STAT_FWDPORTBASED,
    ETHSWTCONT_STAT_MACHWLEARN,
    ETHSWTCONT_STAT_REJECTWATERMARK,
    ETHSWTCONT_STAT_REJECTDIRECTDESC,
    ETHSWTCONT_STAT_REJECTL3,
    ETHSWTCONT_STAT_REJECTL2,
    ETHSWTCONT_STAT_REJECTPORTBASED,
    ETHSWTCONT_STAT_FWDBL,
    ETHSWTCONT_STAT_FWDAL,
    ETHSWTCONT_STAT_FILTERMSDU,
    ETHSWTCONT_STAT_FILTERGATE,
    ETHSWTCONT_STAT_METERGREEN,
    ETHSWTCONT_STAT_METERYELLOW,
    ETHSWTCONT_STAT_METERRED,
    ETHSWTCONT_STAT_MANUALPAUSETX,
    ETHSWTCONT_STAT_AUTOPAUSETX,
    ETHSWTCONT_STAT_PAUSERX,
    ETHSWTCONT_STAT_FALSECARRIER,
    ETHSWTCONT_STAT_ENERGYETH,
    ETHSWTCONT_STAT_MANUALPFCTX0,
    ETHSWTCONT_STAT_MANUALPFCTX1,
    ETHSWTCONT_STAT_AUTOPFCTX0,
    ETHSWTCONT_STAT_AUTOPFCTX1,
    ETHSWTCONT_STAT_PFCRX0,
    ETHSWTCONT_STAT_PFCRX1,
    ETHSWTCONT_STAT_PFCRX2,
    ETHSWTCONT_STAT_PFCRX3,
    ETHSWTCONT_STAT_PFCRX4,
    ETHSWTCONT_STAT_PFCRX5,
    ETHSWTCONT_STAT_PFCRX6,
    ETHSWTCONT_STAT_PFCRX7,
    ETHSWTCONT_STAT_HEADCRCERRRX,
    ETHSWTCONT_STAT_GOODEFRAMERX,
    ETHSWTCONT_STAT_GOODPFRAMERX,
    ETHSWTCONT_STAT_FINALFLAGERRRX,
    ETHSWTCONT_STAT_CFLAGERRRX,
    ETHSWTCONT_STAT_RMACFILTERRRX,
    ETHSWTCONT_STAT_GOODEFRAMETX,
    ETHSWTCONT_STAT_GOODPFRAMETX
} R_EthSwtCont_StatIdType;

typedef struct
{
    uint8 ucSecLv;
    uint8 ucCpuSel;
    uint8 ucIpvVal;
    uint8 ucCpuSubDest;
    uint32 ulExceptFlag0;
    uint32 ulExceptFlag1;
    uint32 ulExceptFlag2;
} R_EthSwtCont_CpuExPathCfgType;

typedef struct
{
    uint8 ucSecLv;
    uint8 ucCpuSel;
    uint8 ucIpvVal;
    uint8 ucCpuSubDest;
    uint32 ulLrnFlag;
} R_EthSwtCont_CpuLrnPathCfgType;

typedef struct
{
    uint8 ucSecLv;
    uint8 ucCpuSel;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucCpuSubDest;
    uint16 usRoutNo;
    uint8 ucRoutValid;
} R_EthSwtCont_CpuMrrPathCfgType;

typedef struct
{
    uint8 ucSecLv;
    uint8 ucPortSel;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint16 usRoutNo;
    uint8 ucRoutValid;
} R_EthSwtCont_EthMrrPathCfgType;

typedef struct
{
    uint8 ucSecLv;
    uint8 ucPortSel;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucCpuSubDest;
    uint16 usSrcVec;
    uint16 usDestVec;
    uint16 usRoutNo;
    uint8 ucRoutValid;
} R_EthSwtCont_SDMrrPathCfgType;

typedef struct
{
    uint8 ucSecLv;
    uint8 ucPortSel;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucCpuSubDest;
    uint16 usSrcVec;
    uint16 usRoutNo;
    uint8 ucRoutValid;
} R_EthSwtCont_SrcMrrPathCfgType;

typedef struct
{
    uint8 ucSVlanMode;
    uint8 ucL3UnknownFRPriority;
    uint8 ucL2UnknownFRPriority;
    uint8 ucFilteringPriorityMode;
    uint16 usSTagTPID;
    uint16 usCTagTPID;
    uint16 usRTagTPID;
    R_EthSwtCont_CpuExPathCfgType stCpuExPathCfg;
    R_EthSwtCont_CpuLrnPathCfgType stCpuLrnPathCfg;
    R_EthSwtCont_CpuMrrPathCfgType stCpuMrrPathCfg;
    R_EthSwtCont_EthMrrPathCfgType stEthMrrPathCfg;
    R_EthSwtCont_SDMrrPathCfgType stSDMrrPathCfg;
    R_EthSwtCont_SrcMrrPathCfgType stSrcMrrPathCfg;
    uint16 usUnsecIPVWMReject;
    uint16 usSecIPVWMReject;
    uint16 usWatermarkCriticalPriority[ETHSWTCONT_PORT_NUM];
    uint16 usWatermarkFlushPriority[ETHSWTCONT_PORT_NUM];
} R_EthSwtCont_MfwdCfgType;

typedef struct
{
    uint32 aaPortFlags[ETHSWTCONT_PORT_NUM];
    uint16 aaL3FwdMask[ETHSWTCONT_PORT_NUM];
    uint16 aaL2FwdMask[ETHSWTCONT_PORT_NUM];
    uint8 aaPFALEnable[ETHSWTCONT_PORT_NUM];
    uint8 aaPFALSecLvDisable[ETHSWTCONT_PORT_NUM];
    uint8 aaBLEnable[ETHSWTCONT_PORT_NUM];
    uint8 aaBLSecLvDisable[ETHSWTCONT_PORT_NUM];
    uint16 aaL3FwdMaskDisable[ETHSWTCONT_PORT_NUM];
    uint8 aaL23UpdateOverwriteEnable[ETHSWTCONT_PORT_NUM];
} R_EthSwtCont_MfwdPortCfgType;

/* L3 Table General Configuration */
typedef struct
{
    uint16 usEntryAddress;
    uint8 ucHwLearnDisable;
    uint8 ucEntryDel;
    uint8 ucBL;
    uint8 ucRoutPriority;
    uint8 ucFilterPriority;
    uint32 aaStreamMask[4];
    uint8 ucGateNo;
    uint8 ucGateValid;
    uint8 ucMsduNo;
    uint8 ucMsduValid;
    uint8 ucFrerNo;
    uint8 ucFrerValid;
    uint8 ucMeterNo;
    uint8 ucMeterValid;
    uint16 usRoutNo;
    uint8 ucRoutValid;
    uint16 usSrcLockVec;
    uint8 aaCpuSubDest[ETHSWTCONT_PORT_GWCA_NUM];
    uint16 usDestVec;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucEthMrrEnable;
    uint8 ucCpuMrrEnable;
    uint16 usDestLockVec;
} R_EthSwtCont_L3TblCfgType;

/* Perfect Filter Configuration */
typedef struct
{
    uint8 ucCfgFlag;
    uint8 ucOffset;
    uint8 ucFilterMode;
    uint8 ucUnitMode;
    uint16 aaFilterVal[ETHSWTCONT_BYTEFILTER_NUM];
} R_EthSwtCont_2BFCfgType;

typedef struct
{
    uint8 ucCfgFlag;
    uint8 ucOffset;
    uint8 ucUnitMode;
    uint32 aaFilterVal[ETHSWTCONT_BYTEFILTER_NUM];
} R_EthSwtCont_3BFCfgType;

typedef struct
{
    uint8 ucCfgFlag;
    uint8 ucOffset;
    uint8 ucUnitMode;
    uint32 aaFilterVal[ETHSWTCONT_BYTEFILTER_NUM];
} R_EthSwtCont_4BFCfgType;

typedef struct
{
    uint8 ucCfgFlag;
    uint8 ucOffset;
    uint8 ucOffsetMode;
    uint8 ucExtensionMode;
    uint16 aaStartVal[ETHSWTCONT_BYTEFILTER_NUM];
    uint16 aaEndVal[ETHSWTCONT_BYTEFILTER_NUM];
} R_EthSwtCont_RFCfgType;

typedef struct
{
    uint8 ucCfgFlag;
    uint16 usPFrameValid;
    uint16 usEFrameValid;
    uint8 ucMatchMode;
    uint8 aaCFValid[ETHSWTCONT_PFL_CFMF_NUM];
    uint16 aaCFFilterNumber[ETHSWTCONT_PFL_CFMF_NUM];
    R_EthSwtCont_L3TblCfgType stL3TblCfg;
} R_EthSwtCont_CFCfgType;

typedef struct
{
    uint32 ulTwoBFEntryNum;
    const R_EthSwtCont_2BFCfgType *pTwoBF;
    uint32 ulThreeBFEntryNum;
    const R_EthSwtCont_3BFCfgType *pThreeBF;
    uint32 ulFourBFEntryNum;
    const R_EthSwtCont_4BFCfgType *pFourBF;
    uint32 ulRFEntryNum;
    const R_EthSwtCont_RFCfgType *pRF;
    uint32 ulCFEntryNum;
    const R_EthSwtCont_CFCfgType *pCF;
} R_EthSwtCont_PFCfgType;


/* L2 Forwarding Rule Configuration */
typedef struct
{
    uint32 aaMacAddr[ETHSWTCONT_MACADDR_WORD_SIZE];
    uint16 usEntryAddress;
    uint8 ucCfgFlag;
    uint8 ucDynamicEntry;
    uint8 ucHwLearnDisable;
    uint8 ucEntryDel;
    uint8 ucDestMacBL;
    uint8 ucSrcMacBL;
    uint8 ucRoutPriority;
    uint8 ucFilterPriority;
    uint8 ucGateNo;
    uint8 ucGateValid;
    uint8 ucMsduNo;
    uint8 ucMsduValid;
    uint8 ucFrerNo;
    uint8 ucFrerValid;
    uint8 ucMeterNo;
    uint8 ucMeterValid;
    uint16 usDestSrcLockVec;
    uint16 usSrcSrcLockVec;
    uint8 aaCpuSubDest[ETHSWTCONT_PORT_GWCA_NUM];
    uint16 usDestVec;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucEthMrrEnable;
    uint8 ucCpuMrrEnable;
} R_EthSwtCont_MacTblCfgType;

typedef struct
{
    uint16 usVlanId;
    uint8 ucCfgFlag;
    uint8 ucSecLv;
    uint8 ucHwLearnDisable;
    uint8 ucEntryDel;
    uint8 ucBL;
    uint8 ucRoutPriority;
    uint8 ucFilterPriority;
    uint8 ucGateNo;
    uint8 ucGateValid;
    uint8 ucMsduNo;
    uint8 ucMsduValid;
    uint8 ucFrerNo;
    uint8 ucFrerValid;
    uint8 ucMeterNo;
    uint8 ucMeterValid;
    uint16 usRoutNo;
    uint8 ucRoutValid;
    uint16 usSrcLockVec;
    uint16 usFwdMaskVec;
    uint8 aaCpuSubDest[ETHSWTCONT_PORT_GWCA_NUM];
    uint16 usDestVec;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucEthMrrEnable;
    uint8 ucCpuMrrEnable;
} R_EthSwtCont_VlanTblCfgType;

typedef struct
{
    uint32 aaDestMacAddr[ETHSWTCONT_MACADDR_WORD_SIZE];
    uint32 aaSrcMacAddr[ETHSWTCONT_MACADDR_WORD_SIZE];
    uint32 aaSrcIpAddr[ETHSWTCONT_IPADDR_WORD_SIZE];
    uint32 aaDestIpAddr[ETHSWTCONT_IPADDR_WORD_SIZE];
    uint16 usSrcPort;
    uint16 usDestPort;
    uint8  ucSTagDei;
    uint8  ucSTagPcp;
    uint16 usSTagVlanId;
    uint8  ucCTagDei;
    uint8  ucCTagPcp;
    uint16 usCTagVlanId;
    uint8  ucProtocol;
    uint8  ucFrameFormatVec;
    R_EthSwtCont_L3TblCfgType stL3TblCfg;
} R_EthSwtCont_StreamFCfgType;

typedef struct
{
    uint16 usRoutNo;
    uint16 usFieldUpdateFlags;
    uint16 usRoutPortValid;
    uint32 aaDestMacAddr[ETHSWTCONT_MACADDR_WORD_SIZE];
    uint8  ucSTagDei;
    uint8  ucSTagPcp;
    uint16 usSTagVlanId;
    uint8  ucCTagDei;
    uint8  ucCTagPcp;
    uint16 usCTagVlanId;
} R_EthSwtCont_L2L3UpTblCfgType;

typedef struct
{
    uint8 ucRemapEnable;
    uint16 usRemapRuleNo;
    uint16 usRemapNewRuleNo;
    uint8 ucRemapSrcPort;
} R_EthSwtCont_L2L3UpRemapCfgType;

typedef struct
{
    uint8 ucIpPart0Flag;
    uint8 ucIpPart1Flag;
    uint8 ucDestPortFlag;
    uint8 ucSTagDeiFlag;
    uint8 ucSTagPcpFlag;
    uint8 ucSTagVlanIdFlag;
    uint8 ucCTagDeiFlag;
    uint8 ucCTagPcpFlag;
    uint8 ucCTagVlanIdFlag;
} R_EthSwtCont_StreamFlagType;

typedef struct
{
    uint8 ucDestMacFlag;
    uint8 ucSrcMacFlag;
    uint8 ucSrcIpFlag;
    uint8 ucDestIpFlag;
    uint8 ucSrcPortFlag;
    uint8 ucDestPortFlag;
    uint8 ucSTagDeiFlag;
    uint8 ucSTagPcpFlag;
    uint8 ucSTagVlanIdFlag;
    uint8 ucCTagDeiFlag;
    uint8 ucCTagPcpFlag;
    uint8 ucCTagVlanIdFlag;
    uint8 ucProtocolFlag;
} R_EthSwtCont_HashFlagType;

typedef struct CDD_EthSwtCont
{
    uint8 ucDestMacFlag;
    uint8 ucSrcMacFlag;
    uint8 ucSTagDeiFlag;
    uint8 ucSTagPcpFlag;
    uint8 ucSTagVlanIdFlag;
    uint8 ucCTagDeiFlag;
    uint8 ucCTagPcpFlag;
    uint8 ucCTagVlanIdFlag;
} R_EthSwtCont_L2StreamFlagType;

typedef struct
{
    R_EthSwtCont_StreamFlagType stIpv4InStreamFlags;
    R_EthSwtCont_HashFlagType stIpv4InHashFlags;
    R_EthSwtCont_StreamFlagType stIpv6InStreamFlags;
    R_EthSwtCont_HashFlagType stIpv6InHashFlags;
    R_EthSwtCont_IPOffsetType aaIpv6OffsetMode[ETHSWTCONT_IPV6PART_NUM];
    uint8 aaIpv6Offset[ETHSWTCONT_IPV6PART_NUM];
    R_EthSwtCont_L2StreamFlagType stL2InStreamFlags;
    uint16 usIpv4HashEquat;
    uint16 usIpv6HashEquat;
} R_EthSwtCont_StreamGenCfgType;

typedef struct
{
    uint32 ulStreamFilterEntryNum;
    const R_EthSwtCont_StreamFCfgType *pStreamFilter;
    const R_EthSwtCont_StreamGenCfgType *pStreamGenCfg;
} R_EthSwtCont_StreamCfgType;

typedef struct
{
    R_EthSwtCont_PFCfgType stPFCfg;
    R_EthSwtCont_StreamCfgType stStreamCfg;
    uint16 usPFAcceptListArea;
    uint8 ucPFAcceptListAreaAll;
    uint16 usStreamUnsecEntry;
} R_EthSwtCont_L3CfgType;

typedef struct
{
    uint32 ulMacTblEntryNum;
    const R_EthSwtCont_MacTblCfgType *pMacTable;
    uint32 ulVlanTblEntryNum;
    const R_EthSwtCont_VlanTblCfgType *pVlanTable;
    uint16 usMacUnsecEntry;
    uint16 usVlanMaxUnsecEntry;
    uint16 usHwLearnStartAddr;
    uint16 usHwLearnEndAddr;
    uint8 ucHwLearnFilter0;
    uint8 ucHwLearnFilter1;
    uint8 ucHwLearnFilter2;
    uint8 ucHwLearnFilter3;
    uint16 aaPerPortDynamicEntryLimitNum[ETHSWTCONT_PORT_NUM];
} R_EthSwtCont_L2CfgType;

typedef struct
{
    uint32 ulL2L3UpTblEntryNum;
    const R_EthSwtCont_L2L3UpTblCfgType *pL2L3UpTblCfg;
    uint32 ulL2L3UpRemapEntryNum;
    const R_EthSwtCont_L2L3UpRemapCfgType *pL2L3UpRemapCfg;
} R_EthSwtCont_L2L3UpCfgType;

typedef struct
{
    uint8 ucIPv4PriorityDecodeEnable;
    uint8 ucIPv4PriorityDecodeMode;
    uint8 ucIPv6PriorityDecodeEnable;
    uint8 ucAllInputPriorityEnable;
    uint8 ucSecLv;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucEthMrrEnable;
    uint8 ucCpuMrrEnable;
    uint8 ucRoutPriority;
    uint8 ucHwLearnDisable;
} R_EthSwtCont_PortBasedCfgType;

typedef struct
{
    R_EthSwtCont_L3CfgType stL3Cfg;
    R_EthSwtCont_L2CfgType stL2Cfg;
    R_EthSwtCont_L2L3UpCfgType stL2L3UpCfg;
    const R_EthSwtCont_PortBasedCfgType *pPortBasedCfg;
} R_EthSwtCont_RoutCfgType;

typedef struct
{
    uint8 ucFilterMode;
    uint16 usValue;
} R_EthSwtCont_MsduCfgType;

typedef struct
{
    uint8 ucGateState;
    uint8 ucIPV;
    uint32 ulTime;
} R_EthSwtCont_GateFCfgType;

typedef struct
{
    uint8 ucInitGateState;
    uint8 ucInitIpv;
    uint16 usJitter;
    uint8 ucIpvUpdateEnable;
    uint8 ucFilterMode;
    uint8 ucEntryNum;
    uint32 ulCycleStartTime0;
    uint32 ulCycleStartTime1;
    uint32 ulCycleTime;
} R_EthSwtCont_GateGenCfgType;

typedef struct
{
    uint32 ulGateFilterEntryNum;
    const R_EthSwtCont_GateFCfgType *pGateFilter;
    const R_EthSwtCont_GateGenCfgType *pGateGenCfg;
} R_EthSwtCont_GateCfgType;

typedef struct
{
    uint16 usColorMode;
    uint8 ucCouplingFlag;
    uint8 ucRedFrameDrop;
    uint8 ucFilterMode;
    uint8 ucFilterEnable;
    uint32 ulCbs;
    uint32 ulCir;
    uint32 ulEbs;
    uint32 ulEir;
} R_EthSwtCont_MeterCfgType;

typedef struct
{
    uint8 ucMeterNo[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucMeterValid[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucMsduNo[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucMsduValid[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucGateNo[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucGateValid[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucSecLv[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint8 ucFilterPriority[ETHSWTCONT_FRAME_PRIORITY_NUM];
} R_EthSwtCont_FilterPrioType;

typedef struct
{
    uint32 ulMsduFilterNum;
    const R_EthSwtCont_MsduCfgType *pMsduCfg;
    uint32 ulGateFilterNum;
    const R_EthSwtCont_GateCfgType *pGateCfg;
    uint32 ulMeterFilterNum;
    const R_EthSwtCont_MeterCfgType *pMeterCfg;
    const R_EthSwtCont_FilterPrioType *pFilterPrioCfg;
} R_EthSwtCont_PsfpCfgType;

typedef struct
{
    uint16 aaIpvSecure[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint16 aaIpvUnsecure[ETHSWTCONT_FRAME_PRIORITY_NUM];
    uint16 usCriticalLevel;
    uint16 usFlushLevel;
    uint16 aaPerPortCriticalLevel[ETHSWTCONT_PORT_NUM];
    uint16 aaPerPortFlushLevel[ETHSWTCONT_PORT_NUM];
    uint16 aaMinPointerNum[ETHSWTCONT_PORT_NUM];
    uint16 aaMaxPointerNum[ETHSWTCONT_PORT_NUM];
} R_EthSwtCont_WatermarkCfgType;

typedef struct
{
    uint8 ucDestMacAddrEnable;
    uint8 ucSrcMacAddrEnable;
    uint8 ucSTagDeiEnable;
    uint8 ucSTagPcpEnable;
    uint8 ucSTagVlanIdEnable;
    uint8 ucCTagDeiEnable;
    uint8 ucCTagPcpEnable;
    uint8 ucCTagVlanIdEnable;
    uint8 ucEtherTypeEnable;
    uint8 ucFCSIn;
    uint8 ucVlanCtrl;
    uint8 ucRTagIn;
    uint32 ulMaxTime;
    uint16 usDestVec;
    uint16 usDestFwdMode;
    uint8 ucIpvVal;
    uint8 ucIpvUpdate;
    uint8 ucEthMrrEnable;
    uint8 ucCpuMrrEnable;
    uint8 aaCpuSubDest[ETHSWTCONT_PORT_GWCA_NUM];
    uint32 aaDestMacAddr[ETHSWTCONT_MACADDR_WORD_SIZE];
    uint32 aaSrcMacAddr[ETHSWTCONT_MACADDR_WORD_SIZE];
    uint8 ucSTagDei;
    uint8 ucSTagPcp;
    uint16 usSTagVlanId;
    uint8 ucCTagDei;
    uint8 ucCTagPcp;
    uint16 usCTagVlanId;
    uint16 usEtherType;
    uint8 ucSrcPortNo;
} R_EthSwtCont_CTCfgType;

typedef struct
{
    uint32 ulIpv4FilterAddr;
    uint8 ucIpv4FilterAddrPrefix;
    uint8 ucIpv4SpecifiedFilterCfg;
    uint32 ulIpv6FilterAddr[ETHSWTCONT_IPADDR_WORD_SIZE];
    uint8 ucIpv6FilterAddrPrefix;
    uint8 ucIpv6SpecifiedFilterCfg;
} R_EthSwtCont_ICIpSpFilterType;

typedef struct
{
    uint32 ulEtherTypeCfg;
    uint8 ucIntgCheckDisableMode;
    uint8 ucDirectFilterEnable;
    uint16 usDirectFilterVal[ETHSWTCONT_INTG_ETYPE_N];
    uint32 ulIpv4Cfg;
    uint32 ulIpv4Addr;
    uint8 ucIpv4Prefix;
    uint16 usIpv4TotalLenMin;
    uint16 usIpv4TotalLenMax;
    uint32 ulIpv6Cfg;
    uint32 ulIpv6Addr[ETHSWTCONT_IPADDR_WORD_SIZE];
    uint8 ucIpv6Prefix;
    uint16 usIpv6PayloadLenMin;
    uint16 usIpv6PayloadLenMax;
    uint16 usL4FilterEnable;
    uint8 ucTCPHeaderLen;
    uint16 usICMPPayloadLen;
    uint8 ucTCPHeaderLenMin;
    uint8 ucTCPHeaderLenMax;
    R_EthSwtCont_ICIpSpFilterType stICIpSpFilter;
} R_EthSwtCont_ICCfgType;

typedef struct
{
    uint8 ucGetEnable;
    uint8 ucNotifyEnable;
    uint32 ulNotifyThreshold;
} R_EthSwtCont_StatElemCfgType;

typedef struct
{
    uint32 aaMFWDPortStat[ETHSWTCONT_MFWDPORTSTAT_NUM][ETHSWTCONT_PORT_NUM];
    uint32 aaMFWDPortStatOverflow[ETHSWTCONT_MFWDPORTSTAT_NUM][ETHSWTCONT_PORT_NUM];
    uint32 aaMsduStat[ETHSWTCONT_PSFP_MSDU_NUM];
    uint32 aaMsduStatOverflow[ETHSWTCONT_PSFP_MSDU_NUM];
    uint32 aaGateStat[ETHSWTCONT_PSFP_GATE_NUM];
    uint32 aaGateStatOverflow[ETHSWTCONT_PSFP_GATE_NUM];
    uint32 aaMeterGreenStat[ETHSWTCONT_PSFP_MTR_NUM];
    uint32 aaMeterGreenStatOverflow[ETHSWTCONT_PSFP_MTR_NUM];
    uint32 aaMeterYellowStat[ETHSWTCONT_PSFP_DMTR_N];
    uint32 aaMeterYellowStatOverflow[ETHSWTCONT_PSFP_DMTR_N];
    uint32 aaMeterRedStat[ETHSWTCONT_PSFP_MTR_NUM];
    uint32 aaMeterRedStatOverflow[ETHSWTCONT_PSFP_MTR_NUM];
    uint32 aaRMACPortStat[ETHSWTCONT_RMACPORTSTAT_NUM][ETHSWTCONT_PORT_TSNA_NUM];
    uint32 aaRMACPortStatOverflow[ETHSWTCONT_RMACPORTSTAT_NUM][ETHSWTCONT_PORT_TSNA_NUM];
} R_EthSwtCont_StatType;

typedef void (*R_EthSwtCont_StatFuncPtrType)(R_EthSwtCont_StatType *pStat);
typedef void (*R_EthSwtCont_NotifyFuncPtrType)(const R_EthSwtCont_StatIdType enStatIdx,
    const uint32 ulEntryIdx,
    const uint32 ulStatValue,
    const uint32 ulOverflowValue);

typedef struct
{
    uint8 aaPortEnable[ETHSWTCONT_PORT_NUM];
    uint32 ulRefreshInterval;
    const R_EthSwtCont_StatElemCfgType *pStatElemCfg;
} R_EthSwtCont_StatCfgType;

typedef struct
{
    uint8 ucSecMode;
    uint8 ucSecTAGTPID;
    uint8 ucSecCpuExPath;
    uint8 ucSecCpuLrnPath;
    uint8 ucSecCpuMrrPath;
    uint8 ucSecEthMrrPath;
    uint8 ucSecSDMrrPath;
    uint8 ucSecWaterMark;
    uint8 ucSecErrorInt;
    uint8 ucSecMonitorInt;
    uint8 ucSecCounter;
} R_EthSwtCont_MFWDSecCfgType;

typedef struct
{
    uint32 ulSecL2L3FwdMask;
    uint32 ulSecDirectDesc;
    uint32 ulSecAcceptList;
    uint32 ulSecBlockList;
    uint32 ulSecL2L3Up;
    uint32 ulSecPortandIPVFilter;
    uint32 ulSecIPv4;
    uint32 ulSecIPv6;
} R_EthSwtCont_MFWDSecPortCfgType;

typedef struct
{
    uint32 ulL2Stream;
    uint8 ucIPv4StreamCfg;
    uint8 ucIPv6StreamCfg;
    uint8 ucL2StreamCfg;
    uint8 ucSecL3TblMonitor;
    uint32 ulSecL3Tbl;
} R_EthSwtCont_MFWDSecL2L3StreamCfgType;

typedef struct
{
    uint32 ulSecPortBased;
    uint32 ulSecIC;
} R_EthSwtCont_MFWDSecICCfgType;

typedef struct
{
    uint32 ulSecL2L3Up[ETHSWTCONT_L23URSL_NUM];
    uint32 ulSecL2L3UpRemap;
    uint32 ulSecL2L3UpMonitor;
} R_EthSwtCont_MFWDSecL2L3UpCfgType;

typedef struct
{
    uint32 ulL2HWLearnPerPort;
    uint8 ucL2HWLearn;
    uint32 ulSecL2Tbl;
    uint8 ucSecL2Monitor;
    uint8 ucSecL2Aging;
} R_EthSwtCont_MFWDSecL2TblCfgType;

typedef struct
{
    uint32 ulSec2BF[ETHSWTCONT_FWSCRTO_NUM];
    uint32 ulSec3BF[ETHSWTCONT_FWSCRTH_NUM];
    uint32 ulSec4BF[ETHSWTCONT_FWSCRFO_NUM];
    uint32 ulSecRF[ETHSWTCONT_FWSCRRA_NUM];
    uint32 ulSecCF[ETHSWTCONT_FWSCRCA_NUM];
} R_EthSwtCont_MFWDSecPFCfgType;

typedef struct
{
    uint32 ulSecPSFPMSDU;
    uint32 ulSecPSFPGate;
    uint8 ucSecPSFPGateRAM;
    uint32 ulSecMeter[ETHSWTCONT_PMTRRSL_NUM];
    uint32 ulSecFRER[ETHSWTCONT_FRERRSL_NUM];
    uint8 ucSecFRERMonitor;
    uint8 ucSecFRERTimeout;
    uint32 ulSecSEQGen;
} R_EthSwtCont_MFWDSecPSFPCfgType;

typedef struct
{
    const R_EthSwtCont_MFWDSecCfgType stFWSecCfg;
    const R_EthSwtCont_MFWDSecPortCfgType stFWSecPortCfg;
    const R_EthSwtCont_MFWDSecL2L3StreamCfgType stFWSecL2L3StreamCfg;
    const R_EthSwtCont_MFWDSecL2TblCfgType stFWSecL2TblCfg;
    const R_EthSwtCont_MFWDSecICCfgType stFWSecICCfg;
    const R_EthSwtCont_MFWDSecL2L3UpCfgType stFWSecL2L3UpCfg;
    const R_EthSwtCont_MFWDSecPFCfgType stFWSecPFCfg;
    const R_EthSwtCont_MFWDSecPSFPCfgType stFWSecPSFP;
    uint8 ucCOMASecEnable;
} R_EthSwtCont_MFWDSecGeneralCfgType;

typedef struct
{
    const R_EthSwtCont_MfwdCfgType *pMfwdCfg;
    const R_EthSwtCont_MfwdPortCfgType *pMfwdPortCfg;
    const R_EthSwtCont_RoutCfgType *pRoutCfg;
    const R_EthSwtCont_PsfpCfgType *pPsfpConfig;
    const R_EthSwtCont_WatermarkCfgType *pWatermarkCfg;
    uint32 ulCTEntryNum;
    const R_EthSwtCont_CTCfgType *pCTCfg;
    const R_EthSwtCont_ICCfgType *pICCfg;
    uint32 ulIntegrityCheck;
} R_EthSwtCont_CfgType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#include "CDD_EthSwtCont_Cfg.h"
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define ETHSWTCONT_START_SEC_PUBLIC_CODE
#include "EthSwtCont_MemMap.h"

extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_Init(const R_EthSwtCont_CfgType *pConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_UpdateRoutTbl(const R_EthSwtCont_CfgType *pConfig);
extern FUNC(void, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_MainFunction(void);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_SetStatCfg(const R_EthSwtCont_StatCfgType *pStatConfig,
    R_EthSwtCont_StatFuncPtrType pStatCbFunc, R_EthSwtCont_NotifyFuncPtrType pStatNotifyCbFunc);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_GetStatCfg(R_EthSwtCont_StatCfgType *pStatConfig);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_StatStart(void);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_StatEnd(void);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_ClearStatAll(void);
extern FUNC(Std_ReturnType, ETHSWTCONT_PUBLIC_CODE) R_EthSwtCont_SetSecureReg(const R_EthSwtCont_MFWDSecGeneralCfgType *pSecConfig);

#define ETHSWTCONT_STOP_SEC_PUBLIC_CODE
#include "EthSwtCont_MemMap.h"

#endif /* CDD_ETHSWTCONT_H */
