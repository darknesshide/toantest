/***********************************************************************************************************************
* Copyright [2025, 2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 2.0.0
* Description  : This file contains the process used in the Protocol Conversion function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_H
#define CDD_PROTOCONV_H

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Include standard Autosar Type */
#include "Std_Types.h"
/* PROTOCONV Pre-compile configuration Header File */
#include "CDD_ProtoConv_Cfg.h"

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#define PROTOCONV_VENDOR_ID           PROTOCONV_VENDOR_ID_VALUE
#define PROTOCONV_MODULE_ID           PROTOCONV_MODULE_ID_VALUE
#define PROTOCONV_INSTANCE_ID         PROTOCONV_INSTANCE_ID_VALUE

/* AUTOSAR Release Version Information */
#define PROTOCONV_AR_RELEASE_MAJOR_VERSION                               4U
#define PROTOCONV_AR_RELEASE_MINOR_VERSION                               8U
#define PROTOCONV_AR_RELEASE_REVISION_VERSION                            0U

/* File version information */
#define PROTOCONV_SW_MAJOR_VERSION                                       2U
#define PROTOCONV_SW_MINOR_VERSION                                       0U
#define PROTOCONV_SW_PATCH_VERSION                                       0U

/* AUTOSAR release version information */
#define PROTOCONV_PBTYPES_AR_RELEASE_MAJOR_VERSION    PROTOCONV_AR_RELEASE_MAJOR_VERSION
#define PROTOCONV_PBTYPES_AR_RELEASE_MINOR_VERSION    PROTOCONV_AR_RELEASE_MINOR_VERSION
#define PROTOCONV_PBTYPES_AR_RELEASE_REVISION_VERSION PROTOCONV_AR_RELEASE_REVISION_VERSION

/* File version information */
#define PROTOCONV_PBTYPES_SW_MAJOR_VERSION            PROTOCONV_SW_MAJOR_VERSION
#define PROTOCONV_PBTYPES_SW_MINOR_VERSION            PROTOCONV_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
/* Ethernet type */
#define PROTOCONV_FRAMETYPE_AVTP       0x22F0U
#define PROTOCONV_FRAMETYPE_IPV4       0x0800U
#define PROTOCONV_FRAMETYPE_IPV6       0x86DDU
#define PROTOCONV_FRAMETYPE_8021Q      0x8100U

/* Integrity check code */
#define PROTOCONV_CHECK_CODE           0x12345678UL
/* Address length in word */
#define PROTOCONV_MACADDR_LEN_IN_WORD    2U
#define PROTOCONV_IPADDR_LEN_IN_WORD     4U
#define PROTOCONV_STREAMID_LEN_IN_WORD   2U
/* Address length in byte */
#define PROTOCONV_IPV4ADDR_LEN_IN_BYTE   4U
#define PROTOCONV_IPV6ADDR_LEN_IN_BYTE   16U

#define PROTOCONV_CLR             0U
#define PROTOCONV_SET             1U
#define PROTOCONV_INVALID         0U
#define PROTOCONV_VALID           1U
#define PROTOCONV_FLAG_IPV4       0U
#define PROTOCONV_FLAG_IPV6       1U
#define PROTOCONV_FLAG_NTSCF      0U
#define PROTOCONV_FLAG_TSCF       1U
#define PROTOCONV_AVTP_NONE       2U

/* Max number of Mix Rx Buffers */
#define PROTOCONV_MIXBUF_MAX      MIX_RX_BUF_NUM

/***********************************************************************************************************************
**                                                    Service IDs                                                     **
***********************************************************************************************************************/
/* Service ID for R_ProtoConv_Init */
#define R_PROTOCONV_INIT_SID                       (uint8)0x00U
/* Service ID for R_ProtoConv_CantoEthTS */
#define R_PROTOCONV_CANTOETHTS_SID                 (uint8)0x01U
/* Service ID for R_ProtoConv_CantoEth */
#define R_PROTOCONV_CANTOETH_SID                   (uint8)0x02U
/* Service ID for R_ProtoConv_LintoEth */
#define R_PROTOCONV_LINTOETH_SID                   (uint8)0x03U
/* Service ID for R_ProtoConv_PorttoEth */
#define R_PROTOCONV_PORTTOETH_SID                  (uint8)0x04U
/* Service ID for R_ProtoConv_TriggerXtoEthTx */
#define R_PROTOCONV_TRIGGERXTOETHTX_SID            (uint8)0x05U
/* Service ID for R_ProtoConv_MainFunction */
#define R_PROTOCONV_MAINFUNCTION_SID               (uint8)0x06U
/* Service ID for R_ProtoConv_EthtoX */
#define R_PROTOCONV_ETHTOX_SID                     (uint8)0x07U
/* Service ID for R_ProtoConv_GetSendStatus */
#define R_PROTOCONV_GETSENDSTATUS_SID              (uint8)0x08U
/* Service ID for R_ProtoConv_UpdateSendStatus */
#define R_PROTOCONV_UPDATESENDSTATUS_SID           (uint8)0x09U
/* Service ID for R_ProtoConv_EnqueueCan */
#define R_PROTOCONV_ENQUEUECAN_SID                 (uint8)0x0AU
/* Service ID for R_ProtoConv_EnqueueLin */
#define R_PROTOCONV_ENQUEUELIN_SID                 (uint8)0x0BU
/* Service ID for R_ProtoConv_EnqueuePort */
#define R_PROTOCONV_ENQUEUEPORT_SID                (uint8)0x0CU
/* Service ID for R_ProtoConv_EnqueueEth */
#define R_PROTOCONV_ENQUEUEETH_SID                 (uint8)0x0DU
/* Service ID for R_ProtoConv_DequeueEth */
#define  R_PROTOCONV_DEQUEUEETH_SID                (uint8)0x0EU
/* Service ID for R_ProtoConv_TriggerQueueDataXtoEth */
#define  R_PROTOCONV_TRIGGERQUEUEDATAXTOETH_SID    (uint8)0x0FU

/***********************************************************************************************************************
**                                                  DET Error Codes                                                   **
***********************************************************************************************************************/
/* DET code to report parameter error (argument is NULL Pointer) */
#define PROTOCONV_E_PARAM_POINTER                   (uint8)0x02U
/* DET code to report process error (API executed in uninitialized state) */
#define PROTOCONV_E_UNINIT                          (uint8)0x03U
/* DET code to report wrong parameter passed to the APIs */
#define PROTOCONV_E_INV_PARAM                       (uint8)0x04U
/* DET code to report invalid call */
#define PROTOCONV_E_ALREADY_INITIALIZED             (uint8)0x05U
/* DET code to report discrepancy error (Miss match with SW routing table value) */
#define PROTOCONV_E_MATCH                           (uint8)0x06U
/* DET code to report transmission error */
#define PROTOCONV_E_TRANS                           (uint8)0x07U
/* DET code to report API service called with wrong Data length */
#define PROTOCONV_E_PARAM_DATA_LENGTH               (uint8)0x08U
/* DET code to report Packed CAN Frame Error */
#define PROTOCONV_E_PACKEDCAN                       (uint8)0x09U
/* DET code to report Packed LIN Frame Error */
#define PROTOCONV_E_PACKEDLIN                       (uint8)0x0AU
/* DET code to report Packed Parallel PORT Message Error */
#define PROTOCONV_E_PACKEDPORT                      (uint8)0x0BU
/* DET code to report Packed CAN/LIN/Parallel Port Message Error */
#define PROTOCONV_E_PACKEDMSG                       (uint8)0x0CU
/* DET code to report IP Header Checksum Error */
#define PROTOCONV_E_IPCKSUM                         (uint8)0x0DU
/* DET code to report UDP Header Checksum Error */
#define PROTOCONV_E_UDPCKSUM                        (uint8)0x0EU
/* DET code to report Invalid CAN/LIN/Port DLC */
#define PROTOCONV_E_NOTFRAME                        (uint8)0x0FU
/* DET code to report BSW Notification Error */
#define PROTOCONV_E_BSWNOTIFY                       (uint8)0x10U
/* DET code to report Filtered and discarded error */
#define PROTOCONV_E_FILTER                          (uint8)0x11U
/* DET code to report Config Error (NULL Pointer) */
#define PROTOCONV_E_PARAM_CONFIG                    (uint8)0x12U
/* DET code to report unexpectedly full FIFO error*/
#define PROTOCONV_E_FIFO_FULL                       (uint8)0x13U
/* DET code to report unexpectedly empty FIFO error*/
#define PROTOCONV_E_FIFO_EMPTY                      (uint8)0x14U
/* DET code to report incorrect or non-supported ACF type */
#define PROTOCONV_E_CFG_ACFTYPE                     (uint8)0x15U

/***********************************************************************************************************************
**                                                   Typedef definitions                                              **
***********************************************************************************************************************/
typedef enum ETag_R_ProtoConv_ConvModeType
{
    PROTOCONV_BASICMODE,
    PROTOCONV_BUFFERMODE
} R_ProtoConv_ConvModeType;

typedef enum ETag_R_ProtoConv_FrameType
{
    PROTOCONV_NORMAL_FRAME,
    PROTOCONV_EMERGENCY_FRAME
} R_ProtoConv_FrameType;

typedef enum ETag_R_ProtoConv_EthFormatType
{
    PROTOCONV_IEEE1722_ACF,
    PROTOCONV_IPDUM_FORMAT
} R_ProtoConv_EthFormatType;

typedef enum ETag_R_ProtoConv_PduEthtoXType
{
    PROTOCONV_PDUETHTOCAN,
    PROTOCONV_PDUETHTOLIN
} R_ProtoConv_PduEthtoXType;

typedef struct
{
    uint32 ulCanId;
    uint32 ulCanDlc;
    uint8 *pCanData;
} R_ProtoConv_CanFrameType;

typedef struct
{
    uint32 ulNanosecond;
    uint32 ulSecond;
} R_ProtoConv_TimeStampType;

typedef struct
{
    uint8 ucPId;
    uint8 ucDlc;
    uint8 *pData;
} R_ProtoConv_LinFrameType;

/* MAC Address Type */
typedef struct
{
    uint32 aaMacAddr[PROTOCONV_MACADDR_LEN_IN_WORD];
} R_ProtoConv_MacAddressType;

/* IPV4 Address Type */
typedef struct
{
    uint32 aaIpAddr[PROTOCONV_IPADDR_LEN_IN_WORD];
} R_ProtoConv_IpAddressType;

/* IP/UDP/AVTP Header Configuration */
typedef struct
{
    uint8  ucIpSetFlag;
    uint8  ucIpType;
    uint8  ucAvtpFormat;
    uint32 aaDestIpAddr[PROTOCONV_IPADDR_LEN_IN_WORD];
    uint16 usDestUdpPort;
    uint16 usVlanId;
    uint8  ucStreamIdValid;
    uint32 aaStreamId[PROTOCONV_STREAMID_LEN_IN_WORD];
    R_ProtoConv_EthFormatType enFormatType;
} R_ProtoConv_HeaderType;

typedef struct
{
    uint32 aaDestMacAddr[PROTOCONV_MACADDR_LEN_IN_WORD];
    R_ProtoConv_HeaderType stHeader;
} R_ProtoConv_XtoEthDestTblType;

/* CAN to Ethernet Sub Routing Table entry */
typedef struct
{
    uint32 ulDestIdx;
    R_ProtoConv_FrameType enTypeFlags;
    uint32 ulPduId;
} R_ProtoConv_CantoEthSubTblType;

/* CAN to Ethernet Main Routing Table entry */
typedef struct
{
    uint32 ulCanId;
    uint32 ulCantoEthSubTblEntryNum;
    const  R_ProtoConv_CantoEthSubTblType *pCantoEthSubTbl;
} R_ProtoConv_CantoEthMainTblType;

typedef struct
{
    uint32 ulCantoEthMainTblEntryNum;
    const R_ProtoConv_CantoEthMainTblType *pCantoEthMainTbl;
} R_ProtoConv_CantoEthMainTblGeneralType;

/* LIN to Ethernet Sub Routing Table entry */
typedef struct
{
    uint32 ulDestIdx;
    R_ProtoConv_FrameType enTypeFlags;
    uint32 ulPduId;
} R_ProtoConv_LintoEthSubTblType;

/* LIN to Ethernet Main Routing Table entry */
typedef struct
{
    uint8  ucPId;
    uint32 ulLintoEthSubTblEntryNum;
    const  R_ProtoConv_LintoEthSubTblType *pLintoEthSubTbl;
} R_ProtoConv_LintoEthMainTblType;

typedef struct
{
    uint32 ulLintoEthMainTblEntryNum;
    const  R_ProtoConv_LintoEthMainTblType *pLintoEthMainTbl;
} R_ProtoConv_LintoEthMainTblGeneralType;

/* Source Address/Port Configuration */
typedef struct
{
    uint32 aaSrcMacAddr[PROTOCONV_MACADDR_LEN_IN_WORD];
    uint32 ulSrcIpv4Addr;
    uint32 aaSrcIpv6Addr[PROTOCONV_IPADDR_LEN_IN_WORD];
    uint16 usSrcUdpPort;
} R_ProtoConv_EthSrcCfgType;

typedef struct
{
    uint8  ucDestBusIdx;
    uint32 ulAddInfo;
} R_ProtoConv_EthtoXSubTblType;

typedef struct
{
    uint32 ulNewId; /* For PDU ETH to X */
    R_ProtoConv_PduEthtoXType enPduConvMsn;
    uint8  ucDestBusIdx;
    uint32 ulAddInfo;
} R_ProtoConv_PduEthtoXSubTblType;

/* Ethernet to CAN Routing Table entry */
typedef struct
{
    uint32 ulCanId;
    uint32 ulEthtoCanSubTblEntryNum;
    const R_ProtoConv_EthtoXSubTblType *pEthtoCanSubTbl;
} R_ProtoConv_EthtoCanMainTblType;

/* Ethernet to LIN Routing Table entry */
typedef struct
{
    uint8  ucPId;
    uint32 ulEthtoLinSubTblEntryNum;
    const R_ProtoConv_EthtoXSubTblType *pEthtoLinSubTbl;
} R_ProtoConv_EthtoLinMainTblType;

/* Ethernet(IPDU-M) to CAN/LIN Routing Table entry */
typedef struct
{
    uint32 ulPduId;
    uint32 ulPduEthtoXSubTblEntryNum;
    const R_ProtoConv_PduEthtoXSubTblType *pPduEthtoXSubTbl;
} R_ProtoConv_PduEthtoXMainTblType;

/* X to Ethernet Converting Configuration */
typedef struct
{
    R_ProtoConv_ConvModeType enConvMode;
    uint32 ulFrameLimit;
    uint32 ulMixTimeLimit;
} R_ProtoConv_ConvCfgType;

/* Buffer Address and Size Configuration */
typedef struct
{
    /* Can Tx/Rx Buffer info */
    uint8 *pCanTxAddr;
    uint32 ulCanTxBufSize;
    uint8 *pCanRxAddr;
    uint32 ulCanRxBufSize;
    /* Lin Tx/Rx Buffer info */
    uint8 *pLinTxAddr;
    uint32 ulLinTxBufSize;
    uint8 *pLinRxAddr;
    uint32 ulLinRxBufSize;
    /* Port Tx/Rx Buffer info */
    uint8 *pPortTxAddr;
    uint32 ulPortTxBufSize;
    uint8 *pPortRxAddr;
    uint32 ulPortRxBufSize;
    /* Eth Tx/Rx Buffer info */
    uint8 *pEthTxAddr;
    uint32 ulEthTxBufSize;
    uint8 *pEthRxAddr;
    uint32 ulEthRxBufSize;
    /* Mixed Rx Buffer info */
    uint32 ulMixRxBufNum;
    uint8 *pMixRxAddr[PROTOCONV_MIXBUF_MAX];
    uint32 ulMixRxBufSize[PROTOCONV_MIXBUF_MAX];
} R_ProtoConv_BufCfgType;

/* StreamID filter Configuration */
typedef struct
{
    uint32 aaStreamId[PROTOCONV_STREAMID_LEN_IN_WORD];
} R_ProtoConv_StreamIdType;

/* Filter Configuration */
typedef struct
{
    uint16                           usSrcMacFilterNum;
    const R_ProtoConv_MacAddressType *aaSrcMacAddr;
    uint16                           usSrcIpFilterNum;
    const R_ProtoConv_IpAddressType  *aaSrcIpAddr;
    uint16                           usVlanIdFilterNum;
    const uint16                     *aaVlanId;
    uint16                           usStreamIdFilterNum;
    const R_ProtoConv_StreamIdType   *aaStreamId;
} R_ProtoConv_FilterCfgType;

/* Initialization Configuration */
typedef struct
{
    const R_ProtoConv_CantoEthMainTblGeneralType *pCantoEthMainTblGeneral;
    const R_ProtoConv_LintoEthMainTblGeneralType *pLintoEthMainTblGeneral;
    const R_ProtoConv_XtoEthDestTblType    *pXtoEthDestTbl;
    const R_ProtoConv_EthSrcCfgType        *pEthSrcCfg;
    const R_ProtoConv_EthtoCanMainTblType  *pEthtoCanMainTbl;
    const R_ProtoConv_EthtoLinMainTblType  *pEthtoLinMainTbl;
    uint32                                 ulIntegrityCheck;
    const R_ProtoConv_ConvCfgType          *pConvCfg;
    const R_ProtoConv_BufCfgType           *pBufCfg;
    const R_ProtoConv_FilterCfgType        *pFilterCfg;
    const R_ProtoConv_PduEthtoXMainTblType *pPduEthtoXMainTbl;
} R_ProtoConv_CfgType;

/***********************************************************************************************************************
**                             Exported global functions (to be accessed by other files)                              **
***********************************************************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
/* APIs of ProtoConv*/
extern Std_ReturnType R_ProtoConv_Init(const R_ProtoConv_CfgType *pConfig);

extern Std_ReturnType R_ProtoConv_CantoEthTS(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
    const R_ProtoConv_TimeStampType *pTimeStamp);

extern Std_ReturnType R_ProtoConv_CantoEth(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame);

extern Std_ReturnType R_ProtoConv_LintoEth(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame);

extern Std_ReturnType R_ProtoConv_PorttoEth(const uint16 usLength, const uint8 *pPortData,
    const uint32 ulDestIdx, const R_ProtoConv_FrameType enTypeFlags);

extern Std_ReturnType R_ProtoConv_TriggerXtoEthTx(const uint32 ulBufIdx);

extern Std_ReturnType R_ProtoConv_EthtoX(const uint16 usFrameType, const uint8* aaSrcMacAddr,
   const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus);

extern void R_ProtoConv_MainFunction(void);

extern Std_ReturnType R_ProtoConv_GetSendStatus(uint32 *pStatus);

extern Std_ReturnType R_ProtoConv_UpdateSendStatus(const uint32 ulStatus);

extern Std_ReturnType R_ProtoConv_EnqueueCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
    const R_ProtoConv_TimeStampType *pTimeStamp);

extern Std_ReturnType R_ProtoConv_EnqueueLin(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame);

extern Std_ReturnType R_ProtoConv_EnqueuePort(const uint16 usLength, const uint8 *pPortData, const uint32 ulDestIdx);

extern Std_ReturnType R_ProtoConv_TriggerQueueDataXtoEth(void);

extern Std_ReturnType R_ProtoConv_EnqueueEth(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
    const uint8 *pEthFrame, const uint32 ulFrameLen);

extern Std_ReturnType R_ProtoConv_DequeueEth(uint16 *pFrameType, uint8 **aaSrcMacAddr,
    uint8 **pEthFrame, uint32 *pFrameLen);
    
#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/***********************************************************************************************************************
**                                        Extern declarations for Global Data                                         **
***********************************************************************************************************************/

#define PROTOCONV_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "ProtoConv_MemMap.h"
/* Global array for Config structure */
extern CONST (R_ProtoConv_CfgType, PROTOCONV_CONFIG_DATA) ProtoConv_GstCfg[];
#define PROTOCONV_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_H */
