/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the FIFO management function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_Fifo.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
uint32 GulCanFifoCount[PROTOCONV_CAN_CH_NUM];
uint32 GulLinFifoCount[PROTOCONV_LIN_CH_NUM];
uint32 GulPortFifoCount;
uint32 GulEthFifoCount;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
R_ProtoConv_CanFifoType GstCanFifo[PROTOCONV_CAN_CH_NUM];
R_ProtoConv_LinFifoType GstLinFifo[PROTOCONV_LIN_CH_NUM];
R_ProtoConv_PortFifoType GstPortFifo;
R_ProtoConv_EthFifoType GstEthFifo;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

static Std_ReturnType DequeueCan(const uint8 ucBusIdx, R_ProtoConv_CanFrameType *pCanFrame,
    R_ProtoConv_TimeStampType *pTimeStamp);

static Std_ReturnType DequeueLin(const uint8 ucBusIdx, R_ProtoConv_LinFrameType *pLinFrame);

static Std_ReturnType DequeuePort(uint16 *pLength, uint8 **pPortData, uint32 *pDestIdx);

static Std_ReturnType TriggerQueueCantoEth(void);

static Std_ReturnType TriggerQueueLintoEth(void);

static Std_ReturnType TriggerQueuePorttoEth(void);

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_042]:[Gen5GW_ProtoConv_UD_12_042]
* Function name: ProtoConv_FifoInit
* Description  : Initialize CAN/LIN/Port/Ethernet FIFO information
* Arguments    : N/A
* Return Value : N/A
***************************************************************************************/
void ProtoConv_FifoInit(void)
{
    uint32 LulCount;

    /* Initialize CAN FIFO information */
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_CAN_CH_NUM; LulCount++)
    {
        GulCanFifoCount[LulCount]   = NUM0;
        GstCanFifo[LulCount].ulHead = NUM0;
        GstCanFifo[LulCount].ulTail = NUM0;
        GstCanFifo[LulCount].ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
    }

    /* Initialize LIN FIFO information */
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_LIN_CH_NUM; LulCount++)
    {
        GulLinFifoCount[LulCount]   = NUM0;
        GstLinFifo[LulCount].ulHead = NUM0;
        GstLinFifo[LulCount].ulTail = NUM0;
        GstLinFifo[LulCount].ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
    }

    /* Initialize Port FIFO information */
    GulPortFifoCount   = NUM0;
    GstPortFifo.ulHead = NUM0;
    GstPortFifo.ulTail = NUM0;
    GstPortFifo.ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;

    /* Initialize ETH FIFO information */
    GulEthFifoCount   = NUM0;
    GstEthFifo.ulHead = NUM0;
    GstEthFifo.ulTail = NUM0;
    GstEthFifo.ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_008]:[Gen5GW_ProtoConv_UD_12_008]
* Function name: ProtoConv_EnqueueCan
* Description  : Enqueue CAN frame into FIFO
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
*                *pTimeStamp - Time Stamp
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
Std_ReturnType ProtoConv_EnqueueCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
   const R_ProtoConv_TimeStampType *pTimeStamp)
{
    Std_ReturnType LucRetVal;
    uint32 ulCount;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_FULL == GstCanFifo[ucBusIdx].ulFlag)
    {
        /* Queue Full */
        LucRetVal = E_NOT_OK;
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUECAN_SID,
                              PROTOCONV_E_FIFO_FULL);
        #endif
    }
    else
    {
        /* Enqueue */
        GstCanFifo[ucBusIdx].stCanFrame[GstCanFifo[ucBusIdx].ulTail].ulCanId = pCanFrame->ulCanId;
        GstCanFifo[ucBusIdx].stCanFrame[GstCanFifo[ucBusIdx].ulTail].ulCanDlc = pCanFrame->ulCanDlc;
        GstCanFifo[ucBusIdx].stTimeStamp[GstCanFifo[ucBusIdx].ulTail].ulSecond = pTimeStamp->ulSecond;
        GstCanFifo[ucBusIdx].stTimeStamp[GstCanFifo[ucBusIdx].ulTail].ulNanosecond = pTimeStamp->ulNanosecond;

        for (ulCount = IDX_0; ulCount < pCanFrame->ulCanDlc; ulCount++)
        {
            GstCanFifo[ucBusIdx].aaCanData[GstCanFifo[ucBusIdx].ulTail][ulCount] = pCanFrame->pCanData[ulCount];
        }
        GstCanFifo[ucBusIdx].stCanFrame[GstCanFifo[ucBusIdx].ulTail].pCanData = 
            &GstCanFifo[ucBusIdx].aaCanData[GstCanFifo[ucBusIdx].ulTail][IDX_0];

        /* Ring buffer */
        if ((PROTOCONV_CAN_FIFO_DEPTH - NUM1) == GstCanFifo[ucBusIdx].ulTail)
        {
            GstCanFifo[ucBusIdx].ulTail = NUM0;
        }
        else
        {
            GstCanFifo[ucBusIdx].ulTail++;
        }
        /* Update flags */
        if (GstCanFifo[ucBusIdx].ulTail == GstCanFifo[ucBusIdx].ulHead)
        {
            GstCanFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_FULL;
        }
        else
        {
            GstCanFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulCanFifoCount[ucBusIdx]++;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_014]:[Gen5GW_ProtoConv_UD_12_014]
* Function name: DequeueCan
* Description  : Dequeue CAN frame from FIFO
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
*                *pTimeStamp - Time Stamp
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType DequeueCan(const uint8 ucBusIdx, R_ProtoConv_CanFrameType *pCanFrame,
   R_ProtoConv_TimeStampType *pTimeStamp)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_EMPTY == GstCanFifo[ucBusIdx].ulFlag)
    {
        /* Empty */
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /* Dequeue */
        *pCanFrame = GstCanFifo[ucBusIdx].stCanFrame[GstCanFifo[ucBusIdx].ulHead];
        *pTimeStamp = GstCanFifo[ucBusIdx].stTimeStamp[GstCanFifo[ucBusIdx].ulHead];

        /* Ring buffer */
        if ((PROTOCONV_CAN_FIFO_DEPTH - NUM1) == GstCanFifo[ucBusIdx].ulHead)
        {
            GstCanFifo[ucBusIdx].ulHead = NUM0;
        }
        else
        {
            GstCanFifo[ucBusIdx].ulHead++;
        }
        /* Update flags */
        if (GstCanFifo[ucBusIdx].ulTail == GstCanFifo[ucBusIdx].ulHead)
        {
            GstCanFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_EMPTY;
        }
        else
        {
            GstCanFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulCanFifoCount[ucBusIdx]--;
    }
    
    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_009]:[Gen5GW_ProtoConv_UD_12_009]
* Function name: ProtoConv_EnqueueLin
* Description  : Enqueue LIN frame into FIFO
* Arguments    : ucBusIdx    - Bus Index
*                *pLinFrame  - LIN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
Std_ReturnType ProtoConv_EnqueueLin(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame)
{
    Std_ReturnType LucRetVal;
    uint32 ulCount;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_FULL == GstLinFifo[ucBusIdx].ulFlag)
    {
        /* Queue Full */
        LucRetVal = E_NOT_OK;
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUELIN_SID,
                              PROTOCONV_E_FIFO_FULL);
        #endif
    }
    else
    {
        /* Enqueue */
        GstLinFifo[ucBusIdx].stLinFrame[GstLinFifo[ucBusIdx].ulTail].ucPId = pLinFrame->ucPId;
        GstLinFifo[ucBusIdx].stLinFrame[GstLinFifo[ucBusIdx].ulTail].ucDlc = pLinFrame->ucDlc;
        for (ulCount = IDX_0; ulCount < pLinFrame->ucDlc; ulCount++)
        {
            GstLinFifo[ucBusIdx].aaLinData[GstLinFifo[ucBusIdx].ulTail][ulCount] = pLinFrame->pData[ulCount];
        }
        GstLinFifo[ucBusIdx].stLinFrame[GstLinFifo[ucBusIdx].ulTail].pData = 
            &GstLinFifo[ucBusIdx].aaLinData[GstLinFifo[ucBusIdx].ulTail][IDX_0];

        /* Ring buffer */
        if ((PROTOCONV_LIN_FIFO_DEPTH - NUM1) == GstLinFifo[ucBusIdx].ulTail)
        {
            GstLinFifo[ucBusIdx].ulTail = NUM0;
        }
        else
        {
            GstLinFifo[ucBusIdx].ulTail++;
        }
        /* Update flags */
        if (GstLinFifo[ucBusIdx].ulTail == GstLinFifo[ucBusIdx].ulHead)
        {
            GstLinFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_FULL;
        }
        else
        {
            GstLinFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulLinFifoCount[ucBusIdx]++;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_015]:[Gen5GW_ProtoConv_UD_12_015]
* Function name: DequeueLin
* Description  : Dequeue LIN frame from FIFO
* Arguments    : ucBusIdx    - Bus Index
*                *pLinFrame  - LIN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType DequeueLin(const uint8 ucBusIdx, R_ProtoConv_LinFrameType *pLinFrame)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_EMPTY == GstLinFifo[ucBusIdx].ulFlag)
    {
        /* Empty */
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /* Dequeue */
        *pLinFrame = GstLinFifo[ucBusIdx].stLinFrame[GstLinFifo[ucBusIdx].ulHead];

        /* Ring buffer */
        if ((PROTOCONV_LIN_FIFO_DEPTH - NUM1) == GstLinFifo[ucBusIdx].ulHead)
        {
            GstLinFifo[ucBusIdx].ulHead = NUM0;
        }
        else
        {
            GstLinFifo[ucBusIdx].ulHead++;
        }
        /* Update flags */
        if (GstLinFifo[ucBusIdx].ulTail == GstLinFifo[ucBusIdx].ulHead)
        {
            GstLinFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_EMPTY;
        }
        else
        {
            GstLinFifo[ucBusIdx].ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulLinFifoCount[ucBusIdx]--;
    }
    
    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_010]:[Gen5GW_ProtoConv_UD_12_010]
* Function name: ProtoConv_EnqueuePort
* Description  : Enqueue Port frame into FIFO
* Arguments    : usLength    - Port Data length
*                *pPortData  - Port Data
*                ulDestIdx   - Destination Index
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
Std_ReturnType ProtoConv_EnqueuePort(const uint16 usLength, const uint8 *pPortData, const uint32 ulDestIdx)
{
    Std_ReturnType LucRetVal;
    uint32 ulCount;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_FULL == GstPortFifo.ulFlag)
    {
        /* Queue Full */
        LucRetVal = E_NOT_OK;
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEPORT_SID,
                              PROTOCONV_E_FIFO_FULL);
        #endif
    }
    else
    {
        /* Enqueue */
        GstPortFifo.usLength = usLength;

        for (ulCount = IDX_0; ulCount < usLength; ulCount++)
        {
            GstPortFifo.aaPortData[ulCount] = pPortData[ulCount];
        }
        GstPortFifo.ulDestIdx = ulDestIdx;

        /* Ring buffer */
        if ((PROTOCONV_PORT_FIFO_DEPTH - NUM1) == GstPortFifo.ulTail)
        {
            GstPortFifo.ulTail = NUM0;
        }
        else
        {
            GstPortFifo.ulTail++;
        }
        /* Update flags */
        if (GstPortFifo.ulTail == GstPortFifo.ulHead)
        {
            GstPortFifo.ulFlag = (uint32)PROTOCONV_FIFO_FULL;
        }
        else
        {
            GstPortFifo.ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulPortFifoCount++;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_016]:[Gen5GW_ProtoConv_UD_12_016]
* Function name: DequeuePort
* Description  : Dequeue CAN frame from FIFO
* Arguments    : *pLength    - Port Data length
*                **pPortData - Port Data
*                *pDestIdx   - Destination Index
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType DequeuePort(uint16 *pLength, uint8 **pPortData, uint32 *pDestIdx)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_EMPTY == GstPortFifo.ulFlag)
    {
        /* Empty */
        LucRetVal = E_NOT_OK;
    }
    else
    {
        /* Dequeue */
        *pLength = GstPortFifo.usLength;
        *pPortData = &GstPortFifo.aaPortData[IDX_0];
        *pDestIdx = GstPortFifo.ulDestIdx;

        /* Ring buffer */
        if ((PROTOCONV_PORT_FIFO_DEPTH - NUM1) == GstPortFifo.ulHead)
        {
            GstPortFifo.ulHead = NUM0;
        }
        else
        {
            GstPortFifo.ulHead++;
        }
        /* Update flags */
        if (GstPortFifo.ulTail == GstPortFifo.ulHead)
        {
            GstPortFifo.ulFlag = (uint32)PROTOCONV_FIFO_EMPTY;
        }
        else
        {
            GstPortFifo.ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulPortFifoCount--;
    }
    
    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_043]:[Gen5GW_ProtoConv_UD_12_043]
* Function Name: TriggerQueueCantoEth
* Description  : Convert the queued CAN frame and send Ethernet frame
* Arguments    : -
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType TriggerQueueCantoEth(void)
{
    R_ProtoConv_CanFrameType  LstCanFrame;
    R_ProtoConv_TimeStampType LstTimeStamp;
    uint32 LulTargetCanFrameNum;
    uint32 LulFrameCount;
    uint8  LucCh;
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    for (LucCh = IDX_0; LucCh < PROTOCONV_CAN_CH_NUM; LucCh++)
    {
        LulTargetCanFrameNum = GulCanFifoCount[LucCh];
        for (LulFrameCount = IDX_0; LulFrameCount < LulTargetCanFrameNum; LulFrameCount++)
        {
            LucRetVal = DequeueCan(LucCh, &LstCanFrame, &LstTimeStamp);
            if (E_OK == LucRetVal)
            {
                if ((NUM0 == LstTimeStamp.ulNanosecond) && (NUM0 == LstTimeStamp.ulSecond))
                {
                    LucRetVal = R_ProtoConv_CantoEth(LucCh, &LstCanFrame);
                }
                else
                {
                    LucRetVal = R_ProtoConv_CantoEthTS(LucCh, &LstCanFrame, &LstTimeStamp);
                }
            }
            else
            {
                /* Fail dequeue. Process next frame */
                LucRetVal = E_OK;
            }

            if (E_OK == LucRetVal)
            {
                /* Process next frame */
            }
            else
            {
                break;
            }
        }

        if (E_OK == LucRetVal)
        {
            /* Process next Channel */
        }
        else
        {
            break;
        }
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_044]:[Gen5GW_ProtoConv_UD_12_044]
* Function Name: TriggerQueueLintoEth
* Description  : Convert the queued LIN frame and send Ethernet frame
* Arguments    : -
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType TriggerQueueLintoEth(void)
{
    R_ProtoConv_LinFrameType LstLinFrame;
    uint32 LulTargetLinFrameNum;
    uint32 LulFrameCount;
    uint8  LucCh;
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    for (LucCh = IDX_0; LucCh < PROTOCONV_LIN_CH_NUM; LucCh++)
    {
        LulTargetLinFrameNum = GulLinFifoCount[LucCh];
        for (LulFrameCount = IDX_0; LulFrameCount < LulTargetLinFrameNum; LulFrameCount++)
        {
            LucRetVal = DequeueLin(LucCh, &LstLinFrame);
            if (E_OK == LucRetVal)
            {
                LucRetVal = R_ProtoConv_LintoEth(LucCh, &LstLinFrame);
            }
            else
            {
                /* Fail dequeue. Process next frame */
                LucRetVal = E_OK;
            }

            if (E_OK == LucRetVal)
            {
                /* Process next frame */
            }
            else
            {
                break;
            }
        }

        if (E_OK == LucRetVal)
        {
            /* Process next Channel */
        }
        else
        {
            break;
        }
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_045]:[Gen5GW_ProtoConv_UD_12_045]
* Function Name: TriggerQueuePorttoEth
* Description  : Convert the queued Port frame and send Ethernet frame
* Arguments    : -
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType TriggerQueuePorttoEth(void)
{
    uint8 *LpPortData;
    uint32 LulTargetPortFrameNum;
    uint32 LulFrameCount;
    uint32 LulDestIdx;
    uint16 LusLength;
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;
    LulTargetPortFrameNum = GulPortFifoCount;

    for (LulFrameCount = IDX_0; LulFrameCount < LulTargetPortFrameNum; LulFrameCount++)
    {
        LucRetVal = DequeuePort(&LusLength, &LpPortData, &LulDestIdx);
        if (E_OK == LucRetVal)
        {
            LucRetVal = R_ProtoConv_PorttoEth(LusLength, &LpPortData[IDX_0], LulDestIdx, PROTOCONV_NORMAL_FRAME);
        }
        else
        {
            /* Fail dequeue. Process next frame */
            LucRetVal = E_OK;
        }

        if (E_OK == LucRetVal)
        {
            /* Process next frame */
        }
        else
        {
            break;
        }
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_005]:[Gen5GW_ProtoConv_UD_13_005]
* Function name: ProtoConv_EnqueueEth
* Description  : Enqueue Ethernet frame into FIFO
* Arguments    : usFrameType -
*                    Ethernet frame type
*                *aaSrcMacAddr -
*                    Ethernet source MacAddress
*                *pEthFrame -
*                    Ethernet frame
*                ulFrameLen -
*                    Ethernet frame length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
Std_ReturnType ProtoConv_EnqueueEth(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
    const uint8 *pEthFrame, const uint32 ulFrameLen)
{
    Std_ReturnType LucRetVal;
    uint32 ulCount;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_FULL == GstEthFifo.ulFlag)
    {
        /* Queue Full */
        LucRetVal = E_NOT_OK;
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEETH_SID,
                              PROTOCONV_E_FIFO_FULL);
        #endif
    }
    else
    {
        /* Enqueue */
        GstEthFifo.stEthFrame[GstEthFifo.ulTail].usFrameType = usFrameType;
        GstEthFifo.stEthFrame[GstEthFifo.ulTail].ulFrameLen = ulFrameLen;

        for (ulCount = IDX_0; ulCount < MACADDR_LEN_IN_BYTE; ulCount++)
        {
            GstEthFifo.stEthFrame[GstEthFifo.ulTail].aaSrcMacAddr[ulCount] = aaSrcMacAddr[ulCount];
        }
        for (ulCount = IDX_0; ulCount < ulFrameLen; ulCount++)
        {
            GstEthFifo.aaEthData[GstEthFifo.ulTail][ulCount] = pEthFrame[ulCount];
        }
        GstEthFifo.stEthFrame[GstEthFifo.ulTail].pEthFrame = 
            &GstEthFifo.aaEthData[GstEthFifo.ulTail][IDX_0];


        /* Ring buffer */
        if ((PROTOCONV_ETH_FIFO_DEPTH - NUM1) == GstEthFifo.ulTail)
        {
            GstEthFifo.ulTail = NUM0;
        }
        else
        {
            GstEthFifo.ulTail++;
        }
        /* Update flags */
        if (GstEthFifo.ulTail == GstEthFifo.ulHead)
        {
            GstEthFifo.ulFlag = (uint32)PROTOCONV_FIFO_FULL;
        }
        else
        {
            GstEthFifo.ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulEthFifoCount++;
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_006]:[Gen5GW_ProtoConv_UD_13_006]
* Function name: ProtoConv_DequeueEth
* Description  : Dequeue ETH frame from FIFO
* Arguments    : *pFrameType -
*                    Ethernet frame type
*                **aaSrcMacAddr -
*                    Ethernet source MacAddress
*                **pEthFrame -
*                    Ethernet frame
*                *pFrameLen -
*                    Ethernet frame length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
Std_ReturnType ProtoConv_DequeueEth(uint16 *pFrameType, uint8 **aaSrcMacAddr,
    uint8 **pEthFrame, uint32 *pFrameLen)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_FIFO_EMPTY == GstEthFifo.ulFlag)
    {
        /* Empty */
        LucRetVal = E_NOT_OK;
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_DEQUEUEETH_SID,
                              PROTOCONV_E_FIFO_EMPTY);
        #endif
    }
    else
    {
        /* Dequeue */
        *pFrameType = GstEthFifo.stEthFrame[GstEthFifo.ulHead].usFrameType;
        *pFrameLen = GstEthFifo.stEthFrame[GstEthFifo.ulHead].ulFrameLen;
        *aaSrcMacAddr = &GstEthFifo.stEthFrame[GstEthFifo.ulHead].aaSrcMacAddr[IDX_0];
        *pEthFrame = &GstEthFifo.aaEthData[GstEthFifo.ulHead][IDX_0];
        
        /* Ring buffer */
        if ((PROTOCONV_ETH_FIFO_DEPTH - NUM1) == GstEthFifo.ulHead)
        {
            GstEthFifo.ulHead = NUM0;
        }
        else
        {
            GstEthFifo.ulHead++;
        }
        /* Update flags */
        if (GstEthFifo.ulTail == GstEthFifo.ulHead)
        {
            GstEthFifo.ulFlag = (uint32)PROTOCONV_FIFO_EMPTY;
        }
        else
        {
            GstEthFifo.ulFlag = (uint32)PROTOCONV_FIFO_AVAILABLE;
        }
        GulEthFifoCount--;
    }
    
    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_011]:[Gen5GW_ProtoConv_UD_12_011]
* Function Name: ProtoConv_TriggerQueueDataXtoEth
* Description  : Convert the queued CAN/LIN/Port frame and send Ethernet frame
* Arguments    : -
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
Std_ReturnType ProtoConv_TriggerQueueDataXtoEth(void)
{
    Std_ReturnType LucRetVal;

    LucRetVal = TriggerQueueCantoEth();
    LucRetVal += TriggerQueueLintoEth();
    LucRetVal += TriggerQueuePorttoEth();

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
