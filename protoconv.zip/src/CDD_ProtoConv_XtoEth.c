/***********************************************************************************************************************
* Copyright [2025, 2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 2.0.0
* Description  : This file contains the process used in the CAN/LIN/Port to Ethernet Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_CantoEth.h"
#include "CDD_ProtoConv_LintoEth.h"
#include "CDD_ProtoConv_PorttoEth.h"
#include "CDD_ProtoConv_XtoEth.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_interface.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Header information */
#define SERVICE_TYPE_IPV4       0U
#define ID_IPV4                 0U
#define FRAGMENT_IPV4           0x4000U
#define TTL_IPV4                8U
#define HL_IPV6                 8U

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
const R_ProtoConv_XtoEthDestTblType *ProtoConv_GstXtoEthDestRoutTbl;
uint8 *ProtoConv_GaaEthTxBuf;
uint8 *ProtoConv_GaaCanRxBuf;
uint8 *ProtoConv_GaaLinRxBuf;
uint8 *ProtoConv_GaaPortRxBuf;
uint8 *ProtoConv_GaaMixRxBuf[PROTOCONV_MIXBUF_MAX];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
uint32 ProtoConv_GulXtoEthDestTblNum;
uint32 ProtoConv_GulEthTxBufIdx;
uint32 ProtoConv_GulCanRxBufSize;
uint32 ProtoConv_GulCanRxBufLen;
uint32 ProtoConv_GulLinRxBufSize;
uint32 ProtoConv_GulLinRxBufLen;
uint32 ProtoConv_GulPortRxBufSize;
uint32 ProtoConv_GulPortRxBufLen;
uint32 ProtoConv_GulMixRxBufNum;
uint32 ProtoConv_GulMixRxBufSize[PROTOCONV_MIXBUF_MAX];
uint32 ProtoConv_GulMixRxBufLen[PROTOCONV_MIXBUF_MAX];
uint32 ProtoConv_GulMixCount[PROTOCONV_MIXBUF_MAX];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
R_ProtoConv_ConvCfgType ProtoConv_GstConvCfg;
R_ProtoConv_CantoEthMainTblGeneralType ProtoConv_GstCantoEthMainTblGeneral[PROTOCONV_CAN_CH_NUM];
R_ProtoConv_LintoEthMainTblGeneralType ProtoConv_GstLintoEthMainTblGeneral[PROTOCONV_LIN_CH_NUM];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
/* Source Address/Port Configuration */
R_ProtoConv_EthSrcCfgType ProtoConv_GstEthSrcCfg;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
/* Sequence number Index */
static uint32 ProtoConv_GulSeqNumIndex[XTOETH_DEST_TABLE_ENTRY_NUM];
/* encapsulation_sequence_num field */
static uint32 ProtoConv_GulEncapSeqNum[XTOETH_DEST_TABLE_ENTRY_NUM];
/* Current Buffering Time and Ethernet Destination Information */
static uint32 ProtoConv_GulMixBufTime[PROTOCONV_MIXBUF_MAX];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_8
#include "ProtoConv_MemMap.h"
/* Sequence number for each destination */
static uint8  ProtoConv_GucSeqNum[XTOETH_DEST_TABLE_ENTRY_NUM];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_8
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
/* Private functions for Common usage in X to Ethernet Conversion */
static void StoreEthBufHeader(const uint32 ulEntryIdx, ProtoConv_BufInfoType *pBufInfo,
    const R_ProtoConv_HeaderType *pHeaderField, uint32 *pHeaderSize);

static void CreateVlanHeader(const R_ProtoConv_HeaderType *pHeaderField,
   uint32 *pSize, ProtoConv_BufInfoType *pBufInfo);

static void CreateIpv4Header(const R_ProtoConv_HeaderType *pHeaderField,
   const uint16 usUdpPktLen, ProtoConv_Ipv4HeaderType *pIpHeader);

static void CreateIpv6Header(const R_ProtoConv_HeaderType *pHeaderField,
   const uint16 usUdpPktLen, ProtoConv_Ipv6HeaderType *pIpHeader);

static void CalcIpv4UdpPseudoCheckSum(const ProtoConv_Ipv4HeaderType *pIpv4Header,
   const ProtoConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum);

static void CalcIpv6UdpPseudoCheckSum(const ProtoConv_Ipv6HeaderType *pIpv6Header,
   const ProtoConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum);

static void CreateNTSCFHeader(const uint32 ulEntryIdx, const uint32 ulDataLen,
   const R_ProtoConv_HeaderType *pHeaderField, ProtoConv_NTSCFType *pstNTSCFHeader);

static void CreateTSCFHeader(const uint32 ulEntryIdx, const uint32 ulDataLen,
   const R_ProtoConv_HeaderType *pHeaderField, ProtoConv_TSCFType *pstTSCFHeader);

static void GetEncapSequenceNumber(const uint32 ulEntryIdx, uint32 *pSeqNo);

static void CreateSeqNumIndex(void);

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_001]:[Gen5GW_ProtoConv_UD_12_001]
* Function Name: ProtoConv_XtoEthInit
* Description  : CAN/LIN/Port to Ethernet Function Initialization.
* Arguments    : *pConfig -
*                    Initialization Config
* Return Value : N/A
*******************************************************************************/
void ProtoConv_XtoEthInit(const R_ProtoConv_CfgType *pConfig)
{
    uint32 LulCount;
    uint32 LulChIdx;

    for (LulChIdx = IDX_0; LulChIdx < PROTOCONV_CAN_CH_NUM; LulChIdx++)
    {
        ProtoConv_GstCantoEthMainTblGeneral[LulChIdx] = pConfig->pCantoEthMainTblGeneral[LulChIdx];
    }

    for (LulChIdx = IDX_0; LulChIdx < PROTOCONV_LIN_CH_NUM; LulChIdx++)
    {
        ProtoConv_GstLintoEthMainTblGeneral[LulChIdx] = pConfig->pLintoEthMainTblGeneral[LulChIdx];
    }

    ProtoConv_GstXtoEthDestRoutTbl = pConfig->pXtoEthDestTbl;
    ProtoConv_GulXtoEthDestTblNum  = XTOETH_DEST_TABLE_ENTRY_NUM;

    /* Set pConfig value to each global variables */
    ProtoConv_GstConvCfg.enConvMode     = pConfig->pConvCfg->enConvMode;
    ProtoConv_GstConvCfg.ulFrameLimit   = pConfig->pConvCfg->ulFrameLimit;
    ProtoConv_GstConvCfg.ulMixTimeLimit = pConfig->pConvCfg->ulMixTimeLimit;
    ProtoConv_GaaLinRxBuf      = pConfig->pBufCfg->pLinRxAddr;
    ProtoConv_GulLinRxBufSize  = pConfig->pBufCfg->ulLinRxBufSize;
    ProtoConv_GaaPortRxBuf     = pConfig->pBufCfg->pPortRxAddr;
    ProtoConv_GulPortRxBufSize = pConfig->pBufCfg->ulPortRxBufSize;
    ProtoConv_GaaCanRxBuf      = pConfig->pBufCfg->pCanRxAddr;
    ProtoConv_GulCanRxBufSize  = pConfig->pBufCfg->ulCanRxBufSize;
    ProtoConv_GaaEthTxBuf      = pConfig->pBufCfg->pEthTxAddr;
    ProtoConv_GulMixRxBufNum   = pConfig->pBufCfg->ulMixRxBufNum;

    for (LulCount = (uint32)IDX_0; LulCount < (uint32)ProtoConv_GulMixRxBufNum; LulCount++)
    {
        ProtoConv_GaaMixRxBuf[LulCount]     = pConfig->pBufCfg->pMixRxAddr[LulCount];
        ProtoConv_GulMixRxBufSize[LulCount] = pConfig->pBufCfg->ulMixRxBufSize[LulCount];
        ProtoConv_GulMixRxBufLen[LulCount]  = NUM0;
        ProtoConv_GulMixCount[LulCount]     = NUM0;
        ProtoConv_GulMixBufTime[LulCount]   = NUM0;
    }

    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_MACADDR_LEN_IN_WORD; LulCount++)
    {
        ProtoConv_GstEthSrcCfg.aaSrcMacAddr[LulCount] = pConfig->pEthSrcCfg->aaSrcMacAddr[LulCount];
    }

    ProtoConv_GstEthSrcCfg.ulSrcIpv4Addr = pConfig->pEthSrcCfg->ulSrcIpv4Addr;

    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        ProtoConv_GstEthSrcCfg.aaSrcIpv6Addr[LulCount] = pConfig->pEthSrcCfg->aaSrcIpv6Addr[LulCount];
    }

    ProtoConv_GstEthSrcCfg.usSrcUdpPort = pConfig->pEthSrcCfg->usSrcUdpPort;

    /* Initialize buffer */
    ProtoConv_GulEthTxBufIdx  = NUM0;
    ProtoConv_GulCanRxBufLen  = NUM0;
    ProtoConv_GulLinRxBufLen  = NUM0;
    ProtoConv_GulPortRxBufLen = NUM0;

    /* Create Sequence Number array Index */
    CreateSeqNumIndex();

    /* Initialize Sequence Number */
    ProtoConv_UtilMemSet(&ProtoConv_GucSeqNum[IDX_0], (uint8)NUM0, sizeof(ProtoConv_GucSeqNum));
    ProtoConv_UtilMemSet(&ProtoConv_GulEncapSeqNum[IDX_0], (uint8)NUM0, sizeof(ProtoConv_GulEncapSeqNum));
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_006]:[Gen5GW_ProtoConv_UD_12_006]
* Function Name: ProtoConv_TriggerXtoEthTx
* Description  : Trigger X to Ethernet Transmit.
* Arguments    : ulBufIdx -
*                    Target Buffer index
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_TriggerXtoEthTx(const uint32 ulBufIdx)
{
    ProtoConv_BufInfoType LstBufInfo;
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if (ulBufIdx < ProtoConv_GulMixRxBufNum)
    {
        if ((uint32)NUM0 != ProtoConv_GulMixRxBufLen[ulBufIdx])
        {
            LstBufInfo.ulRxBufSize = ProtoConv_GulMixRxBufSize[ulBufIdx];
            LstBufInfo.ulRxBufLen = ProtoConv_GulMixRxBufLen[ulBufIdx];
            LstBufInfo.pRxBufPtr = ProtoConv_GaaMixRxBuf[ulBufIdx];
            LstBufInfo.pTxBufPtr = ProtoConv_GaaEthTxBuf;
            LstBufInfo.ulTxBufIdx = ProtoConv_GulEthTxBufIdx;

            LucRetVal = ProtoConv_CreateAndSendEthFrame(ulBufIdx, &LstBufInfo,
                                                        &ProtoConv_GstXtoEthDestRoutTbl[ulBufIdx].stHeader);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID,
                                      R_PROTOCONV_TRIGGERXTOETHTX_SID, PROTOCONV_E_TRANS);
                #endif
            }

            /* Reset Mixed Rx Buffer */
            ProtoConv_GulMixRxBufLen[ulBufIdx] = NUM0;
            ProtoConv_GulMixCount[ulBufIdx] = NUM0;
            /* Reset Ethernet Tx Buffer Index */
            ProtoConv_GulEthTxBufIdx = NUM0;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_TRIGGERXTOETHTX_SID,
                                  PROTOCONV_E_PARAM_CONFIG);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_TRIGGERXTOETHTX_SID,
                              PROTOCONV_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_012]:[Gen5GW_ProtoConv_UD_12_012]
* Function Name: ProtoConv_CreateAndSendEthFrame
* Description  : Create Ethernet Frame and Send.
* Arguments    : ulEntryIdx - 
*                    Route Table Index
*                *pBufInfo -
*                    Buffer Information
*                *pHeaderField -
*                    IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_CreateAndSendEthFrame(const uint32 ulEntryIdx,
   ProtoConv_BufInfoType *pBufInfo, const R_ProtoConv_HeaderType *pHeaderField)
{
    uint8 *LpBuffPtr;
    uint8 *LaaModuleRxBuf;
    uint8 *LaaModuleTxBuf;
    Std_ReturnType LucRetVal;
    uint32 LulHeaderSize;
    uint32 LulTotalFrameSize;
    uint32 LulPaddingByte;
    uint32 LulModuleBufLen;
    uint16 LusFrameType;
    uint8  LaaDestMacAddr[MACADDR_LEN_IN_BYTE];

    LulHeaderSize = NUM0;

    /* Set Header to Ethernet Tx Buffer */
    StoreEthBufHeader(ulEntryIdx, pBufInfo, pHeaderField, &LulHeaderSize);

    LulModuleBufLen = pBufInfo->ulRxBufLen;
    LaaModuleRxBuf  = pBufInfo->pRxBufPtr;
    LaaModuleTxBuf  = pBufInfo->pTxBufPtr;

    LulTotalFrameSize = LulModuleBufLen + LulHeaderSize + (uint32)HEADER_LEN_ETH + (uint32)FCS_LEN_ETH;

    if (LulTotalFrameSize < ETH_FRAME_SIZE_MIN)
    {
        /* Padding 0 into Rx Buffers to meet the minimum Ethernet frame size */
        LulPaddingByte = ETH_FRAME_SIZE_MIN - LulTotalFrameSize;
        LpBuffPtr = &LaaModuleRxBuf[LulModuleBufLen];
        ProtoConv_UtilMemSet(LpBuffPtr, (uint8)NUM0, LulPaddingByte);
        LulModuleBufLen += LulPaddingByte;
        LulTotalFrameSize = ETH_FRAME_SIZE_MIN;
    }
    else
    {
        /*  Do nothing */
    }

    /* Copy Ethernet data buffer to Ethernet Tx Buffer */
    ProtoConv_UtilMemCpy(&LaaModuleTxBuf[pBufInfo->ulTxBufIdx], &LaaModuleRxBuf[IDX_0], LulModuleBufLen);

    /* When passing to API, excludes Ethernet Header and FCS Length */
    LulTotalFrameSize = LulTotalFrameSize - (uint32)HEADER_LEN_ETH - (uint32)FCS_LEN_ETH;

    if ((uint32)NUM0 == (uint32)pHeaderField->usVlanId)
    {
        if ((uint32)PROTOCONV_CLR == (uint32)pHeaderField->ucIpSetFlag)
        {
            LusFrameType = PROTOCONV_FRAMETYPE_AVTP;
        }
        else
        {
            if ((uint32)PROTOCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
            {
                LusFrameType = PROTOCONV_FRAMETYPE_IPV4;
            }
            else
            {
                LusFrameType = PROTOCONV_FRAMETYPE_IPV6;
            }
        }
    }
    else
    {
        LusFrameType = PROTOCONV_FRAMETYPE_8021Q;
    }

    /* Convert from 32 bit 2 Entry to 8 bit 6 Entry */
    ProtoConv_UtilConvMacAddr8Bit(&ProtoConv_GstXtoEthDestRoutTbl[ulEntryIdx].aaDestMacAddr[IDX_0],
                                    &LaaDestMacAddr[IDX_0]);

    /* Ethernet Transmit */
    LucRetVal = (uint8)ProtoConv_EthTransmitUserDef(&LaaDestMacAddr[IDX_0], LusFrameType,
                                    &LaaModuleTxBuf[IDX_0], LulTotalFrameSize);

    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_013]:[Gen5GW_ProtoConv_UD_12_013]
* Function Name: ProtoConv_StorePdutoEthBufData
* Description  : Store PDU frame to Ethernet Data Buffer.
* Arguments    : ulPduId   - PDU ID
*                ulPduDlc  - PDU DLC
*                *pPduData - PDU Data
*                *pBufInfo - Buffer Information
* Return Value : N/A
*******************************************************************************/
void ProtoConv_StorePdutoEthBufData(const uint32 ulPduId, const uint32 ulPduDlc,
   const uint8 *pPduData, ProtoConv_BufInfoType *pBufInfo)
{
    uint8  *LpBuffPtr;
    uint32 LulDataSize;
    uint32 LulPduId;
    uint32 LulPduDlc;

    /* Save Local valuable for endian change. */
    LulPduId  = ulPduId;
    LulPduDlc = ulPduDlc;
    /* Set Target Buffer */
    LpBuffPtr = &pBufInfo->pRxBufPtr[pBufInfo->ulRxBufLen];

    /* IPDU-M format*/
    LulDataSize = pBufInfo->ulRxBufLen + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC + ulPduDlc;

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(&LulPduId);
    ProtoConv_UtilEndianConv32(&LulPduDlc);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    ProtoConv_UtilMemCpy(LpBuffPtr, &LulPduId, PDU_LEN_ID);
    LpBuffPtr = &LpBuffPtr[PDU_LEN_ID];
    ProtoConv_UtilMemCpy(LpBuffPtr, &LulPduDlc, PDU_LEN_DLC);
    LpBuffPtr = &LpBuffPtr[PDU_LEN_DLC];
    ProtoConv_UtilMemCpy(LpBuffPtr, pPduData, ulPduDlc);

    /* Update current position */
    pBufInfo->ulRxBufLen = LulDataSize;
    pBufInfo->ulRxBufCount++;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_007]:[Gen5GW_ProtoConv_UD_12_007]
* Function Name: ProtoConv_MixtoEthMain
* Description  : Mix to Ethernet Conversion Function
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
void ProtoConv_MixtoEthMain(void)
{
    ProtoConv_BufInfoType LstBufInfo;
    uint32 LulEntryIdx;

    if (PROTOCONV_BUFFERMODE == ProtoConv_GstConvCfg.enConvMode)
    {
        /* Loop for all Mix buffers */
        for (LulEntryIdx = IDX_0; LulEntryIdx < ProtoConv_GulMixRxBufNum; LulEntryIdx++)
        {
            /* Check Time Limit Over. */
            ProtoConv_GulMixBufTime[LulEntryIdx]++;
            if (ProtoConv_GulMixBufTime[LulEntryIdx] >= ProtoConv_GstConvCfg.ulMixTimeLimit)
            {
                ProtoConv_GulMixBufTime[LulEntryIdx] = NUM0;

                /* Check Receive Data Size. */
                if (((uint32)NUM0 != ProtoConv_GulMixRxBufLen[LulEntryIdx])
                && (NULL_PTR != ProtoConv_GaaMixRxBuf[LulEntryIdx])
                && (NULL_PTR != ProtoConv_GaaEthTxBuf))
                {
                    LstBufInfo.ulRxBufSize = ProtoConv_GulMixRxBufSize[LulEntryIdx];
                    LstBufInfo.ulRxBufLen = ProtoConv_GulMixRxBufLen[LulEntryIdx];
                    LstBufInfo.pRxBufPtr = ProtoConv_GaaMixRxBuf[LulEntryIdx];
                    LstBufInfo.pTxBufPtr = ProtoConv_GaaEthTxBuf;
                    LstBufInfo.ulTxBufIdx = ProtoConv_GulEthTxBufIdx;

                    (void)ProtoConv_CreateAndSendEthFrame(LulEntryIdx, &LstBufInfo,
                          &ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader);
                    /* Reset Mixed Rx Buffer */
                    ProtoConv_GulMixRxBufLen[LulEntryIdx] = NUM0;
                    ProtoConv_GulMixCount[LulEntryIdx] = NUM0;
                    /* Reset Ethernet Tx Buffer Index */
                    ProtoConv_GulEthTxBufIdx = NUM0;
                }
                else
                {
                    /* Do Nothing */
                }
            }
            else
            {
                /* Do Nothing */
            }
        }
    }
    else
    {
        /* Do Nothing */
    }
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_020]:[Gen5GW_ProtoConv_UD_12_020]
* Function Name: StoreEthBufHeader
* Description  : Store Ethernet Header to Tx Buffer.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pBufInfo -
*                    Buffer Information
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
static void StoreEthBufHeader(const uint32 ulEntryIdx, ProtoConv_BufInfoType *pBufInfo,
   const R_ProtoConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    uint8                    *LaaModuleRxBuf;
    uint8                    *LaaModuleTxBuf;
    ProtoConv_Ipv6HeaderType LstIpv6Header;
    ProtoConv_Ipv4HeaderType LstIpv4Header;
    ProtoConv_UdpHeaderType  LstUdpHeader;
    ProtoConv_NTSCFType      LstNTSCFHeader;
    ProtoConv_TSCFType       LstTSCFHeader;
    uint32                   LulTotalHeaderSize;
    uint32                   LulSeqNum;
    uint32                   LulChecksum;
    uint32                   LulModuleBufLen;
    uint32                   LulEthTxBufIdx;

    LulModuleBufLen = pBufInfo->ulRxBufLen;
    LaaModuleRxBuf  = pBufInfo->pRxBufPtr;
    LaaModuleTxBuf  = pBufInfo->pTxBufPtr;
    LulEthTxBufIdx  = NUM0;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    if ((uint32)PROTOCONV_SET == (uint32)pHeaderField->ucIpSetFlag)
    {
        if (PROTOCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            /* Create NTSCF Header */
            CreateNTSCFHeader(ulEntryIdx, LulModuleBufLen, pHeaderField, &LstNTSCFHeader);
            LulTotalHeaderSize += (uint32)HEADER_LEN_NTSCF;
            GetEncapSequenceNumber(ulEntryIdx, &LulSeqNum);
            /* Add encapsulation_sequence_num field size. */
            LulTotalHeaderSize += (uint32)HEADER_LEN_SEQNUM;
        }
        else if (PROTOCONV_FLAG_TSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            /* Create TSCF Header */
            CreateTSCFHeader(ulEntryIdx, LulModuleBufLen, pHeaderField, &LstTSCFHeader);
            LulTotalHeaderSize += (uint32)HEADER_LEN_TSCF;
            GetEncapSequenceNumber(ulEntryIdx, &LulSeqNum);
            /* Add encapsulation_sequence_num field size. */
            LulTotalHeaderSize += (uint32)HEADER_LEN_SEQNUM;
        }
        else
        {
            /* AVTP None */
            /* No need encapsulation sequence number when AVTP None */
        }

        /* Create UDP Header */
        LstUdpHeader.usSrcPort  = ProtoConv_GstEthSrcCfg.usSrcUdpPort;
        LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
        LstUdpHeader.usLen      = (uint16)(HEADER_LEN_UDP + LulTotalHeaderSize + LulModuleBufLen);
        LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

        if ((uint32)PROTOCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
        {
            /* Set IPv4/UDP Header (Big Endian) */
            CreateIpv4Header(pHeaderField, LstUdpHeader.usLen, &LstIpv4Header);
            /* Add IPv4 header field size. */
            LulTotalHeaderSize += sizeof(LstIpv4Header);
        }
        else
        {
            /* Set IPv6/UDP Header (Big Endian) */
            CreateIpv6Header(pHeaderField, LstUdpHeader.usLen, &LstIpv6Header);
            /* Add IPv6 header field size. */
            LulTotalHeaderSize += sizeof(LstIpv6Header);
        }

        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
        ProtoConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
        ProtoConv_UtilEndianConv16(&LstUdpHeader.usLen);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        /* Caluculate UDP Checksum */
        /* for Pseudo UDP */
        LulChecksum = NUM0;
        if ((uint32)PROTOCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
        {
            /* for Pseudo UDP */
            CalcIpv4UdpPseudoCheckSum(&LstIpv4Header, &LstUdpHeader, &LulChecksum);
        }
        else
        {
            /* for Pseudo UDP */
            CalcIpv6UdpPseudoCheckSum(&LstIpv6Header, &LstUdpHeader, &LulChecksum);
        }
        /* for UDP Header */
        ProtoConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(ProtoConv_UdpHeaderType), &LulChecksum);

        if (PROTOCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            ProtoConv_UtilCalcSum(&LulSeqNum, (uint16)sizeof(LulSeqNum), &LulChecksum);
            ProtoConv_UtilCalcSum(&LstNTSCFHeader, (uint16)sizeof(ProtoConv_NTSCFType), &LulChecksum);
        }
        else if (PROTOCONV_FLAG_TSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            ProtoConv_UtilCalcSum(&LulSeqNum, (uint16)sizeof(LulSeqNum), &LulChecksum);
            ProtoConv_UtilCalcSum(&LstTSCFHeader, (uint16)sizeof(ProtoConv_TSCFType), &LulChecksum);
        }
        else
        {
            /* AVTP None */
        }

        /* for Rx Buffer stored data */
        ProtoConv_UtilCalcSum(&LaaModuleRxBuf[IDX_0], (uint16)LulModuleBufLen, &LulChecksum);
        LstUdpHeader.usChecksum = (uint16)~LulChecksum;

        if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
        {
            LstUdpHeader.usChecksum = REPLACE_UDPSUM;
        }
        else
        {
            /* Do nothing */
        }

        /* Add UDP header field size. */
        LulTotalHeaderSize += sizeof(LstUdpHeader);
    }
    else
    {
        if (PROTOCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            /* Create NTSCF Header */
            CreateNTSCFHeader(ulEntryIdx, LulModuleBufLen, pHeaderField, &LstNTSCFHeader);
            LulTotalHeaderSize += (uint32)HEADER_LEN_NTSCF;
        }
        else
        {
            /* IP Flag None AND AVTP None is not support, so no need to consider */
            /* Create TSCF Header */
            CreateTSCFHeader(ulEntryIdx, LulModuleBufLen, pHeaderField, &LstTSCFHeader);
            LulTotalHeaderSize += (uint32)HEADER_LEN_TSCF;
        }
    }

    /************************************
           Copy Tx Buffer
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize, pBufInfo);
    /* Shift index for VLAN Header */
    LulEthTxBufIdx = pBufInfo->ulTxBufIdx;

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    if ((uint32)PROTOCONV_SET == (uint32)pHeaderField->ucIpSetFlag)
    {
        if ((uint32)PROTOCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
        {
            /* Copy IPv4 Header to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstIpv4Header, sizeof(LstIpv4Header));
            LulEthTxBufIdx += sizeof(LstIpv4Header);
        }
        else
        {
            /* Copy IPv6 Header to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstIpv6Header, sizeof(LstIpv6Header));
            LulEthTxBufIdx += sizeof(LstIpv6Header);
        }

        /* Copy UDP Header to Tx buffer*/
        ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
        LulEthTxBufIdx += sizeof(LstUdpHeader);

        if (PROTOCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            /* Set encapsulation_sequence_num field to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LulSeqNum, sizeof(LulSeqNum));
            LulEthTxBufIdx += sizeof(LulSeqNum);
            /* Copy NTSCF Header to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstNTSCFHeader, sizeof(LstNTSCFHeader));
            LulEthTxBufIdx += sizeof(LstNTSCFHeader);
        }
        else if (PROTOCONV_FLAG_TSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            /* Set encapsulation_sequence_num field to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LulSeqNum, sizeof(LulSeqNum));
            LulEthTxBufIdx += sizeof(LulSeqNum);
            /* Copy TSCF Header to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstTSCFHeader, sizeof(LstTSCFHeader));
            LulEthTxBufIdx += sizeof(LstTSCFHeader);
        }
        else
        {
            /* AVTP None */
        }
    }
    else
    {
        if (PROTOCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        {
            /* Copy NTSCF Header to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstNTSCFHeader, sizeof(LstNTSCFHeader));
            LulEthTxBufIdx += sizeof(LstNTSCFHeader);
        }
        else
        {
            /* IP Flag None AND AVTP None is not support, so no need to consider */
            /* Copy TSCF Header to Tx buffer*/
            ProtoConv_UtilMemCpy(&LaaModuleTxBuf[LulEthTxBufIdx], &LstTSCFHeader, sizeof(LstTSCFHeader));
            LulEthTxBufIdx += sizeof(LstTSCFHeader);
        }
    }

    /* Save latest Eth Tx Buffer  */
    pBufInfo->ulTxBufIdx = LulEthTxBufIdx;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_021]:[Gen5GW_ProtoConv_UD_12_021]
* Function Name: CreateVlanHeader
* Description  : Create VLAN Header.
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                *pSize -
*                    Header size
*                *pBufInfo -
*                    Buffer Information
* Return Value : N/A
*******************************************************************************/
static void CreateVlanHeader(const R_ProtoConv_HeaderType *pHeaderField, uint32 *pSize, ProtoConv_BufInfoType *pBufInfo)
{
    ProtoConv_IEEE8021QType *pIEEE8021QHeader;

    /* Create IEEE802.1Q Header */
    if ((uint32)NUM0 != (uint32)pHeaderField->usVlanId)
    {
        pIEEE8021QHeader = (ProtoConv_IEEE8021QType*)&pBufInfo->pTxBufPtr[pBufInfo->ulTxBufIdx];
        pIEEE8021QHeader->usVlanId = pHeaderField->usVlanId;
        if ((uint32)PROTOCONV_SET == (uint32)pHeaderField->ucIpSetFlag)
        {
            if ((uint32)PROTOCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
            {
                pIEEE8021QHeader->usFrameType = PROTOCONV_FRAMETYPE_IPV4;
            }
            else
            {
                pIEEE8021QHeader->usFrameType = PROTOCONV_FRAMETYPE_IPV6;
            }
        }
        else if (((uint32)PROTOCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        ||       ((uint32)PROTOCONV_FLAG_TSCF  == (uint32)pHeaderField->ucAvtpFormat))
        {
            pIEEE8021QHeader->usFrameType = PROTOCONV_FRAMETYPE_AVTP;
        }
        else
        {
            /* Do nothing */
        }

        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv16(&pIEEE8021QHeader->usVlanId);
        ProtoConv_UtilEndianConv16(&pIEEE8021QHeader->usFrameType);
        #endif

        pBufInfo->ulTxBufIdx += sizeof(ProtoConv_IEEE8021QType);
        *pSize += sizeof(ProtoConv_IEEE8021QType);
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_022]:[Gen5GW_ProtoConv_UD_12_022]
* Function Name: CreateIpv4Header
* Description  : Create IPv4 Header.
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                usUdpPktLen -
*                    Total Length field
*                *pIpHeader -
*                    IPv4 header
* Return Value : N/A
*******************************************************************************/
static void CreateIpv4Header(const R_ProtoConv_HeaderType *pHeaderField,
    const uint16 usUdpPktLen, ProtoConv_Ipv4HeaderType *pIpHeader)
{
    uint32 LulChecksum;

    /* Create IPv4 Header */
    /* Set Version/Internet Header Length field */
    pIpHeader->ucVerAndHeaderLen = VER_AND_HEADERLEN_IPV4;
    pIpHeader->ucServiceType = SERVICE_TYPE_IPV4;
    pIpHeader->usPktLen = (uint16)((uint16)HEADER_LEN_IPV4 + usUdpPktLen);

    /* Set Identification field */
    pIpHeader->usId = ID_IPV4;
    /* Set Various Control Flags/Fragment Offset field */
    pIpHeader->usFragment = FRAGMENT_IPV4;
    /* Set TTL field */
    pIpHeader->ucTTL = TTL_IPV4;
    /* Set Protocol field */
    pIpHeader->ucProtocol = PROTOCOL_UDP;
    pIpHeader->usChecksum = CHECKSUM_ZERO;
    pIpHeader->ulSrcIpAddr = ProtoConv_GstEthSrcCfg.ulSrcIpv4Addr;
    pIpHeader->ulDestIpAddr = pHeaderField->aaDestIpAddr[IDX_0];

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    /* Endian conversion */
    ProtoConv_UtilEndianConv16(&pIpHeader->usPktLen);
    ProtoConv_UtilEndianConv16(&pIpHeader->usId);
    ProtoConv_UtilEndianConv16(&pIpHeader->usFragment);
    ProtoConv_UtilEndianConv16(&pIpHeader->usChecksum);
    ProtoConv_UtilEndianConv32(&pIpHeader->ulSrcIpAddr);
    ProtoConv_UtilEndianConv32(&pIpHeader->ulDestIpAddr);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    /* Calculate IPv4 Header checksum */
    LulChecksum = NUM0;
    ProtoConv_UtilCalcSum(pIpHeader, (uint16)sizeof(ProtoConv_Ipv4HeaderType), &LulChecksum);
    /* Set checksum field to the 1's complement value of calculated checksum */
    pIpHeader->usChecksum = (uint16)~LulChecksum;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_023]:[Gen5GW_ProtoConv_UD_12_023]
* Function Name: CreateIpv6Header
* Description  : Create IPv6 Header.
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                usUdpPktLen -
*                    Total Length field
*                *pIpHeader -
*                    IPv6 header
* Return Value : N/A
*******************************************************************************/
static void CreateIpv6Header(const R_ProtoConv_HeaderType *pHeaderField,
   const uint16 usUdpPktLen, ProtoConv_Ipv6HeaderType *pIpHeader)
{
    uint32 LulCount;

    /* Create IPv6 Header */
    /* Set Version, Traffic Class and Flow Label field */
    pIpHeader->ulVerClassAndLabel = VER_CLASS_AND_LABEL_IPV6;
    pIpHeader->usPayloadLen = usUdpPktLen;

    /* Set Next Header field */
    pIpHeader->ucNextHeader = PROTOCOL_UDP;
    /* Set TTL field */
    pIpHeader->ucHopLimit = HL_IPV6;
    /* Set Source/Destination IP Address field */
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        pIpHeader->aaSrcIpAddr[LulCount] = ProtoConv_GstEthSrcCfg.aaSrcIpv6Addr[LulCount];
        pIpHeader->aaDestIpAddr[LulCount] = pHeaderField->aaDestIpAddr[LulCount];
    }

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    /* Endian conversion */
    ProtoConv_UtilEndianConv32(&pIpHeader->ulVerClassAndLabel);
    ProtoConv_UtilEndianConv16(&pIpHeader->usPayloadLen);
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        ProtoConv_UtilEndianConv32(&pIpHeader->aaSrcIpAddr[LulCount]);
        ProtoConv_UtilEndianConv32(&pIpHeader->aaDestIpAddr[LulCount]);
    }
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_024]:[Gen5GW_ProtoConv_UD_12_024]
* Function Name: CalcIpv4UdpPseudoCheckSum
* Description  : Calculate CheckSum for IPv4 Pseudo Header.
* Arguments    : *pIpv4Header -
*                    IPv4 header
*                *pUdpHeader -
*                    UDP header
*                *pChecksum -
*                    Checksum value
* Return Value : N/A
*******************************************************************************/
static void CalcIpv4UdpPseudoCheckSum(const ProtoConv_Ipv4HeaderType *pIpv4Header,
                                      const ProtoConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum)
{
    ProtoConv_Ipv4PseudoHeaderType LstIpv4PseudoHeader;

    /* Create IPv4 Pseudo Header */
    LstIpv4PseudoHeader.ulSrcIpAddr  = pIpv4Header->ulSrcIpAddr;
    LstIpv4PseudoHeader.ulDestIpAddr = pIpv4Header->ulDestIpAddr;
    LstIpv4PseudoHeader.ucPadZero    = NUM0;
    LstIpv4PseudoHeader.ucProtocol   = PROTOCOL_UDP;
    LstIpv4PseudoHeader.usDataLen    = pUdpHeader->usLen;

    /* Calculate CheckSum for IPv4 Pseudo Header */
    ProtoConv_UtilCalcSum(&LstIpv4PseudoHeader,
                           (uint16)sizeof(ProtoConv_Ipv4PseudoHeaderType), pChecksum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_025]:[Gen5GW_ProtoConv_UD_12_025]
* Function Name: CalcIpv6UdpPseudoCheckSum
* Description  : Calculate CheckSum for IPv6 Pseudo Header.
* Arguments    : *pIpv6Header -
*                    IPv6 header
*                *pUdpHeader -
*                    UDP header
*                *pChecksum -
*                    Checksum value
* Return Value : N/A
*******************************************************************************/
static void CalcIpv6UdpPseudoCheckSum(const ProtoConv_Ipv6HeaderType *pIpv6Header,
                                      const ProtoConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum)
{
    ProtoConv_Ipv6PseudoHeaderType LstIpv6PseudoHeader;
    uint32 LulCount;

    /* Create IPv6 Pseudo Header */
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)PROTOCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        LstIpv6PseudoHeader.aaSrcIpAddr[LulCount]  = pIpv6Header->aaSrcIpAddr[LulCount];
        LstIpv6PseudoHeader.aaDestIpAddr[LulCount] = pIpv6Header->aaDestIpAddr[LulCount];
    }
    LstIpv6PseudoHeader.ulPayloadLen = (uint32)pUdpHeader->usLen;
    LstIpv6PseudoHeader.aaPadZero[IDX_0] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_1] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_2] = NUM0;
    LstIpv6PseudoHeader.ucNextHeader = (uint8)PROTOCOL_UDP;
    
    /* Calculate CheckSum for IPv6 Pseudo Header */
    ProtoConv_UtilCalcSum(&LstIpv6PseudoHeader,
                           (uint16)sizeof(ProtoConv_Ipv6PseudoHeaderType), pChecksum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_026]:[Gen5GW_ProtoConv_UD_12_026]
* Function Name: CreateNTSCFHeader
* Description  : Create NTSCF Header.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                ulDataLen -
*                    Data length
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pstNTSCFHeader -
*                    NTSCF header
* Return Value : N/A
*******************************************************************************/
static void CreateNTSCFHeader(const uint32 ulEntryIdx, const uint32 ulDataLen,
   const R_ProtoConv_HeaderType *pHeaderField, ProtoConv_NTSCFType *pstNTSCFHeader)
{
    /* Create NTSCF Header */
    pstNTSCFHeader->ucSubType = SUBTYPE_NTSCF;
    pstNTSCFHeader->ucSvVerDataLenMSB = (uint8)(((uint32)pHeaderField->ucStreamIdValid << (uint32)SHIFT_7BIT) |
                                                ((uint32)ulDataLen >> (uint32)SHIFT_8BIT));
    pstNTSCFHeader->ucDataLenLSB = (uint8)ulDataLen;
    pstNTSCFHeader->aaStreamId[IDX_0] = pHeaderField->aaStreamId[IDX_0];
    pstNTSCFHeader->aaStreamId[IDX_1] = pHeaderField->aaStreamId[IDX_1];
    pstNTSCFHeader->ucSeqNum = ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]];

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(&pstNTSCFHeader->aaStreamId[IDX_0]);
    ProtoConv_UtilEndianConv32(&pstNTSCFHeader->aaStreamId[IDX_1]);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    if ((uint32)ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] < (uint32)MASK_8BIT)
    {
        ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] =
            (uint8)((uint32)ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] + (uint32)NUM1);
    }
    else
    {
        ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] = NUM0;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_027]:[Gen5GW_ProtoConv_UD_12_027]
* Function Name: CreateTSCFHeader
* Description  : Create TSCF Header.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                ulDataLen -
*                    Data length
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pstTSCFHeader -
*                    TSCF header
* Return Value : N/A
*******************************************************************************/
static void CreateTSCFHeader(const uint32 ulEntryIdx, const uint32 ulDataLen,
   const R_ProtoConv_HeaderType *pHeaderField, ProtoConv_TSCFType *pstTSCFHeader)
{
    Std_ReturnType LucRetVal;
    uint32  LulSec;
    uint32  LulnSec;
    uint32  LulAvtpTimestamp;
    uint16  LusSecHi;
    boolean LbTimeStampValid;
    boolean LbTimeStampUncertain;

    /* Get gPTPTime */
    LucRetVal = (uint8)ProtoConv_GetTimeUserDef(&LusSecHi, &LulSec, &LulnSec);
    if ((uint8)E_OK == LucRetVal)
    {
        LbTimeStampValid     = TRUE;
        LbTimeStampUncertain = FALSE;
        LulAvtpTimestamp     = (uint32)((LulSec * (uint32)GPTP_SECUNIT) + LulnSec);
    }
    else
    {
        LbTimeStampValid     = FALSE;
        LbTimeStampUncertain = TRUE;
        LulAvtpTimestamp     = NUM0;
    }

    /* Create TSCF Header */
    pstTSCFHeader->ucSubType          = SUBTYPE_TSCF;
    pstTSCFHeader->ucSvVerMrRsvTv     =
        (uint8)(((uint32)pHeaderField->ucStreamIdValid << (uint32)SHIFT_7BIT) |        /* StreamIdValid(1bit) */
        (uint32)(LbTimeStampValid ? NUM1 : NUM0));                                     /* TimeStampValid(1bit) */
    pstTSCFHeader->ucSeqNum           = ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]];
    pstTSCFHeader->ucReserveTu        = (uint8)(LbTimeStampUncertain ? NUM1 : NUM0);   /* Timestamp uncertain(1bit) */
    pstTSCFHeader->aaStreamId[IDX_0]  = pHeaderField->aaStreamId[IDX_0];
    pstTSCFHeader->aaStreamId[IDX_1]  = pHeaderField->aaStreamId[IDX_1];
    pstTSCFHeader->ulAvtpTimestamp    = LulAvtpTimestamp;
    pstTSCFHeader->ulReserved1        = NUM0;
    pstTSCFHeader->usStreamDataLength = (uint16)ulDataLen;
    pstTSCFHeader->usReserved1        = NUM0;

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(&pstTSCFHeader->aaStreamId[IDX_0]);
    ProtoConv_UtilEndianConv32(&pstTSCFHeader->aaStreamId[IDX_1]);
    ProtoConv_UtilEndianConv32(&pstTSCFHeader->ulAvtpTimestamp);
    ProtoConv_UtilEndianConv16(&pstTSCFHeader->usStreamDataLength);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    if ((uint32)ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] < (uint32)MASK_8BIT)
    {
        ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] =
            (uint8)((uint32)ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] + (uint32)NUM1);
    }
    else
    {
        ProtoConv_GucSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] = NUM0;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_028]:[Gen5GW_ProtoConv_UD_12_028]
* Function Name: GetEncapSequenceNumber
* Description  : Get EncapSequenceNumber.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pSeqNo -
*                    EncapSequence Number
* Return Value : N/A
*******************************************************************************/
static void GetEncapSequenceNumber(const uint32 ulEntryIdx, uint32 *pSeqNo)
{
    *pSeqNo = ProtoConv_GulEncapSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]];

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(pSeqNo);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    if (ProtoConv_GulEncapSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] < MASK_32BIT)
    {
        ProtoConv_GulEncapSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]]++;
    }
    else
    {
        ProtoConv_GulEncapSeqNum[ProtoConv_GulSeqNumIndex[ulEntryIdx]] = NUM0;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_029]:[Gen5GW_ProtoConv_UD_12_029]
* Function Name: CreateSeqNumIndex
* Description  : Create Sequence Number Index
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
static void CreateSeqNumIndex(void)
{
    uint32 LulSearchIdx;
    uint32 LulEntryIdx;

    /* loop all element */
    for (LulSearchIdx = IDX_0; LulSearchIdx < ProtoConv_GulXtoEthDestTblNum; LulSearchIdx++)
    {
        /* Initialize Index */
        ProtoConv_GulSeqNumIndex[LulSearchIdx] = LulSearchIdx;

        /* Search Same destination */
        for (LulEntryIdx = IDX_0; LulEntryIdx < LulSearchIdx; LulEntryIdx++)
        {
            if ((ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].aaDestMacAddr[IDX_0]             ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].aaDestMacAddr[IDX_0])
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].aaDestMacAddr[IDX_1]             ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].aaDestMacAddr[IDX_1])
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_0]     ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_0])
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_1]     ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_1])
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_2]     ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_2])
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_3]     ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_3])
            &&  ((uint32)ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.usDestUdpPort   ==
                (uint32)ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.usDestUdpPort)
            &&  ((uint32)ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucStreamIdValid ==
                (uint32)ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.ucStreamIdValid)
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.aaStreamId[IDX_0]       ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.aaStreamId[IDX_0])
            &&  (ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.aaStreamId[IDX_1]       ==
                ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.aaStreamId[IDX_1])
            &&  ((uint32)ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucIpSetFlag     ==
                (uint32)ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.ucIpSetFlag)
            &&  ((uint32)ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucIpType        ==
                (uint32)ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.ucIpType)
            &&  ((uint32)ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucAvtpFormat    ==
                (uint32)ProtoConv_GstXtoEthDestRoutTbl[LulSearchIdx].stHeader.ucAvtpFormat))
            {
                /* Update Same destination Index */
                ProtoConv_GulSeqNumIndex[LulSearchIdx] = LulEntryIdx;
                break;
            }
            else
            {
                /* No Entry is matched */
            }
        }
    }
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
