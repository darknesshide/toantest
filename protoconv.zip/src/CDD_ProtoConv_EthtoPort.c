/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to Port Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_EthtoX.h"
#include "CDD_ProtoConv_EthtoPort.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_015]:[Gen5GW_ProtoConv_UD_13_015]
* Function Name: ProtoConv_UnpackPort
* Description  : Unpack the Port frame in ACF format from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pLength -
*                    Port Data length
*                 *pErrorStatus -
*                    Error status of Port packet transmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_UnpackPort(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
                         uint16 *pLength, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint32 LulPortMsgInfo;
    uint16 LusLength;
    uint16 LusACFLength;
    uint16 LusBitWidth;
    uint16 LusPortDataLen;
    uint16 LusRequiredLen;

    LucRetVal = E_OK;

    /* Unpack PORT data from the payload */
    LusLength   = *pLength;
    LulFramePos = *pDataPosition;

    if (ulPayloadLen >= (LulFramePos + (uint32)ACF_PORT_MSG_INFO_LEN))
    {
        /* Retrieve all fields of PORT message info (ACF type, ACF length, reserved, bit_width) */
        ProtoConv_UtilMemCpy(&LulPortMsgInfo, &pPayload[LulFramePos], sizeof(LulPortMsgInfo));
        LulFramePos += sizeof(LulPortMsgInfo); 

        /* Endian conversion for PORT message info */
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulPortMsgInfo);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        LusACFLength = (uint16)((LulPortMsgInfo >> SHIFT_16BIT) & MASK_9BIT);
        LusBitWidth  = (uint16)(LulPortMsgInfo & MASK_8BIT);

        /* Check if bit_width field is out of range and calculate the payload length in byte-level*/
        if ((uint16)PORT_BIT_WIDTH_MIN == LusBitWidth)
        {
            LusPortDataLen = MAX_PORT_UNIT_LEN;    /*256 bits = 32 bytes*/
            LusRequiredLen = MAX_PORT_UNIT_LEN;
        }
        else
        {
            LusPortDataLen = (LusBitWidth + NUM8 - NUM1) / NUM8;
            LusRequiredLen = ((LusBitWidth + MAX_PORT_UNIT_LEN - NUM1) / MAX_PORT_UNIT_LEN) * QUADLETS_BYTES;
        }

        /* Check if ACF Length matches with the bit_width */
        if (LusACFLength == (uint16)(NUM1 + ((LusPortDataLen + ACF_PAD_SIZE_MAX) / QUADLETS_BYTES)))
        {
            /* Copy PORT data to Tx buffer */
            ProtoConv_UtilMemCpy(&ProtoConv_GaaPortTxBuf[LusLength], &pPayload[LulFramePos], (uint32)LusPortDataLen);
            /* Set PORT data length */
            LusLength = LusLength + LusPortDataLen;

            /* Return the next message position */
            *pDataPosition = LulFramePos + (uint32)LusRequiredLen;
            *pLength       = LusLength;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDPORT);
            #endif
            *pErrorStatus = PROTOCONV_E_PACKEDPORT;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No PORT message if the data length from the unpacked position is
         * less than the length of the ACF Parallel message info.
         */
        *pErrorStatus = PROTOCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_016]:[Gen5GW_ProtoConv_UD_13_016]
* Function Name: ProtoConv_UnpackPortIPDUM
* Description  : Unpack the Port frame in IPDU-M from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pLength -
*                    Port Data length
*                 *pErrorStatus -
*                    Error status of Port packet transmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_UnpackPortIPDUM(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
                         uint16 *pLength, uint8 *pErrorStatus)
{
    uint32 LulDlc;
    uint32 LulFramePos;
    uint16 LusLength;
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* Unpack PORT data from the payload */
    LusLength   = *pLength;
    LulFramePos = *pDataPosition;

    if (ulPayloadLen >= (LulFramePos + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC))
    {
        LulFramePos += (uint32)PDU_LEN_ID;
        /* Retrieve data length of Port */
        ProtoConv_UtilMemCpy(&LulDlc, &pPayload[LulFramePos], PDU_LEN_DLC);
        LulFramePos += (uint32)PDU_LEN_DLC;
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulDlc);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        if (((uint32)MAX_PORT_TOTAL_SIZE >= LulDlc)
        &&  ((uint32)MIN_PORT_TOTAL_SIZE <= LulDlc)
        &&  ((LulFramePos + LulDlc) <= ulPayloadLen))
        {
            /* Copy PORT data to Tx buffer */
            ProtoConv_UtilMemCpy(&ProtoConv_GaaPortTxBuf[IDX_0], &pPayload[LulFramePos], LulDlc);
            /* Set PORT data */
            LusLength = LusLength + (uint16)(LulDlc);
            /* Return the next message position */
            *pDataPosition = LulFramePos + LulDlc;
            *pLength       = LusLength;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDPORT);
            #endif            
            /* Invalid Port data length */
            *pErrorStatus = PROTOCONV_E_PACKEDPORT;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No PORT message if the data length from the unpacked position is
         * less than the length of the IPDU-M Port message.
         */
        *pErrorStatus = PROTOCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
