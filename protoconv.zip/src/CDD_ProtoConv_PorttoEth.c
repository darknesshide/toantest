/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Port to Ethernet Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_XtoEth.h"
#include "CDD_ProtoConv_PorttoEth.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_interface.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* Port Msg Buffer */
typedef struct
{
    uint16 usAcfMsgLen;
    uint16 usBitWidth;
} ProtoConv_PortMsgInfo;

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

static Std_ReturnType SendSinglePort(const uint16 usLength, const uint8 *pPortData, const uint32 ulEntryIdx,
                                     const R_ProtoConv_HeaderType *pHeaderField);

static Std_ReturnType ProcessBufModeforPort(const uint16 usLength, const uint8 *pPortData,
                                            const uint32 ulEntryIdx, const R_ProtoConv_HeaderType *pHeaderField);

static void StorePorttoEthBufData(const uint16 usLength, const uint8 *pPortData, ProtoConv_BufInfoType *pBufInfo);

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_005]:[Gen5GW_ProtoConv_UD_12_005]
* Function Name: ProtoConv_PorttoEth
* Description  : Port to Ethernet Conversion Function
* Arguments    : usLength    - Port Data length
*                *pPortData  - Port Data
*                ulDestIdx   - Destination Index
*                enTypeFlags - Frame Type Flag
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_PorttoEth(const uint16 usLength, const uint8 *pPortData, const uint32 ulDestIdx,
   const R_ProtoConv_FrameType enTypeFlags)
{
    R_ProtoConv_HeaderType LstHeaderField;
    Std_ReturnType         LucRetVal;
    uint32                 LulEntryIdx;

    LucRetVal = E_OK;
    
    LulEntryIdx = (uint32)ulDestIdx;
    
    /* For Port, Basic and buffer mode use the same Ethernet Destination Routing Table Entry */
    /* Copy from X to Ethernet Destination Routing Table Entry to pHeaderField */
    LstHeaderField = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader;
    /* To address the warning that it has not been initialized with MISRA-C. */
    LstHeaderField.ucIpSetFlag     = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucIpSetFlag;
    LstHeaderField.ucIpType        = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucIpType;
    LstHeaderField.ucAvtpFormat    = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucAvtpFormat;
    LstHeaderField.usDestUdpPort   = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.usDestUdpPort;
    LstHeaderField.usVlanId        = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.usVlanId;
    LstHeaderField.ucStreamIdValid = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.ucStreamIdValid;
    LstHeaderField.enFormatType    = ProtoConv_GstXtoEthDestRoutTbl[LulEntryIdx].stHeader.enFormatType;

    /* Check Conversion Mode */
    switch (ProtoConv_GstConvCfg.enConvMode)
    {
    case PROTOCONV_BASICMODE:
        LucRetVal = SendSinglePort(usLength, pPortData, LulEntryIdx, &LstHeaderField);
        break;
    case PROTOCONV_BUFFERMODE:
        switch (enTypeFlags)
        {
        case PROTOCONV_EMERGENCY_FRAME:
            LucRetVal = SendSinglePort(usLength, pPortData, LulEntryIdx, &LstHeaderField);
            break;
        case PROTOCONV_NORMAL_FRAME:
            LucRetVal = ProcessBufModeforPort(usLength, pPortData, LulEntryIdx, &LstHeaderField);
            break;
        default:
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID,
                                  PROTOCONV_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
            break;
        }
        break;
    default:
        /* Do nothing */
        LucRetVal = E_OK;
        break;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_039]:[Gen5GW_ProtoConv_UD_12_039]
* Function Name: SendSinglePort
* Description  : Convert one single Port frame and send Ethernet frame
* Arguments    : usLength    - Port Data length
*                *pPortData  - Port Data
*                ulEntryIdx  - Route Table Index
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendSinglePort(const uint16 usLength, const uint8 *pPortData, const uint32 ulEntryIdx,
                                     const R_ProtoConv_HeaderType *pHeaderField)
{
    ProtoConv_BufInfoType LstBufInfo;
    Std_ReturnType LucRetVal;

    ProtoConv_EnterCriticalUserDef();

    LstBufInfo.pTxBufPtr   = ProtoConv_GaaEthTxBuf;
    LstBufInfo.ulTxBufIdx  = ProtoConv_GulEthTxBufIdx;
    LstBufInfo.ulRxBufSize = ProtoConv_GulPortRxBufSize;
    LstBufInfo.ulRxBufLen  = ProtoConv_GulPortRxBufLen;
    LstBufInfo.pRxBufPtr   = ProtoConv_GaaPortRxBuf;

    if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
    {
        /* IPDU-M format */
        ProtoConv_StorePdutoEthBufData(PORT_PDU_ID, usLength, pPortData, &LstBufInfo);
    }
    else
    {
        /* ACF Parallel format */
        StorePorttoEthBufData(usLength, pPortData, &LstBufInfo);
    }

    /* Update buffer information after storing data */
    ProtoConv_GulPortRxBufLen = LstBufInfo.ulRxBufLen;
    LucRetVal = ProtoConv_CreateAndSendEthFrame(ulEntryIdx, &LstBufInfo, pHeaderField);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID, PROTOCONV_E_TRANS);
        #endif
    }
    /* Reset Port Rx Buffer */
    ProtoConv_GulPortRxBufLen = NUM0;
    /* Reset Ethernet Tx Buffer Index */
    ProtoConv_GulEthTxBufIdx = NUM0;

    ProtoConv_ExitCriticalUserDef();

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_040]:[Gen5GW_ProtoConv_UD_12_040]
* Function Name: ProcessBufModeforPort
* Description  : Create Ethernet Frame and Send with Buffer Type
* Arguments    : usLength    - Port Data length
*                *pPortData  - Port Data
*                ulEntryIdx  - Route Table Index
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType ProcessBufModeforPort(const uint16 usLength, const uint8 *pPortData,
                                            const uint32 ulEntryIdx, const R_ProtoConv_HeaderType *pHeaderField)
{
    Std_ReturnType          LucRetVal;
    ProtoConv_BufInfoType   LstBufInfo;
    uint32                  LulDataSize;

    LucRetVal = E_OK;

    ProtoConv_EnterCriticalUserDef();
    
    LstBufInfo.pTxBufPtr   = ProtoConv_GaaEthTxBuf;
    LstBufInfo.ulTxBufIdx  = ProtoConv_GulEthTxBufIdx;
    LstBufInfo.ulRxBufSize = ProtoConv_GulMixRxBufSize[ulEntryIdx];
    LstBufInfo.ulRxBufLen  = ProtoConv_GulMixRxBufLen[ulEntryIdx];
    LstBufInfo.pRxBufPtr   = ProtoConv_GaaMixRxBuf[ulEntryIdx];

    /* Check Receive Data Size. */
    if ((uint32)NUM0 != LstBufInfo.ulRxBufLen)
    {
        /* Get Buffer size if adding the next Port frame */
        if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
        {
            /* IPDU-M fortmat */
            LulDataSize = LstBufInfo.ulRxBufLen + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC + (uint32)usLength;
        }
        else
        {
            /* ACF Parallel format */
            LulDataSize  = LstBufInfo.ulRxBufLen + (uint32)ACF_PORT_MSG_INFO_LEN + (uint32)usLength;
        }

        /* Check if buffer size overflows if adding the next Port frame */
        if ((uint32)LulDataSize <= LstBufInfo.ulRxBufSize)
        {
            /* Not overflow. Do nothing. */
        }
        else
        {
            /* Send frame in buffer. */
            LucRetVal = ProtoConv_CreateAndSendEthFrame(ulEntryIdx, &LstBufInfo, pHeaderField);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID,
                                      PROTOCONV_E_TRANS);
                #endif
            }
            /* Reset Mix Rx Buffer */
            ProtoConv_GulMixRxBufLen[ulEntryIdx] = NUM0;
            ProtoConv_GulMixCount[ulEntryIdx] = NUM0;
            /* Reset Ethernet Tx Buffer Index */
            ProtoConv_GulEthTxBufIdx = NUM0;
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
        {
            /* IPDU-M format */
            ProtoConv_StorePdutoEthBufData(PORT_PDU_ID, usLength, pPortData, &LstBufInfo);
        }
        else
        {
            /* ACF Parallel format */
            StorePorttoEthBufData(usLength, pPortData, &LstBufInfo);
        }
        
        /* Update buffer information after storing data */
        ProtoConv_GulMixCount[ulEntryIdx]++;
        ProtoConv_GulMixRxBufLen[ulEntryIdx] = LstBufInfo.ulRxBufLen;

        if (((LstBufInfo.ulRxBufLen + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC) > LstBufInfo.ulRxBufSize) ||
            (ProtoConv_GulMixCount[ulEntryIdx] >= ProtoConv_GstConvCfg.ulFrameLimit))
        {
            /* Sending conditions met. Send frame in buffer. */
            LucRetVal = ProtoConv_CreateAndSendEthFrame(ulEntryIdx, &LstBufInfo, pHeaderField);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID,
                                      PROTOCONV_E_TRANS);
                #endif
            }
            /* Reset Mix Rx Buffer */
            ProtoConv_GulMixRxBufLen[ulEntryIdx] = NUM0;
            ProtoConv_GulMixCount[ulEntryIdx] = NUM0;
            /* Reset Ethernet Tx Buffer Index */
            ProtoConv_GulEthTxBufIdx = NUM0;
        }
        else
        {
            /* Do Nothing */
        }

    }
    else
    {
        /* Do Nothing */
    }

    ProtoConv_ExitCriticalUserDef();

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_041]:[Gen5GW_ProtoConv_UD_12_041]
* Function Name: StorePorttoEthBufData
* Description  : Store CAN frame to Ethernet Data Buffer.
* Arguments    : usLength      - Port Data length
*                *pPortData    - Port Data
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : N/A
*******************************************************************************/
static void StorePorttoEthBufData(const uint16 usLength, const uint8 *pPortData, ProtoConv_BufInfoType *pBufInfo)
{
    uint8  *LpBuffPtr;
    /* ACF Port Mesage information*/
    ProtoConv_PortMsgInfo LstPortMsgInfo[MAX_ACF_PORT_MSG_NUM];
    uint32 LulDataSize;
    uint32 LulPortMsgInfo;
    uint32 LulRxBufLen;
    uint16 LusPayloadPosition;
    uint16 LusPayloadLen;
    uint16 LusPaddingByte;
    uint8  LaaPayload[MAX_PORT_MSG_PAYLOAD];
    uint8  LucMsgNum;
    uint8  LucIndex;
    uint8  LucCount;
    uint8  LucSurplus;

    /* Calculate number of Port Messages */
    LucMsgNum  = (uint8)(usLength / MAX_PORT_UNIT_LEN);
    LucSurplus = (uint8)(usLength % MAX_PORT_UNIT_LEN);
    if (NUM0 != LucSurplus)
    {
        LucMsgNum += NUM1;
    }
    else
    {
        /* Do nothing*/
    }

    LusPaddingByte = NUM0;
    LulRxBufLen = pBufInfo->ulRxBufLen;
    LpBuffPtr   = &pBufInfo->pRxBufPtr[pBufInfo->ulRxBufLen];

    LulDataSize = LulRxBufLen + ((uint32)ACF_PORT_MSG_INFO_LEN * (uint32)LucMsgNum) + (uint32)usLength;

    for (LucCount = IDX_0; LucCount < LucMsgNum; LucCount++)
    {
        LucIndex = LucCount;
        /* Calculate the length of the buffered payload's data */
        LusPayloadLen = (MAX_PORT_UNIT_LEN * (uint16)LucIndex);

        /* Check if this is not the last message or when usLength % 32 = 0*/
        if (((uint8)NUM1 != (LucMsgNum - LucIndex))
        || ((uint16)NUM0 == LucSurplus))
        {
            LstPortMsgInfo[LucIndex].usAcfMsgLen = NUM9;
            LstPortMsgInfo[LucIndex].usBitWidth  = NUM0;
            LusPaddingByte = NUM0;

            for (LusPayloadPosition = LusPayloadLen;
                LusPayloadPosition < (uint16)(MAX_PORT_UNIT_LEN + LusPayloadLen); LusPayloadPosition++)
            {
                LaaPayload[LusPayloadPosition] = pPortData[LusPayloadPosition];
            }
        }
        /* Check if this is the last message */
        else
        {
            LstPortMsgInfo[LucIndex].usAcfMsgLen =
                (uint16)(NUM1 + ((usLength + (uint16)ACF_PAD_SIZE_MAX - LusPayloadLen) / (uint16)QUADLETS_BYTES));
            LstPortMsgInfo[LucIndex].usBitWidth  = (uint16)((usLength - LusPayloadLen) * NUM8);
            for (LusPayloadPosition = LusPayloadLen;
            LusPayloadPosition < usLength; LusPayloadPosition++)
            {
                LaaPayload[LusPayloadPosition] = pPortData[LusPayloadPosition];
            }
            LusPaddingByte = (uint16)(QUADLETS_BYTES - (usLength % QUADLETS_BYTES));

            /*
             * Check payload to zero-pad it to the nearest quadlet boundary.
             * LusPaddingByte after calculating is in range from 1 to 4.
             * If LusPaddingByte is 1, 2 or 3, conduct zero-padding.
             */
            if ((uint16)ACF_PAD_SIZE_MAX >= LusPaddingByte)
            {
                /* Zero-padding at byte-level */
                ProtoConv_UtilMemSet((uint8 *)LaaPayload + LusPayloadPosition, (uint8)NUM0, (uint32)LusPaddingByte);
                /* Zero-padding at bit-level does not occur */
            }
            /* If LusPaddingByte is 4, reset to 0*/
            else
            {
                LusPaddingByte = NUM0;
            }
        }

        LulPortMsgInfo = (((uint32)ACF_PARALLEL << (uint32)SHIFT_25BIT) |
                          ((uint32)LstPortMsgInfo[LucIndex].usAcfMsgLen << (uint32)SHIFT_16BIT) |
                          ((uint32)LstPortMsgInfo[LucIndex].usBitWidth));

        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulPortMsgInfo);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        /* Calculate current position */
        ProtoConv_UtilMemCpy(LpBuffPtr, &LulPortMsgInfo, sizeof(LulPortMsgInfo));
        LpBuffPtr = &LpBuffPtr[sizeof(LulPortMsgInfo)];
        ProtoConv_UtilMemCpy(LpBuffPtr, &LaaPayload[LusPayloadLen],
                            (uint32)((uint32)LusPayloadPosition - (uint32)LusPayloadLen + (uint32)LusPaddingByte));

        /* Check if this is not the last message, update the current posistion for the next message*/
        if ((uint8)NUM1 != (LucMsgNum - LucIndex))
        {
           LpBuffPtr = &LpBuffPtr[(LusPayloadPosition - LusPayloadLen)];
        }
        else
        {
            /* Do nothing */
        }
    }
    /* Update current position */
    pBufInfo->ulRxBufLen = LulDataSize + LusPaddingByte;
    pBufInfo->ulRxBufCount++;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
