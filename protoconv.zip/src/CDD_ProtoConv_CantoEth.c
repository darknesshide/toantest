/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the CAN to Ethernet Conversion functions.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_XtoEth.h"
#include "CDD_ProtoConv_CantoEth.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_interface.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/* Private functions for Can to Ethernet Conversion */
static Std_ReturnType ProcessBufModeforCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
    const R_ProtoConv_TimeStampType *pTimeStamp, const uint8 ucFormatType);

static Std_ReturnType SendSingleCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
    const R_ProtoConv_TimeStampType *pTimeStamp, const uint8 ucFormatType);

static Std_ReturnType SearchCantoEthRoutTbl(const uint8 ucBusIdx,
                const R_ProtoConv_CanFrameType *pCanFrame, uint32 *pEntryIdx, uint32 *pPduId,
                R_ProtoConv_FrameType *pTypeFlags, R_ProtoConv_HeaderType *pHeaderField);

static void StoreCantoEthBufData(const uint8 ucBusIdx, const uint8 ucFormatType, 
                const R_ProtoConv_CanFrameType *pCanFrame, ProtoConv_BufInfoType *pBufInfo,
                const R_ProtoConv_TimeStampType *pTimeStamp);

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_002]:[Gen5GW_ProtoConv_UD_12_002]
* Function Name: ProtoConv_CantoEthTS
* Description  : Can with TimeStamp to Ethernet Conversion Function
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
*                *pTimeStamp - Time Stamp
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_CantoEthTS(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
   const R_ProtoConv_TimeStampType *pTimeStamp)
{
    Std_ReturnType          LucRetVal;

    LucRetVal = E_OK;

    /* Check CAN-ID */
    LucRetVal = ProtoConv_UtilCanIdCheck(pCanFrame->ulCanId);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Check CAN-DLC */
        LucRetVal = ProtoConv_UtilCanDlcCheck(pCanFrame->ulCanDlc);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do Nothing */
        }
        else
        {                
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETHTS_SID,
                                  PROTOCONV_E_INV_PARAM);
            #endif
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETHTS_SID,
                              PROTOCONV_E_INV_PARAM);
        #endif
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Check Conversion Mode */
        switch (ProtoConv_GstConvCfg.enConvMode)
        {
        case PROTOCONV_BASICMODE:
            LucRetVal = SendSingleCan(ucBusIdx, pCanFrame, pTimeStamp, ACF_CAN);
            break;
        case PROTOCONV_BUFFERMODE:   
            LucRetVal = ProcessBufModeforCan(ucBusIdx, pCanFrame, pTimeStamp, ACF_CAN);
            break;
        default:
            /* Do nothing */
            LucRetVal = E_OK;
            break;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_003]:[Gen5GW_ProtoConv_UD_12_003]
* Function Name: ProtoConv_CantoEth
* Description  : Can to Ethernet Conversion Function
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_CantoEth(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame)
{
    R_ProtoConv_TimeStampType LstTimeStamp;
    Std_ReturnType          LucRetVal;
    
    LucRetVal = E_OK;

    LstTimeStamp.ulNanosecond = NUM0;
    LstTimeStamp.ulSecond = NUM0;

    /* Check CAN-ID */
    LucRetVal = ProtoConv_UtilCanIdCheck(pCanFrame->ulCanId);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Check CAN-DLC */
        LucRetVal = ProtoConv_UtilCanDlcCheck(pCanFrame->ulCanDlc);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do Nothing */
        }
        else
        {                
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETH_SID,
                                  PROTOCONV_E_INV_PARAM);
            #endif
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETH_SID,
                              PROTOCONV_E_INV_PARAM);
        #endif
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Check Conversion Mode */
        switch (ProtoConv_GstConvCfg.enConvMode)
        {
        case PROTOCONV_BASICMODE:
            LucRetVal = SendSingleCan(ucBusIdx, pCanFrame, &LstTimeStamp, ACF_CAN_BRIEF);
            break;
        case PROTOCONV_BUFFERMODE:
            LucRetVal = ProcessBufModeforCan(ucBusIdx, pCanFrame, &LstTimeStamp, ACF_CAN_BRIEF);
            break;
        default:
            /* Do nothing */
            LucRetVal = E_OK;
            break;
        }
    }
    else
    {
        /*Do nothing */
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_030]:[Gen5GW_ProtoConv_UD_12_030]
* Function Name: SendSingleCan
* Description  : Convert one single Can frame and send Ethernet frame
* Arguments    : ucBusIdx     - Bus Index
*                *pCanFrame   - CAN frame
*                *pTimeStamp  - Time Stamp
*                ucFormatType - Frame Format Type
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendSingleCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame, 
                                    const R_ProtoConv_TimeStampType *pTimeStamp, const uint8 ucFormatType)
{
    R_ProtoConv_HeaderType LstHeaderField;
    ProtoConv_BufInfoType  LstBufInfo;
    R_ProtoConv_FrameType  LenTypeFlags;
    uint32 LulEntryIdx;
    uint32 LulPduId;
    Std_ReturnType LucRetVal;

    ProtoConv_EnterCriticalUserDef();

    LstBufInfo.pTxBufPtr   = ProtoConv_GaaEthTxBuf;
    LstBufInfo.ulTxBufIdx  = ProtoConv_GulEthTxBufIdx;
    LstBufInfo.ulRxBufSize = ProtoConv_GulCanRxBufSize;
    LstBufInfo.ulRxBufLen  = ProtoConv_GulCanRxBufLen;
    LstBufInfo.pRxBufPtr   = ProtoConv_GaaCanRxBuf;

    LucRetVal = SearchCantoEthRoutTbl(ucBusIdx, pCanFrame, &LulEntryIdx, &LulPduId, &LenTypeFlags, &LstHeaderField);
    if ((uint8)E_OK == LucRetVal)
    {
        if (PROTOCONV_IPDUM_FORMAT == LstHeaderField.enFormatType)
        {
            /* IPDU-M format */
            ProtoConv_StorePdutoEthBufData(LulPduId, pCanFrame->ulCanDlc, pCanFrame->pCanData, &LstBufInfo);
        }
        else
        {
            /* ACF format */
            StoreCantoEthBufData(ucBusIdx, ucFormatType, pCanFrame, &LstBufInfo, pTimeStamp);
        }
 
        /* Update buffer information after storing data */
        ProtoConv_GulCanRxBufLen = LstBufInfo.ulRxBufLen;

        LucRetVal = ProtoConv_CreateAndSendEthFrame(LulEntryIdx, &LstBufInfo, &LstHeaderField);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            /* Use ucFormatType to identify caller */
            if (ucFormatType == ACF_CAN)
            {
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID,
                                      R_PROTOCONV_CANTOETHTS_SID, PROTOCONV_E_TRANS);
            }
            else
            {
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID,
                                      R_PROTOCONV_CANTOETH_SID, PROTOCONV_E_TRANS);
            }
            #endif
        }
        /* Reset CAN Rx Buffer */
        ProtoConv_GulCanRxBufLen = NUM0;
        /* Reset Ethernet Tx Buffer Index */
        ProtoConv_GulEthTxBufIdx = NUM0;
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        /* Use ucFormatType to identify caller */
        if (ucFormatType == ACF_CAN)
        {
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETHTS_SID, 
                                  PROTOCONV_E_MATCH);
        }
        else
        {
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETH_SID, 
                                  PROTOCONV_E_MATCH);
        }
        #endif
    }

    ProtoConv_ExitCriticalUserDef();

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_031]:[Gen5GW_ProtoConv_UD_12_031]
* Function Name: SearchCantoEthRoutTbl
* Description  : Search CAN to Ethernet Routing Table.
* Arguments    : ucBusIdx      - Bus Index
*                *pCanFrame    - CAN frame
*                *pTimeStamp   - Time Stamp
*                *pEntryIdx    - Route Table Index
*                *pPduId       - RPDU ID
*                *pTypeFlags   - Frame Type Fomat
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SearchCantoEthRoutTbl(const uint8 ucBusIdx,
                const R_ProtoConv_CanFrameType *pCanFrame, uint32 *pEntryIdx, uint32 *pPduId,
                R_ProtoConv_FrameType *pTypeFlags, R_ProtoConv_HeaderType *pHeaderField)
{
    const R_ProtoConv_CantoEthSubTblType *LpCantoEthSubTbl;
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulLeftIdx; /* start key of index */
    uint32 LulRightIdx; /* end key of index */
    uint32 LulCenterIdx; /* middle key of index */
    uint32 LulTargetCanId; /* search value */
    uint32 LulCenterStartValue; /* table in middle value */
    uint32 LulCenterEndValue; /* table in middle value */
    uint32 LulCantoEthSubTblEntryIdx;
    uint32 LulEthDestTblEntryIdx;

    LulEntryIdx = IDX_0;
    LulLeftIdx  = IDX_0;
    LulRightIdx = ProtoConv_GstCantoEthMainTblGeneral[ucBusIdx].ulCantoEthMainTblEntryNum;
    LulTargetCanId = pCanFrame->ulCanId;

    LucRetVal = E_NOT_OK;

    /* Binary search */
    while (LulLeftIdx <= LulRightIdx) 
    {
        LulCenterIdx = (LulLeftIdx + LulRightIdx) / NUM2; /* calc of middle key */
        LulCenterStartValue = ProtoConv_GstCantoEthMainTblGeneral[ucBusIdx].pCantoEthMainTbl[LulCenterIdx].ulCanId;
        LulCenterEndValue = LulCenterStartValue +
                  ProtoConv_GstCantoEthMainTblGeneral[ucBusIdx].pCantoEthMainTbl[LulCenterIdx].ulCantoEthSubTblEntryNum;
        if ((LulCenterStartValue <= LulTargetCanId) && (LulTargetCanId < LulCenterEndValue)) {
            /* Entry found and save index */
            LulEntryIdx = LulCenterIdx;
            LucRetVal = E_OK;
            break;
        } 
        else if (LulCenterStartValue < LulTargetCanId) 
        {
            LulLeftIdx = LulCenterIdx + NUM1; /* adjustment of left(start) key */
        } 
        else
        {
            LulRightIdx = LulCenterIdx - NUM1; /* adjustment of right(end) key */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LpCantoEthSubTbl = ProtoConv_GstCantoEthMainTblGeneral[ucBusIdx].pCantoEthMainTbl[LulEntryIdx].pCantoEthSubTbl;
        LulCantoEthSubTblEntryIdx = LulTargetCanId - LulCenterStartValue;

        LulEthDestTblEntryIdx = LpCantoEthSubTbl[LulCantoEthSubTblEntryIdx].ulDestIdx;
        *pEntryIdx = LulEthDestTblEntryIdx;
        /* Copy from CAN to Ethernet Routing Table Entry to pHeaderField */
        /* To address the warning that it has not been initialized with MISRA-C. */
        pHeaderField->ucIpSetFlag     = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucIpSetFlag;
        pHeaderField->ucIpType        = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucIpType;
        pHeaderField->ucAvtpFormat    = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucAvtpFormat;
        pHeaderField->usDestUdpPort   = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.usDestUdpPort;
        pHeaderField->usVlanId        = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.usVlanId;
        pHeaderField->ucStreamIdValid = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucStreamIdValid;
        pHeaderField->aaStreamId[IDX_0] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaStreamId[IDX_0];
        pHeaderField->aaStreamId[IDX_1] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaStreamId[IDX_1];
        pHeaderField->aaDestIpAddr[IDX_0] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_0];
        pHeaderField->aaDestIpAddr[IDX_1] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_1];
        pHeaderField->aaDestIpAddr[IDX_2] =
           ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_2];
        pHeaderField->aaDestIpAddr[IDX_3] =
           ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_3];
        pHeaderField->enFormatType =
           ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.enFormatType;

        *pTypeFlags = LpCantoEthSubTbl[LulCantoEthSubTblEntryIdx].enTypeFlags;

        if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
        {
            *pPduId = LpCantoEthSubTbl[LulCantoEthSubTblEntryIdx].ulPduId;
        }
        else
        {
            /* If IEEE1722-2016 ACF format is used, PDU ID is not cared. */
            /* Do nothing */
        }
    }
    else
    {
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_033]:[Gen5GW_ProtoConv_UD_12_033]
* Function Name: ProcessBufModeforCan
* Description  : Create Ethernet Frame and Send with Buffer Type or Emergency Type
* Arguments    : ucBusIdx     - Bus Index
*                *pCanFrame   - CAN frame
*                *pTimeStamp  - Time Stamp
*                ucFormatType - Frame Format Type
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType ProcessBufModeforCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame, 
    const R_ProtoConv_TimeStampType *pTimeStamp, const uint8 ucFormatType)
{
    R_ProtoConv_HeaderType LstHeaderField;
    ProtoConv_BufInfoType  LstBufInfo;
    R_ProtoConv_FrameType  LenTypeFlags;
    Std_ReturnType         LucRetVal;
    uint32                 LulDataSize;
    uint32                 LulTimeStampLen;
    uint32                 LulEntryIdx;
    uint32                 LulPduId;
    uint8                  LucFormatType;

    #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
    uint8 LucSID;
    if (ucFormatType == ACF_CAN)
    {
        LucSID = R_PROTOCONV_CANTOETHTS_SID;
    }
    else
    {
        LucSID = R_PROTOCONV_CANTOETH_SID;
    }
    #endif

    LulTimeStampLen = NUM0;
    LucFormatType = ucFormatType;

    LucRetVal = SearchCantoEthRoutTbl(ucBusIdx, pCanFrame, &LulEntryIdx, &LulPduId, &LenTypeFlags, &LstHeaderField);
    if ((uint8)E_OK == LucRetVal)
    {
        if (PROTOCONV_IPDUM_FORMAT == LstHeaderField.enFormatType)
        {
            LucFormatType = IPDUM_FORMAT;
        }
        else
        {
            /* Value is already set by caller */
        }

        ProtoConv_EnterCriticalUserDef();
        LstBufInfo.pTxBufPtr   = ProtoConv_GaaEthTxBuf;
        LstBufInfo.ulTxBufIdx  = ProtoConv_GulEthTxBufIdx;

        if (PROTOCONV_EMERGENCY_FRAME == LenTypeFlags)
        {
            /* When emergency frame, use CAN Rx Buffer */
            LstBufInfo.ulRxBufSize = ProtoConv_GulCanRxBufSize;
            LstBufInfo.ulRxBufLen  = ProtoConv_GulCanRxBufLen;
            LstBufInfo.pRxBufPtr   = ProtoConv_GaaCanRxBuf;

            if (PROTOCONV_IPDUM_FORMAT == LstHeaderField.enFormatType)
            {
                /* IPDU-M format */
                ProtoConv_StorePdutoEthBufData(LulPduId, pCanFrame->ulCanDlc, pCanFrame->pCanData, &LstBufInfo);
            }
            else
            {
                /* ACF format */
                StoreCantoEthBufData(ucBusIdx, ucFormatType, pCanFrame, &LstBufInfo, pTimeStamp);
            }
            /* Update buffer information after storing data */
            ProtoConv_GulCanRxBufLen = LstBufInfo.ulRxBufLen;
            
            LucRetVal = ProtoConv_CreateAndSendEthFrame(LulEntryIdx, &LstBufInfo, &LstHeaderField);
            if ((uint8)E_OK == LucRetVal)
            {
                    /* Do nothing */
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, LucSID, PROTOCONV_E_TRANS);
                #endif
            }
            /* Reset CAN Rx Buffer */
            ProtoConv_GulCanRxBufLen = NUM0;
            /* Reset Ethernet Tx Buffer Index */
            ProtoConv_GulEthTxBufIdx = NUM0;
        }
        else
        {
            /* When normal frame, use Mix Rx Buffer */
            LstBufInfo.ulRxBufSize = ProtoConv_GulMixRxBufSize[LulEntryIdx];
            LstBufInfo.ulRxBufLen  = ProtoConv_GulMixRxBufLen[LulEntryIdx];
            LstBufInfo.pRxBufPtr   = ProtoConv_GaaMixRxBuf[LulEntryIdx];

            /* Get Buffer size if adding the next CAN/CANFD frame */
            if ((uint8)ACF_CAN == LucFormatType)
            {
                /* ACF_CAN format */
                LulDataSize  = LstBufInfo.ulRxBufLen + (uint32)ACF_CAN_MSG_INFO_LEN + pCanFrame->ulCanDlc;
                LulTimeStampLen = (uint32)MSG_TIMESTAMP;
            }
            else if ((uint8)ACF_CAN_BRIEF == LucFormatType)
            {
                /* ACF_CAN_BRIEF format */
                LulDataSize  = LstBufInfo.ulRxBufLen + (uint32)ACF_CAN_BRIEF_MSG_INFO_LEN + pCanFrame->ulCanDlc;
            }
            else
            {
                /* IPDU-M format */
                LulDataSize = LstBufInfo.ulRxBufLen + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC + pCanFrame->ulCanDlc;
            }

            /* Buffer size overflows if adding the next CAN/CANFD frame? */
            if ((uint32)LulDataSize <= LstBufInfo.ulRxBufSize)
            {
                /* Not overflow. Do nothing. */
            }
            else
            {
                /* Send frame in buffer. */
                LucRetVal = ProtoConv_CreateAndSendEthFrame(LulEntryIdx, &LstBufInfo, &LstHeaderField);
                if ((uint8)E_OK == LucRetVal)
                {
                    /* Do nothing */
                }
                else
                {
                    #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, LucSID, PROTOCONV_E_TRANS);
                    #endif
                }
                
                /* Reset Mix Rx Buffer */
                ProtoConv_GulMixRxBufLen[LulEntryIdx] = NUM0;
                ProtoConv_GulMixCount[LulEntryIdx] = NUM0;
                /* Reset Ethernet Tx Buffer Index */
                ProtoConv_GulEthTxBufIdx = NUM0;
            }

            if ((uint8)E_OK == LucRetVal)
            {
                if (PROTOCONV_IPDUM_FORMAT == LstHeaderField.enFormatType)
                {
                    /* IPDU-M format */
                    ProtoConv_StorePdutoEthBufData(LulPduId, pCanFrame->ulCanDlc, pCanFrame->pCanData, &LstBufInfo);
                }
                else
                {
                    /* ACF format */
                    StoreCantoEthBufData(ucBusIdx, ucFormatType, pCanFrame, &LstBufInfo, pTimeStamp);
                }

                /* Update buffer information after storing data */
                ProtoConv_GulMixCount[LulEntryIdx]++;
                ProtoConv_GulMixRxBufLen[LulEntryIdx] = LstBufInfo.ulRxBufLen;
                /*
                 *  The Shortest length ACF format CAN frame is 8 Bytes - ACF_CAN_BRIEF with DLC=0
                 *  The Shortest length IPDU-M format CAN frame is 8 Bytes also - PDU_LEN_ID + PDU_LEN_DLC with DLC=0
                 */
                if (((LstBufInfo.ulRxBufLen + (uint32)NUM8 + LulTimeStampLen) > LstBufInfo.ulRxBufSize)
                ||  (ProtoConv_GulMixCount[LulEntryIdx] >= ProtoConv_GstConvCfg.ulFrameLimit))
                {
                    /* Sending conditions met. Send frame in buffer. */
                    LucRetVal = ProtoConv_CreateAndSendEthFrame(LulEntryIdx, &LstBufInfo, &LstHeaderField);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Do nothing */
                    }
                    else
                    {
                        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, LucSID, PROTOCONV_E_TRANS);
                        #endif
                    }

                    /* Reset Mix Rx Buffer */
                    ProtoConv_GulMixRxBufLen[LulEntryIdx] = NUM0;
                    ProtoConv_GulMixCount[LulEntryIdx] = NUM0;
                    /* Reset Ethernet Tx Buffer Index */
                    ProtoConv_GulEthTxBufIdx = NUM0;
                }
                else
                {
                    /* Do Nothing */
                }
            }
        }
        ProtoConv_ExitCriticalUserDef();
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, LucSID, PROTOCONV_E_MATCH);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_034]:[Gen5GW_ProtoConv_UD_12_034]
* Function Name: StoreCantoEthBufData
* Description  : Store CAN frame to Ethernet Data Buffer.
* Arguments    : ucBusIdx     - Bus Index
*                ucFormatType - Frame Format Type
*                *pCanFrame   - CAN frame
*                *pBufInfo    - Buffer Information
*                *pTimeStamp  - Time Stamp
* Return Value : N/A
*******************************************************************************/
static void StoreCantoEthBufData(const uint8 ucBusIdx, const uint8 ucFormatType, 
                const R_ProtoConv_CanFrameType *pCanFrame, ProtoConv_BufInfoType *pBufInfo,
                const R_ProtoConv_TimeStampType *pTimeStamp)
{
    uint8  *LpBuffPtr;
    uint32  LulDataSize;
    uint32  LulCanId;
    uint32  LulCanDlc;
    uint32  LulRxBufLen;
    uint32  LulCanMessageInfo;
    uint32  LulSecond;
    uint32  LulNanosecond;
    uint16  LusACFLen;
    uint8   LucPad;
    boolean LblMTV;
    boolean LblEFF;
    boolean LblFDF;

    /* Save Local variables for endian change. */
    LulCanDlc    = pCanFrame->ulCanDlc;
    LulRxBufLen  = pBufInfo->ulRxBufLen;
    LpBuffPtr    = &pBufInfo->pRxBufPtr[pBufInfo->ulRxBufLen];

    if ((uint8)ACF_CAN == ucFormatType)
    {
        /* ACF_CAN format */
        LulSecond     = pTimeStamp->ulSecond;
        LulNanosecond = pTimeStamp->ulNanosecond;
        LusACFLen     = (uint16)((ACF_CAN_MSG_INFO_LEN + LulCanDlc + ACF_PAD_SIZE_MAX) / QUADLETS_BYTES);
        LucPad        = (uint8)((LusACFLen * QUADLETS_BYTES) - ACF_CAN_MSG_INFO_LEN);
        LucPad        = (uint8)(LucPad - LulCanDlc);
        LulDataSize   = LulRxBufLen + (uint32)ACF_CAN_MSG_INFO_LEN + LulCanDlc;
        LblMTV = (boolean)NUM1;
    }
    else
    {
        /* ACF_CAN_BRIEF format */
        LusACFLen    = (uint16)((ACF_CAN_BRIEF_MSG_INFO_LEN + LulCanDlc + ACF_PAD_SIZE_MAX) / QUADLETS_BYTES);
        LucPad       = (uint8)((LusACFLen * QUADLETS_BYTES) - ACF_CAN_BRIEF_MSG_INFO_LEN);
        LucPad       = (uint8)(LucPad - LulCanDlc);
        LulDataSize  = LulRxBufLen + (uint32)ACF_CAN_BRIEF_MSG_INFO_LEN + LulCanDlc;
        LblMTV = (boolean)NUM0;
    }

    /* Split FDF and EFF, CAN ID from Input CAN ID */
    LblEFF   = (((pCanFrame->ulCanId >> SHIFT_31BIT) & MASK_1BIT) != NUM0);
    LblFDF   = (((pCanFrame->ulCanId >> SHIFT_30BIT) & MASK_1BIT) != NUM0);
    LulCanId = (pCanFrame->ulCanId & MASK_29BIT);

    LulCanMessageInfo = (((uint32)ucFormatType << SHIFT_25BIT)
                      |  ((uint32)LusACFLen    << SHIFT_16BIT)
                      |  ((uint32)LucPad       << SHIFT_14BIT)
                      |  ((uint32)(LblMTV ? NUM1 : NUM0) << SHIFT_13BIT)
                      |  ((uint32)(LblEFF ? NUM1 : NUM0) << SHIFT_11BIT)
                      |  ((uint32)(LblFDF ? NUM1 : NUM0) << SHIFT_9BIT)
                      |  ((uint32)ucBusIdx));

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(&LulCanId);
    ProtoConv_UtilEndianConv32(&LulCanMessageInfo);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    /* Calculate current position */
    ProtoConv_UtilMemCpy(LpBuffPtr, &LulCanMessageInfo, sizeof(LulCanMessageInfo));
    LpBuffPtr = &LpBuffPtr[sizeof(LulCanMessageInfo)];
    if ((uint8)ACF_CAN == ucFormatType)
    {
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulSecond);
        ProtoConv_UtilEndianConv32(&LulNanosecond);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        ProtoConv_UtilMemCpy(LpBuffPtr, &LulNanosecond, sizeof(LulNanosecond));
        LpBuffPtr = &LpBuffPtr[sizeof(LulNanosecond)];
        ProtoConv_UtilMemCpy(LpBuffPtr, &LulSecond, sizeof(LulSecond));
        LpBuffPtr = &LpBuffPtr[sizeof(LulSecond)];
    }
    else
    {
        /* Do nothing */
    }

    ProtoConv_UtilMemCpy(LpBuffPtr, &LulCanId, CAN_LEN_ID);
    LpBuffPtr = &LpBuffPtr[CAN_LEN_ID];
    ProtoConv_UtilMemCpy(LpBuffPtr, pCanFrame->pCanData, pCanFrame->ulCanDlc);

    /* Check payload for zero-padding to the nearest quadlet boundary */
    if ((uint8)NUM0 < LucPad)
    {
        LpBuffPtr = &LpBuffPtr[pCanFrame->ulCanDlc];
        ProtoConv_UtilMemSet(LpBuffPtr, (uint8)NUM0, (uint32)LucPad);
        LulDataSize += (uint32)LucPad;
    }
    else
    {
        /* Do nothing */
    }

    /* Return the next CAN frame position */
    /* Update current position */
    pBufInfo->ulRxBufLen = LulDataSize;
    pBufInfo->ulRxBufCount++;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
