/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to CAN Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_EthtoX.h"
#include "CDD_ProtoConv_EthtoCan.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
/* Can Packet Send Status */
uint32 GulSendStatus;
uint32 ProtoConv_GulEthtoCanMainTblNum;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
const R_ProtoConv_EthtoCanMainTblType *ProtoConv_GstEthtoCanMainTbl;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
/*******************************************************************************
Private/global variables and functions
*******************************************************************************/

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_008]:[Gen5GW_ProtoConv_UD_13_008]
* Function Name: ProtoConv_SearchCanRoutTbl
* Description  : Search CAN to Ethernet Routing Table.
* Arguments    : *pCanFrame -
*                    CAN frame
*                *pDestBusIdx-
*                    Destination Bus ID
*                *pAddInfo -
*                    Additional Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_SearchCanRoutTbl(const R_ProtoConv_CanFrameType *pCanFrame,
   uint8 *pDestBusIdx, uint32 *pAddInfo)
{
    const R_ProtoConv_EthtoXSubTblType *LpEthtoCanSubTbl;
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulLeftIdx; /* start key of index */
    uint32 LulRightIdx; /* end key of index */
    uint32 LulCenterIdx; /* middle key of index */
    uint32 LulTargetCanId; /* search value */
    uint32 LulCenterStartValue; /* table in middle value */
    uint32 LulCenterEndValue; /* table in middle value */
    uint32 LulEthtoCanSubTblEntryIdx;

    LulEntryIdx = IDX_0;
    LulLeftIdx = IDX_0;
    LulRightIdx = ProtoConv_GulEthtoCanMainTblNum;
    LulTargetCanId = pCanFrame->ulCanId;

    LucRetVal = E_NOT_OK;

    /* Binary search */
    while(LulLeftIdx <= LulRightIdx) {
        LulCenterIdx = (LulLeftIdx + LulRightIdx) / NUM2; /* calc of middle key */
        LulCenterStartValue = ProtoConv_GstEthtoCanMainTbl[LulCenterIdx].ulCanId;
        LulCenterEndValue = LulCenterStartValue + ProtoConv_GstEthtoCanMainTbl[LulCenterIdx].ulEthtoCanSubTblEntryNum;
        if ((LulCenterStartValue <= LulTargetCanId) && (LulTargetCanId < LulCenterEndValue)) {
            /* Entry found and save index */
            LulEntryIdx = LulCenterIdx;
            LucRetVal = E_OK;
            break;
        } else if (LulCenterStartValue < LulTargetCanId) {
            LulLeftIdx = LulCenterIdx + NUM1; /* adjustment of left(start) key */
        } else {
            LulRightIdx = LulCenterIdx - NUM1; /* adjustment of right(end) key */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LpEthtoCanSubTbl = ProtoConv_GstEthtoCanMainTbl[LulEntryIdx].pEthtoCanSubTbl;
        LulEthtoCanSubTblEntryIdx = LulTargetCanId - LulCenterStartValue;

        /* Copy Destination Bus ID and Additional Information */
        *pDestBusIdx = LpEthtoCanSubTbl[LulEthtoCanSubTblEntryIdx].ucDestBusIdx;
        *pAddInfo    = LpEthtoCanSubTbl[LulEthtoCanSubTblEntryIdx].ulAddInfo;
    }
    else
    {
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_009]:[Gen5GW_ProtoConv_UD_13_009]
* Function Name: ProtoConv_UnpackCan
* Description  : Unpack the CAN frame in ACF format from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pCanFrame -
*                    Unpacked CAN frame
*                 *pCanMsgInfo -
*                    CAN Message Information
*                 *pErrorStatus -
*                    Error status of transmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_UnpackCan(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_CanFrameType *pCanFrame, ProtoConv_CanMsgInfoType *pCanMsgInfo, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint32 LulCanId;
    uint32 LulDlc;
    uint32 LulCanMessageInfo;
    uint32 LulSecond;
    uint32 LulNanosecond;
    uint32 LulTimeStampLen;
    uint8  LucFormatType;

    LucRetVal = E_OK;

    LulFramePos     = *pDataPosition;
    LulSecond       = NUM0;
    LulNanosecond   = NUM0;
    LulTimeStampLen = NUM0;

    /* Retrieve the CAN message info */
    ProtoConv_UtilMemCpy(&LulCanMessageInfo, &pPayload[LulFramePos], sizeof(LulCanMessageInfo));
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(&LulCanMessageInfo);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    /* Retrieve ACF Format Type */
    LucFormatType = (uint8)((LulCanMessageInfo >> (uint32)SHIFT_25BIT));
    if ((uint8)ACF_CAN == LucFormatType)
    {
        LulTimeStampLen = (uint32)MSG_TIMESTAMP;
    }
    else
    {
        /* Do nothing */
    }

    /* Unpack one CAN frame from the payload */
    if (ulPayloadLen >= (LulFramePos + (uint32)ACF_CAN_BRIEF_MSG_INFO_LEN + LulTimeStampLen))
    {
        LulFramePos += sizeof(LulCanMessageInfo);
        if ((uint8)ACF_CAN == LucFormatType)
        {
            ProtoConv_UtilMemCpy(&(LulNanosecond), &pPayload[LulFramePos], sizeof(LulNanosecond));
            LulFramePos += sizeof(LulNanosecond);
            ProtoConv_UtilMemCpy(&(LulSecond), &pPayload[LulFramePos], sizeof(LulSecond));
            LulFramePos += sizeof(LulSecond);
        }
        else
        {
            /* CAN frame is Abbreviated ACF CAN/CAN FD. TimeStamp is unavailable. Do nothing*/
        }

        ProtoConv_UtilMemCpy(&LulCanId, &pPayload[LulFramePos], sizeof(LulCanId));
        LulFramePos += (uint32)CAN_LEN_ID;

        /* Endian conversion : Nanosecond, Second, CAN ID */
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulNanosecond);
        ProtoConv_UtilEndianConv32(&LulSecond);
        ProtoConv_UtilEndianConv32(&LulCanId);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        pCanMsgInfo->ucFormatType = (uint8)  ((LulCanMessageInfo >> SHIFT_25BIT));
        pCanMsgInfo->usACFLength  = (uint16) ((LulCanMessageInfo >> SHIFT_16BIT) & MASK_9BIT);
        pCanMsgInfo->ucPad        = (uint8)  ((LulCanMessageInfo >> SHIFT_14BIT) & MASK_2BIT);
        pCanMsgInfo->blMtv        = (((LulCanMessageInfo >> SHIFT_13BIT) & MASK_1BIT) != NUM0);
        pCanMsgInfo->blEFF        = (((LulCanMessageInfo >> SHIFT_11BIT) & MASK_1BIT) != NUM0);
        pCanMsgInfo->blFDF        = (((LulCanMessageInfo >> SHIFT_9BIT)  & MASK_1BIT) != NUM0);
        pCanMsgInfo->ucSrcBusIdx  = (uint8)(LulCanMessageInfo & (uint32)MASK_5BIT);
        /* Calculate DLC*/ 
        LulDlc = (uint32)(((uint32)pCanMsgInfo->usACFLength * QUADLETS_BYTES) - ACF_CAN_BRIEF_MSG_INFO_LEN);
        LulDlc = LulDlc - LulTimeStampLen - (uint32)pCanMsgInfo->ucPad;

        if ((LulDlc <= (uint32)CANFRAME_LEN_MAX) &&
            ((LulFramePos + LulDlc) <= ulPayloadLen))
        {
            /* Copy CAN data to Tx buffer */
            ProtoConv_UtilMemCpy(&ProtoConv_GaaCanTxBuf[IDX_0], &pPayload[LulFramePos], LulDlc);
            /* Set CAN frame data */
            pCanFrame->ulCanId  = LulCanId
                                | ((uint32)(pCanMsgInfo->blEFF ? NUM1 : NUM0) << SHIFT_31BIT)
                                | ((uint32)(pCanMsgInfo->blFDF ? NUM1 : NUM0) << SHIFT_30BIT);
            pCanFrame->ulCanDlc = LulDlc;
            pCanFrame->pCanData = &ProtoConv_GaaCanTxBuf[IDX_0];
            /* Set Timestamp data */
            pCanMsgInfo->ulSecond     = LulSecond;
            pCanMsgInfo->ulNanosecond = LulNanosecond;

            /* Return the next CAN frame position */
            *pDataPosition = LulFramePos + LulDlc;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDCAN);
            #endif            
            /* Invalid CAN DLC */
            *pErrorStatus = PROTOCONV_E_PACKEDCAN;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No CAN frame if the data length from the unpacked position is
         * less than the size of the CAN ID and DLC.
         */
        *pErrorStatus = PROTOCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_010]:[Gen5GW_ProtoConv_UD_13_010]
* Function Name: ProtoConv_UnpackCanIPDUM
* Description  : Unpack the CAN frame in IPDU-M format from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pCanFrame -
*                    Unpacked CAN frame
*                 *pErrorStatus -
*                    Status of CAN packet transmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_UnpackCanIPDUM(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_CanFrameType *pCanFrame, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint32 LulDlc;

    LucRetVal = E_OK;

    /* Unpack one CAN frame from the payload */
    LulFramePos = *pDataPosition;
    if (ulPayloadLen >= (LulFramePos + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC))
    {
        /* Retrieve the CAN DLC (right after PDU ID in Eth Payload) */
        LulFramePos += (uint32)PDU_LEN_ID;
        /* CAN frame DLC fits into 1 Byte size. Read 1 Byte only */
        LulDlc = pPayload[LulFramePos + IDX_3];
        LulFramePos += (uint32)PDU_LEN_DLC;

        if ((LulDlc <= (uint32)CANFRAME_LEN_MAX) &&
            ((LulFramePos + LulDlc) <= ulPayloadLen))
        {
            /* Copy CAN data to Tx buffer */
            ProtoConv_UtilMemCpy(&ProtoConv_GaaCanTxBuf[IDX_0], &pPayload[LulFramePos], LulDlc);
            /* Set CAN frame data */
            /* CAN ID is already set by caller */
            pCanFrame->ulCanDlc = LulDlc;
            pCanFrame->pCanData = &ProtoConv_GaaCanTxBuf[IDX_0];

            /* Return the next frame position */
            *pDataPosition = LulFramePos + LulDlc;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDCAN);
            #endif            
            /* Invalid CAN DLC */
            *pErrorStatus = PROTOCONV_E_PACKEDCAN;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No CAN frame if the data length from the unpacked position is
         * less than the size of the CAN ID and DLC.
         */
        *pErrorStatus = PROTOCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_003]:[Gen5GW_ProtoConv_UD_13_003]
* Function Name: ProtoConv_GetSendStatus
* Description  : Get transmission suppression information.
* Arguments    : *pStatus -
*                    Transmission suppression information
* Return Value : N/A
*******************************************************************************/
void ProtoConv_GetSendStatus(uint32 *pStatus)
{
    *pStatus = GulSendStatus;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_004]:[Gen5GW_ProtoConv_UD_13_004]
* Function Name: ProtoConv_UpdateSendStatus
* Description  : Update transmission suppression information.
* Arguments    : ulStatus -
*                    Transmission suppression information
* Return Value : N/A
*******************************************************************************/
void ProtoConv_UpdateSendStatus(const uint32 ulStatus)
{
    GulSendStatus = ulStatus;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
