/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the API function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_api.h"
#include "CDD_ProtoConv_init.h"
#include "CDD_ProtoConv_CantoEth.h"
#include "CDD_ProtoConv_LintoEth.h"
#include "CDD_ProtoConv_PorttoEth.h"
#include "CDD_ProtoConv_XtoEth.h"
#include "CDD_ProtoConv_EthtoX.h"
#include "CDD_ProtoConv_EthtoCan.h"
#include "CDD_ProtoConv_Fifo.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define PROTOCONV_STS_UNINIT   0U
#define PROTOCONV_STS_INIT     1U

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_INIT_8
#include "ProtoConv_MemMap.h"

uint8 ProtoConv_GucInitStatus = PROTOCONV_STS_UNINIT;

#define PROTOCONV_STOP_SEC_VAR_INIT_8
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_001]:[Gen5GW_ProtoConv_UD_10_001]
* Function Name: R_ProtoConv_Init
* Description  : Protocol Conversion SW Initialization API.
* Arguments    : pConfig -
*                    Initialization Configuration.
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_Init(const R_ProtoConv_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)PROTOCONV_STS_UNINIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pConfig)
        {
            /* Do nothing */
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_INIT_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_INIT_SID,
                              PROTOCONV_E_ALREADY_INITIALIZED);
        #endif         
        /* Already initialized */
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        ProtoConv_Init(pConfig);
        ProtoConv_GucInitStatus = PROTOCONV_STS_INIT;
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_002]:[Gen5GW_ProtoConv_UD_10_002]
* Function Name: R_ProtoConv_CantoEthTS
* Description  : Can with TimeStamp to Ethernet Conversion Function API
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
*                *pTimeStamp - Time Stamp
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_CantoEthTS(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
    const R_ProtoConv_TimeStampType *pTimeStamp)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if ((NULL_PTR != pCanFrame) &&
            (NULL_PTR != pTimeStamp))
        {
            if ((uint8)PROTOCONV_CAN_CH_NUM > ucBusIdx)
            {
                LucRetVal = ProtoConv_CantoEthTS(ucBusIdx, pCanFrame, pTimeStamp);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETHTS_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETHTS_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETHTS_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_003]:[Gen5GW_ProtoConv_UD_10_003]
* Function Name: R_ProtoConv_CantoEth
* Description  : Can to Ethernet Conversion Function API
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_CantoEth(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pCanFrame)
        {
            if ((uint8)PROTOCONV_CAN_CH_NUM > ucBusIdx)
            {
                LucRetVal = ProtoConv_CantoEth(ucBusIdx, pCanFrame);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETH_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETH_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_CANTOETH_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_004]:[Gen5GW_ProtoConv_UD_10_004]
* Function Name: R_ProtoConv_LintoEth
* Description  : Lin to Ethernet Conversion Function API
* Arguments    : ucBusIdx    - Bus Index
*                *pLinFrame  - LIN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_LintoEth(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pLinFrame)
        {
            if ((uint8)PROTOCONV_LIN_CH_NUM > ucBusIdx)
            {
                LucRetVal = ProtoConv_LintoEth(ucBusIdx, pLinFrame);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_005]:[Gen5GW_ProtoConv_UD_10_005]
* Function Name: R_ProtoConv_PorttoEth
* Description  : Port to Ethernet Conversion Function API
* Arguments    : usLength    - Port Data length
*                *pPortData  - Port Data
*                ulDestIdx   - Destination Index
*                enTypeFlags - Frame Type Flag
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_PorttoEth(const uint16 usLength, const uint8 *pPortData, const uint32 ulDestIdx,
   const R_ProtoConv_FrameType enTypeFlags)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pPortData)
        {
            if (((uint16)MIN_PORT_TOTAL_SIZE <= usLength)
            &&  ((uint16)MAX_PORT_TOTAL_SIZE >= usLength)
            &&  ((uint32)XTOETH_DEST_TABLE_ENTRY_NUM > ulDestIdx))
            {
                LucRetVal = ProtoConv_PorttoEth(usLength, pPortData, ulDestIdx, enTypeFlags);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_PORTTOETH_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_006]:[Gen5GW_ProtoConv_UD_10_006]
* Function Name: R_ProtoConv_TriggerXtoEthTx
* Description  : Trigger X to Ethernet Transmit.
* Arguments    : ulBufIdx -
*                    Target Buffer index
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_TriggerXtoEthTx(const uint32 ulBufIdx)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        LucRetVal = ProtoConv_TriggerXtoEthTx(ulBufIdx);
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_TRIGGERXTOETHTX_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_007]:[Gen5GW_ProtoConv_UD_10_007]
* Function Name: R_ProtoConv_MainFunction
* Description  : Main Function for polling API
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
void R_ProtoConv_MainFunction(void)
{
    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        ProtoConv_MixtoEthMain();
    }
    else
    {
        /* Do Nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_008]:[Gen5GW_ProtoConv_UD_10_008]
* Function Name: R_ProtoConv_EthtoX
* Description  : Ethernet to CAN/LIN/Port Conversion Function
* Arguments    : usFrameType -
*                    Ethernet frame type
*                *aaSrcMacAddr -
*                    Ethernet source MacAddress
*                *pEthFrame -
*                    Ethernet frame
*                ulFrameLen -
*                    Ethernet frame length
*                *pSendStatus -
*                    Packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_EthtoX(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
                             const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if ((NULL_PTR != pEthFrame) && (NULL_PTR != aaSrcMacAddr) && (NULL_PTR != pSendStatus))
        {
            LucRetVal = ProtoConv_EthtoX(usFrameType, aaSrcMacAddr, pEthFrame, ulFrameLen, pSendStatus);
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_009]:[Gen5GW_ProtoConv_UD_10_009]
* Function Name: R_ProtoConv_GetSendStatus
* Description  : Get transmission suppression information.
* Arguments    : *pStatus -
*                    Transmission suppression information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_GetSendStatus(uint32 *pStatus)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pStatus)
        {
            ProtoConv_GetSendStatus(pStatus);
            LucRetVal = E_OK;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_GETSENDSTATUS_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_GETSENDSTATUS_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_010]:[Gen5GW_ProtoConv_UD_10_010]
* Function Name: R_ProtoConv_UpdateSendStatus
* Description  : Update transmission suppression information.
* Arguments    : ulStatus -
*                    Transmission suppression information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_UpdateSendStatus(const uint32 ulStatus)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if ((uint32)PACKETSEND_DEFAULT >= ulStatus)
        {
            ProtoConv_UpdateSendStatus(ulStatus);
            LucRetVal = E_OK;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_UPDATESENDSTATUS_SID,
                                  PROTOCONV_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_UPDATESENDSTATUS_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_011]:[Gen5GW_ProtoConv_UD_10_011]
* Function Name: R_ProtoConv_EnqueueCan
* Description  : Enqueue CAN frame into FIFO
* Arguments    : ucBusIdx    - Bus Index
*                *pCanFrame  - CAN frame
*                *pTimeStamp - Time Stamp
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_EnqueueCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
   const R_ProtoConv_TimeStampType *pTimeStamp)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if ((NULL_PTR != pCanFrame) &&
            (NULL_PTR != pTimeStamp))
        {
            if ((uint8)PROTOCONV_CAN_CH_NUM > ucBusIdx)
            {
                LucRetVal = ProtoConv_EnqueueCan(ucBusIdx, pCanFrame, pTimeStamp);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUECAN_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUECAN_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUECAN_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_012]:[Gen5GW_ProtoConv_UD_10_012]
* Function Name: R_ProtoConv_EnqueueLin
* Description  : Enqueue LIN frame into FIFO
* Arguments    : ucBusIdx    - Bus Index
*                *pLinFrame  - LIN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_EnqueueLin(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pLinFrame)
        {
            if ((uint8)PROTOCONV_LIN_CH_NUM > ucBusIdx)
            {
                LucRetVal = ProtoConv_EnqueueLin(ucBusIdx, pLinFrame);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUELIN_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUELIN_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUELIN_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_013]:[Gen5GW_ProtoConv_UD_10_013]
* Function Name: R_ProtoConv_EnqueuePort
* Description  : Enqueue Port frame into FIFO
* Arguments    : usLength    - Port Data length
*                *pPortData  - Port Data
*                ulDestIdx   - Destination Index
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_EnqueuePort(const uint16 usLength, const uint8 *pPortData, const uint32 ulDestIdx)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if (NULL_PTR != pPortData)
        {
            if (((uint16)MIN_PORT_TOTAL_SIZE <= usLength) &&
                ((uint16)MAX_PORT_TOTAL_SIZE >= usLength) &&
                ((uint32)XTOETH_DEST_TABLE_ENTRY_NUM > ulDestIdx))
            {
                LucRetVal = ProtoConv_EnqueuePort(usLength, pPortData, ulDestIdx);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEPORT_SID,
                                      PROTOCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEPORT_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEPORT_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_014]:[Gen5GW_ProtoConv_UD_10_014]
* Function Name: R_ProtoConv_EnqueueEth
* Description  : Enqueue Ethernet frame into FIFO
* Arguments    : usFrameType -
*                    Ethernet frame type
*                *aaSrcMacAddr -
*                    Ethernet source Mac Address
*                *pEthFrame -
*                    Ethernet frame
*                ulFrameLen -
*                    Ethernet frame length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_EnqueueEth(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
                                      const uint8 *pEthFrame, const uint32 ulFrameLen)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if ((NULL_PTR != aaSrcMacAddr) &&
            (NULL_PTR != pEthFrame))
        {
            if((ulFrameLen >= ETH_FRAME_PAYLOAD_SIZE_MIN) &&
               (ulFrameLen <= ProtoConv_GulEthRxBufSize))
            {
                LucRetVal = ProtoConv_EnqueueEth(usFrameType, aaSrcMacAddr, pEthFrame, ulFrameLen);
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEETH_SID,
                                      PROTOCONV_E_PARAM_DATA_LENGTH);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEETH_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ENQUEUEETH_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_015]:[Gen5GW_ProtoConv_UD_10_015]
* Function Name: R_ProtoConv_DequeueEth
* Description  : Dequeue Ethernet frame from FIFO
* Arguments    : *pFrameType -
*                    Ethernet frame type
*                **aaSrcMacAddr -
*                    Ethernet source Mac Address
*                **pEthFrame -
*                    Ethernet frame
*                *pFrameLen -
*                    Ethernet frame length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_DequeueEth(uint16 *pFrameType, uint8 **aaSrcMacAddr, uint8 **pEthFrame, uint32 *pFrameLen)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        if ((NULL_PTR != pFrameType) &&
            (NULL_PTR != aaSrcMacAddr) &&
            (NULL_PTR != pEthFrame) &&
            (NULL_PTR != pFrameLen))
        {
            LucRetVal = ProtoConv_DequeueEth(pFrameType, aaSrcMacAddr, pEthFrame, pFrameLen);
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_DEQUEUEETH_SID,
                                  PROTOCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_DEQUEUEETH_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_10_016]:[Gen5GW_ProtoConv_UD_10_016]
* Function Name: R_ProtoConv_TriggerQueueDataXtoEth
* Description  : Convert the queued CAN/LIN/Port frame and send Ethernet frame
* Arguments    : -
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType R_ProtoConv_TriggerQueueDataXtoEth(void)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)PROTOCONV_STS_INIT == (uint32)ProtoConv_GucInitStatus)
    {
        LucRetVal = ProtoConv_TriggerQueueDataXtoEth();
        if (E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            /* 1 or more called functions return E_NOT_OK */
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_TRIGGERQUEUEDATAXTOETH_SID,
                              PROTOCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
