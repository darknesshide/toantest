/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the LIN to Ethernet Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_XtoEth.h"
#include "CDD_ProtoConv_LintoEth.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_interface.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/* Private functions for Lin to Ethernet Conversion */
static Std_ReturnType ProcessBufModeforLin(const uint8 ucBusIdx, const uint32 ulPduId,
                const R_ProtoConv_LinFrameType *pLinFrame, const uint32 ulEntryIdx, 
                const R_ProtoConv_HeaderType *pHeaderField);

static Std_ReturnType SendSingleLin(const uint8 ucBusIdx, const uint32 ulPduId,
                const R_ProtoConv_LinFrameType *pLinFrame, const uint32 ulEntryIdx,
                const R_ProtoConv_HeaderType *pHeaderField);

static Std_ReturnType SearchLintoEthRoutTbl(const uint8 ucBusIdx,
                const R_ProtoConv_LinFrameType *pLinFrame, uint32 *pEntryIdx, uint32 *pPduId,
                R_ProtoConv_FrameType *pTypeFlags, R_ProtoConv_HeaderType *pHeaderField);

static void StoreLintoEthBufData(const uint8 ucBusIdx,
                const R_ProtoConv_LinFrameType *pLinFrame, ProtoConv_BufInfoType *pBufInfo);

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_004]:[Gen5GW_ProtoConv_UD_12_004]
* Function Name: ProtoConv_LintoEth
* Description  : Lin to Ethernet Conversion Function
* Arguments    : ucBusIdx    - Bus Index
*                *pLinFrame  - LIN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_LintoEth(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame)
{
    R_ProtoConv_HeaderType  LstHeaderField;
    R_ProtoConv_FrameType   LenTypeFlags;
    uint32                  LulEntryIdx;
    uint32                  LulPduId;
    Std_ReturnType          LucRetVal;

    LucRetVal = E_OK;

    /* Check LIN-ID & LIN-DLC */
    if (((uint8)LINID_MAX >= pLinFrame->ucPId)
    &&  ((uint8)LINFRAME_LEN_MAX >= pLinFrame->ucDlc))
    {
        /* Do Nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID,
                              PROTOCONV_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = SearchLintoEthRoutTbl(ucBusIdx, pLinFrame, &LulEntryIdx, &LulPduId, &LenTypeFlags, &LstHeaderField);
    }
    else
    {
        /* Do Nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Check Conversion Mode */
        switch (ProtoConv_GstConvCfg.enConvMode)
        {
        case PROTOCONV_BASICMODE:
            LucRetVal = SendSingleLin(ucBusIdx, LulPduId, pLinFrame, LulEntryIdx, &LstHeaderField);
            break;
        case PROTOCONV_BUFFERMODE:
            if (PROTOCONV_EMERGENCY_FRAME == LenTypeFlags)
            {
                LucRetVal = SendSingleLin(ucBusIdx, LulPduId, pLinFrame, LulEntryIdx, &LstHeaderField);
            }
            else
            {
                LucRetVal = ProcessBufModeforLin(ucBusIdx, LulPduId, pLinFrame, LulEntryIdx, &LstHeaderField);
            }
            break;
        default:
            /* Do nothing */
            LucRetVal = E_OK;
            break;
        }
    }
    else
    {
        /*Do nothing */
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_035]:[Gen5GW_ProtoConv_UD_12_035]
* Function Name: SendSingleLin
* Description  : Convert one single LIN frame and send Ethernet frame
* Arguments    : ucBusIdx      - Bus Index
*                ulPduId       - PDU ID
*                *pLinFrame    - LIN frame
*                ulEntryIdx    - Route Table Index
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendSingleLin(const uint8 ucBusIdx, const uint32 ulPduId,
                const R_ProtoConv_LinFrameType *pLinFrame, const uint32 ulEntryIdx,
                const R_ProtoConv_HeaderType *pHeaderField)
{
    ProtoConv_BufInfoType LstBufInfo;
    Std_ReturnType LucRetVal;

    ProtoConv_EnterCriticalUserDef();

    LstBufInfo.pTxBufPtr   = ProtoConv_GaaEthTxBuf;
    LstBufInfo.ulTxBufIdx  = ProtoConv_GulEthTxBufIdx;
    LstBufInfo.ulRxBufSize = ProtoConv_GulLinRxBufSize;
    LstBufInfo.ulRxBufLen  = ProtoConv_GulLinRxBufLen;
    LstBufInfo.pRxBufPtr   = ProtoConv_GaaLinRxBuf;

    if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
    {
        ProtoConv_StorePdutoEthBufData(ulPduId, pLinFrame->ucDlc, pLinFrame->pData, &LstBufInfo);
    }
    else
    {
        StoreLintoEthBufData(ucBusIdx, pLinFrame, &LstBufInfo);
    }

    /* Update buffer information after storing data */
    ProtoConv_GulLinRxBufLen = LstBufInfo.ulRxBufLen;
        
    LucRetVal = ProtoConv_CreateAndSendEthFrame(ulEntryIdx, &LstBufInfo, pHeaderField);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID, PROTOCONV_E_TRANS);
        #endif
    }
    /* Reset LIN Rx Buffer */
    ProtoConv_GulLinRxBufLen = NUM0;
    /* Reset Ethernet Tx Buffer Index */
    ProtoConv_GulEthTxBufIdx = NUM0;

    ProtoConv_ExitCriticalUserDef();

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_036]:[Gen5GW_ProtoConv_UD_12_036]
* Function Name: SearchLintoEthRoutTbl
* Description  : Search LIN to Ethernet Routing Table.
* Arguments    : ucBusIdx      - Bus Index
*                *pLinFrame    - LIN frame
*                *pEntryIdx    - Route Table Index
*                *pPduId       - PDU ID
*                *pTypeFlags   - Frame Type Format
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SearchLintoEthRoutTbl(const uint8 ucBusIdx,
                const R_ProtoConv_LinFrameType *pLinFrame, uint32 *pEntryIdx, uint32 *pPduId,
                R_ProtoConv_FrameType *pTypeFlags, R_ProtoConv_HeaderType *pHeaderField)
{
    const R_ProtoConv_LintoEthSubTblType *LpLintoEthSubTbl;
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulLeftIdx; /* start key of index */
    uint32 LulRightIdx; /* end key of index */
    uint32 LulCenterIdx; /* middle key of index */
    uint32 LulTargetLinId; /* search value */
    uint32 LulCenterStartValue; /* table in middle value */
    uint32 LulCenterEndValue; /* table in middle value */
    uint32 LulLintoEthSubTblEntryIdx;
    uint32 LulEthDestTblEntryIdx;

    LulEntryIdx = IDX_0;
    LulLeftIdx = IDX_0;
    LulRightIdx = ProtoConv_GstLintoEthMainTblGeneral[ucBusIdx].ulLintoEthMainTblEntryNum;
    LulTargetLinId = (uint32)pLinFrame->ucPId;
    LucRetVal = E_NOT_OK;

    /* Binary search */
    while(LulLeftIdx <= LulRightIdx) {
        LulCenterIdx = (LulLeftIdx + LulRightIdx) / NUM2; /* calc of middle key */
        LulCenterStartValue =
                (uint32)ProtoConv_GstLintoEthMainTblGeneral[ucBusIdx].pLintoEthMainTbl[LulCenterIdx].ucPId;
        LulCenterEndValue = LulCenterStartValue +
                ProtoConv_GstLintoEthMainTblGeneral[ucBusIdx].pLintoEthMainTbl[LulCenterIdx].ulLintoEthSubTblEntryNum;
        if ((LulCenterStartValue <= LulTargetLinId) && (LulTargetLinId < LulCenterEndValue)) {
            /* Entry found and save index */
            LulEntryIdx = LulCenterIdx;
            LucRetVal = E_OK;
            break;
        } else if (LulCenterStartValue < LulTargetLinId) {
            LulLeftIdx = LulCenterIdx + NUM1; /* adjustment of left(start) key */
        } else {
            LulRightIdx = LulCenterIdx - NUM1; /* adjustment of right(end) key */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LpLintoEthSubTbl = ProtoConv_GstLintoEthMainTblGeneral[ucBusIdx].pLintoEthMainTbl[LulEntryIdx].pLintoEthSubTbl;
        LulLintoEthSubTblEntryIdx = LulTargetLinId - LulCenterStartValue;

        LulEthDestTblEntryIdx = LpLintoEthSubTbl[LulLintoEthSubTblEntryIdx].ulDestIdx;
        *pEntryIdx = LulEthDestTblEntryIdx;
        /* Copy from LIN to Ethernet Routing Table Entry to pHeaderField */
        /* To address the warning that it has not been initialized with MISRA-C. */
        pHeaderField->ucIpSetFlag     = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucIpSetFlag;
        pHeaderField->ucIpType        = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucIpType;
        pHeaderField->ucAvtpFormat    = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucAvtpFormat;
        pHeaderField->usDestUdpPort   = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.usDestUdpPort;
        pHeaderField->usVlanId        = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.usVlanId;
        pHeaderField->ucStreamIdValid = ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.ucStreamIdValid;
        pHeaderField->aaStreamId[IDX_0] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaStreamId[IDX_0];
        pHeaderField->aaStreamId[IDX_1] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaStreamId[IDX_1];
        pHeaderField->aaDestIpAddr[IDX_0] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_0];
        pHeaderField->aaDestIpAddr[IDX_1] =
            ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_1];
        pHeaderField->aaDestIpAddr[IDX_2] =
           ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_2];
        pHeaderField->aaDestIpAddr[IDX_3] =
           ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.aaDestIpAddr[IDX_3];
        pHeaderField->enFormatType =
           ProtoConv_GstXtoEthDestRoutTbl[LulEthDestTblEntryIdx].stHeader.enFormatType;

        *pTypeFlags = LpLintoEthSubTbl[LulLintoEthSubTblEntryIdx].enTypeFlags;

        if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
        {
            *pPduId = LpLintoEthSubTbl[LulLintoEthSubTblEntryIdx].ulPduId;
        }
        else
        {
            /* If IEEE1722-2016 ACF format is used, PDU ID is not cared. */
            /* Do nothing */
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID, PROTOCONV_E_MATCH);
        #endif
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_037]:[Gen5GW_ProtoConv_UD_12_037]
* Function Name: ProcessBufModeforLin
* Description  : Create Ethernet Frame and Send with Buffer Type
* Arguments    : ucBusIdx      - Bus Index
*                ulPduId       - PDU ID
*                *pLinFrame    - LIN frame
*                ulEntryIdx    - Route Table Index
*                *pHeaderField - IP/UDP/AVTP header
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType ProcessBufModeforLin(const uint8 ucBusIdx, const uint32 ulPduId,
                const R_ProtoConv_LinFrameType *pLinFrame, const uint32 ulEntryIdx, 
                const R_ProtoConv_HeaderType *pHeaderField)
{
    ProtoConv_BufInfoType LstBufInfo;
    uint32 LulDataSize;
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    ProtoConv_EnterCriticalUserDef();

    LstBufInfo.pTxBufPtr   = ProtoConv_GaaEthTxBuf;
    LstBufInfo.ulTxBufIdx  = ProtoConv_GulEthTxBufIdx;
    LstBufInfo.ulRxBufSize = ProtoConv_GulMixRxBufSize[ulEntryIdx];
    LstBufInfo.ulRxBufLen  = ProtoConv_GulMixRxBufLen[ulEntryIdx];
    LstBufInfo.pRxBufPtr   = ProtoConv_GaaMixRxBuf[ulEntryIdx];

    /* Check Receive Data Size. */
    if ((uint32)NUM0 != LstBufInfo.ulRxBufLen)
    {
        /* Get Buffer size if adding the next LIN frame */
        if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
        {
            /* IPDU-M format */
            LulDataSize = LstBufInfo.ulRxBufLen + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC + (uint32)pLinFrame->ucDlc;
        }
        else
        {
            /* ACF LIN format */
            LulDataSize  = LstBufInfo.ulRxBufLen + (uint32)ACF_LIN_MSG_INFO_LEN + (uint32)pLinFrame->ucDlc;
        }

        /* Check if buffer size overflows if adding the next LIN frame */
        if ((uint32)LulDataSize <= LstBufInfo.ulRxBufSize)
        {
            /* Not overflow. Do nothing. */
        }
        else
        {
            /* Send frame in buffer. */
            LucRetVal = ProtoConv_CreateAndSendEthFrame(ulEntryIdx, &LstBufInfo, pHeaderField);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID,
                                      PROTOCONV_E_TRANS);
                #endif
            }
            /* Reset Mix Rx Buffer */
            ProtoConv_GulMixRxBufLen[ulEntryIdx] = NUM0;
            ProtoConv_GulMixCount[ulEntryIdx] = NUM0;
            /* Reset Ethernet Tx Buffer Index */
            ProtoConv_GulEthTxBufIdx = NUM0;
        }
    }
    else
    {
        /* Do Nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if (PROTOCONV_IPDUM_FORMAT == pHeaderField->enFormatType)
        {
            /* IPDU-M format */
            ProtoConv_StorePdutoEthBufData(ulPduId, pLinFrame->ucDlc, pLinFrame->pData, &LstBufInfo);
        }
        else
        {
            /* ACF LIN format */
            StoreLintoEthBufData(ucBusIdx, pLinFrame, &LstBufInfo);
        }

        /* Update buffer information after storing data */
        ProtoConv_GulMixCount[ulEntryIdx]++;
        ProtoConv_GulMixRxBufLen[ulEntryIdx] = LstBufInfo.ulRxBufLen;

        if (((LstBufInfo.ulRxBufLen + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC) > LstBufInfo.ulRxBufSize)
        ||  (ProtoConv_GulMixCount[ulEntryIdx] >= ProtoConv_GstConvCfg.ulFrameLimit))
        {
            /* Sending conditions met. Send frame in buffer. */
            LucRetVal = ProtoConv_CreateAndSendEthFrame(ulEntryIdx, &LstBufInfo, pHeaderField);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_LINTOETH_SID,
                                     PROTOCONV_E_TRANS);
                #endif
            }
            /* Reset Mix Rx Buffer */
            ProtoConv_GulMixRxBufLen[ulEntryIdx] = NUM0;
            ProtoConv_GulMixCount[ulEntryIdx] = NUM0;
            /* Reset Ethernet Tx Buffer Index */
            ProtoConv_GulEthTxBufIdx = NUM0;
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }

    ProtoConv_ExitCriticalUserDef();

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_12_038]:[Gen5GW_ProtoConv_UD_12_038]
* Function Name: StoreLintoEthBufData
* Description  : Store LIN frame to Ethernet Data Buffer.
* Arguments    : ucBusIdx     - Bus Index
*                *pLinFrame   - LIN frame
*                *pBufInfo    - Buffer Information
* Return Value : N/A
*******************************************************************************/
static void StoreLintoEthBufData(const uint8 ucBusIdx,
                const R_ProtoConv_LinFrameType *pLinFrame, ProtoConv_BufInfoType *pBufInfo)
{
    uint8   *LpBuffPtr;
    uint32   LulDataSize;
    uint32   LulRxBufLen;
    uint32   LulLinMessageInfo;
    uint16   LusACFLen;
    uint8    LucPad;
    uint8    LucPId;
    uint8    LucDlc;

    /* Save Local variables for endian change. */
    LucDlc      = pLinFrame->ucDlc;
    LulRxBufLen = pBufInfo->ulRxBufLen;
    LpBuffPtr   = &pBufInfo->pRxBufPtr[pBufInfo->ulRxBufLen];

    
    LucPId    = pLinFrame->ucPId;
    LusACFLen = (uint16)(((uint16)ACF_LIN_MSG_INFO_LEN + (uint16)LucDlc + (uint16)ACF_PAD_SIZE_MAX) / QUADLETS_BYTES);
    LucPad    = (uint8)((LusACFLen * QUADLETS_BYTES) - ACF_LIN_MSG_INFO_LEN - LucDlc);
    LulDataSize = LulRxBufLen + (uint32)ACF_LIN_MSG_INFO_LEN + pLinFrame->ucDlc;

    LulLinMessageInfo = ((uint32)ACF_LIN   << SHIFT_25BIT)
                      | ((uint32)LusACFLen << SHIFT_16BIT)
                      | ((uint32)LucPad    << SHIFT_14BIT)
                      /* Timestamp is not supported in LIN. Set mtv = 0, TimeStamp = 0*/
                      | ((uint32)NUM0      << SHIFT_13BIT)
                      | ((uint32)ucBusIdx  << SHIFT_8BIT)
                      | ((uint32)LucPId);

    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv32(&LulLinMessageInfo);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    /* Calculate current position */
    ProtoConv_UtilMemCpy(LpBuffPtr, &LulLinMessageInfo, sizeof(LulLinMessageInfo));
    LpBuffPtr = &LpBuffPtr[sizeof(LulLinMessageInfo)];
    /* Timestamp is not supported in LIN. Set 0 to message_timestamp field */
    ProtoConv_UtilMemSet(LpBuffPtr, (uint8)NUM0, (uint32)NUM8);
    LpBuffPtr = &LpBuffPtr[MSG_TIMESTAMP];
    ProtoConv_UtilMemCpy(LpBuffPtr, pLinFrame->pData, LucDlc);

    /* Check payload for zero-padding to the nearest quadlet boundary */
    if ((uint8)NUM0 < LucPad)
    {
        LpBuffPtr = &LpBuffPtr[LucDlc];
        ProtoConv_UtilMemSet(LpBuffPtr, (uint8)NUM0, (uint32)LucPad);
        LulDataSize += (uint32)LucPad;
    }
    else
    {
        /* Do nothing */
    }

    /* Update current position */
    pBufInfo->ulRxBufLen = LulDataSize;
    pBufInfo->ulRxBufCount++;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
