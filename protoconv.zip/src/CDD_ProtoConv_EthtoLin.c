/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to LIN Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_EthtoX.h"
#include "CDD_ProtoConv_EthtoLin.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
/* Ethernet to LIN Routing Table */
uint32 ProtoConv_GulEthtoLinMainTblNum;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
const R_ProtoConv_EthtoLinMainTblType *ProtoConv_GstEthtoLinMainTbl;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_012]:[Gen5GW_ProtoConv_UD_13_012]
* Function Name: ProtoConv_SearchLinRoutTbl
* Description  : Search LIN to Ethernet Routing Table.
* Arguments    : *pLinFrame -
*                    LiN frame
*                *pDestBusIdx-
*                    Destination Bus ID
*                *pAddInfo -
*                    Additional Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_SearchLinRoutTbl(const R_ProtoConv_LinFrameType *pLinFrame,
   uint8 *pDestBusIdx, uint32 *pAddInfo)
{
    const R_ProtoConv_EthtoXSubTblType *LpEthtoLinSubTbl;
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulLeftIdx; /* start key of index */
    uint32 LulRightIdx; /* end key of index */
    uint32 LulCenterIdx; /* middle key of index */
    uint32 LulTargetLinId; /* search value */
    uint32 LulCenterStartValue; /* table in middle value */
    uint32 LulCenterEndValue; /* table in middle value */
    uint32 LulEthtoLinSubTblEntryIdx;

    LulEntryIdx = IDX_0;
    LulLeftIdx = IDX_0;
    LulRightIdx = ProtoConv_GulEthtoLinMainTblNum;
    LulTargetLinId = (uint32)pLinFrame->ucPId;

    LucRetVal = E_NOT_OK;

    /* Binary search */
    while(LulLeftIdx <= LulRightIdx) {
        LulCenterIdx = (LulLeftIdx + LulRightIdx) / NUM2; /* calc of middle key */
        LulCenterStartValue = (uint32)ProtoConv_GstEthtoLinMainTbl[LulCenterIdx].ucPId;
        LulCenterEndValue = LulCenterStartValue + ProtoConv_GstEthtoLinMainTbl[LulCenterIdx].ulEthtoLinSubTblEntryNum;
        if ((LulCenterStartValue <= LulTargetLinId) && (LulTargetLinId < LulCenterEndValue)) {
            /* Entry found and save index */
            LulEntryIdx = LulCenterIdx;
            LucRetVal = E_OK;
            break;
        } else if (LulCenterStartValue < LulTargetLinId) {
            LulLeftIdx = LulCenterIdx + NUM1; /* adjustment of left(start) key */
        } else {
            LulRightIdx = LulCenterIdx - NUM1; /* adjustment of right(end) key */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LpEthtoLinSubTbl = ProtoConv_GstEthtoLinMainTbl[LulEntryIdx].pEthtoLinSubTbl;
        LulEthtoLinSubTblEntryIdx = LulTargetLinId - LulCenterStartValue;

        /* Copy Destination Bus Index and Additional Information */
        *pDestBusIdx = LpEthtoLinSubTbl[LulEthtoLinSubTblEntryIdx].ucDestBusIdx;
        *pAddInfo    = LpEthtoLinSubTbl[LulEthtoLinSubTblEntryIdx].ulAddInfo;
    }
    else
    {
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_013]:[Gen5GW_ProtoConv_UD_13_013]
* Function Name: ProtoConv_UnpackLin
* Description  : Unpack the LIN frame in ACF format from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pLinFrame -
*                    Unpacked LIN frame
*                 *pLinMsgInfo -
*                    LIN Message Information
*                 *pErrorStatus -
*                    Error status of transmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_UnpackLin(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
                        R_ProtoConv_LinFrameType *pLinFrame, ProtoConv_LinMsgInfoType *pLinMsgInfo, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint32 LulLinMessageInfo;
    uint8  LucPId;
    uint8  LucDlc;

    LucRetVal = E_OK;

    /* Unpack one LIN frame from the payload */
    LulFramePos = *pDataPosition;
    if (ulPayloadLen >= (LulFramePos + (uint32)ACF_LIN_MSG_INFO_LEN))
    {
        /* Retrieve the first 24 bits of LIN message and then LIN PID */
        ProtoConv_UtilMemCpy(&LulLinMessageInfo, &pPayload[LulFramePos], sizeof(LulLinMessageInfo));
        LulFramePos += (sizeof(LulLinMessageInfo));
        /* Timestamp is not supported in LIN. No need to copy. Shift message_time_stamp field (8 Byte) */
        LulFramePos += MSG_TIMESTAMP;

        /* Endian conversion : LIN message info*/
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulLinMessageInfo);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        pLinMsgInfo->ucFormatType = (uint8) ((LulLinMessageInfo >> SHIFT_25BIT));
        pLinMsgInfo->usACFLength  = (uint16)((LulLinMessageInfo >> SHIFT_16BIT) & MASK_9BIT);
        pLinMsgInfo->ucPad        = (uint8) ((LulLinMessageInfo >> SHIFT_14BIT) & MASK_2BIT);
        /* Timestamp is not supported in LIN, so mtv = 0 and Timestamp value = 0 */
        pLinMsgInfo->blMtv       = (boolean)NUM0;
        pLinMsgInfo->usSrcBusIdx = (uint8) ((LulLinMessageInfo >> SHIFT_8BIT) & MASK_5BIT);

        /* Get LIN PID and DLC*/
        LucPId = (uint8)(LulLinMessageInfo & MASK_8BIT);
        LucDlc = (uint8)((pLinMsgInfo->usACFLength * QUADLETS_BYTES) - ACF_LIN_MSG_INFO_LEN - pLinMsgInfo->ucPad);

        if ((LucDlc <= (uint8)LINFRAME_LEN_MAX) &&
            ((LulFramePos + LucDlc) <= ulPayloadLen))
        {
            /* Copy LIN data to Tx buffer */
            ProtoConv_UtilMemCpy(&ProtoConv_GaaLinTxBuf[IDX_0], &pPayload[LulFramePos], LucDlc);
            /* Set LIN frame data */
            pLinFrame->ucPId = LucPId;
            pLinFrame->ucDlc = LucDlc;
            pLinFrame->pData = &ProtoConv_GaaLinTxBuf[IDX_0];

            /* Return the next LIN frame position */
            *pDataPosition = LulFramePos + (uint32)LucDlc;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDLIN);
            #endif            
            /* Invalid LIN DLC */
            *pErrorStatus = PROTOCONV_E_PACKEDLIN;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No LIN frame if the data length from the unpacked position is
         * less than the size of the LIN ID and DLC.
         */
        *pErrorStatus = PROTOCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_014]:[Gen5GW_ProtoConv_UD_13_014]
* Function Name: ProtoConv_UnpackLinIPDUM
* Description  : Unpack the LIN frame in IPDU-M format from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pLinFrame -
*                    Unpacked LIN frame
*                 *pErrorStatus -
*                    Status of LIN packet transmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_UnpackLinIPDUM(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_LinFrameType *pLinFrame, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint8  LucDlc;

    LucRetVal = E_OK;

    /* Unpack one LIN frame from the payload */
    LulFramePos = *pDataPosition;
    if (ulPayloadLen >= (LulFramePos + (uint32)PDU_LEN_ID + (uint32)PDU_LEN_DLC))
    {
        /* Retrieve the LIN DLC (right after PDU ID in Eth Payload) */
        LulFramePos += (uint32)PDU_LEN_ID;
        /* LIN frame DLC fits into 1 Byte size. Read 1 Byte only */
        LucDlc = pPayload[LulFramePos + IDX_3];
        LulFramePos += (uint32)PDU_LEN_DLC;

        if ((LucDlc <= (uint32)LINFRAME_LEN_MAX) &&
            ((LulFramePos + (uint32)LucDlc) <= ulPayloadLen))
        {
            /* Copy LIN data to Tx buffer */
            ProtoConv_UtilMemCpy(&ProtoConv_GaaLinTxBuf[IDX_0], &pPayload[LulFramePos], LucDlc);
            /* Set LIN frame data */
            /* LIN PID is already set by caller */
            pLinFrame->ucDlc = LucDlc;
            pLinFrame->pData = &ProtoConv_GaaLinTxBuf[IDX_0];

            /* Return the next frame position */
            *pDataPosition = LulFramePos + LucDlc;
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDLIN);
            #endif            
            /* Invalid LIN DLC */
            *pErrorStatus = PROTOCONV_E_PACKEDLIN;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No LIN frame if the data length from the unpacked position is
         * less than the size of the LIN ID and DLC.
         */
        *pErrorStatus = PROTOCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"
