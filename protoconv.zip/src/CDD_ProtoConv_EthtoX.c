/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to CAN/LIN/Port Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_ProtoConv_common.h"
#include "CDD_ProtoConv_EthtoX.h"
#include "CDD_ProtoConv_Util.h"
#include "CDD_ProtoConv_EthtoCan.h"
#include "CDD_ProtoConv_EthtoLin.h"
#include "CDD_ProtoConv_EthtoPort.h"
#include "CDD_ProtoConv_interface.h"
/* Included for the declaration of Det_ReportError() */
#if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
#include "CDD_ProtoConv_Cfg.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
/*  CAN Tx Buffer */
uint8 *ProtoConv_GaaCanTxBuf;
/*  LIN Tx Buffer */
uint8 *ProtoConv_GaaLinTxBuf;
/*  PORT Tx Buffer */
uint8 *ProtoConv_GaaPortTxBuf;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
/* Ethernet Rx Buffer */
ProtoConv_EthRxBufType ProtoConv_GstEthRxBuf;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
uint32 ProtoConv_GulEthRxBufSize;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Private/global variables and functions
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
/* Filter table */
static R_ProtoConv_FilterCfgType ProtoConv_GstFilterCfg;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
static uint32 ProtoConv_GulPduEthtoXMainTblNum;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
static const R_ProtoConv_PduEthtoXMainTblType *ProtoConv_GstPduEthtoXMainTbl;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
/* Private functions for Common usage in Ethernet to X Conversion */
static Std_ReturnType SearchPduEthtoXTbl(const uint32 ulPduId, uint32 *pNewId, R_ProtoConv_PduEthtoXType *pPduConvMsn,
    uint8 *pDestBusIdx, uint32 *pAddInfo);

static Std_ReturnType CheckEthFormat(const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pPayLoadIdx,
                             uint32 *pPayLoadLen, boolean *pIPDUMCheck);

static Std_ReturnType CheckAvtpFormat(const uint32 ulLeftDataIdx, const uint32 ulLeftDataLen,
                             const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pPayLoadIdx, uint32 *pPayLoadLen);

static Std_ReturnType CheckIpv4UdpFormat(const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pUdpPayloadIdx, 
                             uint32 *pUdpPayloadLen);

static Std_ReturnType CheckIpv6UdpFormat(const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pUdpPayloadIdx,
                             uint32 *pUdpPayloadLen);

static void CalcIpv4UdpChecksum(const uint8 *pIpv4Pkt, uint32 *pCheckSum);

static void CalcIpv6UdpChecksum(const uint8 *pIpv6Pkt, uint32 *pCheckSum);

static Std_ReturnType CheckSrcMac(const uint8 *aaSrcMacAddr);

static Std_ReturnType CheckSrcIpv4(const uint32 *pSrcIp, const uint32 *pDstIp);

static Std_ReturnType CheckSrcIpv6(const uint32 *pSrcIp, const uint32 *pDstIp);

static Std_ReturnType CheckVlanId(const uint16 usVlanId);

static Std_ReturnType CheckStreamId(const uint32 *aaStreamId);

static Std_ReturnType PayloadUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen,
          const boolean blIPDUMCheck, uint32 *pSendStatus);

static Std_ReturnType ACFPayloadUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen,
          const uint32 ulMsgFirstWord, uint32 *pDataPosition, ProtoConv_PacketInfo *pPacketInfo);

static Std_ReturnType IPDUMPayloadUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen,
          const uint32 ulMsgFirstWord, uint32 *pDataPosition, ProtoConv_PacketInfo *pPacketInfo);

/* Private functions for Ethernet to Can Conversion */
static Std_ReturnType SendCanFrame(const R_ProtoConv_CanFrameType *pCanFrame,
          uint32 *pSendStatus, const ProtoConv_CanMsgInfoType *pCanMsgInfo, uint8 *pErrorStatus);

static Std_ReturnType SendPduCanFrame(const R_ProtoConv_CanFrameType *pCanFrame, uint8 ucDestBusIdx, uint32 ulAddInfo,
          uint32 *pSendStatus, uint8 *pErrorStatus);

/* Private functions for Ethernet to Lin Conversion */
static Std_ReturnType SendLinFrame(const uint8 ucSrcBusIdx,
          const R_ProtoConv_LinFrameType *pLinFrame, uint8 *pErrorStatus);
static Std_ReturnType SendPduLinFrame(const R_ProtoConv_LinFrameType *pLinFrame,
          uint8 ucDestBusIdx, uint32 ulAddInfo, uint8 *pErrorStatus);

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_001]:[Gen5GW_ProtoConv_UD_13_001]
* Function Name: ProtoConv_EthtoXInit
* Description  : Ethernet to CAN/LIN/Port Function Initialization.
* Arguments    : *pConfig -
*                    Initialization Config
* Return Value : N/A
*******************************************************************************/
void ProtoConv_EthtoXInit(const R_ProtoConv_CfgType *pConfig)
{
    GulSendStatus = PACKETSEND_DEFAULT;

    /* Set CAN Routing Table */
    ProtoConv_GulEthtoCanMainTblNum = ETHTOCAN_MAINTBL_ENTRY_NUM;
    ProtoConv_GstEthtoCanMainTbl    = pConfig->pEthtoCanMainTbl;
    /* Set LIN Routing Table */
    ProtoConv_GulEthtoLinMainTblNum = ETHTOLIN_MAINTBL_ENTRY_NUM;
    ProtoConv_GstEthtoLinMainTbl    = pConfig->pEthtoLinMainTbl;
    /* Set IPDU-M ETH to CAN/LIN Routing Table */
    ProtoConv_GulPduEthtoXMainTblNum = PDUETHTOXMAINTBL_ENTRY_NUM;
    ProtoConv_GstPduEthtoXMainTbl    = pConfig->pPduEthtoXMainTbl;

    /* Copying Buffer Address and Size to global variables */
    ProtoConv_GaaCanTxBuf  = pConfig->pBufCfg->pCanTxAddr;
    ProtoConv_GaaLinTxBuf  = pConfig->pBufCfg->pLinTxAddr;
    ProtoConv_GaaPortTxBuf = pConfig->pBufCfg->pPortTxAddr;
    ProtoConv_GstEthRxBuf.aaPayload = pConfig->pBufCfg->pEthRxAddr;
    ProtoConv_GulEthRxBufSize = pConfig->pBufCfg->ulEthRxBufSize;
    /* Initialize buffer */
    ProtoConv_UtilMemSet(&ProtoConv_GaaCanTxBuf[IDX_0],  (uint8)NUM0, pConfig->pBufCfg->ulCanTxBufSize);
    ProtoConv_UtilMemSet(&ProtoConv_GaaLinTxBuf[IDX_0],  (uint8)NUM0, pConfig->pBufCfg->ulLinTxBufSize);
    ProtoConv_UtilMemSet(&ProtoConv_GaaPortTxBuf[IDX_0], (uint8)NUM0, pConfig->pBufCfg->ulPortTxBufSize);
    ProtoConv_UtilMemSet(&ProtoConv_GstEthRxBuf.aaPayload[IDX_0], (uint8)NUM0, ProtoConv_GulEthRxBufSize);

    /* Source mac address filter */
    if ((uint32)pConfig->pFilterCfg->usSrcMacFilterNum > (uint32)NUM0)
    {
        ProtoConv_GstFilterCfg.usSrcMacFilterNum = pConfig->pFilterCfg->usSrcMacFilterNum;
        ProtoConv_GstFilterCfg.aaSrcMacAddr      = pConfig->pFilterCfg->aaSrcMacAddr;
    }
    else
    {
        ProtoConv_GstFilterCfg.usSrcMacFilterNum = NUM0;
        ProtoConv_GstFilterCfg.aaSrcMacAddr      = NULL_PTR;
    }

    /* Source IP address filter */
    if ((uint32)pConfig->pFilterCfg->usSrcIpFilterNum > (uint32)NUM0)
    {
        ProtoConv_GstFilterCfg.usSrcIpFilterNum = pConfig->pFilterCfg->usSrcIpFilterNum;
        ProtoConv_GstFilterCfg.aaSrcIpAddr      = pConfig->pFilterCfg->aaSrcIpAddr;
    }
    else
    {
        ProtoConv_GstFilterCfg.usSrcIpFilterNum = NUM0;
        ProtoConv_GstFilterCfg.aaSrcIpAddr      = NULL_PTR;
    }

    /* VlanID filter */
    if ((uint32)pConfig->pFilterCfg->usVlanIdFilterNum > (uint32)NUM0)
    {
        ProtoConv_GstFilterCfg.usVlanIdFilterNum = pConfig->pFilterCfg->usVlanIdFilterNum;
        ProtoConv_GstFilterCfg.aaVlanId          = pConfig->pFilterCfg->aaVlanId;
    }
    else
    {
        ProtoConv_GstFilterCfg.usVlanIdFilterNum = NUM0;
        ProtoConv_GstFilterCfg.aaVlanId          = NULL_PTR;
    }

    /* StreamID filter */
    if ((uint32)pConfig->pFilterCfg->usStreamIdFilterNum > (uint32)NUM0)
    {
        ProtoConv_GstFilterCfg.usStreamIdFilterNum = pConfig->pFilterCfg->usStreamIdFilterNum;
        ProtoConv_GstFilterCfg.aaStreamId          = pConfig->pFilterCfg->aaStreamId;
    }
    else
    {
        ProtoConv_GstFilterCfg.usStreamIdFilterNum = NUM0;
        ProtoConv_GstFilterCfg.aaStreamId          = NULL_PTR;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_002]:[Gen5GW_ProtoConv_UD_13_002]
* Function Name: ProtoConv_EthtoX
* Description  : Ethernet to CAN/LIN/Port Conversion Function
* Arguments    : usFrameType -
*                    Ethernet frame type
*                *aaSrcMacAddr -
*                    Ethernet source MacAddress
*                *pEthFrame -
*                    Ethernet frame
*                ulFrameLen -
*                    Ethernet frame length
*                *pSendStatus -
*                    Packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
Std_ReturnType ProtoConv_EthtoX(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
                           const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus)
{
    const ProtoConv_IEEE8021QType   *pIEEE8021QHeader;
    const uint8                     *LpEthFrame;
    Std_ReturnType                  LucRetVal;
    uint16                          LusFrameType;
    uint16                          LusVlanId;
    uint32                          LulPayLoadIdx;
    uint32                          LulPayLoadLen;
    uint32                          LulFrameLen;
    boolean                         LblIPDUMCheck;
 
    LusFrameType = usFrameType;
    LulFrameLen  = ulFrameLen;
    LulPayLoadIdx = NUM0;
    LulPayLoadLen = NUM0;

    /* Source MAC Address filter */
    LucRetVal = CheckSrcMac(aaSrcMacAddr);
    if ((uint8)E_OK == LucRetVal)
    {
        if ((LulFrameLen >= ETH_FRAME_PAYLOAD_SIZE_MIN) &&
            (LulFrameLen <= ProtoConv_GulEthRxBufSize))
        {
            /* Check IEEE802.1Q */
            if ((uint32)PROTOCONV_FRAMETYPE_8021Q == (uint32)LusFrameType)
            {
                /* VLANID filter */
                pIEEE8021QHeader = (const ProtoConv_IEEE8021QType*)pEthFrame;
                LusVlanId = pIEEE8021QHeader->usVlanId;
                #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
                ProtoConv_UtilEndianConv16((uint16*)&LusVlanId);
                #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
                LucRetVal = CheckVlanId((uint16)((uint32)LusVlanId & (uint32)MASK_12BIT));
                if ((uint8)E_OK == LucRetVal)
                {
                    LusFrameType = pIEEE8021QHeader->usFrameType;
                    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
                    ProtoConv_UtilEndianConv16(&LusFrameType);
                    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

                    LpEthFrame  = &pEthFrame[sizeof(ProtoConv_IEEE8021QType)];
                    LulFrameLen -= sizeof(ProtoConv_IEEE8021QType);
                }
                else
                {
                    /* Do Nothing */
                }
            }
            else
            {
                LpEthFrame = &pEthFrame[IDX_0];
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PARAM_DATA_LENGTH);
            #endif         
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy Ethernet frame to Rx buffer */
        ProtoConv_UtilMemCpy(&ProtoConv_GstEthRxBuf.aaPayload[IDX_0], LpEthFrame, LulFrameLen);
        ProtoConv_GstEthRxBuf.usFrameType = LusFrameType;
        ProtoConv_GstEthRxBuf.ulFrameLen  = LulFrameLen;

        /* Check format of Ethernet frame. */
        LucRetVal = CheckEthFormat(&ProtoConv_GstEthRxBuf, &LulPayLoadIdx, &LulPayLoadLen, &LblIPDUMCheck);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Unpack and Send frame. */
            LucRetVal = PayloadUnpackAndSend(&ProtoConv_GstEthRxBuf.aaPayload[LulPayLoadIdx], LulPayLoadLen,
                                             LblIPDUMCheck, pSendStatus);
        }
        else
        {
            /* Do nothing */
        }

        /* Clear Ethernet Rx buffer. */
        ProtoConv_GstEthRxBuf.usFrameType = NUM0;
        ProtoConv_GstEthRxBuf.ulFrameLen = NUM0;
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_022]:[Gen5GW_ProtoConv_UD_13_022]
* Function Name: CheckEthFormat
* Description  : Check Ethernet frame format.
* Arguments    : *pEthRxBuf  -
*                    Ethernet Rx buffer
*                *pPayLoadIdx  -
*                    AVTP payload position in Ethernet frame.
*                *pPayLoadLen -
*                   AVTP payload length
*                *pEthFormat -
*                   Ethernet format
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType CheckEthFormat(const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pPayLoadIdx,
                             uint32 *pPayLoadLen, boolean *pIPDUMCheck)
{
    Std_ReturnType                  LucRetVal;
    uint32                          LulLeftDataIdx;
    uint32                          LulLeftDataLen;
    uint8                           LucSubType;

    LucRetVal = E_OK;
    *pIPDUMCheck = (boolean)NUM0; /* Not IPDU-M */

    switch ((uint32)pEthRxBuf->usFrameType)
    {
    case PROTOCONV_FRAMETYPE_IPV4:
        /* Check IPv4 header and UDP format */
        LucRetVal = CheckIpv4UdpFormat(pEthRxBuf, &LulLeftDataIdx, &LulLeftDataLen);
        if ((uint8)E_OK == LucRetVal)
        {
            LucSubType = pEthRxBuf->aaPayload[LulLeftDataIdx + sizeof(uint32)];
            if (((uint32)SUBTYPE_NTSCF == (uint32)LucSubType) ||
                ((uint32)SUBTYPE_TSCF == (uint32)LucSubType))
            {
                /* IPv4 + encapsulation_sequence_num + AVTP format */
                /* Check encapsulation_sequence_num field size */
                if (LulLeftDataLen >= sizeof(uint32))
                {
                    /* Set AVTP header position and left data size */
                    LulLeftDataIdx += sizeof(uint32);
                    LulLeftDataLen -= sizeof(uint32);
                    LucRetVal = CheckAvtpFormat(LulLeftDataIdx, LulLeftDataLen, pEthRxBuf, pPayLoadIdx, pPayLoadLen);
                }
                else
                {
                    #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                        PROTOCONV_E_PARAM_DATA_LENGTH);
                    #endif
                    LucRetVal = E_NOT_OK;
                }
            }
            else
            {
                /* IPv4 + IPDU-M format */
                *pIPDUMCheck = (boolean)NUM1;
                *pPayLoadLen = LulLeftDataLen;
                *pPayLoadIdx = LulLeftDataIdx;
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    case PROTOCONV_FRAMETYPE_IPV6:
        /* Check IPv6 header and UDP format */
        LucRetVal = CheckIpv6UdpFormat(pEthRxBuf, &LulLeftDataIdx, &LulLeftDataLen);
        if ((uint8)E_OK == LucRetVal)
        {
            LucSubType = pEthRxBuf->aaPayload[LulLeftDataIdx + sizeof(uint32)];
            if (((uint32)SUBTYPE_NTSCF == (uint32)LucSubType) ||
                ((uint32)SUBTYPE_TSCF == (uint32)LucSubType))
            {
                /* IPv6 + encapsulation_sequence_num + AVTP format */
                /* Check encapsulation_sequence_num field size */
                if (LulLeftDataLen >= sizeof(uint32))
                {
                    /* Set AVTP header position and left data size */
                    LulLeftDataIdx += sizeof(uint32);
                    LulLeftDataLen -= sizeof(uint32);
                    LucRetVal = CheckAvtpFormat(LulLeftDataIdx, LulLeftDataLen, pEthRxBuf, pPayLoadIdx, pPayLoadLen);
                }
                else
                {
                    #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                        PROTOCONV_E_PARAM_DATA_LENGTH);
                    #endif
                    LucRetVal = E_NOT_OK;
                }
            }
            else
            {
                /* IPv6 + IPDU-M format */
                *pIPDUMCheck = (boolean)NUM1;
                *pPayLoadLen = LulLeftDataLen;
                *pPayLoadIdx = LulLeftDataIdx;
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    case PROTOCONV_FRAMETYPE_AVTP:
        /* AVTP format */
        /* Set AVTP header position and left data size */
        LulLeftDataIdx = IDX_0;
        LulLeftDataLen = pEthRxBuf->ulFrameLen;
        LucRetVal = CheckAvtpFormat(LulLeftDataIdx, LulLeftDataLen, pEthRxBuf, pPayLoadIdx, pPayLoadLen);
        break;
    default:
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                              PROTOCONV_E_PARAM_DATA_LENGTH);
        #endif
        LucRetVal = E_NOT_OK;
        break;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_023]:[Gen5GW_ProtoConv_UD_13_023]
* Function Name: CheckAvtpFormat
* Description  : Check AVTP format.
* Arguments    : ulLeftDataIdx -
*                    frame data index
*                ulLeftDataLen -
*                    frame data length
*                *pEthRxBuf  -
*                    Ethernet Rx buffer
*                *pPayLoadIdx  -
*                    AVTP payload position in Ethernet frame.
*                *pPayLoadLen -
*                   AVTP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType CheckAvtpFormat(const uint32 ulLeftDataIdx, const uint32 ulLeftDataLen,
                              const ProtoConv_EthRxBufType *pEthRxBuf,
                              uint32 *pPayLoadIdx, uint32 *pPayLoadLen)
{
    const ProtoConv_AVTPCommonType *pAVTPHeader;
    const ProtoConv_NTSCFType      *pNTSCFHeader;
    const ProtoConv_TSCFType       *pTSCFHeader;
    Std_ReturnType                  LucRetVal;
    uint32                          LaaStreamId[PROTOCONV_STREAMID_LEN_IN_WORD];
    uint32                          LulNTSCFDataLength;
    uint16                          LusTSCFDataLength;

    LucRetVal = E_OK;

    pAVTPHeader = (const ProtoConv_AVTPCommonType*)&pEthRxBuf->aaPayload[ulLeftDataIdx];
    if ((uint32)SUBTYPE_NTSCF == (uint32)pAVTPHeader->ucSubType)
    {
        /* Get NTSCF payload length */
        pNTSCFHeader = (const ProtoConv_NTSCFType *)&pEthRxBuf->aaPayload[ulLeftDataIdx];
        LaaStreamId[IDX_0] = pNTSCFHeader->aaStreamId[IDX_0];
        LaaStreamId[IDX_1] = pNTSCFHeader->aaStreamId[IDX_1];
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LaaStreamId[IDX_0]);
        ProtoConv_UtilEndianConv32(&LaaStreamId[IDX_1]);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
        LulNTSCFDataLength = (((uint32)pNTSCFHeader->ucSvVerDataLenMSB << (uint32)SHIFT_8BIT)
                              | (uint32)pNTSCFHeader->ucDataLenLSB) & (uint32)MASK_NTSCF_DATA_LENGTH;
        /* Check NTSCF header format */
        if ((ulLeftDataLen >= (uint32)HEADER_LEN_NTSCF)
        &&  (LulNTSCFDataLength <= (ulLeftDataLen - (uint32)HEADER_LEN_NTSCF)))
        {
            LucRetVal = CheckStreamId(LaaStreamId);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Set NTSCF payload position and length */
                *pPayLoadIdx = ulLeftDataIdx + (uint32)HEADER_LEN_NTSCF;
                *pPayLoadLen = LulNTSCFDataLength;
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PARAM_DATA_LENGTH);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else if ((uint32)SUBTYPE_TSCF == (uint32)pAVTPHeader->ucSubType)
    {
        /* Get TSCF payload length */
        pTSCFHeader = (const ProtoConv_TSCFType *)&pEthRxBuf->aaPayload[ulLeftDataIdx];
        LaaStreamId[IDX_0] = pTSCFHeader->aaStreamId[IDX_0];
        LaaStreamId[IDX_1] = pTSCFHeader->aaStreamId[IDX_1];
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LaaStreamId[IDX_0]);
        ProtoConv_UtilEndianConv32(&LaaStreamId[IDX_1]);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
        LusTSCFDataLength = pTSCFHeader->usStreamDataLength;
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv16(&LusTSCFDataLength);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        /* Check TSCF header format */
        if ((ulLeftDataLen >= (uint32)HEADER_LEN_TSCF)
        &&  ((uint32)LusTSCFDataLength <= (ulLeftDataLen - (uint32)HEADER_LEN_TSCF)))
        {
            LucRetVal = CheckStreamId(LaaStreamId);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Set TSCF payload position and length */
                *pPayLoadIdx = ulLeftDataIdx + (uint32)HEADER_LEN_TSCF;
                *pPayLoadLen = LusTSCFDataLength;
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PARAM_DATA_LENGTH);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                              PROTOCONV_E_PARAM_DATA_LENGTH);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_024]:[Gen5GW_ProtoConv_UD_13_024]
* Function Name: CheckIpv4UdpFormat
* Description  : Check IPv4 header and UDP format
* Arguments    : *pEthRxBuf -
*                    Ethernet Rx buffer
*                *pUdpPayloadIdx -
*                    UDP payload position in Ethernet frame.
*                *pUdpPayloadLen -
*                    UDP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType CheckIpv4UdpFormat(const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pUdpPayloadIdx,
                                 uint32 *pUdpPayloadLen)
{
    ProtoConv_Ipv4HeaderType LstIpv4Header;
    Std_ReturnType LucRetVal;
    uint32 LulCkSum;
    uint16 LusFragmentOffset;
    uint16 LusDataLen;
    uint16 LusUdpPort;

    LucRetVal = E_OK;

    /* Copy IPv4 header (Big-Endian) */
    ProtoConv_UtilMemCpy(&LstIpv4Header, pEthRxBuf->aaPayload, sizeof(LstIpv4Header));
    /* Endian conversion (Network order to host order) */
    LusFragmentOffset = LstIpv4Header.usFragment;
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv16(&LusFragmentOffset);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
    LusDataLen = LstIpv4Header.usPktLen;
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv16(&LusDataLen);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
    LusUdpPort = ((const ProtoConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV4])->usDestPort;
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv16(&LusUdpPort);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

    /*
     *   Validation of the IPv4 header
     *   The version field is 0x4 and the IHL field value is 0x5. (IP options are not allowed)
     *   MF and fragment offset field value.
     *   Validation of IPv4 data length field value
     *     >= ([IPv4 header length] + [UDP header length])
     *     <= Ethernet frame length
     *   Protocol field value is UDP.
     */
    if (((uint32)VER_AND_HEADERLEN_IPV4 == (uint32)LstIpv4Header.ucVerAndHeaderLen) &&
        ((uint32)NOT_FRAGMENTED_IPV4 == ((uint32)LusFragmentOffset & (uint32)MASK_FRAGMENT_MF_OFFSET)) &&
        ((uint32)LusDataLen   >= ((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP)) &&
        ((uint32)LusDataLen   <= pEthRxBuf->ulFrameLen) &&
        ((uint32)PROTOCOL_UDP == (uint32)LstIpv4Header.ucProtocol))
    {
        /* Verify IPv4 header checksum */
        LulCkSum = NUM0;
        ProtoConv_UtilCalcSum(&LstIpv4Header, sizeof(LstIpv4Header), &LulCkSum);
        if ((uint32)VERIFY_CKSUM == (uint32)LulCkSum)
        {
            /* Do nothing */
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_IPCKSUM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                              PROTOCONV_E_PARAM_DATA_LENGTH);
        #endif
        /* Invalid IPv4 header format */
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Get UDP data length */
        LusDataLen = ((const ProtoConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV4])->usLen;
        /* Endian conversion (Network order to host order) */
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv16(&LusDataLen);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
        /* Verify the UDP data length */
        if (((uint32)LusDataLen >= (uint32)HEADER_LEN_UDP) &&
            ((uint32)LusDataLen <= (pEthRxBuf->ulFrameLen - (uint32)HEADER_LEN_IPV4)) &&
            ((uint32)LusUdpPort == (uint32)ProtoConv_GstEthSrcCfg.usSrcUdpPort))
        {
            /* If the value of the checksum field is 0, the checksum is not verified. */
            if ((uint32)CHECKSUM_ZERO !=
                (uint32)((const ProtoConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV4])->usChecksum)
            {
                /* Compute and verify the IPv4 UDP checksum */
                CalcIpv4UdpChecksum(&pEthRxBuf->aaPayload[IDX_0], &LulCkSum);
                if ((uint32)VERIFY_CKSUM == (uint32)LulCkSum)
                {
                    /* Do nothing */
                }
                else
                {
                    #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                          PROTOCONV_E_UDPCKSUM);
                    #endif
                    LucRetVal = E_NOT_OK;
                }
            }
            else
            {
                /* Do nothing */
            }

            if ((uint8)E_OK == LucRetVal)
            {
                /* Source IP Address filter */
                #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
                ProtoConv_UtilEndianConv32(&LstIpv4Header.ulSrcIpAddr);
                ProtoConv_UtilEndianConv32(&LstIpv4Header.ulDestIpAddr);
                #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
                LucRetVal = CheckSrcIpv4(&LstIpv4Header.ulSrcIpAddr, &LstIpv4Header.ulDestIpAddr);
                if ((uint8)E_OK == LucRetVal)
                {
                    /* Set UDP payload position and length */
                    *pUdpPayloadIdx = ((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP);
                    *pUdpPayloadLen = (uint32)LusDataLen - (uint32)HEADER_LEN_UDP;
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PARAM_DATA_LENGTH);
            #endif
            /* Invalid UDP data length */
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_025]:[Gen5GW_ProtoConv_UD_13_025]
* Function Name: CheckIpv6UdpFormat
* Description  : Check IPv6 header and UDP format
* Arguments    : *pEthRxBuf -
*                    Ethernet Rx buffer
*                *pUdpPayloadIdx -
*                    UDP payload position in Ethernet frame.
*                *pUdpPayloadLen -
*                    UDP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType CheckIpv6UdpFormat(const ProtoConv_EthRxBufType *pEthRxBuf, uint32 *pUdpPayloadIdx,
                                 uint32 *pUdpPayloadLen)
{
    ProtoConv_Ipv6HeaderType LstIpv6Header;
    Std_ReturnType LucRetVal;
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    uint32 LulCount;
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
    uint32 LulVerClassAndLabel;
    uint32 LulCkSum;
    uint16 LusDataLen;
    uint16 LusUdpPort;

    LucRetVal = E_OK;

    /* Check if the Ethernet frame length is longer than the IPv6 header length */
    if (pEthRxBuf->ulFrameLen >= (HEADER_LEN_IPV6 + HEADER_LEN_UDP))
    {
        /* Copy IPv6 header (Big-Endian) */
        ProtoConv_UtilMemCpy(&LstIpv6Header, pEthRxBuf->aaPayload, sizeof(LstIpv6Header));
        /* Endian conversion (Network order to host order) */
        LulVerClassAndLabel = LstIpv6Header.ulVerClassAndLabel;
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulVerClassAndLabel);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
        LusDataLen = LstIpv6Header.usPayloadLen;
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv16(&LusDataLen);
        #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

        /*
         *   Validation of the IPv6 header
         *   The version field is 0x6. Traffic Class and Flow Label field are both 0x0. (IP options are not allowed)
         *   Validation of IPv6 data length field value
         *     >= [UDP header length]
         *     <= Ethernet frame length
         *   Next Header field value is UDP.
         */
        if (((uint32)VER_CLASS_AND_LABEL_IPV6 == LulVerClassAndLabel) &&
            ((uint32)LusDataLen >= (uint32)HEADER_LEN_UDP) &&
            ((uint32)LusDataLen <= (pEthRxBuf->ulFrameLen - (uint32)HEADER_LEN_IPV6)) &&
            ((uint32)PROTOCOL_UDP == (uint32)LstIpv6Header.ucNextHeader))
        {
            /* Get UDP data length and Port Number */
            LusDataLen = ((const ProtoConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV6])->usLen;
            LusUdpPort = ((const ProtoConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV6])->usDestPort;
            /* Endian conversion (Network order to host order) */
            #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
            ProtoConv_UtilEndianConv16(&LusDataLen);
            ProtoConv_UtilEndianConv16(&LusUdpPort);
            #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
            /* Verify the UDP data length */
            if (((uint32)LusDataLen >= (uint32)HEADER_LEN_UDP) &&
                ((uint32)LusDataLen <= (pEthRxBuf->ulFrameLen - (uint32)HEADER_LEN_IPV6)) &&
                ((uint32)LusUdpPort == (uint32)ProtoConv_GstEthSrcCfg.usSrcUdpPort))
            {
                /* If the value of the checksum field is 0, the checksum is not verified. */
                if ((uint32)CHECKSUM_ZERO !=
                    (uint32)((const ProtoConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV6])->usChecksum)
                {
                    /* Compute and verify the IPv6 UDP checksum */
                    LulCkSum = NUM0;
                    CalcIpv6UdpChecksum(&pEthRxBuf->aaPayload[IDX_0], &LulCkSum);
                    if ((uint32)VERIFY_CKSUM == (uint32)LulCkSum)
                    {
                        /* Do nothing */
                    }
                    else
                    {
                        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                              PROTOCONV_E_UDPCKSUM);
                        #endif
                        LucRetVal = E_NOT_OK;
                    }
                }
                else
                {
                    #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                          PROTOCONV_E_UDPCKSUM);
                    #endif
                    LucRetVal = E_NOT_OK;
                }

                if ((uint8)E_OK == LucRetVal)
                {
                    /* Source IP Address filter */
                    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
                    for (LulCount = IDX_0; LulCount < (uint32)PROTOCONV_IPADDR_LEN_IN_WORD; LulCount++)
                    {
                        ProtoConv_UtilEndianConv32(&LstIpv6Header.aaSrcIpAddr[LulCount]);
                        ProtoConv_UtilEndianConv32(&LstIpv6Header.aaDestIpAddr[LulCount]);
                    }
                    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
                    LucRetVal = CheckSrcIpv6(LstIpv6Header.aaSrcIpAddr, LstIpv6Header.aaDestIpAddr);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Set UDP payload position and length */
                        *pUdpPayloadIdx = (HEADER_LEN_IPV6 + HEADER_LEN_UDP);
                        *pUdpPayloadLen = (uint32)LusDataLen - (uint32)HEADER_LEN_UDP;
                    }
                    else
                    {
                        /* Do nothing */
                    }
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                      PROTOCONV_E_PARAM_DATA_LENGTH);
                #endif
                /* Invalid UDP data length */
                LucRetVal = E_NOT_OK; 
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PARAM_DATA_LENGTH);
            #endif
            /* Invalid IPv6 header format */
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                              PROTOCONV_E_PARAM_DATA_LENGTH);
        #endif
        /* Invalid Ethernet frame length */
        LucRetVal = E_NOT_OK;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_026]:[Gen5GW_ProtoConv_UD_13_026]
* Function Name: CalcIpv4UdpChecksum
* Description  : Calculate IPv4 UDP checksum
* Arguments    : *pIpv4Pkt -
*                    IPv4 packet data
*                *pCheckSum -
*                    Calculated UDP checksum
* Return Value : N/A
*******************************************************************************/
static void CalcIpv4UdpChecksum(const uint8 *pIpv4Pkt, uint32 *pCheckSum)
{
    const ProtoConv_Ipv4HeaderType *pIpv4Header;
    ProtoConv_Ipv4PseudoHeaderType  LstIpv4PseudoHeader;
    uint16 LusDataLen;

    /* IPv4 Pseudo Header */
    pIpv4Header = (const ProtoConv_Ipv4HeaderType *)pIpv4Pkt;
    ProtoConv_UtilMemCpy(&LstIpv4PseudoHeader.ulSrcIpAddr,
        &pIpv4Header->ulSrcIpAddr, PROTOCONV_IPV4ADDR_LEN_IN_BYTE);
    ProtoConv_UtilMemCpy(&LstIpv4PseudoHeader.ulDestIpAddr,
        &pIpv4Header->ulDestIpAddr, PROTOCONV_IPV4ADDR_LEN_IN_BYTE);
    LstIpv4PseudoHeader.ucPadZero = NUM0;
    LstIpv4PseudoHeader.ucProtocol = PROTOCOL_UDP;
    LstIpv4PseudoHeader.usDataLen = ((const ProtoConv_UdpHeaderType *)&pIpv4Pkt[HEADER_LEN_IPV4])->usLen;

    /* Calculate checksum of the IPv4 Pseudo Header */
    *pCheckSum = NUM0;
    ProtoConv_UtilCalcSum(&LstIpv4PseudoHeader, (uint16)sizeof(LstIpv4PseudoHeader), pCheckSum);

    /* Endian conversion of UDP data length */
    LusDataLen = LstIpv4PseudoHeader.usDataLen;
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv16(&LusDataLen);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
    /* Calculate the UDP checksum */
    ProtoConv_UtilCalcSum(&pIpv4Pkt[HEADER_LEN_IPV4], LusDataLen, pCheckSum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_027]:[Gen5GW_ProtoConv_UD_13_027]
* Function Name: CalcIpv6UdpChecksum
* Description  : Calculate IPv6 UDP checksum
* Arguments    : *pIpv6Pkt -
*                    IPv6 packet data
*                *pCheckSum -
*                    Calculated UDP checksum
* Return Value : N/A
*******************************************************************************/
static void CalcIpv6UdpChecksum(const uint8 *pIpv6Pkt, uint32 *pCheckSum)
{
    const ProtoConv_Ipv6HeaderType *pIpv6Header;
    ProtoConv_Ipv6PseudoHeaderType  LstIpv6PseudoHeader;
    uint16 LusDataLen;

    /* IPv6 Pseudo Header */
    pIpv6Header = (const ProtoConv_Ipv6HeaderType *)pIpv6Pkt;
    ProtoConv_UtilMemCpy(&LstIpv6PseudoHeader.aaSrcIpAddr[IDX_0],
        &pIpv6Header->aaSrcIpAddr[IDX_0], PROTOCONV_IPV6ADDR_LEN_IN_BYTE);
    ProtoConv_UtilMemCpy(&LstIpv6PseudoHeader.aaDestIpAddr[IDX_0],
        &pIpv6Header->aaDestIpAddr[IDX_0], PROTOCONV_IPV6ADDR_LEN_IN_BYTE);
    LstIpv6PseudoHeader.ulPayloadLen = (uint32)((const ProtoConv_UdpHeaderType *)&pIpv6Pkt[HEADER_LEN_IPV6])->usLen;
    LstIpv6PseudoHeader.aaPadZero[IDX_0] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_1] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_2] = NUM0;
    LstIpv6PseudoHeader.ucNextHeader = (uint8)PROTOCOL_UDP;

    /* Calculate checksum of the IPv6 Pseudo Header */
    *pCheckSum = NUM0;
    ProtoConv_UtilCalcSum(&LstIpv6PseudoHeader, (uint16)sizeof(LstIpv6PseudoHeader), pCheckSum);

    /* Endian conversion of UDP data length */
    LusDataLen = (uint16)LstIpv6PseudoHeader.ulPayloadLen;
    #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
    ProtoConv_UtilEndianConv16(&LusDataLen);
    #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
    /* Calculate the UDP checksum */
    ProtoConv_UtilCalcSum(&pIpv6Pkt[HEADER_LEN_IPV6], LusDataLen, pCheckSum);
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_028]:[Gen5GW_ProtoConv_UD_13_028]
* Function name: CheckSrcMac
* Description  : Filter by source MAC Address
* Arguments    : *aaSrcMacAddr -
*                    Source MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType CheckSrcMac(const uint8 *aaSrcMacAddr)
{
    Std_ReturnType LucRetVal;
    uint32 LulSrcMacAddr[PROTOCONV_MACADDR_LEN_IN_WORD];
    uint32 LulFilterIdx;

    LulSrcMacAddr[IDX_0] = ((uint32)aaSrcMacAddr[IDX_0] << SHIFT_8BIT)  | ((uint32)aaSrcMacAddr[IDX_1]);
    LulSrcMacAddr[IDX_1] = ((uint32)aaSrcMacAddr[IDX_2] << SHIFT_24BIT) | ((uint32)aaSrcMacAddr[IDX_3] << SHIFT_16BIT)
                         | ((uint32)aaSrcMacAddr[IDX_4] << SHIFT_8BIT)  | ((uint32)aaSrcMacAddr[IDX_5]);

    /* Check if filter is enabled */
    if ((uint32)NUM0 < (uint32)ProtoConv_GstFilterCfg.usSrcMacFilterNum)
    {
        /* Scan the filter table */
        LucRetVal = E_NOT_OK;
        for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)ProtoConv_GstFilterCfg.usSrcMacFilterNum; LulFilterIdx++)
        {
            if ((LulSrcMacAddr[IDX_0] == ProtoConv_GstFilterCfg.aaSrcMacAddr[LulFilterIdx].aaMacAddr[IDX_0])
            &&  (LulSrcMacAddr[IDX_1] == ProtoConv_GstFilterCfg.aaSrcMacAddr[LulFilterIdx].aaMacAddr[IDX_1]))
            {
                /* Found MAC Address */
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* Filter disabled */
        LucRetVal = E_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID, PROTOCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_029]:[Gen5GW_ProtoConv_UD_13_029]
* Function name: CheckSrcIpv4
* Description  : Filter by source IPv4 Address
* Arguments    : *pSrcIp -
*                    Source IP Address
*              : *pDstIp -
*                    Destination IP Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType CheckSrcIpv4(const uint32 *pSrcIp, const uint32 *pDstIp)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* Check destination IP Address */
    if (*pDstIp == ProtoConv_GstEthSrcCfg.ulSrcIpv4Addr)
    {
        /* Check if filter is enabled */
        if ((uint32)NUM0 < (uint32)ProtoConv_GstFilterCfg.usSrcIpFilterNum)
        {
            /* Scan the filter table */
            LucRetVal = E_NOT_OK;
            for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)ProtoConv_GstFilterCfg.usSrcIpFilterNum; LulFilterIdx++)
            {
                if (*pSrcIp == ProtoConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_0])
                {
                    /* Found IPV4 Address */
                    LucRetVal = E_OK;
                    break;
                }
                else
                {
                    /* Do nothing */
                }
            }
        }
        else
        {
            /* Filter disabled */
            LucRetVal = E_OK;
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID, PROTOCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_030]:[Gen5GW_ProtoConv_UD_13_030]
* Function name: CheckSrcIpv6
* Description  : Filter by source IPv6 Address
* Arguments    : *pSrcIp -
*                    Source IP Address
*              : *pDstIp -
*                    Destination IP Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType CheckSrcIpv6(const uint32 *pSrcIp, const uint32 *pDstIp)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* Check destination IP Address */
    if ((pDstIp[IDX_0] == ProtoConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_0])
    &&  (pDstIp[IDX_1] == ProtoConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_1])
    &&  (pDstIp[IDX_2] == ProtoConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_2])
    &&  (pDstIp[IDX_3] == ProtoConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_3]))
    {
        /* Check if filter is enabled */
        if ((uint32)NUM0 < (uint32)ProtoConv_GstFilterCfg.usSrcIpFilterNum)
        {
            /* Scan the filter table */
            LucRetVal = E_NOT_OK;
            for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)ProtoConv_GstFilterCfg.usSrcIpFilterNum; LulFilterIdx++)
            {
                if ((pSrcIp[IDX_0] == ProtoConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_0])
                &&  (pSrcIp[IDX_1] == ProtoConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_1])
                &&  (pSrcIp[IDX_2] == ProtoConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_2])
                &&  (pSrcIp[IDX_3] == ProtoConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_3]))
                {
                    /* Found IPV6 Address */
                    LucRetVal = E_OK;
                    break;
                }
                else
                {
                    /* Do nothing */
                }
            }
        }
        else
        {
            /* Filter disabled */
            LucRetVal = E_OK;
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID, PROTOCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_031]:[Gen5GW_ProtoConv_UD_13_031]
* Function name: CheckVlanId
* Description  : Filter by source VLAN ID
* Arguments    : usVlanId -
*                    Vlan ID
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType CheckVlanId(const uint16 usVlanId)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* Check if filter is enabled */
    if ((uint32)NUM0 < (uint32)ProtoConv_GstFilterCfg.usVlanIdFilterNum)
    {
        /* Scan the filter table */
        LucRetVal = E_NOT_OK;
        for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)ProtoConv_GstFilterCfg.usVlanIdFilterNum; LulFilterIdx++)
        {
            if ((uint32)usVlanId == (uint32)ProtoConv_GstFilterCfg.aaVlanId[LulFilterIdx])
            {
                /* Found VLANID */
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* Filter disabled */
        LucRetVal = E_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID, PROTOCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_032]:[Gen5GW_ProtoConv_UD_13_032]
* Function name: CheckStreamId
* Description  : Filter by source Stream ID
* Arguments    : *aaStreamId -
*                    Stream ID
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
static Std_ReturnType CheckStreamId(const uint32 *aaStreamId)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* Check if filter is enabled */
    if ((uint32)NUM0 < (uint32)ProtoConv_GstFilterCfg.usStreamIdFilterNum)
    {
        /* Scan the filter table */
        LucRetVal = E_NOT_OK;
        for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)ProtoConv_GstFilterCfg.usStreamIdFilterNum; LulFilterIdx++)
        {
            if ((aaStreamId[IDX_0] == ProtoConv_GstFilterCfg.aaStreamId[LulFilterIdx].aaStreamId[IDX_0])
            &&  (aaStreamId[IDX_1] == ProtoConv_GstFilterCfg.aaStreamId[LulFilterIdx].aaStreamId[IDX_1]))
            {
                /* Found StreamID */
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* Filter disabled */
        LucRetVal = E_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID, PROTOCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_007]:[Gen5GW_ProtoConv_UD_13_007]
* Function Name: PayloadUnpackAndSend
* Description  : Unpack the CAN/LIN/Port frame from the payload section and send it by CAN/LIN/Port.
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP Payload length
*                blIPDUMCheck -
*                    IPDU-M Packing format check (for IP/UDP + IPDU-M format)
*                pSendStatus -
*                    Packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType PayloadUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen,
                             const boolean blIPDUMCheck, uint32 *pSendStatus)
{
    ProtoConv_PacketInfo         LstPacketInfo;
    R_ProtoConv_PduEthtoXType    LenPduConvMsn;
    Std_ReturnType               LucRetVal;
    uint32                       LulNewId;
    uint32                       LulDataPosition;
    uint32                       LulMsgFirstWord;
    uint32                       LulAddInfo;
    uint8                        LucDestBusIdx;
    
    LucRetVal = E_OK;
    LulDataPosition = NUM0;

    /* Initialize Packet info */
    LstPacketInfo.ulUnpackNum = NUM0;
    LstPacketInfo.ulSendStatus = NUM0;
    LstPacketInfo.ucErrorStatus = NUM0;
    LstPacketInfo.blLinSendStatus = (boolean)NUM0;
    LstPacketInfo.blPortSendStatus = (boolean)NUM0;

    while ((LulDataPosition < ulPayloadLen) &&
           ((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LstPacketInfo.ucErrorStatus))
    {
        ProtoConv_UtilMemCpy(&LulMsgFirstWord, &pPayload[LulDataPosition], sizeof(LulMsgFirstWord));
        #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
        ProtoConv_UtilEndianConv32(&LulMsgFirstWord);
        #endif
        if ((boolean)NUM1 == blIPDUMCheck)
        {
            /* IP/UDP + IPDU-M Packing format */
            LucRetVal = IPDUMPayloadUnpackAndSend(pPayload, ulPayloadLen, LulMsgFirstWord,
                                                  &LulDataPosition, &LstPacketInfo);
        }
        else
        {
            /* Check if the configured PDU ID is found*/
            LucRetVal = SearchPduEthtoXTbl(LulMsgFirstWord, &LulNewId, &LenPduConvMsn, &LucDestBusIdx, &LulAddInfo);
            if (((uint32)PORT_PDU_ID == LulMsgFirstWord)
            ||  ((uint8)E_OK == LucRetVal))
            {
                /* IPDU-M Packing format */
                LucRetVal = IPDUMPayloadUnpackAndSend(pPayload, ulPayloadLen, LulMsgFirstWord,
                                                      &LulDataPosition, &LstPacketInfo);
            }
            else
            {
                /* ACF messages */
                LucRetVal = ACFPayloadUnpackAndSend(pPayload, ulPayloadLen, LulMsgFirstWord,
                                                    &LulDataPosition, &LstPacketInfo);
            }
        }
    }

    /*
     * If the ACF message unpacking is not an error termination and
     * the ACF message unpacking is not 0, it is success.
     */
    if (((uint8)E_OK == LucRetVal) ||
        ((uint8)PROTOCONV_E_NOTFRAME == LstPacketInfo.ucErrorStatus))
    {
        if (((uint32) NUM0 == LstPacketInfo.ulSendStatus) &&
            ((boolean)NUM0 == LstPacketInfo.blLinSendStatus) &&
            ((boolean)NUM0 == LstPacketInfo.blPortSendStatus))
        {
            if ((uint32)NUM0 != LstPacketInfo.ulUnpackNum)
            {
                /* Since the message has been unpacked, it ends normally */
                LucRetVal = E_OK;
            }
            else
            {
                #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                      PROTOCONV_E_PACKEDMSG);
                #endif
                /* If the message is not unpacked, it will end with an error */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_TRANS);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    *pSendStatus = LstPacketInfo.ulSendStatus;

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_033]:[Gen5GW_ProtoConv_UD_13_033]
* Function Name: ACFPayloadUnpackAndSend
* Description  : Unpack the CAN/LIN/Port frame in ACF format from the payload section and send it by CAN/LIN/Port.
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP Payload length
*                ulMsgFirstWord -
*                    First 4 byte of the unpacked message
*                pDataPosition -
*                    Payload Data Position
*                pPacketInfo -
*                    Packet Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType ACFPayloadUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen,
          const uint32 ulMsgFirstWord, uint32 *pDataPosition, ProtoConv_PacketInfo *pPacketInfo)
{
    uint8                     *LpPortData;
    R_ProtoConv_CanFrameType   LstCanFrame;
    R_ProtoConv_LinFrameType   LstLinFrame;
    ProtoConv_CanMsgInfoType   LstCanMsgInfo;
    ProtoConv_LinMsgInfoType   LstLinMsgInfo;
    Std_ReturnType             LucRetVal;
    uint32                     LulUnpackedNum;
    uint32                     LulDataPosition;
    uint32                     LulMsgInfo;
    uint32                     LulSendStatus;
    uint16                     LusPortLength;
    uint8                      LucFormatType;
    uint8                      LucErrorStatus;
    boolean                    LblLinSendStatus;
    boolean                    LblPortSendStatus;
    
    LucRetVal = E_OK;

    /* Initialize Packet info */
    LulDataPosition   = *pDataPosition;
    LulUnpackedNum    = pPacketInfo->ulUnpackNum;
    LulSendStatus     = pPacketInfo->ulSendStatus;
    LucErrorStatus    = pPacketInfo->ucErrorStatus;
    LblLinSendStatus  = pPacketInfo->blLinSendStatus;
    LblPortSendStatus = pPacketInfo->blPortSendStatus;

    LusPortLength = NUM0;
    LpPortData = ProtoConv_GaaPortTxBuf;

    LucFormatType = (uint8)((ulMsgFirstWord >> (uint32)SHIFT_25BIT));
    switch (LucFormatType)
    {
    case ACF_CAN:
        /* Fall through */
    case ACF_CAN_BRIEF:
        LucRetVal = ProtoConv_UnpackCan(pPayload, ulPayloadLen, &LulDataPosition,
                                        &LstCanFrame, &LstCanMsgInfo, &LucErrorStatus);
        if (((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LucErrorStatus))
        {
            LulUnpackedNum++;
            /* Send CAN frame */
            LucRetVal = SendCanFrame(&LstCanFrame, &LulSendStatus, &LstCanMsgInfo, &LucErrorStatus);
            if (((uint8)E_NOT_OK == LucRetVal) && ((uint8)PROTOCONV_E_TRANS == LucErrorStatus))
            {
                /*
                 *   In case User defined transmit function return error, continue to unpack.
                 *   Error occur if LulSendStatus is not 0.
                 */
                LucRetVal = E_OK;
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    case ACF_LIN:
        LucRetVal = ProtoConv_UnpackLin(pPayload, ulPayloadLen, &LulDataPosition,
                                        &LstLinFrame, &LstLinMsgInfo, &LucErrorStatus);
        if (((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LucErrorStatus))
        {
            LulUnpackedNum++;
            /* Send LIN frame */
            LucRetVal = SendLinFrame(LstLinMsgInfo.usSrcBusIdx, &LstLinFrame, &LucErrorStatus);
            if ((((uint8)E_NOT_OK == LucRetVal)) && ((uint8)PROTOCONV_E_TRANS == LucErrorStatus))
            {
                /*
                 *   In case User defined transmit function return error, continue to unpack.
                 *   Error occur if LucLinSendStatus is not 0.
                 */
                LucRetVal = E_OK;
                LblLinSendStatus = (NUM1 != 0U);
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    case ACF_PARALLEL:
        /* If the next message is PORT, continue to buffer PORT data until done reading all PORT messages */
        /* If it overflows when adding one more minimmum Port message */
        while(((uint8)ACF_PARALLEL == LucFormatType) &&
              ((uint16)MAX_PORT_TOTAL_SIZE > (LusPortLength + NUM1)) &&
              ((uint8)E_OK == LucRetVal))
        {
            LucRetVal = ProtoConv_UnpackPort(pPayload, ulPayloadLen,
                                             &LulDataPosition, &LusPortLength, &LucErrorStatus);
            /*Get the ACF type of the next message */                
            ProtoConv_UtilMemCpy(&LulMsgInfo, &pPayload[LulDataPosition], sizeof(LulMsgInfo));
            #if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
            ProtoConv_UtilEndianConv32(&LulMsgInfo);
            #endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */
            LucFormatType = (uint8)((LulMsgInfo >> (uint32)SHIFT_25BIT));
        }

        if (((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LucErrorStatus))
        {
            LulUnpackedNum++;
            LpPortData = &ProtoConv_GaaPortTxBuf[IDX_0];
            /* Send Port Data */
            LucRetVal = ProtoConv_PortTransmitUserDef(LusPortLength, LpPortData);
            /* Reset Data Length after sending Port Data */
            LusPortLength = NUM0;
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /*
                 *   In case User defined transmit function return error, continue to unpack.
                 *   Error occur if LucPortSendStatus is not 0.
                 */
                LucRetVal = E_OK;
                LblPortSendStatus = (NUM1 != 0U);
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    default:
        #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                              PROTOCONV_E_CFG_ACFTYPE);
        #endif
        LucRetVal = E_NOT_OK;
        break;
    }

    /* Update Packet info */
    *pDataPosition = LulDataPosition;
    pPacketInfo->ulUnpackNum      = LulUnpackedNum;
    pPacketInfo->ulSendStatus     = LulSendStatus;
    pPacketInfo->ucErrorStatus    = LucErrorStatus;
    pPacketInfo->blLinSendStatus  = LblLinSendStatus;
    pPacketInfo->blPortSendStatus = LblPortSendStatus;

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_035]:[Gen5GW_ProtoConv_UD_13_035]
* Function Name: SendCanFrame
* Description  : Send CAN frame in ACF format
* Arguments    : *pCanFrame -
*                    CAN frame data
*                *pSendStatus -
*                    Can packet send status
*                *pCanMsgInfo -
*                    CAN message information
*                *pErrorStatus -
*                    Error status of CAN packet tranmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendCanFrame(const R_ProtoConv_CanFrameType *pCanFrame, uint32 *pSendStatus,
                                   const ProtoConv_CanMsgInfoType *pCanMsgInfo, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint8  LucDestBusIdx;
    uint32 LulAddInfo;
    uint32 LulSendStatusMask;
    R_ProtoConv_TimeStampType LstTimeStamp;

    LstTimeStamp.ulSecond = pCanMsgInfo->ulSecond;
    LstTimeStamp.ulNanosecond = pCanMsgInfo->ulNanosecond;

    /* Find the CAN frame destination in the CAN routing table. */
    LucRetVal = ProtoConv_SearchCanRoutTbl(pCanFrame, &LucDestBusIdx, &LulAddInfo);

    if ((uint8)E_OK == LucRetVal)
    {
        /* Check Can Packet Send Guard */
        LulSendStatusMask = (((uint32)NUM1 << (uint32)LucDestBusIdx));
        if ((uint32)NUM0 != (GulSendStatus & LulSendStatusMask))
        {
            /* If the destination exists, send it with a user-defined function. */
            /* If CAN frame is CAN/CANFD with TimeStamp (CAN/CAN FD ACF frame with mtv bit = 1)*/
            if (((uint8)ACF_CAN == pCanMsgInfo->ucFormatType) && ((boolean)NUM1 == pCanMsgInfo->blMtv))
            {
                LucRetVal = (uint8)ProtoConv_CanTransmitTSUserDef(pCanFrame, LucDestBusIdx,
                                   pCanMsgInfo->ucSrcBusIdx, LulAddInfo, &LstTimeStamp);
            }
            /*
             *   If CAN frame is CAN/CANFD without TimeStamp (Abbreviated ACF CAN/CAN FD ACF frame with mtv bit = 0)
             *   pCanMsgInfo member is set internally so no need to check range
             */
            else
            {
                LucRetVal = (uint8)ProtoConv_CanTransmitUserDef(pCanFrame, LucDestBusIdx,
                                   pCanMsgInfo->ucSrcBusIdx, LulAddInfo);
            }

            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                *pSendStatus |= ((uint32)NUM1 << (uint32)LucDestBusIdx);
                *pErrorStatus = PROTOCONV_E_TRANS;
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /*
         *   If the destination is not found,
         *   notify by the user-defined function of inter-core communication
         */

        /* If CAN frame is CAN/CANFD with TimeStamp (CAN/CAN FD ACF frame with mtv bit = 1)*/
        if (((uint8)ACF_CAN == pCanMsgInfo->ucFormatType) && ((boolean)NUM1 == pCanMsgInfo->blMtv))
        {
            LucRetVal = (uint8)ProtoConv_CanNotifyTSUserDef(pCanFrame, pCanMsgInfo->ucSrcBusIdx, &LstTimeStamp);
        }
        /*
         *   If CAN frame is CAN/CANFD without TimeStamp (Abbreviated ACF CAN/CAN FD ACF frame with mtv bit = 0)
         *   pCanMsgInfo member is set internally so no need to check range
         */
        else
        {
            LucRetVal = (uint8)ProtoConv_CanNotifyUserDef(pCanFrame, pCanMsgInfo->ucSrcBusIdx);
        }

        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_BSWNOTIFY);
            #endif
            *pErrorStatus = PROTOCONV_E_BSWNOTIFY;
            LucRetVal = E_NOT_OK;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_036]:[Gen5GW_ProtoConv_UD_13_036]
* Function Name: SendPduCanFrame
* Description  : Send CAN frame in IPDU-M format
* Arguments    : *pCanFrame -
*                    CAN frame data
*                ucDestBusIdx -
*                    Destination Bus ID
*                ulAddInfo -
*                    Additional Information
*                *pSendStatus -
*                    Status of CAN packet tranmission
*                *pErrorStatus -
*                    Error status of CAN packet tranmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendPduCanFrame(const R_ProtoConv_CanFrameType *pCanFrame, uint8 ucDestBusIdx, uint32 ulAddInfo,
    uint32 *pSendStatus, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint32 LulSendStatusMask;

	LucRetVal = E_OK;

    /* Check Can Packet Send Guard */
    LulSendStatusMask = (((uint32)NUM1 << (uint32)ucDestBusIdx));
    if ((uint32)NUM0 != (GulSendStatus & LulSendStatusMask))
    {             
        LucRetVal = (uint8)ProtoConv_CanTransmitUserDef(pCanFrame, ucDestBusIdx, NUM0, ulAddInfo);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            *pSendStatus |= ((uint32)NUM1 << (uint32)ucDestBusIdx);
            *pErrorStatus = PROTOCONV_E_TRANS;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_037]:[Gen5GW_ProtoConv_UD_13_037]
* Function Name: SendLinFrame
* Description  : Send LIN frame
* Arguments    : ucSrcBusIdx -
*                    Source Bus ID
*                *pLinFrame -
*                    LIN frame
*                *pErrorStatus -
*                    Error status of LIN packet tranmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendLinFrame(const uint8 ucSrcBusIdx,
   const R_ProtoConv_LinFrameType *pLinFrame, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;
    uint8  LucDestBusIdx;
    uint32 LulAddInfo;

    /* Find the LIN frame destination in the LIN routing table. */
    LucRetVal = ProtoConv_SearchLinRoutTbl(pLinFrame, &LucDestBusIdx, &LulAddInfo);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Note: Check Lin Packet Send Guard is not necessary */
        /* If the destination exists, send it with a user-defined function. */
        LucRetVal = (uint8)ProtoConv_LinTransmitUserDef(pLinFrame, LucDestBusIdx, LulAddInfo);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            *pErrorStatus = PROTOCONV_E_TRANS;
        }
    }
    else
    {
        /*
         *   If the destination is not found,
         *   notify by the user-defined function of inter-core communication
         */
        LucRetVal = (uint8)ProtoConv_LinNotifyUserDef(pLinFrame, ucSrcBusIdx);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_BSWNOTIFY);
            #endif
            *pErrorStatus = PROTOCONV_E_BSWNOTIFY;
            LucRetVal = E_NOT_OK;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_038]:[Gen5GW_ProtoConv_UD_13_038]
* Function Name: SendPduLinFrame
* Description  : Send LIN frame in IPDU-M format
* Arguments    : *pLinFrame -
*                    LIN frame
*                ucDestBusIdx -
*                    Destination Bus ID
*                ulAddInfo -
*                    Additional Information
*                *pErrorStatus -
*                    Error status of LIN packet tranmission
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SendPduLinFrame(const R_ProtoConv_LinFrameType *pLinFrame,
   uint8 ucDestBusIdx, uint32 ulAddInfo, uint8 *pErrorStatus)
{
    Std_ReturnType LucRetVal;

    /* Note: Check Lin Packet Send Guard is not necessary */
    /* If the destination exists, send it with a user-defined function. */
    LucRetVal = (uint8)ProtoConv_LinTransmitUserDef(pLinFrame, ucDestBusIdx, ulAddInfo);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        *pErrorStatus = PROTOCONV_E_TRANS;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_039]:[Gen5GW_ProtoConv_UD_13_039]
* Function Name: SearchPduEthtoXTbl
* Description  : Search IPDU-M Ethernet to CAN/LIN Routing Table.
* Arguments    : *pCanFrame -
*                    CAN frame
*                *pUnit-
*                    Destination UNIT number
*                *pCh -
*                    Destination CHANNEL number
*                *pAddInfo -
*                    Additional Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType SearchPduEthtoXTbl(const uint32 ulPduId, uint32 *pNewId,
   R_ProtoConv_PduEthtoXType *pPduConvMsn, uint8 *pDestBusIdx, uint32 *pAddInfo)
{
    const R_ProtoConv_PduEthtoXSubTblType *LpPduEthtoXSubTbl;
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulLeftIdx; /* start key of index */
    uint32 LulRightIdx; /* end key of index */
    uint32 LulCenterIdx; /* middle key of index */
    uint32 LulTargetPduId; /* search value */
    uint32 LulCenterStartValue; /* table in middle value */
    uint32 LulCenterEndValue; /* table in middle value */
    uint32 LulEthtoXSubTblEntryIdx;

    LulEntryIdx = IDX_0;
    LulLeftIdx = IDX_0;
    LulRightIdx = ProtoConv_GulPduEthtoXMainTblNum;
    LulTargetPduId = ulPduId;

    LucRetVal = E_NOT_OK;

    /* Binary search */
    while(LulLeftIdx <= LulRightIdx) {
        LulCenterIdx = (LulLeftIdx + LulRightIdx) / NUM2; /* calc of middle key */
        LulCenterStartValue = ProtoConv_GstPduEthtoXMainTbl[LulCenterIdx].ulPduId;
        LulCenterEndValue = LulCenterStartValue + ProtoConv_GstPduEthtoXMainTbl[LulCenterIdx].ulPduEthtoXSubTblEntryNum;
        if ((LulCenterStartValue <= LulTargetPduId) && (LulTargetPduId < LulCenterEndValue)) {
            /* Entry found and save index */
            LulEntryIdx = LulCenterIdx;
            LucRetVal = E_OK;
            break;
        } else if (LulCenterStartValue < LulTargetPduId) {
            LulLeftIdx = LulCenterIdx + NUM1; /* adjustment of left(start) key */
        } else {
            LulRightIdx = LulCenterIdx - NUM1; /* adjustment of right(end) key */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LpPduEthtoXSubTbl = ProtoConv_GstPduEthtoXMainTbl[LulEntryIdx].pPduEthtoXSubTbl;
        LulEthtoXSubTblEntryIdx = LulTargetPduId - LulCenterStartValue;

        *pNewId = LpPduEthtoXSubTbl[LulEthtoXSubTblEntryIdx].ulNewId;
        *pPduConvMsn = LpPduEthtoXSubTbl[LulEthtoXSubTblEntryIdx].enPduConvMsn;
        *pDestBusIdx = LpPduEthtoXSubTbl[LulEthtoXSubTblEntryIdx].ucDestBusIdx;
        *pAddInfo =LpPduEthtoXSubTbl[LulEthtoXSubTblEntryIdx].ulAddInfo;
    }
    else
    {
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_ProtoConv_CD_13_034]:[Gen5GW_ProtoConv_UD_13_034]
* Function Name: IPDUMPayloadUnpackAndSend
* Description  : Unpack the CAN/LIN/Port frame in IPDU-M format from the payload section and send it by CAN/LIN/Port.
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP Payload length
*                ulMsgFirstWord -
*                    First 4 byte of the unpacked message
*                pDataPosition -
*                    Payload Data Position
*                pPacketInfo -
*                    Packet Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
static Std_ReturnType IPDUMPayloadUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen,
          const uint32 ulMsgFirstWord, uint32 *pDataPosition, ProtoConv_PacketInfo *pPacketInfo)
{
    uint8                       *LpPortData;
    R_ProtoConv_PduEthtoXType    LenPduConvMsn;
    R_ProtoConv_CanFrameType     LstCanFrame;
    R_ProtoConv_LinFrameType     LstLinFrame;
    Std_ReturnType               LucRetVal;
    uint32                       LulUnpackedNum;
    uint32                       LulDataPosition;
    uint32                       LulPduId;
    uint32                       LulNewId;
    uint32                       LulSendStatus;
    uint32                       LulAddInfo;
    uint16                       LusPortLength;
    uint8                        LucDestBusIdx;
    uint8                        LucErrorStatus;
    boolean                      LblLinSendStatus;
    boolean                      LblPortSendStatus;
    
    LucRetVal = E_OK;

    /* Initialize Packet info */
    LulDataPosition   = *pDataPosition;
    LulUnpackedNum    = pPacketInfo->ulUnpackNum;
    LulSendStatus     = pPacketInfo->ulSendStatus;
    LucErrorStatus    = pPacketInfo->ucErrorStatus;
    LblLinSendStatus  = pPacketInfo->blLinSendStatus;
    LblPortSendStatus = pPacketInfo->blPortSendStatus;

    LusPortLength = NUM0;
    LpPortData = ProtoConv_GaaPortTxBuf;
    LulPduId = ulMsgFirstWord;

    if ((uint32)PORT_PDU_ID == LulPduId)
    {
        /* IPDU-M PORT messages */
        LucRetVal = ProtoConv_UnpackPortIPDUM(pPayload, ulPayloadLen,
                                              &LulDataPosition, &LusPortLength, &LucErrorStatus);
        if (((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LucErrorStatus))
        {
            LulUnpackedNum++;
            LpPortData = &ProtoConv_GaaPortTxBuf[IDX_0];
            /* Send Port Data */
            LucRetVal = ProtoConv_PortTransmitUserDef(LusPortLength, LpPortData);
            /* Reset Data Length after sending Port Data */
            LusPortLength = NUM0;
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                /*
                 *   In case User defined transmit function return error, continue to unpack.
                 *   Error occur if LucPortSendStatus is not 0.
                 */
                LucRetVal = E_OK;
                LblPortSendStatus = (NUM1 != 0U);
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        LucRetVal = SearchPduEthtoXTbl(LulPduId, &LulNewId, &LenPduConvMsn, &LucDestBusIdx, &LulAddInfo);
        if ((uint8)E_OK == LucRetVal)
        {
            switch (LenPduConvMsn)
            {
            case PROTOCONV_PDUETHTOCAN:
                /* Convert PDU ID to CAN ID */
                LstCanFrame.ulCanId = LulNewId;
                LucRetVal = ProtoConv_UnpackCanIPDUM(pPayload, ulPayloadLen,
                                                    &LulDataPosition, &LstCanFrame, &LucErrorStatus);
                if (((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LucErrorStatus))
                {
                    LulUnpackedNum++;
                    /* Send CAN frame */
                    LucRetVal = SendPduCanFrame(&LstCanFrame, LucDestBusIdx,
                                                LulAddInfo, &LulSendStatus, &LucErrorStatus);
                    if (((uint8)E_NOT_OK == LucRetVal) && ((uint8)PROTOCONV_E_TRANS == LucErrorStatus))
                    {
                        /*
                         *   In case User defined transmit function return error, continue to unpack.
                         *   Error occur if LulSendStatus is not 0.
                         */
                        LucRetVal = E_OK;
                    }
                    else
                    {
                        /* Do nothing */
                    }
                }
                else
                {
                    /* Do nothing */
                }
                break;
            case PROTOCONV_PDUETHTOLIN:
                /* Convert PDU ID to LIN ID */
                LstLinFrame.ucPId = (uint8)(LulNewId & MASK_8BIT);
                LucRetVal = ProtoConv_UnpackLinIPDUM(pPayload, ulPayloadLen,
                                                     &LulDataPosition, &LstLinFrame, &LucErrorStatus);
                if (((uint8)E_OK == LucRetVal) && ((uint8)PROTOCONV_E_NOTFRAME != LucErrorStatus))
                {
                    LulUnpackedNum++;
                    /* Send LIN frame with Source Bus Index 0 */
                    LucRetVal = SendPduLinFrame(&LstLinFrame, LucDestBusIdx, LulAddInfo, &LucErrorStatus);
                    if ((((uint8)E_NOT_OK == LucRetVal)) && ((uint8)PROTOCONV_E_TRANS == LucErrorStatus))
                    {
                        /*
                         *   In case User defined transmit function return error, continue to unpack.
                         *   Error occur if LucLinSendStatus is not 0.
                         */
                        LucRetVal = E_OK;
                        LblLinSendStatus = (NUM1 != 0U);
                    }
                    else
                    {
                        /* Do nothing */
                    }
                }
                else
                {
                    /* Do nothing */
                }
                break;
            default:
                /* Do nothing */
                LucRetVal = E_OK;
                break;
            }
        }
        else
        {
            /* It cannot be converted to either format. */
            #if (PROTOCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(PROTOCONV_MODULE_ID, PROTOCONV_INSTANCE_ID, R_PROTOCONV_ETHTOX_SID,
                                  PROTOCONV_E_PACKEDMSG);
            #endif
        }
    }

    /* Update Packet info */
    *pDataPosition = LulDataPosition;
    pPacketInfo->ulUnpackNum      = LulUnpackedNum;
    pPacketInfo->ulSendStatus     = LulSendStatus;
    pPacketInfo->ucErrorStatus    = LucErrorStatus;
    pPacketInfo->blLinSendStatus  = LblLinSendStatus;
    pPacketInfo->blPortSendStatus = LblPortSendStatus;

    return LucRetVal;
}

#define PROTOCONV_STOP_SEC_PRIVATE_CODE
#include "ProtoConv_MemMap.h"
