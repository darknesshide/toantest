/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to CAN Conversion function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_ETHTOCAN_H
#define CDD_PROTOCONV_ETHTOCAN_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/* CAN message info*/
typedef struct
{
    uint8   ucFormatType;
    uint16  usACFLength;
    uint8   ucPad;
    boolean blMtv;
    boolean blEFF;
    boolean blFDF;
    uint8   ucSrcBusIdx;
    uint32  ulSecond;
    uint32  ulNanosecond;
} ProtoConv_CanMsgInfoType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
extern uint32 GulSendStatus;
extern uint32 ProtoConv_GulEthtoCanMainTblNum;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
extern const R_ProtoConv_EthtoCanMainTblType *ProtoConv_GstEthtoCanMainTbl;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern Std_ReturnType ProtoConv_UnpackCan(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_CanFrameType *pCanFrame, ProtoConv_CanMsgInfoType *pCanMsgInfo, uint8 *pErrorStatus);

extern Std_ReturnType ProtoConv_UnpackCanIPDUM(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_CanFrameType *pCanFrame, uint8 *pErrorStatus);

extern Std_ReturnType ProtoConv_SearchCanRoutTbl(const R_ProtoConv_CanFrameType *pCanFrame,
    uint8 *pDestBusIdx, uint32 *pAddInfo);

extern void ProtoConv_GetSendStatus(uint32 *pStatus);

extern void ProtoConv_UpdateSendStatus(const uint32 ulStatus);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_ETHTOCAN_H */
