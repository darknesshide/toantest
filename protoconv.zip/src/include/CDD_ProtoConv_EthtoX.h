/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to CAN/LIN/Port Conversion function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_ETHTOX_H
#define CDD_PROTOCONV_ETHTOX_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* Ethernet Rx Buffer */
typedef struct
{
    uint16 usFrameType;
    uint32 ulFrameLen;
    uint8 *aaPayload;
} ProtoConv_EthRxBufType;

/* Packet Information structure to reduce the number of parameter */
typedef struct
{
    uint32 ulUnpackNum;
    uint32 ulSendStatus;
    uint8  ucErrorStatus;
    boolean blLinSendStatus;
    boolean blPortSendStatus;
} ProtoConv_PacketInfo;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
/*  CAN Tx Buffer */
extern uint8 *ProtoConv_GaaCanTxBuf;
/*  LIN Tx Buffer */
extern uint8 *ProtoConv_GaaLinTxBuf;
/*  PORT Tx Buffer */
extern uint8 *ProtoConv_GaaPortTxBuf;
/* Ethernet Rx Buffer */
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
extern ProtoConv_EthRxBufType ProtoConv_GstEthRxBuf;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
extern uint32 ProtoConv_GulEthRxBufSize;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern Std_ReturnType ProtoConv_EthtoX(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
                           const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus);

extern void ProtoConv_EthtoXInit(const R_ProtoConv_CfgType *pConfig);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_ETHTOX_H */
