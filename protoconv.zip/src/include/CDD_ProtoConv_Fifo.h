/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the FIFO managment function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_FIFO_H
#define CDD_PROTOCONV_FIFO_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
typedef struct
{
    R_ProtoConv_CanFrameType stCanFrame[PROTOCONV_CAN_FIFO_DEPTH];
    R_ProtoConv_TimeStampType stTimeStamp[PROTOCONV_CAN_FIFO_DEPTH];
    uint8 aaCanData[PROTOCONV_CAN_FIFO_DEPTH][CANFRAME_LEN_MAX];
    uint32 ulHead;
    uint32 ulTail;
    uint32 ulFlag;
} R_ProtoConv_CanFifoType;

typedef struct
{
    R_ProtoConv_LinFrameType stLinFrame[PROTOCONV_LIN_FIFO_DEPTH];
    uint8 aaLinData[PROTOCONV_LIN_FIFO_DEPTH][LINFRAME_LEN_MAX];
    uint32 ulHead;
    uint32 ulTail;
    uint32 ulFlag;
} R_ProtoConv_LinFifoType;

typedef struct
{
    uint16 usLength;
    uint8  aaPortData[MAX_PORT_TOTAL_SIZE];
    uint32 ulDestIdx;
    uint32 ulHead;
    uint32 ulTail;
    uint32 ulFlag;
} R_ProtoConv_PortFifoType;

typedef struct
{
    uint8 aaSrcMacAddr[MACADDR_LEN_IN_BYTE];
    uint16 usFrameType;
    uint32 ulFrameLen;
    uint8 *pEthFrame;
} R_ProtoConv_EthFrameType;

typedef struct
{
    R_ProtoConv_EthFrameType stEthFrame[PROTOCONV_ETH_FIFO_DEPTH];
    uint8 aaEthData[PROTOCONV_ETH_FIFO_DEPTH][ETH_FRAME_SIZE_MAX];
    uint32 ulHead;
    uint32 ulTail;
    uint32 ulFlag;
} R_ProtoConv_EthFifoType;

typedef enum
{
    PROTOCONV_FIFO_EMPTY,
    PROTOCONV_FIFO_AVAILABLE,
    PROTOCONV_FIFO_FULL
} R_ProtoConv_FifoFlagType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
extern uint32 GulCanFifoCount[PROTOCONV_CAN_CH_NUM];
extern uint32 GulLinFifoCount[PROTOCONV_LIN_CH_NUM];
extern uint32 GulPortFifoCount;
extern uint32 GulEthFifoCount;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
extern R_ProtoConv_CanFifoType GstCanFifo[PROTOCONV_CAN_CH_NUM];
extern R_ProtoConv_LinFifoType GstLinFifo[PROTOCONV_LIN_CH_NUM];
extern R_ProtoConv_PortFifoType GstPortFifo;
extern R_ProtoConv_EthFifoType GstEthFifo;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern void ProtoConv_FifoInit(void);

extern Std_ReturnType ProtoConv_EnqueueCan(const uint8 ucBusIdx, const R_ProtoConv_CanFrameType *pCanFrame,
    const R_ProtoConv_TimeStampType *pTimeStamp);

extern Std_ReturnType ProtoConv_EnqueueLin(const uint8 ucBusIdx, const R_ProtoConv_LinFrameType *pLinFrame);

extern Std_ReturnType ProtoConv_EnqueuePort(const uint16 usLength, const uint8 *pPortData, const uint32 ulDestIdx);

extern Std_ReturnType ProtoConv_EnqueueEth(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
    const uint8 *pEthFrame, const uint32 ulFrameLen);

extern Std_ReturnType ProtoConv_DequeueEth(uint16 *pFrameType, uint8 **aaSrcMacAddr,
    uint8 **pEthFrame, uint32 *pFrameLen);

extern Std_ReturnType ProtoConv_TriggerQueueDataXtoEth(void);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_FIFO_H */
