/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the CAN/LIN/Port to Ethernet Conversion function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_XTOETH_H
#define CDD_PROTOCONV_XTOETH_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* Buffer management structure to reduce the number of parameter */
typedef struct
{
    uint8  *pRxBufPtr;
    uint8  *pTxBufPtr;
    uint32 ulRxBufSize;
    uint32 ulRxBufLen;
    uint32 ulRxBufCount;
    uint32 ulTxBufIdx;
} ProtoConv_BufInfoType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
extern const R_ProtoConv_XtoEthDestTblType *ProtoConv_GstXtoEthDestRoutTbl;
extern uint8 *ProtoConv_GaaEthTxBuf;
extern uint8 *ProtoConv_GaaCanRxBuf;
extern uint8 *ProtoConv_GaaLinRxBuf;
extern uint8 *ProtoConv_GaaPortRxBuf;
extern uint8 *ProtoConv_GaaMixRxBuf[PROTOCONV_MIXBUF_MAX];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
extern uint32 ProtoConv_GulXtoEthDestTblNum;
extern uint32 ProtoConv_GulEthTxBufIdx;
extern uint32 ProtoConv_GulCanRxBufSize;
extern uint32 ProtoConv_GulCanRxBufLen;
extern uint32 ProtoConv_GulLinRxBufSize;
extern uint32 ProtoConv_GulLinRxBufLen;
extern uint32 ProtoConv_GulPortRxBufSize;
extern uint32 ProtoConv_GulPortRxBufLen;
extern uint32 ProtoConv_GulMixRxBufNum;
extern uint32 ProtoConv_GulMixRxBufSize[PROTOCONV_MIXBUF_MAX];
extern uint32 ProtoConv_GulMixRxBufLen[PROTOCONV_MIXBUF_MAX];
extern uint32 ProtoConv_GulMixCount[PROTOCONV_MIXBUF_MAX];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
extern R_ProtoConv_ConvCfgType ProtoConv_GstConvCfg;
extern R_ProtoConv_CantoEthMainTblGeneralType ProtoConv_GstCantoEthMainTblGeneral[PROTOCONV_CAN_CH_NUM];
extern R_ProtoConv_LintoEthMainTblGeneralType ProtoConv_GstLintoEthMainTblGeneral[PROTOCONV_LIN_CH_NUM];
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern Std_ReturnType ProtoConv_TriggerXtoEthTx(const uint32 ulBufIdx);

extern Std_ReturnType ProtoConv_CreateAndSendEthFrame(const uint32 ulEntryIdx, ProtoConv_BufInfoType *pBufInfo,
    const R_ProtoConv_HeaderType *pHeaderField);

extern void ProtoConv_XtoEthInit(const R_ProtoConv_CfgType *pConfig);
extern void ProtoConv_MixtoEthMain(void);

extern void ProtoConv_StorePdutoEthBufData(const uint32 ulPduId, const uint32 ulPduDlc,
    const uint8 *pPduData, ProtoConv_BufInfoType *pBufInfo);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_XTOETH_H */
