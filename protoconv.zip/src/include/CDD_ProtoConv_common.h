/***********************************************************************************************************************
* Copyright [2025, 2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 2.0.0
* Description  : This file contains the process used in the Protocol Conversion function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_COMMON_H
#define CDD_PROTOCONV_COMMON_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Length definition */
#define MACADDR_LEN_IN_BYTE             6U
/* Subtype field definition */
#define SUBTYPE_TSCF                    0x05U
#define SUBTYPE_NTSCF                   0x82U

/* CAN frame max length */
#define CANFRAME_LEN_MAX                64U
/* LIN frame max length */
#define LINFRAME_LEN_MAX                8U

/* Maximum Ethernet frame size */
#define ETH_FRAME_SIZE_MAX              1500UL
/* Minimum Ethernet frame size */
#define ETH_FRAME_SIZE_MIN              64UL
/* Minimum size of Ethernet frame payload */
#define ETH_FRAME_PAYLOAD_SIZE_MIN      46UL

/* LIN ID range */
#define LINID_MAX                       0x3FU

/* PORT Bit width minimum values */
/* When bid_width is 0, the number of valid bits in the payload field is 256 */
#define PORT_BIT_WIDTH_MIN              0U

/* CAN ID range */
#define CANID_BASE_MAX                  0x7FFU
#define CANID_EXTENDED_MIN              0x80000000U
#define CANID_EXTENDED_MAX              0x9FFFFFFFU
/* CANFD ID range */
#define CANFD_ID_BASE_MIN               0x40000000U
#define CANFD_ID_BASE_MAX               0x400007FFU
#define CANFD_ID_EXTENDED_MIN           0xC0000000U
#define CANFD_ID_EXTENDED_MAX           0xDFFFFFFFU

/* Common ACF field*/
#define MSG_TIMESTAMP                   8U

/* Message Type  */
#define ACF_CAN                         1U
#define ACF_CAN_BRIEF                   2U
#define ACF_LIN                         3U
#define ACF_PARALLEL                    7U
#define IPDUM_FORMAT                    78U

/* ACF CAN BRIEF Length  */
#define ACF_CAN_BRIEF_MSG_INFO_LEN      8U
/* ACF CAN Length  */
#define ACF_CAN_MSG_INFO_LEN            16U
/* ACF LIN Length  */
#define ACF_LIN_MSG_INFO_LEN            12U
/* The maximum value of ACF pad field */
#define ACF_PAD_SIZE_MAX                3U

/* ACF PORT Length  */
#define ACF_PORT_MSG_INFO_LEN           4U
/* Number of maximum ACF PORT messages */
#define MAX_ACF_PORT_MSG_NUM            8U
/* The maximum data length of 1 of PORT payload unit  */
#define MAX_PORT_UNIT_LEN               32U
/* The maximum payload length of 1 PORT message */
#define MAX_PORT_MSG_PAYLOAD            256U
/* The minimum size of PORT data: 1 byte */
#define MIN_PORT_TOTAL_SIZE             1U
/* The maximum size of PORT data */
#define MAX_PORT_TOTAL_SIZE             256U

#define QUADLETS_BYTES                  4U

/* PDU Frame Header Length */
#define PDU_LEN_ID                      4U
#define PDU_LEN_DLC                     4U

/* Length of CAN ID*/
#define CAN_LEN_ID                      4U

/* Header information */
#define CHECKSUM_ZERO                   0U
#define PROTOCOL_UDP                    0x11U

#define VER_AND_HEADERLEN_IPV4          0x45U
#define VER_CLASS_AND_LABEL_IPV6        0x60000000U
#define NOT_FRAGMENTED_IPV4             0x0000U
#define VERIFY_CKSUM                    0xFFFFU
#define REPLACE_UDPSUM                  (0xFFFFU)
#define MASK_FRAGMENT_MF_OFFSET         0x3FFFU
#define MASK_NTSCF_DATA_LENGTH          0x07FFU

/* Header length */
#define HEADER_LEN_ETH                  14U
#define FCS_LEN_ETH                     4U
#define HEADER_LEN_IPV4                 20U
#define HEADER_LEN_IPV6                 40U
#define HEADER_LEN_UDP                  8U
#define HEADER_LEN_SEQNUM               4U
#define HEADER_LEN_NTSCF                12U
#define HEADER_LEN_TSCF                 24U

/* Bit mask definition */
#define MASK_1BIT                       0x00000001UL
#define MASK_2BIT                       0x00000003UL
#define MASK_5BIT                       0x0000001FUL
#define MASK_8BIT                       0x000000FFUL
#define MASK_9BIT                       0x000001FFUL
#define MASK_12BIT                      0x00000FFFUL
#define MASK_16BIT                      0x0000FFFFUL
#define MASK_29BIT                      0x1FFFFFFFUL
#define MASK_32BIT                      0xFFFFFFFFUL
/* Bit Shift definition */
#define SHIFT_1BIT                      1UL
#define SHIFT_7BIT                      7UL
#define SHIFT_8BIT                      8UL
#define SHIFT_9BIT                      9UL
#define SHIFT_11BIT                     11UL
#define SHIFT_13BIT                     13UL
#define SHIFT_14BIT                     14UL
#define SHIFT_16BIT                     16UL
#define SHIFT_24BIT                     24UL
#define SHIFT_25BIT                     25UL
#define SHIFT_30BIT                     30UL
#define SHIFT_31BIT                     31UL

/* for utility function */
#define ALIGN4                          0x00000003UL
/* Constant definition */
#define NUM0                            0U
#define NUM1                            1U
#define NUM2                            2U
#define NUM3                            3U
#define NUM4                            4U
#define NUM8                            8U
#define NUM9                            9U
/* Array index definition */
#define IDX_0                           0U
#define IDX_1                           1U
#define IDX_2                           2U
#define IDX_3                           3U
#define IDX_4                           4U
#define IDX_5                           5U
/* gPTP Sec Unit */
#define GPTP_SECUNIT                    1000000000U

/* Default Common Packet Send Status */
#define PACKETSEND_DEFAULT              (0x3FFFUL)

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* IEEE802.1Q Header type */
typedef struct
{
  uint16 usVlanId;
  uint16 usFrameType;
} ProtoConv_IEEE8021QType;

/* IPv4 Header Configuration */
typedef struct
{
    uint8 ucVerAndHeaderLen;
    uint8 ucServiceType;
    uint16 usPktLen;
    uint16 usId;
    uint16 usFragment;
    uint8 ucTTL;
    uint8 ucProtocol;
    uint16 usChecksum;
    uint32 ulSrcIpAddr;
    uint32 ulDestIpAddr;
} ProtoConv_Ipv4HeaderType;

/* IPv6 Header Configuration */
typedef struct
{
    uint32 ulVerClassAndLabel;
    uint16 usPayloadLen;
    uint8 ucNextHeader;
    uint8 ucHopLimit;
    uint32 aaSrcIpAddr[PROTOCONV_IPADDR_LEN_IN_WORD];
    uint32 aaDestIpAddr[PROTOCONV_IPADDR_LEN_IN_WORD];
} ProtoConv_Ipv6HeaderType;

/* UDP Header Configuration */
typedef struct
{
    uint16 usSrcPort;
    uint16 usDestPort;
    uint16 usLen;
    uint16 usChecksum;
} ProtoConv_UdpHeaderType;

/* AVTP Common Header Configuration */
typedef struct
{
    uint8 ucSubType;
    uint8 ucHVer;
} ProtoConv_AVTPCommonType;

/* AVTP(NTSCF) Header Configuration */
typedef struct
{
    uint8 ucSubType;
    uint8 ucSvVerDataLenMSB;
    uint8 ucDataLenLSB;
    uint8 ucSeqNum;
    uint32 aaStreamId[PROTOCONV_STREAMID_LEN_IN_WORD];
} ProtoConv_NTSCFType;

/* AVTP(TSCF) Header Configuration */
typedef struct
{
    uint8 ucSubType;
    /* StreamIdValue(1bit) + Version(3bit) + Media clock Restart(1bit) + Reserve(2bit) + avtp_timestamp vali(1bit) */
    uint8 ucSvVerMrRsvTv;
    uint8 ucSeqNum;
    uint8 ucReserveTu;                  /* timestamp uncertain(1bit) */
    uint32 aaStreamId[PROTOCONV_STREAMID_LEN_IN_WORD];
    uint32 ulAvtpTimestamp;
    uint32 ulReserved1;
    uint16 usStreamDataLength;
    uint16 usReserved1;
} ProtoConv_TSCFType;

/* IPv4 Pseudo Header for Checksum calculation */
typedef struct
{
    uint32 ulSrcIpAddr;
    uint32 ulDestIpAddr;
    uint8 ucPadZero;
    uint8 ucProtocol;
    uint16 usDataLen;
} ProtoConv_Ipv4PseudoHeaderType;

/* IPv6 Pseudo Header for Checksum calculation */
typedef struct
{
    uint32 aaSrcIpAddr[PROTOCONV_IPADDR_LEN_IN_WORD];
    uint32 aaDestIpAddr[PROTOCONV_IPADDR_LEN_IN_WORD];
    uint32 ulPayloadLen;
    uint8  aaPadZero[NUM3];
    uint8  ucNextHeader;
} ProtoConv_Ipv6PseudoHeaderType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"
/* Source Address/Port Configuration */
extern R_ProtoConv_EthSrcCfgType ProtoConv_GstEthSrcCfg;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_PROTOCONV_COMMON_H */
