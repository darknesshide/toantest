/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Utility function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_UTIL_H
#define CDD_PROTOCONV_UTIL_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define PROTOCONV_LITTLE_ENDIAN    STD_ON

/* CAN-DLC Values */
#define PROTOCONV_DLC_8    (8U)
#define PROTOCONV_DLC_12   (12U)
#define PROTOCONV_DLC_16   (16U)
#define PROTOCONV_DLC_20   (20U)
#define PROTOCONV_DLC_24   (24U)
#define PROTOCONV_DLC_32   (32U)
#define PROTOCONV_DLC_48   (48U)
#define PROTOCONV_DLC_64   (64U)

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern void ProtoConv_UtilMemCpy(void *pDest, const void *pSrc, const uint32 ulSize);

extern void ProtoConv_UtilMemSet(void *pDest, const uint8 ucMyChar, const uint32 ulSize);

extern void ProtoConv_UtilCalcSum(const void *pBuf, const uint16 usBytes, uint32 *pSum);

extern void ProtoConv_UtilConvMacAddr8Bit(const uint32 *aaInputMacAddr, uint8 *aaOutputMacAddr);

#if (PROTOCONV_LITTLE_ENDIAN == STD_ON)
extern void ProtoConv_UtilEndianConv16(uint16 *pValue);
extern void ProtoConv_UtilEndianConv32(uint32 *pValue);
#endif /* (PROTOCONV_LITTLE_ENDIAN == STD_ON) */

extern Std_ReturnType ProtoConv_UtilCanIdCheck(const uint32 ulCanId);

extern Std_ReturnType ProtoConv_UtilCanDlcCheck(const uint32 ulCanDlc);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_UTIL_H */
