/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the Ethernet to LIN Conversion function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_ETHTOLIN_H
#define CDD_PROTOCONV_ETHTOLIN_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* LIN message info*/
typedef struct
{
    uint8   ucFormatType;
    uint16  usACFLength;
    uint8   ucPad;
    boolean blMtv;
    uint8   usSrcBusIdx;
} ProtoConv_LinMsgInfoType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define PROTOCONV_START_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"
/* Ethernet to LIN Routing Table */
extern uint32 ProtoConv_GulEthtoLinMainTblNum;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_32
#include "ProtoConv_MemMap.h"

#define PROTOCONV_START_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"
extern const R_ProtoConv_EthtoLinMainTblType *ProtoConv_GstEthtoLinMainTbl;
#define PROTOCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "ProtoConv_MemMap.h"

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern Std_ReturnType ProtoConv_SearchLinRoutTbl(const R_ProtoConv_LinFrameType *pLinFrame,
    uint8 *pDestBusIdx, uint32 *pAddInfo);

extern Std_ReturnType ProtoConv_UnpackLin(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_LinFrameType *pLinFrame, ProtoConv_LinMsgInfoType *pLinMsgInfo, uint8 *pErrorStatus);

extern Std_ReturnType ProtoConv_UnpackLinIPDUM(const uint8 *pPayload, const uint32 ulPayloadLen, uint32 *pDataPosition,
    R_ProtoConv_LinFrameType *pLinFrame, uint8 *pErrorStatus);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_ETHTOLIN_H */
