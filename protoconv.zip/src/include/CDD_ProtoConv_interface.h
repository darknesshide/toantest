/***********************************************************************************************************************
* Copyright [2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 1.0.0
* Description  : This file contains the process used in the User-Define function.
***********************************************************************************************************************/
#ifndef CDD_PROTOCONV_INTERFACE_H
#define CDD_PROTOCONV_INTERFACE_H

#include "rcar-xos/protoconv/CDD_ProtoConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define PROTOCONV_START_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

extern Std_ReturnType ProtoConv_EthTransmitUserDef(const uint8 *aaDestAddr, const uint16 usFrameType,
    const uint8 *pBufAddr, const uint32 ulDataSize);

extern Std_ReturnType ProtoConv_CanTransmitTSUserDef(const R_ProtoConv_CanFrameType *pCanFrame,
    const uint8 ucDestBusIdx, const uint8 ucSrcBusIdx,
    const uint32 ulAddInfo, const R_ProtoConv_TimeStampType *pTimeStamp);

extern Std_ReturnType ProtoConv_CanTransmitUserDef(const R_ProtoConv_CanFrameType *pCanFrame,
    const uint8 ucDestBusIdx, const uint8 ucSrcBusIdx, const uint32 ulAddInfo);

extern Std_ReturnType ProtoConv_CanNotifyTSUserDef(const R_ProtoConv_CanFrameType *pCanFrame, const uint8 ucSrcBusIdx,
    const R_ProtoConv_TimeStampType *pTimeStamp);

extern Std_ReturnType ProtoConv_CanNotifyUserDef(const R_ProtoConv_CanFrameType *pCanFrame, const uint8 ucSrcBusIdx);

extern Std_ReturnType ProtoConv_LinTransmitUserDef(const R_ProtoConv_LinFrameType *pLinFrame,
    const uint8 ucDestBusIdx, const uint32 ulAddInfo);

extern Std_ReturnType ProtoConv_LinNotifyUserDef(const R_ProtoConv_LinFrameType *pLinFrame, const uint8 ucSrcBusIdx);

extern Std_ReturnType ProtoConv_PortTransmitUserDef(const uint16 usLength, const uint8 *pPortData);

extern Std_ReturnType ProtoConv_GetTimeUserDef(uint16 *pSecHi, uint32 *pSec, uint32 *pnSec);

extern void ProtoConv_EnterCriticalUserDef(void);

extern void ProtoConv_ExitCriticalUserDef(void);

#define PROTOCONV_STOP_SEC_PUBLIC_CODE
#include "ProtoConv_MemMap.h"

#endif /* CDD_PROTOCONV_INTERFACE_H */
