/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Pack Library.
***********************************************************************************************************************/
#ifndef CDD_PACKLIB_H
#define CDD_PACKLIB_H

/* Include standard Autosar Type */
#include "Std_Types.h"
/*******************************************************************************
Version Information
*******************************************************************************/
#define CANETHCONV_VENDOR_ID           CANETHCONV_VENDOR_ID_VALUE
#define CANETHCONV_MODULE_ID           CANETHCONV_MODULE_ID_VALUE
#define CANETHCONV_INSTANCE_ID         CANETHCONV_INSTANCE_ID_VALUE

/* AUTOSAR Release Version Information */
#define CANETHCONV_AR_RELEASE_MAJOR_VERSION                               4U
#define CANETHCONV_AR_RELEASE_MINOR_VERSION                               9U
#define CANETHCONV_AR_RELEASE_REVISION_VERSION                            0U

/* File version information */
#define CANETHCONV_SW_MAJOR_VERSION                                       0U
#define CANETHCONV_SW_MINOR_VERSION                                       8U
#define CANETHCONV_SW_PATCH_VERSION                                       0U

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Service IDs
*******************************************************************************/
/* Service ID for R_PackLib_Init */
#define R_PACKLIB_INIT_SID                          (uint8)0x10U
/* Service ID for R_PackLib_SetCanData */
#define R_PACKLIB_SETCANDATA_SID                    (uint8)0x11U
/* Service ID for R_PackLib_GetPackData */
#define R_PACKLIB_GETPACKDATA_SID                   (uint8)0x12U
/* Service ID for R_PackLib_Unpack */
#define R_PACKLIB_UNPACK_SID                        (uint8)0x13U
/* Service ID for R_PackLib_SetCanXLData */
#define R_PACKLIB_SETCANXLDATA_SID                  (uint8)0x14U

/*******************************************************************************
DET Error Codes
*******************************************************************************/
/* DET code to report parameter error (argument is NULL Pointer) */
#define CANETHCONV_E_PARAM_POINTER                   (uint8)0x02U   /*  2U  */
/* DET code to report process error (API executed in uninitialized state) */
#define CANETHCONV_E_UNINIT                          (uint8)0x03U   /*  3U  */
/* DET code to report wrong parameter passed to the APIs */
#define CANETHCONV_E_INV_PARAM                       (uint8)0x04U   /*  4U  */
/* DET code to report invalid call */
#define CANETHCONV_E_ALREADY_INITIALIZED             (uint8)0x06U   /*  6U  */
/* DET code to report discrepancy error (Miss match with SW routing table value) */
#define CANETHCONV_E_MATCH                           (uint8)0x08U   /*  8U  */
/* DET code to report transmission error */
#define CANETHCONV_E_TRANS                           (uint8)0x09U   /*  9U  */
/* DET code to report API service called with wrong Data length */
#define CANETHCONV_E_PARAM_DATA_LENGTH               (uint8)0x0BU   /*  11U */
/* DET code to report Packed CAN Frame Error */
#define CANETHCONV_E_PACKEDCAN                       (uint8)0x0CU   /*  12U */
/* DET code to report IP Header Checksum Error */
#define CANETHCONV_E_IPCKSUM                         (uint8)0x0DU   /*  13U */
/* DET code to report UDP Header Checksum Error */
#define CANETHCONV_E_UDPCKSUM                        (uint8)0x0EU   /*  14U */
/* DET code to report Invalid CAN DLC */
#define CANETHCONV_E_NOTFRAME                        (uint8)0x0FU   /*  15U */
/* DET code to report BSW Notification Error */
#define CANETHCONV_E_BSWNOTIFY                       (uint8)0x10U   /*  16U */
/* DET code to report Filtered and discarded error */
#define CANETHCONV_E_FILTER                          (uint8)0x11U   /*  17U */
/* DET code to report configuration errors (overall)*/
#define CANETHCONV_E_CFG                             (uint8)0x14U   /*  20U */
/* DET code to report Config Error (CAN to Ethernet Routing Table) */
#define CANETHCONV_E_CFG_ETHTBL                      (uint8)0x32U   /*  50U */
/* DET code to report Config Error (Ethernet to CAN Routing Table) */
#define CANETHCONV_E_CFG_CANTBL                      (uint8)0x33U   /*  51U */
/* DET code to report Config Error (NULL Pointer) */
#define CANETHCONV_E_PARAM_CONFIG                    (uint8)0x3CU   /*  60U */
/* DET code to report Config Error (Conversion Mode)*/
#define CANETHCONV_E_CFG_CONVMODE                    (uint8)0x3DU   /*  61U */
/* DET code to report Config Error (Storable CAN Frame and Buffering Time)*/
#define CANETHCONV_E_CFG_LIMIT                       (uint8)0x3FU   /*  63U */
/* DET code to report Config Error (Ethernet Source Address)*/
#define CANETHCONV_E_CFG_ETHSRC                      (uint8)0x40U   /*  64U */
/* DET code to report Config Error (Buffer Address and Size)*/
#define CANETHCONV_E_CFG_BUF                         (uint8)0x41U   /*  65U */
/* DET code to report Config Error (Filtering Table)*/
#define CANETHCONV_E_CFG_FILTER                      (uint8)0x42U   /*  66U */
/* DET code to report Config Error (Pack ID Table)*/
#define CANETHCONV_E_CFG_PACKTBL                     (uint8)0x50U   /*  80U */
/* DET code to report Config Error (Ethernet Source Address)*/
#define CANETHCONV_E_BUF_FULL                        (uint8)0x51U   /*  81U */
/* DET code to report unexpectedly full buffer error*/
#define CANETHCONV_E_BUFF                            (uint8)0x65U   /* 101U */

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/* Pack ID Table Entry */
typedef struct
{
    uint16 usPackId;
    uint8  ucUnit;
    uint8  ucCh;
    uint32 ulCanId;
    uint32 ulCanIdMask;
} R_PackLib_PackIdTblType;

/* Buffer Address and Size Table Entry */
typedef struct
{
    uint16 usPackId;
    uint16 usPackDataBufSize;
    uint8 *pPackDataAddr;
} R_PackLib_PackBufTblType;

/* Packing Library Initialization Configuration */
typedef struct
{
    uint32 ulPackIdTblEntryNum;
    const R_PackLib_PackIdTblType *pPackIdTbl;
    uint32 ulPackBufTblEntryNum;
    const R_PackLib_PackBufTblType *pPackBufTbl;
} R_PackLib_CfgType;

/* Packing Library CAN frame to set */
typedef struct
{
    uint32 ulCanId;
    uint32 ulCanDlc;
    uint8 *pCanData;
} R_PackLib_CanFrameType;

typedef struct
{    
    uint16 usPriorityId;
    uint16 usVcid;
    uint8  ucSduType;
    uint32 ulAcceptanceField;
    uint8  ucSec;
} R_PackLib_CanXLParamType;

/* Packing Library CANXL frame to set */
typedef struct
{
    uint32 ulCanDlc;
    uint8 *pCanData;
    R_PackLib_CanXLParamType *pXLParams;
} R_PackLib_CanXLFrameType;

/* Packing Library CAN frame pack information */
typedef struct
{
    uint16 usPackId;
    uint16 usCanFrameCount;
    uint16 usRemCap;
} R_PackLib_PackInfoType;

/* CANETHCONV Pre-compile configuration Header File */
#include "CDD_CanEthConv_PackLib_Cfg.h"
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"

extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_Init(const R_PackLib_CfgType *pConfig);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_SetCanData(const uint8 ucUnit, const uint8 ucCh, 
                const R_PackLib_CanFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_GetPackData(const uint16 usPackId, 
                uint16 *pDataLen, uint8 *pPackData);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_Unpack(const uint16 usDataLen, const uint8 *pPackData, 
                uint8 *pOffsetNum, uint16 *aaDataOffset);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_SetCanXLData(const uint8 ucUnit, const uint8 ucCh, 
                const R_PackLib_CanXLFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo);

#define CANETHCONV_STOP_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"

#endif /* CDD_PACKLIB_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
