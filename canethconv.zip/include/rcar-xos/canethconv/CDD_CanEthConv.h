/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the CAN-Ethernet Conversion function.
***********************************************************************************************************************/
#ifndef CDD_CANETHCONV_H
#define CDD_CANETHCONV_H

/* Include standard Autosar Type */
#include "Std_Types.h"

/*******************************************************************************
Version Information
*******************************************************************************/
#define CANETHCONV_VENDOR_ID           CANETHCONV_VENDOR_ID_VALUE
#define CANETHCONV_MODULE_ID           CANETHCONV_MODULE_ID_VALUE
#define CANETHCONV_INSTANCE_ID         CANETHCONV_INSTANCE_ID_VALUE

/* AUTOSAR Release Version Information */
#define CANETHCONV_AR_RELEASE_MAJOR_VERSION                               4U
#define CANETHCONV_AR_RELEASE_MINOR_VERSION                               9U
#define CANETHCONV_AR_RELEASE_REVISION_VERSION                            0U

/* File version information */
#define CANETHCONV_SW_MAJOR_VERSION                                       0U
#define CANETHCONV_SW_MINOR_VERSION                                       8U
#define CANETHCONV_SW_PATCH_VERSION                                       0U

/* AUTOSAR release version information */
#define CANETHCONV_PBTYPES_AR_RELEASE_MAJOR_VERSION    CANETHCONV_AR_RELEASE_MAJOR_VERSION
#define CANETHCONV_PBTYPES_AR_RELEASE_MINOR_VERSION    CANETHCONV_AR_RELEASE_MINOR_VERSION
#define CANETHCONV_PBTYPES_AR_RELEASE_REVISION_VERSION CANETHCONV_AR_RELEASE_REVISION_VERSION

/* File version information */
#define CANETHCONV_PBTYPES_SW_MAJOR_VERSION            CANETHCONV_SW_MAJOR_VERSION
#define CANETHCONV_PBTYPES_SW_MINOR_VERSION            CANETHCONV_SW_MINOR_VERSION
/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Ethernet type */
#define CANETHCONV_FRAMETYPE_AVTP       0x22F0U
#define CANETHCONV_FRAMETYPE_IPV4       0x0800U
#define CANETHCONV_FRAMETYPE_IPV6       0x86DDU
#define CANETHCONV_FRAMETYPE_8021Q      0x8100U

/* Integrity check code */
#define CANETHCONV_CHECK_CODE           0x12345678UL
/* Address length in word */
#define CANETHCONV_MACADDR_LEN_IN_WORD  2U
#define CANETHCONV_IPADDR_LEN_IN_WORD   4U
#define CANETHCONV_STREAMID_LEN_IN_WORD 2U
/* Address length in byte */
#define CANETHCONV_IPV4ADDR_LEN_IN_BYTE   4U
#define CANETHCONV_IPV6ADDR_LEN_IN_BYTE   16U

#define CANETHCONV_CLR          0U
#define CANETHCONV_SET          1U
#define CANETHCONV_INVALID      0U
#define CANETHCONV_VALID        1U
#define CANETHCONV_FLAG_IPV4    0U
#define CANETHCONV_FLAG_IPV6    1U
#define CANETHCONV_FLAG_NTSCF   0U
#define CANETHCONV_FLAG_TSCF    1U
#define CANETHCONV_AVTP_NONE    2U

/*******************************************************************************
Service IDs
*******************************************************************************/
/* Service ID for R_CanEthConv_Init */
#define R_CANETHCONV_INIT_SID                       (uint8)0x00U
/* Service ID for R_CanEthConv_CantoEth */
#define R_CANETHCONV_CANTOETH_SID                   (uint8)0x01U
/* Service ID for R_CanEthConv_MainFunction */
#define R_CANETHCONV_MAINFUNCTION_SID               (uint8)0x02U
/* Service ID for R_CanEthConv_EthtoCan */
#define R_CANETHCONV_ETHTOCAN_SID                   (uint8)0x03U
/* Service ID for R_CanEthConv_SendEnable */
#define R_CANETHCONV_SENDENABLE_SID                 (uint8)0x04U
/* Service ID for R_CanEthConv_SendDisable */
#define R_CANETHCONV_SENDDISABLE_SID                (uint8)0x05U
/* Service ID for R_CanEthConv_GetSendStatus */
#define R_CANETHCONV_GETSENDSTATUS_SID              (uint8)0x06U
/* Service ID for R_CanEthConv_CantoEth */
#define R_CANETHCONV_CANXLTOETH_SID                 (uint8)0x07U

/*******************************************************************************
DET Error Codes
*******************************************************************************/
/* DET code to report parameter error (argument is NULL Pointer) */
#define CANETHCONV_E_PARAM_POINTER                   (uint8)0x02U   /*  2U  */
/* DET code to report process error (API executed in uninitialized state) */
#define CANETHCONV_E_UNINIT                          (uint8)0x03U   /*  3U  */
/* DET code to report wrong parameter passed to the APIs */
#define CANETHCONV_E_INV_PARAM                       (uint8)0x04U   /*  4U  */
/* DET code to report invalid call */
#define CANETHCONV_E_ALREADY_INITIALIZED             (uint8)0x06U   /*  6U  */
/* DET code to report discrepancy error (Miss match with SW routing table value) */
#define CANETHCONV_E_MATCH                           (uint8)0x08U   /*  8U  */
/* DET code to report transmission error */
#define CANETHCONV_E_TRANS                           (uint8)0x09U   /*  9U  */
/* DET code to report API service called with wrong Data length */
#define CANETHCONV_E_PARAM_DATA_LENGTH               (uint8)0x0BU   /*  11U */
/* DET code to report Packed CAN Frame Error */
#define CANETHCONV_E_PACKEDCAN                       (uint8)0x0CU   /*  12U */
/* DET code to report IP Header Checksum Error */
#define CANETHCONV_E_IPCKSUM                         (uint8)0x0DU   /*  13U */
/* DET code to report UDP Header Checksum Error */
#define CANETHCONV_E_UDPCKSUM                        (uint8)0x0EU   /*  14U */
/* DET code to report Invalid CAN DLC */
#define CANETHCONV_E_NOTFRAME                        (uint8)0x0FU   /*  15U */
/* DET code to report BSW Notification Error */
#define CANETHCONV_E_BSWNOTIFY                       (uint8)0x10U   /*  16U */
/* DET code to report Filtered and discarded error */
#define CANETHCONV_E_FILTER                          (uint8)0x11U   /*  17U */
/* DET code to report configuration errors (overall)*/
#define CANETHCONV_E_CFG                             (uint8)0x14U   /*  20U */
/* DET code to report Config Error (CAN to Ethernet Routing Table) */
#define CANETHCONV_E_CFG_ETHTBL                      (uint8)0x32U   /*  50U */
/* DET code to report Config Error (Ethernet to CAN Routing Table) */
#define CANETHCONV_E_CFG_CANTBL                      (uint8)0x33U   /*  51U */
/* DET code to report Config Error (NULL Pointer) */
#define CANETHCONV_E_PARAM_CONFIG                    (uint8)0x3CU   /*  60U */
/* DET code to report Config Error (Conversion Mode)*/
#define CANETHCONV_E_CFG_CONVMODE                    (uint8)0x3DU   /*  61U */
/* DET code to report Config Error (Storable CAN Frame and Buffering Time)*/
#define CANETHCONV_E_CFG_LIMIT                       (uint8)0x3FU   /*  63U */
/* DET code to report Config Error (Ethernet Source Address)*/
#define CANETHCONV_E_CFG_ETHSRC                      (uint8)0x40U   /*  64U */
/* DET code to report Config Error (Buffer Address and Size)*/
#define CANETHCONV_E_CFG_BUF                         (uint8)0x41U   /*  65U */
/* DET code to report Config Error (Filtering Table)*/
#define CANETHCONV_E_CFG_FILTER                      (uint8)0x42U   /*  66U */
/* DET code to report Config Error (Pack ID Table)*/
#define CANETHCONV_E_CFG_PACKTBL                     (uint8)0x50U   /*  80U */
/* DET code to report Config Error (Ethernet Source Address)*/
#define CANETHCONV_E_BUF_FULL                        (uint8)0x51U   /*  81U */
/* DET code to report unexpectedly full buffer error*/
#define CANETHCONV_E_BUFF                            (uint8)0x65U   /* 101U */

/*******************************************************************************
Typedef definitions
*******************************************************************************/
typedef enum
{
    CANETHCONV_BASICMODE,
    CANETHCONV_BUFFERMODE,
    CANETHCONV_EMERGENCYMODE
} R_CanEthConv_ConvModeType;

typedef struct
{
    uint32 ulCanId;
    uint32 ulCanDlc;
    uint8 *pCanData;
} R_CanEthConv_CanFrameType;

typedef struct
{    
    uint16 usPriorityId;
    uint16 usVcid;
    uint8  ucSduType;
    uint32 ulAcceptanceField;
    uint8  ucSec;
} R_CanEthConv_CanXLParamType;

typedef struct
{
    uint32 ulCanDlc;
    uint8  *pCanData;
    R_CanEthConv_CanXLParamType *pXLParams;
} R_CanEthConv_CanXLFrameType;

/* MAC Address Type */
typedef struct
{
    uint32 aaMacAddr[CANETHCONV_MACADDR_LEN_IN_WORD];
} R_CanEthConv_MacAddressType;

/* IPV4 Address Type */
typedef struct
{
    uint32 aaIpAddr[CANETHCONV_IPADDR_LEN_IN_WORD];
} R_CanEthConv_IpAddressType;

/* IP/UDP/AVTP Header Configuration */
typedef struct
{
    uint8  ucIpSetFlag;
    uint8  ucIpType;
    uint8  ucAvtpFormat;
    uint8  ucEmergencyFlag;
    uint32 aaDestIpAddr[CANETHCONV_IPADDR_LEN_IN_WORD];
    uint16 usDestUdpPort;
    uint16 usVlanId;
    uint8  ucStreamIdValid;
    uint32 aaStreamId[CANETHCONV_STREAMID_LEN_IN_WORD];
} R_CanEthConv_HeaderType;

/* CAN to Ethernet Routing Table entry */
typedef struct
{
    uint32 ulCanId;
    uint32 ulCanIdMask;
    uint32 aaDestMacAddr[CANETHCONV_MACADDR_LEN_IN_WORD];
    R_CanEthConv_HeaderType stHeader;
} R_CanEthConv_EthRoutTblType;

/* Source Address/Port Configuration */
typedef struct
{
    uint32 aaSrcMacAddr[CANETHCONV_MACADDR_LEN_IN_WORD];
    uint32 ulSrcIpv4Addr;
    uint32 aaSrcIpv6Addr[CANETHCONV_IPADDR_LEN_IN_WORD];
    uint16 usSrcUdpPort;
} R_CanEthConv_EthSrcCfgType;

/* Ethernet to CAN Routing Table entry */
typedef struct
{
    uint32 ulCanId;
    uint32 ulCanIdMask;
    uint8 ucUnit;
    uint8 ucCh;
    uint8 ucAddInfo;
} R_CanEthConv_CanRoutTblType;

/* CAN to Ethernet Conifguration */
typedef struct
{
    R_CanEthConv_ConvModeType enConvMode;
    uint32 ulReserved;
    uint32 ulFrameLimit;
    uint32 ulTimeLimit;
} R_CanEthConv_ConvCfgType;

/* Buffer Address and Size Configuration */
typedef struct
{
    uint8 *pCanRxAddr;
    uint32 ulCanRxBufSize;
    uint8 *pEthTxAddr;
    uint32 ulEthTxBufSize;
    uint8 *pEthRxAddr;
    uint32 ulEthRxBufSize;
    uint8 *pCanTxAddr;
    uint32 ulCanTxBufSize;
} R_CanEthConv_BufCfgType;

/* StreamID filter Configuration */
typedef struct
{
    uint32 aaStreamId[CANETHCONV_STREAMID_LEN_IN_WORD];
} R_CanEthConv_StreamIdType;

/* Filter Configuration */
typedef struct
{
    uint16                        usSrcMacFilterNum;
    const R_CanEthConv_MacAddressType   *aaSrcMacAddr;
    uint16                        usSrcIpFilterNum;
    const R_CanEthConv_IpAddressType    *aaSrcIpAddr;
    uint16                        usVlanIdFilterNum;
    const uint16                        *aaVlanId;
    uint16                        usStreamIdFilterNum;
    const R_CanEthConv_StreamIdType     *aaStreamId;
} R_CanEthConv_FilterCfgType;

/* Initialization Configuration */
typedef struct
{
    uint32 ulEthRoutTblEntryNum;
    const R_CanEthConv_EthRoutTblType *pEthRoutTbl;
    const R_CanEthConv_EthSrcCfgType  *pEthSrcCfg;
    uint32                            ulCanRoutTblEntryNum;
    const R_CanEthConv_CanRoutTblType *pCanRoutTbl;
    uint32                            ulIntegrityCheck;
    const R_CanEthConv_ConvCfgType    *pConvCfg;
    const R_CanEthConv_BufCfgType     *pBufCfg;
    const R_CanEthConv_FilterCfgType  *pFilterCfg;
} R_CanEthConv_CfgType;

/* CANETHCONV Pre-compile configuration Header File */
#include "CDD_CanEthConv_Cfg.h"
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"

extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_Init(const R_CanEthConv_CfgType *pConfig);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_CantoEth(const R_CanEthConv_CanFrameType *pCanFrame);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_EthtoCan(const uint16 usFrameType, 
    const uint8* aaSrcMacAddr, const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus);
extern FUNC(void, CANETHCONV_PUBLIC_CODE)   R_CanEthConv_MainFunction(void);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_SendEnable(const uint8 ucUnit, const uint8 ucCh);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_SendDisable(const uint8 ucUnit, const uint8 ucCh);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_GetSendStatus(uint32 *pStatus);
extern FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_CanXLtoEth(
    const R_CanEthConv_CanXLFrameType *pCanFrame);

#define CANETHCONV_STOP_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"

#endif /* CDD_CANETHCONV_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
