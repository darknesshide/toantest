/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Unpack function for Pack Library.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_PackLib_common.h"
#include "CDD_PackLib_Unpack.h"
#include "CDD_CanEthConv_Util.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* CAN Frame Structure */
typedef struct
{
    uint32 ulCanId;
    uint32 ulDlc;
} PackLib_CanFrmStrType;

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_33_001]:[Gen5GW_CanEthConv_UD_33_001]
* Function Name: PackLib_Unpack
* Description  : Unpack Function
* Arguments    : usDataLen -
*                    Pack Data Buffer Length
*                *pPackData -
*                    Pack Data Buffer Pointer 
*                *pOffsetNum -
*                    Pointer to Unpacking Buffer Offset Num
*                *aaDataOffset -
*                    Pointer to Unpacking Buffer Offset
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_Unpack(const uint16 usDataLen, const uint8 *pPackData, 
                                                             uint8 *pOffsetNum, uint16 *aaDataOffset)
{
    Std_ReturnType LucRetVal;
    uint32 LulCanId;
    uint32 LulCanLength;
    uint16 LucFlg;
    uint16 LusCanOffset;
    uint16 LusChkCanOffset;

    LucRetVal  = E_OK;

    LucFlg       = PACKLIB_SET;
    *pOffsetNum  = NUM0;
    LusCanOffset = NUM0;

    /* Search Pack Data Buffer */
    while ((uint32)PACKLIB_SET == (uint32)LucFlg)
    {
        LulCanId     = ((const PackLib_CanFrmStrType*)(&pPackData[LusCanOffset]))->ulCanId;
        LulCanLength = ((const PackLib_CanFrmStrType*)(&pPackData[LusCanOffset]))->ulDlc;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LulCanId);
        CanEthConv_UtilEndianConv32(&LulCanLength);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        if (CANXL_XLF_BIT == (LulCanId & CANXL_XLF_BIT))
        {
            /* Analyze as CANXL frame */
            if (((uint32)(CAN_LEN_ID + CAN_LEN_DLC + CANXL_PARAM_LEN + CANXL_DLC_SIZE_MIN) <= 
                 (uint32)((uint32)usDataLen - (uint32)LusCanOffset))
            && (((uint32)CANXL_DLC_SIZE_MIN <= (uint32)LulCanLength) &&
                ((uint32)CANXL_DLC_SIZE_MAX >= (uint32)LulCanLength)))
            {
                LusChkCanOffset = (uint16)((uint32)LusCanOffset 
                                + (CAN_LEN_ID + CAN_LEN_DLC + CANXL_PARAM_LEN + (uint32)LulCanLength));
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                LucRetVal = E_NOT_OK;
                LucFlg    = PACKLIB_CLR;
            }
        }
        else
        {
            /* Analyze as CAN/CANFD frame */
            if (((uint32)(CAN_LEN_ID + CAN_LEN_DLC) <= (uint32)((uint32)usDataLen - (uint32)LusCanOffset))
            &&  ((uint32)CANDLC_SIZE_MAX >= (uint32)LulCanLength))
            {
                LusChkCanOffset = (uint16)((uint32)LusCanOffset + (CAN_LEN_ID + CAN_LEN_DLC + (uint32)LulCanLength));
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                LucRetVal = E_NOT_OK;
                LucFlg    = PACKLIB_CLR;
            }
        }
        
        if ((uint8)E_OK == LucRetVal)
        {
            if ((uint32)usDataLen >= (uint32)LusChkCanOffset)
            {
                aaDataOffset[*pOffsetNum] = LusCanOffset;
                (*pOffsetNum) = (uint8)((uint32)(*pOffsetNum) + (uint32)NUM1);
                LusCanOffset = LusChkCanOffset;

                if ((uint32)NUM0 == (uint32)((uint32)usDataLen - (uint32)LusCanOffset))
                {
                    LucFlg = PACKLIB_CLR;
                }
                else
                {
                    /*  Do nothing */
                }
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                LucRetVal = E_NOT_OK;
                LucFlg    = PACKLIB_CLR;
            }
        }
        else
        {
            /* Do nothing */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /*  Do nothing */
    }
    else
    {
        *pOffsetNum = NUM0;
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
