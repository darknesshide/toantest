/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Initialization function for Packing library.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_PackLib_common.h"
#include "CDD_PackLib_init.h"
#include "CDD_PackLib_Pack.h"
#include "CDD_PackLib_Unpack.h"
#include "CDD_CanEthConv_Util.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_31_001]:[Gen5GW_CanEthConv_UD_31_001]
* Function Name: PackLib_Init
* Description  : Packing library SW Initialization.
* Arguments    : *pConfig -
*                    Initialization Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_Init(const R_PackLib_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((NULL_PTR != pConfig->pPackIdTbl) &&
        (NULL_PTR != pConfig->pPackBufTbl))
    {
        /* NULL check is passed */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                              CANETHCONV_E_PARAM_CONFIG);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = PackLib_PackInit(pConfig);
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
