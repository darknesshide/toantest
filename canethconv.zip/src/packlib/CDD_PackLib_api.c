/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the API function for Packing library.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_PackLib_common.h"
#include "CDD_PackLib_api.h"
#include "CDD_PackLib_init.h"
#include "CDD_PackLib_Pack.h"
#include "CDD_PackLib_Unpack.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
/*******************************************************************************
Macro definitions
*******************************************************************************/
#define PACKLIB_STS_UNINIT   0U
#define PACKLIB_STS_INIT     1U

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_INIT_8
#include "CanEthConv_MemMap.h" 
VAR(uint8, CANETHCONV_VAR_INIT) PackLib_GucInitStatus = PACKLIB_STS_UNINIT;
#define CANETHCONV_STOP_SEC_VAR_INIT_8
#include "CanEthConv_MemMap.h" 

/*******************************************************************************
Private global variables and functions
*******************************************************************************/

#define CANETHCONV_START_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_30_001]:[Gen5GW_CanEthConv_UD_30_001]
* Function Name: R_PackLib_Init
* Description  : PackLib SW Initialization API.
* Arguments    : pConfig -
*                    Initialization Configuration.
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_Init(const R_PackLib_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)PACKLIB_STS_UNINIT == (uint32)PackLib_GucInitStatus)
    {
        if (NULL_PTR != pConfig)
        {
            /* Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                              CANETHCONV_E_ALREADY_INITIALIZED);
        #endif
        /* Already initialized */
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = PackLib_Init(pConfig);
        if ((uint8)E_OK == LucRetVal)
        {
            PackLib_GucInitStatus = PACKLIB_STS_INIT;
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_30_002]:[Gen5GW_CanEthConv_UD_30_002]
* Function Name: R_PackLib_SetCanData
* Description  : PackLib Function API
* Arguments    : ucUnit -
*                    Unit No
*                ucCh -
*                    Channel No
*                *pCanFrame -
*                    Pointer to Can frame structure
*                *pPackInfo -
*                    Pointer to Result of Pack Can frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_SetCanData(const uint8 ucUnit, const uint8 ucCh,
                            const R_PackLib_CanFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo)
{
    Std_ReturnType LucRetVal;
    uint32 LulCanId;

    LucRetVal = E_OK;

    /* Initialization check */
    if ((uint32)PACKLIB_STS_INIT == (uint32)PackLib_GucInitStatus)
    {
        /* Check Unit No, Channel No, CAN ID */
        if ((((uint32)CAN_UNIT_MAX   >= (uint32)ucUnit) && ((uint32)CAN_CHANNEL_MAX   >= (uint32)ucCh))
        ||  (((uint32)CANXL_UNIT_NUM == (uint32)ucUnit) && ((uint32)CANXL_CHANNEL_MAX >= (uint32)ucCh)))
        {
            /* Unit No, Channel No check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                                  CANETHCONV_E_INV_PARAM);
            #endif
            /* Unit No, Channel No check is failed */
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {
            if (NULL_PTR != pCanFrame)
            {
                /* Buffer Address NULL check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                                      CANETHCONV_E_PARAM_POINTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LulCanId  = pCanFrame->ulCanId;
            /* Check Standard CAN ID */
            if (((uint32)CANID_BASE_MAX >= LulCanId)
            /* Check Extended CAN ID */
            || (((uint32)CANID_EXTENDED_MIN <= LulCanId) && ((uint32)CANID_EXTENDED_MAX >= LulCanId))
            /* Check Standard CANFD ID */
            || (((uint32)CANFD_ID_BASE_MIN  <= LulCanId) && ((uint32)CANFD_ID_BASE_MAX  >= LulCanId))
            /* Check Extended CANFD ID */
            || (((uint32)CANFD_ID_EXTENDED_MIN <= LulCanId) && ((uint32)CANFD_ID_EXTENDED_MAX >= LulCanId)))
            {
                /*  Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */             
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID, 
                                      CANETHCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        /* Check Buffer, Result info */
        if ((uint8)E_OK == LucRetVal)
        {
            if ((NULL_PTR != pPackInfo) &&
                (NULL_PTR != pCanFrame->pCanData))
            {
                /* Buffer Address NULL check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                                      CANETHCONV_E_PARAM_POINTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = PackLib_SetCanData(ucUnit, ucCh, pCanFrame, pPackInfo);
        }
        else
        {
            /*  Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_30_003]:[Gen5GW_CanEthConv_UD_30_003]
* Function Name: R_PackLib_GetPackData
* Description  : PackLib Function API
* Arguments    : usPackId -
*                    Pack ID
*                *pDataLen -
*                    Stored Pack Data Length
*                *pPackData -
*                    Stored Pack Data Pointer
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_GetPackData(const uint16 usPackId, uint16 *pDataLen, uint8 *pPackData)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* Initialization check */
    if ((uint32)PACKLIB_STS_INIT == (uint32)PackLib_GucInitStatus)
    {
        /* Check PACK ID */
        if ((uint32)PACK_ID_MAX >= (uint32)usPackId)
        {
            /* Pack ID check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_GETPACKDATA_SID,
                                  CANETHCONV_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {
            if ((NULL_PTR != pDataLen) &&
                (NULL_PTR != pPackData))
            {
                /* Len Address NULL check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_GETPACKDATA_SID,
                                      CANETHCONV_E_PARAM_POINTER);
                #endif
                /* Len Address NULL check is failed */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = PackLib_GetPackData(usPackId, pDataLen, pPackData);
        }
        else
        {
            /*  Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_GETPACKDATA_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_30_004]:[Gen5GW_CanEthConv_UD_30_004]
* Function Name: R_PackLib_Unpack
* Description  : UnpackLib Function API
* Arguments    : usDataLen -
*                    Packing Buffer length
*                *pPackData -
*                    Pointer to Packing Buffer
*                *pOffsetNum -
*                    Pointer to Unpacking Buffer Offset Num
*                *aaDataOffset -
*                    Pointer to Unpacking Buffer Offset
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_Unpack(const uint16 usDataLen, const uint8 *pPackData, 
                                                              uint8 *pOffsetNum, uint16 *aaDataOffset)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* Initialization check */
    if ((uint32)PACKLIB_STS_INIT == (uint32)PackLib_GucInitStatus)
    {
        /* Check Pack Data Buffer */
        if (NULL_PTR != pPackData)
        {
            /* Buffer Address NULL check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {
            if (((uint32)PACKBUF_SIZE_MIN <= (uint32)usDataLen) &&
                ((uint32)PACKBUF_SIZE_MAX >= (uint32)usDataLen))
            {
                /* Buffer Size check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID,
                                      CANETHCONV_E_INV_PARAM);
                #endif
                /* Buffer Size check is failed */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        /* Check Offset Buffer and Offset Num */
        if ((uint8)E_OK == LucRetVal)
        {
            if ((NULL_PTR != pOffsetNum) &&
                (NULL_PTR != aaDataOffset))
            {
                /* Buffer Address NULL check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID,
                                      CANETHCONV_E_PARAM_POINTER);
                #endif
                /* Buffer Address NULL check is failed */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = PackLib_Unpack(usDataLen, pPackData, pOffsetNum, aaDataOffset);
        }
        else
        {
            /*  Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_UNPACK_SID, CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_30_005]:[Gen5GW_CanEthConv_UD_30_005]
* Function Name: R_PackLib_SetCanXLData
* Description  : PackLib Function API
* Arguments    : ucUnit -
*                    Unit No
*                ucCh -
*                    Channel No
*                *pCanFrame -
*                    Pointer to CanXL frame structure
*                *pPackInfo -
*                    Pointer to Result of Pack Can frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_PackLib_SetCanXLData(const uint8 ucUnit, const uint8 ucCh,
                            const R_PackLib_CanXLFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* Initialization check */
    if ((uint32)PACKLIB_STS_INIT == (uint32)PackLib_GucInitStatus)
    {
        /* Check Unit No, CH No, CAN ID */
        if (((uint32)CANXL_UNIT_NUM    == (uint32)ucUnit)
		&&  ((uint32)CANXL_CHANNEL_MAX >= (uint32)ucCh))
        {
            /* Unit No, Channel No check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                                  CANETHCONV_E_INV_PARAM);
            #endif
            /* Unit No, Channel No check is failed */
            LucRetVal = E_NOT_OK;
        }

        if (E_OK == LucRetVal)
        {
            if (NULL_PTR != pCanFrame)
            {
                /* Buffer Address NULL check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                                      CANETHCONV_E_PARAM_POINTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if (E_OK == LucRetVal)
        {
            if ((uint16)CANID_XL_MAX >= pCanFrame->pXLParams->usPriorityId)
            {
                /*  Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */             
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID, 
                                      CANETHCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        /* Check Buffer, Result info */
        if (E_OK == LucRetVal)
        {
            if ((NULL_PTR != pPackInfo)
            &&  (NULL_PTR != pCanFrame->pCanData))
            {
                /* Buffer Address NULL check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                                      CANETHCONV_E_PARAM_POINTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if (E_OK == LucRetVal)
        {
            LucRetVal = PackLib_SetCanXLData(ucUnit, ucCh, pCanFrame, pPackInfo);
        }
        else
        {
            /*  Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
