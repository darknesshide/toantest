/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Pack function for Packing Library.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_PackLib_common.h"
#include "CDD_PackLib_Pack.h"
#include "CDD_CanEthConv_Util.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif
/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* Pack ID Convert Table */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)   PackLib_GulPackIdTblNum;
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)   PackLib_GulPackBufTblNo[PACKIDTBL_ENTRY_MAX];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
STATIC VAR(R_PackLib_PackIdTblType, CANETHCONV_VAR_NO_INIT)   PackLib_GstPackIdTbl[PACKIDTBL_ENTRY_MAX];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* Buffer Address and Size Table */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)   PackLib_GulPackBufTblNum;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_16
#include "CanEthConv_MemMap.h" 
STATIC VAR(uint16, CANETHCONV_VAR_NO_INIT)   PackLib_GusPackDataSetSize[PACKBUFTBL_ENTRY_MAX];
STATIC VAR(uint16, CANETHCONV_VAR_NO_INIT)   PackLib_GusPackDataSetCount[PACKBUFTBL_ENTRY_MAX];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_16
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
STATIC VAR(R_PackLib_PackBufTblType, CANETHCONV_VAR_NO_INIT)   PackLib_GstPackBufTbl[PACKBUFTBL_ENTRY_MAX];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetPackIdTbl(const R_PackLib_CfgType *pConfig);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetPackBufTbl(const R_PackLib_CfgType *pConfig);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) LinkPackIdTblAndBuffer(void);

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_001]:[Gen5GW_CanEthConv_UD_32_001]
* Function Name: PackLib_PackInit
* Description  : Pack Function Initialization.
* Arguments    : *pConfig -
*                    Initialization Config Pointer
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_PackInit(const R_PackLib_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* Packing Library Initialization Configuration */
    if (((uint32)NUM1                <= pConfig->ulPackIdTblEntryNum)
    &&  ((uint32)PACKIDTBL_ENTRY_MAX >= pConfig->ulPackIdTblEntryNum))
    {
        /* Entry Num check is passed */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                              CANETHCONV_E_CFG_PACKTBL);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if (((uint32)NUM1                 <= pConfig->ulPackBufTblEntryNum)
        &&  ((uint32)PACKBUFTBL_ENTRY_MAX >= pConfig->ulPackBufTblEntryNum))
        {
            /* Entry Num check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                                  CANETHCONV_E_CFG_PACKTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*  Do nothing */
    }

    /* Check All entry config data and Set */
    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = SetPackIdTbl(pConfig);
    }
    else
    {
        /*  Do nothing */
    }

    /* Check All entry Buffer data and Set */
    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = SetPackBufTbl(pConfig);
    }
    else
    {
        /*  Do nothing */
    }

    /* Check BuffNo in Pack ID Table */
    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = LinkPackIdTblAndBuffer();
    }
    else
    {
        /*  Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_002]:[Gen5GW_CanEthConv_UD_32_002]
* Function Name: PackLib_SetCanData
* Description  : Pack Function(Set)
* Arguments    : ucUnit -
*                    Unit No
*                ucCh -
*                    Channel No
*                *pCanFrame -
*                    Pointer to Can frame structure
*                *pPackInfo -
*                    Pointer to Result of Pack Can frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_SetCanData(const uint8 ucUnit, const uint8 ucCh,
                          const R_PackLib_CanFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;

    uint32 LulCan;
    uint32 LulDlc;
    uint32 LulCanId;
    uint32 LulCanIdMask;
    uint32 LulLen;
    uint16 LusBufSize;
    uint16 LusBufSetSize;
    uint16 LusDataStart;
    uint8 *LpDataAddr;
    uint32 LulBuffNo;

    /* Check CAN-DLC */
    LucRetVal = CanEthConv_UtilCanDlcCheck(pCanFrame->ulCanDlc);
    if ((uint8)E_OK == LucRetVal)
    {
        LulCanId   = pCanFrame->ulCanId;
        LulLen     = pCanFrame->ulCanDlc;

        /* Search entry config data */
        for (LulEntryIdx = IDX_0; LulEntryIdx < PackLib_GulPackIdTblNum; LulEntryIdx++)
        {
            LulCanIdMask = PackLib_GstPackIdTbl[LulEntryIdx].ulCanIdMask;

            if (((uint32)PackLib_GstPackIdTbl[LulEntryIdx].ucUnit           == (uint32)ucUnit) &&
                ((uint32)PackLib_GstPackIdTbl[LulEntryIdx].ucCh             == (uint32)ucCh) &&
                ((PackLib_GstPackIdTbl[LulEntryIdx].ulCanId & LulCanIdMask) == (LulCanId & LulCanIdMask)))
            {
                LulBuffNo     = PackLib_GulPackBufTblNo[LulEntryIdx];

                LusBufSize    = PackLib_GstPackBufTbl[LulBuffNo].usPackDataBufSize;
                LusDataStart  = PackLib_GusPackDataSetSize[LulBuffNo];
                LpDataAddr    = &(PackLib_GstPackBufTbl[LulBuffNo].pPackDataAddr[LusDataStart]);
                LusBufSetSize = (uint16)((uint32)PackLib_GusPackDataSetSize[LulBuffNo] +
                    (uint32)(CAN_LEN_ID + CAN_LEN_DLC) + LulLen);

                if ((uint32)LusBufSize >= (uint32)LusBufSetSize)
                {
                    /* Enough Space */
                    LulCan     = pCanFrame->ulCanId;
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    CanEthConv_UtilEndianConv32(&LulCan);
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

                    CanEthConv_UtilMemCpy(LpDataAddr, &LulCan, CAN_LEN_ID);

                    LulDlc     = pCanFrame->ulCanDlc;
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    CanEthConv_UtilEndianConv32(&LulDlc);
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_4]), &LulDlc, CAN_LEN_DLC);

                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_8]), pCanFrame->pCanData, LulLen);
                    PackLib_GusPackDataSetSize[LulBuffNo]  = LusBufSetSize;
                    PackLib_GusPackDataSetCount[LulBuffNo] = 
                        (uint16)((uint32)PackLib_GusPackDataSetCount[LulBuffNo] + (uint32)NUM1);
                }
                else
                {
                    #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                                          CANETHCONV_E_BUF_FULL);
                    #endif
                    /* not Enough Space */
                    LucRetVal = E_NOT_OK;
                }

                pPackInfo->usPackId        = PackLib_GstPackBufTbl[LulBuffNo].usPackId;
                pPackInfo->usCanFrameCount = PackLib_GusPackDataSetCount[LulBuffNo];
                pPackInfo->usRemCap        = 
                    (uint16)((uint32)LusBufSize - (uint32)PackLib_GusPackDataSetSize[LulBuffNo]);
                break;
            }
            else
            {
                /*  Do nothing */
            }
        }

        if (PackLib_GulPackIdTblNum != LulEntryIdx)
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                                  CANETHCONV_E_MATCH);
            #endif
            /* No search results */
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANDATA_SID,
                              CANETHCONV_E_INV_PARAM);
        #endif
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_003]:[Gen5GW_CanEthConv_UD_32_003]
* Function Name: PackLib_GetPackData
* Description  : Pack Function(Get)
* Arguments    : usPackId -
*                    Pack ID
*                *pDataLen -
*                    Stored Pack Data Length
*                *pPackData -
*                    Stored Pack Data Pointer
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_GetPackData(const uint16 usPackId, uint16 *pDataLen, 
                                                                  uint8 *pPackData)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;

    uint16 LusPackId;
    uint8 *LpDataAddr;
    uint16 LusBufSetSize;

    LucRetVal = E_OK;

    /* Search Pack Buffer Table */
    for (LulEntryIdx = IDX_0; LulEntryIdx < PackLib_GulPackBufTblNum; LulEntryIdx++)
    {
        LusPackId     = PackLib_GstPackBufTbl[LulEntryIdx].usPackId;

        if ((uint32)LusPackId  == (uint32)usPackId)
        {
            LpDataAddr    = PackLib_GstPackBufTbl[LulEntryIdx].pPackDataAddr;
            LusBufSetSize = PackLib_GusPackDataSetSize[LulEntryIdx];

            CanEthConv_UtilMemCpy(pPackData, LpDataAddr, (uint32)LusBufSetSize);
            *pDataLen = (uint16)LusBufSetSize;
            PackLib_GusPackDataSetSize[LulEntryIdx]  = NUM0;
            PackLib_GusPackDataSetCount[LulEntryIdx] = NUM0;
            break;
        }
        else
        {
            /*  Do nothing */
        }
    }

    if (PackLib_GulPackBufTblNum != LulEntryIdx)
    {
        /*  Do nothing */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_GETPACKDATA_SID,
                              CANETHCONV_E_MATCH);
        #endif
        /* No search results */
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_004]:[Gen5GW_CanEthConv_UD_32_004]
* Function Name: SetPackIdTbl
* Description  : Check All entry config data and Set Pack ID Convert Table
* Arguments    : *pConfig -
*                    Initialization Config Pointer
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetPackIdTbl(const R_PackLib_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;

    uint16 LusPackId;
    uint8  LucUnit;
    uint8  LucCh;
    uint32 LulCanId;
    uint32 LulCanIdMask;

    LucRetVal = E_OK;
    PackLib_GulPackIdTblNum = pConfig->ulPackIdTblEntryNum;

    /* Check All entry config data */
    for (LulEntryIdx = IDX_0; LulEntryIdx < PackLib_GulPackIdTblNum; LulEntryIdx++)
    {
        /* Check PACK-ID, UNIT-ID, CH-ID, CAN-ID, CAN-ID MASK */
        LusPackId    = pConfig->pPackIdTbl[LulEntryIdx].usPackId;
        LucUnit      = pConfig->pPackIdTbl[LulEntryIdx].ucUnit;
        LucCh        = pConfig->pPackIdTbl[LulEntryIdx].ucCh;
        LulCanId     = pConfig->pPackIdTbl[LulEntryIdx].ulCanId;
        LulCanIdMask = pConfig->pPackIdTbl[LulEntryIdx].ulCanIdMask;

        if (((uint32)PACK_ID_MAX >= (uint32)LusPackId)
        && ((((uint32)CAN_UNIT_MAX   >= (uint32)LucUnit) && ((uint32)CAN_CHANNEL_MAX   >= (uint32)LucCh))
        ||  (((uint32)CANXL_UNIT_NUM == (uint32)LucUnit) && ((uint32)CANXL_CHANNEL_MAX >= (uint32)LucCh))))
        {
            /* Pack ID, Unit ID, Channel check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                                  CANETHCONV_E_CFG_PACKTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {            
            /* Check Standard CAN ID */
            if (((uint32)CANID_BASE_MAX >= LulCanId)
            /* Check Extended CAN ID */
            || (((uint32)CANID_EXTENDED_MIN <= LulCanId)
            &&  ((uint32)CANID_EXTENDED_MAX >= LulCanId))
            /* Check Standard CANFD ID */
            || (((uint32)CANFD_ID_BASE_MIN <= LulCanId)
            &&  ((uint32)CANFD_ID_BASE_MAX >= LulCanId))
            /* Check Extended CANFD ID */
            || (((uint32)CANFD_ID_EXTENDED_MIN <= LulCanId)
            &&  ((uint32)CANFD_ID_EXTENDED_MAX >= LulCanId))
            /* Check CANXL ID */
            || (((uint32)CANXL_XLF_BIT <= LulCanId)
            && (((uint32)CANID_XL_MAX | (uint32)CANXL_XLF_BIT) >= LulCanId)))
            {
                /* Can ID check is passed */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                                      CANETHCONV_E_CFG_PACKTBL);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /*  Do nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            /* Set Pack ID Convert Table */
            PackLib_GstPackIdTbl[LulEntryIdx].usPackId    = LusPackId;
            PackLib_GstPackIdTbl[LulEntryIdx].ucUnit      = LucUnit;
            PackLib_GstPackIdTbl[LulEntryIdx].ucCh        = LucCh;
            PackLib_GstPackIdTbl[LulEntryIdx].ulCanId     = LulCanId;
            PackLib_GstPackIdTbl[LulEntryIdx].ulCanIdMask = LulCanIdMask;

            PackLib_GulPackBufTblNo[LulEntryIdx]          = NUM0;
        }
        else
        {
            PackLib_GulPackIdTblNum = NUM0;
            break;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_005]:[Gen5GW_CanEthConv_UD_32_005]
* Function Name: SetPackBufTbl
* Description  : Check All entry Buffer data and Set Buffer Address and Size Table
* Arguments    : *pConfig -
*                    Initialization Config Pointer
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetPackBufTbl(const R_PackLib_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;

    uint16 LusPackId;
    uint16 LusBufSize;
    uint8 *LpDataAddr;

    LucRetVal = E_OK;
    PackLib_GulPackBufTblNum = pConfig->ulPackBufTblEntryNum;

    /* Check All entry Buffer Table */
    for (LulEntryIdx = IDX_0; LulEntryIdx < PackLib_GulPackBufTblNum; LulEntryIdx++)
    {
        /* Check PACK-ID, BUFF-SIZE */
        LusPackId  = pConfig->pPackBufTbl[LulEntryIdx].usPackId;
        LusBufSize = pConfig->pPackBufTbl[LulEntryIdx].usPackDataBufSize;
        LpDataAddr = pConfig->pPackBufTbl[LulEntryIdx].pPackDataAddr;

        if (((uint32)PACK_ID_MAX >= (uint32)LusPackId) &&
            ((uint32)PACKBUF_SIZE_MIN <= (uint32)LusBufSize) &&
            ((uint32)PACKBUF_SIZE_MAX >= (uint32)LusBufSize) &&
            (NULL_PTR != LpDataAddr))
        {
            /* Buffer ID,  Buffer size, Buffer Address check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                                  CANETHCONV_E_CFG_PACKTBL);
            #endif
            LucRetVal = E_NOT_OK;
            PackLib_GulPackBufTblNum = NUM0;

            break;
        }

        /* Set Pack Buffer Table */
        PackLib_GstPackBufTbl[LulEntryIdx].usPackId          = LusPackId;
        PackLib_GstPackBufTbl[LulEntryIdx].usPackDataBufSize = LusBufSize;
        PackLib_GstPackBufTbl[LulEntryIdx].pPackDataAddr     = LpDataAddr;
        PackLib_GusPackDataSetSize[LulEntryIdx]              = NUM0;
        PackLib_GusPackDataSetCount[LulEntryIdx]             = NUM0;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_006]:[Gen5GW_CanEthConv_UD_32_006]
* Function Name: LinkPackIdTblAndBuffer
* Description  : Set Link info Convert Table to Buffer Table
* Arguments    : N/A
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) LinkPackIdTblAndBuffer(void)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulCheckIdx;

    LucRetVal = E_OK;

    /* Check BuffNo in Pack ID Table */
    for (LulEntryIdx = IDX_0; LulEntryIdx < PackLib_GulPackIdTblNum; LulEntryIdx++)
    {
        for (LulCheckIdx = IDX_0; LulCheckIdx < PackLib_GulPackBufTblNum; LulCheckIdx++)
        {
            if ((uint32)PackLib_GstPackIdTbl[LulEntryIdx].usPackId !=
                (uint32)PackLib_GstPackBufTbl[LulCheckIdx].usPackId)
            {
                /*  Do nothing */
            }
            else
            {
                PackLib_GulPackBufTblNo[LulEntryIdx] = LulCheckIdx;
                break;
            }
        }

        if (PackLib_GulPackBufTblNum > LulCheckIdx)
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_INIT_SID,
                                  CANETHCONV_E_CFG_PACKTBL);
            #endif
            LucRetVal = E_NOT_OK;
            break;
        }
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_32_007]:[Gen5GW_CanEthConv_UD_32_007]
* Function Name: PackLib_SetCanXLData
* Description  : Pack Function(Set)
* Arguments    : ucUnit -
*                    Unit No
*                ucCh -
*                    Channel No
*                *pCanFrame -
*                    Pointer to Can frame structure
*                *pPackInfo -
*                    Pointer to Result of Pack Can frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_SetCanXLData(const uint8 ucUnit, const uint8 ucCh,
                          const R_PackLib_CanXLFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;

    uint32 LulCan;
    uint32 LulDlc;
    uint32 LulCanId;
    uint32 LulCanIdMask;
    uint8  LucSduType;
    uint8  LucSec;    
    uint16 LusVcid;
    uint32 LulAcceptanceField;

    uint32 LulLen;
    uint16 LusBufSize;
    uint16 LusBufSetSize;
    uint16 LusDataStart;
    uint8 *LpDataAddr;
    uint32 LulBuffNo;

    /* Check CAN-DLC */
    if (((uint32)CANXL_DLC_SIZE_MIN <= pCanFrame->ulCanDlc)
    &&  ((uint32)CANXL_DLC_SIZE_MAX >= pCanFrame->ulCanDlc))
    {
        LucRetVal = E_OK;
    }
    else
    {        
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                              CANETHCONV_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LulCanId   = ((uint32)pCanFrame->pXLParams->usPriorityId | (uint32)CANXL_XLF_BIT);
        LulLen     = pCanFrame->ulCanDlc;
        LucSduType = pCanFrame->pXLParams->ucSduType; 
        LucSec     = pCanFrame->pXLParams->ucSec;
        LusVcid    = pCanFrame->pXLParams->usVcid;
        LulAcceptanceField = pCanFrame->pXLParams->ulAcceptanceField;

        /* Search entry config data */
        for (LulEntryIdx = IDX_0; LulEntryIdx < PackLib_GulPackIdTblNum; LulEntryIdx++)
        {
            LulCanIdMask = PackLib_GstPackIdTbl[LulEntryIdx].ulCanIdMask;

            if (((uint32)PackLib_GstPackIdTbl[LulEntryIdx].ucUnit           == (uint32)ucUnit) &&
                ((uint32)PackLib_GstPackIdTbl[LulEntryIdx].ucCh             == (uint32)ucCh)   &&
                ((PackLib_GstPackIdTbl[LulEntryIdx].ulCanId & LulCanIdMask) == (LulCanId & LulCanIdMask)))
            {
                LulBuffNo     = PackLib_GulPackBufTblNo[LulEntryIdx];

                LusBufSize    = PackLib_GstPackBufTbl[LulBuffNo].usPackDataBufSize;
                LusDataStart  = PackLib_GusPackDataSetSize[LulBuffNo];
                LpDataAddr    = &(PackLib_GstPackBufTbl[LulBuffNo].pPackDataAddr[LusDataStart]);
                LusBufSetSize = (uint16)((uint32)PackLib_GusPackDataSetSize[LulBuffNo] +
                                (uint32)(CAN_LEN_ID + CAN_LEN_DLC + CANXL_PARAM_LEN) + LulLen);

                if ((uint32)LusBufSize >= (uint32)LusBufSetSize)
                {
                    /* Enough Space */
                    LulCan     = ((uint32)pCanFrame->pXLParams->usPriorityId | (uint32)CANXL_XLF_BIT);
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    CanEthConv_UtilEndianConv32(&LulCan);
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

                    CanEthConv_UtilMemCpy(LpDataAddr, &LulCan, CAN_LEN_ID);

                    LulDlc     = pCanFrame->ulCanDlc;
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    CanEthConv_UtilEndianConv32(&LulDlc);
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_4]), &LulDlc, CAN_LEN_DLC);
                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_8]), &LucSduType, sizeof(LucSduType));
                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_9]), &LucSec, sizeof(LucSec));
                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_10]), &LusVcid, sizeof(LusVcid));
                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_12]), &LulAcceptanceField, sizeof(LulAcceptanceField));
                    CanEthConv_UtilMemCpy(&(LpDataAddr[IDX_16]), pCanFrame->pCanData, LulLen); 
                    PackLib_GusPackDataSetSize[LulBuffNo]  = LusBufSetSize;
                    PackLib_GusPackDataSetCount[LulBuffNo] = 
                        (uint16)((uint32)PackLib_GusPackDataSetCount[LulBuffNo] + (uint32)NUM1);
                }
                else
                {
                    #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                                          CANETHCONV_E_BUF_FULL);
                    #endif
                    /* Not Enough Space */
                    LucRetVal = E_NOT_OK;
                }

                pPackInfo->usPackId        = PackLib_GstPackBufTbl[LulBuffNo].usPackId;
                pPackInfo->usCanFrameCount = PackLib_GusPackDataSetCount[LulBuffNo];
                pPackInfo->usRemCap        = 
                    (uint16)((uint32)LusBufSize - (uint32)PackLib_GusPackDataSetSize[LulBuffNo]);
                break;
            }
            else
            {
                /*  Do nothing */
            }
        }

        if (PackLib_GulPackIdTblNum != LulEntryIdx)
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_PACKLIB_SETCANXLDATA_SID,
                                  CANETHCONV_E_MATCH);
            #endif
            /* No search results */
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
