/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the CAN-Ethernet Conversion function.
***********************************************************************************************************************/
#ifndef CDD_CANETHCONV_COMMON_H
#define CDD_CANETHCONV_COMMON_H

#include "rcar-xos/canethconv/CDD_CanEthConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Length definition */
#define MACADDR_LEN_IN_BYTE     6U
/* Subtype field definition */
#define SUBTYPE_TSCF            0x05U
#define SUBTYPE_NTSCF           0x82U
/* CAN frame max number and Rx buffer size */
#define CANFRAME_NUM_MAX        186U
#define CANRXBUFF_SIZE_MAX      1420U
/* CAN frame max length */
#define CANFRAME_LEN_MAX        64U
/* CANXL frame min and max length */
#define CANXLFRAME_LEN_MIN      1U
#define CANXLFRAME_LEN_MAX      1404U
/* The maximum number of CAN to Ethernet Routing Table Entry */
#define ETHTBL_ENTRY_NUM        200UL
/* The maximum number of Ethernet to CAN Routing Table Entry */
#define CANTBL_ENTRY_NUM        800UL
/* Maximum Ethernet frame size */
#define ETH_FRAME_SIZE_MAX      1500UL
/* Minimum Ethernet frame size */
#define ETH_FRAME_SIZE_MIN      64UL
/* Minimum and Maximum size of Ethernet frame payload */
#define ETH_FRAME_PAYLOAD_SIZE_MIN   46UL
#define ETH_FRAME_PAYLOAD_SIZE_MAX   1500UL

/* source mac address filter max size */
#define MACADDRESS_FILTER_NUM_MAX    (200U)
/* source ip address filter max size */
#define IPADDRESS_FILTER_NUM_MAX     (200U)
/* vlanid filter max size */
#define VLANID_FILTER_NUM_MAX        (8U)
/* streamid filter max size */
#define STREAMID_FILTER_NUM_MAX      (200U)

/* VLANID range */
#define VLANID_MAX          (4095U)

/* CAN ID range */
#define CANID_BASE_MAX         0x7FFU
#define CANID_EXTENDED_MIN     0x80000000U
#define CANID_EXTENDED_MAX     0x9FFFFFFFU
/* CANFD ID range */
#define CANFD_ID_BASE_MIN      0x40000000U
#define CANFD_ID_BASE_MAX      0x400007FFU
#define CANFD_ID_EXTENDED_MIN  0xC0000000U
#define CANFD_ID_EXTENDED_MAX  0xDFFFFFFFU
/* CANXL PriorityID range */
#define CANID_XL_MAX           0x07FFU

/* CAN Frame Header Length */
#define CAN_LEN_ID          4U
#define CAN_LEN_DLC         4U

/* CANXL Parameter Header Length */
#define CANXL_PARAM_LEN     8U

/* Header information */
#define CHECKSUM_ZERO       0U
#define PROTOCOL_UDP        0x11U

#define VER_AND_HEADERLEN_IPV4  0x45U
#define VER_CLASS_AND_LABEL_IPV6    0x60000000U
#define NOT_FRAGMENTED_IPV4     0x0000U
#define VERIFY_CKSUM        0xFFFFU
#define REPLACE_UDPSUM      (0xFFFFU)
#define MASK_FRAGMENT_MF_OFFSET 0x3FFFU
#define MASK_NTSCF_DATA_LENGTH  0x07FFU

/* Header length */
#define HEADER_LEN_ETH      14U
#define FCS_LEN_ETH         4U
#define HEADER_LEN_IPV4     20U
#define HEADER_LEN_IPV6     40U
#define HEADER_LEN_UDP      8U
#define HEADER_LEN_SEQNUM   4U
#define HEADER_LEN_NTSCF    12U
#define HEADER_LEN_TSCF     24U
#define HEADER_MAX_ETH      (4U + HEADER_LEN_IPV6 + HEADER_LEN_UDP + HEADER_LEN_SEQNUM + HEADER_LEN_TSCF)

/* Minimum Size of Can Rx Buffer */
#define CANBUF_SIZE_MIN     72U
/* Minimum Size of Eth Tx Buffer (VLAN(4)+IPV6(40)+UDP(8)+EncapSeq(4)+TSCF(24)+CAN(72) = 152) */
#define ETHBUF_SIZE_MIN     152U

/* Buffer Address and Size for LPDDR4 */
#ifdef RFS_ENV_SUPPORTED
  #define LPDDR4_ADDR_START   0x70000000U
  #define LPDDR4_SIZE         0x01FFFFFFU
  /* Buffer Address and Size for RT-SRAM */
  #define RT_SRAM_ADDR_START  0xFFE90000U
  #define RT_SRAM_SIZE        0x0000FFFFU
#else
  #ifdef X5H_VDK_PLATFORM_USED
    #define LPDDR4_ADDR_START   0x40000000U
    #define LPDDR4_SIZE         0x01FFFFFFU
    /* Buffer Address and Size for RT-SRAM */
    #define RT_SRAM_ADDR_START  0xFFE90000U
    #define RT_SRAM_SIZE        0x0000FFFFU
  #else
    /* Buffer Address and Size for LPDDR4 BOARD option */
      #define LPDDR4_ADDR_START   0x40000000U
      #define LPDDR4_SIZE         0x01FFFFFFU
      /* Buffer Address and Size for RT-SRAM */
      #define RT_SRAM_ADDR_START  0xEB200000U
      #define RT_SRAM_SIZE        0x000FFFFFU
  #endif /* X5H_VDK_PLATFORM_USED */
#endif /* RFS_ENV_SUPPORTED */

/* Bit mask definition */
#define MASK_1BIT       0x00000001UL
#define MASK_8BIT       0x000000FFUL
#define MASK_12BIT      0x00000FFFUL
#define MASK_16BIT      0x0000FFFFUL
#define MASK_32BIT      0xFFFFFFFFUL
/* Bit Shift definition */
#define SHIFT_1BIT      1UL
#define SHIFT_4BIT      4UL
#define SHIFT_7BIT      7UL
#define SHIFT_8BIT      8UL
#define SHIFT_15BIT     15UL
#define SHIFT_16BIT     16UL
#define SHIFT_24BIT     24UL
#define SHIFT_32BIT     32UL
/* Maximum value definition */
#define MAXVALUE_16BIT  0xFFFFU
/* for utility function */
#define ALIGN4          0x00000003UL
/* Constant definition */
#define NUM0            0U
#define NUM1            1U
#define NUM3            3U
#define NUM4            4U
#define NUM8            8U
/* Array index definition */
#define IDX_0           0U
#define IDX_1           1U
#define IDX_2           2U
#define IDX_3           3U
#define IDX_4           4U
#define IDX_5           5U
/* gPTP Sec Unit */
#define GPTP_SECUNIT    1000000000U
/* Default Can Packet Send Status */
#define CANPACKETSEND_DEFAULT   (0x3FFFFU)
/* CANXL XLF Bit */
#define CANXL_XLF_BIT   (0x20000000UL)

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* IEEE802.1Q Header type */
typedef struct
{
  uint16 usVlanId;
  uint16 usFrameType;
} CanEthConv_IEEE8021QType;

/* IPv4 Header Configuration */
typedef struct
{
    uint8 ucVerAndHeaderLen;
    uint8 ucServiceType;
    uint16 usPktLen;
    uint16 usId;
    uint16 usFragment;
    uint8 ucTTL;
    uint8 ucProtocol;
    uint16 usChecksum;
    uint32 ulSrcIpAddr;
    uint32 ulDestIpAddr;
} CanEthConv_Ipv4HeaderType;

/* IPv6 Header Configuration */
typedef struct
{
    uint32 ulVerClassAndLabel;
    uint16 usPayloadLen;
    uint8 ucNextHeader;
    uint8 ucHopLimit;
    uint32 aaSrcIpAddr[CANETHCONV_IPADDR_LEN_IN_WORD];
    uint32 aaDestIpAddr[CANETHCONV_IPADDR_LEN_IN_WORD];
} CanEthConv_Ipv6HeaderType;

/* UDP Header Configuration */
typedef struct
{
    uint16 usSrcPort;
    uint16 usDestPort;
    uint16 usLen;
    uint16 usChecksum;
} CanEthConv_UdpHeaderType;

/* AVTP Common Header Configuration */
typedef struct
{
    uint8 ucSubType;
    uint8 ucHVer;
} CanEthConv_AVTPCommonType;

/* AVTP(NTSCF) Header Configuration */
typedef struct
{
    uint8 ucSubType;
    uint8 ucSvVerDataLenMSB;
    uint8 ucDataLenLSB;
    uint8 ucSeqNum;
    uint32 aaStreamId[CANETHCONV_STREAMID_LEN_IN_WORD];
} CanEthConv_NTSCFType;

/* AVTP(TSCF) Header Configuration */
typedef struct
{
    uint8 ucSubType;
    /* StreamIdValue(1bit) + Version(3bit) + Media clock Restart(1bit) + Reserve(2bit) + avtp_timestamp vali(1bit) */
    uint8 ucSvVerMrRsvTv;
    uint8 ucSeqNum;
    uint8 ucReserveTu;                  /* timestamp uncertain(1bit) */
    uint32 aaStreamId[CANETHCONV_STREAMID_LEN_IN_WORD];
    uint32 ulAvtpTimestamp;
    uint32 ulReserved1;
    uint16 usStreamDataLength;
    uint16 usReserved1;
} CanEthConv_TSCFType;

/* IPv4 Pseudo Header for Checksum calculation */
typedef struct
{
    uint32 ulSrcIpAddr;
    uint32 ulDestIpAddr;
    uint8 ucPadZero;
    uint8 ucProtocol;
    uint16 usDataLen;
} CanEthConv_Ipv4PseudoHeaderType;

/* IPv6 Pseudo Header for Checksum calculation */
typedef struct
{
    uint32 aaSrcIpAddr[CANETHCONV_IPADDR_LEN_IN_WORD];
    uint32 aaDestIpAddr[CANETHCONV_IPADDR_LEN_IN_WORD];
    uint32 ulPayloadLen;
    uint8  aaPadZero[NUM3];
    uint8  ucNextHeader;
} CanEthConv_Ipv6PseudoHeaderType;
/*******************************************************************************
Exported global variables
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
/* Source Address/Port Configuration */
extern VAR(R_CanEthConv_EthSrcCfgType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstEthSrcCfg;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_CANETHCONV_COMMON_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
