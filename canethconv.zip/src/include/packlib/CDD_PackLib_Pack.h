/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Pack function for Pack Library.
***********************************************************************************************************************/
#ifndef CDD_PACKLIB_PACKING_H
#define CDD_PACKLIB_PACKING_H

#include "rcar-xos/canethconv/CDD_PackLib.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_PackInit(const R_PackLib_CfgType *pConfig);
extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_SetCanData(const uint8 ucUnit, const uint8 ucCh,
    const R_PackLib_CanFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo);
extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_SetCanXLData(const uint8 ucUnit, const uint8 ucCh,
    const R_PackLib_CanXLFrameType *pCanFrame, R_PackLib_PackInfoType *pPackInfo);
extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) PackLib_GetPackData(const uint16 usPackId, uint16 *pDataLen, 
                                                                         uint8 *pPackData);

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#endif /* CDD_PACKLIB_PACKING_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
