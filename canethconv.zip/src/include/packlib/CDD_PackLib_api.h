/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the API function for Packing Library.
***********************************************************************************************************************/
#ifndef CDD_PACKLIB_API_H
#define CDD_PACKLIB_API_H

#include "rcar-xos/canethconv/CDD_PackLib.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_INIT_8
#include "CanEthConv_MemMap.h" 
extern VAR(uint8, CANETHCONV_VAR_INIT)  PackLib_GucInitStatus;
#define CANETHCONV_STOP_SEC_VAR_INIT_8
#include "CanEthConv_MemMap.h" 

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_PACKLIB_API_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
