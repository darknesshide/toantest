/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Packing Library function.
***********************************************************************************************************************/
#ifndef CDD_PACKLIB_COMMON_H
#define CDD_PACKLIB_COMMON_H

#include "rcar-xos/canethconv/CDD_PackLib.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* The number of Pack Id Table Entry Range*/
#define PACKIDTBL_ENTRY_MAX            800U

/* The number of Buffer Address and Size Table Entry Range*/
#define PACKBUFTBL_ENTRY_MAX           800U

/* Pack Id Table Configuration Range */
#define PACK_ID_MAX                    0x0FFFU
/* CAN ID range */
#define CANID_BASE_MAX         0x07FFU
#define CANID_EXTENDED_MIN     0x80000000U
#define CANID_EXTENDED_MAX     0x9FFFFFFFU
/* CANFD ID range */
#define CANFD_ID_BASE_MIN      0x40000000U
#define CANFD_ID_BASE_MAX      0x400007FFU
#define CANFD_ID_EXTENDED_MIN  0xC0000000U
#define CANFD_ID_EXTENDED_MAX  0xDFFFFFFFU
/* CANXL PriorityID range */
#define CANID_XL_MAX           0x07FFU
/* CANXL XLF Bit */
#define CANXL_XLF_BIT          (0x20000000UL)

/* Destination unit and channel of CAN frame */
#define CAN_UNIT_MAX        1U
#define CAN_CHANNEL_MAX     7U
#define CANXL_UNIT_NUM      2U
#define CANXL_CHANNEL_MAX   1U

/* Buffer Address and Size Table Configuration Range */
#define PACKBUF_SIZE_MIN               8U    /* CAN ID 4Byte + CAN DLC 4Byte + CAN Data 0 Byte */
#define PACKBUF_SIZE_MAX               1420U /* MAX Ethernet Payload 1420Byte */

/* Maximum DLC size of CAN/CANFD */
#define CANDLC_SIZE_MAX                64U
/* Minimum and maximum DLC size of CANXL */
#define CANXL_DLC_SIZE_MIN             1U
#define CANXL_DLC_SIZE_MAX             1404U
/* Constant definition */
#define NUM0                           0U
#define NUM1                           1U

/* Array index definition */
#define IDX_0                          0U
#define IDX_4                          4U
#define IDX_8                          8U
#define IDX_9                          9U
#define IDX_10                         10U
#define IDX_12                         12U
#define IDX_16                         16U

#define CAN_LEN_ID                     4U
#define CAN_LEN_DLC                    4U
#define CANXL_PARAM_LEN                8U

/* Bit mask definition */
#define MASK_8BIT                      0x000000FFUL

#define CANID_MASK                     0xFFFFFFFFUL

/* Bit Shift definition */
#define SHIFT_8BIT                     8UL
#define SHIFT_16BIT                    16UL
#define SHIFT_24BIT                    24UL

/* Loop Condition */
#define PACKLIB_CLR                    0U
#define PACKLIB_SET                    1U


/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_PACKLIB_COMMON_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
