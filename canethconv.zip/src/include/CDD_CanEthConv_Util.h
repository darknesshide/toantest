/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Utility function.
***********************************************************************************************************************/
#ifndef CDD_CANETHCONV_UTIL_H
#define CDD_CANETHCONV_UTIL_H

#include "rcar-xos/canethconv/CDD_CanEthConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define CANETHCONV_LITTLE_ENDIAN    STD_ON

/* Can-DLC Values */
#define CANETHCONV_DLC_8    (8U)
#define CANETHCONV_DLC_12   (12U)
#define CANETHCONV_DLC_16   (16U)
#define CANETHCONV_DLC_20   (20U)
#define CANETHCONV_DLC_24   (24U)
#define CANETHCONV_DLC_32   (32U)
#define CANETHCONV_DLC_48   (48U)
#define CANETHCONV_DLC_64   (64U)

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

extern FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilMemCpy(void *pDest, const void *pSrc, const uint32 ulSize);
extern FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilMemSet(void *pDest, const uint8 ucMyChar, 
    const uint32 ulSize);
extern FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilCalcSum(const void *pBuf, const uint16 usBytes, uint32 *pSum);
extern FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilConvMacAddr8Bit(const uint32 *aaInputMacAddr, 
    uint8 *aaOutputMacAddr);
extern FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilConvMacAddr32Bit(const uint8 *aaInputMacAddr, 
    uint32 *aaOutputMacAddr);

#if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
extern void CanEthConv_UtilEndianConv16(uint16 *pValue);
extern void CanEthConv_UtilEndianConv32(uint32 *pValue);
#endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilCanDlcCheck(const uint32 ulCanDlc);

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#endif /* CDD_CANETHCONV_UTIL_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
