/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the CAN to Ethernet Conversion function.
***********************************************************************************************************************/
#ifndef CDD_CANETHCONV_CANTOETH_H
#define CDD_CANETHCONV_CANTOETH_H

#include "rcar-xos/canethconv/CDD_CanEthConv.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_CantoEth(const R_CanEthConv_CanFrameType *pCanFrame);
extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_CanXLtoEth(const R_CanEthConv_CanXLFrameType *pCanFrame);
extern FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_CantoEthInit(const R_CanEthConv_CfgType *pConfig);
extern void CanEthConv_CantoEthMain(void);

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#endif /* CDD_CANETHCONV_CANTOETH_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
