/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the CAN to Ethernet Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanEthConv_common.h"
#include "CDD_CanEthConv_CantoEth.h"
#include "CDD_CanEthConv_Util.h"
#include "CDD_CanEthConv_interface.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Header information */
#define SERVICE_TYPE_IPV4   0U

#define ID_IPV4                 0U
#define FRAGMENT_IPV4           0x4000U
#define TTL_IPV4                8U
#define HL_IPV6                 8U

#define FRAME_LIMIT_MIN         1U
#define FRAME_LIMIT_MAX         186U
#define TIME_LIMIT_MIN          1U
#define TIME_LIMIT_MAX          1000U

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
/* Source Address/Port Configuration */
VAR(R_CanEthConv_EthSrcCfgType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstEthSrcCfg;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
/*******************************************************************************
Private global variables and functions
*******************************************************************************/
/* CAN Rx Buffer*/
#define CANETHCONV_START_SEC_VAR_NO_INIT_PTR
#include "CanEthConv_MemMap.h" 
STATIC P2VAR(uint8, CANETHCONV_VAR_NO_INIT, CANETHCONV_CONFIG_DATA)  CanEthConv_GaaCanRxBuf;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulCanRxBufSize;
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulCanRxBufLen;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

/* Ethernet Tx Buffer*/
#define CANETHCONV_START_SEC_VAR_NO_INIT_PTR
#include "CanEthConv_MemMap.h" 
STATIC P2VAR(uint8, CANETHCONV_VAR_NO_INIT, CANETHCONV_CONFIG_DATA)  CanEthConv_GaaEthTxBuf;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulEthTxBufIdx;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
/* Conversion Mode / Buffer Mode / Frame Limit / Time Limit Configuration */
STATIC VAR(R_CanEthConv_ConvCfgType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstConvCfg;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* CAN to Ethernet Routing Table */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulEthRoutTblNum;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h"
STATIC VAR(R_CanEthConv_EthRoutTblType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstEthRoutTbl[ETHTBL_ENTRY_NUM];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* Message Authentication code length */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulCanCount;
/* Current Buffering Time and Ethernet Destination Information */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulBufTime;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h"
STATIC VAR(R_CanEthConv_EthRoutTblType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstEthDestInfo;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* Entry index matched in CAN to Ethernet routing table */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulEthTblEntryIdx;
/* Sequence number Index */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulSeqNumIndex[ETHTBL_ENTRY_NUM];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_8
#include "CanEthConv_MemMap.h" 
/* Sequence number for each destination */
STATIC VAR(uint8, CANETHCONV_VAR_NO_INIT)  CanEthConv_GucSeqNum[ETHTBL_ENTRY_NUM];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_8
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* encapsulation_sequence_num field */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulEncapSeqNum[ETHTBL_ENTRY_NUM];
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetEthRoutTbl(const R_CanEthConv_EthRoutTblType *pEthRoutTblCfg);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchEthRoutTbl(const R_CanEthConv_CanFrameType *pCanFrame, 
                    uint32 *pEntryIdx, R_CanEthConv_HeaderType *pHeaderField, uint8 *aaDestMacAddr);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateSeqNumIndex(void);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) ProcessBufMode(const R_CanEthConv_CanFrameType *pCanFrame, 
                    const uint32 ulEntryIdx, const R_CanEthConv_HeaderType *pHeaderField, const uint8 *aaDestMacAddr);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CreateAndSendEthFrame(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, const uint8 *aaDestMacAddr);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   StoreEthBufHeader(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderIpv4Ntscf(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderIpv4Tscf(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderIpv4(const R_CanEthConv_HeaderType *pHeaderField, 
                    uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderIpv6Ntscf(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderIpv6Tscf(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderIpv6(const R_CanEthConv_HeaderType *pHeaderField, 
                    uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderNtscf(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateEthHeaderTscf(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateVlanHeader(const R_CanEthConv_HeaderType *pHeaderField, 
                    uint32 *pSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateIpv4Header(const R_CanEthConv_HeaderType *pHeaderField, 
                    CanEthConv_Ipv4HeaderType *pIpHeader);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateIpv6Header(const R_CanEthConv_HeaderType *pHeaderField, 
                    CanEthConv_Ipv6HeaderType *pIpHeader);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CalcIpv4UdpPseudoCheckSum(const CanEthConv_Ipv4HeaderType *pIpv4Header,
                                        const CanEthConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CalcIpv6UdpPseudoCheckSum(const CanEthConv_Ipv6HeaderType *pIpv6Header,
                                        const CanEthConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) StoreEthBufData(const R_CanEthConv_CanFrameType *pCanFrame);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateNTSCFHeader(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField,
                    CanEthConv_NTSCFType *pstNTSCFHeader, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE)   CreateTSCFHeader(const uint32 ulEntryIdx, 
                    const R_CanEthConv_HeaderType *pHeaderField,
                    CanEthConv_TSCFType *pstTSCFHeader, uint32 *pHeaderSize);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) GetEncapSequenceNumber(const uint32 ulEntryIdx, uint32 *pSeqNo);

STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) ProcessBufModeForCanXL(
                             const R_CanEthConv_CanXLFrameType *pCanFrame, const uint32 ulEntryIdx,
                             const R_CanEthConv_HeaderType *pHeaderField, const uint8 *aaDestMacAddr);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchEthRoutTblForCanXL(
              const R_CanEthConv_CanXLFrameType *pCanFrame, uint32 *pEntryIdx,
              R_CanEthConv_HeaderType *pHeaderField, uint8 *aaDestMacAddr);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) StoreEthBufDataForCanXL(
                                                                      const R_CanEthConv_CanXLFrameType *pCanFrame);

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_001]:[Gen5GW_CanEthConv_UD_12_001]
* Function Name: CanEthConv_CantoEthInit
* Description  : Can to Ethernet Function Initialization.
* Arguments    : *pConfig -
*                    Initialization Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_CantoEthInit(const R_CanEthConv_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;
    uint32 LulCount;

    LucRetVal = E_OK;

    if (pConfig->pEthSrcCfg->aaSrcMacAddr[IDX_0] <= (uint32)MAXVALUE_16BIT)
    {
        switch (pConfig->pConvCfg->enConvMode)
        {
        case CANETHCONV_BASICMODE:
            if (((uint32)NUM0 == pConfig->pConvCfg->ulFrameLimit) &&
                ((uint32)NUM0 == pConfig->pConvCfg->ulTimeLimit))
            {
                /* Do Nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                      CANETHCONV_E_CFG_LIMIT);
                #endif
                LucRetVal = E_NOT_OK;
            }
            break;
        case CANETHCONV_BUFFERMODE:
            /* Fall through */
        case CANETHCONV_EMERGENCYMODE:
            if (((pConfig->pConvCfg->ulFrameLimit >= (uint32)FRAME_LIMIT_MIN)  &&
                 (pConfig->pConvCfg->ulFrameLimit <= (uint32)FRAME_LIMIT_MAX)) &&
                ((pConfig->pConvCfg->ulTimeLimit  >= (uint32)TIME_LIMIT_MIN)   &&
                 (pConfig->pConvCfg->ulTimeLimit  <= (uint32)TIME_LIMIT_MAX)))
            {
                /* Do Nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                      CANETHCONV_E_CFG_LIMIT);
                #endif
                LucRetVal = E_NOT_OK;
            }
            break;
        default:
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                  CANETHCONV_E_CFG_CONVMODE);
            #endif
            LucRetVal = E_NOT_OK;
            break;
        }        
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                              CANETHCONV_E_CFG_ETHSRC);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if ((pConfig->ulEthRoutTblEntryNum >= NUM1)
        &&  (pConfig->ulEthRoutTblEntryNum <= ETHTBL_ENTRY_NUM))
        {
            CanEthConv_GulEthRoutTblNum = pConfig->ulEthRoutTblEntryNum;
            /* Set Ethernet Routing Table */
            LucRetVal = SetEthRoutTbl(pConfig->pEthRoutTbl);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Set pConfig value to each global valiables */
                CanEthConv_GstConvCfg.enConvMode = pConfig->pConvCfg->enConvMode;
                CanEthConv_GstConvCfg.ulFrameLimit = pConfig->pConvCfg->ulFrameLimit;
                CanEthConv_GstConvCfg.ulTimeLimit = pConfig->pConvCfg->ulTimeLimit;
                CanEthConv_GaaCanRxBuf = pConfig->pBufCfg->pCanRxAddr;
                CanEthConv_GulCanRxBufSize = pConfig->pBufCfg->ulCanRxBufSize;
                CanEthConv_GaaEthTxBuf = pConfig->pBufCfg->pEthTxAddr;
                for (LulCount = (uint32)IDX_0; LulCount < (uint32)CANETHCONV_MACADDR_LEN_IN_WORD; LulCount++)
                {
                    CanEthConv_GstEthSrcCfg.aaSrcMacAddr[LulCount] = pConfig->pEthSrcCfg->aaSrcMacAddr[LulCount];
                }

                CanEthConv_GstEthSrcCfg.ulSrcIpv4Addr = pConfig->pEthSrcCfg->ulSrcIpv4Addr;

                for (LulCount = (uint32)IDX_0; LulCount < (uint32)CANETHCONV_IPADDR_LEN_IN_WORD; LulCount++)
                {
                    CanEthConv_GstEthSrcCfg.aaSrcIpv6Addr[LulCount] = pConfig->pEthSrcCfg->aaSrcIpv6Addr[LulCount];
                }

                CanEthConv_GstEthSrcCfg.usSrcUdpPort = pConfig->pEthSrcCfg->usSrcUdpPort;

                /* Initialize buffer */
                CanEthConv_GulEthTxBufIdx = NUM0;
                CanEthConv_GulCanRxBufLen = NUM0;
                CanEthConv_GulCanCount    = NUM0;
                CanEthConv_GulBufTime     = NUM0;

                CanEthConv_GstEthDestInfo.ulCanId                      = NUM0;
                CanEthConv_GstEthDestInfo.ulCanIdMask                  = NUM0;
                CanEthConv_GstEthDestInfo.aaDestMacAddr[IDX_0]         = NUM0;
                CanEthConv_GstEthDestInfo.aaDestMacAddr[IDX_1]         = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.ucIpSetFlag         = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.ucIpType            = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.ucAvtpFormat        = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.ucEmergencyFlag     = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.aaDestIpAddr[IDX_0] = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.aaDestIpAddr[IDX_1] = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.aaDestIpAddr[IDX_2] = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.aaDestIpAddr[IDX_3] = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.usDestUdpPort       = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.usVlanId            = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.ucStreamIdValid     = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.aaStreamId[IDX_0]   = NUM0;
                CanEthConv_GstEthDestInfo.stHeader.aaStreamId[IDX_1]   = NUM0;

                /* Create Sequence Number array Index */
                CreateSeqNumIndex();

                /* Initialize Sequence Number */
                CanEthConv_UtilMemSet(&CanEthConv_GucSeqNum[IDX_0], (uint8)NUM0,
                    sizeof(CanEthConv_GucSeqNum));
                CanEthConv_UtilMemSet(&CanEthConv_GulEncapSeqNum[IDX_0], (uint8)NUM0,
                    sizeof(CanEthConv_GulEncapSeqNum));
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                  CANETHCONV_E_CFG_ETHTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do Nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_013]:[Gen5GW_CanEthConv_UD_12_013]
* Function Name: CanEthConv_CantoEthMain
* Description  : Can to Ethernet Conversion Function
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_CantoEthMain(void)
{
    const R_CanEthConv_EthRoutTblType *LpEthDestInfo;
    uint8 LaaDestMacAddr[MACADDR_LEN_IN_BYTE];
    uint32 LulEntryIdx;

    if ((NULL_PTR != CanEthConv_GaaCanRxBuf)
    &&  (NULL_PTR != CanEthConv_GaaEthTxBuf))
    {
        if ((CANETHCONV_BUFFERMODE    == CanEthConv_GstConvCfg.enConvMode)
        ||  (CANETHCONV_EMERGENCYMODE == CanEthConv_GstConvCfg.enConvMode))
        {
            /* Check Time Limit Over. */
            CanEthConv_GulBufTime++;
            if (CanEthConv_GulBufTime >= CanEthConv_GstConvCfg.ulTimeLimit)
            {
                CanEthConv_GulBufTime = NUM0;

                /* Check Receive Data Size. */
                if ((uint32)NUM0 != CanEthConv_GulCanRxBufLen)
                {
                    LulEntryIdx   = CanEthConv_GulEthTblEntryIdx;
                    LpEthDestInfo = &CanEthConv_GstEthDestInfo;

                    /* Convert from 32 bit 2 Entry to 8 bit 6 Entry */
                    CanEthConv_UtilConvMacAddr8Bit(&LpEthDestInfo->aaDestMacAddr[IDX_0], &LaaDestMacAddr[IDX_0]);

                    (void)CreateAndSendEthFrame(LulEntryIdx, &LpEthDestInfo->stHeader, &LaaDestMacAddr[IDX_0]);
                    /* Initialize Ethernet Tx Buffer Index */
                    CanEthConv_GulEthTxBufIdx = NUM0;
                }
                else
                {
                    /* Do Nothing */
                }
            }
            else
            {
                /* Do Nothing */
            }
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_002]:[Gen5GW_CanEthConv_UD_12_002]
* Function Name: CanEthConv_CantoEth
* Description  : Can to Ethernet Conversion Function
* Arguments    : *pCanFrame -
*                    CAN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_CantoEth(const R_CanEthConv_CanFrameType *pCanFrame)
{
    Std_ReturnType          LucRetVal;
    uint32                  LulEntryIdx;
    R_CanEthConv_HeaderType LstHeaderField;
    uint8                   LucDestMacAddr[MACADDR_LEN_IN_BYTE];

    LucRetVal = E_OK;

    if ((NULL_PTR != CanEthConv_GaaCanRxBuf)
    &&  (NULL_PTR != CanEthConv_GaaEthTxBuf))
    {
        /* Check CAN-ID */
        if ((pCanFrame->ulCanId <= (uint32)CANID_BASE_MAX)
        /* Check Extended CAN ID */
        || ((pCanFrame->ulCanId >= (uint32)CANID_EXTENDED_MIN)
        &&  (pCanFrame->ulCanId <= (uint32)CANID_EXTENDED_MAX))
        /* Check Standard CANFD ID */
        || ((pCanFrame->ulCanId >= (uint32)CANFD_ID_BASE_MIN)
        &&  (pCanFrame->ulCanId <= (uint32)CANFD_ID_BASE_MAX))
        /* Check Extended CANFD ID */
        || ((pCanFrame->ulCanId >= (uint32)CANFD_ID_EXTENDED_MIN)
        &&  (pCanFrame->ulCanId <= (uint32)CANFD_ID_EXTENDED_MAX)))
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                  CANETHCONV_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }

        /* Check CAN-DLC */
        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = CanEthConv_UtilCanDlcCheck(pCanFrame->ulCanDlc);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do Nothing */
            }
            else
            {                
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                      CANETHCONV_E_INV_PARAM);
                #endif
            }
        }
        else
        {
            /* Do Nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = SearchEthRoutTbl(pCanFrame, &LulEntryIdx, &LstHeaderField, &LucDestMacAddr[IDX_0]);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Check Conversion Mode */
                if (CANETHCONV_BASICMODE == CanEthConv_GstConvCfg.enConvMode)
                {
                    CanEthConv_EnterCriticalUserDef();
                    LucRetVal = StoreEthBufData(pCanFrame);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        LucRetVal = CreateAndSendEthFrame(LulEntryIdx, &LstHeaderField, &LucDestMacAddr[IDX_0]);
                        if ((uint8)E_OK == LucRetVal)
                        {
                            /* Do nothing */
                        }
                        else
                        {
                            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                            /* Report to DET */
                            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID,
                                                  R_CANETHCONV_CANTOETH_SID, CANETHCONV_E_TRANS);
                            #endif
                        }
                        /* Initialize Ethernet Tx Buffer Index */
                        CanEthConv_GulEthTxBufIdx = NUM0;
                    }
                    else
                    {
                        /* Do nothing */
                    }
                    CanEthConv_ExitCriticalUserDef();
                }
                else
                {
                    LucRetVal = ProcessBufMode(pCanFrame, LulEntryIdx, &LstHeaderField, &LucDestMacAddr[IDX_0]);
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID, 
                              CANETHCONV_E_PARAM_CONFIG);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_003]:[Gen5GW_CanEthConv_UD_12_003]
* Function Name: SetEthRoutTbl
* Description  : CAN to Ethernet Routing Table Setting.
* Arguments    : *pEthRoutTblCfg -
*                    CAN to Ethernet Routing Table Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetEthRoutTbl(const R_CanEthConv_EthRoutTblType *pEthRoutTblCfg)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulEthEntryNum;
    uint32 LulCanId;

    LucRetVal = E_OK;
    LulEthEntryNum = CanEthConv_GulEthRoutTblNum;

    /* Check All entry config data */
    for (LulEntryIdx = IDX_0; LulEntryIdx < LulEthEntryNum; LulEntryIdx++)
    {
        LulCanId = pEthRoutTblCfg[LulEntryIdx].ulCanId;
        /* Check Standard CAN ID */
        if ((LulCanId <= (uint32)CANID_BASE_MAX)
        /* Check Extended CAN ID */
        || ((LulCanId >= (uint32)CANID_EXTENDED_MIN)    && (LulCanId <= (uint32)CANID_EXTENDED_MAX))
        /* Check Standard CANFD ID */
        || ((LulCanId >= (uint32)CANFD_ID_BASE_MIN)     && (LulCanId <= (uint32)CANFD_ID_BASE_MAX))
        /* Check Extended CANFD ID */
        || ((LulCanId >= (uint32)CANFD_ID_EXTENDED_MIN) && (LulCanId <= (uint32)CANFD_ID_EXTENDED_MAX))
        /* Check CANXL ID */
        || ((LulCanId >= (uint32)CANXL_XLF_BIT) && (LulCanId <= ((uint32)CANID_XL_MAX | (uint32)CANXL_XLF_BIT))))
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                  CANETHCONV_E_CFG_ETHTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {
            if ((pEthRoutTblCfg[LulEntryIdx].aaDestMacAddr[IDX_0]             <= (uint32)MASK_16BIT)
            &&  ((uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucIpSetFlag     <= (uint32)CANETHCONV_SET)
            &&  ((uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucIpType        <= (uint32)CANETHCONV_FLAG_IPV6)
            &&  (((uint32)CANETHCONV_FLAG_NTSCF == (uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucAvtpFormat)
            ||   ((uint32)CANETHCONV_FLAG_TSCF  == (uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucAvtpFormat)
            ||   ((uint32)CANETHCONV_AVTP_NONE  == (uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucAvtpFormat))
            &&  ((uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.usVlanId        <= (uint32)VLANID_MAX)
            &&  ((uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucStreamIdValid <= (uint32)CANETHCONV_VALID))
            {
                if (((uint32)CANETHCONV_CLR       != (uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucIpSetFlag)
                ||  ((uint32)CANETHCONV_AVTP_NONE != (uint32)pEthRoutTblCfg[LulEntryIdx].stHeader.ucAvtpFormat))
                {
                    /* Check one entry is OK. Next entry. */
                }
                else
                {
                    /* Check one entry is NG. Exit loop. */
                    #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                          CANETHCONV_E_CFG_ETHTBL);
                    #endif
                    LucRetVal = E_NOT_OK;
                }
            }
            else
            {
                /* Check one entry is NG. Exit loop. */
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                      CANETHCONV_E_CFG_ETHTBL);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do Nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            /* Do Nothing */
        }
        else
        {
            break;
        }
    } /* for */

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy from Configuration to Table */
        CanEthConv_UtilMemCpy(CanEthConv_GstEthRoutTbl, pEthRoutTblCfg,
            (sizeof(R_CanEthConv_EthRoutTblType) * LulEthEntryNum));
    }
    else
    {
        /*  Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_004]:[Gen5GW_CanEthConv_UD_12_004]
* Function Name: SearchEthRoutTbl
* Description  : Search CAN to Ethernet Routing Table.
* Arguments    : *pCanFrame -
*                    CAN frame
*                *pEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *aaDestMacAddr -
*                    Destination MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchEthRoutTbl(const R_CanEthConv_CanFrameType *pCanFrame,
                                  uint32 *pEntryIdx, R_CanEthConv_HeaderType *pHeaderField, uint8 *aaDestMacAddr)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulComparedCanId;
    uint32 LulEntryCanId;

    LucRetVal = E_NOT_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < CanEthConv_GulEthRoutTblNum; LulEntryIdx++)
    {
        /* Apply CAN ID Mask */
        LulComparedCanId = pCanFrame->ulCanId &
            CanEthConv_GstEthRoutTbl[LulEntryIdx].ulCanIdMask;
        LulEntryCanId = CanEthConv_GstEthRoutTbl[LulEntryIdx].ulCanId &
            CanEthConv_GstEthRoutTbl[LulEntryIdx].ulCanIdMask;

        if (LulComparedCanId == LulEntryCanId)
        {
            /* Entry is match. Save Entry ID and End Search */
            *pEntryIdx = LulEntryIdx;
            LucRetVal = E_OK;
            break;
        }
        else
        {
            /* Entry is not match. Next Entry */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy from CAN to Ethernet Routing Table Entry to pHeaderField */
        *pHeaderField = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader;
        /* To address the warning that it has not been initialized with MISRA-C. */
        pHeaderField->ucIpSetFlag     = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucIpSetFlag;
        pHeaderField->ucIpType        = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucIpType;
        pHeaderField->ucAvtpFormat    = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucAvtpFormat;
        pHeaderField->ucEmergencyFlag = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucEmergencyFlag;
        pHeaderField->usDestUdpPort   = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.usDestUdpPort;
        pHeaderField->usVlanId        = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.usVlanId;
        pHeaderField->ucStreamIdValid = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucStreamIdValid;

        /* Convert from 32 bit 2 Entry to 8 bit 6 Entry */
        CanEthConv_UtilConvMacAddr8Bit(&CanEthConv_GstEthRoutTbl[LulEntryIdx].aaDestMacAddr[IDX_0],
                                       &aaDestMacAddr[IDX_0]);
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                              CANETHCONV_E_MATCH);
        #endif
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_020]:[Gen5GW_CanEthConv_UD_12_020]
* Function Name: CreateSeqNumIndex
* Description  : Search CAN to Ethernet Routing Table.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateSeqNumIndex(void)
{
    uint32 LulSearchIdx;
    uint32 LulEntryIdx;

    /* loop all element */
    for (LulSearchIdx = IDX_0; LulSearchIdx < CanEthConv_GulEthRoutTblNum; LulSearchIdx++)
    {
        /* Initialize Index */
        CanEthConv_GulSeqNumIndex[LulSearchIdx] = LulSearchIdx;

        /* Search Same destination */
        for (LulEntryIdx = IDX_0; LulEntryIdx < LulSearchIdx; LulEntryIdx++)
        {
            if ((CanEthConv_GstEthRoutTbl[LulEntryIdx].aaDestMacAddr[IDX_0]             ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].aaDestMacAddr[IDX_0])
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].aaDestMacAddr[IDX_1]             ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].aaDestMacAddr[IDX_1])
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_0]     ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_0])
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_1]     ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_1])
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_2]     ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_2])
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.aaDestIpAddr[IDX_3]     ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.aaDestIpAddr[IDX_3])
            &&  ((uint32)CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.usDestUdpPort   ==
                (uint32)CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.usDestUdpPort)
            &&  ((uint32)CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucStreamIdValid ==
                (uint32)CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.ucStreamIdValid)
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.aaStreamId[IDX_0]       ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.aaStreamId[IDX_0])
            &&  (CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.aaStreamId[IDX_1]       ==
                CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.aaStreamId[IDX_1])
            &&  ((uint32)CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucIpSetFlag     ==
                (uint32)CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.ucIpSetFlag)
            &&  ((uint32)CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucIpType        ==
                (uint32)CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.ucIpType)
            &&  ((uint32)CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucAvtpFormat    ==
                (uint32)CanEthConv_GstEthRoutTbl[LulSearchIdx].stHeader.ucAvtpFormat))
            {
                /* Update Same destination Index */
                CanEthConv_GulSeqNumIndex[LulSearchIdx] = LulEntryIdx;
                break;
            }
            else
            {
                /* No Entry is matched */
            }
        }
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_014]:[Gen5GW_CanEthConv_UD_12_014]
* Function Name: ProcessBufMode
* Description  : Create Ethernet Frame and Send with Buffer Type or Emergency Type
* Arguments    : *pCanFrame -
*                    CAN frame
*                ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *aaDestMacAddr -
*                    Destination MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) ProcessBufMode(const R_CanEthConv_CanFrameType *pCanFrame, 
    const uint32 ulEntryIdx, const R_CanEthConv_HeaderType *pHeaderField, const uint8 *aaDestMacAddr)
{
    Std_ReturnType                      LucRetVal;
    uint32                              LulEntryIdx;
    uint32                              LulDataSize;
    uint32                              LaaDestMacAddr[CANETHCONV_MACADDR_LEN_IN_WORD];
    uint8                               LaaOldDestMacAddr[MACADDR_LEN_IN_BYTE];
    const R_CanEthConv_EthRoutTblType   *LpEthDestInfo;

    LucRetVal = E_OK;

    /* Convert from 8 bit 6 Entry to 32 bit 2 Entry */
    CanEthConv_UtilConvMacAddr32Bit(&aaDestMacAddr[IDX_0], &LaaDestMacAddr[IDX_0]);

    /* Check Receive Data Size. */
    if ((uint32)NUM0 != CanEthConv_GulCanRxBufLen)
    {
        CanEthConv_EnterCriticalUserDef();

        /* Get Buffer destination info */
        LulEntryIdx   = CanEthConv_GulEthTblEntryIdx;
        LpEthDestInfo = &CanEthConv_GstEthDestInfo;
        /* Get Buffer size if adding the next CAN/CANFD frame */
        LulDataSize = CanEthConv_GulCanRxBufLen + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC + pCanFrame->ulCanDlc;

        /* Different Destination info? */
        if ((LpEthDestInfo->aaDestMacAddr[IDX_0]             == LaaDestMacAddr[IDX_0])
        &&  (LpEthDestInfo->aaDestMacAddr[IDX_1]             == LaaDestMacAddr[IDX_1])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_0]     == pHeaderField->aaDestIpAddr[IDX_0])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_1]     == pHeaderField->aaDestIpAddr[IDX_1])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_2]     == pHeaderField->aaDestIpAddr[IDX_2])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_3]     == pHeaderField->aaDestIpAddr[IDX_3])
        &&  ((uint32)LpEthDestInfo->stHeader.usDestUdpPort   == (uint32)pHeaderField->usDestUdpPort)
        &&  ((uint32)LpEthDestInfo->stHeader.ucStreamIdValid == (uint32)pHeaderField->ucStreamIdValid)
        &&  (LpEthDestInfo->stHeader.aaStreamId[IDX_0]       == pHeaderField->aaStreamId[IDX_0])
        &&  (LpEthDestInfo->stHeader.aaStreamId[IDX_1]       == pHeaderField->aaStreamId[IDX_1])
        &&  ((uint32)LpEthDestInfo->stHeader.ucIpSetFlag     == (uint32)pHeaderField->ucIpSetFlag)
        &&  ((uint32)LpEthDestInfo->stHeader.ucIpType        == (uint32)pHeaderField->ucIpType)
        &&  ((uint32)LpEthDestInfo->stHeader.ucAvtpFormat    == (uint32)pHeaderField->ucAvtpFormat)
        /* Check Buffer size is full if adding the next CAN/CANFD frame */
        &&  ((uint32)LulDataSize <= CanEthConv_GulCanRxBufSize))
        {
            /* Destination is the same. Do nothing. */
        }
        else
        {
            /* Destination is different. Send frame in buffer. */
            /* Convert from 32 bit 2 Entry to 8 bit 6 Entry */
            CanEthConv_UtilConvMacAddr8Bit(&LpEthDestInfo->aaDestMacAddr[IDX_0], &LaaOldDestMacAddr[IDX_0]);

            LucRetVal = CreateAndSendEthFrame(LulEntryIdx, &LpEthDestInfo->stHeader, &LaaOldDestMacAddr[IDX_0]);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                      CANETHCONV_E_TRANS);
                #endif
            }
            /* Initialize Ethernet Tx Buffer Index */
            CanEthConv_GulEthTxBufIdx = NUM0;
        }
        CanEthConv_ExitCriticalUserDef();
    }
    else
    {
        /* Do Nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        CanEthConv_EnterCriticalUserDef();

        LucRetVal = StoreEthBufData(pCanFrame);
        if (((uint8)E_OK == LucRetVal)
        &&  (((CanEthConv_GulCanRxBufLen + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC) > CanEthConv_GulCanRxBufSize)
        ||  (CanEthConv_GulCanCount            >= CanEthConv_GstConvCfg.ulFrameLimit)
        ||  (((uint32)CANETHCONV_EMERGENCYMODE == (uint32)CanEthConv_GstConvCfg.enConvMode)
        &&   ((uint32)CANETHCONV_SET           == (uint32)pHeaderField->ucEmergencyFlag))))
        {
            /* Sending conditions met. Send frame in buffer. */
            LucRetVal = CreateAndSendEthFrame(ulEntryIdx, pHeaderField, &aaDestMacAddr[IDX_0]);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                      CANETHCONV_E_TRANS);
                #endif
            }
            /* Initialize Ethernet Tx Buffer Index */
            CanEthConv_GulEthTxBufIdx = NUM0;
        }
        else
        {
            /* to Buffer */
            CanEthConv_GulEthTblEntryIdx       = ulEntryIdx;
            CanEthConv_GstEthDestInfo.stHeader = *pHeaderField;
            CanEthConv_GstEthDestInfo.aaDestMacAddr[IDX_0] = LaaDestMacAddr[IDX_0];
            CanEthConv_GstEthDestInfo.aaDestMacAddr[IDX_1] = LaaDestMacAddr[IDX_1];
        }

        CanEthConv_ExitCriticalUserDef();
    }
    else
    {
        /* Do Nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_005]:[Gen5GW_CanEthConv_UD_12_005]
* Function Name: CreateAndSendEthFrame
* Description  : Create Ethernet Frame and Send.
* Arguments    : ulEntryIdx - 
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *aaDestMacAddr -
*                    Destination MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CreateAndSendEthFrame(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, const uint8 *aaDestMacAddr)
{
    Std_ReturnType LucRetVal;
    uint32 LulHeaderSize;
    uint32 LulTotalFrameSize;
    uint8 *LpBuffPtr;
    uint32 LulPaddingByte;
    uint16 LusFrameType;

    LulHeaderSize = NUM0;

    /* Set Header to Ethernet Tx Buffer */
    StoreEthBufHeader(ulEntryIdx, pHeaderField, &LulHeaderSize);

    LulTotalFrameSize = CanEthConv_GulCanRxBufLen + LulHeaderSize + (uint32)HEADER_LEN_ETH + (uint32)FCS_LEN_ETH;

    if (LulTotalFrameSize < ETH_FRAME_SIZE_MIN)
    {
        /* Padding 0 CAN Rx Buffer to meet the minimum Ethernet frame size */
        LulPaddingByte = ETH_FRAME_SIZE_MIN - LulTotalFrameSize;
        LpBuffPtr = &CanEthConv_GaaCanRxBuf[CanEthConv_GulCanRxBufLen];
        CanEthConv_UtilMemSet(LpBuffPtr, (uint8)NUM0, LulPaddingByte);
        CanEthConv_GulCanRxBufLen += LulPaddingByte;
        LulTotalFrameSize = ETH_FRAME_SIZE_MIN;
    }
    else
    {
        /*  Do nothing */
    }

    /* Copy Ethernet data buffer to Ethernet Tx Buffer */
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx],
        &CanEthConv_GaaCanRxBuf[IDX_0], CanEthConv_GulCanRxBufLen);
    /* Clear Ethernet Data Buffer */
    CanEthConv_GulCanRxBufLen = NUM0;
    /* Clear CAN Count */
    CanEthConv_GulCanCount = NUM0;

    /* When passing to API, excludes Ethernet Header and FCS Length */
    LulTotalFrameSize = LulTotalFrameSize - (uint32)HEADER_LEN_ETH - (uint32)FCS_LEN_ETH;

    if ((uint32)NUM0 == (uint32)pHeaderField->usVlanId)
    {
        if ((uint32)CANETHCONV_CLR == (uint32)pHeaderField->ucIpSetFlag)
        {
            LusFrameType = CANETHCONV_FRAMETYPE_AVTP;
        }
        else
        {
            if ((uint32)CANETHCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
            {
                LusFrameType = CANETHCONV_FRAMETYPE_IPV4;
            }
            else
            {
                LusFrameType = CANETHCONV_FRAMETYPE_IPV6;
            }
        }
    }
    else
    {
        LusFrameType = CANETHCONV_FRAMETYPE_8021Q;
    }

    /* Ethernet Transmit */
    LucRetVal = (uint8)CanEthConv_EthTransmitUserDef(&aaDestMacAddr[IDX_0], LusFrameType,
                                              &CanEthConv_GaaEthTxBuf[IDX_0], LulTotalFrameSize);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_006]:[Gen5GW_CanEthConv_UD_12_006]
* Function Name: StoreEthBufHeader
* Description  : Store Ethernet Header to Tx Buffer.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) StoreEthBufHeader(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    if ((uint32)CANETHCONV_SET == (uint32)pHeaderField->ucIpSetFlag)
    {
        if ((uint32)CANETHCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
        {
            switch ((uint32)pHeaderField->ucAvtpFormat)
            {
            case CANETHCONV_FLAG_NTSCF:
                /* Ipv4Ntscf IPv4+UDP+SeqNo+NTSCF+Payload */
                CreateEthHeaderIpv4Ntscf(ulEntryIdx, pHeaderField, pHeaderSize);
                break;
            case CANETHCONV_FLAG_TSCF:
                /* Ipv4Tscf IPv4+UDP+SeqNo+TSCF+Payload */
                CreateEthHeaderIpv4Tscf(ulEntryIdx, pHeaderField, pHeaderSize);
                break;
            case CANETHCONV_AVTP_NONE:
                /* Fall through */
            default:
                /* Ipv4     IPv4+UDP+Payload */
                CreateEthHeaderIpv4(pHeaderField, pHeaderSize);
                break;
            }
        }
        else
        {
            switch ((uint32)pHeaderField->ucAvtpFormat)
            {
            case CANETHCONV_FLAG_NTSCF:
                /* Ipv6Ntscf IPv6+UDP+SeqNo+NTSCF+Payload */
                CreateEthHeaderIpv6Ntscf(ulEntryIdx, pHeaderField, pHeaderSize);
                break;
            case CANETHCONV_FLAG_TSCF:
                /* Ipv6Tscf  IPv6+UDP+SeqNo+TSCF+Payload */
                CreateEthHeaderIpv6Tscf(ulEntryIdx, pHeaderField, pHeaderSize);
                break;
            case CANETHCONV_AVTP_NONE:
                /* Fall through */
            default:
                /* Ipv6      IPv6+UDP+Payload */
                CreateEthHeaderIpv6(pHeaderField, pHeaderSize);
                break;
            }
        }
    }
    else
    {
        switch ((uint32)pHeaderField->ucAvtpFormat)
        {
        case CANETHCONV_FLAG_NTSCF:
            /* Ntscf NTSCF+Payload */
            CreateEthHeaderNtscf(ulEntryIdx, pHeaderField, pHeaderSize);
            break;
        case CANETHCONV_FLAG_TSCF:
            /* Tscf  TSCF+Payload */
            CreateEthHeaderTscf(ulEntryIdx, pHeaderField, pHeaderSize);
            break;
        case CANETHCONV_AVTP_NONE:
            /* Fall through */
        default:
            /* Nothing */
            break;
        }
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_022]:[Gen5GW_CanEthConv_UD_12_022]
* Function Name: CreateEthHeaderIpv4Ntscf
* Description  : Store Ethernet Header to Tx Buffer.(IPv4+UDP+SEQNO+NTSCF)
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderIpv4Ntscf(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    const uint32              LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32                    LulTotalHeaderSize;
    uint32                    LulSeqNum;
    uint32                    LulChecksum;
    CanEthConv_Ipv4HeaderType LstIpv4Header;
    CanEthConv_UdpHeaderType  LstUdpHeader;
    CanEthConv_NTSCFType      LstNTSCFHeader;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Set IPv4/UDP Header (Big Endian) */
    CreateIpv4Header(pHeaderField, &LstIpv4Header);
    /* Add IPv4 header field size. */
    LulTotalHeaderSize += sizeof(LstIpv4Header);

    /* Create UDP Header */
    LstUdpHeader.usSrcPort  = CanEthConv_GstEthSrcCfg.usSrcUdpPort;
    LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
    LstUdpHeader.usLen      = (uint16)(HEADER_LEN_UDP + HEADER_LEN_SEQNUM + HEADER_LEN_NTSCF + LulEthBufLen);
    LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Add UDP header field size. */
    LulTotalHeaderSize += sizeof(LstUdpHeader);

    GetEncapSequenceNumber(ulEntryIdx, &LulSeqNum);
    /* Add encapsulation_sequence_num field size. */
    LulTotalHeaderSize += (uint32)HEADER_LEN_SEQNUM;

    /* Create NTSCF Header */
    CreateNTSCFHeader(ulEntryIdx, pHeaderField, &LstNTSCFHeader, &LulTotalHeaderSize);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /************************************
       Calculate CheckSum
    *************************************/
    /* for Pseudo UDP */
    LulChecksum = NUM0;
    CalcIpv4UdpPseudoCheckSum(&LstIpv4Header, &LstUdpHeader, &LulChecksum);

    /* for UDP Header */
    CanEthConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(CanEthConv_UdpHeaderType), &LulChecksum);

    /* for Sequence Number, AVTP Header */
    CanEthConv_UtilCalcSum(&LulSeqNum, (uint16)sizeof(LulSeqNum), &LulChecksum);
    CanEthConv_UtilCalcSum(&LstNTSCFHeader, (uint16)sizeof(CanEthConv_NTSCFType), &LulChecksum);
        
    /* for CAN Rx Buffer stored data */
    CanEthConv_UtilCalcSum(&CanEthConv_GaaCanRxBuf[IDX_0], (uint16)LulEthBufLen, &LulChecksum);
    LstUdpHeader.usChecksum = (uint16)~LulChecksum;
    if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
    {
        LstUdpHeader.usChecksum = REPLACE_UDPSUM;
    }
    else
    {
        /* Do nothing */
    }

    /************************************
       Copy Tx Buffer
    *************************************/
    /* Copy IPv4 Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstIpv4Header, sizeof(LstIpv4Header));
    CanEthConv_GulEthTxBufIdx += sizeof(LstIpv4Header);

    /* Copy UDP Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstUdpHeader);

    /* Set encapsulation_sequence_num field to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LulSeqNum, sizeof(LulSeqNum));
    CanEthConv_GulEthTxBufIdx += sizeof(LulSeqNum);

    /* Copy NTSCF Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstNTSCFHeader, sizeof(LstNTSCFHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstNTSCFHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_023]:[Gen5GW_CanEthConv_UD_12_023]
* Function Name: CreateEthHeaderIpv4Tscf
* Description  : Store Ethernet Header to Tx Buffer.(IPv4+UDP+SEQNO+TSCF)
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderIpv4Tscf(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    const uint32              LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32                    LulTotalHeaderSize;
    uint32                    LulSeqNum;
    uint32                    LulChecksum;
    CanEthConv_Ipv4HeaderType LstIpv4Header;
    CanEthConv_UdpHeaderType  LstUdpHeader;
    CanEthConv_TSCFType       LstTSCFHeader;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Set IPv4/UDP Header (Big Endian) */
    CreateIpv4Header(pHeaderField, &LstIpv4Header);
    /* Add IPv4 header field size. */
    LulTotalHeaderSize += sizeof(LstIpv4Header);

    /* Create UDP Header */
    LstUdpHeader.usSrcPort  = CanEthConv_GstEthSrcCfg.usSrcUdpPort;
    LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
    LstUdpHeader.usLen      = (uint16)(HEADER_LEN_UDP + HEADER_LEN_SEQNUM + HEADER_LEN_TSCF + LulEthBufLen);
    LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Add UDP header field size. */
    LulTotalHeaderSize += sizeof(LstUdpHeader);

    GetEncapSequenceNumber(ulEntryIdx, &LulSeqNum);
    /* Add encapsulation_sequence_num field size. */
    LulTotalHeaderSize += (uint32)HEADER_LEN_SEQNUM;

    /* Create TSCF Header */
    CreateTSCFHeader(ulEntryIdx, pHeaderField, &LstTSCFHeader, &LulTotalHeaderSize);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /************************************
       Calculate CheckSum
    *************************************/
    /* for Pseudo UDP */
    LulChecksum = NUM0;
    CalcIpv4UdpPseudoCheckSum(&LstIpv4Header, &LstUdpHeader, &LulChecksum);

    /* for UDP Header */
    CanEthConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(CanEthConv_UdpHeaderType), &LulChecksum);

    /* for Sequence Number, AVTP Header */
    CanEthConv_UtilCalcSum(&LulSeqNum, (uint16)sizeof(LulSeqNum), &LulChecksum);
    CanEthConv_UtilCalcSum(&LstTSCFHeader, (uint16)sizeof(CanEthConv_TSCFType), &LulChecksum);
        
    /* for CAN Rx Buffer stored data */
    CanEthConv_UtilCalcSum(&CanEthConv_GaaCanRxBuf[IDX_0], (uint16)LulEthBufLen, &LulChecksum);
    LstUdpHeader.usChecksum = (uint16)~LulChecksum;
    if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
    {
        LstUdpHeader.usChecksum = REPLACE_UDPSUM;
    }
    else
    {
        /* Do nothing */
    }

    /************************************
       Copy Tx Buffer
    *************************************/
    /* Copy IPv4 Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstIpv4Header, sizeof(LstIpv4Header));
    CanEthConv_GulEthTxBufIdx += sizeof(LstIpv4Header);

    /* Copy UDP Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstUdpHeader);

    /* Set encapsulation_sequence_num field to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LulSeqNum, sizeof(LulSeqNum));
    CanEthConv_GulEthTxBufIdx += sizeof(LulSeqNum);

    /* Copy TSCF Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstTSCFHeader, sizeof(LstTSCFHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstTSCFHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_024]:[Gen5GW_CanEthConv_UD_12_024]
* Function Name: CreateEthHeaderIpv4
* Description  : Store Ethernet Header to Tx Buffer.(IPv4+UDP)
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderIpv4(const R_CanEthConv_HeaderType *pHeaderField, 
    uint32 *pHeaderSize)
{
    const uint32              LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32                    LulTotalHeaderSize;
    uint32                    LulChecksum;
    CanEthConv_Ipv4HeaderType LstIpv4Header;
    CanEthConv_UdpHeaderType  LstUdpHeader;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Set IPv4/UDP Header (Big Endian) */
    CreateIpv4Header(pHeaderField, &LstIpv4Header);
    /* Add IPv4 header field size. */
    LulTotalHeaderSize += sizeof(LstIpv4Header);

    /* Create UDP Header */
    LstUdpHeader.usSrcPort  = CanEthConv_GstEthSrcCfg.usSrcUdpPort;
    LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
    LstUdpHeader.usLen      = (uint16)((uint32)HEADER_LEN_UDP + (uint32)LulEthBufLen);
    LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Add UDP header field size. */
    LulTotalHeaderSize += sizeof(LstUdpHeader);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /************************************
       Calculate CheckSum
    *************************************/
    /* for Pseudo UDP */
    LulChecksum = NUM0;
    CalcIpv4UdpPseudoCheckSum(&LstIpv4Header, &LstUdpHeader, &LulChecksum);

    /* for UDP Header */
    CanEthConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(CanEthConv_UdpHeaderType), &LulChecksum);

    /* for CAN Rx Buffer stored data */
    CanEthConv_UtilCalcSum(&CanEthConv_GaaCanRxBuf[IDX_0], (uint16)LulEthBufLen, &LulChecksum);
    LstUdpHeader.usChecksum = (uint16)~LulChecksum;
    if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
    {
        LstUdpHeader.usChecksum = REPLACE_UDPSUM;
    }
    else
    {
        /* Do nothing */
    }

    /************************************
       Copy Tx Buffer
    *************************************/
    /* Copy IPv4 Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstIpv4Header, sizeof(LstIpv4Header));
    CanEthConv_GulEthTxBufIdx += sizeof(LstIpv4Header);

    /* Copy UDP Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstUdpHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_025]:[Gen5GW_CanEthConv_UD_12_025]
* Function Name: CreateEthHeaderIpv6Ntscf
* Description  : Store Ethernet Header to Tx Buffer.(IPv6+UDP+SEQNO+NTSCF)
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderIpv6Ntscf(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    const uint32              LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32                    LulTotalHeaderSize;
    uint32                    LulSeqNum;
    uint32                    LulChecksum;
    CanEthConv_Ipv6HeaderType LstIpv6Header;
    CanEthConv_UdpHeaderType  LstUdpHeader;
    CanEthConv_NTSCFType      LstNTSCFHeader;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Set IPv6/UDP Header (Big Endian) */
    CreateIpv6Header(pHeaderField, &LstIpv6Header);
    /* Add IPv6 header field size. */
    LulTotalHeaderSize += sizeof(LstIpv6Header);

    /* Create UDP Header */
    LstUdpHeader.usSrcPort  = CanEthConv_GstEthSrcCfg.usSrcUdpPort;
    LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
    LstUdpHeader.usLen      = (uint16)(HEADER_LEN_UDP + HEADER_LEN_SEQNUM + HEADER_LEN_NTSCF + LulEthBufLen);
    LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Add UDP header field size. */
    LulTotalHeaderSize += sizeof(LstUdpHeader);

    GetEncapSequenceNumber(ulEntryIdx, &LulSeqNum);
    /* Add encapsulation_sequence_num field size. */
    LulTotalHeaderSize += (uint32)HEADER_LEN_SEQNUM;

    /* Create NTSCF Header */
    CreateNTSCFHeader(ulEntryIdx, pHeaderField, &LstNTSCFHeader, &LulTotalHeaderSize);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /************************************
       Calculate CheckSum
    *************************************/
    /* for Pseudo UDP */
    LulChecksum = NUM0;
    CalcIpv6UdpPseudoCheckSum(&LstIpv6Header, &LstUdpHeader, &LulChecksum);

    /* for UDP Header */
    CanEthConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(CanEthConv_UdpHeaderType), &LulChecksum);

    /* for Sequence Number, AVTP Header */
    CanEthConv_UtilCalcSum(&LulSeqNum, (uint16)sizeof(LulSeqNum), &LulChecksum);
    CanEthConv_UtilCalcSum(&LstNTSCFHeader, (uint16)sizeof(CanEthConv_NTSCFType), &LulChecksum);
        
    /* for CAN Rx Buffer stored data */
    CanEthConv_UtilCalcSum(&CanEthConv_GaaCanRxBuf[IDX_0], (uint16)LulEthBufLen, &LulChecksum);
    LstUdpHeader.usChecksum = (uint16)~LulChecksum;
    if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
    {
        LstUdpHeader.usChecksum = REPLACE_UDPSUM;
    }
    else
    {
        /* Do nothing */
    }

    /************************************
       Copy Tx Buffer
    *************************************/
    /* Copy IPv6 Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstIpv6Header, sizeof(LstIpv6Header));
    CanEthConv_GulEthTxBufIdx += sizeof(LstIpv6Header);

    /* Copy UDP Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstUdpHeader);

    /* Set encapsulation_sequence_num field to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LulSeqNum, sizeof(LulSeqNum));
    CanEthConv_GulEthTxBufIdx += sizeof(LulSeqNum);

    /* Copy NTSCF Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstNTSCFHeader, sizeof(LstNTSCFHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstNTSCFHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_026]:[Gen5GW_CanEthConv_UD_12_026]
* Function Name: CreateEthHeaderIpv6Tscf
* Description  : Store Ethernet Header to Tx Buffer.(IPv6+UDP+SEQNO+TSCF)
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderIpv6Tscf(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    const uint32              LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32                    LulTotalHeaderSize;
    uint32                    LulSeqNum;
    uint32                    LulChecksum;
    CanEthConv_Ipv6HeaderType LstIpv6Header;
    CanEthConv_UdpHeaderType  LstUdpHeader;
    CanEthConv_TSCFType       LstTSCFHeader;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Set IPv6/UDP Header (Big Endian) */
    CreateIpv6Header(pHeaderField, &LstIpv6Header);
    /* Add IPv6 header field size. */
    LulTotalHeaderSize += sizeof(LstIpv6Header);

    /* Create UDP Header */
    LstUdpHeader.usSrcPort  = CanEthConv_GstEthSrcCfg.usSrcUdpPort;
    LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
    LstUdpHeader.usLen      = (uint16)(HEADER_LEN_UDP + HEADER_LEN_SEQNUM + HEADER_LEN_TSCF + LulEthBufLen);
    LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Add UDP header field size. */
    LulTotalHeaderSize += sizeof(LstUdpHeader);

    GetEncapSequenceNumber(ulEntryIdx, &LulSeqNum);
    /* Add encapsulation_sequence_num field size. */
    LulTotalHeaderSize += (uint32)HEADER_LEN_SEQNUM;

    /* Create TSCF Header */
    CreateTSCFHeader(ulEntryIdx, pHeaderField, &LstTSCFHeader, &LulTotalHeaderSize);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /************************************
       Calculate CheckSum
    *************************************/
    /* for Pseudo UDP */
    LulChecksum = NUM0;
    CalcIpv6UdpPseudoCheckSum(&LstIpv6Header, &LstUdpHeader, &LulChecksum);

    /* for UDP Header */
    CanEthConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(CanEthConv_UdpHeaderType), &LulChecksum);

    /* for Sequence Number, AVTP Header */
    CanEthConv_UtilCalcSum(&LulSeqNum, (uint16)sizeof(LulSeqNum), &LulChecksum);
    CanEthConv_UtilCalcSum(&LstTSCFHeader, (uint16)sizeof(CanEthConv_TSCFType), &LulChecksum);
        
    /* for CAN Rx Buffer stored data */
    CanEthConv_UtilCalcSum(&CanEthConv_GaaCanRxBuf[IDX_0], (uint16)LulEthBufLen, &LulChecksum);
    LstUdpHeader.usChecksum = (uint16)~LulChecksum;
    if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
    {
        LstUdpHeader.usChecksum = REPLACE_UDPSUM;
    }
    else
    {
        /* Do nothing */
    }

    /************************************
       Copy Tx Buffer
    *************************************/
    /* Copy IPv6 Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstIpv6Header, sizeof(LstIpv6Header));
    CanEthConv_GulEthTxBufIdx += sizeof(LstIpv6Header);

    /* Copy UDP Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstUdpHeader);

    /* Set encapsulation_sequence_num field to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LulSeqNum, sizeof(LulSeqNum));
    CanEthConv_GulEthTxBufIdx += sizeof(LulSeqNum);

    /* Copy TSCF Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstTSCFHeader, sizeof(LstTSCFHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstTSCFHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_027]:[Gen5GW_CanEthConv_UD_12_027]
* Function Name: CreateEthHeaderIpv6
* Description  : Store Ethernet Header to Tx Buffer.(IPv6+UDP)
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderIpv6(const R_CanEthConv_HeaderType *pHeaderField, 
    uint32 *pHeaderSize)
{
    const uint32              LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32                    LulTotalHeaderSize;
    uint32                    LulChecksum;
    CanEthConv_Ipv6HeaderType LstIpv6Header;
    CanEthConv_UdpHeaderType  LstUdpHeader;

    LulTotalHeaderSize = NUM0;

    /************************************
       Create Block
    *************************************/
    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Set IPv6/UDP Header (Big Endian) */
    CreateIpv6Header(pHeaderField, &LstIpv6Header);
    /* Add IPv6 header field size. */
    LulTotalHeaderSize += sizeof(LstIpv6Header);

    /* Create UDP Header */
    LstUdpHeader.usSrcPort  = CanEthConv_GstEthSrcCfg.usSrcUdpPort;
    LstUdpHeader.usDestPort = pHeaderField->usDestUdpPort;
    LstUdpHeader.usLen      = (uint16)((uint32)HEADER_LEN_UDP + (uint32)LulEthBufLen);
    LstUdpHeader.usChecksum = (uint16)CHECKSUM_ZERO;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usSrcPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usDestPort);
    CanEthConv_UtilEndianConv16(&LstUdpHeader.usLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Add UDP header field size. */
    LulTotalHeaderSize += sizeof(LstUdpHeader);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /************************************
       Calculate CheckSum
    *************************************/
    /* for Pseudo UDP */
    LulChecksum = NUM0;
    CalcIpv6UdpPseudoCheckSum(&LstIpv6Header, &LstUdpHeader, &LulChecksum);

    /* for UDP Header */
    CanEthConv_UtilCalcSum(&LstUdpHeader, (uint16)sizeof(CanEthConv_UdpHeaderType), &LulChecksum);

    /* for CAN Rx Buffer stored data */
    CanEthConv_UtilCalcSum(&CanEthConv_GaaCanRxBuf[IDX_0], (uint16)LulEthBufLen, &LulChecksum);
    LstUdpHeader.usChecksum = (uint16)~LulChecksum;
    if ((uint32)NUM0 == (uint32)LstUdpHeader.usChecksum)
    {
        LstUdpHeader.usChecksum = REPLACE_UDPSUM;
    }
    else
    {
        /* Do nothing */
    }

    /************************************
       Copy Tx Buffer
    *************************************/
    /* Copy IPv6 Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstIpv6Header, sizeof(LstIpv6Header));
    CanEthConv_GulEthTxBufIdx += sizeof(LstIpv6Header);

    /* Copy UDP Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstUdpHeader, sizeof(LstUdpHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstUdpHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_028]:[Gen5GW_CanEthConv_UD_12_028]
* Function Name: CreateEthHeaderNtscf
* Description  : Store Ethernet Header to Tx Buffer.(NTSCF)
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderNtscf(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    uint32                    LulTotalHeaderSize;
    CanEthConv_NTSCFType      LstNTSCFHeader;

    LulTotalHeaderSize = NUM0;

    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Create NTSCF Header */
    CreateNTSCFHeader(ulEntryIdx, pHeaderField, &LstNTSCFHeader, &LulTotalHeaderSize);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /* Copy NTSCF Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstNTSCFHeader, sizeof(LstNTSCFHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstNTSCFHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_029]:[Gen5GW_CanEthConv_UD_12_029]
* Function Name: CreateEthHeaderTscf
* Description  : Store Ethernet Header to Tx Buffer.(TSCF)
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pHeaderSize -
*                    AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateEthHeaderTscf(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField, uint32 *pHeaderSize)
{
    uint32                    LulTotalHeaderSize;
    CanEthConv_TSCFType       LstTSCFHeader;

    LulTotalHeaderSize = NUM0;

    /* Create IEEE802.1Q Header */
    CreateVlanHeader(pHeaderField, &LulTotalHeaderSize);

    /* Create TSCF Header */
    CreateTSCFHeader(ulEntryIdx, pHeaderField, &LstTSCFHeader, &LulTotalHeaderSize);

    /* all Header Size */
    *pHeaderSize = LulTotalHeaderSize;

    /* Copy TSCF Header to Tx buffer*/
    CanEthConv_UtilMemCpy(&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx], &LstTSCFHeader, sizeof(LstTSCFHeader));
    CanEthConv_GulEthTxBufIdx += sizeof(LstTSCFHeader);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_017]:[Gen5GW_CanEthConv_UD_12_017]
* Function Name: CreateVlanHeader
* Description  : Create VLAN Header.
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                *pSize -
*                    header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateVlanHeader(const R_CanEthConv_HeaderType *pHeaderField, uint32 *pSize)
{
    CanEthConv_IEEE8021QType        *pIEEE8021QHeader;

    /* Create IEEE802.1Q Header */
    if ((uint32)NUM0 != (uint32)pHeaderField->usVlanId)
    {
        pIEEE8021QHeader = (CanEthConv_IEEE8021QType*)&CanEthConv_GaaEthTxBuf[CanEthConv_GulEthTxBufIdx];
        pIEEE8021QHeader->usVlanId = pHeaderField->usVlanId;
        if ((uint32)CANETHCONV_SET == (uint32)pHeaderField->ucIpSetFlag)
        {
            if ((uint32)CANETHCONV_FLAG_IPV4 == (uint32)pHeaderField->ucIpType)
            {
                pIEEE8021QHeader->usFrameType = CANETHCONV_FRAMETYPE_IPV4;
            }
            else
            {
                pIEEE8021QHeader->usFrameType = CANETHCONV_FRAMETYPE_IPV6;
            }
        }
        else if (((uint32)CANETHCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
        ||       ((uint32)CANETHCONV_FLAG_TSCF  == (uint32)pHeaderField->ucAvtpFormat))
        {
            pIEEE8021QHeader->usFrameType = CANETHCONV_FRAMETYPE_AVTP;
        }
        else
        {
            /* Do Nothing */
        }

        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&pIEEE8021QHeader->usVlanId);
        CanEthConv_UtilEndianConv16(&pIEEE8021QHeader->usFrameType);
        #endif

        CanEthConv_GulEthTxBufIdx += sizeof(CanEthConv_IEEE8021QType);
        *pSize += sizeof(CanEthConv_IEEE8021QType);
    }
    else
    {
        /* Do nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_007]:[Gen5GW_CanEthConv_UD_12_007]
* Function Name: CreateIpv4Header
* Description  : Create IPv4 Header.
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                *pIpHeader -
*                    IPv4 header
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateIpv4Header(const R_CanEthConv_HeaderType *pHeaderField, 
    CanEthConv_Ipv4HeaderType *pIpHeader)
{
    const uint32 LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32 LulChecksum;

    /* Create IPv4 Header */
    /* Set Version/Internet Header Length field */
    pIpHeader->ucVerAndHeaderLen = VER_AND_HEADERLEN_IPV4;
    pIpHeader->ucServiceType = SERVICE_TYPE_IPV4;
    /* Set Total Packet Length */
    if ((uint32)CANETHCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
    {
        pIpHeader->usPktLen = (uint16)((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP
                + (uint32)HEADER_LEN_SEQNUM + (uint32)HEADER_LEN_NTSCF + (uint32)LulEthBufLen);
    }
    else if ((uint32)CANETHCONV_FLAG_TSCF == (uint32)pHeaderField->ucAvtpFormat)
    {
        pIpHeader->usPktLen = (uint16)((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP
                + (uint32)HEADER_LEN_SEQNUM + (uint32)HEADER_LEN_TSCF + (uint32)LulEthBufLen);
    }
    else if ((uint32)CANETHCONV_AVTP_NONE == (uint32)pHeaderField->ucAvtpFormat)
    {
        pIpHeader->usPktLen = (uint16)((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP + (uint32)LulEthBufLen);
    }
    else
    {
        /* Do nothing */
    }

    /* Set Identification field */
    pIpHeader->usId = ID_IPV4;
    /* Set Various Control Flags/Fragment Offset field */
    pIpHeader->usFragment = FRAGMENT_IPV4;
    /* Set TTL field */
    pIpHeader->ucTTL = TTL_IPV4;
    /* Set Protocol field */
    pIpHeader->ucProtocol = PROTOCOL_UDP;
    pIpHeader->usChecksum = CHECKSUM_ZERO;
    pIpHeader->ulSrcIpAddr = CanEthConv_GstEthSrcCfg.ulSrcIpv4Addr;
    pIpHeader->ulDestIpAddr = pHeaderField->aaDestIpAddr[IDX_0];

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    /* Endian conversion */
    CanEthConv_UtilEndianConv16(&pIpHeader->usPktLen);
    CanEthConv_UtilEndianConv16(&pIpHeader->usId);
    CanEthConv_UtilEndianConv16(&pIpHeader->usFragment);
    CanEthConv_UtilEndianConv16(&pIpHeader->usChecksum);
    CanEthConv_UtilEndianConv32(&pIpHeader->ulSrcIpAddr);
    CanEthConv_UtilEndianConv32(&pIpHeader->ulDestIpAddr);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    /* Calculate IPv4 Header checksum */
    LulChecksum = NUM0;
    CanEthConv_UtilCalcSum(pIpHeader, (uint16)sizeof(CanEthConv_Ipv4HeaderType), &LulChecksum);
    /* Set checksum field to the 1's complement value of calculated checksum */
    pIpHeader->usChecksum = (uint16)~LulChecksum;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_015]:[Gen5GW_CanEthConv_UD_12_015]
* Function Name: CreateIpv6Header
* Description  : Create IPv6 Header.
* Arguments    : *pHeaderField -
*                    IP/UDP/AVTP header
*                *pIpHeader -
*                    IPv6 header
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateIpv6Header(const R_CanEthConv_HeaderType *pHeaderField, 
    CanEthConv_Ipv6HeaderType *pIpHeader)
{
    const uint32 LulEthBufLen = CanEthConv_GulCanRxBufLen;
    uint32 LulCount;

    /* Create IPv6 Header */
    /* Set Version, Traffic Class and Flow Label field */
    pIpHeader->ulVerClassAndLabel = VER_CLASS_AND_LABEL_IPV6;
    /* Set Total Packet Length */
    if ((uint32)CANETHCONV_FLAG_NTSCF == (uint32)pHeaderField->ucAvtpFormat)
    {
        pIpHeader->usPayloadLen = (uint16)((uint32)HEADER_LEN_UDP + (uint32)HEADER_LEN_SEQNUM
                + (uint32)HEADER_LEN_NTSCF + (uint32)LulEthBufLen);
    }
    else if ((uint32)CANETHCONV_FLAG_TSCF == (uint32)pHeaderField->ucAvtpFormat)
    {
        pIpHeader->usPayloadLen = (uint16)((uint32)HEADER_LEN_UDP + (uint32)HEADER_LEN_SEQNUM
                + (uint32)HEADER_LEN_TSCF + (uint32)LulEthBufLen);
    }
    else if ((uint32)CANETHCONV_AVTP_NONE == (uint32)pHeaderField->ucAvtpFormat)
    {
        pIpHeader->usPayloadLen = (uint16)((uint32)HEADER_LEN_UDP + (uint32)LulEthBufLen);
    }
    else
    {
        /* Do nothing */
    }
    /* Set Next Header field */
    pIpHeader->ucNextHeader = PROTOCOL_UDP;
    /* Set TTL field */
    pIpHeader->ucHopLimit = HL_IPV6;
    /* Set Source/Destination IP Address field */
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)CANETHCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        pIpHeader->aaSrcIpAddr[LulCount] = CanEthConv_GstEthSrcCfg.aaSrcIpv6Addr[LulCount];
        pIpHeader->aaDestIpAddr[LulCount] = pHeaderField->aaDestIpAddr[LulCount];
    }

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    /* Endian conversion */
    CanEthConv_UtilEndianConv32(&pIpHeader->ulVerClassAndLabel);
    CanEthConv_UtilEndianConv16(&pIpHeader->usPayloadLen);
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)CANETHCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        CanEthConv_UtilEndianConv32(&pIpHeader->aaSrcIpAddr[LulCount]);
        CanEthConv_UtilEndianConv32(&pIpHeader->aaDestIpAddr[LulCount]);
    }
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_018]:[Gen5GW_CanEthConv_UD_12_018]
* Function Name: CalcIpv4UdpPseudoCheckSum
* Description  : Calculate CheckSum for IPv4 Pseudo Header.
* Arguments    : *pIpv4Header -
*                    IPv4 header
*                *pUdpHeader -
*                    UDP header
*                *pChecksum -
*                    Checksum value
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CalcIpv4UdpPseudoCheckSum(const CanEthConv_Ipv4HeaderType *pIpv4Header,
                                      const CanEthConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum)
{
    CanEthConv_Ipv4PseudoHeaderType LstIpv4PseudoHeader;

    /* Create IPv4 Pseudo Header */
    LstIpv4PseudoHeader.ulSrcIpAddr  = pIpv4Header->ulSrcIpAddr;
    LstIpv4PseudoHeader.ulDestIpAddr = pIpv4Header->ulDestIpAddr;
    LstIpv4PseudoHeader.ucPadZero    = NUM0;
    LstIpv4PseudoHeader.ucProtocol   = PROTOCOL_UDP;
    LstIpv4PseudoHeader.usDataLen    = pUdpHeader->usLen;

    /* Calculate CheckSum for IPv4 Pseudo Header */
    CanEthConv_UtilCalcSum(&LstIpv4PseudoHeader,
                           (uint16)sizeof(CanEthConv_Ipv4PseudoHeaderType), pChecksum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_019]:[Gen5GW_CanEthConv_UD_12_019]
* Function Name: CalcIpv6UdpPseudoCheckSum
* Description  : Calculate CheckSum for IPv6 Pseudo Header.
* Arguments    : *pIpv6Header -
*                    IPv6 header
*                *pUdpHeader -
*                    UDP header
*                *pChecksum -
*                    Checksum value
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CalcIpv6UdpPseudoCheckSum(const CanEthConv_Ipv6HeaderType *pIpv6Header,
                                      const CanEthConv_UdpHeaderType *pUdpHeader, uint32 *pChecksum)
{
    uint32       LulCount;
    CanEthConv_Ipv6PseudoHeaderType LstIpv6PseudoHeader;

    /* Create IPv6 Pseudo Header */
    for (LulCount = (uint32)IDX_0; LulCount < (uint32)CANETHCONV_IPADDR_LEN_IN_WORD; LulCount++)
    {
        LstIpv6PseudoHeader.aaSrcIpAddr[LulCount]  = pIpv6Header->aaSrcIpAddr[LulCount];
        LstIpv6PseudoHeader.aaDestIpAddr[LulCount] = pIpv6Header->aaDestIpAddr[LulCount];
    }
    LstIpv6PseudoHeader.ulPayloadLen = (uint32)pUdpHeader->usLen;
    LstIpv6PseudoHeader.aaPadZero[IDX_0] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_1] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_2] = NUM0;
    LstIpv6PseudoHeader.ucNextHeader = (uint8)PROTOCOL_UDP;
    
    /* Calculate CheckSum for IPv6 Pseudo Header */
    CanEthConv_UtilCalcSum(&LstIpv6PseudoHeader,
                           (uint16)sizeof(CanEthConv_Ipv6PseudoHeaderType), pChecksum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_008]:[Gen5GW_CanEthConv_UD_12_008]
* Function Name: StoreEthBufData
* Description  : Store CAN frame to Ethernet Data Buffer.
* Arguments    : *pCanFrame -
*                    CAN Frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) StoreEthBufData(const R_CanEthConv_CanFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;
    uint32 LulDataSize;
    uint8 *LpBuffPtr;
    uint32 LulCanId;
    uint32 LulCanDlc;

    /* Save Local valuable for endian change. */
    LulCanId = pCanFrame->ulCanId;
    LulCanDlc = pCanFrame->ulCanDlc;

    LucRetVal = E_OK;
    LulDataSize = CanEthConv_GulCanRxBufLen + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC + pCanFrame->ulCanDlc;

    if (LulDataSize <= CanEthConv_GulCanRxBufSize)
    {
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LulCanId);
        CanEthConv_UtilEndianConv32(&LulCanDlc);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        /* Calculate current position */
        LpBuffPtr = &CanEthConv_GaaCanRxBuf[CanEthConv_GulCanRxBufLen];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LulCanId, CAN_LEN_ID);
        LpBuffPtr = &LpBuffPtr[CAN_LEN_ID];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LulCanDlc, CAN_LEN_DLC);
        LpBuffPtr = &LpBuffPtr[CAN_LEN_DLC];
        CanEthConv_UtilMemCpy(LpBuffPtr, pCanFrame->pCanData, pCanFrame->ulCanDlc);
        /* Update current position */
        CanEthConv_GulCanRxBufLen = LulDataSize;
        CanEthConv_GulCanCount++;
    }
    else
    {
        /* Buffer is unexpectedly full */
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                              CANETHCONV_E_BUFF);
        #endif
        LucRetVal = E_NOT_OK;        
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_016]:[Gen5GW_CanEthConv_UD_12_016]
* Function Name: CreateNTSCFHeader
* Description  : Create NTSCF Header.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pstNTSCFHeader -
*                    NTSCF header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateNTSCFHeader(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField,
    CanEthConv_NTSCFType *pstNTSCFHeader, uint32 *pHeaderSize)
{
    const uint32 LulEthBufLen = CanEthConv_GulCanRxBufLen;

    /* Create NTSCF Header */
    pstNTSCFHeader->ucSubType = SUBTYPE_NTSCF;
    pstNTSCFHeader->ucSvVerDataLenMSB = (uint8)(((uint32)pHeaderField->ucStreamIdValid << (uint32)SHIFT_7BIT) |
                                                ((uint32)LulEthBufLen >> (uint32)SHIFT_8BIT));
    pstNTSCFHeader->ucDataLenLSB = (uint8)LulEthBufLen;
    pstNTSCFHeader->aaStreamId[IDX_0] = pHeaderField->aaStreamId[IDX_0];
    pstNTSCFHeader->aaStreamId[IDX_1] = pHeaderField->aaStreamId[IDX_1];
    pstNTSCFHeader->ucSeqNum = CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]];

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv32(&pstNTSCFHeader->aaStreamId[IDX_0]);
    CanEthConv_UtilEndianConv32(&pstNTSCFHeader->aaStreamId[IDX_1]);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    if ((uint32)CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] < (uint32)MASK_8BIT)
    {
        CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] =
            (uint8)((uint32)CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] + (uint32)NUM1);
    }
    else
    {
        CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] = NUM0;
    }

    *pHeaderSize += (uint32)HEADER_LEN_NTSCF;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_021]:[Gen5GW_CanEthConv_UD_12_021]
* Function Name: CreateTSCFHeader
* Description  : Create TSCF Header.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *pstTSCFHeader -
*                    TSCF header
*                *pHeaderSize -
*                    IP/UDP/AVTP header size
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CreateTSCFHeader(const uint32 ulEntryIdx, 
    const R_CanEthConv_HeaderType *pHeaderField,
    CanEthConv_TSCFType *pstTSCFHeader, uint32 *pHeaderSize)
{
    const uint32 LulEthBufLen = CanEthConv_GulCanRxBufLen;

    Std_ReturnType  LucRetVal;
    uint16  LusSecHi;
    uint32  LulSec;
    uint32  LulnSec;
    uint32  LulAvtpTimestamp;
    boolean LbTimeStampValid;
    boolean LbTimeStampUncertain;

    /* Get gPTPTime */
    LucRetVal = (uint8)CanEthConv_GetTimeUserDef(&LusSecHi, &LulSec, &LulnSec);
    if ((uint8)E_OK == LucRetVal)
    {
        LbTimeStampValid     = TRUE;
        LbTimeStampUncertain = FALSE;
        LulAvtpTimestamp     = (uint32)((LulSec * (uint32)GPTP_SECUNIT) + LulnSec);
    }
    else
    {
        LbTimeStampValid     = FALSE;
        LbTimeStampUncertain = TRUE;
        LulAvtpTimestamp     = NUM0;
    }

    /* Create TSCF Header */
    pstTSCFHeader->ucSubType          = SUBTYPE_TSCF;
    pstTSCFHeader->ucSvVerMrRsvTv     =
        (uint8)(((uint32)pHeaderField->ucStreamIdValid << (uint32)SHIFT_7BIT) | /* StreamIdValid(1bit) */
        (uint32)LbTimeStampValid);                                              /* TimeStampValid(1bit) */
    pstTSCFHeader->ucSeqNum           = CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]];
    pstTSCFHeader->ucReserveTu        = (uint8)(LbTimeStampUncertain);          /* timestamp uncertain(1bit) */
    pstTSCFHeader->aaStreamId[IDX_0]  = pHeaderField->aaStreamId[IDX_0];
    pstTSCFHeader->aaStreamId[IDX_1]  = pHeaderField->aaStreamId[IDX_1];
    pstTSCFHeader->ulAvtpTimestamp    = LulAvtpTimestamp;
    pstTSCFHeader->ulReserved1        = NUM0;
    pstTSCFHeader->usStreamDataLength = (uint16)LulEthBufLen;
    pstTSCFHeader->usReserved1        = NUM0;

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv32(&pstTSCFHeader->aaStreamId[IDX_0]);
    CanEthConv_UtilEndianConv32(&pstTSCFHeader->aaStreamId[IDX_1]);
    CanEthConv_UtilEndianConv32(&pstTSCFHeader->ulAvtpTimestamp);
    CanEthConv_UtilEndianConv16(&pstTSCFHeader->usStreamDataLength);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    if ((uint32)CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] < (uint32)MASK_8BIT)
    {
        CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] =
            (uint8)((uint32)CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] + (uint32)NUM1);
    }
    else
    {
        CanEthConv_GucSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] = NUM0;
    }

    *pHeaderSize += (uint32)HEADER_LEN_TSCF;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_030]:[Gen5GW_CanEthConv_UD_12_030]
* Function Name: GetEncapSequenceNumber
* Description  : Get EncapSequenceNumber.
* Arguments    : ulEntryIdx -
*                    Route Table Index
*                *pSeqNo -
*                    EncapSequence Number
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) GetEncapSequenceNumber(const uint32 ulEntryIdx, uint32 *pSeqNo)
{
    *pSeqNo = CanEthConv_GulEncapSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]];

    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv32(pSeqNo);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    if (CanEthConv_GulEncapSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] < MASK_32BIT)
    {
        CanEthConv_GulEncapSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]]++;
    }
    else
    {
        CanEthConv_GulEncapSeqNum[CanEthConv_GulSeqNumIndex[ulEntryIdx]] = NUM0;
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_009]:[Gen5GW_CanEthConv_UD_12_009]
* Function Name: CanEthConv_CanXLtoEth
* Description  : CanXL to Ethernet Conversion Function
* Arguments    : *pCanFrame -
*                    CANXL frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_CanXLtoEth(const R_CanEthConv_CanXLFrameType *pCanFrame)
{
    Std_ReturnType          LucRetVal;
    uint32                  LulEntryIdx;
    R_CanEthConv_HeaderType LstHeaderField;
    uint8                   LucDestMacAddr[MACADDR_LEN_IN_BYTE];

    LucRetVal = E_OK;

    if ((NULL_PTR != CanEthConv_GaaCanRxBuf)
    &&  (NULL_PTR != CanEthConv_GaaEthTxBuf))
    {
        /* Check CAN-ID */
        if ((uint16)CANID_XL_MAX >= pCanFrame->pXLParams->usPriorityId)
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                                  CANETHCONV_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }

        /* Check CANXL Data */
        if ((uint8)E_OK == LucRetVal)
        {
            if (((uint32)CANXLFRAME_LEN_MIN <= pCanFrame->ulCanDlc)
            &&  ((uint32)CANXLFRAME_LEN_MAX >= pCanFrame->ulCanDlc))
            {
                /* Do Nothing */

            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                                      CANETHCONV_E_INV_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do Nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = SearchEthRoutTblForCanXL(pCanFrame, &LulEntryIdx, &LstHeaderField, &LucDestMacAddr[IDX_0]);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Check Conversion Mode */
                if (CANETHCONV_BASICMODE == CanEthConv_GstConvCfg.enConvMode)
                {
                    CanEthConv_EnterCriticalUserDef();
                    LucRetVal = StoreEthBufDataForCanXL(pCanFrame);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        LucRetVal = CreateAndSendEthFrame(LulEntryIdx, &LstHeaderField, &LucDestMacAddr[IDX_0]);
                        if ((uint8)E_OK == LucRetVal)
                        {
                            /* Do nothing */
                        }
                        else
                        {
                            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                            /* Report to DET */
                            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID,
                                                  R_CANETHCONV_CANXLTOETH_SID, CANETHCONV_E_TRANS);
                            #endif
                        }
                        /* Initialize Ethernet Tx Buffer Index */
                        CanEthConv_GulEthTxBufIdx = NUM0;
                    }
                    else
                    {
                        /* Do nothing */
                    }
                    CanEthConv_ExitCriticalUserDef();
                }
                else
                {
                    LucRetVal = ProcessBufModeForCanXL(pCanFrame, LulEntryIdx, &LstHeaderField, &LucDestMacAddr[IDX_0]);
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                              CANETHCONV_E_PARAM_CONFIG);
        #endif
        LucRetVal = E_NOT_OK;   
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_031]:[Gen5GW_CanEthConv_UD_12_031]
* Function Name: SearchEthRoutTblForCanXL
* Description  : Search CANXL to Ethernet Routing Table.
* Arguments    : *pCanFrame -
*                    CANXL frame
*                *pEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *aaDestMacAddr -
*                    Destination MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchEthRoutTblForCanXL(
    const R_CanEthConv_CanXLFrameType *pCanFrame, uint32 *pEntryIdx,
    R_CanEthConv_HeaderType *pHeaderField, uint8 *aaDestMacAddr)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulComparedCanId;
    uint32 LulEntryCanId;

    LucRetVal = E_NOT_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < CanEthConv_GulEthRoutTblNum; LulEntryIdx++)
    {
        /* Apply CAN ID Mask */
        LulComparedCanId = ((uint32)pCanFrame->pXLParams->usPriorityId | (uint32)CANXL_XLF_BIT) &
            CanEthConv_GstEthRoutTbl[LulEntryIdx].ulCanIdMask;
        LulEntryCanId = CanEthConv_GstEthRoutTbl[LulEntryIdx].ulCanId &
            CanEthConv_GstEthRoutTbl[LulEntryIdx].ulCanIdMask;

        if (LulComparedCanId == LulEntryCanId)
        {
            /* Entry is match. Save Entry ID and End Search */
            *pEntryIdx = LulEntryIdx;
            LucRetVal = E_OK;
            break;
        }
        else
        {
            /* Entry is not match. Next Entry */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy from CAN to Ethernet Routing Table Entry to pHeaderField */
        *pHeaderField = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader;
        /* To address the warning that it has not been initialized with MISRA-C. */
        pHeaderField->ucIpSetFlag     = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucIpSetFlag;
        pHeaderField->ucIpType        = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucIpType;
        pHeaderField->ucAvtpFormat    = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucAvtpFormat;
        pHeaderField->ucEmergencyFlag = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucEmergencyFlag;
        pHeaderField->usDestUdpPort   = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.usDestUdpPort;
        pHeaderField->usVlanId        = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.usVlanId;
        pHeaderField->ucStreamIdValid = CanEthConv_GstEthRoutTbl[LulEntryIdx].stHeader.ucStreamIdValid;

        /* Convert from 32 bit 2 Entry to 8 bit 6 Entry */
        CanEthConv_UtilConvMacAddr8Bit(&CanEthConv_GstEthRoutTbl[LulEntryIdx].aaDestMacAddr[IDX_0],
                                       &aaDestMacAddr[IDX_0]);
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                              CANETHCONV_E_MATCH);
        #endif
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_033]:[Gen5GW_CanEthConv_UD_12_033]
* Function Name: StoreEthBufDataForCanXL
* Description  : Store CANXL frame to Ethernet Data Buffer.
* Arguments    : *pCanFrame -
*                    CANXL Frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) StoreEthBufDataForCanXL(
                                                 const R_CanEthConv_CanXLFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;
    uint32 LulDataSize;
    uint8 *LpBuffPtr;
    uint32 LulCanId;
    uint32 LulCanDlc;
    uint8  LucSduType;
    uint8  LucSec;    
    uint16 LusVcid;
    uint32 LulAcceptanceField;

    /* Save Local valuable for endian change. */
    LulCanId   = ((uint32)CANXL_XLF_BIT | (uint32)pCanFrame->pXLParams->usPriorityId);
    LulCanDlc  = pCanFrame->ulCanDlc;
    LucSduType = pCanFrame->pXLParams->ucSduType; 
    LucSec     = pCanFrame->pXLParams->ucSec;
    LusVcid    = pCanFrame->pXLParams->usVcid;
    LulAcceptanceField = pCanFrame->pXLParams->ulAcceptanceField;
    
    LucRetVal = E_OK;
    LulDataSize = CanEthConv_GulCanRxBufLen + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC 
                                            + (uint32)CANXL_PARAM_LEN + pCanFrame->ulCanDlc;

    if (LulDataSize <= CanEthConv_GulCanRxBufSize)
    {
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LulCanId);
        CanEthConv_UtilEndianConv32(&LulCanDlc);
        CanEthConv_UtilEndianConv16(&LusVcid);
        CanEthConv_UtilEndianConv32(&LulAcceptanceField);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        /* Calculate current position */
        LpBuffPtr = &CanEthConv_GaaCanRxBuf[CanEthConv_GulCanRxBufLen];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LulCanId, CAN_LEN_ID);
        LpBuffPtr = &LpBuffPtr[CAN_LEN_ID];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LulCanDlc, CAN_LEN_DLC);
        LpBuffPtr = &LpBuffPtr[CAN_LEN_DLC];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LucSduType, sizeof(LucSduType));
        LpBuffPtr = &LpBuffPtr[sizeof(LucSduType)];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LucSec, sizeof(LucSec));
        LpBuffPtr = &LpBuffPtr[sizeof(LucSec)];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LusVcid, sizeof(LusVcid));
        LpBuffPtr = &LpBuffPtr[sizeof(LusVcid)];
        CanEthConv_UtilMemCpy(LpBuffPtr, &LulAcceptanceField, sizeof(LulAcceptanceField));
        LpBuffPtr = &LpBuffPtr[sizeof(LulAcceptanceField)];
        CanEthConv_UtilMemCpy(LpBuffPtr, pCanFrame->pCanData, pCanFrame->ulCanDlc);
        /* Update current position */
        CanEthConv_GulCanRxBufLen = LulDataSize;
        CanEthConv_GulCanCount++;
    }
    else
    {
        /* Buffer is unexpectedly full */
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                              CANETHCONV_E_BUFF);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_12_032]:[Gen5GW_CanEthConv_UD_12_032]
* Function Name: ProcessBufModeForCanXL
* Description  : Create Ethernet Frame and Send with Buffer Type or Emergency Type
* Arguments    : *pCanFrame -
*                    CANXL frame
*                ulEntryIdx -
*                    Route Table Index
*                *pHeaderField -
*                    IP/UDP/AVTP header
*                *aaDestMacAddr -
*                    Destination MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) ProcessBufModeForCanXL(
                             const R_CanEthConv_CanXLFrameType *pCanFrame, const uint32 ulEntryIdx,
                             const R_CanEthConv_HeaderType *pHeaderField, const uint8 *aaDestMacAddr)
{
    Std_ReturnType                      LucRetVal;
    uint32                              LulEntryIdx;
    uint32                              LulDataSize;
    uint32                              LaaDestMacAddr[CANETHCONV_MACADDR_LEN_IN_WORD];
    uint8                               LaaOldDestMacAddr[MACADDR_LEN_IN_BYTE];
    const R_CanEthConv_EthRoutTblType   *LpEthDestInfo;

    LucRetVal = E_OK;

    /* Convert from 8 bit 6 Entry to 32 bit 2 Entry */
    CanEthConv_UtilConvMacAddr32Bit(&aaDestMacAddr[IDX_0], &LaaDestMacAddr[IDX_0]);

    /* Check Receive Data Size. */
    if ((uint32)NUM0 != CanEthConv_GulCanRxBufLen)
    {
        CanEthConv_EnterCriticalUserDef();

        /* Get Buffer destination info */
        LulEntryIdx   = CanEthConv_GulEthTblEntryIdx;
        LpEthDestInfo = &CanEthConv_GstEthDestInfo;
        /* Get Buffer size if adding the next CANXL frame */
        LulDataSize = CanEthConv_GulCanRxBufLen + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC 
                                                + (uint32)CANXL_PARAM_LEN   + pCanFrame->ulCanDlc;

        /* Different Destination info? */
        if ((LpEthDestInfo->aaDestMacAddr[IDX_0]             == LaaDestMacAddr[IDX_0])
        &&  (LpEthDestInfo->aaDestMacAddr[IDX_1]             == LaaDestMacAddr[IDX_1])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_0]     == pHeaderField->aaDestIpAddr[IDX_0])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_1]     == pHeaderField->aaDestIpAddr[IDX_1])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_2]     == pHeaderField->aaDestIpAddr[IDX_2])
        &&  (LpEthDestInfo->stHeader.aaDestIpAddr[IDX_3]     == pHeaderField->aaDestIpAddr[IDX_3])
        &&  ((uint32)LpEthDestInfo->stHeader.usDestUdpPort   == (uint32)pHeaderField->usDestUdpPort)
        &&  ((uint32)LpEthDestInfo->stHeader.ucStreamIdValid == (uint32)pHeaderField->ucStreamIdValid)
        &&  (LpEthDestInfo->stHeader.aaStreamId[IDX_0]       == pHeaderField->aaStreamId[IDX_0])
        &&  (LpEthDestInfo->stHeader.aaStreamId[IDX_1]       == pHeaderField->aaStreamId[IDX_1])
        &&  ((uint32)LpEthDestInfo->stHeader.ucIpSetFlag     == (uint32)pHeaderField->ucIpSetFlag)
        &&  ((uint32)LpEthDestInfo->stHeader.ucIpType        == (uint32)pHeaderField->ucIpType)
        &&  ((uint32)LpEthDestInfo->stHeader.ucAvtpFormat    == (uint32)pHeaderField->ucAvtpFormat)
        /* Check Buffer size is full if adding the next CANXL frame */
        &&  ((uint32)LulDataSize <= CanEthConv_GulCanRxBufSize))
        {
            /* Destination is the same. Do nothing. */
        }
        else
        {
            /* Destination is different. Send frame in buffer. */
            /* Convert from 32 bit 2 Entry to 8 bit 6 Entry */
            CanEthConv_UtilConvMacAddr8Bit(&LpEthDestInfo->aaDestMacAddr[IDX_0], &LaaOldDestMacAddr[IDX_0]);

            LucRetVal = CreateAndSendEthFrame(LulEntryIdx, &LpEthDestInfo->stHeader, &LaaOldDestMacAddr[IDX_0]);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                                      CANETHCONV_E_TRANS);
                #endif
            }
            /* Initialize Ethernet Tx Buffer Index */
            CanEthConv_GulEthTxBufIdx = NUM0;
        }
        CanEthConv_ExitCriticalUserDef();
    }
    else
    {
        /* Do Nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        CanEthConv_EnterCriticalUserDef();

        LucRetVal = StoreEthBufDataForCanXL(pCanFrame);
        if (((uint8)E_OK == LucRetVal)
        &&  (((CanEthConv_GulCanRxBufLen + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC) > CanEthConv_GulCanRxBufSize)
        ||  (CanEthConv_GulCanCount            >= CanEthConv_GstConvCfg.ulFrameLimit)
        ||  (((uint32)CANETHCONV_EMERGENCYMODE == (uint32)CanEthConv_GstConvCfg.enConvMode)
        &&   ((uint32)CANETHCONV_SET           == (uint32)pHeaderField->ucEmergencyFlag))))
        {
            /* Sending conditions met. Send frame in buffer. */
            LucRetVal = CreateAndSendEthFrame(ulEntryIdx, pHeaderField, &aaDestMacAddr[IDX_0]);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                                      CANETHCONV_E_TRANS);
                #endif
            }
            /* Initialize Ethernet Tx Buffer Index */
            CanEthConv_GulEthTxBufIdx = NUM0;
        }
        else
        {
            /* to Buffer */
            CanEthConv_GulEthTblEntryIdx       = ulEntryIdx;
            CanEthConv_GstEthDestInfo.stHeader = *pHeaderField;
            CanEthConv_GstEthDestInfo.aaDestMacAddr[IDX_0] = LaaDestMacAddr[IDX_0];
            CanEthConv_GstEthDestInfo.aaDestMacAddr[IDX_1] = LaaDestMacAddr[IDX_1];
        }

        CanEthConv_ExitCriticalUserDef();
    }
    else
    {
        /* Do Nothing */
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
