/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Utility function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanEthConv_common.h"
#include "CDD_CanEthConv_Util.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/

/*******************************************************************************
Utility Function
*******************************************************************************/

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_001]:[Gen5GW_CanEthConv_UD_15_001]
* Function name: CanEthConv_UtilMemCpy
* Description  : Same as C Standard API memcpy()
* Arguments    : pDest -
*                   Memory of destination
*                pSrc -
*                   Copy this data to pDest
*                ulSize -
*                   Size of data to be copied
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilMemCpy(void *pDest, const void *pSrc, const uint32 ulSize)
{
    uint32 LulAlign1;
    uint32 LulAlign2;
    uint32 LulSize;
    uint8 *LpDest;
    const uint8 *LpSrc;

    LpDest = (uint8 *)pDest;
    LpSrc = (const uint8 *)pSrc;

    /* check 4bytes align */
    LulAlign1 = (uint32)LpDest & ALIGN4;
    LulAlign2 = (uint32)LpSrc & ALIGN4;
    LulSize = ulSize;

    if (((uint32)NUM0 == LulAlign1) && ((uint32)NUM0 == LulAlign2))
    {
        while (LulSize >= (uint32)NUM4)
        {
            /* when size is over 4bytes, copy 4bytes at the time */
            *(uint32 *)LpDest = *(const uint32 *)LpSrc;
            LpDest += NUM4;
            LpSrc += NUM4;
            LulSize = LulSize - (uint32)NUM4;
        }
    }
    else if (LulAlign1 == LulAlign2)
    {
        while ((LulAlign1 < (uint32)NUM4) && (LulSize > (uint32)NUM0))
        {
            /* when dest address is not 4bytes align, copy 1byte at the time */
            *LpDest = *LpSrc;
            LpDest++;
            LpSrc++;
            LulSize = LulSize - (uint32)NUM1;
            LulAlign1++;
        }
        while (LulSize >= (uint32)NUM4)
        {
            /* when size is over 4bytes, copy 4bytes at the time */
            *(uint32 *)LpDest = *(const uint32 *)LpSrc;
            LpDest += NUM4;
            LpSrc += NUM4;
            LulSize = LulSize - (uint32)NUM4;
        }
    }
    else
    {
        /* nothing */
    }

    while (LulSize > (uint32)NUM0)
    {
        /* copy 1byte at the time */
        *LpDest = *LpSrc;
        LpDest++;
        LpSrc++;
        LulSize = LulSize - (uint32)NUM1;
    }
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_002]:[Gen5GW_CanEthConv_UD_15_002]
* Function name: CanEthConv_UtilMemSet
* Description  : Same as C Standard API memset()
* Arguments    : pDest   : Memory of destination
*                ucMyChar : Set this data to dest
*                ulSize   : Size of data to be set
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilMemSet(void *pDest, const uint8 ucMyChar, const uint32 ulSize)
{
    uint32 LulWork;
    uint32 LulAlign;
    uint32 LulSize;
    uint8 *LpDest;

    LpDest = (uint8 *)pDest;
    LulSize = ulSize;
    /* copy 4bytes ucMyChar to LulWork */
    LulWork = (uint32)ucMyChar | ((uint32)ucMyChar << SHIFT_8BIT);
    LulWork |= (LulWork << SHIFT_16BIT);

    /* check 4bytes align */
    LulAlign = (uint32)LpDest & (uint32)ALIGN4;

    if ((uint32)NUM0 != LulAlign)
    {
        while ((LulAlign < (uint32)NUM4) && (LulSize > (uint32)NUM0))
        {
            /* when dest address is not 4bytes align, set 1byte at the time */
            *LpDest = ucMyChar;
            LpDest++;
            LulSize = LulSize - (uint32)NUM1;
            LulAlign++;
        }
    }
    else
    {
        /* Do nothing */
    }

    while (LulSize >= (uint32)NUM4)
    {
        /* when size is over 4bytes, set 4bytes at the time */
        *(uint32 *)LpDest = LulWork;
        LpDest += NUM4;
        LulSize = LulSize - (uint32)NUM4;
    }
    while (LulSize > (uint32)NUM0)
    {
        /* when size is less than 4bytes, set 1byte at the time */
        *LpDest = ucMyChar;
        LpDest++;
        LulSize = LulSize - (uint32)NUM1;
    }
}


/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_003]:[Gen5GW_CanEthConv_UD_15_003]
* Function name: CanEthConv_UtilCalcSum
* Description  : Computes the internet checksum 
*                it does not compute the 1 complement checksum.
* Arguments    : *pBuf  - 
*                  Data for checksum calculation.
*                usBytes  -
*                  Data length in byte.
*                *pSum  -
*                  [IN]   Partially computed checksum value
*                  [OUT]  A checksum value
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilCalcSum(const void *pBuf, const uint16 usBytes, uint32 *pSum)
{
    uint32 LulNwords;
    const uint8 *Lpbuf;
    const uint16 *LpBuf16;
    uint32 LulSum;
    uint16 LusLeftoverByte;

    Lpbuf = (const uint8 *)pBuf;
    LpBuf16 = (const uint16 *)pBuf;
    /* Initial checksum value */
    LulSum = NUM0;

    for (LulNwords = ((uint32)usBytes >> (uint32)SHIFT_1BIT); LulNwords > (uint32)NUM0; LulNwords--)
    {
        LulSum += (uint32)*LpBuf16;
        LpBuf16++;
    }

    /* Add left-over byte, if any. */
    if (((uint32)usBytes & (uint32)MASK_1BIT) != (uint32)NUM0)
    {
        /* This logic is only when the host order is little endian. */
        LusLeftoverByte = (uint16)Lpbuf[((uint32)usBytes - (uint32)NUM1)];
        LulSum += (uint32)LusLeftoverByte;
    }
    else
    {
        /* Do nothing */
    }

    /* Add Partially calculated checksum */
    LulSum += *pSum;

   /* Fold 32-bit Sum to 16 bits. */
    LulSum = (LulSum & MASK_16BIT) + (LulSum >> SHIFT_16BIT);
    LulSum = (LulSum & MASK_16BIT) + (LulSum >> SHIFT_16BIT);

    /* Result of Sum value */
    *pSum = LulSum;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_004]:[Gen5GW_CanEthConv_UD_15_004]
* Function name: CanEthConv_UtilConvMacAddr8Bit
* Description  : Converts MAC Address 32 bit to 8 bit
* Arguments    : *aaInputMacAddr  -
*                  MAC Address to Convert.
*                *aaOutputMacAddr  -
*                  Array to store after MAC Address Convert.
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilConvMacAddr8Bit(const uint32 *aaInputMacAddr, uint8 *aaOutputMacAddr)
{
    aaOutputMacAddr[IDX_0] = (uint8)((aaInputMacAddr[IDX_0] >> SHIFT_8BIT) & MASK_8BIT);
    aaOutputMacAddr[IDX_1] = (uint8)(aaInputMacAddr[IDX_0] & MASK_8BIT);
    aaOutputMacAddr[IDX_2] = (uint8)(aaInputMacAddr[IDX_1] >> SHIFT_24BIT);
    aaOutputMacAddr[IDX_3] = (uint8)((aaInputMacAddr[IDX_1] >> SHIFT_16BIT) & MASK_8BIT);
    aaOutputMacAddr[IDX_4] = (uint8)((aaInputMacAddr[IDX_1] >> SHIFT_8BIT) & MASK_8BIT);
    aaOutputMacAddr[IDX_5] = (uint8)(aaInputMacAddr[IDX_1] & MASK_8BIT);
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_005]:[Gen5GW_CanEthConv_UD_15_005]
* Function name: CanEthConv_UtilConvMacAddr32Bit
* Description  : Converts MAC Address 8 bit to 32 bit
* Arguments    : *aaInputMacAddr  -
*                  MAC Address to Convert.
*                *aaOutputMacAddr  -
*                  Array to store after MAC Address Convert.
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilConvMacAddr32Bit(const uint8 *aaInputMacAddr, 
    uint32 *aaOutputMacAddr)
{
    aaOutputMacAddr[IDX_0] = (((uint32)aaInputMacAddr[IDX_0] << SHIFT_8BIT) |
        (uint32)aaInputMacAddr[IDX_1]);
    aaOutputMacAddr[IDX_1] = (((uint32)aaInputMacAddr[IDX_2] << SHIFT_24BIT) |
        ((uint32)aaInputMacAddr[IDX_3] << SHIFT_16BIT) |
        ((uint32)aaInputMacAddr[IDX_4] << SHIFT_8BIT) |
        ((uint32)aaInputMacAddr[IDX_5]));
}

#if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_006]:[Gen5GW_CanEthConv_UD_15_006]
* Function name: CanEthConv_UtilEndianConv16
* Description  : Change 16 bit value from Little Endian to Big Endian
* Arguments    : pValue: changed value
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilEndianConv16(uint16 *pValue)
{
    uint16 LusWork;

    LusWork = (uint16)(((uint32)*pValue << (uint32)SHIFT_8BIT) | ((uint32)*pValue >> (uint32)SHIFT_8BIT));
    *pValue = LusWork;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_007]:[Gen5GW_CanEthConv_UD_15_007]
* Function name: CanEthConv_UtilEndianConv32
* Description  : Change 32 bit value from Little Endian to Big Endian
* Arguments    : pValue: changed value
* Return Value : void
***************************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilEndianConv32(uint32 *pValue)
{
    uint32 LulWork;

    LulWork = ((*pValue << SHIFT_24BIT) | (((*pValue >> SHIFT_8BIT) & MASK_8BIT) << SHIFT_16BIT) |
        (((*pValue >> SHIFT_16BIT) & MASK_8BIT) << SHIFT_8BIT) | (*pValue >> SHIFT_24BIT));
    *pValue = LulWork;
}
#endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_15_008]:[Gen5GW_CanEthConv_UD_15_008]
* Function Name: CanEthConv_UtilCanDlcCheck
* Description  : Check CAN DLC range.
* Arguments    : ulCanDlc -
*                    received CAN DLC
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_UtilCanDlcCheck(const uint32 ulCanDlc)
{
    Std_ReturnType LucRetVal;

    if (((uint32)CANETHCONV_DLC_8  >= ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_12 == ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_16 == ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_20 == ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_24 == ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_32 == ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_48 == ulCanDlc)
    ||  ((uint32)CANETHCONV_DLC_64 == ulCanDlc))
    {
        LucRetVal = E_OK;
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
