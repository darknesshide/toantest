/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Ethernet to CAN Conversion function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanEthConv_common.h"
#include "CDD_CanEthConv_EthtoCan.h"
#include "CDD_CanEthConv_Util.h"
#include "CDD_CanEthConv_interface.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/* Destination unit and channel of CAN frame */
#define CAN_UNIT_MAX        1U
#define CAN_CHANNEL_MAX     7U
#define CANXL_UNIT_NUM      2U
#define CANXL_CHANNEL_MAX   1U

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* Ethernet Rx Buffer */
typedef struct
{
    uint16 usFrameType;
    uint32 ulFrameLen;
    uint8 *aaPayload;
} CanEthConv_EthRxBufType;

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
/* Ethernet Rx Buffer */
STATIC VAR(CanEthConv_EthRxBufType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstEthRxBuf;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulEthRxBufSize;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_PTR
#include "CanEthConv_MemMap.h" 
/*  CAN Tx Buffer */
STATIC P2VAR(uint8, CANETHCONV_VAR_NO_INIT, CANETHCONV_CONFIG_DATA)  CanEthConv_GaaCanTxBuf;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_PTR
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* Ethernet to CAN Routing Table */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  CanEthConv_GulCanRoutTblNum;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 
STATIC VAR(R_CanEthConv_CanRoutTblType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstCanRoutTbl[CANTBL_ENTRY_NUM];

/* filter table */
STATIC VAR(R_CanEthConv_FilterCfgType, CANETHCONV_VAR_NO_INIT)  CanEthConv_GstFilterCfg;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 
/* Can Packet Send Status */
STATIC VAR(uint32, CANETHCONV_VAR_NO_INIT)  GulSendStatus;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_32
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_VAR_NO_INIT_8
#include "CanEthConv_MemMap.h" 
/* Pack check error */
VAR(uint8, CANETHCONV_VAR_NO_INIT)  GucCheckError;
#define CANETHCONV_STOP_SEC_VAR_NO_INIT_8
#include "CanEthConv_MemMap.h" 

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/* Private functions for Ethernet to CAN Conversion */
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetCanRoutTbl(const R_CanEthConv_CanRoutTblType *pCanRoutTblCfg, 
                const uint32 ulCanRoutTblEntryNum);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetSrcMacFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetSrcIpFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetVlanFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetStreamIdFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchCanRoutTbl(const R_CanEthConv_CanFrameType *pCanFrame, 
    uint8 *pUnit, uint8 *pCh, uint8 *pAddInfo);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckEthFormat(const CanEthConv_EthRxBufType *pEthRxBuf,
    uint32 *pPayLoadIdx, uint32 *pPayLoadLen);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckAvtpFormat(const uint32 ulLeftDataIdx, 
    const uint32 ulLeftDataLen, const CanEthConv_EthRxBufType *pEthRxBuf, uint32 *pPayLoadIdx, uint32 *pPayLoadLen);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckIpv4UdpFormat(const CanEthConv_EthRxBufType *pEthRxBuf, 
    uint32 *pUdpPayloadIdx, uint32 *pUdpPayloadLen);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckIpv6UdpFormat(const CanEthConv_EthRxBufType *pEthRxBuf, 
    uint32 *pUdpPayloadIdx, uint32 *pUdpPayloadLen);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CalcIpv4UdpChecksum(const uint8 *pIpv4Pkt, uint32 *pCheckSum);
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CalcIpv6UdpChecksum(const uint8 *pIpv6Pkt, uint32 *pCheckSum);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen, 
    uint32 *pSendStatus);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) UnpackCan(const uint8 *pPayload, const uint32 ulPayloadLen, 
    uint32 *pDataPosition, R_CanEthConv_CanFrameType *pCanFrame);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SendCanFrame(const R_CanEthConv_CanFrameType *pCanFrame, 
    uint32 *pSendStatus);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckSrcMac(const uint8 *aaSrcMacAddr);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckSrcIpv4(const uint32 *pSrcIp, const uint32 *pDstIp);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckSrcIpv6(const uint32 *pSrcIp, const uint32 *pDstIp);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckVlanId(const uint16 usVlanId);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckStreamId(const uint32 *aaStreamId);

/* CAN XL Specific */
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchCanRoutTblForCanXL(
    const R_CanEthConv_CanXLFrameType *pCanFrame, uint8 *pUnit, uint8 *pCh, uint8 *pAddInfo);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) UnpackCanXL(const uint8 *pPayload, const uint32 ulPayloadLen, 
    uint32 *pDataPosition, R_CanEthConv_CanXLFrameType *pCanFrame);
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SendCanXLFrame(const R_CanEthConv_CanXLFrameType *pCanFrame, 
    uint32 *pSendStatus);


#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_001]:[Gen5GW_CanEthConv_UD_13_001]
* Function Name: CanEthConv_EthtoCanInit
* Description  : Ethernet to CAN Function Initialization.
* Arguments    : *pConfig -
*                    Initialization Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_EthtoCanInit(const R_CanEthConv_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    GulSendStatus = CANPACKETSEND_DEFAULT;

    if ((pConfig->ulCanRoutTblEntryNum >= NUM1)
    &&  (pConfig->ulCanRoutTblEntryNum <= CANTBL_ENTRY_NUM))
    {
        /* Set CAN Routing Table */
        LucRetVal = SetCanRoutTbl(pConfig->pCanRoutTbl, pConfig->ulCanRoutTblEntryNum);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Set CAN Routing Table entry number */
            CanEthConv_GulCanRoutTblNum = pConfig->ulCanRoutTblEntryNum;
            /* Copying Buffer Address and Size to global valiables */
            CanEthConv_GstEthRxBuf.aaPayload = pConfig->pBufCfg->pEthRxAddr;
            CanEthConv_GulEthRxBufSize = pConfig->pBufCfg->ulEthRxBufSize;
            CanEthConv_GaaCanTxBuf = pConfig->pBufCfg->pCanTxAddr;
            /* Initialize Ethernet Rx buffer */
            CanEthConv_UtilMemSet(&CanEthConv_GstEthRxBuf.aaPayload[IDX_0], (uint8)NUM0, CanEthConv_GulEthRxBufSize);
            /* Initialize CAN Tx buffer */
            CanEthConv_UtilMemSet(&CanEthConv_GaaCanTxBuf[IDX_0], (uint8)NUM0, pConfig->pBufCfg->ulCanTxBufSize);
        
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_CFG_CANTBL);
        #endif         
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* filter config clear */
        CanEthConv_GstFilterCfg.usSrcMacFilterNum   = NUM0;
        CanEthConv_GstFilterCfg.aaSrcMacAddr        = NULL_PTR;
        CanEthConv_GstFilterCfg.usSrcIpFilterNum    = NUM0;
        CanEthConv_GstFilterCfg.aaSrcIpAddr         = NULL_PTR;
        CanEthConv_GstFilterCfg.usVlanIdFilterNum   = NUM0;
        CanEthConv_GstFilterCfg.aaVlanId            = NULL_PTR;
        CanEthConv_GstFilterCfg.usStreamIdFilterNum = NUM0;
        CanEthConv_GstFilterCfg.aaStreamId          = NULL_PTR;

        if (NULL_PTR != pConfig->pFilterCfg)
        {
            /* source mac address filter */
            LucRetVal = SetSrcMacFilterCfg(pConfig->pFilterCfg);
            if ((uint8)E_OK == LucRetVal)
            {
                /* source ip address filter */
                LucRetVal = SetSrcIpFilterCfg(pConfig->pFilterCfg);
                if ((uint8)E_OK == LucRetVal)
                {
                    /* vlanid filter */
                    LucRetVal = SetVlanFilterCfg(pConfig->pFilterCfg);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* streamid filter */
                        LucRetVal = SetStreamIdFilterCfg(pConfig->pFilterCfg);
                    }
                    else
                    {
                        /* Do nothing */
                    }
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_CFG_FILTER);
            #endif         
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_002]:[Gen5GW_CanEthConv_UD_13_002]
* Function Name: CanEthConv_EthtoCan
* Description  : Ethernet to CAN Conversion Function
* Arguments    : usFrameType -
*                    Ethernet frame type
*                *aaSrcMacAddr -
*                    Ethernet source MacAddress
*                *pEthFrame -
*                    EThernet frame
*                ulFrameLen -
*                    Etherenet frame length
*                *pSendStatus -
*                    can packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_EthtoCan(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
                           const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus)
{
    Std_ReturnType                  LucRetVal;
    uint16                          LusFrameType;
    uint16                          LusVlanId;
    uint32                          LulPayLoadIdx;
    uint32                          LulPayLoadLen;
    uint32                          LulFrameLen;
    const CanEthConv_IEEE8021QType  *pIEEE8021QHeader;
    const uint8                     *LpEthFrame;

    if ((NULL_PTR != CanEthConv_GaaCanTxBuf)
    && ( ((uint32)NUM0 == (uint32)CanEthConv_GstFilterCfg.usSrcMacFilterNum)   ||
        (NULL_PTR != CanEthConv_GstFilterCfg.aaSrcMacAddr) )
    && ( ((uint32)NUM0 == (uint32)CanEthConv_GstFilterCfg.usSrcIpFilterNum)    ||
        (NULL_PTR != CanEthConv_GstFilterCfg.aaSrcIpAddr ) )
    && ( ((uint32)NUM0 == (uint32)CanEthConv_GstFilterCfg.usVlanIdFilterNum)   ||
        (NULL_PTR != CanEthConv_GstFilterCfg.aaVlanId    ) )
    && ( ((uint32)NUM0 == (uint32)CanEthConv_GstFilterCfg.usStreamIdFilterNum) ||
        (NULL_PTR != CanEthConv_GstFilterCfg.aaStreamId  ) ) )
    {
        LusFrameType = usFrameType;
        LulFrameLen  = ulFrameLen;
        LulPayLoadIdx = NUM0;
        LulPayLoadLen = NUM0;

        /* source MAC Address filter */
        LucRetVal = CheckSrcMac(aaSrcMacAddr);
        if ((uint8)E_OK == LucRetVal)
        {
            if ((LulFrameLen >= ETH_FRAME_PAYLOAD_SIZE_MIN) &&
                (LulFrameLen <= CanEthConv_GulEthRxBufSize))
            {
                /* Check IEEE802.1Q */
                if ((uint32)CANETHCONV_FRAMETYPE_8021Q == (uint32)LusFrameType)
                {
                    /* VLANID filter */
                    pIEEE8021QHeader = (const CanEthConv_IEEE8021QType*)pEthFrame;
                    LusVlanId = pIEEE8021QHeader->usVlanId;
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    CanEthConv_UtilEndianConv16((uint16*)&LusVlanId);
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
                    LucRetVal = CheckVlanId((uint16)((uint32)LusVlanId & (uint32)MASK_12BIT));
                    if ((uint8)E_OK == LucRetVal)
                    {
                        LusFrameType = pIEEE8021QHeader->usFrameType;
                        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                        CanEthConv_UtilEndianConv16(&LusFrameType);
                        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

                        LpEthFrame  = &pEthFrame[sizeof(CanEthConv_IEEE8021QType)];
                        LulFrameLen -= sizeof(CanEthConv_IEEE8021QType);
                    }
                    else
                    {
                        /* Do Nothing */
                    }
                }
                else
                {
                    LpEthFrame = &pEthFrame[IDX_0];
                }

                if ((uint8)E_OK == LucRetVal)
                {
                    /* Copy Ethernet frame to Rx buffer */
                    CanEthConv_UtilMemCpy(&CanEthConv_GstEthRxBuf.aaPayload[IDX_0], LpEthFrame, LulFrameLen);
                    CanEthConv_GstEthRxBuf.usFrameType = LusFrameType;
                    CanEthConv_GstEthRxBuf.ulFrameLen  = LulFrameLen;

                    /* Check format of Ethernet frame. */
                    LucRetVal = CheckEthFormat(&CanEthConv_GstEthRxBuf, &LulPayLoadIdx, &LulPayLoadLen);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Unpack and Send CAN frame. */
                        LucRetVal = CanUnpackAndSend(&CanEthConv_GstEthRxBuf.aaPayload[LulPayLoadIdx],
                                                     LulPayLoadLen, pSendStatus);
                    }
                    else
                    {
                        /* Do nothing */
                    }

                    /* Clear Ethernet Rx buffer. */
                    CanEthConv_GstEthRxBuf.usFrameType = NUM0;
                    CanEthConv_GstEthRxBuf.ulFrameLen = NUM0;
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif         
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_PARAM_CONFIG);
        #endif         
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_003]:[Gen5GW_CanEthConv_UD_13_003]
* Function Name: SetCanRoutTbl
* Description  : Ethernet to CAN Routing Table Setting.
* Arguments    : *pCanRoutTblCfg -
*                    Ethernet to CAN Routing Table Config
*                 ulCanRoutTblEntryNum -
*                    Number of CAN routing entries
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetCanRoutTbl(const R_CanEthConv_CanRoutTblType *pCanRoutTblCfg,
                                    const uint32 ulCanRoutTblEntryNum)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulCanId;

    LucRetVal = E_OK;

    /* Check All entry config data */
    for (LulEntryIdx = IDX_0; LulEntryIdx < ulCanRoutTblEntryNum; LulEntryIdx++)
    {
        /* Check CAN-ID */
        LulCanId = pCanRoutTblCfg[LulEntryIdx].ulCanId;
        /* Check Standard CAN ID */
        if ((LulCanId <= (uint32)CANID_BASE_MAX)
        /* Check Extended CAN ID */
        || ((LulCanId >= (uint32)CANID_EXTENDED_MIN)    && (LulCanId <= (uint32)CANID_EXTENDED_MAX))
        /* Check Standard CANFD ID */
        || ((LulCanId >= (uint32)CANFD_ID_BASE_MIN)     && (LulCanId <= (uint32)CANFD_ID_BASE_MAX))
        /* Check Extended CANFD ID */
        || ((LulCanId >= (uint32)CANFD_ID_EXTENDED_MIN) && (LulCanId <= (uint32)CANFD_ID_EXTENDED_MAX))
        /* Check CANXL ID */
        || ((LulCanId >= (uint32)CANXL_XLF_BIT) && (LulCanId <= ((uint32)CANID_XL_MAX | (uint32)CANXL_XLF_BIT))))
        {
            /*  Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_CFG_CANTBL);
            #endif
            /* Check one entry is NG. */
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {
            /* Check Unit and Channel number*/
            if ((((uint32)pCanRoutTblCfg[LulEntryIdx].ucUnit <= (uint32)CAN_UNIT_MAX)   &&
                 ((uint32)pCanRoutTblCfg[LulEntryIdx].ucCh   <= (uint32)CAN_CHANNEL_MAX))
            ||  (((uint32)pCanRoutTblCfg[LulEntryIdx].ucUnit == (uint32)CANXL_UNIT_NUM) &&
                 ((uint32)pCanRoutTblCfg[LulEntryIdx].ucCh   <= (uint32)CANXL_CHANNEL_MAX)))
            {
                /* Check one entry is OK. Next entry. */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_CFG_CANTBL);
                #endif
                /* Check one entry is NG. */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do Nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            /* Do Nothing */
        }
        else
        {
            break;
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy from Configuration to Table */
        CanEthConv_UtilMemCpy(&CanEthConv_GstCanRoutTbl, pCanRoutTblCfg,
                              (sizeof(R_CanEthConv_CanRoutTblType) * ulCanRoutTblEntryNum));
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_020]:[Gen5GW_CanEthConv_UD_13_020]
* Function Name: SetSrcMacFilterCfg
* Description  : Source Mac Address Filter Setting.
* Arguments    : *pFilterCfg -
*                    Filter Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetSrcMacFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg)
{
    Std_ReturnType LucRetVal;
    
    LucRetVal = E_OK;

    /* Source mac address filter */
    if ((uint32)pFilterCfg->usSrcMacFilterNum > (uint32)NUM0)
    {
        if ((uint32)pFilterCfg->usSrcMacFilterNum <= (uint32)MACADDRESS_FILTER_NUM_MAX)
        {
            if (NULL_PTR != pFilterCfg->aaSrcMacAddr)
            {
                CanEthConv_GstFilterCfg.usSrcMacFilterNum = pFilterCfg->usSrcMacFilterNum;
                CanEthConv_GstFilterCfg.aaSrcMacAddr      = pFilterCfg->aaSrcMacAddr;
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_CFG_FILTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_CFG_FILTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*  Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_021]:[Gen5GW_CanEthConv_UD_13_021]
* Function Name: SetSrcIpFilterCfg
* Description  : Source IP Address Filter Setting.
* Arguments    : *pFilterCfg -
*                    Filter Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetSrcIpFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* Source IP address filter */
    if ((uint32)pFilterCfg->usSrcIpFilterNum > (uint32)NUM0)
    {
        if ((uint32)pFilterCfg->usSrcIpFilterNum <= (uint32)IPADDRESS_FILTER_NUM_MAX)
        {
            if (NULL_PTR != pFilterCfg->aaSrcIpAddr)
            {
                CanEthConv_GstFilterCfg.usSrcIpFilterNum = pFilterCfg->usSrcIpFilterNum;
                CanEthConv_GstFilterCfg.aaSrcIpAddr      = pFilterCfg->aaSrcIpAddr;
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_CFG_FILTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_CFG_FILTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*  Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_022]:[Gen5GW_CanEthConv_UD_13_022]
* Function Name: SetVlanFilterCfg
* Description  : VlanID Filter Setting.
* Arguments    : *pFilterCfg -
*                    Filter Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetVlanFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* VlanID filter */
    if ((uint32)pFilterCfg->usVlanIdFilterNum > (uint32)NUM0)
    {
        if ((uint32)pFilterCfg->usVlanIdFilterNum <= (uint32)VLANID_FILTER_NUM_MAX)
        {
            if (NULL_PTR != pFilterCfg->aaVlanId)
            {
                CanEthConv_GstFilterCfg.usVlanIdFilterNum = pFilterCfg->usVlanIdFilterNum;
                CanEthConv_GstFilterCfg.aaVlanId          = pFilterCfg->aaVlanId;
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_CFG_FILTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_CFG_FILTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*  Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_023]:[Gen5GW_CanEthConv_UD_13_023]
* Function Name: SetStreamIdFilterCfg
* Description  : StreamID Filter Setting.
* Arguments    : *pFilterCfg -
*                    Filter Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SetStreamIdFilterCfg(const R_CanEthConv_FilterCfgType *pFilterCfg)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    /* StreamID filter */
    if ((uint32)pFilterCfg->usStreamIdFilterNum > (uint32)NUM0)
    {
        if ((uint32)pFilterCfg->usStreamIdFilterNum <= (uint32)STREAMID_FILTER_NUM_MAX)
        {
            if (NULL_PTR != pFilterCfg->aaStreamId)
            {
                CanEthConv_GstFilterCfg.usStreamIdFilterNum = pFilterCfg->usStreamIdFilterNum;
                CanEthConv_GstFilterCfg.aaStreamId          = pFilterCfg->aaStreamId;
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_CFG_FILTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_CFG_FILTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*  Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_004]:[Gen5GW_CanEthConv_UD_13_004]
* Function Name: SearchCanRoutTbl
* Description  : Search CAN to Ethernet Routing Table.
* Arguments    : *pCanFrame -
*                    CAN frame
*                *pUnit-
*                    Destination UNIT number
*                *pCh -
*                    Destination CHANNEL number
*                *pAddInfo -
*                    Additional Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchCanRoutTbl(const R_CanEthConv_CanFrameType *pCanFrame, 
    uint8 *pUnit, uint8 *pCh, uint8 *pAddInfo)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulComparedCanId;
    uint32 LulEntryCanId;

    LucRetVal = E_NOT_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < CanEthConv_GulCanRoutTblNum; LulEntryIdx++)
    {
        /* Apply CAN ID Mask */
        LulComparedCanId = pCanFrame->ulCanId &
                            CanEthConv_GstCanRoutTbl[LulEntryIdx].ulCanIdMask;
        LulEntryCanId = CanEthConv_GstCanRoutTbl[LulEntryIdx].ulCanId &
                            CanEthConv_GstCanRoutTbl[LulEntryIdx].ulCanIdMask;

        if (LulComparedCanId == LulEntryCanId)
        {
            /* Entry is match. End Search */
            LucRetVal = E_OK;
            break;
        }
        else
        {
            /* Entry is not match. Next Entry */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy Destination Unit, Channel and Additional Information */
        *pUnit    = CanEthConv_GstCanRoutTbl[LulEntryIdx].ucUnit;
        *pCh      = CanEthConv_GstCanRoutTbl[LulEntryIdx].ucCh;
        *pAddInfo = CanEthConv_GstCanRoutTbl[LulEntryIdx].ucAddInfo;
    }
    else
    {
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_005]:[Gen5GW_CanEthConv_UD_13_005]
* Function Name: CheckEthFormat
* Description  : Check Ethernet frame format.
* Arguments    : *pEthRxBuf  -
*                    Ethernet Rx buffer
*                *pPayLoadIdx  -
*                    AVTP payload position in Ethernet frame.
*                *pPayLoadLen -
*                   AVTP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckEthFormat(const CanEthConv_EthRxBufType *pEthRxBuf, 
    uint32 *pPayLoadIdx, uint32 *pPayLoadLen)
{
    Std_ReturnType                  LucRetVal;
    uint32                          LulLeftDataIdx;
    uint32                          LulLeftDataLen;

    LucRetVal = E_OK;

    switch ((uint32)pEthRxBuf->usFrameType)
    {
    case CANETHCONV_FRAMETYPE_IPV4:
        /* Check IPv4 header and UPD format */
        LucRetVal = CheckIpv4UdpFormat(pEthRxBuf, &LulLeftDataIdx, &LulLeftDataLen);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Check encapsulation_sequence_num field size */
            if (LulLeftDataLen >= sizeof(uint32))
            {
                /* Set AVTP header position and left data size */
                LulLeftDataIdx += sizeof(uint32);
                LulLeftDataLen -= sizeof(uint32);
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    case CANETHCONV_FRAMETYPE_IPV6:
        /* Check IPv6 header and UPD format */
        LucRetVal = CheckIpv6UdpFormat(pEthRxBuf, &LulLeftDataIdx, &LulLeftDataLen);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Check encapsulation_sequence_num field size */
            if (LulLeftDataLen >= sizeof(uint32))
            {
                /* Set AVTP header position and left data size */
                LulLeftDataIdx += sizeof(uint32);
                LulLeftDataLen -= sizeof(uint32);
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do nothing */
        }
        break;
    case CANETHCONV_FRAMETYPE_AVTP:
        /* Set AVTP header position and left data size */
        LulLeftDataIdx = IDX_0;
        LulLeftDataLen = pEthRxBuf->ulFrameLen;
        break;
    default:
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_PARAM_DATA_LENGTH);
        #endif
        LucRetVal = E_NOT_OK;
        break;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CheckAvtpFormat(LulLeftDataIdx, LulLeftDataLen, pEthRxBuf, pPayLoadIdx, pPayLoadLen);
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_027]:[Gen5GW_CanEthConv_UD_13_027]
* Function Name: CheckAvtpFormat
* Description  : Check AVTP format.
* Arguments    : ulLeftDataIdx -
*                    frame data index
*                ulLeftDataLen -
*                    frame data length
*                *pEthRxBuf  -
*                    Ethernet Rx buffer
*                *pPayLoadIdx  -
*                    AVTP payload position in Ethernet frame.
*                *pPayLoadLen -
*                   AVTP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckAvtpFormat(const uint32 ulLeftDataIdx, 
                              const uint32 ulLeftDataLen,
                              const CanEthConv_EthRxBufType *pEthRxBuf,
                              uint32 *pPayLoadIdx, uint32 *pPayLoadLen)
{
    Std_ReturnType                  LucRetVal;
    uint32                          LulNTSCFDataLength;
    uint16                          LusTSCFDataLength;
    uint32                          LaaStreamId[CANETHCONV_STREAMID_LEN_IN_WORD];
    const CanEthConv_AVTPCommonType *pAVTPHeader;
    const CanEthConv_NTSCFType      *pNTSCFHeader;
    const CanEthConv_TSCFType       *pTSCFHeader;

    LucRetVal = E_OK;

    pAVTPHeader = (const CanEthConv_AVTPCommonType*)&pEthRxBuf->aaPayload[ulLeftDataIdx];
    if ((uint32)SUBTYPE_NTSCF == (uint32)pAVTPHeader->ucSubType)
    {
        /* Get NTSCF payload length */
        pNTSCFHeader = (const CanEthConv_NTSCFType *)&pEthRxBuf->aaPayload[ulLeftDataIdx];
        LaaStreamId[IDX_0] = pNTSCFHeader->aaStreamId[IDX_0];
        LaaStreamId[IDX_1] = pNTSCFHeader->aaStreamId[IDX_1];
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LaaStreamId[IDX_0]);
        CanEthConv_UtilEndianConv32(&LaaStreamId[IDX_1]);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
        LulNTSCFDataLength = (((uint32)pNTSCFHeader->ucSvVerDataLenMSB << (uint32)SHIFT_8BIT)
                              | (uint32)pNTSCFHeader->ucDataLenLSB) & (uint32)MASK_NTSCF_DATA_LENGTH;
        /* Check NTSCF header format */
        if ((ulLeftDataLen >= (uint32)HEADER_LEN_NTSCF)
        &&  (LulNTSCFDataLength <= (ulLeftDataLen - (uint32)HEADER_LEN_NTSCF)))
        {
            LucRetVal = CheckStreamId(LaaStreamId);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Set NTSCF payload position and length */
                *pPayLoadIdx = ulLeftDataIdx + (uint32)HEADER_LEN_NTSCF;
                *pPayLoadLen = LulNTSCFDataLength;
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PARAM_DATA_LENGTH);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else if ((uint32)SUBTYPE_TSCF == (uint32)pAVTPHeader->ucSubType)
    {
        /* Get TSCF payload length */
        pTSCFHeader = (const CanEthConv_TSCFType *)&pEthRxBuf->aaPayload[ulLeftDataIdx];
        LaaStreamId[IDX_0] = pTSCFHeader->aaStreamId[IDX_0];
        LaaStreamId[IDX_1] = pTSCFHeader->aaStreamId[IDX_1];
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LaaStreamId[IDX_0]);
        CanEthConv_UtilEndianConv32(&LaaStreamId[IDX_1]);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
        LusTSCFDataLength = pTSCFHeader->usStreamDataLength;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&LusTSCFDataLength);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        /* Check TSCF header format */
        if ((ulLeftDataLen >= (uint32)HEADER_LEN_TSCF)
        &&  ((uint32)LusTSCFDataLength <= (ulLeftDataLen - (uint32)HEADER_LEN_TSCF)))
        {
            LucRetVal = CheckStreamId(LaaStreamId);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Set TSCF payload position and length */
                *pPayLoadIdx = ulLeftDataIdx + (uint32)HEADER_LEN_TSCF;
                *pPayLoadLen = LusTSCFDataLength;
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PARAM_DATA_LENGTH);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else if ((uint32)NUM0 == (uint32)pAVTPHeader->ucSubType)
    {
        /* AVTP Header none (raw) */
        if ((uint32)NUM4 <= ulLeftDataIdx)
        {
            /* Set payload position and length */
            *pPayLoadIdx = ulLeftDataIdx - sizeof(uint32);
            *pPayLoadLen = ulLeftDataLen + sizeof(uint32);
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PARAM_DATA_LENGTH);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_PARAM_DATA_LENGTH);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_006]:[Gen5GW_CanEthConv_UD_13_006]
* Function Name: CheckIpv4UdpFormat
* Description  : Check IPv4 header and UDP format
* Arguments    : *pEthRxBuf -
*                    Ethernet Rx buffer
*                *pUdpPayloadIdx -
*                    UDP payload position in Ethernet frame.
*                *pUdpPayloadLen -
*                    UDP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckIpv4UdpFormat(const CanEthConv_EthRxBufType *pEthRxBuf, 
                                 uint32 *pUdpPayloadIdx, uint32 *pUdpPayloadLen)
{
    Std_ReturnType LucRetVal;
    CanEthConv_Ipv4HeaderType LstIpv4Header;
    uint16 LusFragmentOffset;
    uint16 LusDataLen;
    uint16 LusUdpPort;
    uint32 LulCkSum;

    LucRetVal = E_OK;

    /* Check if the Ethernet frame length is longer than the IPv4 header length */
    if (pEthRxBuf->ulFrameLen >= (HEADER_LEN_IPV4 + HEADER_LEN_UDP))
    {
        /* Copy IPv4 header (Big-Endian) */
        CanEthConv_UtilMemCpy(&LstIpv4Header, pEthRxBuf->aaPayload, sizeof(LstIpv4Header));
        /* Endian conversion (Network order to host order) */
        LusFragmentOffset = LstIpv4Header.usFragment;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&LusFragmentOffset);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
        LusDataLen = LstIpv4Header.usPktLen;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&LusDataLen);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
        LusUdpPort = ((const CanEthConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV4])->usDestPort;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&LusUdpPort);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        /*
         *   Validation of the IPv4 header
         *   The version field is 0x4 and the IHL field value is 0x5. (IP options are not allowed)
         *   MF and fragment offset field value.
         *   Validation of IPv4 data length field value
         *     >= ([IPv4 header length] + [UDP header length])
         *     <= Ethernet frame length
         *   Protocol field value is UDP.
         */
        if (((uint32)VER_AND_HEADERLEN_IPV4 == (uint32)LstIpv4Header.ucVerAndHeaderLen) &&
            ((uint32)NOT_FRAGMENTED_IPV4 == ((uint32)LusFragmentOffset & (uint32)MASK_FRAGMENT_MF_OFFSET)) &&
            ((uint32)LusDataLen   >= ((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP)) &&
            ((uint32)LusDataLen   <= pEthRxBuf->ulFrameLen) &&
            ((uint32)PROTOCOL_UDP == (uint32)LstIpv4Header.ucProtocol))
        {
            /* Verify IPv4 header checksum */
            LulCkSum = NUM0;
            CanEthConv_UtilCalcSum(&LstIpv4Header, sizeof(LstIpv4Header), &LulCkSum);
            if ((uint32)VERIFY_CKSUM == (uint32)LulCkSum)
            {
                /* Do nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_IPCKSUM);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PARAM_DATA_LENGTH);
            #endif
            /* Invalid IPv4 header format */
            LucRetVal = E_NOT_OK;
        }

        if ((uint8)E_OK == LucRetVal)
        {
            /* Get UDP data length */
            LusDataLen = ((const CanEthConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV4])->usLen;
            /* Endian conversion (Network order to host order) */
            #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
            CanEthConv_UtilEndianConv16(&LusDataLen);
            #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
            /* Verify the UDP data length */
            if (((uint32)LusDataLen >= (uint32)HEADER_LEN_UDP) &&
                ((uint32)LusDataLen <= (pEthRxBuf->ulFrameLen - (uint32)HEADER_LEN_IPV4)) &&
                ((uint32)LusUdpPort == (uint32)CanEthConv_GstEthSrcCfg.usSrcUdpPort))
            {
                /* If the value of the checksum field is 0, the checksum is not verified. */
                if ((uint32)CHECKSUM_ZERO !=
                    (uint32)((const CanEthConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV4])->usChecksum)
                {
                    /* Compute and verify the IPv4 UDP checksum */
                    CalcIpv4UdpChecksum(&pEthRxBuf->aaPayload[IDX_0], &LulCkSum);
                    if ((uint32)VERIFY_CKSUM == (uint32)LulCkSum)
                    {
                        /* Do nothing */
                    }
                    else
                    {
                        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                              CANETHCONV_E_UDPCKSUM);
                        #endif
                        LucRetVal = E_NOT_OK;
                    }
                }
                else
                {
                    /* Do nothing */
                }

                if ((uint8)E_OK == LucRetVal)
                {
                    /* source IP Address filter */
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    CanEthConv_UtilEndianConv32(&LstIpv4Header.ulSrcIpAddr);
                    CanEthConv_UtilEndianConv32(&LstIpv4Header.ulDestIpAddr);
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
                    LucRetVal = CheckSrcIpv4(&LstIpv4Header.ulSrcIpAddr, &LstIpv4Header.ulDestIpAddr);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Set UDP payload position and length */
                        *pUdpPayloadIdx = ((uint32)HEADER_LEN_IPV4 + (uint32)HEADER_LEN_UDP);
                        *pUdpPayloadLen = (uint32)LusDataLen - (uint32)HEADER_LEN_UDP;
                    }
                    else
                    {
                        /* Do nothing */
                    }
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                /* Invalid the UDP data length */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_PARAM_DATA_LENGTH);
        #endif
        /* Invalid the Ethernet frame length */
        LucRetVal = E_NOT_OK;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_013]:[Gen5GW_CanEthConv_UD_13_013]
* Function Name: CheckIpv6UdpFormat
* Description  : Check IPv6 header and UDP format
* Arguments    : *pEthRxBuf -
*                    Ethernet Rx buffer
*                *pUdpPayloadIdx -
*                    UDP payload position in Ethernet frame.
*                *pUdpPayloadLen -
*                    UDP payload length
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckIpv6UdpFormat(const CanEthConv_EthRxBufType *pEthRxBuf, 
                                 uint32 *pUdpPayloadIdx, uint32 *pUdpPayloadLen)
{
    Std_ReturnType LucRetVal;
    CanEthConv_Ipv6HeaderType LstIpv6Header;
    uint32 LulVerClassAndLabel;
    uint16 LusDataLen;
    uint16 LusUdpPort;
    uint32 LulCkSum;
    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    uint32 LulCount;
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

    LucRetVal = E_OK;

    /* Check if the Ethernet frame length is longer than the IPv6 header length */
    if (pEthRxBuf->ulFrameLen >= (HEADER_LEN_IPV6 + HEADER_LEN_UDP))
    {
        /* Copy IPv6 header (Big-Endian) */
        CanEthConv_UtilMemCpy(&LstIpv6Header, pEthRxBuf->aaPayload, sizeof(LstIpv6Header));
        /* Endian conversion (Network order to host order) */
        LulVerClassAndLabel = LstIpv6Header.ulVerClassAndLabel;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LulVerClassAndLabel);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
        LusDataLen = LstIpv6Header.usPayloadLen;
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&LusDataLen);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        /*
         *   Validation of the IPv6 header
         *   The version field is 0x6. Traffic Class and Flow Label field are both 0x0. (IP options are not allowed)
         *   Validation of IPv6 data length field value
         *     >= [UDP header length]
         *     <= Ethernet frame length
         *   Next Header field value is UDP.
         */
        if (((uint32)VER_CLASS_AND_LABEL_IPV6 == LulVerClassAndLabel) &&
            ((uint32)LusDataLen >= (uint32)HEADER_LEN_UDP) &&
            ((uint32)LusDataLen <= (pEthRxBuf->ulFrameLen - (uint32)HEADER_LEN_IPV6)) &&
            ((uint32)PROTOCOL_UDP == (uint32)LstIpv6Header.ucNextHeader))
        {
            /* Get UDP data length and Port Number */
            LusDataLen = ((const CanEthConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV6])->usLen;
            LusUdpPort = ((const CanEthConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV6])->usDestPort;
            /* Endian conversion (Network order to host order) */
            #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
            CanEthConv_UtilEndianConv16(&LusDataLen);
            CanEthConv_UtilEndianConv16(&LusUdpPort);
            #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
            /* Verify the UDP data length */
            if (((uint32)LusDataLen >= (uint32)HEADER_LEN_UDP) &&
                ((uint32)LusDataLen <= (pEthRxBuf->ulFrameLen - (uint32)HEADER_LEN_IPV6)) &&
                ((uint32)LusUdpPort == (uint32)CanEthConv_GstEthSrcCfg.usSrcUdpPort))
            {
                /* If the value of the checksum field is 0, the checksum is not verified. */
                if ((uint32)CHECKSUM_ZERO !=
                    (uint32)((const CanEthConv_UdpHeaderType *)&pEthRxBuf->aaPayload[HEADER_LEN_IPV6])->usChecksum)
                {
                    /* Compute and verify the IPv6 UDP checksum */
                    LulCkSum = NUM0;
                    CalcIpv6UdpChecksum(&pEthRxBuf->aaPayload[IDX_0], &LulCkSum);
                    if ((uint32)VERIFY_CKSUM == (uint32)LulCkSum)
                    {
                        /* Do nothing */
                    }
                    else
                    {
                        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                              CANETHCONV_E_UDPCKSUM);
                        #endif
                        LucRetVal = E_NOT_OK;
                    }
                }
                else
                {
                    #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                          CANETHCONV_E_UDPCKSUM);
                    #endif
                    LucRetVal = E_NOT_OK;
                }

                if ((uint8)E_OK == LucRetVal)
                {
                    /* source IP Address filter */
                    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
                    for (LulCount = IDX_0; LulCount < (uint32)CANETHCONV_IPADDR_LEN_IN_WORD; LulCount++)
                    {
                        CanEthConv_UtilEndianConv32(&LstIpv6Header.aaSrcIpAddr[LulCount]);
                        CanEthConv_UtilEndianConv32(&LstIpv6Header.aaDestIpAddr[LulCount]);
                    }
                    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
                    LucRetVal = CheckSrcIpv6(LstIpv6Header.aaSrcIpAddr, LstIpv6Header.aaDestIpAddr);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Set UDP payload position and length */
                        *pUdpPayloadIdx = (HEADER_LEN_IPV6 + HEADER_LEN_UDP);
                        *pUdpPayloadLen = (uint32)LusDataLen - (uint32)HEADER_LEN_UDP;
                    }
                    else
                    {
                        /* Do nothing */
                    }
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_PARAM_DATA_LENGTH);
                #endif
                /* Invalid the UDP data length */
                LucRetVal = E_NOT_OK; 
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PARAM_DATA_LENGTH);
            #endif
            /* Invalid IPv6 header format */
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_PARAM_DATA_LENGTH);
        #endif
        /* Invalid the Ethernet frame length */
        LucRetVal = E_NOT_OK;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_007]:[Gen5GW_CanEthConv_UD_13_007]
* Function Name: CalcIpv4UdpChecksum
* Description  : Calculate IPv4 UDP checksum
* Arguments    : *pIpv4Pkt -
*                    IPv4 packet data
*                *pCheckSum -
*                    Calculated UDP checksum
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CalcIpv4UdpChecksum(const uint8 *pIpv4Pkt, uint32 *pCheckSum)
{
    CanEthConv_Ipv4PseudoHeaderType  LstIpv4PseudoHeader;
    const CanEthConv_Ipv4HeaderType *pIpv4Header;
    uint16 LusDataLen;

    /* IPv4 Pseudo Header */
    pIpv4Header = (const CanEthConv_Ipv4HeaderType *)pIpv4Pkt;
    CanEthConv_UtilMemCpy(&LstIpv4PseudoHeader.ulSrcIpAddr,
        &pIpv4Header->ulSrcIpAddr, CANETHCONV_IPV4ADDR_LEN_IN_BYTE);
    CanEthConv_UtilMemCpy(&LstIpv4PseudoHeader.ulDestIpAddr,
        &pIpv4Header->ulDestIpAddr, CANETHCONV_IPV4ADDR_LEN_IN_BYTE);
    LstIpv4PseudoHeader.ucPadZero = NUM0;
    LstIpv4PseudoHeader.ucProtocol = PROTOCOL_UDP;
    LstIpv4PseudoHeader.usDataLen = ((const CanEthConv_UdpHeaderType *)&pIpv4Pkt[HEADER_LEN_IPV4])->usLen;

    /* Calculate checksum of the IPv4 Pseudo Header */
    *pCheckSum = NUM0;
    CanEthConv_UtilCalcSum(&LstIpv4PseudoHeader, (uint16)sizeof(LstIpv4PseudoHeader), pCheckSum);

    /* Endian conversion of UDP data length */
    LusDataLen = LstIpv4PseudoHeader.usDataLen;
    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LusDataLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
    /* Calculate the UDP checksum */
    CanEthConv_UtilCalcSum(&pIpv4Pkt[HEADER_LEN_IPV4], LusDataLen, pCheckSum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_014]:[Gen5GW_CanEthConv_UD_13_014]
* Function Name: CalcIpv6UdpChecksum
* Description  : Calculate IPv6 UDP checksum
* Arguments    : *pIpv6Pkt -
*                    IPv6 packet data
*                *pCheckSum -
*                    Calculated UDP checksum
* Return Value : N/A
*******************************************************************************/
STATIC FUNC(void, CANETHCONV_PRIVATE_CODE) CalcIpv6UdpChecksum(const uint8 *pIpv6Pkt, uint32 *pCheckSum)
{
    CanEthConv_Ipv6PseudoHeaderType  LstIpv6PseudoHeader;
    const CanEthConv_Ipv6HeaderType *pIpv6Header;
    uint16 LusDataLen;

    /* IPv6 Pseudo Header */
    pIpv6Header = (const CanEthConv_Ipv6HeaderType *)pIpv6Pkt;
    CanEthConv_UtilMemCpy(&LstIpv6PseudoHeader.aaSrcIpAddr[IDX_0],
        &pIpv6Header->aaSrcIpAddr[IDX_0], CANETHCONV_IPV6ADDR_LEN_IN_BYTE);
    CanEthConv_UtilMemCpy(&LstIpv6PseudoHeader.aaDestIpAddr[IDX_0],
        &pIpv6Header->aaDestIpAddr[IDX_0], CANETHCONV_IPV6ADDR_LEN_IN_BYTE);
    LstIpv6PseudoHeader.ulPayloadLen = (uint32)((const CanEthConv_UdpHeaderType *)&pIpv6Pkt[HEADER_LEN_IPV6])->usLen;
    LstIpv6PseudoHeader.aaPadZero[IDX_0] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_1] = NUM0;
    LstIpv6PseudoHeader.aaPadZero[IDX_2] = NUM0;
    LstIpv6PseudoHeader.ucNextHeader = (uint8)PROTOCOL_UDP;

    /* Calculate checksum of the IPv6 Pseudo Header */
    *pCheckSum = NUM0;
    CanEthConv_UtilCalcSum(&LstIpv6PseudoHeader, (uint16)sizeof(LstIpv6PseudoHeader), pCheckSum);

    /* Endian conversion of UDP data length */
    LusDataLen = (uint16)LstIpv6PseudoHeader.ulPayloadLen;
    #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
    CanEthConv_UtilEndianConv16(&LusDataLen);
    #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
    /* Calculate the UDP checksum */
    CanEthConv_UtilCalcSum(&pIpv6Pkt[HEADER_LEN_IPV6], LusDataLen, pCheckSum);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_008]:[Gen5GW_CanEthConv_UD_13_008]
* Function Name: CanUnpackAndSend
* Description  : Unpack the CAN frame from the payload section and send it by CAN.
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP Payload length
*                pSendStatus -
*                    can packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanUnpackAndSend(const uint8 *pPayload, const uint32 ulPayloadLen, 
    uint32 *pSendStatus)
{
    Std_ReturnType LucRetVal;
    R_CanEthConv_CanFrameType   LstCanFrame;
    R_CanEthConv_CanXLFrameType LstCanXLFrame;
    R_CanEthConv_CanXLParamType LstCanXLParam;
    uint32 LulUnpackedNum;
    uint32 LulDataPosition;
    uint32 LulCanId;
    
    LulDataPosition = NUM0;
    LstCanXLFrame.pXLParams = &LstCanXLParam;
    LstCanXLParam.usPriorityId = NUM0;
    LstCanXLParam.usVcid = NUM0;
    LstCanXLParam.ucSduType = NUM0;
    LstCanXLParam.ulAcceptanceField = NUM0;
    LstCanXLParam.ucSec = NUM0;

    /* clear send status */
    *pSendStatus = NUM0;
    GucCheckError = NUM0;

    /* Unpack All CAN frames */
    for (LulUnpackedNum = IDX_0; LulUnpackedNum <= (uint32)CANFRAME_NUM_MAX; LulUnpackedNum++)
    {
        CanEthConv_UtilMemCpy(&LulCanId, &pPayload[LulDataPosition], sizeof(LulCanId));
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LulCanId);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */
        
        /* CAN Protocol check */ 
        if (CANXL_XLF_BIT == (LulCanId & CANXL_XLF_BIT))
        {
            /* Unpack CANXL frame from payload */
            LucRetVal = UnpackCanXL(pPayload, ulPayloadLen, &LulDataPosition, &LstCanXLFrame);
            if (((uint8)E_OK == LucRetVal) && ((uint8)CANETHCONV_E_NOTFRAME != GucCheckError))
            {
                /* Send CANXL frame */
                LucRetVal = SendCanXLFrame(&LstCanXLFrame, pSendStatus);
                if (((uint8)E_OK == LucRetVal)
                ||  ((uint8)CANETHCONV_E_TRANS == GucCheckError))
                {
                    LucRetVal = E_OK;
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        else
        {
            /* Unpack CAN frame from payload */
            LucRetVal = UnpackCan(pPayload, ulPayloadLen, &LulDataPosition, &LstCanFrame);
            if (((uint8)E_OK == LucRetVal) && ((uint8)CANETHCONV_E_NOTFRAME != GucCheckError))
            {
                /* Send CAN frame */
                LucRetVal = SendCanFrame(&LstCanFrame, pSendStatus);
                if (((uint8)E_OK == LucRetVal)
                ||  ((uint8)CANETHCONV_E_TRANS == GucCheckError))
                {
                    LucRetVal = E_OK;
                }
                else
                {
                    /* Do nothing */
                }
            }
            else
            {
                /* Do nothing */
            }
        }
        if (((uint8)E_OK == LucRetVal) && ((uint8)CANETHCONV_E_NOTFRAME != GucCheckError))
        {
            /* Do nothing */
        }
        else
        {
            break;
        }
    }

    /*
     * If the CAN frame unpacking is not an error termination and
     * the CAN frame unpacking is not 0, it is success
     */
    if (((uint8)E_OK == LucRetVal) ||
        ((uint8)CANETHCONV_E_NOTFRAME == GucCheckError))
    {
        if ((uint32)NUM0 == *pSendStatus)
        {
            if ((uint32)NUM0 != LulUnpackedNum)
            {
                /* Since the CAN frame has been unpacked, it ends normally */
                LucRetVal = E_OK;
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                      CANETHCONV_E_PACKEDCAN);
                #endif
                /* If the CAN frame is not unpacked, it will end with an error */
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_TRANS);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_009]:[Gen5GW_CanEthConv_UD_13_009]
* Function Name: UnpackCan
* Description  : Unpack the CAN frame from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pCanFrame -
*                    Unpacked CAN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) UnpackCan(const uint8 *pPayload, const uint32 ulPayloadLen, 
    uint32 *pDataPosition, R_CanEthConv_CanFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint32 LulCanId;
    uint32 LulDlc;

    LucRetVal = E_OK;

    /* Unpack one CAN frame from the payload */
    LulFramePos = *pDataPosition;
    if (ulPayloadLen >= (LulFramePos + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC))
    {
        /* Retrieve the CAN ID and DLC */
        CanEthConv_UtilMemCpy(&LulCanId, &pPayload[LulFramePos], sizeof(LulCanId));
        LulFramePos +=  (uint32)CAN_LEN_ID;
        CanEthConv_UtilMemCpy(&LulDlc, &pPayload[LulFramePos], sizeof(LulDlc));
        LulFramePos +=  (uint32)CAN_LEN_DLC;

        /* Endian conversion : CAN ID , DLC */
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv32(&LulCanId);
        CanEthConv_UtilEndianConv32(&LulDlc);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        if ((LulDlc <= (uint32)CANFRAME_LEN_MAX) &&
            ((LulFramePos + LulDlc) <= ulPayloadLen))
        {
            /* Copy CAN data to Tx buffer */
            CanEthConv_UtilMemCpy(&CanEthConv_GaaCanTxBuf[IDX_0], &pPayload[LulFramePos], LulDlc);
            /* Set CAN frame data */
            pCanFrame->ulCanId = LulCanId;
            pCanFrame->ulCanDlc = LulDlc;
            pCanFrame->pCanData = &CanEthConv_GaaCanTxBuf[IDX_0];

            /* Return the next CAN frame position */
            *pDataPosition = LulFramePos + LulDlc;
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PACKEDCAN);
            #endif            
            /* Invald the CAN DLC */
            GucCheckError = CANETHCONV_E_PACKEDCAN;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No CAN frame if the data length from the unpacked position is
         * less than the size of the CAN ID and DLC.
         */
        GucCheckError = CANETHCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_010]:[Gen5GW_CanEthConv_UD_13_010]
* Function Name: SendCanFrame
* Description  : Send CAN frame
* Arguments    : *pCanFrame -
*                    CAN frame data
*                *pSendStatus -
*                    can packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SendCanFrame(const R_CanEthConv_CanFrameType *pCanFrame, 
     uint32 *pSendStatus)
{
    Std_ReturnType LucRetVal;
    uint8  LucUnit;
    uint8  LucChannel;    
    uint8  LucAddInfo;
    uint32 LulSendStatusMask;

    /* Find the CAN frame destination in the CAN routing table. */
    LucRetVal = SearchCanRoutTbl(pCanFrame, &LucUnit, &LucChannel, &LucAddInfo);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Check Can Packet Send Guard */
        LulSendStatusMask = (((uint32)NUM1 << (uint32)LucChannel) << ((uint32)LucUnit * (uint32)NUM8));
        if ((uint32)NUM0 != (GulSendStatus & LulSendStatusMask))
        {
            /* If the destination exists, send it with a user-defined function. */
            LucRetVal = (uint8)CanEthConv_CanTransmitUserDef(pCanFrame, LucUnit, LucChannel, LucAddInfo);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                *pSendStatus |= (((uint32)NUM1 << (uint32)LucChannel) << ((uint32)LucUnit * (uint32)NUM8));
                GucCheckError = CANETHCONV_E_TRANS;
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /*
         * If the destination is not found,
         * notify by the user-defined function of inter-core communication
         */
        LucRetVal = (uint8)CanEthConv_CanNotifyUserDef(pCanFrame);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_BSWNOTIFY);
            #endif
            GucCheckError = CANETHCONV_E_BSWNOTIFY;
            LucRetVal = E_NOT_OK;
        }
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_015]:[Gen5GW_CanEthConv_UD_13_015]
* Function name: CheckSrcMac
* Description  : filter by source MAC Address
* Arguments    : *aaSrcMacAddr -
*                   source MAC Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckSrcMac(const uint8 *aaSrcMacAddr)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;
    uint32 LulSrcMacAddr[CANETHCONV_MACADDR_LEN_IN_WORD];

    LulSrcMacAddr[IDX_0] = ((uint32)aaSrcMacAddr[IDX_0] << SHIFT_8BIT)  | ((uint32)aaSrcMacAddr[IDX_1]);
    LulSrcMacAddr[IDX_1] = ((uint32)aaSrcMacAddr[IDX_2] << SHIFT_24BIT) | ((uint32)aaSrcMacAddr[IDX_3] << SHIFT_16BIT)
                       | ((uint32)aaSrcMacAddr[IDX_4] << SHIFT_8BIT)  | (uint32)aaSrcMacAddr[IDX_5];

    /* filter enabled */
    if ((uint32)NUM0 < (uint32)CanEthConv_GstFilterCfg.usSrcMacFilterNum)
    {
        /* Scan the filter table */
        LucRetVal = E_NOT_OK;
        for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)CanEthConv_GstFilterCfg.usSrcMacFilterNum; LulFilterIdx++)
        {
            if ((LulSrcMacAddr[IDX_0] == CanEthConv_GstFilterCfg.aaSrcMacAddr[LulFilterIdx].aaMacAddr[IDX_0])
            &&  (LulSrcMacAddr[IDX_1] == CanEthConv_GstFilterCfg.aaSrcMacAddr[LulFilterIdx].aaMacAddr[IDX_1]))
            {
                /* found MAC Address */
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* filter disabled */
        LucRetVal = E_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_016]:[Gen5GW_CanEthConv_UD_13_016]
* Function name: CheckSrcIpv4
* Description  : filter by source IPv4 Address
* Arguments    : *pSrcIp -
*                   source IP Address
*              : *pDstIp -
*                   destination IP Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckSrcIpv4(const uint32 *pSrcIp, const uint32 *pDstIp)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* check destination IP Address */
    if (*pDstIp == CanEthConv_GstEthSrcCfg.ulSrcIpv4Addr)
    {
        /* filter enabled */
        if ((uint32)NUM0 < (uint32)CanEthConv_GstFilterCfg.usSrcIpFilterNum)
        {
            /* Scan the filter table */
            LucRetVal = E_NOT_OK;
            for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)CanEthConv_GstFilterCfg.usSrcIpFilterNum; LulFilterIdx++)
            {
                if (*pSrcIp == CanEthConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_0])
                {
                    /* found IPV4 Address */
                    LucRetVal = E_OK;
                    break;
                }
                else
                {
                    /* Do nothing */
                }
            }
        }
        else
        {
            /* filter disabled */
            LucRetVal = E_OK;
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_017]:[Gen5GW_CanEthConv_UD_13_017]
* Function name: CheckSrcIpv6
* Description  : filter by source IPv6 Address
* Arguments    : *pSrcIp -
*                   source IP Address
*              : *pDstIp -
*                   destination IP Address
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckSrcIpv6(const uint32 *pSrcIp, const uint32 *pDstIp)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* check destination IP Address */
    if ((pDstIp[IDX_0] == CanEthConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_0])
    &&  (pDstIp[IDX_1] == CanEthConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_1])
    &&  (pDstIp[IDX_2] == CanEthConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_2])
    &&  (pDstIp[IDX_3] == CanEthConv_GstEthSrcCfg.aaSrcIpv6Addr[IDX_3]))
    {
        /* filter enabled */
        if ((uint32)NUM0 < (uint32)CanEthConv_GstFilterCfg.usSrcIpFilterNum)
        {
            /* Scan the filter table */
            LucRetVal = E_NOT_OK;
            for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)CanEthConv_GstFilterCfg.usSrcIpFilterNum; LulFilterIdx++)
            {
                if ((pSrcIp[IDX_0] == CanEthConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_0])
                &&  (pSrcIp[IDX_1] == CanEthConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_1])
                &&  (pSrcIp[IDX_2] == CanEthConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_2])
                &&  (pSrcIp[IDX_3] == CanEthConv_GstFilterCfg.aaSrcIpAddr[LulFilterIdx].aaIpAddr[IDX_3]))
                {
                    /* found IPV6 Address */
                    LucRetVal = E_OK;
                    break;
                }
                else
                {
                    /* Do nothing */
                }
            }
        }
        else
        {
            /* filter disabled */
            LucRetVal = E_OK;
        }
    }
    else
    {
        LucRetVal = E_NOT_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_018]:[Gen5GW_CanEthConv_UD_13_018]
* Function name: CheckVlanId
* Description  : filter by source VLAN ID
* Arguments    : usVlanId -
*                   vlan id
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckVlanId(const uint16 usVlanId)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* filter enabled */
    if ((uint32)NUM0 < (uint32)CanEthConv_GstFilterCfg.usVlanIdFilterNum)
    {
        /* Scan the filter table */
        LucRetVal = E_NOT_OK;
        for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)CanEthConv_GstFilterCfg.usVlanIdFilterNum; LulFilterIdx++)
        {
            if ((uint32)usVlanId == (uint32)CanEthConv_GstFilterCfg.aaVlanId[LulFilterIdx])
            {
                /* found VLANID */
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* filter disabled */
        LucRetVal = E_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}

/***************************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_019]:[Gen5GW_CanEthConv_UD_13_019]
* Function name: CheckStreamId
* Description  : filter by source Stream ID
* Arguments    : *aaStreamId -
*                  Stream ID
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
***************************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckStreamId(const uint32 *aaStreamId)
{
    Std_ReturnType LucRetVal;
    uint32 LulFilterIdx;

    /* filter enabled */
    if ((uint32)NUM0 < (uint32)CanEthConv_GstFilterCfg.usStreamIdFilterNum)
    {
        /* Scan the filter table */
        LucRetVal = E_NOT_OK;
        for (LulFilterIdx = IDX_0; LulFilterIdx<(uint32)CanEthConv_GstFilterCfg.usStreamIdFilterNum; LulFilterIdx++)
        {
            if ((aaStreamId[IDX_0] == CanEthConv_GstFilterCfg.aaStreamId[LulFilterIdx].aaStreamId[IDX_0])
            &&  (aaStreamId[IDX_1] == CanEthConv_GstFilterCfg.aaStreamId[LulFilterIdx].aaStreamId[IDX_1]))
            {
                /* found StreamID */
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* filter disabled */
        LucRetVal = E_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Do nothing */
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_FILTER);
        #endif
    }

    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_024]:[Gen5GW_CanEthConv_UD_13_024]
* Function Name: CanEthConv_SendEnable
* Description  : Cancel transmission suppression
* Arguments    : ucUnit -
*                    CAN Unit number
*                ucCh -
*                    CAN Channel number
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_SendEnable(const uint8 ucUnit, const uint8 ucCh)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((((uint32)ucUnit <= (uint32)CAN_UNIT_MAX)   && ((uint32)ucCh <= (uint32)CAN_CHANNEL_MAX))
    ||  (((uint32)ucUnit == (uint32)CANXL_UNIT_NUM) && ((uint32)ucCh <= (uint32)CANXL_CHANNEL_MAX)))
    {
        GulSendStatus |= (((uint32)NUM1 << (uint32)ucCh) << ((uint32)ucUnit * (uint32)NUM8));
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_SENDENABLE_SID,
                              CANETHCONV_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_025]:[Gen5GW_CanEthConv_UD_13_025]
* Function Name: CanEthConv_SendDisable
* Description  : Transmission suppression
* Arguments    : ucUnit -
*                    CAN Unit number
*                ucCh -
*                    CAN Channel number
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CanEthConv_SendDisable(const uint8 ucUnit, const uint8 ucCh)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((((uint32)ucUnit <= (uint32)CAN_UNIT_MAX)   && ((uint32)ucCh <= (uint32)CAN_CHANNEL_MAX))
    ||  (((uint32)ucUnit == (uint32)CANXL_UNIT_NUM) && ((uint32)ucCh <= (uint32)CANXL_CHANNEL_MAX)))
    {
        GulSendStatus = (uint32)GulSendStatus & ~(((uint32)NUM1 << (uint32)ucCh) << ((uint32)ucUnit * (uint32)NUM8));
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_SENDDISABLE_SID,
                              CANETHCONV_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_026]:[Gen5GW_CanEthConv_UD_13_026]
* Function Name: CanEthConv_GetSendStatus
* Description  : Get transmission suppression information.
* Arguments    : *pStatus -
*                    transmission suppression information
* Return Value : void
*******************************************************************************/
FUNC(void, CANETHCONV_PRIVATE_CODE) CanEthConv_GetSendStatus(uint32 *pStatus)
{
    *pStatus = GulSendStatus;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_028]:[Gen5GW_CanEthConv_UD_13_028]
* Function Name: SearchCanRoutTbl
* Description  : Search CANXL to Ethernet Routing Table.
* Arguments    : *pCanFrame -
*                    CANXL frame
*                *pUnit-
*                    Destination UNIT number
*                *pCh -
*                    Destination CHANNEL number
*                *pAddInfo -
*                    Additional Information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SearchCanRoutTblForCanXL(const R_CanEthConv_CanXLFrameType *pCanFrame, 
                                               uint8 *pUnit, uint8 *pCh, uint8 *pAddInfo)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulComparedCanId;
    uint32 LulEntryCanId;

    LucRetVal = E_NOT_OK;

    for (LulEntryIdx = IDX_0; LulEntryIdx < CanEthConv_GulCanRoutTblNum; LulEntryIdx++)
    {
        /* Apply CANXL ID Mask */
        LulComparedCanId = ((uint32)pCanFrame->pXLParams->usPriorityId | (uint32)CANXL_XLF_BIT) &
                            CanEthConv_GstCanRoutTbl[LulEntryIdx].ulCanIdMask;
        LulEntryCanId = CanEthConv_GstCanRoutTbl[LulEntryIdx].ulCanId &
                            CanEthConv_GstCanRoutTbl[LulEntryIdx].ulCanIdMask;

        if ((LulComparedCanId == LulEntryCanId)
        &&  (CanEthConv_GstCanRoutTbl[LulEntryIdx].ucUnit == CANXL_UNIT_NUM) 
        &&  (CanEthConv_GstCanRoutTbl[LulEntryIdx].ucCh   <= CANXL_CHANNEL_MAX))
        {
            /* Entry is match. End Search */
            LucRetVal = E_OK;
            break;
        }
        else
        {
            /* Entry is not match. Next Entry */
        }
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Copy Destination Unit and Channel */
        *pUnit    = CanEthConv_GstCanRoutTbl[LulEntryIdx].ucUnit;
        *pCh      = CanEthConv_GstCanRoutTbl[LulEntryIdx].ucCh;
        *pAddInfo = CanEthConv_GstCanRoutTbl[LulEntryIdx].ucAddInfo;
    }
    else
    {
        /* No Entry is matched */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_029]:[Gen5GW_CanEthConv_UD_13_029]
* Function Name: UnpackCanXL
* Description  : Unpack the CANXL frame from the payload section
* Arguments    : *pPayload -
*                    AVTP payload
*                ulPayloadLen -
*                    AVTP payload length
*                 *pDataPosition -
*                    UnPacking position in the payload
*                 *pCanFrame -
*                    Unpacked CANXL frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) UnpackCanXL(const uint8 *pPayload, const uint32 ulPayloadLen, 
    uint32 *pDataPosition, R_CanEthConv_CanXLFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;
    uint32 LulFramePos;
    uint16 LusCanId;
    uint32 LulDlc;
    R_CanEthConv_CanXLParamType LstCanXLPara;

    LucRetVal = E_OK;

    /* Unpack one CANXL frame from the payload */
    LulFramePos = *pDataPosition;
    if (ulPayloadLen >= (LulFramePos + (uint32)CAN_LEN_ID + (uint32)CAN_LEN_DLC))
    {
        /* Retrieve the CAN ID, DLC and CANXL Parameters */
        LulFramePos += sizeof(uint16);
        CanEthConv_UtilMemCpy(&LusCanId, &pPayload[LulFramePos], sizeof(LusCanId));
        LulFramePos += sizeof(LusCanId);
        CanEthConv_UtilMemCpy(&LulDlc, &pPayload[LulFramePos], sizeof(LulDlc));
        LulFramePos += (uint32)CAN_LEN_DLC;
        CanEthConv_UtilMemCpy(&LstCanXLPara.ucSduType, &pPayload[LulFramePos], sizeof(LstCanXLPara.ucSduType));
        LulFramePos += sizeof(LstCanXLPara.ucSduType);
        CanEthConv_UtilMemCpy(&LstCanXLPara.ucSec, &pPayload[LulFramePos], sizeof(LstCanXLPara.ucSec));
        LulFramePos += sizeof(LstCanXLPara.ucSec);
        CanEthConv_UtilMemCpy(&LstCanXLPara.usVcid, &pPayload[LulFramePos], sizeof(LstCanXLPara.usVcid));
        LulFramePos += sizeof(LstCanXLPara.usVcid);
        CanEthConv_UtilMemCpy(&LstCanXLPara.ulAcceptanceField,
                                                   &pPayload[LulFramePos], sizeof(LstCanXLPara.ulAcceptanceField));
        LulFramePos +=  sizeof(LstCanXLPara.ulAcceptanceField);

        /* Endian conversion : CAN ID , DLC , Virtual CAN ID, Acceptance Field */
        #if (CANETHCONV_LITTLE_ENDIAN == STD_ON)
        CanEthConv_UtilEndianConv16(&LusCanId);
        CanEthConv_UtilEndianConv32(&LulDlc);
        CanEthConv_UtilEndianConv16(&LstCanXLPara.usVcid);
        CanEthConv_UtilEndianConv32(&LstCanXLPara.ulAcceptanceField);
        #endif /* (CANETHCONV_LITTLE_ENDIAN == STD_ON) */

        if ((((uint32)CANXLFRAME_LEN_MIN <= LulDlc)
        &&   ((uint32)CANXLFRAME_LEN_MAX >= LulDlc))
        && ((LulFramePos + LulDlc) <= ulPayloadLen))
        {
            /* Copy CANXL data to Tx buffer */
            CanEthConv_UtilMemCpy(&CanEthConv_GaaCanTxBuf[IDX_0], &pPayload[LulFramePos], LulDlc);
            /* Set CAN frame data */
            pCanFrame->pXLParams->usPriorityId = LusCanId;
            pCanFrame->ulCanDlc = LulDlc;
            pCanFrame->pXLParams->ucSduType         = LstCanXLPara.ucSduType;
            pCanFrame->pXLParams->ucSec             = LstCanXLPara.ucSec;
            pCanFrame->pXLParams->usVcid            = LstCanXLPara.usVcid;
            pCanFrame->pXLParams->ulAcceptanceField = LstCanXLPara.ulAcceptanceField;
            pCanFrame->pCanData = &CanEthConv_GaaCanTxBuf[IDX_0];

            /* Return the next CAN frame position */
            *pDataPosition = LulFramePos + LulDlc;
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PACKEDCAN);
            #endif            
            /* Invald the CAN DLC */
            GucCheckError = CANETHCONV_E_PACKEDCAN;
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /*
         * No CAN frame if the data length from the unpacked position is
         * less than the size of the CAN ID and DLC.
         */
        GucCheckError = CANETHCONV_E_NOTFRAME;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_13_030]:[Gen5GW_CanEthConv_UD_13_030]
* Function Name: SendCanXLFrame
* Description  : Send CANXL frame
* Arguments    : *pCanFrame -
*                    CANXL frame data
*                *pSendStatus -
*                    can packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) SendCanXLFrame(const R_CanEthConv_CanXLFrameType *pCanFrame, 
    uint32 *pSendStatus)
{
    Std_ReturnType LucRetVal;
    uint8  LucUnit;
    uint8  LucChannel;
    uint8  LucAddInfo;
    uint32 LulSendStatusMask;

    /* Find the CAN frame destination in the CAN routing table. */
    LucRetVal = SearchCanRoutTblForCanXL(pCanFrame, &LucUnit, &LucChannel, &LucAddInfo);
    if ((uint8)E_OK == LucRetVal)
    {
        /* Check Can Packet Send Guard */
        LulSendStatusMask = (((uint32)NUM1 << (uint32)LucChannel) << ((uint32)LucUnit * (uint32)NUM8));
        if ((uint32)NUM0 != (GulSendStatus & LulSendStatusMask))
        {
            /* If the destination exists, send it with a user-defined function. */
            LucRetVal = CanEthConv_CanXLTransmitUserDef(pCanFrame, LucUnit, LucChannel, LucAddInfo);
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                *pSendStatus |= (((uint32)NUM1 << (uint32)LucChannel) << ((uint32)LucUnit * (uint32)NUM8));
                GucCheckError = CANETHCONV_E_TRANS;
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /*
         * If the destination is not found,
         * notify by the user-defined function of inter-core communication
         */
        LucRetVal = CanEthConv_CanXLNotifyUserDef(pCanFrame);
        if ((uint8)E_OK == LucRetVal)
        {
            /* Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_BSWNOTIFY);
            #endif
            GucCheckError = CANETHCONV_E_BSWNOTIFY;
            LucRetVal = E_NOT_OK;
        }
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
