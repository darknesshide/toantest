/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the Initialization function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanEthConv_common.h"
#include "CDD_CanEthConv_init.h"
#include "CDD_CanEthConv_CantoEth.h"
#include "CDD_CanEthConv_EthtoCan.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckBufAddr(const R_CanEthConv_BufCfgType *pBufCfg);

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

#define CANETHCONV_START_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_11_001]:[Gen5GW_CanEthConv_UD_11_001]
* Function Name: CanEthConv_Init
* Description  : Can-Ethernet Conversion SW Initialization.
* Arguments    : *pConfig -
*                    Initialization Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE)  CanEthConv_Init(const R_CanEthConv_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if (CANETHCONV_CHECK_CODE == pConfig->ulIntegrityCheck)
    {
        if ((NULL_PTR != pConfig->pEthRoutTbl)
        &&  (NULL_PTR != pConfig->pEthSrcCfg)
        &&  (NULL_PTR != pConfig->pCanRoutTbl)
        &&  (NULL_PTR != pConfig->pConvCfg)
        &&  (NULL_PTR != pConfig->pBufCfg))
        {
            /* NULL check is passed */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID,
                                  CANETHCONV_E_PARAM_CONFIG);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID, CANETHCONV_E_CFG);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CheckBufAddr(pConfig->pBufCfg);
    }
    else
    {
        /* Do nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CanEthConv_CantoEthInit(pConfig);
    }
    else
    {
        /* Do nothing */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CanEthConv_EthtoCanInit(pConfig);
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_11_002]:[Gen5GW_CanEthConv_UD_11_002]
* Function Name: CheckBufAddr
* Description  : Check Buffer Address and Size configuration.
* Arguments    : pBufCfg -
*                    Buffer Config
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANETHCONV_PRIVATE_CODE) CheckBufAddr(const R_CanEthConv_BufCfgType *pBufCfg)
{
    Std_ReturnType LucRetVal;
    const uint32 LulCanRxAddr = (uint32)pBufCfg->pCanRxAddr;
    const uint32 LulEthTxAddr = (uint32)pBufCfg->pEthTxAddr;
    const uint32 LulEthRxAddr = (uint32)pBufCfg->pEthRxAddr;
    const uint32 LulCanTxAddr = (uint32)pBufCfg->pCanTxAddr;

    LucRetVal = E_OK;

    /* Configuration Check for Buffer Address and Size are in LPDDR4 or RT-SRAM */
    if (((pBufCfg->ulCanRxBufSize >= (uint32)CANBUF_SIZE_MIN) &&
        (pBufCfg->ulCanRxBufSize <= (uint32)CANRXBUFF_SIZE_MAX)) &&
        (((LulCanRxAddr >= (uint32)LPDDR4_ADDR_START) &&
        (LulCanRxAddr < ((LPDDR4_ADDR_START + LPDDR4_SIZE) - pBufCfg->ulCanRxBufSize))) ||
        ((LulCanRxAddr >= (uint32)RT_SRAM_ADDR_START) &&
        (LulCanRxAddr < ((RT_SRAM_ADDR_START + RT_SRAM_SIZE) - pBufCfg->ulCanRxBufSize)))) &&
        ((pBufCfg->ulEthTxBufSize >= (uint32)ETHBUF_SIZE_MIN) &&
        (pBufCfg->ulEthTxBufSize <= ETH_FRAME_SIZE_MAX)) &&
        (((LulEthTxAddr >= (uint32)LPDDR4_ADDR_START) &&
        (LulEthTxAddr < ((LPDDR4_ADDR_START + LPDDR4_SIZE) - pBufCfg->ulEthTxBufSize))) ||
        ((LulEthTxAddr >= (uint32)RT_SRAM_ADDR_START) &&
        (LulEthTxAddr < ((RT_SRAM_ADDR_START + RT_SRAM_SIZE) - pBufCfg->ulEthTxBufSize)))) &&
        ((pBufCfg->ulEthRxBufSize >= (uint32)ETHBUF_SIZE_MIN) &&
        (pBufCfg->ulEthRxBufSize <= ETH_FRAME_SIZE_MAX)) &&
        (((LulEthRxAddr >= (uint32)LPDDR4_ADDR_START) &&
        (LulEthRxAddr < ((LPDDR4_ADDR_START + LPDDR4_SIZE) - pBufCfg->ulEthRxBufSize))) ||
        ((LulEthRxAddr >= (uint32)RT_SRAM_ADDR_START) &&
        (LulEthRxAddr < ((RT_SRAM_ADDR_START + RT_SRAM_SIZE) - pBufCfg->ulEthRxBufSize)))) &&
        ((uint32)CANRXBUFF_SIZE_MAX == pBufCfg->ulCanTxBufSize) &&
        (((LulCanTxAddr >= (uint32)LPDDR4_ADDR_START) &&
        (LulCanTxAddr < ((LPDDR4_ADDR_START + LPDDR4_SIZE) - CANBUF_SIZE_MIN))) ||
        ((LulCanTxAddr >= (uint32)RT_SRAM_ADDR_START) &&
        (LulCanTxAddr < ((RT_SRAM_ADDR_START + RT_SRAM_SIZE) - CANBUF_SIZE_MIN)))))
    {
        /* Configuration Check for Buffer Address and Size are not overlapping */
        if (((LulCanRxAddr >= (LulEthTxAddr + pBufCfg->ulEthTxBufSize)) ||
            ((LulCanRxAddr + pBufCfg->ulCanRxBufSize) <= LulEthTxAddr)) &&
            ((LulCanRxAddr >= (LulEthRxAddr + pBufCfg->ulEthRxBufSize)) ||
            ((LulCanRxAddr + pBufCfg->ulCanRxBufSize) <= LulEthRxAddr)) &&
            ((LulCanRxAddr >= (LulCanTxAddr + pBufCfg->ulCanTxBufSize)) ||
            ((LulCanRxAddr + pBufCfg->ulCanRxBufSize) <= LulCanTxAddr)) &&
            ((LulEthTxAddr >= (LulEthRxAddr + pBufCfg->ulEthRxBufSize)) ||
            ((LulEthTxAddr + pBufCfg->ulEthTxBufSize) <= LulEthRxAddr)) &&
            ((LulEthTxAddr >= (LulCanTxAddr + pBufCfg->ulCanTxBufSize)) ||
            ((LulEthTxAddr + pBufCfg->ulEthTxBufSize) <= LulCanTxAddr)) &&
            ((LulEthRxAddr >= (LulCanTxAddr + pBufCfg->ulCanTxBufSize)) ||
            ((LulEthRxAddr + pBufCfg->ulEthRxBufSize) <= LulCanTxAddr)))
        {
            if (pBufCfg->ulCanRxBufSize <= (pBufCfg->ulEthTxBufSize - (uint32)HEADER_MAX_ETH))
            {
                /* Do Nothing */
            }
            else
            {
                #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID,
                                      CANETHCONV_E_CFG_BUF);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID,
                                  CANETHCONV_E_CFG_BUF);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID,
                              CANETHCONV_E_CFG_BUF);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

#define CANETHCONV_STOP_SEC_PRIVATE_CODE
#include "CanEthConv_MemMap.h"

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
