/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.21.0
* Description  : This file contains the process used in the API function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanEthConv_common.h"
#include "CDD_CanEthConv_api.h"
#include "CDD_CanEthConv_init.h"
#include "CDD_CanEthConv_CantoEth.h"
#include "CDD_CanEthConv_EthtoCan.h"
/* Including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define CANETHCONV_STS_UNINIT   0U
#define CANETHCONV_STS_INIT     1U

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define CANETHCONV_START_SEC_VAR_INIT_8
#include "CanEthConv_MemMap.h" 

VAR(uint8, CANETHCONV_VAR_INIT)  CanEthConv_GucInitStatus = CANETHCONV_STS_UNINIT;

#define CANETHCONV_STOP_SEC_VAR_INIT_8
#include "CanEthConv_MemMap.h" 

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANETHCONV_START_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h" 
/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_001]:[Gen5GW_CanEthConv_UD_10_001]
* Function Name: R_CanEthConv_Init
* Description  : Can-Ethernet Conversion SW Initialization API.
* Arguments    : pConfig -
*                    Initialization Configuration.
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_Init(const R_CanEthConv_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)CANETHCONV_STS_UNINIT == (uint32)CanEthConv_GucInitStatus)
    {
        if (NULL_PTR != pConfig)
        {
            /* Do nothing */
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_INIT_SID,
                              CANETHCONV_E_ALREADY_INITIALIZED);
        #endif         
        /* Already initialized */
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CanEthConv_Init(pConfig);
        if ((uint8)E_OK == LucRetVal)
        {
            CanEthConv_GucInitStatus = CANETHCONV_STS_INIT;
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_002]:[Gen5GW_CanEthConv_UD_10_002]
* Function Name: R_CanEthConv_CantoEth
* Description  : Can to Ethernet Conversion Function API
* Arguments    : *pCanFrame -
*                    CAN frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_CantoEth(const R_CanEthConv_CanFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        if (NULL_PTR != pCanFrame)
        {
            LucRetVal = CanEthConv_CantoEth(pCanFrame);
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANTOETH_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_004]:[Gen5GW_CanEthConv_UD_10_004]
* Function Name: R_CanEthConv_MainFunction
* Description  : Main Function for polling API
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, CANETHCONV_PUBLIC_CODE) R_CanEthConv_MainFunction(void)
{
    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        CanEthConv_CantoEthMain();
    }
    else
    {
        /* Do Nothing */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_003]:[Gen5GW_CanEthConv_UD_10_003]
* Function Name: R_CanEthConv_EthtoCan
* Description  : Ethernet to CAN Conversion Function
* Arguments    : usFrameType -
*                    Ethernet frame type
*                *aaSrcMacAddr -
*                    Ethernet source MacAddress
*                *pEthFrame -
*                    EThernet frame
*                ulFrameLen -
*                    Etherenet frame length
*                *pSendStatus -
*                    can packet send status
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_EthtoCan(const uint16 usFrameType, const uint8 *aaSrcMacAddr,
                             const uint8 *pEthFrame, const uint32 ulFrameLen, uint32 *pSendStatus)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        if ((NULL_PTR != pEthFrame) && (NULL_PTR != aaSrcMacAddr) && (NULL_PTR != pSendStatus))
        {
            LucRetVal = CanEthConv_EthtoCan(usFrameType, aaSrcMacAddr, pEthFrame, ulFrameLen, pSendStatus);
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_ETHTOCAN_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_005]:[Gen5GW_CanEthConv_UD_10_005]
* Function Name: R_CanEthConv_SendEnable
* Description  : Cancel transmission suppression
* Arguments    : ucUnit -
*                    CAN Unit number
*                ucCh -
*                    CAN Channel number
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_SendEnable(const uint8 ucUnit, const uint8 ucCh)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        LucRetVal = CanEthConv_SendEnable(ucUnit, ucCh);
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_SENDENABLE_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_006]:[Gen5GW_CanEthConv_UD_10_006]
* Function Name:R_CanEthConv_SendDisable
* Description  : Transmission suppression
* Arguments    : ucUnit -
*                    CAN Unit number
*                ucCh -
*                    CAN Channel number
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_SendDisable(const uint8 ucUnit, const uint8 ucCh)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        LucRetVal = CanEthConv_SendDisable(ucUnit, ucCh);
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_SENDDISABLE_SID,
                              CANETHCONV_E_UNINIT);
        #endif         
        /* already initialized */
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_007]:[Gen5GW_CanEthConv_UD_10_007]
* Function Name: R_CanEthConv_GetSendStatus
* Description  : Get transmission suppression information.
* Arguments    : *pStatus -
*                    transmission suppression information
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_GetSendStatus(uint32 *pStatus)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        if (NULL_PTR != pStatus)
        {
            CanEthConv_GetSendStatus(pStatus);
            LucRetVal = E_OK;
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_GETSENDSTATUS_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_GETSENDSTATUS_SID,
                              CANETHCONV_E_UNINIT);
        #endif         
        /* Already initialized */
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanEthConv_CD_10_008]:[Gen5GW_CanEthConv_UD_10_008]
* Function Name: R_CanEthConv_CanXLtoEth
* Description  : Can to Ethernet Conversion Function API
* Arguments    : *pCanFrame -
*                    CANXL frame
* Return Value : E_OK -
*                    Successful Completion
*                E_NOT_OK -
*                    Not Successful Completion (Error)
*******************************************************************************/
FUNC(Std_ReturnType, CANETHCONV_PUBLIC_CODE) R_CanEthConv_CanXLtoEth(const R_CanEthConv_CanXLFrameType *pCanFrame)
{
    Std_ReturnType LucRetVal;

    /* Initialization check */
    if ((uint32)CANETHCONV_STS_INIT == (uint32)CanEthConv_GucInitStatus)
    {
        if (NULL_PTR != pCanFrame)
        {
            LucRetVal = CanEthConv_CanXLtoEth(pCanFrame);
        }
        else
        {
            #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                                  CANETHCONV_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANETHCONV_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANETHCONV_MODULE_ID, CANETHCONV_INSTANCE_ID, R_CANETHCONV_CANXLTOETH_SID,
                              CANETHCONV_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}
#define CANETHCONV_STOP_SEC_PUBLIC_CODE
#include "CanEthConv_MemMap.h"
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
