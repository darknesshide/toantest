/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Ram.h                                                                                           */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Ethernet driver global variables and the                                                        */
/* Ram Allocation functions                                                                                           */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.4.1: 24/04/2026    : Support Multicore for X5H
 * 1.4.0: 31/03/2026    : Update to add new pointer Eth_GpCoreId2Index and modify type of Eth_CtrlConfigIdx.
 * 1.1.1: 16/09/2025    : Update to support TSN-ES
 * 1.1.0: 25/07/2025    : Update to use macro constant instead of hard code.
 * 1.0.2: 25/06/2025    : Correct memmap mapping for Eth_GaaTimeTuple.
 * 1.0.1: 17/03/2025    : Update to merging SingleMainline
 *                        + Update Eth_CtrlConfigIdx, Eth_GaaHwFunc from SEC_VAR_INIT_UNSPECIFIED to
 *                        SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
 *                        + Update Eth_GaaHwFunc change from P2CONST to CONSTP2CONST
 * 1.0.0: 28/09/2024    : Add new global variables Eth_Ctrl1_TxBufferData, Eth_Ctrl1_RxBufferData,
 *                        Eth_Ctrl1_TxBufferNode, Eth_Ctrl1_RxBufferNode.
 *                        Remove Eth_GaaHeap since it is no longer used.
 *                        Change variable name
 *                        from Eth_GbDemEventAccess to Eth_GpDemEventAccess,
 *                        from Eth_GbDemEventRxFramesLost to Eth_GpDemEventRxFramesLost,
 *                        from Eth_GbDemEventCRC to Eth_GpDemEventCRC,
 *                        from Eth_GbDemEventUnderSizeFrame to Eth_GpDemEventUnderSizeFrame,
 *                        from Eth_GbDemEventOverSizeFrame to Eth_GpDemEventOverSizeFrame,
 *                        from Eth_GbDemEventAlignment to Eth_GpDemEventAlignment,
 *                        from Eth_GbDemEventSinglecollision to Eth_GpDemEventSinglecollision,
 *                        from Eth_GbDemEventMultiplecollision to Eth_GpDemEventMultiplecollision,
 *                        from Eth_GbDemEventLatecollision to Eth_GpDemEventLatecollision.
 *                        from Eth_GbDemEventDmaError to Eth_GpDemEventDmaError.
 *                        from Eth_GbDemEventEccError to Eth_GpDemEventEccError.
 *                        from Eth_GbDemEventTimerincFailed to Eth_GpDemEventTimerincFailed.
 *                        from Eth_GbDemEventTimeroffset to Eth_GpDemEventTimeroffset.
 *                        from Eth_GbDemEventRegisterCorruption to Eth_GpDemEventRegisterCorruption.
 *        29/08/2024    : Add new global variables Eth_Ctrl0_TxBufferData, Eth_Ctrl0_RxBufferData,
 *                        Eth_Ctrl0_TxBufferNode, Eth_Ctrl0_RxBufferNode, Eth_GaaTxBufferDataTable,
 *                        Eth_GaaRxBufferDataTable, Eth_GaaTxBufferNodes, Eth_GaaTxBufferNodes to support static memory.
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3684)    : Array declared with unknown size.                                                            */
/* Rule                : CERTCCM ARR02,  MISRA C:2012 Rule-8.11                                                       */
/* JV-01 Justification : Arrays used are verified in the file which are only declarations and size is configuration   */
/*                       dependent.                                                                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/
#ifndef ETH_RAM_H
#define ETH_RAM_H
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for utility definitions */
#include "Eth_Common_LLDriver.h"

/* Included for Type definitions */
#include "Eth_Types.h"

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RAM_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_RAM_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_RAM_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_RAM_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_RAM_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION
/***********************************************************************************************************************
**                                              MISRA C Rule Violations                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    QAC Warning                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#if (ETH_MULTI_CORE_SUPPORT == STD_ON)
#define ETH_START_SEC_CONST_8
#include "Eth_MemMap.h"
/* Global pointer to point to the core index table */
extern P2CONST(uint8, ETH_VAR_INIT, ETH_CONFIG_CONST) Eth_GpCoreId2Index;                                               /* PRQA S 3432 # JV-01 */
#define ETH_STOP_SEC_CONST_8
#include "Eth_MemMap.h"
#endif

/***********************************************************************************************************************
** Transmit/Receieve buffer node                                                                                      **
** Array to store Buffer information of all buffer of each queue on a controller                                      **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"


#define ETH_START_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"
extern VAR(Eth_RxFrameType, ETH_VAR_NO_INIT) Eth_GaaRxFrame[ETH_TOTAL_CTRL_CONFIG];

extern VAR(uint32, ETH_VAR_NO_INIT) Eth_CtrlConfigIdx[ETH_TOTAL_CORE_CONFIG][ETH_MAX_CTRL_CONFIG_PER_CORE];
#define ETH_STOP_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

/* Global variable to store pointer to Configuration */
extern P2CONST(Eth_CtrlConfigType, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpCtrlConfigPtr;                           /* PRQA S 3432 # JV-01 */

extern P2CONST(Eth_EthConfigType, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpEthConfigPtr;                             /* PRQA S 3432 # JV-01 */

extern P2CONST(uint32, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpTotalCtrlConfig;                                     /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventAccess;                                               /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventRxFramesLost;                                         /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventCRC;                                                  /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventUnderSizeFrame;                                       /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventOverSizeFrame;                                        /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventAlignment;                                            /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventSinglecollision;                                      /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventMultiplecollision;                                    /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventLatecollision;                                        /* PRQA S 3432 # JV-01 */

#if ( ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventIntInconsistent;
#endif

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventUnintendedIntChk;                                     /* PRQA S 3432 # JV-01 */
#endif

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventDmaError;                                             /* PRQA S 3432 # JV-01 */

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventEccError;                                             /* PRQA S 3432 # JV-01 */

#if (ETH_MACRO_ETNB == STD_ON || ETH_MACRO_ETNF ==STD_ON)
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventTimerincFailed;

extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventTimeroffsetFailed;
#endif
#if ((ETH_REGISTER_CHECK_INITTIME == STD_ON) || (ETH_REGISTER_CHECK_RUNTIME == STD_ON))
extern P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventRegisterCorruption;
#endif
#endif

#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

extern VAR(Eth_MacAddressType, ETH_VAR_NO_INIT) Eth_GaaAddressFilters[ETH_TOTAL_CTRL_CONFIG][ETH_MAX_FILTERS];

extern VAR(Eth_ControllerStatusType, ETH_VAR_NO_INIT) Eth_GaaCtrlStat[ETH_TOTAL_CTRL_CONFIG];

#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"
#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_CONST_32
#include "Eth_MemMap.h"
extern CONST(uint32, ETH_VAR_INIT) Eth_CtrlTxMaxFrameLengthMapping[ETH_TOTAL_CTRL_CONFIG];
extern CONST(uint32, ETH_VAR_INIT) Eth_CtrlRxMaxFrameLengthMapping[ETH_TOTAL_CTRL_CONFIG];
#define ETH_STOP_SEC_CONST_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

/* Tx Buffer Node of Controller */
extern P2VAR(Eth_BufHandlerType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxBufferNodes[ETH_TOTAL_CTRL_CONFIG];              /* PRQA S 3432 # JV-01 */

/* Rx Buffer Node of Controller */
extern P2VAR(Eth_RxBufManageType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxBufferNodes[ETH_TOTAL_CTRL_CONFIG];             /* PRQA S 3432 # JV-01 */

/* Tx Buffer Data of Controller */
extern P2VAR(uint8, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxBufferDataTable[ETH_TOTAL_CTRL_CONFIG];                       /* PRQA S 3432 # JV-01 */

/* Rx Buffer Data */
extern P2VAR(uint8, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxBufferDataTable[ETH_TOTAL_CTRL_CONFIG];                       /* PRQA S 3432 # JV-01 */

extern P2VAR(Eth_TxBufferType, AUTOMATIC, ETH_VAR_INIT_PTR) Eth_GaaTxBufferMgrTable[ETH_TOTAL_CTRL_CONFIG];             /* PRQA S 3432 # JV-01 */

/* Array of timetupple to store timestamp info */
extern P2VAR(TimeTupleType, AUTOMATIC, ETH_VAR_INIT_PTR) Eth_GaaTimeTuple[ETH_TOTAL_CTRL_CONFIG];                       /* PRQA S 3432 # JV-01 */

extern P2VAR(Eth_StateType, ETH_VAR_INIT, ETH_VAR_INIT) Eth_GpDriverState;                                              /* PRQA S 3432 # JV-01 */

#if(ETH_DEVICE_NAME == ETH_U5X)
/* Array to store the rx buffer warning level info */
extern P2VAR(uint32, AUTOMATIC, ETH_VAR_INIT_PTR) Eth_GaaRxBufferWarnLvlStat[ETH_TOTAL_CTRL_CONFIG];                    /* PRQA S 3432 # JV-01 */
#endif

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"
extern CONST(uint32, ETH_CONFIG_DATA) Eth_GaaTxBufferTotal[ETH_TOTAL_CTRL_CONFIG];
extern CONST(uint32, ETH_CONFIG_DATA) Eth_GaaRxBufferTotal[ETH_TOTAL_CTRL_CONFIG];
/* Function pointer variable for ETN# configuration */
extern CONSTP2CONST(Eth_HwFuncTableType, ETH_VAR_INIT, ETH_CONFIG_DATA) Eth_GaaHwFunc[];                                /* PRQA S 3684 # JV-01 */
#define ETH_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

/***********************************************************************************************************************
**                                                   Macro Defines                                                    **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
#endif /* ETH_ETNF_RAM_H  */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
