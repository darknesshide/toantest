/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth.h                                                                                               */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains macros, ETH type definitions, structure data types and API function prototypes of ETH Driver    */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.3.3: 01/07/2026    : Update to add new API Eth_GetAndResetMeasurementData.
 * 1.3.2: 04/02/2026    : Update SW-VERSION to 1.1.31 for X5H.
 * 1.3.1: 05/03/2026    : Update SW-VERSION to 1.1.30 for X5H.
 * 1.3.0: 20/01/2026    : Update SW-VERSION to 1.3.0 for U5x.
 * 1.2.2: 30/12/2025    : Update to fix for Misra C msg 1753.
 * 1.2.1: 24/11/2025    : Update SW-VERSION to 1.1.29 for X5H.
 * 1.2.0: 24/10/2025    : Update SW-VERSION to 1.2.0 for U5x.
 * 1.1.2: 24/10/2025    : Update SW-VERSION to 1.1.28 for X5H.
 * 1.1.1: 09/10/2025    : Update SW-VERSION to 1.1.1 for U5x.
 *        02/10/2025    : Update SW-VERSION to 1.1.27 for X5H.
 * 1.1.0: 19/08/2025    : Update SW-VERSION to 1.1.0 for U5x.
 *        25/07/2025    : Remove prototype of Eth_GetDropCount, Eth_GetEtherStats API and macro for old AUTOSAR version.
 *                        Add new macro to define constant value.
 * 1.0.6: 21/07/2025    : Update SW-VERSION
 * 1.0.5: 04/07/2025    : Update SW-VERSION
 * 1.0.4: 25/06/2025    : Remove dupplicated macro ETH_E_EGRESS_QUEUE_OCCUPIED.
 * 1.0.3: 12/05/2025    : Update SW-VERSION
 * 1.0.2: 12/05/2025    : Update to seperate SW-VERSION base on hardwrae device
 * 1.0.1: 24/04/2025    : Update to remove macro ETH_UPDATE_PHYS_ADDR_FILTER
 * 1.0.0: 29/08/2024    : Add new API Eth_ImmediateTransmit, Eth_ReleaseRxBuffer to support R23-11.
 *        16/07/2024    : Add new API Eth_GetCurrentTimeTuple, global variable Eth_GaaTimeTuple to support R23-11.
 *        09/04/2024    : Initial Version.
 */
/**********************************************************************************************************************/

#ifndef ETH_H
#define ETH_H

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (7:0791)    : Macro identifier does not differ from other macro identifier(s) (e.g. '%1s') within the      */
/*                       specified number of significant characters.                                                  */
/* Rule                : CERTCCM DCL23, MISRA C:2012 Rule-5.4                                                         */
/*                       REFERENCE - ISO:C90-6.1.2 Identifiers - Implementation Limits                                */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule (Symbolic Name or Published         */
/*                       Macro's name), so this is accepted.                                                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions and do not conflict in linkage.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3684)    : Array declared with unknown size.                                                            */
/* Rule                : CERTCCM ARR02,  MISRA C:2012 Rule-8.11                                                       */
/* JV-01 Justification : Arrays used are verified in the file which are only declarations and size is configuration   */
/*                       dependent.                                                                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/


/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/

#include "Eth_Types.h"
#include "Eth_Common_LLDriver.h"
#include "Dem.h"
#include "ComStack_Types.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* Module identifications */
#define ETH_VENDOR_ID              (uint8)ETH_VENDOR_ID_VALUE
#define ETH_MODULE_ID              (uint16)ETH_MODULE_ID_VALUE
#define ETH_INSTANCE_ID            (uint8)ETH_INSTANCE_ID_VALUE

/* AUTOSAR release version information */
#define ETH_AR_RELEASE_MAJOR_VERSION    4U                                                                              /* PRQA S 0791 # JV-01 */
#define ETH_AR_RELEASE_MINOR_VERSION    9U                                                                              /* PRQA S 0791 # JV-01 */
#define ETH_AR_RELEASE_REVISION_VERSION 0U                                                                              /* PRQA S 0791 # JV-01 */

#if (ETH_DEVICE_NAME == ETH_X5X)
/* Module Software version information */
#define ETH_SW_MAJOR_VERSION            1U                                                                              /* PRQA S 0791 # JV-01 */
#define ETH_SW_MINOR_VERSION            1U                                                                              /* PRQA S 0791 # JV-01 */
#define ETH_SW_PATCH_VERSION            31U                                                                             /* PRQA S 0791 # JV-01 */
#elif (ETH_DEVICE_NAME == ETH_U5X)
/* Module Software version information */
#define ETH_SW_MAJOR_VERSION            1U                                                                              /* PRQA S 0791 # JV-01 */
#define ETH_SW_MINOR_VERSION            4U                                                                              /* PRQA S 0791 # JV-01 */
#define ETH_SW_PATCH_VERSION            0U                                                                              /* PRQA S 0791 # JV-01 */
#endif
/***********************************************************************************************************************
**                                               API Service Id Macros                                                **
***********************************************************************************************************************/
/* Service Id of Eth_Init */
#define ETH_INIT_SID                    (uint8)0x01U
/* Service Id of Eth_SetControllerMode */
#define ETH_SETCONTROLLERMODE_SID       (uint8)0x03U
/* Service Id of Eth_GetControllerMode */
#define ETH_GETCONTROLLERMODE_SID       (uint8)0x04U
/* Service Id of Eth_WriteMii */
#define ETH_WRITEMII_SID                (uint8)0x05U
/* Service Id of Eth_ReadMii */
#define ETH_READMII_SID                 (uint8)0x06U
/* Service Id of Eth_GetPhysAddr */
#define ETH_GETPHYSADDR_SID             (uint8)0x08U
/* Service Id of Eth_ProvideTxBuffer */
#define ETH_PROVIDETXBUFFER_SID         (uint8)0x09U
/* Service Id of Eth_Transmit */
#define ETH_TRANSMIT_SID                (uint8)0x0AU
/* Service Id of Eth_Receive */
#define ETH_RECEIVE_SID                 (uint8)0x0BU
/* Service Id of Eth_TxConfirmation */
#define ETH_TXCONFIRMATION_SID          (uint8)0x0CU
/* Service Id of Eth_GetVersionInfo */
#define ETH_GET_VERSION_INFO_SID        (uint8)0x0DU
/* Service Id of Eth_UpdatePhysAddrFilter */
#define ETH_UPDATEPHYSADDRFILTER_SID    (uint8)0x12U
/* Service Id of Eth_SetPhysAddr */
#define ETH_SETPHYSADDR_SID             (uint8)0x13U
/* Service Id of Eth_GetCounterValues */
#define ETH_GETCOUNTERVALUES_SID        (uint8)0x14U
/* Service Id of Eth_GetRxStats */
#define ETH_GETRXSTATS_SID              (uint8)0x15U
/* Service Id of Eth_GetTxStats */
#define ETH_GETTXSTATS_SID              (uint8)0x1CU
/* Service Id of Eth_GetTxErrorCounterValues */
#define ETH_GETTXERRORCOUNTERVALUES_SID (uint8)0x1DU
/* Service Id of Eth_GetSpiStatus */
#define ETH_GETSPISTATUS_SID            (uint8)0x1EU
/* Service Id of Eth_ImmediateTransmit */
#define ETH_IMMEDIATETRANSMIT_SID       (uint8)0x26U
/* Service Id of Eth_ReleaseRxBuffer */
#define ETH_RELEASERXBUFFER_SID         (uint8)0x22U
/* Service Id of Eth_InitSerdes */
#define ETH_INITSERDES_SID              (uint8)0xA6U
/* Service Id of Eth_UpdateStreamFilter */
#define ETH_UPDATESTREAMFILTER_SID      (uint8)0xA0U
/* Service Id of Eth_MainFunction  */
#define ETH_MAINFUNCTION_SID            (uint8)0x20U
/* Service Id of Eth_SetStatus  */
#define ETH_SETSTATUS_SID               (uint8)0xFFU
#if (ETH_DEINIT_API == STD_ON)
/* Service Id of Eth_DeInit */
#define ETH_DEINIT_SID                  (uint8)0xA3U
#endif

#if(ETH_DEVICE_NAME == ETH_U5X)
/* Service Id of Eth_GetAndResetMeasurementData */
#define ETH_GETANDRESETMEASUREMENTDATA_API (uint8)0xA4U
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

/*********gPTP TimeStamp Apis *****************/
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/* Service Id of Eth_GetCurrentTime */
#define ETH_GETCURRENTTIME_SID          (uint8)0x16U
/* Service Id of Eth_GetCurrentTimeTuple */
#define ETH_GETCURRENTTIMETUPLE_SID     (uint8)0x21U
/* Service Id of Eth_EnableEgressTimeStamp  */
#define ETH_ENEGRESSTS_SID              (uint8)0x17U
/* Service Id of Eth_GetEgressTimeStamp  */
#define ETH_GETEGRESSTS_SID             (uint8)0x18U
/* Service Id of Eth_GetIngressTimeStamp  */
#define ETH_GETINGRESSTS_SID            (uint8)0x19U
/* Service Id of Eth_SetIncrementTimeForGptp */
#define ETH_SETINCREMENTTIMEFORGPTP_SID (uint8)0xA1U
/* Service Id of Eth_SetOffsetTimeForGptp */
#define ETH_SETOFFSETTIMEFORGPTP_SID    (uint8)0xA2U
#endif

/***********************************************************************************************************************
**                                                  DET Error Codes                                                   **
***********************************************************************************************************************/
/* Invalid controller index */
#define ETH_E_INV_CTRL_IDX              (uint8)0x01U

/* Eth module or controller was not initialized */
#define ETH_E_UNINIT                    (uint8)0x02U

/* Invalid pointer in parameter list. */
#define ETH_E_PARAM_POINTER             (uint8)0x03U

/* A wrong parameter passed to the APIs */
#define ETH_E_INV_PARAM                 (uint8)0x04U

/* Invalid mode */
#define ETH_E_INV_MODE                  (uint8)0x05U

/* Invalid clock unit index */
#define ETH_E_INV_CLKUNIT_IDX                  (uint8)0x06U

/*Clock adjustment in absolut value or rate/offset correction failed*/
#define ETH_E_CLOCK_ADJUSTMENT_FAILED                  (uint8)0x07U

/* No egress queue for requested priority available */
#define ETH_E_UNKNOWN_EGRESS_PRIORITY                  (uint8)0x08U

/* The size of the Ethernet frame exceed the available egress queue element size */
#define ETH_E_EXCEED_EGRESS_QUEUE_ELEMENT                  (uint8)0x09U

/* A requested hardware supported data transfer was rejected by hardware */
#define ETH_E_HW_SUPPORTED_DATA_TRANSFER_REJECTED                  (uint8)0x0AU

/* A rx handle id is not associated with an ingress queue element. */
#define ETH_E_RX_HANDLE_ID_NOT_ASSOCIATED                  (uint8)0x0BU

/* A received Ethernet frame could not be enqueued in any ingress queue */
#define ETH_E_NO_MATCHING_INGRESS_QUEUE_IDENTIFIED                  (uint8)0x0CU

#define ETH_E_UNKNOWN_PRIORITY_TX_FAILED                    (uint8)0x0DU

/*All egress queue elements are occupied*/
#define ETH_E_EGRESS_QUEUE_OCCUPIED                  (uint8)0x01U

/*All ingress queues elements are occupied */
#define ETH_E_INRESS_QUEUE_OCCUPIED                  (uint8)0x02U

/* Failure or incorrect communication with the Ethernet Controller */
#define ETH_E_COMMUNICATION             (uint8)0x06U

/* When valid Database is not available */
#define ETH_E_INVALID_DATABASE          (uint8)0xEFU

#define ETH_E_INVALID_CTRL_IDX             (uint8)0x0EU
/* DET Error - Call in invalid core */
#if (ETH_MULTI_CORE_SUPPORT == STD_ON)
#define ETH_E_INVALID_CORE              (uint8)0xF1U
#endif /* #if (ETH_MULTI_CORE_SUPPORT == STD_ON) */
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
/* Constant definition */
#define ETH_ZERO                        (uint8)0U
#define ETH_ONE                         (uint8)1U
#define ETH_TWO                         (uint8)2U
#define ETH_THREE                       (uint8)3U
#define ETH_FOUR                        (uint8)4U
#define ETH_FIVE                        (uint8)5U
#define ETH_SIX                         (uint8)6U
#define ETH_SEVEN                       (uint8)7U
#define ETH_EIGHT                       (uint8)8U
#define ETH_NINE                        (uint8)9U
#define ETH_TEN                         (uint8)10U
#define ETH_ELEVENT                     (uint8)11U
#define ETH_TWELVE                      (uint8)12U
#define ETH_THIRTEEN                    (uint8)13U
#define ETH_FOURTEEN                    (uint8)14U
#define ETH_FIFTEEN                     (uint8)15U
#define ETH_SIXTEEN                     (uint8)16U
#define ETH_NINETEEN                    (uint8)19U
#define ETH_TWENTLY                     (uint8)20U
#define ETH_TWENTLY_FOUR                (uint8)24U
#define ETH_TWENTLY_EIGHT               (uint8)28U

#define ETH_LENGTH_64B                  64U
#define ETH_LENGTH_127B                 127U
#define ETH_LENGTH_255B                 255U
#define ETH_LENGTH_511B                 511U
#define ETH_LENGTH_1023B                1023U

#define ETH_BUFFER_NUM_ZERO             0U

#define ETH_CORE_NUM_TWO                2U
#define ETH_CORE_NUM_THREE              3U
#define ETH_CORE_NUM_FOUR               4U

#define ETH_CTRL_NUM_ONE                1U
#define ETH_CTRL_NUM_TWO                2U

/* INVALID_CORE constant */
#if (ETH_MULTI_CORE_SUPPORT == STD_ON)
#define ETH_INVALID_CORE                (uint8)0xFFU
#endif /* #if (ETH_MULTI_CORE_SUPPORT == STD_ON) */

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/

#define ETH_START_SEC_PUBLIC_CODE
#include "Eth_MemMap.h"

extern FUNC(void, ETH_PUBLIC_CODE) Eth_Init(P2CONST(Eth_ConfigType, AUTOMATIC, ETH_APPL_CONST) CfgPtr);                 /* PRQA S 3432 # JV-01 */

#if (ETH_DEINIT_API == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_DeInit(CONST(boolean, AUTOMATIC) ForceReset);
#endif
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_SetControllerMode(uint8 CtrlIdx, Eth_ModeType CtrlMode);

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetControllerMode(uint8 CtrlIdx,
                        P2VAR(Eth_ModeType, AUTOMATIC, ETH_APPL_DATA) CtrlModePtr);                                     /* PRQA S 3432 # JV-01 */

extern FUNC(void, ETH_PUBLIC_CODE) Eth_GetPhysAddr(uint8 CtrlIdx, P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr);  /* PRQA S 3432 # JV-01 */

extern FUNC(void, ETH_PUBLIC_CODE) Eth_SetPhysAddr(uint8 CtrlIdx, P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr);/* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_UpdatePhysAddrFilter(uint8 CtrlIdx,                                    /* PRQA S 1710 # JV-01 */
                        P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr, Eth_FilterActionType Action);             /* PRQA S 3432 # JV-01 */

#if (ETH_CTRL_ENABLE_MII == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_WriteMii(uint8 CtrlIdx, uint8 TrcvIdx, uint8 RegIdx, uint16 RegVal);

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_ReadMii(uint8 CtrlIdx,
                        uint8 TrcvIdx, uint8 RegIdx, P2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) RegValPtr);                /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetCounterValues(uint8 CtrlIdx,
                        P2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) CounterPtr);                                   /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_RX_STATS_API == STD_ON)
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetRxStats(uint8 CtrlIdx,
                        P2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) RxStats);                                      /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_TX_STATS_API == STD_ON)
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetTxStats(uint8 CtrlIdx,
                        P2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) TxStats);                                      /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetTxErrorCounterValues(uint8 CtrlIdx,
                        P2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) TxErrorCounterValues);            /* PRQA S 3432 # JV-01 */
#endif

extern FUNC(BufReq_ReturnType, ETH_PUBLIC_CODE) Eth_ProvideTxBuffer(uint8 CtrlIdx,
                        uint8 Priority,
                        P2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) BufIdxPtr,                                      /* PRQA S 3432 # JV-01 */
                        P2VAR(P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA), AUTOMATIC, ETH_APPL_DATA) BufPtr,                 /* PRQA S 3432 # JV-01 */
                        P2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr);                                            /* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_Transmit(uint8 CtrlIdx,
                        Eth_BufIdxType BufIdx, Eth_FrameType FrameType, boolean TxConfirmation,
                        uint16 LenByte, P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr);                          /* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_ImmediateTransmit(
  uint8 CtrlIdx, Eth_BufIdxType TxHandleId, uint8 Priority,
  ListElemStructType* HeaderListPtr,
  uint8* PayloadPtr, uint16 PayloadLength);

extern FUNC(void, ETH_PUBLIC_CODE) Eth_ReleaseRxBuffer(CONST(uint8, AUTOMATIC) CtrlIdx, Eth_BufIdxType RxHandleId);

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetCurrentTimeTuple(uint8 CtrlIdx,
                        uint8 ClkUnitIdx, P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) currentTimeTuplePtr);          /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
extern FUNC(void, ETH_PUBLIC_CODE) Eth_Receive(uint8 CtrlIdx,
  uint8 QueueIdx,
  P2VAR(Eth_RxStatusType, AUTOMATIC, ETH_APPL_DATA) RxStatusPtr);                                                       /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_CTRL_ENABLE_TX_POLLING == STD_ON)
extern FUNC(void, ETH_PUBLIC_CODE) Eth_TxConfirmation(uint8 CtrlIdx);
#endif

#if (ETH_VERSION_INFO_API == STD_ON)
extern FUNC(void, ETH_PUBLIC_CODE) Eth_GetVersionInfo(
                        P2VAR(Std_VersionInfoType, AUTOMATIC, ETH_APPL_DATA) VersionInfoPtr);                           /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetCurrentTime(uint8 CtrlIdx,
                        P2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) timeQualPtr,                                 /* PRQA S 3432 # JV-01 */
                        P2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) timeStampPtr);                                   /* PRQA S 3432 # JV-01 */

extern FUNC(void, ETH_PUBLIC_CODE) Eth_EnableEgressTimeStamp(uint8 CtrlIdx, Eth_BufIdxType BufIdx);

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetEgressTimeStamp(uint8 CtrlIdx, Eth_BufIdxType BufIdx,
  P2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) timeQualPtr,                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) timeStampPtr);                                                         /* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetIngressTimeStamp(uint8 CtrlIdx,
  P2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) DataPtr,                                                              /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) timeQualPtr,                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) timeStampPtr);                                                         /* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_SetIncrementTimeForGptp(CONST(uint8, AUTOMATIC) CtrlIdx,
                        CONST(uint32, AUTOMATIC) IncVal);

extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_SetOffsetTimeForGptp(CONST(uint8, AUTOMATIC) CtrlIdx,
                        CONSTP2CONST(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) pTimeOffsetPtr);
#endif

#if (ETH_STREAM_FILTERING == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_UpdateStreamFilter(CONST(uint8, AUTOMATIC) CtrlIdx,
                        CONST(uint8, AUTOMATIC) QueIdx, CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) StreamIdPtr);
#endif

#if (ETH_CTRL_ENABLE_SPI_INTERFACE_API == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetSpiStatus(CONST(uint8, AUTOMATIC) CtrlIdx,
                        P2VAR(Eth_SpiStatusType, AUTOMATIC, ETH_APPL_DATA) SpiStatusType);
#endif

#if (ETH_INIT_SERDES_API == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_InitSerdes(CONST(Eth_ConfigType*, AUTOMATIC) CfgPtr);
#endif

#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
extern FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetAndResetMeasurementData (
uint8 CtrlIdx,
Eth_MeasurementIdxType MeasurementIdx,
boolean ResetNeeded,
P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) MeasurementData);
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
#endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */

#define ETH_STOP_SEC_PUBLIC_CODE
#include "Eth_MemMap.h"

#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

extern FUNC(void, ETH_PRIVATE_CODE) Eth_DemConfigCheck(CONST(Dem_EventIdType, AUTOMATIC) EventId,
                        CONST(Dem_EventStatusType, AUTOMATIC) EventStatus);

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#define ETH_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

/* Declaration for ETH Database */
/* Multiple configuration is not supported */
extern CONST(Eth_ConfigType, ETH_CONST) Eth_GaaConfiguration[];                                                         /* PRQA S 3684 # JV-01 */

/* Array of structures for HW-IP Configuration */
extern CONST(Eth_HWIPType, ETH_CONST) Eth_GaaHWIP[];                                                                    /* PRQA S 3684 # JV-01 */

#define ETH_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

#endif /* ETH_H */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
