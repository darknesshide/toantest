/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETND_Ram.h                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Ethernet driver global variables and the                                                        */
/* Ram Allocation functions                                                                                           */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.2.0: 30/12/2025    : Update to fix for Misra C msg 1752.
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *        25/06/2025    : Correct memmap mapping for Eth_Ctrl0_TxDescDataEtnd, Eth_Ctrl0_RxDescDataEtnd,
 *                        Eth_GaaTxRamDesc.
 * 1.0.2: 17/03/2025    : Update to merging SingleMainline
 *                        + Add declaration: Eth_GaaDescTsChainTable, Eth_GaaTxRamInitState,
 *                        Eth_GaaTsDescTotal, Eth_GstETND_Regs
 * 1.0.1: 21/02/2025    : Remove function Eth_ETND_CheckProvideBuffer.
 *                        Remove function Eth_ETND_CheckBufferWithPiority.
 *                        Add function Eth_ETND_GetImmTxBuffer.
 * 1.0.0: 28/09/2024    : Add new global variables Eth_Ctrl1_TxDescDataEtnd, Eth_Ctrl1_RxDescDataEtnd, 
 *                        to support static memory.
 *        29/08/2024    : Add new global variables Eth_Ctrl0_TxDescDataEtnd, Eth_Ctrl0_RxDescDataEtnd,
 *                        Eth_GaaTxDescTableEtnd, Eth_GaaRxDescTableEtnd to support static memory.
 *                        Remove global variables Eth_GulTsDescTail since it belong to ETNE.
 *                        Add function Eth_ETND_RamInit to support static memory.
 *                        Add function Eth_ETND_CheckBufferWithPiority to support Eth_ImmediateTransmit API.
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/
/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/
#ifndef ETH_ETND_RAM_H
#define ETH_ETND_RAM_H
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for utility definitions */
#include "Eth_Common_LLDriver.h"

/* Included for Type definitions */
#include "Eth_Types.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#if (ETH_MACRO_ETND == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETND_RAM_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_ETND_RAM_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_ETND_RAM_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_ETND_RAM_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_ETND_RAM_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION
/***********************************************************************************************************************
**                                              MISRA C Rule Violations                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    QAC Warning                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

/* Tx Desc Data for TxRam */
extern VAR(Eth_ExtDescType, ETH_VAR_NO_INIT) Eth_GaaTxRamDesc[(ETH_ETND_INIT_DESC_NUM + ETH_ETND_EOS_DESC_NUM)];

#define ETH_STOP_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"


#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

extern VAR(uint8, ETH_VAR_NO_INIT) Eth_GaaTxRamBuffer[ETH_ETND_2KB_FRAME_SIZE];

#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

/* Array variable store status of transmit ram initialization state */
extern VAR(boolean, ETH_VAR_INIT) Eth_GaaTxRamInitState[ETH_TOTAL_CTRL_CONFIG];

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

/* Tx Desc Data */
extern P2VAR(Eth_ExtDescType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxDescTableEtnd[ETH_TOTAL_CTRL_CONFIG];               /* PRQA S 3432 # JV-01 */

/* Rx Desc Data */
extern P2VAR(Eth_ExtDescWithTsType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxDescTableEtnd[ETH_TOTAL_CTRL_CONFIG];         /* PRQA S 3432 # JV-01 */

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)

extern P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_VAR_INIT_PTR) Eth_GaaDescTsChainTable[ETH_TOTAL_CTRL_CONFIG];        /* PRQA S 3432 # JV-01 */

#endif

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

/* Function pointer variable for ETND Unit configuration */
extern VAR(Eth_HwFuncTableType, ETH_VAR_INIT) Eth_EtndFunc;

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/* Array variable store total descriptor for each controller */
extern CONST(uint32, ETH_CONFIG_DATA) Eth_GaaTsDescTotal[ETH_TOTAL_CTRL_CONFIG];
#endif

#define ETH_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

/***********************************************************************************************************************
**                                                   Macro Defines                                                    **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_InitializeBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_PreprocessBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(BufReq_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_GetTxBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucPriority,
                    CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                   /* PRQA S 3432 # JV-01 */
                    CONSTP2VAR(uint8 *, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                             /* PRQA S 3432 # JV-01 */
                    CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr);                                           /* PRQA S 3432 # JV-01 */
extern FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_ETND_GetImmTxBuffer(
                    CONST(uint32, AUTOMATIC) LulCtrlIdx,
                    CONST(uint8, AUTOMATIC) LucPriority,
                    CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                   /* PRQA S 3432 # JV-01 */
                    P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                  /* PRQA S 3432 # JV-01 */
                    CONST(uint16, AUTOMATIC) LusFrameLength);
extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETND_ReleaseTxBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);
    
extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETND_PreprocessFrame(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
                        CONST(uint32, AUTOMATIC) LulFrameType,
                        CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
                        CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen);                                     /* PRQA S 3432 # JV-01 */
extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETND_RamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx);

extern FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE)
    Eth_ETND_FindTxBufferHandler(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
#endif /* ETH_ETND_RAM_H  */
#endif /* ETH_MACRO_ETND == STD_ON */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
