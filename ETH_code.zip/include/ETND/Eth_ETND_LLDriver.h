/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETND_LLDriver.h                                                                                 */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains ETND specific definitions of Eth Driver Component.                                              */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.4.0: 09/04/2026    : Update to add MISRA-C Justification comment.
 * 1.2.0: 30/12/2025    : Update to add the justification for Misra C msg 1710.
 * 1.1.1: 16/09/2025    : Add macro for MPIC register
 *                        rename ETH_MIN_PAYLOAD_SIZE to ETH_MIN_PAYLOAD_SIZE_ETND
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *                        Add volatile for element ulDT of type Eth_DataDescLType to fix issue ARDAACL-56612.
 * 1.0.2: 13/03/2025    : Update to merging SingleMainline
 *                        + Commonize the type Eth_TxBufferType, Eth_BufHandlerType, Eth_RxFrameType,
 *                        Eth_RxBufManageType and move these type from Eth_<HWIP>_LLDriver.h to Eth_Types.h
 * 1.0.1: 27/02/2025    : Change name of function Eth_ETND_GetTimeOutValue to Eth_ETND_GetElapsedTimeValue.
 *                        Update function Eth_HwReadMiiBit to modify return type and add 1 new input argument.
 *                        Remove WA() implementation.
 * 1.0.0: 21/10/2024    : Add WA() in macro function ETH_GET_TAS_STARTUP_TIME to workaround for HW defect.
 *        28/09/2024    : Modify type Eth_ETNDConfigType to add element enData0InterruptID, enData1InterruptID,
 *                        enData2InterruptID, enData3InterruptID, enGenInterruptID to store the InterruptID.
 *                        Add new function Eth_ETND_ResetRxDesc to reset the Rx descriptor.
 *                        Remove new type Eth_RxBufManageType.
 *        29/08/2024    : Modify ETH_CPUCLK_MHZ to 240Mhz as mentioned in HWUM.
 *                        Add macro ETH_TXQ_NUM, ETH_RXQ_NUM.
 *                        Add type Eth_RxBufManageType.
 *                        Modify type Eth_HwStatusType to remove element pTxAllocCnt and update type for elements
 *                        pBufTxCnt, ppHeadTxDesc, ppNextTxDesc, ppHeadRxDesc.
 *        03/08/2024    : Add function Eth_ETND_HwGetCurrentTimeTuple to get timestamp infor.
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/
#ifndef ETH_ETND_LLDRIVER_H
#define ETH_ETND_LLDRIVER_H
#include "mcal_Types.h" // TODO: LTT, NEED TO CHECK
#include "Std_Types.h"
#include "Eth_Types.h"
#include "Eth_Util.h"
#include "Os.h"
/* #include <rh850_Types.h> */
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#if (ETH_MACRO_ETND == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETND_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_ETND_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_ETND_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_ETND_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_ETND_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0635)    : Bit-field %1s in %2s has been declared with a type not explicitly supported.                 */
/* Rule                : CERTCCM INT12, MSC14, MISRA C:2012 Dir-1.1,  Rule-1.2, Rule-6.1                              */
/*                       REFERENCE - ISO:C90-6.5.2.1 Structure and Union Specifiers - Semantics                       */
/* JV-01 Justification : To access bit wise from register.                                                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0750)    : A union type specifier has been defined.                                                     */
/* Rule                : CWE Rule CWE-843,  MISRA C:2012 Rule-19.2                                                    */
/* JV-01 Justification : This union type is used for register accessing and there is no issue with this usage.        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1039)    : Treating array of length one as potentially flexible member.                                 */
/* Rule                : CERTCCM DCL38,  MISRA C:2012 Dir-1.1, Rule-1.2                                               */
/* JV-01 Justification : Use array of length as the final member has no problem by manual reviewing.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3472)    : All toplevel uses of this function-like macro look like they could be replaced by            */
/*                       equivalent function calls.                                                                   */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3630)    : The implementation of this struct/union type should be hidden.                               */
/* Rule                :  MISRA C:2012 Dir-4.8                                                                        */
/* JV-01 Justification : This is accepted. Redundant of struct or union type has no affect to driver operation.       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions.                                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/
/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
/* TxRAM initialization */
#define ETH_ETND_INIT_TMS_CONFIG              0x00004000UL
#define ETH_ETND_INIT_DESC_NUM                16UL
#define ETH_ETND_INIT_DESC_LOOP_NUM           2UL
#define ETH_ETND_INIT_TFS0_CONFIG             0x00000100UL
#define ETH_ETND_MIDDLE_DESC_NUM              6UL
#define ETH_ETND_EOS_DESC_NUM                 1UL
#define ETH_ETND_TDIS_0_MASK                  0x00000001UL
#define ETH_ETND_SOFTWARE_RESET_ENABLE        0x00000001UL
#define ETH_ETND_GIS_SWRCF_MASK               0x00010000UL
#define ETH_ETND_MCC_TXE_MASK                 0x00000002UL
#define ETH_ETND_TRCR0_TRANSMIT_ENABLE        0x00000001UL

/* MHD Mode values in OCR register */
#define ETH_ETND_MHD_DISABLE_MODE             0x00000000UL
#define ETH_ETND_MHD_CONFIG_MODE              0x00000001UL
#define ETH_ETND_MHD_OPERATION_MODE           0x00000002UL

/* MHD Tx General Configuration */
#define ETH_ETND_MAX_TFS                      4UL
#define ETH_ETND_TFS_CONFIG                   0x00200020UL
#define ETH_ETND_TGC1_CONFIG                  0x0000FF05UL
#define ETH_ETND_TCR1_CONFIG                  0x00000000UL
#define ETH_ETND_TCR2_CONFIG                  0x00000000UL
#define ETH_ETND_TCR3_CONFIG                  0x00000000UL
#define ETH_ETND_TCR4_CONFIG                  0x00000000UL

/* MHD Rx General Configuration */
#define ETH_ETND_RGC_CONFIG                   0x88A80000UL
#define ETH_ETND_RDFCR_CONFIG                 0x04000800UL
#define ETH_ETND_RCFCR_CONFIG                 0x00800100UL

/* Descriptor Attribute Types */
#define ETH_TX_DESCR_TSUN_MASK                0x00000FF0UL

/* Interrupt related registers */
/* AXIBMI Error Interrupt */
#define ETH_ETND_EIE0_CONFIG                  0x00000003UL
/* MHD Error Interrupt */
#define ETH_ETND_TCIE_CONFIG                  0x00000400UL
#define ETH_ETND_TIE2_CONFIG                  0xFF010000UL
#define ETH_ETND_RIE_CONFIG                   0x00000010UL

/* Minimum payload length allowed by the HW */
#define ETH_MIN_PAYLOAD_SIZE_ETND                  14UL

/***********************************************************************************************************************
** Number of Tx/Rx queues
***********************************************************************************************************************/
#define ETH_TXQ_NUM_ETND                            8UL  /* tx queue number */
#define ETH_RXQ_NUM_ETND                            1UL  /* rx queue number */

/***********************************************************************************************************************
**                            HW specific parameters referred from the upper-level driver                             **
***********************************************************************************************************************/
#define ETH_CPUCLK_MHZ                        240UL

/* Insert paddings to the top of buffers to align payload location as 4 byte */
/* Paddings before header */
#define ETH_TXRX_BUFFER_PRE_PADDING           2UL
/* Paddings between header and payload */
#define ETH_TXRX_BUFFER_IN_PADDING            0UL

/* Use gPTP timer domain 1 */
#define ETH_GPTP_TIMER_DOMAIN                 0UL

/* Enable gPTP timer domain 1 */
#define ETH_GPTP_TIMER_DOMAIN_ENABLE          1UL
#define ETH_GPTP_TIMER_DOMAIN_MASK            (1UL << ETH_GPTP_TIMER_DOMAIN)

#define ETH_GPTP_OFFSET_NANOSEC_MAXVALUE      0x3B9AC9FFUL

/***********************************************************************************************************************
**                                                  Descriptor Types                                                  **
***********************************************************************************************************************/
#define ETH_DESC_FEMPTY_ND                    3UL
#define ETH_DESC_FEMPTY                       4UL
#define ETH_DESC_FSINGLE                      8UL
#define ETH_DESC_FSTART                       9UL
#define ETH_DESC_FMID                         10UL
#define ETH_DESC_FEND                         11UL
#define ETH_DESC_LEMPTY                       12UL
#define ETH_DESC_LINK                         14UL
#define ETH_DESC_EOS                          15UL

/***********************************************************************************************************************
**                                             Descriptor Attribute Types                                             **
***********************************************************************************************************************/
#define ETH_TX_DESC_TYPE_DIRECT               1UL
#define ETH_TX_DESC_TCX_ENABLE                1UL
#define ETH_TX_DESC_TN_DOMAIN                 ETH_GPTP_TIMER_DOMAIN
#define ETH_TX_DESC_DIE_ENABLE                1UL
#define ETH_RX_DESC_DIE_ENABLE                1UL
#define ETH_TS_DESC_DIE_ENABLE                1UL

/***********************************************************************************************************************
**                                                 Size of descriptor                                                 **
***********************************************************************************************************************/
#define ETH_EXT_DESC_SIZE                     16UL /* Extended descriptor size(in byte) */
#define ETH_EXT_DESC_TS_SIZE                  24UL /* Extended descriptor with Timestamp size(in byte) */

/***********************************************************************************************************************
**                                         General Ethernet MAC Address Size                                          **
***********************************************************************************************************************/
#define ETH_RX_DPTR_OFFSET                    2UL

/***********************************************************************************************************************
**                                                 Descriptor related                                                 **
***********************************************************************************************************************/
#define ETH_CYCLIC_DESC_NUM                   1U
/* TxRAM initialization */
#define ETH_ETND_2KB_FRAME_SIZE               0x00000800UL
#define ETH_ETND_INIT_FRAME_LENGTH            0x00004000UL
#define ETH_ETND_DESC_FCS_INCLUDED            0x00000001UL

/***********************************************************************************************************************
** Queues related definitions
***********************************************************************************************************************/
#define ETH_TAS_QUEUE_NUM                     8UL /* Maximum TAS queue number */

/* Queue ID mask */
#define ETH_QUEUE_ID_0_4_MASK                 0x00000011UL
#define ETH_QUEUE_ID_1_5_MASK                 0x00000022UL
#define ETH_QUEUE_ID_2_6_MASK                 0x00000033UL
#define ETH_QUEUE_ID_3_7_MASK                 0x00000044UL

/***********************************************************************************************************************
** Mask for the Status Register
***********************************************************************************************************************/
/* RAM reset in descriptor */
#define ETH_ETND_RATRR_RESET                 0x00000001UL
#define ETH_ETND_TATRR_RESET                 0x00000002UL
#define ETH_ETND_RMSRR_RESET                 0x00000001UL

/* AXI Bus Configuration */
#define ETH_ETND_AXIWC_CONFIG                0x00014411UL
#define ETH_ETND_AXIRC_CONFIG                0x00011144UL

/* Tx Descriptor Address Table Learning */
#define ETH_ETND_TATLS0_CONFIG               0x00000002UL
#define ETH_ETND_TATLR_LEARNING              0x80000000UL
#define ETH_ETND_TATLR_FAILED                0x00000001UL

/* Rx Descriptor Address Table Learning */
#define ETH_ETND_RATLS0_CONFIG               0x0000000CUL
#define ETH_ETND_RATLS0_CHAIN_ENTRY_INVALID  0x00000040UL
#define ETH_ETND_RATLR_LEARNING              0x80000000UL
#define ETH_ETND_RATLR_FAILED                0x00000001UL
#define ETH_ETND_RATSR2_SEARCHING            0x80000000UL

/* Ts Descriptor Address Table Learning */
#define ETH_ETND_TSS_CONFIG                  0x00000005UL

/* TAS Control List Table Learning */
#define ETH_ETND_TAEN_POSITION               4UL
#define ETH_ETND_TAEN_OFFSET                 8UL
#define ETH_ETND_TACLL2_LEARNING             0x80000000UL
#define ETH_ETND_TCC_ENABLE                  0x00000001UL
#define ETH_ETND_TCC_DISABLE                 0x00000000UL

/* MAC automatic timestamp configuration */
#define ETH_ETND_MTATC_CONFIG                0x02000000UL

/* MAC Timestamp reception configuration */
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
#define ETH_ETND_MTRC_CONFIG                 0x00020000UL
#else
#define ETH_ETND_MTRC_CONFIG                 0x03020000UL
#endif

/* MAC reception address filter configuration */
#define ETH_ETND_MRAFC_CONFIG                0x00660066UL
#define ETH_ETND_PROMISCUOUS_MODE            0x00010001UL

#define ETH_ETND_GECMR_SPEED                 0x00000001UL
#define ETH_ETND_SGSRST_SRST                 0x00000001UL
#define ETH_ETND_SGINTM_URDYIM               0x0002U
#define ETH_ETND_SGINTM_RDYIM                0x0001U
#define ETH_ETND_SGINTM_ENABLE               0x00000000UL
#define ETH_ETND_SGSDS_SUC                   0x04U
#define ETH_ETND_SGSDS_PWS_ON                0x03U
#define ETH_ETND_SGCLKSEL_SEL                0x01U
#define ETH_ETND_SGRCIE_RCIE                 0x01U

/* MAC Loopback configuration */
#define ETH_ETND_MLBC_CONFIG                 0x00000001UL

/* AXIBMI Data Interrupt */
#define ETH_ETND_DIE_CONFIG                   0x0001FFFFUL
#define ETH_ETND_TSDIE_CONFIG                 0x00000001UL

/* Link Verification Settings */
#define ETH_ETND_MLVC_PASE_MASK               0x00000100UL
#define ETH_ETND_MLVC_PLV_MASK                0x00020000UL
#define ETH_ETND_MLVC_PSE_MASK                0x00010000UL

/* Masking for summary of error information in info0 */
#define ETH_ETND_INFO0_SEI_MASK               0x00000002UL

/* MAC PHY interfaces configuration */
#define ETH_ETND_MPIC_10MB                    0x00000000UL
#define ETH_ETND_MPIC_100MB                   0x00000004UL
#define ETH_ETND_MPIC_1GB                     0x00000008UL
#define ETH_ETND_MPIC_2500MB                  0x0000000CUL
#define ETH_ETND_MPIC_MII_RMII                0x00000000UL
#define ETH_ETND_MPIC_GMII_SGMII              0x00000002UL

/***********************************************************************************************************************
**                                             MDIO related definitions                                               **
***********************************************************************************************************************/
/* MDIO Config:                                                                                                       */
/* PHY Station Management Capture time:         User define                                                           */
/* PHY Station Management Hold time adjustment: User define                                                           */
/* PHY Station Management Preamble:             Enabled                                                               */
/* PHY Station Management Clock Selection:      User define                                                           */
/* PHY Link Status Pin Plugged:                 Unplugged                                                             */
/* PHY Interrupt Pin Plugged:                   Unplugged                                                             */
/* PHY Interrupt Polarity:                      Active low                                                            */
/* RMII error pin plugged:                      Unplugged                                                             */
/* Link Speed Configuration:                    Gentool variable                                                      */
/* PHY Interface Select:                        Gentool variable                                                      */
/**********************************************************************************************************************/
#define ETH_ETND_PHY_CONFIG_REGISTER_MASK 0x1UL

#define ETH_ETND_MPSM_READ_OPERATION      0x1UL
#define ETH_ETND_MPSM_WRITE_DATA_SET      0x2UL
#define ETH_ETND_MPSM_WRITE_OPERATION     0x1UL

#define ETH_ETND_MPIC_PSMCS_MASK          0xFFC0FFFFUL
#define ETH_ETND_MMIS1_PWACS_MASK         0x02UL

/***********************************************************************************************************************
**                                             SGMII related definitions                                              **
***********************************************************************************************************************/
#define ETH_ETND_WAIT_FOR_SGMII                4000UL /* nanosecond */

#define ETH_ETND_PIR_MDC                       0x00000001UL
#define ETH_ETND_PIR_MMD                       0x00000002UL
#define ETH_ETND_PIR_MDO                       0x00000004UL
#define ETH_ETND_GECMR_SPEED                   0x00000001UL
#define ETH_ETND_SGSRST_SRST                   0x00000001UL
#define ETH_ETND_SGINTM_URDYIM                 0x0002U
#define ETH_ETND_SGINTM_RDYIM                  0x0001U
#define ETH_ETND_SGINTS_URDY                   0x0002U
#define ETH_ETND_SGINTS_RDY                    0x0001U
#define ETH_ETND_SGINTS_RDY_UNRDY              (ETH_ETND_SGINTS_RDY | ETH_ETND_SGINTS_URDY)
#define ETH_ETND_SGSDS_SUC                     0x04U
#define ETH_ETND_SGSDS_PWS_ON                  0x03U
#define ETH_ETND_SGCLKSEL_SEL                  0x01U
#define ETH_ETND_SGRCIE_RCIE                   0x01U

#define ETH_ETND_SGOPMC_10M                    0x00000003UL
#define ETH_ETND_SGOPMC_100M                   0x00000007UL
#define ETH_ETND_SGOPMC_1G                     0x0000000BUL

/***********************************************************************************************************************
**                                              GTO related definitions                                               **
***********************************************************************************************************************/
#define ETH_ETND_GTO_MINUS                0xFFFFU

/***********************************************************************************************************************
**                                              Register address offset                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/

/* TSN frame type */
typedef enum ETag_Eth_TSN_FrameType
{
  ETH_EXPRESS_FRAME,
  ETH_PREEMPTION_FRAME
} Eth_TSN_FrameType;

typedef enum ETag_Eth_TxFragmentType
{
  ETH_FRAGMENT_64_BYTE,
  ETH_FRAGMENT_128_BYTE,
  ETH_FRAGMENT_192_BYTE,
  ETH_FRAGMENT_256_BYTE
} Eth_TxFragmentType;

typedef enum ETag_Eth_TASGateStateType
{
  ETH_TAS_OPEN,
  ETH_TAS_CLOSE
} Eth_TASGateStateType;

typedef enum ETag_Eth_RxExtStatusType
{
  ETH_EXT_RECEIVED = 0,
  ETH_EXT_NOT_RECEIVED,
  ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE,
  ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE
} Eth_ExtRxStatusType;

/* Credit Based Shaper */
/* ulCIV: Credit Increment Value */
/* ulCUL: Credit Upper Limit */
typedef struct STag_Eth_CBSConfigType
{
  Eth_OptionType enCE;
  uint32 ulCIV;                                                                                                         /* PRQA S 1710 # JV-01 */
  uint32 ulCUL;
} Eth_CBSConfigType;

typedef struct STag_Eth_TASEntryType                                                                                    /* PRQA S 3630 # JV-01 */
{
  Eth_TASGateStateType enGateState;
  uint32 ulTimeInterval;
} Eth_TASEntryType;

/* Time Aware Shaper */
typedef struct STag_Eth_TASConfigType
{
  Eth_OptionType enTasEnable;
  uint32 ulTxMiniLatency;
  uint32 ulTxJitter;
  uint32 aaNumberOfTasTable[ETH_TAS_QUEUE_NUM];
  P2CONST(Eth_TASEntryType, TYPEDEF, ETH_APPL_CONST) aaTasAdminTable[ETH_TAS_QUEUE_NUM];
} Eth_TASConfigType;

/* Tx Queue Struct */
typedef struct STag_Eth_TxQueueType                                                                                     /* PRQA S 3630 # JV-01 */
{
  uint32 ulQueueBufs;
  uint32 ulQueueId;
  Eth_TSN_FrameType enFrameType;
  uint32 ulMaxFrameSize;
  Eth_CBSConfigType stCBSConfig;
} Eth_TxQueueType;

/* Rx Queue struct */
typedef struct STag_Eth_RxQueueType                                                                                     /* PRQA S 3630 # JV-01 */
{
  uint32 ulQueueBufs;
  uint32 ulQueueId;
  uint8 aaMacFilterPattern[ETH_MACADDR_SIZE];
} Eth_RxQueueType;

typedef struct STag_Eth_QueueConfigType
{
  P2CONST(Eth_TxQueueType, TYPEDEF, ETH_APPL_CONST) pTxQueueConfig;
  P2CONST(Eth_RxQueueType, TYPEDEF, ETH_APPL_CONST) pRxQueueConfig;
  uint8 ucNumberOfTxQueue;
  uint8 ucNumberOfRxQueue;
  uint8 ucOffsetOfTxQueue;
  uint8 ucOffsetOfRxQueue;
  uint32 ulTxIntConfig;
  uint32 ulRxIntConfig;
} Eth_QueueConfigType;

/***********************************************************************************************************************
**  Type: Eth_CaptureTimeAdjustment                                                                                   **
**                                                                                                                    **
**  Capture Time option                                                                                               **
**                                                                                                                    **
**  Members:                                                                                                          **
**    MDIO_CAPTURE_TIME_0_CLK_CYCLE  -  No adjusted capture time                                                      **
**    MDIO_CAPTURE_TIME_1_CLK_CYCLE  -  Capture before 1 clk                                                          **
**    MDIO_CAPTURE_TIME_2_CLK_CYCLE  -  Capture before 2 clk                                                          **
**    MDIO_CAPTURE_TIME_3_CLK_CYCLE  -  Capture before 3 clk                                                          **
**    MDIO_CAPTURE_TIME_4_CLK_CYCLE  -  Capture before 4 clk                                                          **
**    MDIO_CAPTURE_TIME_5_CLK_CYCLE  -  Capture before 5 clk                                                          **
**    MDIO_CAPTURE_TIME_6_CLK_CYCLE  -  Capture before 6 clk                                                          **
**    MDIO_CAPTURE_TIME_7_CLK_CYCLE  -  Capture before 7 clk                                                          **
***********************************************************************************************************************/
typedef enum ETag_Eth_CaptureTimeAdjustmentType
{
  MDIO_CAPTURE_TIME_0_CLK_CYCLE = 0,
  MDIO_CAPTURE_TIME_1_CLK_CYCLE,
  MDIO_CAPTURE_TIME_2_CLK_CYCLE,
  MDIO_CAPTURE_TIME_3_CLK_CYCLE,
  MDIO_CAPTURE_TIME_4_CLK_CYCLE,
  MDIO_CAPTURE_TIME_5_CLK_CYCLE,
  MDIO_CAPTURE_TIME_6_CLK_CYCLE,
  MDIO_CAPTURE_TIME_7_CLK_CYCLE
} Eth_CaptureTimeAdjustmentType;

/***********************************************************************************************************************
**  Type: Eth_HoldTimeAdjustment                                                                                      **
**                                                                                                                    **
**  Hold Time option                                                                                                  **
**                                                                                                                    **
**  Members:                                                                                                          **
**    MDIO_HOLD_TIME_0_CLK_CYCLE  -  No adjusted hold time                                                            **
**    MDIO_HOLD_TIME_1_CLK_CYCLE  -  Hold extra 1 clk                                                                 **
**    MDIO_HOLD_TIME_2_CLK_CYCLE  -  Hold extra 2 clk                                                                 **
**    MDIO_HOLD_TIME_3_CLK_CYCLE  -  Hold extra 3 clk                                                                 **
**    MDIO_HOLD_TIME_4_CLK_CYCLE  -  Hold extra 4 clk                                                                 **
**    MDIO_HOLD_TIME_5_CLK_CYCLE  -  Hold extra 5 clk                                                                 **
**    MDIO_HOLD_TIME_6_CLK_CYCLE  -  Hold extra 6 clk                                                                 **
**    MDIO_HOLD_TIME_7_CLK_CYCLE  -  Hold extra 7 clk                                                                 **
***********************************************************************************************************************/
typedef enum ETag_Eth_HoldTimeAdjustmentType
{
  MDIO_HOLD_TIME_0_CLK_CYCLE = 0,
  MDIO_HOLD_TIME_1_CLK_CYCLE,
  MDIO_HOLD_TIME_2_CLK_CYCLE,
  MDIO_HOLD_TIME_3_CLK_CYCLE,
  MDIO_HOLD_TIME_4_CLK_CYCLE,
  MDIO_HOLD_TIME_5_CLK_CYCLE,
  MDIO_HOLD_TIME_6_CLK_CYCLE,
  MDIO_HOLD_TIME_7_CLK_CYCLE
} Eth_HoldTimeAdjustmentType;

/***********************************************************************************************************************
**  Type: Eth_RxConfigType                                                                                            **
**                                                                                                                    **
**  reception configuration structure                                                                                 **
**                                                                                                                    **
**  Members:                                                                                                          **
**    enEncf                  - enable network control filtering                                                      **
**    enEsf                   - enable stream filtering                                                               **
**    enEts0                  - enable timestamp storage (best effort)                                                **
**    enEts2                  - enable timestamp storage (stream)                                                     **
**    ulRfcl                  - reception FIFO critical level                                                         **
**    enSRPTalkerFiltering    - enable stream filtering for talker only                                               **
***********************************************************************************************************************/
typedef struct STag_Eth_RxConfigType
{
  uint32 ulBcastThreshold;
  uint32 ulMcastThreshold;
  Eth_OptionType enBcastStormFilter;
  Eth_OptionType enMcastStormFilter;
  uint32 ulMaxFrameSize;
} Eth_RxConfigType;

/***********************************************************************************************************************
**  Type: Eth_MACConfigType                                                                                           **
**                                                                                                                    **
**  MAC configuration structure                                                                                       **
**                                                                                                                    **
**  Members:                                                                                                          **
**    enPauseFrame                   - enable/disable flow control                                                    **
**    ulRetransmissionTime           - pause frame retransmission time                                                **
**    ulPauseTime                    - stop time at pause frame                                                       **
**    enPauseTimeZero                - enable/disable receive pause frame zero                                        **
**    ulLVTimer                      - Link Verification Timer                                                        **
***********************************************************************************************************************/
typedef struct STag_Eth_MACConfigType
{
  Eth_OptionType enPauseFrame;
  uint32 ulRetransmissionTime;
  uint32 ulPauseTime;
  Eth_OptionType enPauseTimeZero;
  uint32 ulLVTimer;
} Eth_MACConfigType;

/***********************************************************************************************************************
**  Type: Eth_TimeAdjustment                                                                                          **
**                                                                                                                    **
**  Time adjustment structure                                                                                         **
**                                                                                                                    **
**  Members:                                                                                                          **
**    enPSMCaptureTime        - PHY Station Management Capture time                                                   **
**    enPSMHoldTime           - PHY Station Management Hold time                                                      **
**    ulPSMClockSelection     - PHY Station Management Clock Selection                                                **
***********************************************************************************************************************/
typedef struct STag_Eth_PHYConfigType
{
  Eth_CaptureTimeAdjustmentType enPSMCaptureTime;
  Eth_HoldTimeAdjustmentType enPSMHoldTime;
  uint32 ulPSMClockSelection;
} Eth_PHYConfigType;

/* ETND LLDriver specific hardware configuration */
typedef struct STag_Eth_ETNDConfigType
{
  uint32 ulEthPortId;
  Eth_QueueConfigType stQueueConfig;
  Eth_RxConfigType stRxConfig;
  Eth_TxFragmentType enTxFragment;
  Eth_TASConfigType stTASConfig;
  Eth_PHYConfigType stPHYConfig;
  Eth_MACConfigType stMACConfig;
  #if(ETH_DEVICE_NAME == ETH_U5X)
  Eth_OptionType enPreemption;
  Eth_OptionType enBypassMode;
  uint32 ulInterPacketGap;
  #endif
  /* IRQ number of the Interrupt Vector Table */
  VAR(IRQn_Type, TYPEDEF) enData0InterruptID;
  /* IRQ number of the Interrupt Vector Table */
  VAR(IRQn_Type, TYPEDEF) enData1InterruptID;
  /* IRQ number of the Interrupt Vector Table */
  VAR(IRQn_Type, TYPEDEF) enData2InterruptID;
  /* IRQ number of the Interrupt Vector Table */
  VAR(IRQn_Type, TYPEDEF) enData3InterruptID;
  /* IRQ number of the Interrupt Vector Table */
  VAR(IRQn_Type, TYPEDEF) enGenInterruptID;
} Eth_ETNDConfigType;

/***********************************************************************************************************************
**  Type: Eth_TxCtrlInfo0Type                                                                                         **
**                                                                                                                    **
**  Tx specific control field structure                                                                               **
**                                                                                                                    **
**  Members End Station:                                                                                              **
**    ulFi   - FCS in                                                                                                 **
**    ulFr   - FCS Replacement                                                                                        **
**    ulTxc  - Tx Capture                                                                                             **
**    ulIet  - Insert egress timestamp                                                                                **
**    ulTsun - Timestamp unique number                                                                                **
**    ulTn   - Timer number                                                                                           **
**  Members R-Switch:                                                                                                 **
**    ulFmt  - Frame format                                                                                           **
**    ulErr  - Descriptor error                                                                                       **
**    ulFi   - FCS                                                                                                    **
**    ulVctr - VLAN control                                                                                           **
**    ulReserved  - Reserved                                                                                          **
***********************************************************************************************************************/
typedef struct STag_Eth_TxCtrlInfo0Type
{
  uint32 ulFi : 1;                                                                                                      /* PRQA S 0635 # JV-01 */
  uint32 ulFr : 1;                                                                                                      /* PRQA S 0635 # JV-01 */
  uint32 ulTxc : 1;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulIet : 1;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulTsun : 8;                                                                                                    /* PRQA S 0635 # JV-01 */
  uint32 ulTn : 1;                                                                                                      /* PRQA S 0635 # JV-01 */
} Eth_TxCtrlInfo0Type;

/***********************************************************************************************************************
**  Union: Eth_TxCtrlInfo0WordType                                                                                    **
**                                                                                                                    **
**  Simplifies Bit and Byte access                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stTxCtrl  - Tx control field                                                                                    **
**    ulWord    - Allow access of the whole word.                                                                     **
***********************************************************************************************************************/
typedef union UTag_Eth_TxCtrlInfo0WordType
{                                                                                                                       /* PRQA S 0750 # JV-01 */
  Eth_TxCtrlInfo0Type stTxCtrl;
  uint32 ulWord;
} Eth_TxCtrlInfo0WordType;

/***********************************************************************************************************************
**  Type: Eth_TxCtrlInfo1Type                                                                                         **
**                                                                                                                    **
**  Tx specific control field structure                                                                               **
**                                                                                                                    **
**  Members End Station:                                                                                              **
**    ulTfl        - Total Frame Length                                                                               **
**    ulCrt        - Calculate residence time (This bit should be always set to 0)                                    **
**    ulReserved0  - Reserved                                                                                         **
**  Members R-Switch:                                                                                                 **
**    ulTsun       - Timestamp Unique Number for IEEE 1588, AS, AS_rev                                                **
**    ulTxc        - TX Capture                                                                                       **
**    ulIet        - Insert Egress Timestamp for IEEE 1588, AS, AS_rev                                                **
**    ulCrt        - Calculation Residence Time for IEEE 1588, AS, AS_rev                                             **
**    ulReserved0  - Reserved                                                                                         **
**    ulTn         - Timestamp domain Number                                                                          **
**    ulReserved1  - Reserved                                                                                         **
***********************************************************************************************************************/
typedef struct STag_Eth_TxCtrlInfo1Type
{
  uint32 ulTfl : 16;                                                                                                    /* PRQA S 0635 # JV-01 */
  uint32 ulCrt : 1;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulReserved0 : 15;                                                                                              /* PRQA S 0635 # JV-01 */
} Eth_TxCtrlInfo1Type;

/***********************************************************************************************************************
**  Union: Eth_TxCtrlInfo1WordType                                                                                    **
**                                                                                                                    **
**  Simplifies Bit and Byte access                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stTxCtrl  - Tx control field                                                                                    **
**    ulWord    - Allow access of the whole word.                                                                     **
***********************************************************************************************************************/
typedef union UTag_Eth_TxCtrlInfo1WordType
{                                                                                                                       /* PRQA S 0750 # JV-01 */
  Eth_TxCtrlInfo1Type stTxCtrl;
  uint32 ulWord;
} Eth_TxCtrlInfo1WordType;

/***********************************************************************************************************************
**  Type: Eth_DataDescLType                                                                                           **
**                                                                                                                    **
**  Data descriptor structure low word                                                                                **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulDs    - Descriptor size                                                                                       **
**    ulInfo0 - Information 0 between CPU and MHD                                                                     **
**    ulDse   - Data Size Error                                                                                       **
**    ulAxie  - AXI Bus Error                                                                                         **
**    ulDie   - Descriptor Interrupt Enable                                                                           **
**    ulDt    - Descriptor Type                                                                                       **
***********************************************************************************************************************/
typedef struct STag_Eth_DataDescLType
{
  uint32 ulDs : 12;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulInfo0 : 13;                                                                                                  /* PRQA S 0635 # JV-01 */
  uint32 ulDse : 1;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulAxie : 1;                                                                                                    /* PRQA S 0635 # JV-01 */
  uint32 ulDie : 1;                                                                                                     /* PRQA S 0635, 1710 # JV-01, JV-01 */
  volatile uint32 ulDt : 4;                                                                                             /* PRQA S 0635 # JV-01 */
}Eth_DataDescLType;

/***********************************************************************************************************************
**  Type: Eth_ExtDescType                                                                                             **
**                                                                                                                    **
**  Extended data descriptor structure                                                                                **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stHeader    - low word of the data descriptor                                                                   **
**    ulDptr      - Descriptor data                                                                                   **
**    ulInfo1     - Information 1 between CPU and MHD                                                                 **
***********************************************************************************************************************/
typedef struct STag_Eth_ExtDescType                                                                                     /* PRQA S 3630 # JV-01 */
{
  Eth_DataDescLType stHeader;
  uint32 ulDptr;
  uint32 ulInfo1[2];
} Eth_ExtDescType;

/***********************************************************************************************************************
**  Type: Eth_ExtDescWithTsType                                                                                       **
**                                                                                                                    **
**  Extended data descriptor with Timestamp structure                                                                 **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stHeader    - low word of the data descriptor                                                                   **
**    ulDptr      - Descriptor data                                                                                   **
**    ulInfo1     - Information 1 between CPU and MHD                                                                 **
**    ulTsns      - Timestamps nanosecond                                                                             **
**    ulTss       - Timestamp second                                                                                  **
***********************************************************************************************************************/
typedef struct STag_Eth_ExtDescWithTsType                                                                               /* PRQA S 3630 # JV-01 */
{
  Eth_DataDescLType stHeader;
  uint32 ulDptr;
  uint32 ulInfo1[2];
  uint32 ulTsns;
  uint32 ulTss;
} Eth_ExtDescWithTsType;

/***********************************************************************************************************************
**  Type: Eth_ETNDStatusType                                                                                          **
**                                                                                                                    **
**  Device instance specific data.                                                                                    **
**                                                                                                                    **
**  All instance specific data is kept within that structure.                                                         **
**                                                                                                                    **
**  Members:                                                                                                          **
**    aaBufTxCnt            - Buffer Tx counter                                                                       **
**    aaHeadTxDesc          - Head tx descriptor address                                                              **
**    aaNextTxDesc          - Last tx descriptor address                                                              **
**    aaHeadRxDesc          - Head rx descriptor address                                                              **
***********************************************************************************************************************/
typedef struct STag_Eth_HwStatusType
{
  uint32                                                 aaBufTxCnt[ETH_TXQ_NUM_ETND];
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA)       aaHeadTxDesc[ETH_TXQ_NUM_ETND];                                /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA)       aaNextTxDesc[ETH_TXQ_NUM_ETND];                                /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) aaHeadRxDesc[ETH_RXQ_NUM_ETND];                                /* PRQA S 1039, 3432 # JV-01, JV-01 */
} Eth_HwStatusType;

/***********************************************************************************************************************
**  Type: Eth_EtherFrameType                                                                                          **
**                                                                                                                    **
**  Ethernet Frame structure                                                                                          **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ucDstAddr    - Destination address                                                                              **
**    ucSrcAddr    - Source address                                                                                   **
**    ucFrameType  - EtherType                                                                                        **
**    ucPayload    - Payload                                                                                          **
***********************************************************************************************************************/
typedef struct STag_Eth_EtherFrameType
{
  uint8 ucDstAddr[6];
  uint8 ucSrcAddr[6];
  uint8 ucFrameType[2];
  Eth_DataType ucPayload;
} Eth_EtherFrameType;

/* ETND register definitions */
typedef struct STag_Eth_ETND_TBFRegType
{
  uint32 ulTBFCRi;                      /* CONFIG/OPERATION                  */
  uint32 ulTBFVRi;                      /* CONFIG/OPERATION                  */
  uint32 Reserved0[2];                  /* Reserved                          */
} Eth_ETND_TBFRegType;

typedef struct STag_Eth_ETND_FBFRegType
{
  uint32 ulFBFCRi;                      /* CONFIG/OPERATION                  */
  uint32 ulFBFV0Ri;                     /* CONFIG/OPERATION                  */
  uint32 ulFBFV1Ri;                     /* CONFIG/OPERATION                  */
  uint32 Reserved0;                     /* Reserved                          */
} Eth_ETND_FBFRegType;

typedef struct STag_Eth_ETND_CFSFRegType
{
  uint32 ulCFCRi;                       /* CONFIG/OPERATION                  */
  uint32 ulSFN0Ri;                      /* CONFIG/OPERATION                  */
  uint32 ulSFN1Ri;                      /* CONFIG/OPERATION                  */
  uint32 Reserved0;                     /* Reserved                          */
} Eth_ETND_CFSFRegType;

typedef struct STag_Eth_ETND_RMACRegType
{
  uint32 ulMCC;                         /* Write inhibit CONFIG/OPERATION    */
  uint32 Reserved0[3];                  /* Reserved                          */
  uint32 ulMPSM;                        /* Any                               */
  uint32 ulMPIC;                        /* CONFIG                            */
  uint32 Reserved1[2];                  /* Reserved                          */
  uint32 ulMTFFC;                       /* CONFIG                            */
  uint32 ulMTPFC;                       /* CONFIG/OPERATION                  */
  uint32 Reserved2[6];                  /* Reserved                          */
  uint32 ulMTATC[16];                   /* CONFIG                            */
  uint32 ulMRGC;                        /* CONFIG                            */
  uint32 ulMRMAC0;                      /* CONFIG                            */
  uint32 ulMRMAC1;                      /* CONFIG                            */
  uint32 ulMRAFC;                       /* CONFIG                            */
  uint32 ulMRSCE;                       /* CONFIG                            */
  uint32 ulMRSCP;                       /* CONFIG                            */
  uint32 ulMRSCC;                       /* CONFIG/OPERATION                  */
  uint32 ulMRFSCE;                      /* CONFIG                            */
  uint32 ulMRFSCP;                      /* CONFIG                            */
  uint32 ulMTRC;                        /* CONFIG                            */
  uint32 Reserved3[22];                 /* Reserved                          */
  uint32 ulMPFC[16];                    /* CONFIG                            */
  uint32 Reserved4[128];                /* Reserved                          */
  uint32 ulMLVC;                        /* CONFIG/OPERATION                  */
  uint32 Reserved5[3];                  /* Reserved                          */
  uint32 ulMEEEC;                       /* CONFIG/OPERATION                  */
  uint32 Reserved6[3];                  /* Reserved                          */
  uint32 ulMLBC;                        /* CONFIG                            */
  uint32 Reserved13[3];                 /* Reserved                          */
  uint32 ulMTIFGC;                      /* Any                               */
  uint32 ulMIRFC;                       /* Any                               */
  uint32 Reserved7[34];                 /* Reserved                          */
  uint32 ulMGMR;                        /* Read only                         */
  uint32 Reserved8[3];                  /* Reserved                          */
  uint32 ulMMPFTCT;                     /* Read only                         */
  uint32 ulMAPFTCT;                     /* Read only                         */
  uint32 ulMPFRCT;                      /* Read only                         */
  uint32 ulMFCICT;                      /* Read only                         */
  uint32 ulMEEECT;                      /* Read only                         */
  uint32 Reserved9[55];                 /* Reserved                          */
  uint32 ulMEIS;                        /* Any                               */
  uint32 ulMEIE;                        /* Any                               */
  uint32 ulMEID;                        /* Any                               */
  uint32 Reserved10;                    /* Reserved                          */
  uint32 ulMMIS0;                       /* Any                               */
  uint32 ulMMIE0;                       /* Any                               */
  uint32 ulMMID0;                       /* Any                               */
  uint32 Reserved11;                    /* Reserved                          */
  uint32 ulMMIS1;                       /* Any                               */
  uint32 ulMMIE1;                       /* Any                               */
  uint32 ulMMID1;                       /* Any                               */
  uint32 Reserved12;                    /* Reserved                          */
  uint32 ulMMIS2;                       /* Any                               */
  uint32 ulMMIE2;                       /* Any                               */
  uint32 ulMMID2;                       /* Any                               */
} Eth_ETND_RMACRegType;

typedef struct STag_Eth_ETND_RMACSRegType
{
  Eth_ETND_TBFRegType stTBF[64];       /* CONFIG/OPERATION                  */
  Eth_ETND_FBFRegType stFBF[64];       /* CONFIG/OPERATION                  */
  Eth_ETND_CFSFRegType stCFSF[64];     /* CONFIG/OPERATION                  */
  uint32 ulVTCCR;                       /* CONFIG                            */
  uint32 Reserved0[3];                  /* Reserved                          */
  uint32 ulFMSCR;                       /* CONFIG                            */
  uint32 Reserved1[59];                 /* Reserved                          */
  uint32 ulFVLSR;                       /* Read only                         */
  uint32 Reserved2[3];                  /* Reserved                          */
  uint32 ulMVCR;                        /* Read only                         */
  uint32 ulMV0R;                        /* Read only                         */
  uint32 ulMV1R;                        /* Read only                         */
  uint32 Reserved3[57];                 /* Reserved                          */
  uint32 ulINTSR;                       /* CONFIG/DISABLE/OPERATION          */
  uint32 ulINTER;                       /* CONFIG/DISABLE/OPERATION          */
  uint32 ulINTDR;                       /* CONFIG/DISABLE/OPERATION          */
  uint32 Reserved4[125];                /* Reserved                          */
  uint32 ulRXBCE;                       /* Read only                         */
  uint32 ulRXBCP;                       /* Read only                         */
  uint32 ulRGFCE;                       /* Read only                         */
  uint32 ulRGFCP;                       /* Read only                         */
  uint32 ulRBFC;                        /* Read only                         */
  uint32 ulRMFC;                        /* Read only                         */
  uint32 ulRVFC;                        /* Read only                         */
  uint32 ulRPEFC;                       /* Read only                         */
  uint32 ulRNEFC;                       /* Read only                         */
  uint32 ulRFMEFC;                      /* Read only                         */
  uint32 ulRFFMEFC;                     /* Read only                         */
  uint32 ulRCFCEFC;                     /* Read only                         */
  uint32 ulRFCEFC;                      /* Read only                         */
  uint32 ulRRCFEFC;                     /* Read only                         */
  uint32 ulRRXFEFC;                     /* Read only                         */
  uint32 ulRUEFC;                       /* Read only                         */
  uint32 ulROEFC;                       /* Read only                         */
  uint32 ulRBOEC;                       /* Read only                         */
  uint32 Reserved5[46];                 /* Reserved                          */
  uint32 ulTXBCE;                       /* Read only                         */
  uint32 ulTXBCP;                       /* Read only                         */
  uint32 ulTGFCE;                       /* Read only                         */
  uint32 ulTGFCP;                       /* Read only                         */
  uint32 ulTBFC;                        /* Read only                         */
  uint32 ulTMFC;                        /* Read only                         */
  uint32 ulTVFC;                        /* Read only                         */
  uint32 ulTEFC;                        /* Read only                         */
  uint32 Reserved6[440];                /* Reserved                          */
  Eth_ETND_RMACRegType stRMAC;          /* RMAC regs                         */
} Eth_ETND_RMACSRegType;

typedef struct STag_Eth_ETND_TSDRegType
{
  uint32 ulTSAs;                        /* TS Descriptor Chain Address s */
  uint32 ulTSSs;                        /* TS Descriptor Chain Setting s */
} Eth_ETND_TSDRegType;

typedef struct STag_Eth_ETND_RIDRegType
{
  uint32 ulRIDASMi;                      /* RX Incremental Data Area Size Monitoring i              */
  uint32 ulRIDASAMi;                     /* RX Incremental Data Area Start Address Monitoring i     */
  uint32 ulRIDACAMi;                     /* RX Incremental Data Area Current Address Monitoring i   */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_RIDRegType;

typedef struct STag_Eth_ETND_TCERegType
{
  uint32 ulTCEISi;                       /* TX Descriptor Configuration Error Interrupt Status i    */
  uint32 ulTCEIEi;                       /* TX Descriptor Configuration Error Interrupt Enable i    */
  uint32 ulTCEIDi;                       /* TX Descriptor Configuration Error Interrupt Disable i   */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_TCERegType;

typedef struct STag_Eth_ETND_RFSRegType
{
  uint32 ulRFSEISi;                      /* RX Frame Size Error Interrupt Status i                  */
  uint32 ulRFSEIEi;                      /* RX Frame Size Error Interrupt Enable i                  */
  uint32 ulRFSEIDi;                      /* RX Frame Size Error Interrupt Disable i                 */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_RFSRegType;

typedef struct STag_Eth_ETND_RFERegType
{
  uint32 ulRFEISi;                       /* RX Descriptor Full Error Interrupt Status i             */
  uint32 ulRFEIEi;                       /* RX Descriptor Full Error Interrupt Enable i             */
  uint32 ulRFEIDi;                       /* RX Descriptor Full Error Interrupt Disable i            */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_RFERegType;

typedef struct STag_Eth_ETND_RCERegType
{
  uint32 ulRCEISi;                       /* RX Descriptor Configuration Error Interrupt Status i    */
  uint32 ulRCEIEi;                       /* RX Descriptor Configuration Error Interrupt Enable i    */
  uint32 ulRCEIDi;                       /* RX Descriptor Configuration Error Interrupt Disable i   */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_RCERegType;

typedef struct STag_Eth_ETND_TDIRegType
{
  uint32 ulTDISi;                        /* TX Descriptor Data Interrupt Status i                   */
  uint32 ulTDIEi;                        /* TX Descriptor Data Interrupt Enable i                   */
  uint32 ulTDIDi;                        /* TX Descriptor Data Interrupt Disable i                  */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_TDIRegType;

typedef struct STag_Eth_ETND_RDIRegType
{
  uint32 ulRDISi;                        /* RX Descriptor Data Interrupt Status i                   */
  uint32 ulRDIEi;                        /* RX Descriptor Data Interrupt Enable i                   */
  uint32 ulRDIDi;                        /* RX Descriptor Data Interrupt Disable i                  */
  uint32 Reserved0;                      /* Reserved                                                */
} Eth_ETND_RDIRegType;

typedef struct STag_Eth_ETND_AXIBMIRegType
{
  uint32 ulAXIWC;                       /* AXI Bus Write Configuration                              */
  uint32 ulAXIRC;                       /* AXI Bus Read Configuration                               */
  uint32 Reserved0[2];                  /* Reserved                                                 */
  uint32 ulTDPC[32];                    /* TX Descriptor chain Priority Configuration i             */
  uint32 ulTFT;                         /* TX Descriptor Chain Type                                 */
  uint32 Reserved1[3];                  /* Reserved                                                 */
  uint32 ulTATLS0;                      /* TX Descriptor Address Table Learning Setting 0           */
  uint32 ulTATLS1;                      /* TX Descriptor Address Table Learning Setting 1           */
  uint32 ulTATLR;                       /* TX Descriptor Address Table Learning Result              */
  uint32 Reserved2;                     /* Reserved                                                 */
  uint32 ulRATLS0;                      /* RX Descriptor Address Table Learning Setting 0           */
  uint32 ulRATLS1;                      /* RX Descriptor Address Table Learning Setting 1           */
  uint32 ulRATLR;                       /* RX Descriptor Address Table Learning Result              */
  uint32 Reserved3;                     /* Reserved                                                 */
  Eth_ETND_TSDRegType stTSD[16];       /* TS Regs                                                  */
  uint32 ulTRCR[8];                     /* Transmission Request Configuration Register i            */
  uint32 Reserved4[8];                  /* Reserved                                                 */
  uint32 ulRIDAUAS[8];                  /* RX Incremental Data Area Used Area Size                  */
  uint32 Reserved5[24];                 /* Reserved                                                 */
  uint32 ulRR;                          /* RAM Reset                                                */
  uint32 Reserved6[3];                  /* Reserved                                                 */
  uint32 ulTATS;                        /* TX Descriptor Address Table Searching                    */
  uint32 ulTATSR0;                      /* TX Descriptor Address Table Searching Result 0           */
  uint32 ulTATSR1;                      /* TX Descriptor Address Table Searching Result 1           */
  uint32 ulTATSR2;                      /* TX Descriptor Address Table Searching Result 2           */
  uint32 ulRATS;                        /* RX Descriptor Address Table Searching                    */
  uint32 ulRATSR0;                      /* RX Descriptor Address Table Searching Result 0           */
  uint32 ulRATSR1;                      /* RX Descriptor Address Table Searching Result 1           */
  uint32 ulRATSR2;                      /* RX Descriptor Address Table Searching Result 2           */
  uint32 Reserved7[4];                  /* Reserved                                                 */
  Eth_ETND_RIDRegType stRID[8];        /* RX Regs                                                  */
  uint32 Reserved8[16];                 /* Reserved                                                 */
  uint32 ulEIS0;                        /* Error Interrupt Status 0                                 */
  uint32 ulEIE0;                        /* Error Interrupt Enable 0                                 */
  uint32 ulEID0;                        /* Error Interrupt Disable 0                                */
  uint32 Reserved9;                     /* Reserved                                                 */
  uint32 ulEIS1;                        /* Error Interrupt Status 1                                 */
  uint32 ulEIE1;                        /* Error Interrupt Enable 1                                 */
  uint32 ulEID1;                        /* Error Interrupt Disable 1                                */
  uint32 Reserved10[9];                 /* Reserved                                                 */
  Eth_ETND_TCERegType stTXDCEI[8];     /* TX Descriptor Configuration Error Interrupt Regs         */
  uint32 Reserved11[64];                /* Reserved                                                 */
  Eth_ETND_RFSRegType stRXFSEI[8];     /* RX Frame Size Error Interrupt Regs                       */
  Eth_ETND_RFERegType stRXDFEI[8];     /* RX Descriptor Full Error Interrupt Regs                  */
  Eth_ETND_RCERegType stRXDCEI[8];     /* RX Descriptor Configuration Error Interrupt Regs         */
  uint32 ulRIDAOIS;                     /* RX Incremental Data Area Overflow Interrupt Error        */
  uint32 ulRIDAOIE;                     /* RX Incremental Data Area Overflow Interrupt Enable       */
  uint32 ulRIDAOID;                     /* RX Incremental Data Area Overflow Interrupt Disable      */
  uint32 Reserved12[29];                /* Reserved                                                 */
  uint32 ulTSFEIS;                      /* TS Descriptor Full Error Interrupt Status                */
  uint32 ulTSFEIE;                      /* TS Descriptor Full Error Interrupt Enable                */
  uint32 ulTSFEID;                      /* TS Descriptor Full Error Interrupt Disable               */
  uint32 Reserved13;                    /* Reserved                                                 */
  uint32 ulTSCEIS;                      /* TS Descriptor Configuration Error Interrupt Status       */
  uint32 ulTSCEIE;                      /* TS Descriptor Configuration Error Interrupt Enable       */
  uint32 ulTSCEID;                      /* TS Descriptor Configuration Error Interrupt Disable      */
  uint32 Reserved14[265];               /* Reserved                                                 */
  uint32 ulDIS;                         /* Data Interrupt Status                                    */
  uint32 ulDIE;                         /* Data Interrupt Enable                                    */                  /* PRQA S 1710 # JV-01 */
  uint32 ulDID;                         /* Data Interrupt Disable                                   */
  uint32 Reserved15;                    /* Reserved                                                 */
  Eth_ETND_TDIRegType stTXDI[8];        /* TX Descriptor Data Interrupt Regs                        */
  Eth_ETND_RDIRegType stRXDI[8];        /* RX Descriptor Data Interrupt Regs                        */
  uint32 ulTSDIS;                       /* TS Descriptor Data Interrupt Status                      */
  uint32 ulTSDIE;                       /* TS Descriptor Data Interrupt Enable                      */
  uint32 ulTSDID;                       /* TS Descriptor Data Interrupt Disable                     */
} Eth_ETND_AXIBMIRegType;

typedef struct STag_Eth_ETND_QCISRegType
{
  uint32 ulQSTMACUs;                    /* CONFIG/OPERATION                  */
  uint32 ulQSTMACDs;                    /* CONFIG/OPERATION                  */
  uint32 ulQSTMAMUs;                    /* CONFIG/OPERATION                  */
  uint32 ulQSTMAMDs;                    /* CONFIG/OPERATION                  */
  uint32 ulQSFTVLs;                     /* CONFIG/OPERATION                  */
  uint32 ulQSFTVLMs;                    /* CONFIG/OPERATION                  */
  uint32 ulQSFTMSDs;                    /* CONFIG/OPERATION                  */
  uint32 ulQSFTGMIs;                    /* CONFIG/OPERATION                  */
} Eth_ETND_QCISRegType;

typedef struct STag_Eth_ETND_MHDRegType
{
  uint32 ulOCR;                         /* Any                               */
  uint32 ulOSR;                         /* N/A                               */
  uint32 ulSWR;                         /* DISABLE                           */
  uint32 ulSIS;                         /* N/A                               */
  uint32 ulGIS;                         /* Any                               */
  uint32 ulGIE;                         /* Any                               */
  uint32 ulGID;                         /* Any                               */
  uint32 Reserved0;                     /* Reserved                          */
  uint32 ulTIS1;                        /* Any                               */
  uint32 ulTIE1;                        /* Any                               */
  uint32 ulTID1;                        /* Any                               */
  uint32 Reserved1;                     /* Reserved                          */
  uint32 ulTIS2;                        /* Any                               */
  uint32 ulTIE2;                        /* Any                               */
  uint32 ulTID2;                        /* Any                               */
  uint32 Reserved2;                     /* Reserved                          */
  uint32 ulRIS;                         /* Any                               */
  uint32 ulRIE;                         /* Any                               */
  uint32 ulRID;                         /* Any                               */
  uint32 Reserved3;                     /* Reserved                          */
  uint32 ulTGC1;                        /* CONFIG                            */
  uint32 ulTGC2;                        /* CONFIG                            */
  uint32 Reserved4[2];                  /* Reserved                          */
  uint32 ulTFS[4];                      /* CONFIG                            */
  uint32 ulTCF[4];                      /* CONFIG                            */
  uint32 ulTCR1;                        /* CONFIG                            */
  uint32 ulTCR2;                        /* CONFIG                            */
  uint32 ulTCR3;                        /* CONFIG                            */
  uint32 ulTCR4;                        /* CONFIG                            */
  uint32 ulTMS[8];                      /* CONFIG                            */
  uint32 ulTSR1;                        /* N/A                               */
  uint32 ulTSR2;                        /* N/A                               */
  uint32 ulTSR3;                        /* N/A                               */
  uint32 ulTSR4;                        /* N/A                               */
  uint32 ulTSR5;                        /* N/A                               */
  uint32 Reserved5[3];                  /* Reserved                          */
  uint32 ulRGC;                         /* CONFIG                            */
  uint32 ulRDFCR;                       /* CONFIG                            */
  uint32 ulRCFCR;                       /* CONFIG                            */
  uint32 ulREFCNCR;                     /* CONFIG                            */
  uint32 ulRSR1;                        /* N/A                               */
  uint32 ulRSR2;                        /* N/A                               */
  uint32 ulRSR3;                        /* N/A                               */
  uint32 Reserved6[61];                 /* Reserved                          */
  uint32 ulTCIS;                        /* Any                               */
  uint32 ulTCIE;                        /* Any                               */
  uint32 ulTCID;                        /* Any                               */
  uint32 Reserved7;                     /* Reserved                          */
  uint32 ulTPTPC;                       /* CONFIG                            */
  uint32 ulTTML;                        /* CONFIG                            */
  uint32 ulTTJ;                         /* CONFIG                            */
  uint32 Reserved8;                     /* Reserved                          */
  uint32 ulTCC;                         /* CONFIG/OPERATION                  */
  uint32 ulTCS;                         /* CONFIG/OPERATION                  */
  uint32 Reserved9;                     /* Reserved                          */
  uint32 ulTGS;                         /* CONFIG/OPERATION                  */
  uint32 ulTACST0;                      /* CONFIG/OPERATION                  */
  uint32 ulTACST1;                      /* CONFIG/OPERATION                  */
  uint32 ulTACST2;                      /* CONFIG/OPERATION                  */
  uint32 Reserved10;                    /* Reserved                          */
  uint32 ulTALIT0;                      /* CONFIG/OPERATION                  */
  uint32 ulTALIT1;                      /* CONFIG/OPERATION                  */
  uint32 ulTALIT2;                      /* CONFIG/OPERATION                  */
  uint32 Reserved11;                    /* Reserved                          */
  uint32 ulTAEN[2];                     /* CONFIG/OPERATION                  */
  uint32 Reserved12[2];                 /* Reserved                          */
  uint32 ulTASFE;                       /* CONFIG/OPERATION                  */
  uint32 Reserved13[3];                 /* Reserved                          */
  uint32 ulTACLL0;                      /* CONFIG/OPERATION                  */
  uint32 ulTACLL1;                      /* CONFIG/OPERATION                  */
  uint32 ulTACLL2;                      /* CONFIG/OPERATION                  */
  uint32 Reserved14;                    /* Reserved                          */
  uint32 ulCACC;                        /* CONFIG/OPERATION                  */
  uint32 ulCCS;                         /* CONFIG/OPERATION                  */
  uint32 Reserved15[2];                 /* Reserved                          */
  uint32 ulCAIV[8];                     /* CONFIG/OPERATION                  */
  uint32 ulCAUL[8];                     /* CONFIG/OPERATION                  */
  uint32 Reserved16[20];                /* Reserved                          */
  uint32 ulTOCST0;                      /* N/A                               */
  uint32 ulTOCST1;                      /* N/A                               */
  uint32 ulTOCST2;                      /* N/A                               */
  uint32 Reserved17;                    /* Reserved                          */
  uint32 ulTOLIT0;                      /* N/A                               */
  uint32 ulTOLIT1;                      /* N/A                               */
  uint32 ulTOLIT2;                      /* N/A                               */
  uint32 Reserved18;                    /* Reserved                          */
  uint32 ulTOEN0;                       /* N/A                               */
  uint32 ulTOEN1;                       /* N/A                               */
  uint32 Reserved19[2];                 /* Reserved                          */
  uint32 ulTOSFE;                       /* N/A                               */
  uint32 Reserved20[3];                 /* Reserved                          */
  uint32 ulTCLR0;                       /* N/A                               */
  uint32 ulTCLR1;                       /* N/A                               */
  uint32 ulTCLR2;                       /* N/A                               */
  uint32 Reserved21;                    /* Reserved                          */
  uint32 ulTSMS;                        /* N/A                               */
  uint32 Reserved22[3];                 /* Reserved                          */
  uint32 ulCOCC;                        /* N/A                               */
  uint32 Reserved23[19];                /* Reserved                          */
  uint32 ulCOIV[8];                     /* N/A                               */
  uint32 ulCOUL[8];                     /* N/A                               */
  uint32 Reserved24[4];                 /* Reserved                          */
  Eth_ETND_QCISRegType stQCIS[16];     /* CONFIG/OPERATION                  */
  uint32 ulQSFTLS;                      /* N/A                               */
  uint32 ulQSFTLIS;                     /* Any                               */
  uint32 ulQSFTLIE;                     /* Any                               */
  uint32 ulQSFTLID;                     /* Any                               */
  uint32 ulQSMSMC;                      /* CONFIG/OPERATION                  */
  uint32 ulQSGTMC;                      /* CONFIG/OPERATION                  */
  uint32 ulQSEIS;                       /* Any                               */
  uint32 ulQSEIE;                       /* Any                               */
  uint32 ulQSEID;                       /* Any                               */
  uint32 Reserved25[3];                 /* Reserved                          */
  uint32 ulQGACST0;                     /* CONFIG/OPERATION                  */
  uint32 ulQGACST1;                     /* CONFIG/OPERATION                  */
  uint32 ulQGACST2;                     /* CONFIG/OPERATION                  */
  uint32 ulQGALIT0;                     /* CONFIG/OPERATION                  */
  uint32 ulQGALIT1;                     /* CONFIG/OPERATION                  */
  uint32 ulQGALIT2;                     /* CONFIG/OPERATION                  */
  uint32 ulQGAEN0;                      /* CONFIG/OPERATION                  */
  uint32 ulQGAEN1;                      /* CONFIG/OPERATION                  */
  uint32 ulQGIGS;                       /* CONFIG/OPERATION                  */
  uint32 ulQGJC;                        /* CONFIG/OPERATION                  */
  uint32 ulQGTL;                        /* CONFIG/OPERATION                  */
  uint32 ulQGSE;                        /* CONFIG/OPERATION                  */
  uint32 ulQGCC;                        /* CONFIG/OPERATION                  */
  uint32 ulQGATL0;                      /* CONFIG/OPERATION                  */
  uint32 ulQGATL1;                      /* CONFIG/OPERATION                  */
  uint32 ulQGATL2;                      /* CONFIG/OPERATION                  */
  uint32 ulQGOCST0;                     /* N/A                               */
  uint32 ulQGOCST1;                     /* N/A                               */
  uint32 ulQGOCST2;                     /* N/A                               */
  uint32 ulQGOLIT0;                     /* N/A                               */
  uint32 ulQGOLIT1;                     /* N/A                               */
  uint32 ulQGOLIT2;                     /* N/A                               */
  uint32 ulQGOEN0;                      /* N/A                               */
  uint32 ulQGOEN1;                      /* N/A                               */
  uint32 ulQGTR0;                       /* CONFIG/OPERATION                  */
  uint32 ulQGTR1;                       /* CONFIG/OPERATION                  */
  uint32 ulQGTR2;                       /* N/A                               */
  uint32 ulQGFSMS;                      /* N/A                               */
  uint32 Reserved26[16];                /* Reserved                          */
  uint32 ulQTMIS;                       /* Any                               */
  uint32 ulQTMIE;                       /* Any                               */
  uint32 ulQTMID;                       /* Any                               */
  uint32 ulQTEIS;                       /* Any                               */
  uint32 ulQTEIE;                       /* Any                               */
  uint32 ulQTEID;                       /* Any                               */
  uint32 Reserved27[2];                 /* Reserved                          */
  uint32 ulQMEC;                        /* CONFIG/OPERATION                  */
  uint32 ulQMMC;                        /* CONFIG/OPERATION                  */
  uint32 ulQRFDC;                       /* CONFIG/OPERATION                  */
  uint32 ulQYFDC;                       /* CONFIG/OPERATION                  */
  uint32 ulQVTCMC[16];                  /* CONFIG/OPERATION                  */
  uint32 ulQMCBSC[16];                  /* CONFIG/OPERATION                  */
  uint32 ulQMCIRC[16];                  /* CONFIG/OPERATION                  */
  uint32 ulQMEBSC[16];                  /* CONFIG/OPERATION                  */
  uint32 ulQMEIRC[16];                  /* CONFIG/OPERATION                  */
  uint32 ulQMCFC;                       /* CONFIG/OPERATION                  */
  uint32 Reserved28[3];                 /* Reserved                          */
  uint32 ulQMEIS;                       /* Any                               */
  uint32 ulQMEIE;                       /* Any                               */
  uint32 ulQMEID;                       /* Any                               */
  uint32 Reserved29;                    /* Reserved                          */
  uint32 ulQSMFC[16];                   /* N/A                               */
  uint32 ulQMSPPC[16];                  /* N/A                               */
  uint32 ulQMSRPC[16];                  /* N/A                               */
  uint32 ulQGPPC[8];                    /* N/A                               */
  uint32 ulQGRPC[8];                    /* N/A                               */
  uint32 ulQMDPC[16];                   /* N/A                               */
  uint32 ulQMGPC[16];                   /* N/A                               */
  uint32 ulQMYPC[16];                   /* N/A                               */
  uint32 ulQMRPC[16];                   /* N/A                               */
  uint32 ulMQSTMACU;                    /* N/A                               */
  uint32 ulMQSTMACD;                    /* N/A                               */
  uint32 ulMQSTMAMU;                    /* N/A                               */
  uint32 ulMQSTMAMD;                    /* N/A                               */
  uint32 ulMQSFTVL;                     /* N/A                               */
  uint32 ulMQSFTVLM;                    /* N/A                               */
  uint32 ulMQSFTMSD;                    /* N/A                               */
  uint32 ulMQSFTGMI;                    /* N/A                               */
  uint32 Reserved30[92];                /* Reserved                          */
  #if (ETH_DEVICE_NAME == ETH_U5X)
  uint32 Reserved33;                    /* Reserved                          */
  uint32 Reserved31[7];                 /* Reserved                          */
  uint32 Reserved34;                    /* Reserved                          */
  uint32 Reserved35;                    /* Reserved                          */
  uint32 Reserved36;                    /* Reserved                          */
  uint32 Reserved37;                    /* Reserved                          */
  uint32 Reserved38;                    /* Reserved                          */
  uint32 Reserved32[3];                 /* Reserved                          */
  uint32 Reserved39;                    /* Reserved                          */
  uint32 Reserved40;                    /* Reserved                          */
  uint32 Reserved41;                    /* Reserved                          */
  uint32 Reserved42;                    /* Reserved                          */
  uint32 Reserved43;                    /* Reserved                          */
  #else /* X2x Devices */
  uint32 ulDCR;                         /* Any                               */
  uint32 Reserved31[7];                 /* Reserved                          */
  uint32 ulTDRRR;                       /* Any                               */
  uint32 ulTDRRD;                       /* Any                               */
  uint32 ulTCRRR;                       /* Any                               */
  uint32 ulTCRRD;                       /* Any                               */
  uint32 ulTCD;                         /* N/A                               */
  uint32 Reserved32[3];                 /* Reserved                          */
  uint32 ulRDRRR;                       /* Any                               */
  uint32 ulRDRRD;                       /* Any                               */
  uint32 ulRCRRR;                       /* Any                               */
  uint32 ulRCRRD;                       /* Any                               */
  uint32 ulVRR;                         /* Any                               */
  #endif
} Eth_ETND_MHDRegType;

typedef struct STag_Eth_ETND_GPTPCFGRegType
{
  uint32 ulGTIVt;                       /* Any                               */
  uint32 ulGTOVt0;                      /* Any                               */
  uint32 ulGTOVt1;                      /* Any                               */
  uint32 ulGTOVt2;                      /* Any                               */
  uint32 ulGAVTPt;                      /* Any                               */
  uint32 ulGCTt0;                       /* Any                               */
  uint32 ulGCTt1;                       /* Any                               */
  uint32 ulGCTt2;                       /* Any                               */
} Eth_ETND_GPTPCFGRegType;

typedef struct STag_Eth_ETND_GPTPCMPRegType
{
  uint32 ulTCDg;                        /* Any                               */
  uint32 ulTCMg;                        /* Any                               */
  uint32 ulGTMg;                        /* Any                               */
  uint32 ulTLSCVg;                      /* Any                               */
  uint32 ulTNVg;                        /* Any                               */
  uint32 ulTPVg;                        /* Any                               */
  uint32 ulTFFCECg;                     /* Any                               */
  uint32 ulTCSTg;                       /* Any                               */
} Eth_ETND_GPTPCMPRegType;

typedef struct STag_Eth_ETND_GPTPDBGRegType
{
  #if (ETH_DEVICE_NAME == ETH_U5X)
  uint32 Reserved0;                     /* Reserved                          */
  uint32 Reserved1;                     /* Reserved                          */
  #else /* X2x Devices */
  uint32 ulTCDFRg;                      /* When debug_mode signal is 1       */
  uint32 ulTCDFRRg;                     /* When debug_mode signal is 1       */
  #endif
} Eth_ETND_GPTPDBGRegType;

typedef struct STag_Eth_ETND_GPTMARegType                                                                               /* PRQA S 3630 # JV-01 */
{
  uint32 ulTME;                         /* Any                               */
  uint32 ulTMD;                         /* Any                               */
  uint32 Reserved0[2];                  /* Reserved                          */
  Eth_ETND_GPTPCFGRegType stGptpCfg[8]; /* 0x0810 - 0x090F                   */
  uint32 Reserved1[64];                 /* Reserved                          */
  Eth_ETND_GPTPCMPRegType stGptpCmp[8]; /* 0x0A10 - 0x0B0F                   */
  uint32 Reserved2[64];                 /* Reserved                          */
  uint32 ulGIS;                         /* Any                               */
  uint32 ulGIE;                         /* Any                               */
  uint32 ulGID;                         /* Any                               */
  uint32 Reserved3;                     /* Reserved                          */
  #if (ETH_DEVICE_NAME == ETH_U5X)
  Eth_ETND_GPTPDBGRegType Reserved4[8]; /* Reserved                          */
  #else /* X2x Devices */
  Eth_ETND_GPTPDBGRegType stGptpDbg[8]; /* When debug_mode signal is 1       */
  #endif
} Eth_ETND_GPTMARegType;

typedef struct STag_Eth_ETND_ESRegType                                                                                  /* PRQA S 3630 # JV-01 */
{
  Eth_ETND_AXIBMIRegType stAXIBMI;     /* AXIBMI regs                       */
  uint32 Reserved0[249];               /* Reserved                          */
  Eth_ETND_MHDRegType stMHD;           /* MHD regs                          */
  uint32 Reserved1[235];               /* Reserved                          */
  Eth_ETND_RMACSRegType stRMACSys;     /* RMACSys & RMAC regs               */
} Eth_ETND_ESRegType;

typedef struct STag_Eth_ETND_PWRCTLRegType
{
  #if (ETH_ETND_SGMII_SUPPORT == STD_ON)
  uint32 ulETNDzSGSDS;                 /* <PWRCTLz_base> + 0000H            */
  uint32 ulETNDzSGCLKSEL;              /* <PWRCTLz_base> + 0004H            */
  uint32 ulETNDzSGRCIE;                /* <PWRCTLz_base> + 0008H            */
  #else
  uint32 Reserved0;                    /* Reserved                          */
  uint32 ulETNDzSGCLKSEL;              /* <PWRCTLz_base> + 0004H            */
  uint32 Reserved1;                    /* Reserved                          */
  #endif
} Eth_ETND_PWRCTLRegType;

#if (ETH_ETND_SGMII_SUPPORT == STD_ON)
typedef struct STag_Eth_ETND_SGMIIRegType                                                                               /* PRQA S 3630 # JV-01 */
{
  uint32 ulETNDzSGOPMC;                /* <SGMIIz_base> + 0000H             */
  uint32 ulETNDzSGOPMS;                /* <SGMIIz_base> + 0004H             */
  uint32 ulETNDzSGSRST;                /* <SGMIIz_base> + 0008H             */
  uint32 ulETNDzSGINTS;                /* <SGMIIz_base> + 000CH             */
  uint32 ulETNDzSGINTM;                /* <SGMIIz_base> + 0010H             */
  uint32 ulETNDzSGLTVC;                /* <SGMIIz_base> + 0014H             */
  uint32 ulETNDzSGCECT;                /* <SGMIIz_base> + 0018H             */
  uint32 ulETNDzSGRECT;                /* <SGMIIz_base> + 001CH             */
  uint32 Reserved0[120];                /* Reserved                          */
  Eth_ETND_PWRCTLRegType stPWRCTL;     /* PWRCTL regs                       */
} Eth_ETND_SGMIIRegType;
#endif

typedef struct STag_Eth_ETND_RegType
{
  volatile Eth_ETND_ESRegType *pES[ETH_TOTAL_CTRL_CONFIG];
  #if (ETH_ETND_SGMII_SUPPORT == STD_ON)
  volatile Eth_ETND_SGMIIRegType *pSGMII;
  #endif
  volatile Eth_ETND_GPTMARegType *pGPTMA;
} Eth_ETND_RegType;

typedef struct STag_Eth_ETND_EICRegType
{
  uint16 usINTETNDw0;                    /* CPU data request 0 (TX[0,4]/RX[0,4]/TS) */
  uint16 usINTETNDw1;                    /* CPU data request 1 (TX[1,5]/RX[1,5])    */
  uint16 usINTETNDw2;                    /* CPU data request 2 (TX[2,6]/RX[0,6])    */
  uint16 usINTETNDw3;                    /* CPU data request 3 (TX[3,7]/RX[0,7])    */
  uint16 usINTETNDw4;                    /* MDIO related PHY control                */
  uint16 usINTETNDw5;                    /* MagicPacket/LPI                         */
  uint16 usINTETNDw6;                    /* General                                 */
  uint16 usINTETNDw7;                    /* GPTP interrupt                          */
} Eth_ETND_EICRegType;

/***********************************************************************************************************************
**                                                 Macro Functions                                                    **
***********************************************************************************************************************/

#define ETH_NS2HZ(nano_sec) ((ETH_CPUCLK_MHZ * (uint32) (nano_sec)) / 1000UL)                                           /* PRQA S 3472 # JV-01 */

/* Caculate gPTP timer increment value */
#define ETH_GPTP_SET_GTIV(clock_hz) \
  ((uint32)0x08000000 * ((uint32)1000000000 / (uint32) clock_hz))

/* AXI Transmit Status */
#define ETH_GET_TDIS_STAT(val, offset)\
  ((uint32) (val) & (0x000000FFUL << (uint32) (offset)))

#define ETH_GET_TX_INT_STAT(que, val, offset)\
  ((uint32) (val) & ((1UL << (uint32) (que)) << (uint32) (offset)))

/* AXI Receive Status */
#define ETH_GET_RX_INT_STAT(que, val, offset)                                                                           /* PRQA S 3472 # JV-01 */\
  ((uint32) (val) & ((1UL << (uint32) (que)) << (uint32) (offset)))

/* Rx descriptor full Status */
#define ETH_GET_RX_FULL_INT_STAT(que, val, offset)                                                                      /* PRQA S 3472 # JV-01 */\
  ((uint32) (val) & ((1UL << (uint32) (que)) << (uint32) (offset)))

#define ETH_FLOAT64_RIGHT_SHIFT_32(base) ((float64)base / (float64)4294967296.0)
#define ETH_FLOAT64_RIGHT_SHIFT_64(base) ((float64)ETH_FLOAT64_RIGHT_SHIFT_32(base) / (float64)4294967296.0)

/*
 * TACST0.ACSTUP[13:0]
 * Admin cycle start time upper part.
 * Nanosecond upper part from which the first cycle of a new configuration should start.
 *
 * TACST0 = ((base / 2^32) / 2^32) - (((base / 2^32) / 2^32) / 2^14) *  2^14
 * Note:
 *   4294967296 = 2^32
 *   (1)   ((base / 2^32) / 2^32)                 <=> (base >> 32) >> 32                  <=> number over bit 64
 *   (2.1) (((base / 2^32) / 2^32) / 2^14)        <=> (((base >> 32) >> 32) >> 14)        <=> number over bit (64+14)
 *   (2.2) (((base / 2^32) / 2^32) / 2^14) * 2^14 <=> (((base >> 32) >> 32) >> 14) << 14  <=> fill 14 bit with 0
 *   TACST0 = (1) - (2.2) => get the 14-bit-number from the bit 64 of the base. [78...64]
 * Since float/float = float, so convert the value of (((base >> 32) >> 32) >> 14) to usigned long long to get the
 * interger part. The result before converted is not exceed the maximum range of type "unsigned long long".
 */
#define ETH_CALC_TAS_TACST0(base)                                                                                       /* PRQA S 3472 # JV-01 */\
  ((uint32)(ETH_FLOAT64_RIGHT_SHIFT_64(base) - \
            ((uint64)(ETH_FLOAT64_RIGHT_SHIFT_64(base) / (float64)16384.0) * (float64)16384.0)))

/*
 * TACST1.ACSTMP[31:0]
 * Admin cycle start time middle part
 * Nanosecond middle part from which the first cycle of a new configuration should start.
 *
 * TACST1 = (base / 2^32) - ((base / 2^32) / 2^32) * 2^32
 * Note:
 *   (1)   (base / 2^32)                 <=> (base >> 32)                <=> number over bit 32
 *   (2.1) ((base / 2^32) / 2^32)        <=> ((base >> 32) >> 32)        <=> number over bit (32+32)
 *   (2.2) ((base / 2^32) / 2^32) * 2^32 <=> ((base >> 32) >> 32) << 32  <=> fill 32 bit with 0
 *   TACST1 = (1) - (2.2) => get the 32-bit-number from the bit 32 of the base. [63...32]
 * Since float/float = float, so convert the value of ((base >> 32) >> 32) to usigned long long to get the interger part
 * The result before converted is not exceed the maximum range of type "unsigned long long".
 */
#define ETH_CALC_TAS_TACST1(base)                                                                                       /* PRQA S 3472 # JV-01 */\
  ((uint32)(ETH_FLOAT64_RIGHT_SHIFT_32(base)  - \
            ((uint64)(ETH_FLOAT64_RIGHT_SHIFT_32(base) / (float64)4294967296.0) * (float64)4294967296.0)))

/*
 * TACST2.ACSTLP[31:0]
 * Admin cycle start time lower part
 * Nanosecond lower part from which the first cycle of a new configuration should start.
 *
 * TACST2 = base - (base / 2^32) * 2^32
 *
 * Note:
 *   (1)   base                 <=> base                <=> number over bit 0
 *   (2.1) (base / 2^32)        <=> (base >> 32)        <=> number over (32)bit
 *   (2.2) (base / 2^32) * 2^32 <=> (base >> 32) << 32  <=> fill 32 bit with 0
 *   TACST1 = (1) - (2.2) => get the 32-bit-number from the bit 0 of the base. [31...0]
 * Since float/float = float, so convert the value of (base >> 32) to usigned long long to get the interger part
 * The result before converted is not exceed the maximum range of type "unsigned long long".
 */
#define ETH_CALC_TAS_TACST2(base)                                                                                       /* PRQA S 3472 # JV-01 */\
  ((uint32)(((float64)base) - ((uint64)((float64)base / (float64)4294967296.0) * (float64)4294967296.0)))

/* Mask patterns to be used for the register corruption checking */
#define ETH_ETNDE_ECMR_CHECK_MASK 0x04BF02C3UL

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
#define ETH_START_SEC_CONST_32
#include "Eth_MemMap.h"

/* Variable store pointer to register address */
extern CONST(Eth_ETND_RegType, ETH_CONFIG_DATA) Eth_GstETND_Regs;

#define ETH_STOP_SEC_CONST_32
#include "Eth_MemMap.h"
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwInit(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#if defined(ETH_HW_DEINIT)
#if (ETH_DEINIT_API == STD_ON)
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwDeInit(
    CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(boolean, AUTOMATIC) ForceReset);
#endif
#endif
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwDisableController(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwEnableController(CONST(uint32, AUTOMATIC) LulCtrlIdx);

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwTransmit(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
                   CONST(uint32, AUTOMATIC) LulLenByte, CONST(boolean, AUTOMATIC) LblConfirmation);

#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETND_HwGetCounterValues(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                           CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounterPtr);                         /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_RX_STATS_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetRxStats(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                     CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpRxStats);                                  /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_TX_STATS_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetTxStats(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                     CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpTxStats);                                  /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetTxErrorCounterValues(
    CONST(uint32, AUTOMATIC) LulCtrlIdx,
    CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpTxErrorCounterValues);                         /* PRQA S 3432 # JV-01 */
#endif
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwMainFunction(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwTxConfirmation(CONST(uint32, AUTOMATIC) LulCtrlIdx);

#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwCheckFifoIndex(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx);
#endif

extern FUNC(Eth_RxStatusType, ETH_PRIVATE_CODE)
    Eth_ETND_HwReceive(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx);

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_MHD_ModeSetting(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulMode);

extern FUNC(Eth_ExtRxStatusType, ETH_PRIVATE_CODE)
  Eth_RxQueueProcess(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx);

extern FUNC(TickType, ETH_PRIVATE_CODE)
  Eth_ETND_GetElapsedTimeValue(P2VAR(TickType, AUTOMATIC, ETH_APPL_DATA) LusTimeOutCount);                              /* PRQA S 3432 # JV-01 */

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TxDescLearning(
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs,
  CONST(uint32, AUTOMATIC) LulEntryNum,
  CONST(uint32, AUTOMATIC) LulChainAddr);

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
  Eth_ETND_HwSetIncrementTimeForGptp(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIncVal);

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
  Eth_ETND_HwSetOffsetTimeForGptp(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                             CONSTP2CONST(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeOffsetPtr);

FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwGetCurrentTime(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                         CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                     /* PRQA S 3432 # JV-01 */
                         CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                       /* PRQA S 3432 # JV-01 */

FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwGetCurrentTimeTuple(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                              P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) LpCurrentTimeTuplePtr);                    /* PRQA S 3432 # JV-01 */

FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwGetEgressTimeStamp(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx,
                             CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                 /* PRQA S 3432 # JV-01 */
                             CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                   /* PRQA S 3432 # JV-01 */

FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwGetIngressTimeStamp(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                              CONSTP2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpDataPtr,
                              CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                /* PRQA S 3432 # JV-01 */
                              CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                  /* PRQA S 3432 # JV-01 */

#endif
#if (ETH_CTRL_ENABLE_MII == STD_ON)
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwReadMii(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
                   CONST(uint8, AUTOMATIC) LucRegIdx, CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr);        /* PRQA S 3432 # JV-01 */
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETND_HwWriteMii(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
                   CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusRegVal);
#endif

extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETND_ResetRxDesc(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                  CONSTP2CONST(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode);

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#endif /* !ETH_ETND_LLDRIVER_H_ */
#endif /* ETH_MACRO_ETND == STD_ON */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
