/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Serdes_LLDriver.h                                                                               */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Ethernet SERDES specific definitions of                                                         */
/* Eth Driver Component.                                                                                              */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.22: 16/09/2025   : Update correct macro vesion
 * 1.1.21: 19/11/2024   : Update new macro value: ETH_SERDES_MASK_BIT4, ETH_SERDES_MASK_BIT8
 * 1.0.1: 21/12/2023    : Define macro for RSW3:
 *                        change ETH_SERDES_CH_NUM value to 8UL
 * 1.0.0: 16/08/2023    : Initial Version
 */
/**********************************************************************************************************************/

#ifndef Eth_SERDES_LLDRIVER_H
#define Eth_SERDES_LLDRIVER_H

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth_Util.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_SERDES_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_RSW3_SERDES_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_RSW3_SERDES_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_RSW3_SERDES_SW_MAJOR_VERSION  ETH_SW_MAJOR_VERSION
#define ETH_RSW3_SERDES_SW_MINOR_VERSION  ETH_SW_MINOR_VERSION


/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3472)    : All toplevel uses of this function-like macro look like they could be replaced by            */
/*                       equivalent function calls.                                                                   */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                   SERDES Channel                                                   **
***********************************************************************************************************************/
#define ETH_SERDES_CH_NUM      8UL
#define ETH_SERDES_XPCS_CH0    0UL
#define ETH_SERDES_XPCS_CH1    1UL
#define ETH_SERDES_XPCS_CH2    2UL
#define ETH_SERDES_XPCS_CH3    3UL
#define ETH_SERDES_XPCS_CH4    4UL
#define ETH_SERDES_XPCS_CH5    5UL
#define ETH_SERDES_XPCS_CH6    6UL
#define ETH_SERDES_XPCS_CH7    7UL

/***********************************************************************************************************************
**                                           SERDES Register Offset Address                                           **
***********************************************************************************************************************/
#define ETH_SERDES_OFS_H0000   0x0000U
#define ETH_SERDES_OFS_H0004   0x0004U
#define ETH_SERDES_OFS_H0008   0x0008U
#define ETH_SERDES_OFS_H0014   0x0014U
#define ETH_SERDES_OFS_H001C   0x001CU
#define ETH_SERDES_OFS_H0028   0x0028U
#define ETH_SERDES_OFS_H0040   0x0040U
#define ETH_SERDES_OFS_H0080   0x0080U
#define ETH_SERDES_OFS_H00C4   0x00C4U
#define ETH_SERDES_OFS_H00C8   0x00C8U
#define ETH_SERDES_OFS_H00D0   0x00D0U
#define ETH_SERDES_OFS_H00D8   0x00D8U
#define ETH_SERDES_OFS_H00DC   0x00DCU
#define ETH_SERDES_OFS_H00F8   0x00F8U
#define ETH_SERDES_OFS_H0144   0x0144U
#define ETH_SERDES_OFS_H0148   0x0148U
#define ETH_SERDES_OFS_H0150   0x0150U
#define ETH_SERDES_OFS_H0160   0x0160U
#define ETH_SERDES_OFS_H0170   0x0170U
#define ETH_SERDES_OFS_H0174   0x0174U
#define ETH_SERDES_OFS_H01A0   0x01A0U
#define ETH_SERDES_OFS_H01AC   0x01ACU
#define ETH_SERDES_OFS_H01C0   0x01C0U
#define ETH_SERDES_OFS_H01C4   0x01C4U
#define ETH_SERDES_OFS_H01C8   0x01C8U
#define ETH_SERDES_OFS_H01CC   0x01CCU
#define ETH_SERDES_OFS_H01D0   0x01D0U
#define ETH_SERDES_OFS_H01D4   0x01D4U
#define ETH_SERDES_OFS_H01D8   0x01D8U
#define ETH_SERDES_OFS_H01DC   0x01DCU
#define ETH_SERDES_OFS_H01E0   0x01E0U
#define ETH_SERDES_OFS_H0244   0x0244U
#define ETH_SERDES_OFS_H0248   0x0248U
#define ETH_SERDES_OFS_H0258   0x0258U
#define ETH_SERDES_OFS_H0260   0x0260U
#define ETH_SERDES_OFS_H026C   0x026CU
#define ETH_SERDES_OFS_H03C0   0x03C0U
#define ETH_SERDES_OFS_H03D0   0x03D0U
#define ETH_SERDES_OFS_H03D4   0x03D4U
#define ETH_SERDES_OFS_H00C0   0x00C0U
#define ETH_SERDES_OFS_H0100   0x0100U
#define ETH_SERDES_OFS_H0180   0x0180U

/***********************************************************************************************************************
**                                                 SERDES BANK Value                                                  **
***********************************************************************************************************************/
#define ETH_SERDES_BANKVAL_H0180    0x0180U
#define ETH_SERDES_BANKVAL_H0300    0x0300U
#define ETH_SERDES_BANKVAL_H0380    0x0380U
#define ETH_SERDES_BANKVAL_H1F00    0x1F00U
#define ETH_SERDES_BANKVAL_H1F80    0x1F80U

/***********************************************************************************************************************
**                                                 Mask macro                                                         **
***********************************************************************************************************************/
#define ETH_SERDES_MASK_BIT4    0x00000010UL
#define ETH_SERDES_MASK_BIT8    0x00000100UL
#define ETH_BIT(n)                  (uint32)(1UL << (uint32)(n))

/***********************************************************************************************************************
**                                                 Register Accessor                                                  **
***********************************************************************************************************************/
#define ETH_SERDES_SEL_BANK(ch, value) \
          {*(volatile uint32*)Eth_GaaSerdesBankAddr[ch] = (uint32)value;}
#define ETH_SERDES_REG_WRITE(ch, offset, value) \
          {*(volatile uint32*)(Eth_GaaSerdesBaseAddr[ch] + (uint16)offset) = (uint32)value;}
#define ETH_SERDES_REG_READ(ch, offset) \
          (*(volatile uint32*)(Eth_GaaSerdesBaseAddr[ch] + (uint16)offset))
#define ETH_SERDES_SET_BIT(ch, offset, mask) \
          {*(volatile uint32*)(Eth_GaaSerdesBaseAddr[ch] + (uint16)offset) |= (uint32)mask;}
#define ETH_SERDES_CLEAR_BIT(ch, offset, mask) \
          {*(volatile uint32*)(Eth_GaaSerdesBaseAddr[ch] + (uint16)offset) &= ~(uint32)mask;}

#define ETH_SERDES_WRITE(ch, bank, offset, value)                                                                       /* PRQA S 3472 # JV-01 */\
do {                                                                                                     \
    (*(volatile uint32*)(Eth_GaaSerdesBankAddr[ch])) = (uint32)(bank);                                   \
    (*(volatile uint32*)((uint32)(Eth_GaaSerdesBaseAddr[ch] + (uint16)(offset)))) = (uint32)(value);     \
} while(0)

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_Initialize(CONST(uint32, AUTOMATIC) LulChannel);

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#endif /* !ETH_SERDES_LLDRIVER_H_ */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
