/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_Ram.h                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Ethernet driver global variables and the                                                        */
/* Ram Allocation functions                                                                                           */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.24: 29/06/2026  :  Move declare Eth_GaaRsw3PortValid, Eth_GaaRsw3PortCtrlIdx, Eth_GstDescChainMap
 *                        to CONFIG_DATA_POSTBUILD_UNSPECIFIED, for support generate these variable in gentool
 * 1.1.23: 16/09/2025  :  Update to support TSN-ES
 * 1.1.22: 25/07/2025  :  Remove macro for old AUTOSAR version.
 * 1.1.21: 03/07/2025  :  Move Eth_GaaRsw3PortCtrlIdx into section VAR_NO_INIT_32
 * 1.1.20: 12/03/2025  :  Update to merging SingleMainline
 *                        + Remove function Eth_RSW_CheckProvideBuffer, Eth_RSW_CheckBufferWithPiority
 *                        + Add function Eth_RSW_GetImmTxBuffer
 * 1.1.19: 12/09/2024  :  Update to support zero TX buffer
 * 1.0.3: 28/07/2024   :  Add new arrays Eth_Ctrl<n>_TxBufferData, Eth_Ctrl<n>_RxBufferData, Eth_Ctrl<n>_TxDescData,
 *                        Eth_Ctrl<n>_RxDescData, Eth_Ctrl<n>_TxBufferNode, Eth_Ctrl<n>_RxBufferNode,
 *                        Eth_GaaRxBufferTotal.
 *                        Add new array of pointers Eth_GaaTxBufferNodes, Eth_GaaTxBufferDataTable, Eth_GaaTxDescTable
 *                        Eth_GaaRxBufferDataTable, Eth_GaaRxDescTable, Eth_GaaRxBufferNodes.
 *                        Remove unnecessary array Eth_GaaHeap, Eth_GaaRamSize, Eth_GaaMemPoolBuffer_<n>
 *                        Eth_GaaMemPoolBufferTable.
 *                        Add function prototype for Eth_CheckBufferWithPiority
 * 1.0.2: 04/03/2024    : Replace Eth_GpGwcaRegPtr by Eth_GpGwcaCfgPtr, Add Eth_GawcaValid
 *                        Add ETH_BOTHCORE_ENABLE conditional to enable/disable Eth_GpBothCoreCfgPtr.
 * 1.0.1: 24/11/2023    : Update to fix QAC violation
 *                        Re-define Eth_GaaSerdesChConfig range using ETH_SERDES_CH_NUM
 * 1.0.0: 16/08/2023    : Initial Version
 */

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/
#ifndef ETH_RSW3_RAM_H
#define ETH_RSW3_RAM_H
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for utility definitions */
#include "Eth_Common_LLDriver.h"

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_RAM_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_RSW3_RAM_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_RSW3_RAM_AR_RELEASE_REVISION_VERSION  ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_RSW3_RAM_SW_MAJOR_VERSION  ETH_SW_MAJOR_VERSION
#define ETH_RSW3_RAM_SW_MINOR_VERSION  ETH_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

/* Global variable to store pointer to Configuration */
extern P2CONST(Eth_GlobalPauseConfiguration, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpGlobalPauseCfgPtr;             /* PRQA S 3432 # JV-01 */

#if (ETH_BOTHCORE_ENABLE == STD_ON)
extern P2CONST(Eth_BothCoreConfiguration, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpBothCoreCfgPtr;                   /* PRQA S 3432 # JV-01 */
#endif /* ETH_BOTHCORE_ENABLE */

extern P2CONST(Eth_GwcaConfiguration, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpGwcaCfgPtr;                           /* PRQA S 3432 # JV-01 */

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
extern P2VAR(Eth_TSDescType, ETH_VAR_FAST_NO_INIT, ETH_VAR_FAST_NO_INIT) Eth_GpNextTsDesc;                              /* PRQA S 3432 # JV-01 */
#endif

#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

extern VAR(boolean, ETH_VAR_INIT)Eth_GaaRsw3GWCACtrlValid;

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

extern VAR(uint8, ETH_VAR_INIT)Eth_GaaGWCAValid[ETH_RSW3_GWCA_TOTAL_CONFIGURED];

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"
extern VAR(uint32, ETH_VAR_INIT) Eth_GulRxMaxFrameSize;
#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"

/* LINKFIX table */
extern VAR(Eth_LinkDescType, ETH_VAR_NO_INIT) Eth_GaaLinkFixTable[ETH_RACE_AXI_CHAIN_N];

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/* Timestamp descriptor chain */
extern VAR(Eth_TSDescType, ETH_VAR_NO_INIT) Eth_GaaTsDescChain[ETH_MAX_TS_DESCRIPTOR + ETH_CYCLIC_DESC_NUM];
#endif

#define ETH_STOP_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

extern CONST(boolean, ETH_CONFIG_DATA)Eth_GaaRsw3PortValid[ETH_RACE_PORT_N];

extern CONST(uint32, ETH_CONFIG_DATA) Eth_GaaRsw3PortCtrlIdx[ETH_RACE_PORT_N];

/* Descriptor Chain information Map table */
extern CONST(Eth_DescChainMap, ETH_CONFIG_DATA) Eth_GstDescChainMap;

#define ETH_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

/* Tx Desc Data */
extern P2VAR(Eth_ExtTxDirDescType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxDescTable[ETH_TOTAL_CTRL_CONFIG];              /* PRQA S 3432 # JV-01 */

/* Rx Desc Data */
extern P2VAR(Eth_ExtRxEthDescType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxDescTable[ETH_TOTAL_CTRL_CONFIG];              /* PRQA S 3432 # JV-01 */

extern P2CONST(Eth_EthConfigType, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GaaSerdesChConfig[ETH_SERDES_CH_NUM];       /* PRQA S 3432 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

/* Function pointer variable for RSW Unit configuration */
extern VAR(Eth_HwFuncTableType, ETH_VAR_INIT) Eth_RswFunc;

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

/***********************************************************************************************************************
**                                                   Macro Defines                                                    **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_InitializeBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_PreprocessBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(BufReq_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_GetTxBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint8*, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr);                                                             /* PRQA S 3432 # JV-01 */
extern FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_RSW_GetImmTxBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                                    /* PRQA S 3432 # JV-01 */
  CONST(uint16, AUTOMATIC) LusFrameLength);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_ReleaseTxBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_PreprocessFrame(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulFrameType,
  CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen);                                                           /* PRQA S 3432 # JV-01 */

extern FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE) Eth_RSW_FindTxBufferHandler(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulBufIdx);

extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_RamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
#endif /* ETH_RSW3_RAM_H  */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/

