/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_LLDriver.h                                                                                 */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains RSW3 specific definitions of Eth Driver Component.                                              */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.30: 29/06/2026   : Update struct Eth_DescChainMap to change aaChainInfo and ucValidChainId from array to P2CONST
 * 1.1.29: 26/03/2026   : Update to add macro ETH_RSW3_RMAC_MXGMIIC_RXBFM_MASK, ETH_RSW3_RMAC_MXGMIIC_RXBFM_FORCE_IDLE
 * 1.1.28: 18/11/2025   : Update Eth_StatsRegValueType to remove: ulMRXBCEU, ulMRXBCEL, ulMRXBCPU, ulMRXBCPL, ulMRFC
 *                        Update Eth_StatsRegValueType to add: ulMRGFCE, ulMRGFCP
 *                        Add macro ETH_TX_DESCR_TSUN_ETHA_INDICATE_MASK, ETH_TX_DESCR_TSUN_GWCA_ID_MASK,
 *                        ETH_TX_DESCR_TSUN_ETHA_INDICATE_BIT, ETH_TX_DESCR_TSUN_GWCA_ID_BIT
 *                        Update Eth_TSDescType to correct size for ulSpn, ulDpn
 * 1.1.27: 16/09/2025   : Update to support TSN-ES
 *                      : Move macro ETH_MAX_TS_DESCRIPTOR to gentool generated output
 *                      : Update Eth_RxConfigType, to remove redudant element enPauseFrameRecv
 * 1.1.26: 25/07/2025   : Remove macro for old AUTOSAR version.
 *                      : Update ulReserved2 to ulReserved2[3] for Eth_RSW3_TOPRegType
 * 1.1.25: 18/07/2025   : Remove unused ulGateLatency, ulGateJitter in Eth_RSW3ConfigType
 *                        Add volatile for ulDt of Eth_BasicDescType
 *                        Improve Link Verification
 * 1.1.24: 03/07/2025   : Add macro ETH_GPTP_PTPTIVC_BIT0_TO_BIT26 and ETH_GPTP_PTPTIVC_BIT27_TO_BIT31 to write into
 *                        PTPTIVC.TIVt with a common approach, instead of fixed value.
 *                        Add cache support.
 * 1.1.23: 09/06/2025   : Add ETH_RSW3_RMAC_MIOC_BIT3, ETH_RSW3_RMAC_MRAFC_ENABLE
 * 1.1.22: 13/03/2025   : Update to merging SingleMainline
 *                        + Commonize the type Eth_TxBufferType, Eth_BufHandlerType, Eth_RxFrameType,
 *                        Eth_RxBufManageType and move these type from Eth_<HWIP>_LLDriver.h to Eth_Types.h
 *         07/03/2025   : Update register MTATCt to Reserve2 in Eth_RSW3_RMACRegType
 * 1.1.20: 18/10/2024   : Update some macro to follow HW TS0.40
 * 1.1.18: 13/08/2024   : Update value for macro ETH_MAX_RX_FRAME_LENGTH
 *                        Remove macro ETH_TX_PAYLOAD_PADDING, ETH_RX_PAYLOAD_PADDING
 * 1.1.17: 28/07/2024   : Update data type for Eth_BufHandlerType, define new macro ETH_MAX_TX_FRAME_LENGTH,
 *                        ETH_MAX_RX_FRAME_LENGTH
 *                        Add new data type Eth_RxBufManageType
 * 1.1.16: 29/06/2024   : Update new datatype TimeStampType, TimeStampQualType
 * 1.0.3: 24/03/2024    : Correct ulReserved6 in STag_Eth_RSW3_RMACRegType
 * 1.0.2: 21/12/2023    : Define macro error interrupt
 *                        remove uneccesary register
 * 1.0.1: 24/11/2023    : Update to fix QAC violation
 * 1.0.0: 16/08/2023    : Initial Version
 */

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0635)    : Bit-field %1s in %2s has been declared with a type not explicitly supported.                 */
/* Rule                : CERTCCM INT12, MSC14, MISRA C:2012 Dir-1.1,  Rule-1.2, Rule-6.1                              */
/*                       REFERENCE - ISO:C90-6.5.2.1 Structure and Union Specifiers - Semantics                       */
/* JV-01 Justification : To access bit wise from register.                                                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0750)    : A union type specifier has been defined.                                                     */
/* Rule                : CWE Rule CWE-843,  MISRA C:2012 Rule-19.2                                                    */
/* JV-01 Justification : This union type is used for register accessing and there is no issue with this usage.        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0791)    : Macro identifier does not differ from other macro identifier(s) (e.g. '%1s') within the      */
/*                       specified number of significant characters.                                                  */
/* Rule                : CERTCCM DCL23, MISRA C:2012 Rule-5.4                                                         */
/*                       REFERENCE - ISO:C90-6.1.2 Identifiers - Implementation Limits                                */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule (Symbolic Name or Published         */
/*                       Macro's name), so this is accepted.                                                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions and do not conflict in linkage.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1753)    : The function '' with external linkage is declared but not defined within this project.       */
/* Rule                : MISRA-C:2012                                                                                 */
/* JV-01 Justification : This function is declare for user specify the calling function so this is accepted.          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3472)    : All toplevel uses of this function-like macro look like they could be replaced by            */
/*                       equivalent function calls.                                                                   */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3630)    : The implementation of this struct/union type should be hidden.                               */
/* Rule                :  MISRA C:2012 Dir-4.8                                                                        */
/* JV-01 Justification : This is accepted. Redundant of struct or union type has no affect to driver operation.       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/
#ifndef ETH_RSW3_LLDRIVER_H
#define ETH_RSW3_LLDRIVER_H

#include "Eth_Util.h"
#include "Os.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_RSW3_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_RSW3_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_RSW3_SW_MAJOR_VERSION  ETH_SW_MAJOR_VERSION
#define ETH_RSW3_SW_MINOR_VERSION  ETH_SW_MINOR_VERSION
/***********************************************************************************************************************
**                                                Switching Mode type                                                 **
***********************************************************************************************************************/
#define ETH_SWMODE_ENDSTATION                           0
#define ETH_SWMODE_SWITCH                               1

/***********************************************************************************************************************
**                                                Cache supported                                                     **
***********************************************************************************************************************/
#define ETH_DCACHE                                      STD_ON

/* Cache Line size */
#define ETH_CACHE_LINE_SIZE     (uint32)(32)
/* TxRx buffer length cache align */
#define ETH_BUF_LEN_CACHE_ALIGN(x) \
  (((uint32)x) + \
  (ETH_CACHE_LINE_SIZE - ((uint32)x % ETH_CACHE_LINE_SIZE)))
extern void CR7_Invalidate_DCache_By_Addr(uint32 start_addr, uint32 size);                                              /* PRQA S 1753 # JV-01 */
extern void CR7_Flush_DCache_By_Addr(uint32 start_addr, uint32 size);                                                   /* PRQA S 1753 # JV-01 */
/***********************************************************************************************************************
**                            HW specific parameters referred from the upper-level driver                             **
***********************************************************************************************************************/
#define ETH_CPUCLK_MHZ          1066UL
#define ETH_NS2HZ(nano_sec)     ((ETH_CPUCLK_MHZ * (nano_sec)) / 1000UL)                                                /* PRQA S 3472 # JV-01 */
#define ETH_HZ2NS(clock_hz)     (1000000000UL / (clock_hz))

/* Caculate gPTP timer increment value */
#define ETH_GPTP_SET_PTPTIVC_50MHZ             0xA0000000UL
#define ETH_GPTP_SET_PTPTIVC_100MHZ            0x50000000UL
#define ETH_GPTP_SET_PTPTIVC_200MHZ            0x28000000UL
#define ETH_GPTP_SET_PTPTIVC_320MHZ            0x19000000UL
#define ETH_GPTP_SET_PTPTIVC_400MHZ            0x14000000UL
#define ETH_GPTP_SET_PTPTIVC_356250000HZ       0x1674C59DUL
#define ETH_GPTP_SET_PTPTIVC_712500000HZ       0x0B3A62CEUL

/*
 * HWUM gPTP:
 *   + section 3.3.2.3 PTPTIVCt (t=0..PTP_TN-1) 
 *   + section 5. Functional details, 5.1.1 gPTP timer t
 * Timer increment value in ns per clock clk.
 *    PTPTIVCt.TIVt[31:27] is the nanosecond part and
 *    PTPTIVCt.TIVt[26:0] is the nanosecond sub-part
 * HWUM Notes: "Notes: Exp 3.125 -> 3 and 0.125 * 2^27"
 *   => the integer part (= 3) will be TIVt[31:27], the fractional part (= 0.125) TIVt[26:0]
 *      with this note as an example of clock frequency 320MHz,
 *      then convert to clock period with 10^3/320(MHz)=3.125 or 10^9/320000000(Hz)
 *   => PTPTIVCt.TIVt = (3 << 27) | (0.125 * 2^27) = 419430400 = 0x19000000
 */

/* Formula to get the fractional part of 10^9/clk_in_hz:
 *      (10^9 mod clk_in_hz) / clk_in_hz
 * TIVt[26:0] will be:
 *      ((10^9 mod clk_in_hz) / clk_in_hz) * 2^27
 * Note:
 *   1. (((uint64)A << 32) / (uint64)B): "<< 32" and cast with (uint64), calculation in uint64 increases accuracy
 *   2. (1) << 27: "<< 27" performs multiplication with 2^27
 *   3. (2) >> 32: ">> 32" left shift to return to original uint32
 */
#define ETH_GPTP_PTPTIVC_BIT0_TO_BIT26(clk_freq_hz)                                                                     /* PRQA S 3472 # JV-01 */ \
    ((uint32)((((((uint64)(1000000000UL % (clk_freq_hz))) << 32) / (uint64)(clk_freq_hz)) << 27) >> 32))

/* Get the integer part of 10^9/clk_in_hz:
 *      (uint32)(10^9 / clk_in_hz)
 * TIVt[31:27] will be:
 *      (uint32)(10^9 / clk_in_hz) << 27
 */
#define ETH_GPTP_PTPTIVC_BIT27_TO_BIT31(clk_freq_hz)                                                                    /* PRQA S 3472 # JV-01 */ \
    ((uint32)((uint32)(1000000000UL / (clk_freq_hz)) << 27))

/* Minimum payload length allowed by the HW */
#define ETH_MIN_PAYLOAD_SIZE            2UL

/* Maximum payload size without GWCA's frame splitting */
#define ETH_GWCA_MAX_PAYLOAD_SIZE       2048UL

/* gPTP timer MAX Ctroler */
#define ETH_GPTP_MAX_CTRLS_SUPPORTED           2UL

/* Use gPTP timer domain 1 */
#define ETH_GPTP_TIMER_DOMAIN           0U

/* Use AVTP timer domain 1 */
#define ETH_AVTP_TIMER_DOMAIN           0U

/* Enable gPTP timer domain 1 */
#define ETH_GPTP_TIMER_DOMAIN_ENABLE   1UL
#define ETH_GPTP_TIMER_DOMAIN_MASK     (1UL << ETH_GPTP_TIMER_DOMAIN)

#define ETH_GPTP_OFFSET_NANOSEC_MAXVALUE 0x3B9AC9FFUL

/***********************************************************************************************************************
**                                                  Descriptor Types                                                  **
***********************************************************************************************************************/
#define ETH_DESC_LINKFIX          0U
#define ETH_DESC_FEMPTY_ND        3U
#define ETH_DESC_FEMPTY           4U
#define ETH_DESC_FSINGLE          8U
#define ETH_DESC_FSTART           9UL
#define ETH_DESC_FMID             10UL
#define ETH_DESC_FEND             11UL
#define ETH_DESC_LEMPTY           12UL
#define ETH_DESC_LINK             14U
#define ETH_DESC_EOS              15UL

/***********************************************************************************************************************
**                                             Descriptor Attribute Types                                             **
***********************************************************************************************************************/
#define ETH_TX_DESCR_TSUN_OFFSET  16UL   /* offset = 256 / maximum port */
#define ETH_TX_DESCR_TSUN_ETHA_INDICATE_MASK    0x80UL   /* bit 7 */
#define ETH_TX_DESCR_TSUN_GWCA_ID_MASK          0x40UL   /* bit 6 */
#define ETH_TX_DESCR_TSUN_ETHA_INDICATE_BIT     7U                                                                      /* PRQA S 0791 # JV-01 */
#define ETH_TX_DESCR_TSUN_GWCA_ID_BIT           6U

#define ETH_TX_DESC_TYPE_DIRECT               1UL
#define ETH_TX_DESC_TCX_ENABLE                1UL
#define ETH_TX_DESC_DIE_ENABLE                1UL
#define ETH_RX_DESC_DIE_ENABLE                1UL
#define ETH_TS_DESC_DIE_ENABLE                1UL

/***********************************************************************************************************************
**                                                 Size of descriptor                                                 **
***********************************************************************************************************************/
#define ETH_BASIC_DESC_SIZE        8UL    /* Basic descriptor size(in byte) */
#define ETH_TS_DESC_SIZE          16UL    /* Timestamp descriptor size(in byte) */
#define ETH_EXT_TX_DIR_DESC_SIZE       16UL    /* Extended TX Direct descriptor size(in byte) */
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
#define ETH_EXT_RX_ETH_TS_DESC_SIZE    24UL    /* Extended RX Ethernet TimeStamp descriptor size(in byte) */
#define ETH_EXT_RX_ETH_DESC_SIZE       ETH_EXT_RX_ETH_TS_DESC_SIZE
#else
#define ETH_EXT_RX_ETH_DESC_SIZE       16UL    /* Extended RX Ethernet descriptor size(in byte) */
#endif

/***********************************************************************************************************************
**                                         General Ethernet MAC Address Size                                          **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Descriptor related                                                 **
***********************************************************************************************************************/
#define ETH_CYCLIC_DESC_NUM               1U

/***********************************************************************************************************************
** Number of Tx/Rx queues
***********************************************************************************************************************/
#define ETH_TXQ_NUM               8UL     /* Number of tx queue per port */
#define ETH_RXQ_NUM               32UL     /* Number of rx queue per port */

/***********************************************************************************************************************
** Maximum frame length supports macro
***********************************************************************************************************************/

/***********************************************************************************************************************
** Number of Tx/Rx queues
***********************************************************************************************************************/
#define ETH_TAS_ENTRY_NUM     8UL       /* Maximum TAS entry number */

/***********************************************************************************************************************
** Mask for the Status Register
***********************************************************************************************************************/

/* GWCA Mode values in GWMC register */
#define ETH_RSW3_GWCA_RESET_MODE       0x00000000UL
#define ETH_RSW3_GWCA_DISABLE_MODE     0x00000001UL
#define ETH_RSW3_GWCA_CONFIG_MODE      0x00000002UL
#define ETH_RSW3_GWCA_OPERATION_MODE   0x00000003UL

/* ETHA Mode values in EAMC register */
#define ETH_RSW3_ETHA_RESET_MODE       0x00000000UL
#define ETH_RSW3_ETHA_DISABLE_MODE     0x00000001UL
#define ETH_RSW3_ETHA_CONFIG_MODE      0x00000002UL
#define ETH_RSW3_ETHA_OPERATION_MODE   0x00000003UL

/* MAC reception frame size configuration for e-frames */

/* MAC reception frame size configuration for p-frames */

/* MAC Timestamp reception configuration */

/* MAC reception address filter configuration */

/* AXI Transmit Status */

/* AXI Receive Status */

/* Rx descriptor full Status */

/***********************************************************************************************************************
**                                                        RSW3                                                        **
***********************************************************************************************************************/
/* R-ACE parameters for X5H and depended parameter */
#define ETH_RACE_AXI_CHAIN_N            128UL
#define ETH_RACE_PORT_TSNA_N            13UL
#define ETH_RACE_PORT_GWCA_N            2UL
#define ETH_RACE_LTH_REMAP_N            32UL
#define ETH_RACE_PTP_TN                 2UL
#define ETH_RACE_PFL_TWBF_N             512UL
#define ETH_RACE_PFL_FOBF_N             512UL
#define ETH_RACE_PFL_RAGF_N             128UL
#define ETH_RACE_PFL_CADF_N             512UL
#define ETH_RACE_PFL_CFMF_N             7UL
#define ETH_RACE_PSFP_GATE_N            8UL
#define ETH_RACE_PAS_LVL_N              2UL
#define ETH_RACE_PORT_N                 (ETH_RACE_PORT_TSNA_N+ETH_RACE_PORT_GWCA_N)
#define ETH_RACE_PSFP_MTR_N             105UL
#define ETH_GWCA_AXI_RINC_N             8UL
#define ETH_GWCA_AXI_TLIM_N             32UL
#define ETH_GWCA_FRM_PRIO_N             8UL
#define ETH_ETHA_FRM_PRIO_N             8UL
#define ETH_MEDIA_CAPT_N                2UL
#define ETH_MEDIA_CAPT_ADD_N            15UL
#define ETH_MEDIA_RECV_N                2UL
#define ETH_CYC_COMP_N                  8UL
#define ETH_RACE_AXI_CHAIN_RLMIN_N      96UL /* Need re-check since this parameter not found in HWUM */
#define ETH_RMAC_PORT_N                 12UL

#define ETH_RACE_PORT_TSNA0             0x00000001UL /* BIT 0*/
#define ETH_RACE_PORT_TSNA1             0x00000002UL /* BIT 1*/
#define ETH_RACE_PORT_TSNA2             0x00000004UL /* BIT 2*/
#define ETH_RACE_PORT_TSNA3             0x00000008UL /* BIT 3*/
#define ETH_RACE_PORT_TSNA4             0x00000010UL /* BIT 4*/
#define ETH_RACE_PORT_TSNA5             0x00000020UL /* BIT 5*/
#define ETH_RACE_PORT_TSNA6             0x00000040UL /* BIT 6*/
#define ETH_RACE_PORT_TSNA7             0x00000080UL /* BIT 7*/
#define ETH_RACE_PORT_TSNA8             0x00000100UL /* BIT 8*/
#define ETH_RACE_PORT_TSNA9             0x00000200UL /* BIT 9*/
#define ETH_RACE_PORT_TSNA10            0x00000400UL /* BIT 10*/
#define ETH_RACE_PORT_TSNA11            0x00000800UL /* BIT 11*/
#define ETH_RACE_PORT_TSNA12            0x00001000UL /* BIT 12*/
#define ETH_RACE_PORT_ETHA0             ETH_RACE_PORT_TSNA0
#define ETH_RACE_PORT_ETHA1             ETH_RACE_PORT_TSNA1
#define ETH_RACE_PORT_ETHA2             ETH_RACE_PORT_TSNA2
#define ETH_RACE_PORT_ETHA3             ETH_RACE_PORT_TSNA3
#define ETH_RACE_PORT_ETHA4             ETH_RACE_PORT_TSNA4
#define ETH_RACE_PORT_ETHA5             ETH_RACE_PORT_TSNA5
#define ETH_RACE_PORT_ETHA6             ETH_RACE_PORT_TSNA6
#define ETH_RACE_PORT_ETHA7             ETH_RACE_PORT_TSNA7
#define ETH_RACE_PORT_ETHA8             ETH_RACE_PORT_TSNA8
#define ETH_RACE_PORT_ETHA9             ETH_RACE_PORT_TSNA9
#define ETH_RACE_PORT_ETHA10            ETH_RACE_PORT_TSNA10
#define ETH_RACE_PORT_ETHA11            ETH_RACE_PORT_TSNA11
#define ETH_RACE_PORT_ETHA12            ETH_RACE_PORT_TSNA12

#define ETH_RACE_PORT_GWCA0             0x00002000UL
#define ETH_RACE_PORT_GWCA1             0x00004000UL
#define ETH_RACE_PORT_ACPA0             0x00008000UL
#define ETH_RACE_PORT_ALL               ( \
                                          ETH_RACE_PORT_TSNA0 | \
                                          ETH_RACE_PORT_TSNA1 | \
                                          ETH_RACE_PORT_TSNA2 | \
                                          ETH_RACE_PORT_TSNA3 | \
                                          ETH_RACE_PORT_TSNA4 | \
                                          ETH_RACE_PORT_TSNA5 | \
                                          ETH_RACE_PORT_TSNA6 | \
                                          ETH_RACE_PORT_TSNA7 | \
                                          ETH_RACE_PORT_TSNA8 | \
                                          ETH_RACE_PORT_TSNA9 | \
                                          ETH_RACE_PORT_TSNA10| \
                                          ETH_RACE_PORT_TSNA11| \
                                          ETH_RACE_PORT_TSNA12| \
                                          ETH_RACE_PORT_GWCA0 | \
                                          ETH_RACE_PORT_GWCA1 )
#define ETH_RACE_PORT_GWCA              ETH_RACE_PORT_GWCA0
#define ETH_RACE_PORT_NULL              0x00000000UL

#define ETH_RACE_ID_GWCA0               0U
#define ETH_RACE_ID_GWCA1               1U
#define ETH_RACE_ID_ETHA0               0U
#define ETH_RACE_ID_ETHA1               1U
#define ETH_RACE_ID_ETHA2               2U
#define ETH_RACE_ID_ETHA3               3U
#define ETH_RACE_ID_ETHA4               4U
#define ETH_RACE_ID_ETHA5               5U
#define ETH_RACE_ID_ETHA6               6U
#define ETH_RACE_ID_ETHA7               7U
#define ETH_RACE_ID_ETHA8               8U
#define ETH_RACE_ID_ETHA9               9U
#define ETH_RACE_ID_ETHA10              10U
#define ETH_RACE_ID_ETHA11              11U
#define ETH_RACE_ID_ETHA12              12U
#define ETH_RACE_ID_RMAC0               0U
#define ETH_RACE_ID_RMAC1               1U
#define ETH_RACE_ID_RMAC2               2U

#define ETH_CONV_ETHAID_TO_PORTID(id)   (id)                                                                            /* PRQA S 3472 # JV-01 */
#define ETH_CONV_RMACID_TO_PORTID(id)   (id)                                                                            /* PRQA S 3472 # JV-01 */
#define ETH_CONV_GWCAID_TO_PORTID(id)   (uint32)(ETH_RACE_PORT_TSNA_N + id)
#define ETH_CONV_PORTID_TO_ETHAID(id)   (id)                                                                            /* PRQA S 3472 # JV-01 */
#define ETH_CONV_PORTID_TO_RMACID(id)   (id)                                                                            /* PRQA S 3472 # JV-01 */
#define ETH_CONV_PORTID_TO_GWCAID(id)   (uint32)(id - ETH_RACE_PORT_TSNA_N)

/* Port type */
#define ETH_RSW3_PORT_TYPE_GWCA         0UL
#define ETH_RSW3_PORT_TYPE_ETHA         1UL

#define ETH_MAX_GWCA_SUPPORTED          ETH_RACE_PORT_GWCA_N
#define ETH_MAX_TSNA_SUPPORTED          ETH_RACE_PORT_TSNA_N
#define ETH_MAX_RMAC_SUPPORTED          ETH_RACE_PORT_TSNA_N
#define ETH_MAX_TSNES_SUPPORTED         8UL

#define ETH_RSW3_SETCYCLE_START         (uint64)1500000000U
#define ETH_RSW3_64_TO_32_SHIFT         (uint64)32U

/* Hwip type */
#define ETH_RSW3_HWIP_TYPE_GWCA         0x0FFFFFFFUL
#define ETH_RSW3_HWIP_TYPE_ETHA         0x1FFFFFFFUL
#define ETH_RSW3_HWIP_TYPE_TSNES        0x2FFFFFFFUL
/* Hwip unit */
#define ETH_RSW3_HWIP_UNIT_GWCA0        (uint32)((ETH_RSW3_HWIP_TYPE_GWCA  - 0x0FFFFFFFUL) + 0UL)
#define ETH_RSW3_HWIP_UNIT_GWCA1        (uint32)((ETH_RSW3_HWIP_TYPE_GWCA  - 0x0FFFFFFFUL) + 1UL)
#define ETH_RSW3_HWIP_UNIT_ETHA0        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 0UL)
#define ETH_RSW3_HWIP_UNIT_ETHA1        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 1UL)
#define ETH_RSW3_HWIP_UNIT_ETHA2        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 2UL)
#define ETH_RSW3_HWIP_UNIT_ETHA3        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 3UL)
#define ETH_RSW3_HWIP_UNIT_ETHA4        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 4UL)
#define ETH_RSW3_HWIP_UNIT_ETHA5        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 5UL)
#define ETH_RSW3_HWIP_UNIT_ETHA6        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 6UL)
#define ETH_RSW3_HWIP_UNIT_ETHA7        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 7UL)
#define ETH_RSW3_HWIP_UNIT_ETHA8        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 8UL)
#define ETH_RSW3_HWIP_UNIT_ETHA9        (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 9UL)
#define ETH_RSW3_HWIP_UNIT_ETHA10       (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 10UL)
#define ETH_RSW3_HWIP_UNIT_ETHA11       (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 11UL)
#define ETH_RSW3_HWIP_UNIT_ETHA12       (uint32)((ETH_RSW3_HWIP_TYPE_ETHA  - 0x0FFFFFFFUL) + 12UL)
#define ETH_RSW3_HWIP_UNIT_TSNES0       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 0UL)
#define ETH_RSW3_HWIP_UNIT_TSNES1       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 1UL)
#define ETH_RSW3_HWIP_UNIT_TSNES2       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 2UL)
#define ETH_RSW3_HWIP_UNIT_TSNES3       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 3UL)
#define ETH_RSW3_HWIP_UNIT_TSNES4       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 4UL)
#define ETH_RSW3_HWIP_UNIT_TSNES5       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 5UL)
#define ETH_RSW3_HWIP_UNIT_TSNES6       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 6UL)
#define ETH_RSW3_HWIP_UNIT_TSNES7       (uint32)((ETH_RSW3_HWIP_TYPE_TSNES - 0x0FFFFFFFUL) + 7UL)
/* Get Hwip unit index, get the last 28 bits of hwip unit */
#define ETH_CONV_HWIP_UNIT_INDEX(hwip_unit) ((uint32)((hwip_unit) & 0x0FFFFFFFUL))

/***********************************************************************************************************************
**                                                        TOP                                                         **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                        COMA                                                        **
***********************************************************************************************************************/
#define ETH_RSW3_COMA_RCEC_RCE          0x00010000UL
#define ETH_RSW3_COMA_CABPIRM_BPIOG     0x00000001UL
#define ETH_RSW3_COMA_CABPIRM_BPR       0x00000002UL
#define ETH_RSW3_COMA_CABPPCM_RPC_MASK  0x00003FFFUL
#define ETH_RSW3_COMA_CABPPCM_LCL_PTR_N 0x000003CFUL /* 8192UL */

#if (ETH_COMA_ERR_ISR == STD_ON)
#define ETH_RSW3_COMA_CAEIE0_BPECCEE    0x00000004UL
#define ETH_RSW3_COMA_CAEIE0_DSECCEE    0x00000002UL
#define ETH_RSW3_COMA_CAEIE0_PECCEE     0x00000001UL
#define ETH_RSW3_COMA_ECC_ERROR_MASK    ( ETH_RSW3_COMA_CAEIE0_BPECCEE | \
                                          ETH_RSW3_COMA_CAEIE0_DSECCEE | \
                                          ETH_RSW3_COMA_CAEIE0_PECCEE )
#endif /* (ETH_COMA_ERR_ISR == STD_ON) */

/***********************************************************************************************************************
**                                                        MFWD                                                        **
***********************************************************************************************************************/
#define ETH_RSW3_MFWD_FWPC1_DDE             0x00000001UL
#define ETH_RSW3_MFWD_FWPC1_DDSL            0x00000002UL
#define ETH_RSW3_MFWD_FWPC1_DDE_DDSL_MASK   (ETH_RSW3_MFWD_FWPC1_DDE | ETH_RSW3_MFWD_FWPC1_DDSL)
#define ETH_RSW3_MFWD_FWVLANTIM_VLANTIOG    0x00000001UL
#define ETH_RSW3_MFWD_FWVLANTIM_VLANTR      0x00000002UL
#define ETH_RSW3_MFWD_FWLTHTIM_LTHTIOG      0x00000001UL
#define ETH_RSW3_MFWD_FWLTHTIM_LTHTR        0x00000002UL
#define ETH_RSW3_MFWD_FWMACTIM_MACTIOG      0x00000001UL
#define ETH_RSW3_MFWD_FWMACTIM_MACTR        0x00000002UL
#define ETH_RSW3_MFWD_FWL23UTIM_L23UTIOG    0x00000001UL
#define ETH_RSW3_MFWD_FWL23UTIM_L23UTR      0x00000002UL
#define ETH_RSW3_MFWD_FWPGFRIM_GFRIOG       0x00000001UL
#define ETH_RSW3_MFWD_FWPGFRIM_GFRR         0x00000002UL
/*********
** GWCA **
*********/
#define ETH_RSW3_GWCA0                  0UL
#define ETH_RSW3_GWCA1                  1UL

#define ETH_RSW3_GWCA_GWDCC_RX          0x00000000UL   /* BIT 11: 1'b0 */
#define ETH_RSW3_GWCA_GWDCC_TX          0x00000800UL   /* BIT 11: 1'b1 */
#define ETH_RSW3_GWCA_GWDCC_ETS         0x00000200UL
#define ETH_RSW3_GWCA_GWDCC_EDE         0x00000100UL
#define ETH_RSW3_GWCA_GWDCC_BALR        0x01000000UL
#define ETH_RSW3_GWCA_GWDCC_DCP_MASK    0x00070000UL

#define ETH_RSW3_GWCA_GWDCC_DCP_SET(priority) ((priority << 16UL) & ETH_RSW3_GWCA_GWDCC_DCP_MASK)

#define ETH_RSW3_GWCA_GWMTIRM_MTIOG     0x00000001UL
#define ETH_RSW3_GWCA_GWMTIRM_MTR       0x00000002UL
#define ETH_RSW3_GWCA_GWARIRM_ARIOG     0x00000001UL
#define ETH_RSW3_GWCA_GWARIRM_ARR       0x00000002UL
#define ETH_RSW3_GWCA_GWMS_OPS_MASK     0x00000003UL

/* Need re-check since this parameter not found in HWUM */
#define ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG                      32UL

#if ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON))
#define ETH_GWCA_ERR_ISR                STD_ON
#define ETH_RSW3_GWCA_GWEIE0_L23UECCEE  0x00000100UL
#define ETH_RSW3_GWCA_GWEIE0_TSECCEE    0x00000080UL
#define ETH_RSW3_GWCA_GWEIE0_AECCEE     0x00000040UL
#define ETH_RSW3_GWCA_GWEIE0_MECCEE     0x00000020UL
#define ETH_RSW3_GWCA_GWEIE0_DSECCEE    0x00000010UL
#define ETH_RSW3_GWCA_GWEIE0_PECCEE     0x00000008UL
#define ETH_RSW3_GWCA_GWEIE0_TECCEE     0x00000004UL
#define ETH_RSW3_GWCA_GWEIE0_DECCEE     0x00000002UL
#define ETH_RSW3_GWCA_GWEIE0_AEE        0x00000001UL
#define ETH_RSW3_GWCA_DMA_ERROR_MASK    ( ETH_RSW3_GWCA_GWEIE0_AEE )
#define ETH_RSW3_GWCA_ECC_ERROR_MASK    ( ETH_RSW3_GWCA_GWEIE0_L23UECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_TSECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_AECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_MECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_DSECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_PECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_TECCEE | \
                                          ETH_RSW3_GWCA_GWEIE0_DECCEE )
#else /* ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON)) */
#define ETH_GWCA_ERR_ISR                STD_OFF
#endif /* ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON)) */

/***********************************************************************************************************************
**                                                        ETHA                                                        **
***********************************************************************************************************************/
#define ETH_RSW3_ETHA_TASRIRM_TASRIOG   0x00000001UL
#define ETH_RSW3_ETHA_TASRIRM_TASRR     0x00000002UL
#define ETH_RSW3_ETHA_EAMS_OPS_MASK     0x00000003UL

#if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) \
     || (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) \
     ||(ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) \
     ||(ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) \
     || (ETH_ETHA12_ERR_ISR == STD_ON))
#define ETH_ETHA_ERR_ISR                STD_ON
#define ETH_RSW3_ETHA_EAEIE0_TASGEEE    0x00FF0000UL
#define ETH_RSW3_ETHA_EAEIE0_L23UECCEE  0x00000010UL
#define ETH_RSW3_ETHA_EAEIE0_DSECCEE    0x00000008UL
#define ETH_RSW3_ETHA_EAEIE0_PECCEE     0x00000004UL
#define ETH_RSW3_ETHA_EAEIE0_TECCEE     0x00000002UL
#define ETH_RSW3_ETHA_EAEIE0_DECCEE     0x00000001UL
#define ETH_RSW3_ETHA_ECC_ERROR_MASK    ( ETH_RSW3_ETHA_EAEIE0_TASGEEE | \
                                          ETH_RSW3_ETHA_EAEIE0_L23UECCEE | \
                                          ETH_RSW3_ETHA_EAEIE0_DSECCEE | \
                                          ETH_RSW3_ETHA_EAEIE0_PECCEE | \
                                          ETH_RSW3_ETHA_EAEIE0_TECCEE | \
                                          ETH_RSW3_ETHA_EAEIE0_DECCEE )
#else
#define ETH_ETHA_ERR_ISR                STD_OFF
#endif

#define ETH_RSW3_ETHA_EATASC_TASCI 0x00000004UL
#define ETH_RSW3_ETHA_EATASC_TASCA 0x00FF0000UL
#define ETH_RSW3_ETHA_EATASGLR_GL  0x80000000UL
#define ETH_RSW3_ETHA_EATASC_TASE  0x00000001UL
#define ETH_RSW3_ETHA_EATASC_TASCC 0x00000002UL

/***********************************************************************************************************************
**                                                        RMAC                                                        **
***********************************************************************************************************************/
#define ETH_RSW3_RMAC_MPSM_MFF_MDIO     0x00000000UL  /*B2: normal management frame format Clause 22 of IEEE802.3 */
#define ETH_RSW3_RMAC_MPSM_MFF_EMDIO    0x00000004UL  /*B2: extension management frame format Clause 45 of IEEE802.3 */
#define ETH_RSW3_RMAC_MPSM_POP_READ     0x00004000UL  /*10  Read Frame when MDIO was selected via MPSM.MFF=0 */
#define ETH_RSW3_RMAC_MPSM_POP_WRITE    0x00002000UL  /*01  Write Frame when MDIO was selected via MPSM.MFF=0 */
#define ETH_RSW3_RMAC_MPSM_PSME         0x00000001UL
#define ETH_RSW3_RMAC_MPIC_PSMCS_BIT    0x007F0000UL
#define ETH_RSW3_RMAC_MPIC_10MB         0x00000000UL
#define ETH_RSW3_RMAC_MPIC_100MB        0x00000008UL
#define ETH_RSW3_RMAC_MPIC_1GB          0x00000010UL
#define ETH_RSW3_RMAC_MPIC_2_5GB        0x00000018UL
#define ETH_RSW3_RMAC_MPIC_5GB          0x00000020UL
#define ETH_RSW3_RMAC_MPIC_10GB         0x00000028UL
#define ETH_RSW3_RMAC_MPIC_MII          0x00000000UL
#define ETH_RSW3_RMAC_MPIC_GMII         0x00000002UL
#define ETH_RSW3_RMAC_MPIC_XGMII        0x00000004UL
#define ETH_RSW3_RMAC_MPIC_PSMC_320MHZ  0x003F0000UL /* re-check clk clock to select MDC clock via the divide */
#define ETH_RSW3_RMAC_MPIC_LSC_BIT      0x00000038UL
#define ETH_RSW3_RMAC_MPIC_PIS_BIT      0x00000007UL
#define ETH_RSW3_RMAC_MPIC_MASK         (ETH_RSW3_RMAC_MPIC_LSC_BIT | \
                                         ETH_RSW3_RMAC_MPIC_PIS_BIT)
#define ETH_RSW3_RMAC_MPIC_PSMCS_MASK   ETH_RSW3_RMAC_MPIC_PSMCS_BIT
#define ETH_RSW3_RMAC_MLVC_PLV          0x00010000UL
#define ETH_RSW3_RMAC_MLVC_LVT          (uint32)(0x09U) /* 10ms wait time (default specified by IEEE 802.3) */
#define ETH_RSW3_RMAC_MLVC_PASE         (0x1UL << 8UL)
#define ETH_RSW3_RMAC_MTRC_TRHFME_ENABLE      0x00000001UL

#define ETH_RSW3_RMAC_MTFFC_PAUSE       0x00000000UL
#define ETH_RSW3_RMAC_MTFFC_PFC         0x00000001UL

#define ETH_RSW3_MPSM_SET(regidx, trcvidx, mode, val) ((uint32) \
  (((uint32)val << 16U) | ((uint32)regidx << 8U) | ((uint32)trcvidx << 3U) | (mode) | \
   (ETH_RSW3_RMAC_MPSM_MFF_MDIO) | (ETH_RSW3_RMAC_MPSM_PSME)))

#define ETH_RSW3_SET_MPSM_PRD_READ(LulRegVal) ((uint16)((LulRegVal) >> 16UL))                                           /* PRQA S 3472 # JV-01 */

#define ETH_RSW3_RMAC_MIOC_BIT3            (0x1UL << 3UL)
#define ETH_RSW3_RMAC_MRAFC_ENABLE         0x00670067UL

/* MAC Loopback configuration */
#define ETH_RSW3_RMAC_MLBC_LBM          0x00000001UL

#define ETH_RSW3_RMAC_MXGMIIC_RXBFM_MASK           0x00070000UL /* B18:16 RX XGMII Bus Forcing mode */
#define ETH_RSW3_RMAC_MXGMIIC_RXBFM_FORCE_IDLE     0x00040000UL /* 3'b100: Rx XGMII bus is forced to IDLE signal */

/***********************************************************************************************************************
**                                                        gPTP                                                        **
***********************************************************************************************************************/
#define ETH_RSW3_64_TO_32_LOW  (uint64)0x00000000FFFFFFFFU
#define ETH_RSW3_64_TO_32_HIGH (uint64)0xFFFFFFFF00000000U
/***********************************************************************************************************************
**                                             MDIO reletive definitions                                              **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                              GTO reletive definitions                                              **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                             Macro for the Configuratin                                             **
***********************************************************************************************************************/
/* ulFwdVectorId */
#define ETH_FWD_VECTOR_GWCA0  0x00002000UL
#define ETH_FWD_VECTOR_GWCA1  0x00004000UL
#define ETH_FWD_VECTOR_ETHA0  0x00000001UL
#define ETH_FWD_VECTOR_ETHA1  0x00000002UL
#define ETH_FWD_VECTOR_ETHA2  0x00000004UL
#define ETH_FWD_VECTOR_ETHA3  0x00000008UL
#define ETH_FWD_VECTOR_ETHA4  0x00000010UL
#define ETH_FWD_VECTOR_ETHA5  0x00000020UL
#define ETH_FWD_VECTOR_ETHA6  0x00000040UL
#define ETH_FWD_VECTOR_ETHA7  0x00000080UL
#define ETH_FWD_VECTOR_ETHA8  0x00000100UL
#define ETH_FWD_VECTOR_ETHA9  0x00000200UL
#define ETH_FWD_VECTOR_ETHA10 0x00000400UL
#define ETH_FWD_VECTOR_ETHA11 0x00000800UL
#define ETH_FWD_VECTOR_ETHA12 0x00001000UL
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/

/* TSN frame type */
typedef enum ETag_Eth_TSN_FrameType
{
  ETH_EXPRESS_FRAME,
  ETH_PREEMPTION_FRAME
} Eth_TSN_FrameType;

typedef enum ETag_Eth_TxFragmentType
{
  ETH_FRAGMENT_64_BYTE,
  ETH_FRAGMENT_128_BYTE,
  ETH_FRAGMENT_192_BYTE,
  ETH_FRAGMENT_256_BYTE
} Eth_TxFragmentType;

typedef enum ETag_Eth_TASGateStateType
{
  ETH_TAS_CLOSE,
  ETH_TAS_OPEN
} Eth_TASGateStateType;

typedef enum ETag_Eth_RxExtStatusType
{
  ETH_EXT_RECEIVED = 0,
  ETH_EXT_NOT_RECEIVED,
  ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE,
  ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE
} Eth_ExtRxStatusType;

/* Credit Based Shaper */
typedef struct STag_Eth_CBSConfigType
{
  Eth_OptionType enCE;
  uint32 ulCIV;    /* Credit Increment Value */
  uint32 ulCUL;    /* Credit Upper Limit */
} Eth_CBSConfigType;

typedef struct STag_Eth_TASEntryType                                                                                    /* PRQA S 3630 # JV-01 */
{
  Eth_TASGateStateType enGateState;
  uint32 ulTimeInterval;
} Eth_TASEntryType;

/***********************************************************************************************************************
  Type: EthPerQueueRLConfigType

  Structure for Per-queue rate-limiter setting in GWCA register

  Members:
    ulGWRLCiValue - GWCA Rate Limiter Configuration i.
    ulGWRLULCiValue - GWCA Rate limiter upper limit configuration i.
***********************************************************************************************************************/
typedef struct STagEth_PerQueRLCfgType
{
  uint32 ulGWRLCiValue;
  uint32 ulGWRLULCiValue;
}Eth_PerQueRLCfgType;

/* Time Aware Shaper */
typedef struct STag_Eth_TASConfigType
{
  Eth_OptionType enTasEnable;
  uint32 ulTxMiniLatency;
  uint32 ulTxJitter;
  P2CONST(Eth_TASEntryType, TYPEDEF, ETH_APPL_CONST) pTasTable;                                                         /* PRQA S 3432 # JV-01 */
  uint32 ulNumberOfTasTable;
  uint8 aaEntryNumber[ETH_ETHA_FRM_PRIO_N];
} Eth_TASConfigType;

/* Tx Queue Struct */
typedef struct STag_Eth_TxQueueType                                                                                     /* PRQA S 3630 # JV-01 */
{
  uint32 ulQueueBufs;
  uint32 ulQueueId;
  uint32 ulChainId;
  Eth_TSN_FrameType enFrameType;
  uint32 ulMaxFrameSize;
  Eth_TASGateStateType enInitGateState;
  uint32 ulCycleTime;
  Eth_CBSConfigType stCBSConfig;
  Eth_PerQueRLCfgType stPerQueRLConfig;
} Eth_TxQueueType;

/* Rx Queue struct */
typedef struct STag_Eth_RxQueueType                                                                                     /* PRQA S 3630 # JV-01 */
{
  uint32 ulQueueBufs;
  uint32 ulQueueId;
  uint32 ulChainId;
  uint32 ulMaxFrameSize;
} Eth_RxQueueType;

typedef struct STag_Eth_QueueConfigType
{
  P2CONST(Eth_TxQueueType, TYPEDEF, ETH_APPL_CONST) pTxQueueConfig;                                                     /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_RxQueueType, TYPEDEF, ETH_APPL_CONST) pRxQueueConfig;                                                     /* PRQA S 3432 # JV-01 */
  uint8 ucNumberOfTxQueue;
  uint8 ucNumberOfRxQueue;
  uint8 ucOffsetOfTxQueue;
  uint8 ucOffsetOfRxQueue;
  uint32 ulTxIntConfig;
  uint32 ulRxIntConfig;
} Eth_QueueConfigType;

typedef struct STag_Eth_PauseLevelType
{
  uint32 ulPauseAssertionLevel;
  uint32 ulPauseDeAssertionLevel;
} Eth_PauseLevelType;

typedef struct STag_Eth_FlowControlType
{
  Eth_OptionType enPauseFrame;
  uint32 ulRetransmissionTime;
  uint32 ulPauseTime;
  Eth_OptionType enPauseTimeZero;
  Eth_PauseLevelType stPauseLevelConfig;
} Eth_FlowControlType;

typedef struct STag_Eth_PFCPauseLevelConfig
{
  uint32 ulPausePriority;
  uint32 ulPauseAssertionLevel;
  uint32 ulPauseDeAssertionLevel;
} Eth_PFCPauseLevelConfig;

typedef struct STag_Eth_PFCType
{
  Eth_OptionType enPFCFrame;
  uint32 ulRetransmissionTime;
  uint32 ulPauseTime;
  Eth_OptionType enPauseTimeZero;
  Eth_PFCPauseLevelConfig stPFCPauseLevelConfig[ETH_RACE_PAS_LVL_N];
} Eth_PFCType;

/***********************************************************************************************************************
**  Type: Eth_CaptureTimeAdjustment                                                                                   **
**                                                                                                                    **
**  Capture Time option                                                                                               **
**                                                                                                                    **
**  Members:                                                                                                          **
**    MDIO_CAPTURE_TIME_0_CLK_CYCLE  -  No adjusted capture time                                                      **
**    MDIO_CAPTURE_TIME_1_CLK_CYCLE  -  Capture before 1 clk                                                          **
**    MDIO_CAPTURE_TIME_2_CLK_CYCLE  -  Capture before 2 clk                                                          **
**    MDIO_CAPTURE_TIME_3_CLK_CYCLE  -  Capture before 3 clk                                                          **
**    MDIO_CAPTURE_TIME_4_CLK_CYCLE  -  Capture before 4 clk                                                          **
**    MDIO_CAPTURE_TIME_5_CLK_CYCLE  -  Capture before 5 clk                                                          **
**    MDIO_CAPTURE_TIME_6_CLK_CYCLE  -  Capture before 6 clk                                                          **
**    MDIO_CAPTURE_TIME_7_CLK_CYCLE  -  Capture before 7 clk                                                          **
***********************************************************************************************************************/
typedef enum STag_Eth_CaptureTimeAdjustmentType
{
  MDIO_CAPTURE_TIME_0_CLK_CYCLE = 0,
  MDIO_CAPTURE_TIME_1_CLK_CYCLE,
  MDIO_CAPTURE_TIME_2_CLK_CYCLE,
  MDIO_CAPTURE_TIME_3_CLK_CYCLE,
  MDIO_CAPTURE_TIME_4_CLK_CYCLE,
  MDIO_CAPTURE_TIME_5_CLK_CYCLE,
  MDIO_CAPTURE_TIME_6_CLK_CYCLE,
  MDIO_CAPTURE_TIME_7_CLK_CYCLE
} Eth_CaptureTimeAdjustmentType;

/***********************************************************************************************************************
**  Type: Eth_HoldTimeAdjustment                                                                                      **
**                                                                                                                    **
**  Hold Time option                                                                                                  **
**                                                                                                                    **
**  Members:                                                                                                          **
**    MDIO_HOLD_TIME_0_CLK_CYCLE  -  No adjusted hold time                                                            **
**    MDIO_HOLD_TIME_1_CLK_CYCLE  -  Hold extra 1 clk                                                                 **
**    MDIO_HOLD_TIME_2_CLK_CYCLE  -  Hold extra 2 clk                                                                 **
**    MDIO_HOLD_TIME_3_CLK_CYCLE  -  Hold extra 3 clk                                                                 **
**    MDIO_HOLD_TIME_4_CLK_CYCLE  -  Hold extra 4 clk                                                                 **
**    MDIO_HOLD_TIME_5_CLK_CYCLE  -  Hold extra 5 clk                                                                 **
**    MDIO_HOLD_TIME_6_CLK_CYCLE  -  Hold extra 6 clk                                                                 **
**    MDIO_HOLD_TIME_7_CLK_CYCLE  -  Hold extra 7 clk                                                                 **
***********************************************************************************************************************/
typedef enum STag_Eth_HoldTimeAdjustmentType
{
  MDIO_HOLD_TIME_0_CLK_CYCLE = 0,
  MDIO_HOLD_TIME_1_CLK_CYCLE,
  MDIO_HOLD_TIME_2_CLK_CYCLE,
  MDIO_HOLD_TIME_3_CLK_CYCLE,
  MDIO_HOLD_TIME_4_CLK_CYCLE,
  MDIO_HOLD_TIME_5_CLK_CYCLE,
  MDIO_HOLD_TIME_6_CLK_CYCLE,
  MDIO_HOLD_TIME_7_CLK_CYCLE
} Eth_HoldTimeAdjustmentType;

/***********************************************************************************************************************
**  Type: Etag_Eth_DirectionType                                                                                      **
**                                                                                                                    **
**  Direction type                                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ETH_TX    - Transmit                                                                                            **
**    ETH_RX    - Receive                                                                                             **
***********************************************************************************************************************/
typedef enum Etag_Eth_DirectionType
{
  ETH_TX,
  ETH_RX
} Eth_DirectionType;

/***********************************************************************************************************************
**  Type: Eth_RxConfigType                                                                                            **
**                                                                                                                    **
**  reception configuration structure                                                                                 **
**                                                                                                                    **
**  Members:                                                                                                          **
**  ulBcastThreshold        - Consecutive Broadcast Frame Reception Count Setting                                     **
**  ulMcastThreshold        - Consecutive Multicast Frame Reception Count Setting                                     **
**  enBcastStormFilter      - Broadcast storm filter reception enable                                                 **
**  enMcastStormFilter      - Multicast storm filter reception enable                                                 **
**  ulMaxFrameSize          - Reception Maximum frame size                                                            **
***********************************************************************************************************************/
typedef struct STag_Eth_RxConfigType
{
  uint32            ulBcastThreshold;
  uint32            ulMcastThreshold;
  Eth_OptionType    enBcastStormFilter;
  Eth_OptionType    enMcastStormFilter;
  uint32            ulMaxFrameSize;
} Eth_RxConfigType;

/***********************************************************************************************************************
**  Type: Eth_TimeAdjustment                                                                                          **
**                                                                                                                    **
**  Time adjustment structure                                                                                         **
**                                                                                                                    **
**  Members:                                                                                                          **
**    enPSMCaptureTime        - PHY Station Management Capture time                                                   **
**    enPSMHoldTime           - PHY Station Management Hold time                                                      **
**    ulPSMClockSelection     - PHY Station Management Clock Selection                                                **
***********************************************************************************************************************/
typedef struct STag_Eth_PHYConfigType
{
  Eth_CaptureTimeAdjustmentType enPSMCaptureTime;
  Eth_HoldTimeAdjustmentType    enPSMHoldTime;
  uint32 ulPSMClockSelection;
} Eth_PHYConfigType;

typedef struct STag_Eth_RMACIOConfigType
{
  uint32 ulMIOCConfigValue;
  Eth_OptionType enSerDesConnected; 
} Eth_RMACIOConfigType;

/* RSW3 LLDriver specific hardware configuration */
typedef struct STag_Eth_RSW3ConfigType                                                                                  /* PRQA S 3630 # JV-01 */
{
  uint32 ulEthPortId;
  uint32 ulFwdVectorId;
  uint32 aaFwdCsd[ETH_MAX_GWCA_SUPPORTED];
  Eth_FlowControlType stFlowControlConfig;
  Eth_PFCType stPFCConfig;
  Eth_QueueConfigType stQueueConfig;
  Eth_RxConfigType stRxConfig;
  Eth_TxFragmentType enTxFragment;
  Eth_TASConfigType stTASConfig;
  Eth_PHYConfigType stPHYConfig;
  Eth_RMACIOConfigType stRMACIOConfig;
} Eth_RSW3ConfigType, Eth_ETNDConfigType;

/***********************************************************************************************************************
**  Type: Eth_BasicDescType                                                                                           **
**                                                                                                                    **
**  Basic descriptor structure                                                                                        **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulDs     - Descriptor size                                                                                      **
**    ulInfo0  - Information 0                                                                                        **
**    ulErr    - Error                                                                                                **
**    ulDse    - Data Size Error                                                                                      **
**    ulAxie   - AXI Bus Error                                                                                        **
**    ulDie    - Descriptor Interrupt Enable                                                                          **
**    ulDt     - Descriptor Type                                                                                      **
**    ulDptrH  - Data Pinter Hith                                                                                     **
**    ulDptr   - Data Pinter                                                                                          **
***********************************************************************************************************************/
typedef struct STag_Eth_BasicDescType
{
  uint32 ulDs               : 12;                                                                                       /* PRQA S 0635 # JV-01 */
  uint32 ulInfo0            : 4;                                                                                        /* PRQA S 0635 # JV-01 */
  uint32 ulErr              : 1;                                                                                        /* PRQA S 0635 # JV-01 */
  uint32 ulDse              : 1;                                                                                        /* PRQA S 0635 # JV-01 */
  uint32 ulAxie             : 1;                                                                                        /* PRQA S 0635 # JV-01 */
  uint32 ulDie              : 1;                                                                                        /* PRQA S 0635, 1710 # JV-01, JV-01 */
  volatile uint32 ulDt      : 4;                                                                                        /* PRQA S 0635 # JV-01 */
  uint32 ulDptrH            : 8;                                                                                        /* PRQA S 0635 # JV-01 */
  uint32 ulDptr;
} Eth_BasicDescType;

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
**  Type: Eth_TimeStampDescType                                                                                       **
**                                                                                                                    **
**  Timestamp structure                                                                                               **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulTSNS - Timestamp nanosecond                                                                                   **
**    ulTSV  - Timestamp valid                                                                                        **
**    ulTSD  - Timestamp default                                                                                      **
**    ulTSS  - Timestamp second                                                                                       **
***********************************************************************************************************************/
typedef struct STag_Eth_TimeStampDescType
{
  uint32 ulTSNS: 30;                                                                                                    /* PRQA S 0635, 1710 # JV-01, JV-01 */
  uint32 ulTSV : 1;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulTSD : 1;                                                                                                     /* PRQA S 0635 # JV-01 */
  uint32 ulTSS;                                                                                                         /* PRQA S 1710 # JV-01 */
} Eth_TimeStampDescType;

/***********************************************************************************************************************
**  Type: Eth_TSDescType                                                                                              **
**                                                                                                                    **
**  Timestamp descriptor structure                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulDs        - Descriptor size                                                                                   **
**    ulInfo0     - Information 0                                                                                     **
**    ulErr       -  Error                                                                                            **
**    ulDse       -  Data Size Error                                                                                  **
**    ulAxie      -  AXI Bus Error                                                                                    **
**    ulDie       -  Descriptor Interrupt Enable                                                                      **
**    ulDt        -  Descriptor Type                                                                                  **
**    ulRSV1      -  Reserved                                                                                         **
**    ulTsun      -  Timestamp unique number                                                                          **
**    ulSpn       -  Port number from which the timestamp corresponding frame                                         **
**                   entered the switch                                                                               **
**    ulRSV2      -  Reserved                                                                                         **
**    ulDpn       -  Port number by which the timestamp has been taken                                                **
**    ulRSV3      -  Reserved                                                                                         **
**    ulTn        -  Timer Number                                                                                     **
**    ulRSV4      -  Reserved                                                                                         **
**    stTimestamp - Timestamp information                                                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_TSDescType
{
  uint64 ulDs      : 12;                                                                                                /* PRQA S 0635 # JV-01 */
  uint64 ulInfo0   : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulErr     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulDse     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulAxie    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulDie     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulDt      : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV1    : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTsun    : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulSpn     : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV2    : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulDpn     : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV3    : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTn      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV4    : 7;                                                                                                 /* PRQA S 0635 # JV-01 */
  Eth_TimeStampDescType stTimestamp;
} Eth_TSDescType;
#endif /* ETH_GLOBAL_TIME_SUPPORT */

/***********************************************************************************************************************
**  Type: Eth_LinkDescType                                                                                            **
**                                                                                                                    **
**  LINKFIX table descriptor structure                                                                                **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulDs     - Descriptor size                                                                                      **
**    ulInfo0  - Information 0                                                                                        **
**    ulErr    - Error                                                                                                **
**    ulDse    - Data Size Error                                                                                      **
**    ulAxie   - AXI Bus Error                                                                                        **
**    ulDie    - Descriptor Interrupt Enable                                                                          **
**    ulDt     - Descriptor Type                                                                                      **
**    ulDptrH  - Data Pinter Hith                                                                                     **
**    ulDptr   - Data Pinter                                                                                          **
***********************************************************************************************************************/
typedef struct STag_Eth_LinkDescType
{
  uint32 ulDs      : 12;                                                                                                /* PRQA S 0635 # JV-01 */
  uint32 ulInfo0   : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulErr     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulDse     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulAxie    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulDie     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulDt      : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulDptrH   : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulDptr;
} Eth_LinkDescType;

/***********************************************************************************************************************
**  Type: Eth_ExtTxEthDescType                                                                                        **
**                                                                                                                    **
**  (Extended descriptor) Transmission ethernet descriptor structure                                                  **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stHeader  - Basic Descriptor                                                                                    **
**    ulFi      - FCS in                                                                                              **
**    ulRSV1    - Reserved                                                                                            **
**    ulFmt     - Descriptor format                                                                                   **
**    ulTxc     - TX Timestamp capture                                                                                **
**    ulIet     - Timestamp insertion request                                                                         **
**    ulCrt     - Residence time calculation request                                                                  **
**    ulTn      - Timer utilized for capture/insertion                                                                **
**    ulRSV2    - Reserved                                                                                            **
**    ulTsun    - Timestamp unique number                                                                             **
**    ulRSV3    - Reserved                                                                                            **
***********************************************************************************************************************/
typedef struct STag_Eth_ExtTxEthDescType
{
  Eth_BasicDescType stHeader;
  uint32 ulFi      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulRSV1    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulFmt     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulTxc     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulIet     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulCrt     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulTn      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulRSV2    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulTsun    : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint32 ulRSV3_H  : 16;                                                                                                /* PRQA S 0635 # JV-01 */
  uint32 ulRSV3_L;
} Eth_ExtTxEthDescType;

/***********************************************************************************************************************
**  Type: Eth_ExtTxDirDescType                                                                                        **
**                                                                                                                    **
**  (Extended descriptor) Transmission direct descriptor structure                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stHeader  - Basic Descriptor                                                                                    **
**    ulFi      - FCS in                                                                                              **
**    ulSec     - Secure descriptor                                                                                   **
**    ulFmt     - Descriptor format                                                                                   **
**    ulTxc     - TX Timestamp capture                                                                                **
**    ulIet     - Timestamp insertion request                                                                         **
**    ulCrt     - Residence time calculation request                                                                  **
**    ulTn      - Timer utilized for capture/insertion                                                                **
**    ulRSV1    - Reserved                                                                                            **
**    ulTsun    - Timestamp unique number                                                                             **
**    ulRn1     - Routing valid 1                                                                                     **
**    ulL3cc    - Layer 3 checksum calculation                                                                        **
**    ulL4cc    - Layer 4 checksum calculation                                                                        **
**    ulRSV2    - Reserved                                                                                            **
**    ulRv      - Routing valid                                                                                       **
**    ulIpv     - Internal priority value                                                                             **
**    ulFw      - The FCS contained in the frame is wrong                                                             **
**    ulCsd     - CPU sub destination for GWCA0 and GWCA1 or RSV                                                      **
**    ulRSV3    - Reserved                                                                                            **
**    ulRn2     - Routing valid 2                                                                                     **
**    ulRSV4    - Reserved                                                                                            **
**    ulDv      - Destination vector                                                                                  **
**    ulRSV5    - Reserved                                                                                            **
***********************************************************************************************************************/
typedef struct STag_Eth_ExtTxDirDescType                                                                                /* PRQA S 3630 # JV-01 */
{
  Eth_BasicDescType stHeader;
  uint64 ulFi      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulSec     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulFmt     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTxc     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulIet     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulCrt     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTn      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV1    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTsun    : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRn1     : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulL3cc    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulL4cc    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV2    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRv      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulIpv     : 3;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulFw      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  // Or RSW. These bits were unuse.
  uint64 ulCsd     : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV3    : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRn2     : 3;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV4    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulDv      : 15;                                                                                                /* PRQA S 0635 # JV-01 */
  uint64 ulRSV5    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
} Eth_ExtTxDirDescType;

/***********************************************************************************************************************
**  Type: Eth_ExtRxEthDescType                                                                                        **
**                                                                                                                    **
**  (Extended descriptor) Reception ethernet descriptor structure                                                     **
**  (Extended timestamp descriptor) Reception ethernet descriptor structure                                           **
**                                                                                                                    **
**  Members:                                                                                                          **
**    stHeader    - Basic Descriptor                                                                                  **
**    ulFi        - FCS in                                                                                            **
**    ulSec       - Secure descriptor                                                                                 **
**    ulFmt       - Descriptor format                                                                                 **
**    ulTxc       - TX Timestamp capture                                                                              **
**    ulIet       - Timestamp insertion request                                                                       **
**    ulCrt       - Residence time calculation request                                                                **
**    ulTn        - Timer utilized for capture/insertion                                                              **
**    ulRSV1      - Reserved                                                                                          **
**    ulTsun      - Timestamp unique number                                                                           **
**    ulSaef      - Source agent error flags                                                                          **
**    ulRn        - Routing valid                                                                                     **
**    ulRv        - Routing valid                                                                                     **
**    ulSpn       - Source port number                                                                                **
**    ulFesf      - Forwarding engine status flags                                                                    **
**                                                                                                                    **
**  Below this is used only when ETH_GLOBAL_TIME_SUPPORT is STD_ON.                                                   **
**    stTimestamp - Timestamp information                                                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_ExtRxEthDescType                                                                                /* PRQA S 3630 # JV-01 */
{
  Eth_BasicDescType stHeader;
  uint64 ulFi      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulSec     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulFmt     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTxc     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulIet     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulCrt     : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTn      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRSV1    : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulTsun    : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulSaef    : 8;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulRn      : 11;                                                                                                /* PRQA S 0635 # JV-01 */
  uint64 ulRv      : 1;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulSpn     : 4;                                                                                                 /* PRQA S 0635 # JV-01 */
  uint64 ulFesf    : 24;                                                                                                /* PRQA S 0635 # JV-01 */
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_TimeStampDescType  stTimestamp;
#endif
} Eth_ExtRxEthDescType;

/***********************************************************************************************************************
**  Type: Eth_RSW3StatusType                                                                                          **
**                                                                                                                    **
**  Device instance specific data.                                                                                    **
**                                                                                                                    **
**  All instance specific data is kept within that structure.                                                         **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulBaseAddr            - Avb part base address                                                                   **
**    ulDescTableAddr       - Descriptor table address                                                                **
**    aaBufTxCnt            - Buffer Tx counter                                                                       **
**    aaHeadTxDesc          - Head tx descriptor address                                                              **
**    aaLastTxDesc          - Last tx descriptor address                                                              **
**    aaNextRxDesc          - Next free rx descriptor address                                                         **
**    enRxBeTimestamp       - Rx timestamp function status of best effort                                             **
**                            channel                                                                                 **
**    enRxSTimestamp        - Rx timestamp function status of stream channel                                          **
**    aaRxBeQueueBuf        - Rx BE buffer addresses                                                                  **
**    aaRxNcQueueBuf        - Rx NC buffer addresses                                                                  **
**    aaRxSQueueBuf         - Rx stream buffer address                                                                **
**    enDevStatus           - Device status                                                                           **
**    stStats               - Statistics (e.g. RxPacketNo, BroadcastNo)                                               **
***********************************************************************************************************************/
typedef struct STag_Eth_HwStatusType
{
  uint32                                                 aaBufTxCnt[ETH_TXQ_NUM];
  P2VAR(void, AUTOMATIC, ETH_APPL_DATA)  aaHeadTxDesc[ETH_TXQ_NUM];                                     /* PRQA S 3432 # JV-01 */
  P2VAR(void, AUTOMATIC, ETH_APPL_DATA)  aaNextTxDesc[ETH_TXQ_NUM];                                     /* PRQA S 3432 # JV-01 */
  P2VAR(void, AUTOMATIC, ETH_APPL_DATA)  aaHeadRxDesc[ETH_RXQ_NUM];                                     /* PRQA S 3432 # JV-01 */
  P2VAR(void, AUTOMATIC, ETH_APPL_DATA)  aaNextRxDesc[ETH_RXQ_NUM];                                     /* PRQA S 3432 # JV-01 */
} Eth_HwStatusType;

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**  Type: Eth_EtherFrameType                                                                                          **
**                                                                                                                    **
**  Ethernet Frame structure                                                                                          **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ucDstAddr    - Destination address                                                                              **
**    ucSrcAddr    - Source address                                                                                   **
**    ucFrameType  - EtherType                                                                                        **
**    ucPayload    - Payload                                                                                          **
***********************************************************************************************************************/
typedef struct STag_Eth_EtherFrameType
{
  uint8 ucDstAddr[6];
  uint8 ucSrcAddr[6];
  uint8 ucFrameType[2];
  Eth_DataType ucPayload;
} Eth_EtherFrameType;

/***********************************************************************************************************************
**  Type: Eth_DescChainInfo                                                                                           **
**                                                                                                                    **
**  Descriptor Chain configuration information structure                                                              **
**                                                                                                                    **
**  Members:                                                                                                          **
**  enDir                   - Tx / Rx direction                                                                       **
**  ulCtrlIdx               - Index of the controller                                                                 **
**  ulFifoIdx               - Index of related fifo                                                                   **
**  enInterrupt             - enable interrupt                                                                        **
***********************************************************************************************************************/
typedef struct STag_Eth_DescChainInfo                                                                                   /* PRQA S 3630 # JV-01 */
{
  Eth_DirectionType enDir;
  uint32 ulCtrlIdx;
  uint32 ulFifoIdx;
  Eth_OptionType enInterrupt;
} Eth_DescChainInfo;

/***********************************************************************************************************************
**  Type: Eth_DescChainMap                                                                                            **
**                                                                                                                    **
**  Descriptor Chain configuration information map structure                                                          **
**                                                                                                                    **
**  Members:                                                                                                          **
**  aaChainInfo             - Descriptor Chain information array                                                      **
**  ulValidChainNum         - Number of Descriptor Chain used                                                         **
**  ucValidChainId          - Valid Chain ID array                                                                    **
***********************************************************************************************************************/
typedef struct STag_Eth_DescQueueMap
{
  P2CONST(Eth_DescChainInfo, TYPEDEF, ETH_CONST) aaChainInfo;                                                           /* PRQA S 3432 # JV-01 */
  uint32 ulValidChainNum;
  P2CONST(uint8, TYPEDEF, ETH_CONST) ucValidChainId;                                                                    /* PRQA S 3432 # JV-01 */
} Eth_DescChainMap;

/***********************************************************************************************************************
**                                             RSW3 TOP module Registers                                              **
***********************************************************************************************************************/
typedef struct STag_Eth_RSW3_TOPRegType                                                                                 /* PRQA S 3630 # JV-01 */
{
  uint32 ulTPEMIMC0;                                 /* 0000H TPEMIMC0 */
  uint32 ulTPEMIMC1;                                 /* 0004H TPEMIMC1 */
  uint32 ulReserved0[2];                             /*       Reserved0 */
  uint32 ulTPGEMIMCt[ETH_RACE_PORT_GWCA_N];          /* 0010H TPGEMIMC */
  uint32 ulReserved1[14];                            /*       Reserved1 */
  uint32 ulTPEEMIMCt[ETH_RACE_PORT_TSNA_N];          /* 0050H TPEEMIMC */
  uint32 ulReserved2[3];                             /*       Reserved2 */
  uint32 ulTPTEMIMCt[ETH_RACE_PORT_GWCA_N];          /* 0090H TPTEMIMC */
  uint32 ulReserved3[26];                            /*       Reserved3 */
  uint32 ulTPDEMIMCt[ETH_RACE_AXI_CHAIN_N];          /* 0100H TPDEMIMC */
  uint32 ulReserved4[384];                           /*       Reserved4 */
  uint32 ulTSIM;                                     /* 0900H TSIM */
  uint32 ulTAIM;                                     /* 0904H TAIM */
  uint32 ulTFIM;                                     /* 0908H TFIM */
  uint32 ulTCIM;                                     /* 090CH TCIM */
  uint32 ulTGIM[ETH_RACE_PORT_GWCA_N];               /* 0910H TGIM */
  uint32 ulReserved5[14];                            /*       Reserved5 */
  uint32 ulTEIM[ETH_RACE_PORT_TSNA_N];               /* 0950H TEIM0 */
} Eth_RSW3_TOPRegType;

/***********************************************************************************************************************
**                                             RSW3 COMA module Registers                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_RSW3_COMARegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulRIPV;                                             /* 0000H RIPV */
  uint32 ulRRC;                                              /* 0004H RRC */
  uint32 ulRCEC;                                             /* 0008H RCEC */
  uint32 ulRCDC;                                             /* 000CH RCDC */
  uint32 ulRSSIS;                                            /* 0010H RSSIS */
  uint32 ulRSSIE;                                            /* 0014H RSSIE */
  uint32 ulRSSID;                                            /* 0018H RSSID */
  uint32 ulReserved0;                                        /*       Reserved0 */
  uint32 ulCABPIBWMCi[8];                                    /* 0020H CABPIBWMCi */
  uint32 ulCABPWMLC;                                         /* 0040H CABPWMLC */
  uint32 ulReserved1[3];                                     /*       Reserved1 */
  uint32 ulCABPPFLCi[ETH_RACE_PAS_LVL_N];                    /* 0050H CABPPFLCi */
  uint32 ulReserved2[2];                                     /*       Reserved2 */
  uint32 ulCABPPWMLCi[ETH_RACE_PORT_N];                      /* 0060H CABPPWMLCi */
  uint32 ulReserved3;                                        /*       Reserved3 */
  uint32 ulCABPPPFLCij[ETH_RACE_PORT_N][ETH_RACE_PAS_LVL_N]; /* 00A0H CABPPPFLCij */
  uint32 ulReserved4[2];                                      /*       Reserved4 */
  uint32 ulCABPULCi[ETH_RACE_PORT_N];                        /* 0120H CABPULCi */
  uint32 ulReserved5;                                        /*       Reserved5 */
  uint32 ulCABPIRM;                                          /* 0160H CABPIRM */
  uint32 ulCABPPCM;                                          /* 0164H CABPPCM */
  uint32 ulCABPLCM;                                          /* 0168H CABPLCM */
  uint32 ulCABPLCM_E;                                        /* 016CH CABPLCM(E) */
  uint32 ulReserved6[4];                                    /*       Reserved6 */
  uint32 ulCABPCPMi[ETH_RACE_PORT_N];                        /* 0180H CABPCPMi */
  uint32 ulReserved7[17];                                    /*       Reserved7 */
  uint32 ulCABPMCPMi[ETH_RACE_PORT_N];                       /* 0200H CABPMCPMi */
  uint32 ulReserved8[17];                                    /*       Reserved8 */
  uint32 ulCABPMCPMi_E[ETH_RACE_PORT_N];                     /* 0280H CABPMCPMi(E) */
  uint32 ulReserved9[17];                                    /*       Reserved9 */
  uint32 ulCARDNM;                                           /* 0300H CARDNM */
  uint32 ulCARDMNM;                                          /* 0304H CARDMNM */
  uint32 ulCARDMNM_E;                                        /* 0308H CARDMNM(E) */
  uint32 ulReserved10;                                       /*       Reserved10 */
  uint32 ulCARDCN;                                           /* 0310H CARDCN */
  uint32 ulCARDCN_E;                                         /* 0314H CARDCN(E) */
  uint32 ulReserved11[58];                                   /*       Reserved11 */
  uint32 ulCAEIS0;                                           /* 0400H CAEIS0 */
  uint32 ulCAEIE0;                                           /* 0404H CAEIE0 */
  uint32 ulCAEID0;                                           /* 0408H CAEID0 */
  uint32 ulReserved12;                                       /*       Reserved12 */
  uint32 ulCAEIS1;                                           /* 0410H CAEIS1 */
  uint32 ulCAEIE1;                                           /* 0414H CAEIE1 */
  uint32 ulCAEID1;                                           /* 0418H CAEID1 */
  uint32 ulReserved13[9];                                    /*       Reserved13 */
  uint32 ulCAMIS0;                                           /* 0440H CAMIS0 */
  uint32 ulCAMIE0;                                           /* 0444H CAMIE0 */
  uint32 ulCAMID0;                                           /* 0448H CAMID0 */
  uint32 ulReserved14;                                       /*       Reserved14 */
  uint32 ulCAMIS1;                                           /* 0450H CAMIS1 */
  uint32 ulCAMIE1;                                           /* 0454H CAMIE1 */
  uint32 ulCAMID1;                                           /* 0458H CAMID1 */
  uint32 ulReserved15[9];                                    /*       Reserved15 */
  uint32 ulCASCR;                                            /* 0480H CASCR */
} Eth_RSW3_COMARegType;

/***********************************************************************************************************************
**                                             RSW3 MFWD module Registers                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_RSW3_MFWDRegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulFWGC;                                   /* 0000H FWGC      */
  uint32 ulReserved0[3];                           /*       Reserved0 */
  uint32 ulFWTTC0;                                 /* 0010H FWTTC0    */
  uint32 ulFWTTC1;                                 /* 0014H FWTTC1    */
  uint32 ulReserved1[2];                           /*       Reserved1 */
  uint32 ulFWCEPTC;                                /* 0020H FWCEPTC   */
  uint32 ulFWCEPRC0;                               /* 0024H FWCEPRC0  */
  uint32 ulFWCEPRC1;                               /* 0028H FWCEPRC1  */
  uint32 ulFWCEPRC2;                               /* 002CH FWCEPRC2  */
  uint32 ulFWCLPTC;                                /* 0030H FWCLPTC   */
  uint32 ulFWCLPRC;                                /* 0034H FWCLPTC   */
  uint32 ulReserved2[2];                           /*       Reserved2 */
  uint32 ulFWCMPTC;                                /* 0040H FWCMPTC   */
  uint32 ulFWCMPL23URC;                            /* 0044H FWCMPL23URC */
  uint32 ulFWEMPTC;                                /* 0048H FWEMPTC     */
  uint32 ulFWEMPL23URC;                            /* 004CH FWEMPL23URC */
  uint32 ulFWSDMPTC;                               /* 0050H FWSDMPTC */
  uint32 ulFWSDMPVC;                               /* 0054H FWSDMPVC */
  uint32 ulFWSDMPL23URC;                           /* 0058H FWSDMPL23URC */
  uint32 ulReserved3;                              /*       Reserved3 */
  uint32 ulFWSMPTC;                                /* 0060H FWSMPTC */
  uint32 ulFWSMPVC;                                /* 0064H FWSMPVC */
  uint32 ulFWSMPL23URC;                            /* 0068H FWSMPL23URC */
  uint32 ulReserved4[5];                           /*       Reserved4 */
  uint32 ulFWLBWMCi[ETH_RACE_PORT_N];              /* 0080H FWLBWMCi */
  uint32 ulReserved5;                              /*       Reserved5 */
  uint32 ulFWIBWMC;                                /* 00C0H FWIBWMC */
  uint32 ulReserved6[15];                          /*       Reserved6 */
  struct STag_FWPC{
    uint32 ulFWPC0i;                               /* 0100H FWPC0i */
    uint32 ulFWPC1i;                               /* 0104H FWPC1i */
    uint32 ulFWPC2i;                               /* 0108H FWPC2i */
    uint32 ulFWPC3i;                               /* 010CH FWPC3i */
  } FWPC[ETH_RACE_PORT_N];
  uint32 ulReserved74[4];                          /*       Reserved2 */
  uint32 ulFWPIFPIij[ETH_RACE_PORT_N][8];          /* 0200H FWPIFPIij */
  uint32 ulReserved75[8];                          /*       Reserved2 */
  struct STag_FWCT{
    uint32 ulFWCTGC0i;                             /* 0400H FWCTGC0i */
    uint32 ulFWCTGC1i;                             /* 0404H FWCTGC1i */
    uint32 ulFWCTTC0i;                             /* 0408H FWCTTC0i */
    uint32 ulFWCTTC1i;                             /* 040CH FWCTTC1i */
    uint32 ulFWCTTC2ji[ETH_RACE_PORT_GWCA_N];      /* 0410H FWCTTC2ji */
    uint32 ulReserved7[13];                        /*       Reserved9 */
    uint32 ulFWCTSC0i;                             /* 0450H FWCTSC0i */
    uint32 ulFWCTSC1i;                             /* 0454H FWCTSC1i */
    uint32 ulFWCTSC2i;                             /* 0458H FWCTSC2i */
    uint32 ulFWCTSC3i;                             /* 045CH FWCTSC3i */
    uint32 ulFWCTSC4i;                             /* 0460H FWCTSC4i */
    uint32 ulReserved8[3];                         /*       Reserved7 */
  }FWCT[8];
  uint32 ulReserved9[40];                           /*       Reserved8 */
  uint32 ulReserved10[3656];                        /*       Reserved9 */
  uint32 ulFWLTHTIM;                               /* 4120H FWLTHTIM */
  uint32 ulFWLTHTEM0;                              /* 4124H FWLTHTEM0 */
  uint32 ulFWLTHTEM1;                              /* 4128H FWLTHTEM1 */
  uint32 ulReserved11;                             /*       Reserved29 */
  uint32 ulFWLTHTS0;                               /* 4130H FWLTHTS0 */
  uint32 ulFWLTHTS1;                               /* 4134H FWLTHTS1 */
  uint32 ulFWLTHTS2;                               /* 4138H FWLTHTS2 */
  uint32 ulFWLTHTS3;                               /* 413CH FWLTHTS3 */
  uint32 ulFWLTHTS4;                               /* 4140H FWLTHTS4 */
  uint32 ulFWLTHTS5;                               /* 4144H FWLTHTS5 */
  uint32 ulFWLTHTS6;                               /* 4148H FWLTHTS6 */
  uint32 ulReserved12;                             /*       Reserved30 */
  uint32 ulFWLTHTSR0;                              /* 4150H FWLTHTSR0 */
  uint32 ulFWLTHTSR1;                              /* 4154H FWLTHTSR1 */
  uint32 ulFWLTHTSR2;                              /* 4158H FWLTHTSR2 */
  uint32 ulFWLTHTSR3;                              /* 415CH FWLTHTSR3 */
  uint32 ulFWLTHTSR4i[ETH_RACE_PORT_GWCA_N];       /* 4160H FWLTHTSR4i */
  uint32 ulReserved13[14];                         /*       Reserved31 */
  uint32 ulFWLTHTSR5;                              /* 41A0H FWLTHTSR5 */
  uint32 ulFWLTHTSR6;                              /* 41A4H FWLTHTSR6 */
  uint32 ulFWLTHTSR7;                              /* 41A8H FWLTHTSR7 */
  uint32 ulReserved14;                             /*       Reserved32 */
  uint32 ulFWLTHTR;                                /* 41B0H FWLTHTR */
  uint32 ulFWLTHTRR0;                              /* 41B4H FWLTHTRR0 */
  uint32 ulFWLTHTRR1;                              /* 41B8H FWLTHTRR1 */
  uint32 ulFWLTHTRR2;                              /* 41BCH FWLTHTRR2 */
  uint32 ulFWLTHTRR3;                              /* 41C0H FWLTHTRR3 */
  uint32 ulFWLTHTRR4;                              /* 41C4H FWLTHTRR4 */
  uint32 ulFWLTHTRR5;                              /* 41C8H FWLTHTRR5 */
  uint32 ulFWLTHTRR6;                              /* 41CCH FWLTHTRR6 */
  uint32 ulFWLTHTRR7;                              /* 41D0H FWLTHTRR7 */
  uint32 ulFWLTHTRR8;                              /* 41D4H FWLTHTRR8 */
  uint32 ulFWLTHTRR9;                              /* 41D8H FWLTHTRR9 */
  uint32 ulFWLTHTRR10;                             /* 41DCH FWLTHTRR10 */
  uint32 ulFWLTHTRR11;                             /* 41E0H FWLTHTRR11 */
  uint32 ulFWLTHTRR12;                             /* 41E4H FWLTHTRR12 */
  uint32 ulFWLTHTRR13i[ETH_RACE_PORT_GWCA_N];      /* 41E8H FWLTHTRR13i */
  uint32 ulReserved15[10];                         /*       Reserved33 */
  uint32 ulFWLTHTRR14;                             /* 4218H FWLTHTRR14 */
  uint32 ulFWLTHTRR15;                             /* 421CH FWLTHTRR15 */
  uint32 ulReserved76[56];                         /*       Reserved33 */
  uint32 ulFWLTHREUSPC;                            /* 4300H FWLTHREUSPC */
  uint32 ulFWLTHREC;                               /* 4304H FWLTHREC */
  uint32 ulFWLTHREM;                               /* 4308H FWLTHREM */
  uint32 ulReserved16[189];                        /*       Reserved34 */
  uint32 ulFWMACTEC0;                              /* 4600H FWMACTEC0 */
  uint32 ulReserved17[3];                          /*       Reserved35 */
  uint32 ulFWMACTL0;                               /* 4610H FWMACTL0 */
  uint32 ulFWMACTL1;                               /* 4614H FWMACTL1 */
  uint32 ulFWMACTL2;                               /* 4618H FWMACTL2 */
  uint32 ulFWMACTL3;                               /* 461CH FWMACTL3 */
  uint32 ulFWMACTL4;                               /* 4620H FWMACTL4 */
  uint32 ulFWMACTL5;                               /* 4624H FWMACTL5 */
  uint32 ulFWMACTL6;                               /* 4628H FWMACTL6 */
  uint32 ulFWMACTL7i[ETH_RACE_PORT_GWCA_N];        /* 462CH FWMACTL7i */
  uint32 ulReserved18[14];                         /*       Reserved36 */
  uint32 ulFWMACTL8;                               /* 466CH FWMACTL8 */
  uint32 ulFWMACTLR;                               /* 4670H FWMACTLR */
  uint32 ulReserved19[3];                          /*       Reserved37 */
  uint32 ulFWMACTIM;                               /* 4680H FWMACTIM */
  uint32 ulFWMACTEM;                               /* 4684H FWMACTEM */
  uint32 ulReserved20[2];                          /*       Reserved38 */
  uint32 ulFWMACTS0;                               /* 4690H FWMACTS0 */
  uint32 ulFWMACTS1;                               /* 4694H FWMACTS1 */
  uint32 ulFWMACTS2;                               /* 4698H FWMACTS2 */
  uint32 ulFWMACTS3;                               /* 469CH FWMACTS3 */
  uint32 ulFWMACTSR0;                              /* 46A0H FWMACTSR0 */
  uint32 ulFWMACTSR1;                              /* 46A4H FWMACTSR1 */
  uint32 ulFWMACTSR2i[ETH_RACE_PORT_GWCA_N];       /* 46A8H FWMACTSR2i */
  uint32 ulReserved21[14];                         /*       Reserved39 */
  uint32 ulFWMACTSR3;                              /* 46E8H FWMACTSR3 */
  uint32 ulReserved22;                             /*       Reserved40 */
  uint32 ulFWMACTSR4;                              /* 46F0H FWMACTSR4 */
  uint32 ulFWMACTSR5;                              /* 46F4H FWMACTSR5 */
  uint32 ulFWMACTSR6;                              /* 46F8H FWMACTSR6 */
  uint32 ulReserved23;                             /*       Reserved41 */
  uint32 ulFWMACTR;                                /* 4700H FWMACTR */
  uint32 ulReserved24[3];                          /*       Reserved42 */
  uint32 ulFWMACTRR0;                              /* 4710H FWMACTRR0 */
  uint32 ulFWMACTRR1;                              /* 4714H FWMACTRR1 */
  uint32 ulFWMACTRR2;                              /* 4718H FWMACTRR2 */
  uint32 ulFWMACTRR3;                              /* 471CH FWMACTRR3 */
  uint32 ulFWMACTRR4;                              /* 4720H FWMACTRR4 */
  uint32 ulFWMACTRR5;                              /* 4724H FWMACTRR5 */
  uint32 ulFWMACTRR6;                              /* 4728H FWMACTRR6 */
  uint32 ulFWMACTRR7i[ETH_RACE_PORT_GWCA_N];       /* 472CH FWMACTRR7i */
  uint32 ulReserved25[14];                         /*       Reserved43 */
  uint32 ulFWMACTRR8;                              /* 476CH FWMACTRR8 */
  uint32 ulReserved26[36];                         /*       Reserved44 */
  uint32 ulFWMACHWLC0;                             /* 4800H FWMACHWLC0 */
  uint32 ulFWMACHWLC1;                             /* 4804H FWMACHWLC1 */
  uint32 ulReserved27[2];                          /*       Reserved10 */
  uint32 ulFWMACHWLC2i[ETH_RACE_PORT_N];           /* 4810H FWMACHWLC2i */
  uint32 ulReserved28[13];                         /*       Reserved45 */
  uint32 ulFWMACAGUSPC;                            /* 4880H FWMACAGUSPC */
  uint32 ulFWMACAGC;                               /* 4884H FWMACAGC */
  uint32 ulFWMACAGM0;                              /* 4888H FWMACAGM0 */
  uint32 ulFWMACAGM1;                              /* 488CH FWMACAGM1 */
  uint32 ulFWMACREUSPC;                            /* 4890H FWMACREUSPC */
  uint32 ulFWMACREC;                               /* 4894H  FWMACREC */
  uint32 ulFWMACREM;                               /* 4898H  FWMACREM */
  uint32 ulReserved29[25];                         /*       Reserved46 */
  uint32 ulFWVLANTEC;                              /* 4900H  FWVLANTEC */
  uint32 ulReserved30[3];                          /*       Reserved47 */
  uint32 ulFWVLANTL0;                              /* 4910H FWVLANTL0 */
  uint32 ulFWVLANTL1;                              /* 4914H FWVLANTL1 */
  uint32 ulFWVLANTL2;                              /* 4918H FWVLANTL2 */
  uint32 ulFWVLANTL3;                              /* 491CH FWVLANTL3 */
  uint32 ulFWVLANTL4;                              /* 4920H FWVLANTL4 */
  uint32 ulFWVLANTL5;                              /* 4924H FWVLANTL5 */
  uint32 ulFWVLANTL6i[ETH_RACE_PORT_GWCA_N];       /* 4928H FWVLANTL6i */
  uint32 ulReserved31[14];                         /*       Reserved48 */
  uint32 ulFWVLANTL7;                              /* 4968H FWVLANTL7 */
  uint32 ulFWVLANTLR;                              /* 496CH FWVLANTLR */
  uint32 ulFWVLANTIM;                              /* 4970H FWVLANTIM */
  uint32 ulFWVLANTEM;                              /* 4974H FWVLANTEM */
  uint32 ulReserved32[2];                          /*       Reserved49 */
  uint32 ulFWVLANTS;                               /* 4980H FWVLANTS */
  uint32 ulFWVLANTSR0;                             /* 4984H FWVLANTSR0 */
  uint32 ulFWVLANTSR1;                             /* 4988H FWVLANTSR1 */
  uint32 ulFWVLANTSR2;                             /* 498CH FWVLANTSR2 */
  uint32 ulFWVLANTSR3;                             /* 4990H FWVLANTSR3 */
  uint32 ulFWVLANTSR4;                             /* 4994H FWVLANTSR4 */
  uint32 ulFWVLANTSR5i[ETH_RACE_PORT_GWCA_N];      /* 4998H FWVLANTSR5i */
  uint32 ulReserved33[10];                         /*       Reserved50 */
  uint32 ulFWVLANTSR6;                             /* 49C8H FWVLANTSR6 */
  uint32 ulReserved34[13];                         /*       Reserved51 */
  struct STag_FWPBF{
    uint32 ulFWPBFC0i;                             /* 4A00H FWPBFC0i */
    uint32 ulFWPBFC1i;                             /* 4A04H FWPBFC1i */
    uint32 ulReserved35[2];                        /*       Reserved52*/
  } FWPBF[ETH_RACE_PORT_N];
  uint32 ulReserved77[4];                          /*       Reserved52*/
  uint32 ulFWPBFCSDCji[ETH_RACE_PORT_N][8];        /* 4B00H FWPBFCSDCji */
  uint32 ulReserved36[72];                         /*       Reserved53 */
  uint32 ulFWL23URL0;                              /* 4E00H FWL23URL0 */
  uint32 ulFWL23URL1;                              /* 4E04H FWL23URL1 */
  uint32 ulFWL23URL2;                              /* 4E08H FWL23URL2 */
  uint32 ulFWL23URL3;                              /* 4E0CH FWL23URL3 */
  uint32 ulFWL23URLR;                              /* 4E10H FWL23URLR */
  uint32 ulReserved38[3];                          /*       Reserved55 */
  uint32 ulFWL23UTIM;                              /* 4E20H FWL23UTIM */
  uint32 ulReserved39[3];                          /*       Reserved56 */
  uint32 ulFWL23URR;                               /* 4E30H FWL23URR */
  uint32 ulFWL23URRR0;                             /* 4E34H FWL23URRR0 */
  uint32 ulFWL23URRR1;                             /* 4E38H FWL23URRR1 */
  uint32 ulFWL23URRR2;                             /* 4E3CH FWL23URRR2 */
  uint32 ulFWL23URRR3;                             /* 4E40H FWL23URRR3 */
  uint32 ulReserved40[47];                         /*       Reserved57 */
  uint32 ulFWL23URMCi[32];                         /* 4F00H FWL23URMCi */
  uint32 ulReserved41[32];                         /*       Reserved58 */
  uint32 ulFWPMFGCi[16];                           /* 5000H FWPMFGCi */
  uint32 ulReserved42[48];                         /*       Reserved59 */
  struct STag_FWPGF{
    uint32 ulFWPGFCi;                               /* 5100H FWPGFCi */
    uint32 ulFWPGFIGSCi;                            /* 5104H FWPGFIGSCi */
    uint32 ulFWPGFENCi;                             /* 5108H FWPGFENCi */
    uint32 ulFWPGFENMi;                             /* 510CH FWPGFENMi */
    uint32 ulFWPGFCSTC0i;                           /* 5110H FWPGFCSTC0i */
    uint32 ulFWPGFCSTC1i;                           /* 5114H FWPGFCSTC1i */
    uint32 ulFWPGFCSTM0i;                           /* 5118H FWPGFCSTM0i */
    uint32 ulFWPGFCSTM1i;                           /* 511CH FWPGFCSTM1i */
    uint32 ulFWPGFCTCi;                             /* 5120H FWPGFCTCi */
    uint32 ulFWPGFCTMi;                             /* 5124H FWPGFCTMi */
    uint32 ulFWPGFHCCi;                             /* 5128H FWPGFHCCi */
    uint32 ulFWPGFSMi;                              /* 512CH FWPGFSMi */
    uint32 ulFWPGFGCi;                              /* 5130H FWPGFGCi */
  }FWPGF[8];
  uint32 ulReserved43[152];                        /*       Reserved58 */
  uint32 ulFWPGFGL0;                               /* 5500H FWPGFGL0 */
  uint32 ulFWPGFGL1;                               /* 5504H FWPGFGL1 */
  uint32 ulFWPGFGLR;                               /* 5508H FWPGFGLR */
  uint32 ulReserved44;                             /*       Reserved61 */
  uint32 ulFWPGFGR;                                /* 5510H FWPGFGR */
  uint32 ulFWPGFGRR0;                              /* 5514H FWPGFGRR0 */
  uint32 ulFWPGFGRR1;                              /* 5518H FWPGFGRR1 */
  uint32 ulReserved45;                             /*       Reserved62 */
  uint32 ulFWPGFRIM;                               /* 5520H FWPGFRIM */
  uint32 ulReserved46[695];                        /*       Reserved63 */
  uint32 ulFWFTL0;                                 /* 6000H FWFTL0 */
  uint32 ulFWFTL1;                                 /* 6004H FWFTL1 */
  uint32 ulFWFTLR;                                 /* 6008H FWFTLR */
  uint32 ulReserved47;                             /*       Reserved64 */
  uint32 ulFWFTOC;                                 /* 6010H FWFTOC */
  uint32 ulFWFTOPC;                                /* 6014H FWFTOPC */
  uint32 ulReserved48[2];                          /*       Reserved65 */
  uint32 ulFWFTIM;                                 /* 6020H FWFTIM */
  uint32 ulReserved49[3];                          /*       Reserved66 */
  uint32 ulFWFTR;                                  /* 6030H FWFTR */
  uint32 ulFWFTRR0;                                /* 6034H FWFTRR0 */
  uint32 ulFWFTRR1;                                /* 6038H FWFTRR1 */
  uint32 ulFWFTRR2;                                /* 603CH FWFTRR2 */
  struct STag_FWSEQNG{
    uint32 ulFWSEQNGCi;                              /* 6100H FWSEQNGCi */
    uint32 ulFWSEQNGMi;                              /* 6104H FWSEQNGMi */
    uint32 ulReserved50[2];                          /*       Reserved67 */
  }FWSEQNG[32];
  uint32 ulReserved51[2];                          /*       Reserved68 */
  uint32 ulFWSEQNRC;                               /* 6200H FWSEQNRC */
  uint32 ulReserved52[63];                         /*       Reserved68 */
  union STag_FWFDESCCNTR{                                                                                               /* PRQA S 0750 # JV-01 */
    struct FWFDESCCNTR_ETHA{
      uint32 ulFWCTFDCNi;                          /* 6300H FWCTFDCNi */
      uint32 ulReserved53[3];                      /*       Reserved69 */
      uint32 ulFWPBFDCNi;                          /* 6310H FWPBFDCNi */
      uint32 ulFWMHLCNi;                           /* 6314H FWMHLCNi */
      uint32 ulReserved54[2];                      /*       Reserved70 */
    } Etha;

    struct FWFDESCCNTR_GWCA{
      uint32 ulFWDDFDCNi;                          /* 6300H FWDDFDCNi */
      uint32 ulReserved55[3];                      /*       Reserved71 */
      uint32 ulFWPBFDCNi;                          /* 6310H FWPBFDCNi */
      uint32 ulFWMHLCNi;                           /* 6314H FWMHLCNi */
      uint32 ulReserved56[2];                      /*       Reserved72 */
    } Gwca;
  } FWFDESCCNTR[ETH_RACE_PORT_N];
  uint32 ulReserved57[7];                          /*       Reserved73 */
  union STag_FWRDESCCNTR{                                                                                               /* PRQA S 0750 # JV-01 */
    struct FWRDESCCNTR_ETHA{
      uint32 ulFWICRDCNi;                          /* 6500H FWICRDCNi */
      uint32 ulFWWMRDCNi;                          /* 6504H FWWMRDCNi */
      uint32 ulFWCTRDCNi;                          /* 6508H FWCTRDCNi */
      uint32 ulFWLTHRDCNi;                         /* 650CH FWLTHRDCNi */
      uint32 ulFWLTWRDCNi;                         /* 6514H FWLTWRDCNi */
      uint32 ulFWPBRDCNi;                          /* 6518H FWPBRDCNi */
      uint32 ulReserved58[2];                      /*       Reserved74 */
    } Etha;

    struct FWRDESCCNTR_GWCA{
      uint32 ulFWICRDCNi;                          /* 6500H FWICRDCNi */
      uint32 ulFWWMRDCNi;                          /* 6504H FWWMRDCNi */
      uint32 ulFWDDRDCNi;                          /* 6508H FWDDRDCNi */
      uint32 ulFWLTHRDCNi;                         /* 650CH FWLTHRDCNi */
      uint32 ulFWLTWRDCNi;                         /* 6514H FWLTWRDCNi */
      uint32 ulFWPBRDCNi;                          /* 6518H FWPBRDCNi */
      uint32 ulReserved59[2];                      /*       Reserved75 */
    } Gwca;
  } FWRDESCCNTR[ETH_RACE_PORT_N];
  uint32 ulReserved60[104];                        /*       Reserved76 */
  uint32 ulFWPMFDCNi[8];                           /* 6700H FWPMFDCNi */
  uint32 ulReserved61[23];                         /*       Reserved77 */
  uint32 ulFWPGFDCNi[16];                          /* 6780H FWPGFDCNi */
  uint32 ulReserved62[143];                        /*       Reserved78 */
  struct STag_FWFR{
    uint32 ulFWFRPPCNi;                            /* 6A00H FWFRPPCNi */
    uint32 ulFWFRDPCNi;                            /* 6A04H FWFRDPCNi */
  }FWFR[128];
  uint32 ulReserved63[238];                        /*       Reserved79 */
  union STag_FWFDESCCNTR_E{                                                                                             /* PRQA S 0750 # JV-01 */

    struct FWFDESCCNTR_E_ETHA{
      uint32 ulFWCTFDCNi_E;                        /* 6E00H FWCTFDCNi(E)*/
      uint32 ulFWLTHFDCNi_E;                       /* 6E04H FWLTHFDCNi(E)*/
      uint32 ulReserved64;                         /*       Reserved80 */
      uint32 ulFWLTWFDCNi_E;                       /* 6E0CH FWLTWFDCNi(E)*/
      uint32 ulFWPBFDCNi_E;                        /* 6E10H FWPBFDCNi(E) */
      uint32 ulFWMHLCNi_E;                         /* 6E14H FWMHLCNi(E) */
      uint32 ulReserved65[2];                      /*       Reserved81 */
    } Etha;

    struct FWFDESCCNTR_E_GWCA{
      uint32 ulFWDDFDCNi_E;                        /* 6E00H FWDDFDCNi(E) */
      uint32 ulFWLTHFDCNi_E;                       /* 6E04H FWLTHFDCNi(E)*/
      uint32 ulReserved66;                         /*       Reserved82 */
      uint32 ulFWLTWFDCNi_E;                       /* 6E0CH FWLTWFDCNi(E)*/
      uint32 ulFWPBFDCNi_E;                        /* 6E10H FWPBFDCNi(E) */
      uint32 ulFWMHLCNi_E;                         /* 6E14H FWMHLCNi(E) */
      uint32 ulReserved67[2];                      /*       Reserved83 */
    } Gwca;
  } FWFDESCCNTR_E[ETH_RACE_PORT_N];
  uint32 ulReserved68[105];                         /*       Reserved84 */

  union STag_FWRDESCCNTR_E{                                                                                             /* PRQA S 0750 # JV-01 */
    struct FWRDESCCNTR_E_ETHA{
      uint32 ulFWICRDCNi_E;                       /* 7000H FWICRDCNi(E) */
      uint32 ulFWWMRDCNi_E;                       /* 7004H FWWMRDCNi(E) */
      uint32 ulFWCTRDCNi_E;                       /* 7008H FWCTRDCNi(E) */
      uint32 ulFWLTHRDCNi_E;                      /* 700CH FWLTHRDCNi(E) */
      uint32 ulReserved69[2];                     /*       Reserved85 */
      uint32 ulFWPBRDCNi_E;                       /* 7018H FWPBRDCNi(E) */
      uint32 ulReserved70;                        /*       Reserved86 */
      uint32 ulFWPMFDCNi_E;                       /* 7200H FWPMFDCNi(E) */
    } Etha;

    struct FWRDESCCNTR_E_GWCA{
      uint32 ulFWICRDCNi_E;                       /* 7000H FWICRDCNi(E) */
      uint32 ulFWWMRDCNi_E;                       /* 7004H FWWMRDCNi(E) */
      uint32 ulFWDDRDCNi_E;                       /* 7008H FWDDRDCNi(E) */
      uint32 ulFWLTHRDCNi_E;                      /* 700CH FWLTHRDCNi(E) */
      uint32 ulReserved71[2];                     /*       Reserved87 */
      uint32 ulFWPBRDCNi_E;                       /* 7018H FWPBRDCNi(E) */
      uint32 ulReserved72;                        /*       Reserved88 */
      uint32 ulFWPMFDCNi_E;                       /* 7200H FWPMFDCNi(E) */
    } Gwca;
  } FWRDESCCNTR_E[ETH_RACE_PORT_N];
  uint32 ulReserved73[838];                       /*       Reserved89 */
} Eth_RSW3_MFWDRegType;

/***********************************************************************************************************************
**                                             RSW3 GWCA module Registers                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_RSW3_GWCARegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulGWMC;                                 /* 0000H GWMC */
  uint32 ulGWMS;                                 /* 0004H GWMS */
  uint32 ulGWRDRC;                               /* 0008H GWRDRC */
  uint32 ulReserved0;                            /*       Reserved0 */
  uint32 ulGWIRC;                                /* 0010H GWIRC */
  uint32 ulGWRDQSC;                              /* 0014H GWRDQSC */
  uint32 ulGWRDQC;                               /* 0018H GWRDQC */
  uint32 ulGWRDQAC;                              /* 001CH GWRDQAC */
  uint32 ulGWRGC;                                /* 0020H GWRGC */
  uint32 ulGWCSDRC;                              /* 0024H GWCSDRC */
  uint32 ulReserved1[6];                         /*       Reserved1 */
  uint32 ulGWRMFSCq[ETH_GWCA_FRM_PRIO_N];        /* 0040H GWRMFSCq */
  uint32 ulGWRDQDCq[ETH_GWCA_FRM_PRIO_N];        /* 0060H GWRDQDCq */
  uint32 ulGWRDQMq[ETH_GWCA_FRM_PRIO_N];         /* 0080H GWRDQDCq */
  uint32 ulGWRDQMLMq[ETH_GWCA_FRM_PRIO_N];       /* 00A0H GWRDQDCq */
  uint32 ulGWRDQMLMq_E[ETH_GWCA_FRM_PRIO_N];     /* 00A0H GWRDQDCq */
  uint32 ulReserved2[8];                         /*       Reserved2 */
  uint32 ulGWMTIRM;                              /* 0100H GWMTIRM */
  uint32 ulGWMSTLS;                              /* 0104H GWMSTLS */
  uint32 ulGWMSTLR;                              /* 0108H GWMSTLR */
  uint32 ulGWMSTSS;                              /* 010CH GWMSTSS */
  uint32 ulGWMSTSR;                              /* 0110H GWMSTSR */
  uint32 ulReserved3[3];                         /*       Reserved3 */
  uint32 ulGWMAC0;                               /* 0120H GWMAC0 */
  uint32 ulGWMAC1;                               /* 0124H GWMAC1 */
  uint32 ulReserved4[2];                         /*       Reserved4 */
  uint32 ulGWVCC;                                /* 0130H GWVCC */
  uint32 ulGWVTC;                                /* 0134H GWVTC */
  uint32 ulGWTTFC;                               /* 0138H GWTTFC */
  uint32 ulGWCKSC;                               /* 013CH GWCKSC */
  struct STag_GWTDCAC{
    uint32 ulGWTDCAC0s;                          /* 0140H GWTDCAC0s */
    uint32 ulGWTDCAC1s;                          /* 0144H GWTDCAC1s */
  } GWTDCAC[ETH_RACE_PTP_TN];
  uint32 ulReserved6[4];                         /*       Reserved6 */
  uint32 ulGWTSDCCs[ETH_RACE_PTP_TN];            /* 0160H GWTSDCCs */
  uint32 ulReserved7[6];                         /*       Reserved7 */
  uint32 ulGWTSNM;                               /* 0180H GWTSNM */
  uint32 ulGWTSMNM;                              /* 0184H GWTSMNM */
  uint32 ulGWTSMNM_E;                            /* 0188H GWTSMNM(E) */
  uint32 ulReserved8[5];                         /*       Reserved8 */
  struct STag_GWAVTPTM{
    uint32 ulGWAVTPTM0t;                         /* 01A0H GWAVTPTM0t */
    uint32 ulGWAVTPTM1t;                         /* 01A4H GWAVTPTM1t */
        uint32 ulGWGPTPTM0t;                         /* 01A8H GWGPTPTM0t */
        uint32 ulGWGPTPTM1t;                         /* 01ACH GWGPTPTM1t */
        uint32 ulGWGPTPTM2t;                         /* 01B0H GWGPTPTM2t */
  } GWAVTPTM[ETH_RACE_PTP_TN];
  uint32 ulReserved9[6];                          /*       Reserved9 */
  uint32 ulGWAC;                                 /* 01E0H GWAC */
  uint32 ulGWDCBAC0;                             /* 01E4H GWDCBAC0 */
  uint32 ulGWDCBAC1;                             /* 01E8H GWDCBAC1 */
  uint32 ulGWIICBSC;                             /* 01ECH GWIICBSC */
  uint32 ulGWMDNC;                               /* 01F0H GWMDNC */
  uint32 ulReserved10[3];                        /*       Reserved10 */
  uint32 ulGWTRCi[ETH_RACE_AXI_CHAIN_N/32UL];    /* 0200H GWTRCi */
  uint32 ulReserved11[60];                       /*       Reserved11 */
  uint32 ulGWTPCp[ETH_RACE_PAS_LVL_N];           /* 0300H GWTPCp */
  uint32 ulReserved12[30];                       /*       Reserved12 */
  uint32 ulGWARIRM;                              /* 0380H GWARIRM */
  uint32 ulReserved13[31];                       /*       Reserved13 */
  uint32 ulGWDCCi[ETH_RACE_AXI_CHAIN_N];         /* 0400H GWDCCi */
  uint32 ulReserved14[128];                      /*       Reserved14 */
  uint32 ulGWAARSS;                              /* 0800H GWAARSS */
  uint32 ulGWAARSR0;                             /* 0804H GWAARSR0 */
  uint32 ulGWAARSR1;                             /* 0808H GWAARSR1 */
  uint32 ulReserved15[13];                       /*       Reserved15 */
  uint32 ulGWIDAUASi[ETH_GWCA_AXI_RINC_N];       /* 0840H GWIDAUASi */
  uint32 ulReserved16[8];                        /*       Reserved16 */
  uint32 ulGWIDASMi[ETH_GWCA_AXI_RINC_N];        /* 0880H GWIDASMi */
  uint32 ulReserved17[24];                       /*       Reserved17 */
  struct STag_GWIDASAM{
    uint32 ulGWIDASAM0i;                         /* 0900H GWIDASAM0i */
    uint32 ulGWIDASAM1i;                         /* 0904H GWIDASAM1i */
  } GWIDASAM[ETH_GWCA_AXI_RINC_N];
  uint32 ulReserved18[16];                       /*       Reserved18 */
  struct STag_GWIDACAM{
    uint32 ulGWIDACAM0i;                         /* 0980H GWIDACAM0i */
    uint32 ulGWIDACAM1i;                         /* 0984H GWIDACAM1i */
  } GWIDACAM[ETH_GWCA_AXI_RINC_N];
  uint32 ulReserved19[16];                       /*       Reserved19 */
  uint32 ulGWGRLC;                               /* 0A00H GWGRLC */
  uint32 ulGWGRLULC;                             /* 0A04H GWGRLULC */
  uint32 ulReserved20[30];                       /*       Reserved20 */
  struct STag_GWRL{
    uint32 ulGWRLCi;                             /* 0A80H GWRLCi */
    uint32 ulGWRLULCi;                           /* 0A84H GWRLULCi */
  } GWRL[ETH_GWCA_AXI_TLIM_N];
  uint32 ulGWIDPC;                               /* 0B80H GWIDPC */
  uint32 ulReserved21[31];                       /*       Reserved21 */
  uint32 ulGWIDCi[ETH_RACE_AXI_CHAIN_N];         /* 0C00H GWIDCi */
  uint32 ulReserved22[128];                      /*       Reserved22 */
  uint32 ulGWRDCN;                               /* 1000H GWRDCN */
  uint32 ulGWTDCN;                               /* 1004H GWTDCN */
  uint32 ulGWTSCN;                               /* 1008H GWTSCN */
  uint32 ulGWTSOVFECN;                           /* 100CH GWTSOVFECN */
  uint32 ulGWUSMFSECN;                           /* 1010H GWUSMFSECN */
  uint32 ulGWTFECN;                              /* 1014H GWTFECN */
  uint32 ulGWSEQECN;                             /* 1018H GWSEQECN */
  uint32 ulReserved23;                           /*       Reserved23 */
  uint32 ulGWTXDNECN;                            /* 1020H GWTXDNECN */
  uint32 ulGWFSECN;                              /* 1024H GWFSECN */
  uint32 ulGWTDFECN;                             /* 1028H GWTDFECN */
  uint32 ulGWTSDNECN;                            /* 102CH GWTSDNECN */
  uint32 ulGWDQOECN;                             /* 1030H GWDQOECN */
  uint32 ulGWDQSECN;                             /* 1034H GWDQSECN */
  uint32 ulGWDFECN;                              /* 1038H GWDFECN */
  uint32 ulGWDSECN;                              /* 103CH GWDSECN */
  uint32 ulGWDSZECN;                             /* 1040H GWDSZECN */
  uint32 ulGWDCTECN;                             /* 1044H GWDCTECN */
  uint32 ulGWRXDNECN;                            /* 1048H GWRXDNECN */
  uint32 ulReserved24[12];                       /*       Reserved24 */
  uint32 ulGWLDCN;                               /* 107CH GWLDCN */
  uint32 ulGWRDCN_E;                             /* 1080H GWRDCN(E) */
  uint32 ulGWTDCN_E;                             /* 1084H GWTDCN(E) */
  uint32 ulGWTSCN_E;                             /* 1088H GWTSCN(E) */
  uint32 ulGWTSOVFECN_E;                         /* 108CH GWTSOVFECN(E) */
  uint32 ulGWUSMFSECN_E;                         /* 1090H GWUSMFSECN(E) */
  uint32 ulGWTFECN_E;                            /* 1094H GWTFECN(E) */
  uint32 ulGWSEQECN_E;                           /* 1098H GWSEQECN(E) */
  uint32 ulReserved25;                           /*       Reserved25 */
  uint32 ulGWTXDNECN_E;                          /* 10A0H GWTXDNECN(E) */
  uint32 ulGWFSECN_E;                            /* 10A4H GWFSECN(E) */
  uint32 ulGWTDFECN_E;                           /* 10A8H GWTDFECN(E) */
  uint32 ulGWTSDNECN_E;                          /* 10ACH GWTSDNECN(E) */
  uint32 ulGWDQOECN_E;                           /* 10B0H GWDQOECN(E) */
  uint32 ulGWDQSECN_E;                           /* 10B4H GWDQSECN(E) */
  uint32 ulGWDFECN_E;                            /* 10B8H GWDFECN(E) */
  uint32 ulGWDSECN_E;                            /* 10BCH GWDSECN(E) */
  uint32 ulGWDSZECN_E;                           /* 10C0H GWDSZECN(E) */
  uint32 ulGWDCTECN_E;                           /* 10C4H GWDCTECN(E) */
  uint32 ulGWRXDNECN_E;                          /* 10C8H GWRXDNECN(E) */
  uint32 ulReserved26[12];                       /*       Reserved26 */
  uint32 ulGWLDCN_E;                             /* 10FCH GWLDCN (E) */
  struct STag_GWDI{
    uint32 ulGWDISi;                             /* 1100H GWDISi */
    uint32 ulGWDIEi;                             /* 1104H GWDIEi */
    uint32 ulGWDIDi;                             /* 1108H GWDIDi */
    uint32 ulGWDIDSi;                            /* 110CH GWDIDSi */
  } GWDI[ETH_RACE_AXI_CHAIN_N/32UL];
  uint32 ulReserved27[16];                       /*       Reserved27 */
  uint32 ulGWTSDIS;                              /* 1180H GWTSDIS */
  uint32 ulGWTSDIE;                              /* 1184H GWTSDIE */
  uint32 ulGWTSDID;                              /* 1188H GWTSDID */
  uint32 ulReserved28;                           /*       Reserved28 */
  uint32 ulGWEIS0;                               /* 1190H GWEIS0 */
  uint32 ulGWEIE0;                               /* 1194H GWEIE0 */
  uint32 ulGWEID0;                               /* 1198H GWEID0 */
  uint32 ulReserved29;                           /*       Reserved29 */
  uint32 ulGWEIS1;                               /* 11A0H GWEIS1 */
  uint32 ulGWEIE1;                               /* 11A4H GWEIE1 */
  uint32 ulGWEID1;                               /* 11A8H GWEID1 */
  uint32 ulReserved30[21];                       /*       Reserved30 */
  struct STag_GWEI{
    uint32 ulGWEIS2i;                            /* 1200H GWEIS2i */
    uint32 ulGWEIE2i;                            /* 1204H GWEIE2i */
    uint32 ulGWEID2i;                            /* 1208H GWEID2i */
    uint32 ulReserved31;                         /*       Reserved31 */
  } GWEI[ETH_RACE_AXI_CHAIN_N/32UL];
  uint32 ulReserved32[16];                       /*       Reserved32 */
  uint32 ulGWEIS3;                               /* 1280H GWEIS3 */
  uint32 ulGWEIE3;                               /* 1284H GWEIE3 */
  uint32 ulGWEID3;                               /* 1288H GWEIS3 */
  uint32 ulReserved33;                           /*       Reserved33 */
  uint32 ulGWEIS4;                               /* 1290H GWEIS4 */
  uint32 ulGWEIE4;                               /* 1294H GWEIE4 */
  uint32 ulGWEID4;                               /* 1298H GWEIS4 */
  uint32 ulReserved34;                           /*       Reserved34 */
  uint32 ulGWEIS5;                               /* 12A0H GWEIS5 */
  uint32 ulGWEIE5;                               /* 12A4H GWEIE5 */
  uint32 ulGWEID5;                               /* 12A8H GWEIS5 */
  uint32 ulReserved35[341];                      /*       Reserved35 */
  uint32 ulGWSCR0;                               /* 1800H GWSCR0 */
  uint32 ulGWSCR1;                               /* 1804H GWSCR1 */
  uint32 ulReserved36[62];                       /*       Reserved36 */
  uint32 ulGWSCR2i[ETH_RACE_AXI_CHAIN_N/32UL];   /* 1900H GWSCR2i */
  uint32 ulReserved37[60];                       /*       Reserved37 */
  uint32 ulGWICD0RC;                             /* 1A00H GWICD0RC */
  uint32 ulGWICD1RC;                             /* 1A04H GWICD1RC */
  uint32 ulGWISD0RC;                             /* 1A08H GWISD0RC */
  uint32 ulGWISD1RC;                             /* 1A0CH GWISD1RC */
  uint32 ulGWECD0RC;                             /* 1A10H GWECD0RC */
  uint32 ulGWECD1RC;                             /* 1A14H GWECD1RC */
  uint32 ulGWESD0RC;                             /* 1A18H GWESD0RC */
  uint32 ulGWESD1RC;                             /* 1A1CH GWESD1RC */
  uint32 ulGWDQOECNPq[ETH_GWCA_FRM_PRIO_N];      /* 1A20H GWDQOECNPq */
  uint32 ulGWDQOECNPq_E[ETH_GWCA_FRM_PRIO_N];    /* 1A40H GWDQOECNPq (E)*/
} Eth_RSW3_GWCARegType;

/***********************************************************************************************************************
**                                             RSW3 ETHA module Registers                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_RSW3_ETHARegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulEAMC;                                 /* 0000H EAMC */
  uint32 ulEAMS;                                 /* 0004H EAMS */
  uint32 ulEATDRC;                               /* 0008H EATDRC */
  uint32 ulReserved0;                            /*       Reserved0 */
  uint32 ulEAIRC;                                /* 0010H EAIRC */
  uint32 ulEATDQSC;                              /* 0014H EATDQSC */
  uint32 ulEATDQC;                               /* 0018H EATDQC */
  uint32 ulEATDQAC;                              /* 001CH EATDQAC */
  uint32 ulEATPEC;                               /* 0020H EATPEC */
  uint32 ulReserved1[7];                         /*       Reserved1 */
  uint32 ulEATMFSCq[ETH_ETHA_FRM_PRIO_N];        /* 0040H EATMFSCq */
  uint32 ulEATDQDCq[ETH_ETHA_FRM_PRIO_N];        /* 0060H EATDQDCq */
  uint32 ulEATDQMq[ETH_ETHA_FRM_PRIO_N];         /* 0080H EATDQMq */
  uint32 ulEATDQMLMq[ETH_ETHA_FRM_PRIO_N];       /* 00A0H EATDQMLMq */
  uint32 ulEATDQMLMq_E[ETH_ETHA_FRM_PRIO_N];     /* 00C0H EATDQMLMq(E) */
  uint32 ulReserved2[8];                         /*       Reserved2 */
  uint32 ulEACTQC;                               /* 0100H EACTQC */
  uint32 ulEACTDQDC;                             /* 0104H EACTDQDC */
  uint32 ulEACTDQM;                              /* 0108H EACTDQM*/
  uint32 ulEACTDQMLM;                            /* 010CH EACTDQMLM*/
  uint32 ulEACTDQMLM_E;                          /* 0110H EACTDQMLM (E)*/
  uint32 ulReserved3[7];                         /*       Reserved3 */
  uint32 ulEAVCC;                                /* 0130H EAVCC */
  uint32 ulEAVTC;                                /* 0134H EAVTC */
  uint32 ulEARTFC;                               /* 0138H EARTFC */
  uint32 ulReserved4[49];                        /*       Reserved4 */
  uint32 ulEACAEC;                               /* 0200H EACAEC */
  uint32 ulEACC;                                 /* 0204H EACC */
  uint32 ulReserved5[6];                         /*       Reserved5 */
  uint32 ulEACAIVCq[ETH_ETHA_FRM_PRIO_N];        /* 0220H EACAIVCq */
  uint32 ulEACAULCq[ETH_ETHA_FRM_PRIO_N];        /* 0240H EACAULCq */
  uint32 ulEACOEM;                               /* 0260H EACOEM */
  uint32 ulReserved6[7];                         /*       Reserved6 */
  uint32 ulEACOIVMq[ETH_ETHA_FRM_PRIO_N];        /* 0280H EACOIVMq */
  uint32 ulEACOULMq[ETH_ETHA_FRM_PRIO_N];        /* 02A0H EACOULMq */
  uint32 ulEACGSM;                               /* 02C0H EACGSM */
  uint32 ulReserved7[15];                        /*       Reserved7 */
  uint32 ulEATASC;                               /* 0300H EATASC */
  uint32 ulEATASIGSC;                            /* 0304H EATASIGSC */
  uint32 ulReserved8[6];                         /*       Reserved8 */
  uint32 ulEATASENCi[ETH_ETHA_FRM_PRIO_N];       /* 0320H EATASENCi */
  uint32 ulReserved9[8];                         /*       Reserved9 */
  uint32 ulEATASENMi[ETH_ETHA_FRM_PRIO_N];       /* 0360H EATASENMi */
  uint32 ulReserved10[8];                         /*      Reserved10 */
  uint32 ulEATASCSTC0;                           /* 03A0H EATASCSTC0 */
  uint32 ulEATASCSTC1;                           /* 03A4H EATASCSTC1 */
  uint32 ulEATASCSTM0;                           /* 03A8H EATASCSTM0 */
  uint32 ulEATASCSTM1;                           /* 03ACH EATASCSTM1 */
  uint32 ulEATASCTC;                             /* 03B0H EATASCTC */
  uint32 ulEATASCTM;                             /* 03B4H EATASCTM */
  uint32 ulReserved11[2];                        /*       Reserved11 */
  uint32 ulEATASGL0;                             /* 03C0H EATASGL0 */
  uint32 ulEATASGL1;                             /* 03C4H EATASGL1 */
  uint32 ulEATASGLR;                             /* 03C8H EATASGLR */
  uint32 ulReserved12;                           /*       Reserved12 */
  uint32 ulEATASGR;                              /* 03D0H EATASGR */
  uint32 ulEATASGRR;                             /* 03D4H EATASGRR */
  uint32 ulReserved13[2];                        /*       Reserved13 */
  uint32 ulEATASHCC;                             /* 03E0H EATASHCC */
  uint32 ulEATASRIRM;                            /* 03E4H EATASRIRM */
  uint32 ulEATASSM;                              /* 03E8H EATASSM */
  uint32 ulReserved14[5];                        /*       Reserved14 */
  uint32 ulEAUSMFSECN;                           /* 0400H EAUSMFSECN */
  uint32 ulEATFECN;                              /* 0404H EATFECN */
  uint32 ulEAFSECN;                              /* 0408H EAFSECN */
  uint32 ulEADQOECN;                             /* 040CH EADQOECN */
  uint32 ulEADQSECN;                             /* 0410H EADQSECN */
  uint32 ulReserved15[26];                       /*       Reserved15 */
  uint32 ulEALDCN;                               /* 047CH EALDCN */
  uint32 ulEAUSMFSECN_E;                         /* 0480H EAUSMFSECN(E) */
  uint32 ulEATFECN_E;                            /* 0484H EATFECN(E) */
  uint32 ulEAFSECN_E;                            /* 0488H EAFSECN(E) */
  uint32 ulEADQOECN_E;                           /* 048CH EADQOECN(E) */
  uint32 ulEADQSECN_E;                           /* 0490H EADQSECN(E) */
  uint32 ulReserved16[26];                       /*       Reserved16 */
  uint32 ulEALDCN_E;                             /* 04FCH EALDCN (E) */
  uint32 ulEAEIS0;                               /* 0500H EAEIS0 */
  uint32 ulEAEIE0;                               /* 0504H EAEIE0 */
  uint32 ulEAEID0;                               /* 0508H EAEID0 */
  uint32 ulReserved17;                           /*       Reserved17 */
  uint32 ulEAEIS1;                               /* 0510H EAEIS1 */
  uint32 ulEAEIE1;                               /* 0514H EAEIE1 */
  uint32 ulEAEID1;                               /* 0518H EAEID1 */
  uint32 ulReserved18;                           /*       Reserved18 */
  uint32 ulEAEIS2;                               /* 0520H EAEIS2 */
  uint32 ulEAEIE2;                               /* 0524H EAEIE2 */
  uint32 ulEAEID2;                               /* 0528H EAEID2 */
  uint32 ulReserved19[21];                       /*       Reserved19 */
  uint32 ulEASCR;                                /* 0580H EASCR */
  uint32 ulReserved20[21];                       /*       Reserved20 */
  uint32 ulEAICD0RC;                             /* 0600H EAICD0RC */
  uint32 ulEAICD1RC;                             /* 0604H EAICD1RC */
  uint32 ulEAISD0RC;                             /* 0608H EAISD0RC */
  uint32 ulEAISD1RC;                             /* 060CH EAISD1RC */
  uint32 ulEAECD0RC;                             /* 0610H EAECD0RC */
  uint32 ulEAECD1RC;                             /* 0614H EAECD1RC */
  uint32 ulEAESD0RC;                             /* 0618H EAESD0RC */
  uint32 ulEAESD1RC;                             /* 061CH EAESD1RC */
  uint32 ulReserved21[56];                       /*       Reserved21 */
  uint32 ulEARFCNEO0;                            /* 0700H EARFCNEO0 */
  uint32 ulEARFCNEO1;                            /* 0704H EARFCNEO1 */
  uint32 ulEARFCNEO2;                            /* 0708H EARFCNEO2 */
  uint32 ulEARFCNEO3;                            /* 070CH EARFCNEO3 */
  uint32 ulEARFCNEO4;                            /* 0710H EARFCNEO4 */
  uint32 ulEARFCNEO5;                            /* 0714H EARFCNEO5 */
  uint32 ulEARFCNEO6;                            /* 0718H EARFCNEO6 */
  uint32 ulEARFCNPO0;                            /* 071CH EARFCNPO0 */
  uint32 ulEARFCNPO1;                            /* 0720H EARFCNPO1 */
  uint32 ulEARFCNPO2;                            /* 0724H EARFCNPO2 */
  uint32 ulEARFCNPO3;                            /* 0728H EARFCNPO3 */
  uint32 ulEARFCNPO4;                            /* 072CH EARFCNPO4 */
  uint32 ulEARFCNPO5;                            /* 0730H EARFCNPO5 */
  uint32 ulEARFCNPO6;                            /* 0734H EARFCNPO6 */
  uint32 ulReserved22[2];                        /*       Reserved22 */
  uint32 ulEADQOECNPq[ETH_ETHA_FRM_PRIO_N];      /* 0740H  EADQOECNPq */
  uint32 ulEADQOECNCT;                           /* 0760H EADQOECNCT */
  uint32 ulReserved23[7];                        /*       Reserved23 */
  uint32 ulEARFCNEO0_E;                          /* 0780H EARFCNEO0 (E)*/
  uint32 ulEARFCNEO1_E;                          /* 0784H EARFCNEO1 (E)*/
  uint32 ulEARFCNEO2_E;                          /* 0788H EARFCNEO2 (E)*/
  uint32 ulEARFCNEO3_E;                          /* 078CH EARFCNEO3 (E)*/
  uint32 ulEARFCNEO4_E;                          /* 0790H EARFCNEO4 (E)*/
  uint32 ulEARFCNEO5_E;                          /* 0794H EARFCNEO5 (E)*/
  uint32 ulEARFCNEO6_E;                          /* 0798H EARFCNEO6 (E)*/
  uint32 ulEARFCNPO0_E;                          /* 079CH EARFCNPO0 (E)*/
  uint32 ulEARFCNPO1_E;                          /* 07A0H EARFCNPO1 (E)*/
  uint32 ulEARFCNPO2_E;                          /* 07A4H EARFCNPO2 (E)*/
  uint32 ulEARFCNPO3_E;                          /* 07A8H EARFCNPO3 (E)*/
  uint32 ulEARFCNPO4_E;                          /* 07ACH EARFCNPO4 (E)*/
  uint32 ulEARFCNPO5_E;                          /* 07B0H EARFCNPO5 (E)*/
  uint32 ulEARFCNPO6_E;                          /* 07B4H EARFCNPO6 (E)*/
  uint32 ulReserved24[2];                        /*       Reserved24 */
  uint32 ulEADQOECNPq_E[ETH_ETHA_FRM_PRIO_N];    /* 07C0H EADQOECNPq (E) */
  uint32 ulEADQOECNCT_E;                         /* 07E0H EADQOECNCT (E) */
  uint32 ulRMRO;                                 /* 1000H RMRO */
} Eth_RSW3_ETHARegType;

/***********************************************************************************************************************
**                                             RSW3 RMAC module Registers                                             **
***********************************************************************************************************************/
typedef struct STag_Eth_RSW3_RMACRegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulMPSM;                                 /* 0000H MPSM */
  uint32 ulMPIC;                                 /* 0004H MPIC */
  uint32 ulMPIM;                                 /* 0008H MPIM */
  uint32 ulReserved;                             /*       Reserved0 */
  uint32 ulMIOC;                                 /* 0010H MIOC */
  uint32 ulReserved0[3];                         /*       Reserved0 */
  uint32 ulMTFFC;                                /* 0020H MTFFC */
  uint32 ulMTPFC;                                /* 0024H MTPFC */
  uint32 ulMTPFC2;                               /* 0028H MTPFC2 */
  uint32 ulReserved1;                            /*       Reserved1 */
  uint32 ulMTPFC3t[ETH_RACE_PAS_LVL_N];          /* 0030H MTPFC3t */
  uint32 ulReserved2[10];                        /*       Reserved2 */
  uint32 ulMTIM;                                 /* 0060H MTIM */
  uint32 ulReserved4[7];                         /*       Reserved4 */
  uint32 ulMRGC;                                 /* 0080H MRGC */
  uint32 ulMRMAC0;                               /* 0084H MRMAC0 */
  uint32 ulMRMAC1;                               /* 0088H MRMAC1 */
  uint32 ulMRAFC;                                /* 008CH MRAFC */
  uint32 ulMRSCE;                                /* 0090H MRSCE */
  uint32 ulMRSCP;                                /* 0094H MRSCP */
  uint32 ulMRSCC;                                /* 0098H MRSCC */
  uint32 ulMRFSCE;                               /* 009CH MRFSCE */
  uint32 ulMRFSCP;                               /* 00A0H MRFSCP */
  uint32 ulMTRC;                                 /* 00A4H MTRC */
  uint32 ulMRIM;                                 /* 00A8H MRIM */
  uint32 ulMRPFM;                                /* 00ACH MRPFM */
  uint32 ulReserved5[20];                        /*       Reserved5 */
  uint32 ulMPFCt[ETH_RACE_PTP_TN*8UL];           /* 0100H MPFCt */
  uint32 ulReserved6[16];                        /*       Reserved6 */
  uint32 ulMLVC;                                 /* 0180H MLVC */
  uint32 ulMEEEC;                                /* 0184H MEEEC */
  uint32 ulMLBC;                                 /* 0188H MLBC */
  uint32 ulReserved7;                            /*       Reserved7 */
  uint32 ulMXGMIIC;                              /* 0190H MXGMIIC */
  uint32 ulMPCH;                                 /* 0194H MPCH */
  uint32 ulMANC;                                 /* 0198H MANC */
  uint32 ulMANM;                                 /* 019CH MANM */
  uint32 ulReserved8[24];                        /*       Reserved8 */
  uint32 ulMEIS;                                 /* 0200H MEIS */
  uint32 ulMEIE;                                 /* 0204H MEIE */
  uint32 ulMEID;                                 /* 0208H MEID */
  uint32 ulReserved9;                            /*       Reserved9 */
  uint32 ulMMIS0;                                /* 0210H MMIS0 */
  uint32 ulMMIE0;                                /* 0214H MMIE0 */
  uint32 ulMMID0;                                /* 0218H MMID0 */
  uint32 ulReserved10;                           /*       Reserved10 */
  uint32 ulMMIS1;                                /* 0220H MMIS1 */
  uint32 ulMMIE1;                                /* 0224H MMIE1 */
  uint32 ulMMID1;                                /* 0228H MMID1 */
  uint32 ulReserved11;                           /*       Reserved11 */
  uint32 ulMMIS2;                                /* 0230H MMIS2 */
  uint32 ulMMIE2;                                /* 0234H MMIE2 */
  uint32 ulMMID2;                                /* 0238H MMID2 */
  uint32 ulReserved12[49];                       /*       Reserved12 */
  uint32 ulMMPFTCT;                              /* 0300H MMPFTCT */
  uint32 ulMAPFTCT;                              /* 0304H MAPFTCT */
  uint32 ulMPFRCT;                               /* 0308H MPFRCT */
  uint32 ulMFCICT;                               /* 030CH MFCICT */
  uint32 ulMEEECT;                               /* 0310H MEEECT */
  uint32 ulReserved13[3];                        /*       Reserved13 */
  uint32 ulMMPCFTCTt[ETH_RACE_PAS_LVL_N];        /* 0320H MMPCFTCTt */
  uint32 ulReserved14[2];                        /*       Reserved14 */
  uint32 ulMAPCFTCTt[ETH_RACE_PAS_LVL_N];        /* 0330H MAPCFTCTt */
  uint32 ulReserved15[2];                        /*       Reserved15 */
  uint32 ulMPCFRCTt[ETH_ETHA_FRM_PRIO_N];        /* 0340H MMPCFTCTt */
  uint32 ulMROVFC;                               /* 0360H MROVFC */
  uint32 ulMRHCRCEC;                             /* 0364H MRHCRCEC */
  uint32 ulReserved16[40];                       /*       Reserved16 */
  uint32 ulMRGFCE;                               /* 0408H MRGFCE */
  uint32 ulMRGFCP;                               /* 040CH MRGFCP */
  uint32 ulMRBFC;                                /* 0410H MRBFC */
  uint32 ulMRMFC;                                /* 0414H MRMFC */
  uint32 ulMRUFC;                                /* 0418H MRUFC */
  uint32 ulMRPEFC;                               /* 041CH MRPEFC */
  uint32 ulMRNEFC;                               /* 0420H MRNEFC */
  uint32 ulMRFMEFC;                              /* 0424H MRFMEFC */
  uint32 ulMRFFMEFC;                             /* 0428H MRFFMEFC */
  uint32 ulMRCFCEFC;                             /* 042CH MRCFCEFC */
  uint32 ulMRFCEFC;                              /* 0430H MRFCEFC */
  uint32 ulMRRCFEFC;                             /* 0434H MRRCFEFC */
  uint32 ulMRFC;                                 /* 0438H MRFC */
  uint32 ulMRGUEFC;                              /* 043CH MRGUEFC */
  uint32 ulMRBUEFC;                              /* 0440H MRBUEFC */
  uint32 ulMRGOEFC;                              /* 0444H MRGOEFC */
  uint32 ulMRBOEFC;                              /* 0448H MRBOEFC */
  uint32 ulMRXBCEU;                              /* 044CH MRXBCEU */
  uint32 ulMRXBCEL;                              /* 0450H MRXBCEL */
  uint32 ulMRXBCPU;                              /* 0454H MRXBCPU */
  uint32 ulMRXBCPL;                              /* 0458H MRXBCPL */
  uint32 ulReserved17[43];                       /*       Reserved17 */
  uint32 ulMTGFCE;                               /* 0508H MTGFCE */
  uint32 ulMTGFCP;                               /* 050CH MTGFCP */
  uint32 ulMTBFC;                                /* 0510H MTBFC */
  uint32 ulMTMFC;                                /* 0514H MTMFC */
  uint32 ulMTUFC;                                /* 0518H MTUFC */
  uint32 ulMTEFC;                                /* 051CH MTEFC */
  uint32 ulMTXBCEU;                              /* 0520H MTXBCEU */
  uint32 ulMTXBCEL;                              /* 0524H MTXBCEL */
  uint32 ulMTXBCPU;                              /* 0528H MTXBCPU */
  uint32 ulMTXBCPL;                              /* 052CH MTXBCPL */
  uint32 ulMPBLTFCESPi[ETH_RMAC_PORT_N];         /* 0530H MPBLTFCESPi */
  uint32 ulMPBLTFCPSPi[ETH_RMAC_PORT_N];         /* 0570H MPBLTFCPSPi */
  uint32 ulMPBLTFCE;                             /* 05B0H MPBLTFCE */
  uint32 ulMPBLTFCP;                             /* 05B4H MPBLTFCP */
  uint32 ulReserved18[52];                       /*       Reserved18 */
} Eth_RSW3_RMACRegType;

/***********************************************************************************************************************
**                                             RSW3 gPTP module Registers                                             **
***********************************************************************************************************************/
/* gPTPa */
typedef struct STag_Eth_RSW3_gPTPRegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulPTPIPV;                                 /* 0000H PTPIPV */
  uint32 ulReserved0[3];                           /*       Reserved0 */
  uint32 ulPTPTMEC;                                /* 0010H PTPTMEC */
  uint32 ulPTPTMDC;                                /* 0014H PTPTMDC */
  uint32 ulReserved1[2];                           /*       Reserved1 */
  struct STag_PTP{
    uint32 ulPTPTIVCt;                             /* 0020H GWDISi */
    uint32 ulReserved2[3];                         /*       Reserved2 */
    uint32 ulPTPTOVC0t;                            /* 0030H GWDIEi */
    uint32 ulPTPTOVC1t;                            /* 0034H GWDIDi */
    uint32 ulPTPTOVC2t;                            /* 0038H GWDIDSi */
    uint32 ulReserved3;                            /*       Reserved3 */
    uint32 ulPTPAVTPTM0t;                          /* 0040H GWDIDSi */
    uint32 ulPTPAVTPTM1t;                          /* 0044H GWDIDSi */
    uint32 ulReserved4[2];                         /*       Reserved4 */
    uint32 ulPTPGPTPTM0t;                          /* 0050H GWDIDSi */
    uint32 ulPTPGPTPTM1t;                          /* 0054H GWDIDSi */
    uint32 ulPTPGPTPTM2t;                          /* 0058H GWDIDSi */
    uint32 ulReserved5;                            /*       Reserved5 */
  } PTP[ETH_RACE_PTP_TN];
  uint32 ulReserved6[88];                          /*       Reserved6 */
  struct STag_PTPMCC{
    uint32 ulPTPMCCCm;                             /* 0200H PTPMCCCm */
    uint32 ulPTPMCCM0m;                            /* 0204H PTPMCCM0m */
    uint32 ulPTPMCCM1m;                            /* 0208H PTPMCCM1m */
    uint32 ulPTPMCCM2m;                            /* 020CH PTPMCCM2m */
  } PTPMCC[ETH_MEDIA_CAPT_N];
  uint32 ulReserved7[56];                          /*       Reserved7 */
  struct STag_PTPMCR{
    uint32 ulPTPMCRCm;                             /* 0300H PTPMCCCm */
    uint32 ulPTPMCRTC0m;                           /* 0304H PTPMCCM0m */
    uint32 ulPTPMCRTC1m;                           /* 0308H PTPMCCM1m */
    uint32 ulPTPMCRTC2m;                           /* 030CH PTPMCCM2m */
  } PTPMCR[ETH_MEDIA_RECV_N];
  uint32 ulReserved8[56];                          /*       Reserved8 */
  uint32 ulPTPMCPCm[ETH_MEDIA_RECV_N];             /* 0400H ulPTPMCPCm */
  uint32 ulReserved9[62];                          /*       Reserved9 */
  struct STag_PTPCCC{
    uint32 ulPTPCCC0c;                             /* 0500H PTPCCC0c */
    uint32 ulPTPCCC1c;                             /* 0504H PTPCCC1c */
  } PTPCCC[ETH_CYC_COMP_N];
  uint32 ulReserved10[112];                        /*       Reserved10 */
  uint32 ulPTPIS0;                                 /* 0700H PTPIS0 */
  uint32 ulPTPIE0;                                 /* 0704H PTPIE0 */
  uint32 ulPTPID0;                                 /* 0708H PTPID0 */
  uint32 ulReserved11;                             /*       Reserved11 */
  uint32 ulPTPIS1;                                 /* 0710H PTPIS1 */
  uint32 ulPTPIE1;                                 /* 0714H PTPIE1 */
  uint32 ulPTPID1;                                 /* 0718H PTPID1 */
  uint32 ulReserved12[25];                         /*       Reserved12 */
  uint32 ulPTPSCR0;                                /* 0780H PTPSCR0 */
  uint32 ulPTPSCR1;                                /* 0784H PTPSCR1 */
  uint32 ulPTPSCR2;                                /* 0788H PTPSCR2 */
} Eth_RSW3_gPTPRegType;

/* gPTPb */
typedef struct STag_Eth_RSW3_gPTPBRegType                                                                                /* PRQA S 3630 # JV-01 */
{
  uint32 ulPTPIPV;                                 /* 0000H PTPIPV */
  uint32 ulReserved0[3];                           /*       Reserved0 */
  uint32 ulPTPTMEC;                                /* 0010H PTPTMEC */
  uint32 ulPTPTMDC;                                /* 0014H PTPTMDC */
  uint32 ulReserved1[2];                           /*       Reserved1 */
  struct STag_gPTPb_PTP{
    uint32 ulPTPTIVCt;                             /* 0020H GWDISi */
    uint32 ulReserved2[3];                         /*       Reserved2 m*/
    uint32 ulPTPTOVC0t;                            /* 0030H GWDIEi */
    uint32 ulPTPTOVC1t;                            /* 0034H GWDIDi */
    uint32 ulPTPTOVC2t;                            /* 0038H GWDIDSi */
    uint32 ulReserved3;                            /*       Reserved3 */
    uint32 ulPTPAVTPTM0t;                          /* 0040H GWDIDSi */
    uint32 ulPTPAVTPTM1t;                          /* 0044H GWDIDSi */
    uint32 ulReserved4[2];                         /*       Reserved4 */
    uint32 ulPTPGPTPTM0t;                          /* 0050H GWDIDSi */
    uint32 ulPTPGPTPTM1t;                          /* 0054H GWDIDSi */
    uint32 ulPTPGPTPTM2t;                          /* 0058H GWDIDSi */
    uint32 ulReserved5;                            /*       Reserved5 */
  } PTP[ETH_RACE_PTP_TN];
  uint32 ulReserved6[88];                          /*       Reserved6 */
  struct STag_gPTPb_PTPMCC{
    uint32 ulPTPMCCCm;                             /* 0200H PTPMCCCm */
    uint32 ulPTPMCCM0m;                            /* 0204H PTPMCCM0m */
    uint32 ulPTPMCCM1m;                            /* 0208H PTPMCCM1m */
    uint32 ulPTPMCCM2m;                            /* 020CH PTPMCCM2m */
  } PTPMCC[ETH_MEDIA_CAPT_N];
  uint32 ulReserved7[56];                          /*       Reserved7 */
  struct STag_gPTPb_PTPMCR{
    uint32 ulPTPMCRCm;                             /* 0300H PTPMCCCm */
    uint32 ulPTPMCRTC0m;                           /* 0304H PTPMCCM0m */
    uint32 ulPTPMCRTC1m;                           /* 0308H PTPMCCM1m */
    uint32 ulPTPMCRTC2m;                           /* 030CH PTPMCCM2m */
  } PTPMCR[ETH_MEDIA_RECV_N];
  uint32 ulReserved8[56];                          /*       Reserved8 */
  uint32 ulPTPMCPCm[ETH_MEDIA_RECV_N];             /* 0400H ulPTPMCPCm */
  uint32 ulReserved9[30];                          /*       Reserved9 */
  struct STag_gPTPb_PTPCCC{
    uint32 ulPTPCCC0c;                             /* 0480H PTPCCC0c */
    uint32 ulPTPCCC1c;                             /* 0484H PTPCCC1c */
  } PTPCCC[ETH_CYC_COMP_N];
  uint32 ulReserved10[17];                         /*       Reserved9 */
  struct STag_gPTPb_PTPMCC_A{
    uint32 ulPTPMCCCAm;                            /* 0200H PTPMCCCm */
    uint32 ulPTPMCCMA0m;                           /* 0204H PTPMCCM0m */
    uint32 ulPTPMCCMA1m;                           /* 0208H PTPMCCM1m */
    uint32 ulPTPMCCMA2m;                           /* 020CH PTPMCCM2m */
  } PTPMCC_A[ETH_MEDIA_CAPT_ADD_N];
  uint32 ulReserved11[112];                        /*       Reserved10 */
  uint32 ulPTPIS0;                                 /* 0700H PTPIS0 */
  uint32 ulPTPIE0;                                 /* 0704H PTPIE0 */
  uint32 ulPTPID0;                                 /* 0708H PTPID0 */
  uint32 ulReserved12;                             /*       Reserved11 */
  uint32 ulPTPIS1;                                 /* 0710H PTPIS1 */
  uint32 ulPTPIE1;                                 /* 0714H PTPIE1 */
  uint32 ulPTPID1;                                 /* 0718H PTPID1 */
  uint32 ulPTPIS2;                                 /* 0720H PTPIS2 */
  uint32 ulPTPIE2;                                 /* 0724H PTPIE2 */
  uint32 ulPTPID2;                                 /* 0728H PTPID2 */
  uint32 ulReserved13[22];                         /*       Reserved12 */
  uint32 ulPTPSCR0;                                /* 0780H PTPSCR0 */
  uint32 ulPTPSCR1;                                /* 0784H PTPSCR1 */
  uint32 ulPTPSCR2;                                /* 0788H PTPSCR2 */
} Eth_RSW3_gPTPBRegType;

/* Limit the statistics counter value, because where the maximal possible value shall denote an invalid value */
#define ETH_STATISTICS_MAXVALUE   (ETH_UINT32_MAXVALUE - 1UL)
#define ETH_STATISTICS_LIMIT(val) ((ETH_UINT32_MAXVALUE == (val)) ? ((uint32)((val) - 1UL)) : ((uint32)(val)))          /* PRQA S 3472 # JV-01 */

/* Statistics counter register values */
typedef struct Stag_Eth_StatsRegValueType
{
  uint32 ulMROVFC;  /* Receive overflow Counter */
  uint32 ulMRFMEFC; /* RMAC Received FCS/mCRC error frame count */
  uint32 ulMRGUEFC; /* RMAC Received good undersize error frame count */
  uint32 ulMRBUEFC; /* RMAC Received bad undersize error frame count */
  uint32 ulMRGOEFC; /* RMAC Received good oversize error frame count */
  uint32 ulMRBOEFC; /* RMAC Received bad oversize error frame count */
  uint32 ulMRNEFC;  /* RMAC Received nibble error frame count */
  uint32 ulMRFCEFC; /* RMAC Received fragment count error frame count */
  uint32 ulMRGFCE;  /* RMAC Received good frame count E-frames */
  uint32 ulMRGFCP;  /* RMAC Received good frame count P-frames */
  uint32 ulMRBFC;   /* RMAC Received good broadcast frame counter */
  uint32 ulMRUFC;   /* RMAC Received good unicast frame counter */
  uint32 ulMRMFC;   /* RMAC Received good multicast frame counter */
  uint32 ulMTXBCEU; /* RMAC Transmitted byte counter E-frames upper side */
  uint32 ulMTXBCEL; /* RMAC Transmitted byte counter E-frames lower side */
  uint32 ulMTXBCPU; /* RMAC Transmitted byte counter P-frames upper side */
  uint32 ulMTXBCPL; /* RMAC Transmitted byte counter P-frames lower side */
  uint32 ulMTBFC;   /* RMAC Transmitted broadcast frame counter */
  uint32 ulMTMFC;   /* RMAC Transmitted multicast frame counter */
  uint32 ulMTUFC;   /* RMAC Transmitted unicast frame counter */
  uint32 ulMTEFC;   /* RMAC Transmitted error frame counter */
  uint32 ulMRPEFC;  /* RMAC Received PHY error frame count */
} Eth_StatsRegValueType;

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
#define ETH_START_SEC_CONST_UNSPECIFIED
#include "Eth_MemMap.h"

/* RSW3 TOP module register */
extern CONSTP2VAR(volatile Eth_RSW3_TOPRegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_TOPRegs;

/* RSW3 COMA module register */
extern CONSTP2VAR(volatile Eth_RSW3_COMARegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_COMARegs;

/* RSW3 MFWD module register */
extern CONSTP2VAR(volatile Eth_RSW3_MFWDRegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_MFWDRegs;

/* RSW3 GWCA module register */
extern CONSTP2VAR(volatile Eth_RSW3_GWCARegType, ETH_CONST, REGSPACE)
  Eth_GaaRSW3_GWCARegs[ETH_MAX_GWCA_SUPPORTED];

/* RSW3 ETHA module register */
extern CONSTP2VAR(volatile Eth_RSW3_ETHARegType, ETH_CONST, REGSPACE)
  Eth_GaaRSW3_ETHARegs[ETH_MAX_TSNA_SUPPORTED];

/* RSW3 RMAC module register */
extern CONSTP2VAR(volatile Eth_RSW3_RMACRegType, ETH_CONST, REGSPACE)
  Eth_GaaRSW3_RMACRegs[ETH_MAX_RMAC_SUPPORTED];

/* RSW3 gPTP module register */
extern CONSTP2VAR(volatile Eth_RSW3_gPTPRegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_GPTPRegs;

extern CONST(uint32, ETH_CONST) Eth_GaaRsw3PortType[ETH_RACE_PORT_N];
extern CONST(uint32, ETH_CONST) Eth_GaaRsw3PortMap[ETH_RACE_PORT_N];
#define ETH_STOP_SEC_CONST_UNSPECIFIED
#include "Eth_MemMap.h"
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwInit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwDisableController(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwEnableController(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwTransmit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulLenByte, CONST(boolean, AUTOMATIC) LblConfirmation);
#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounterPtr);                                                  /* PRQA S 3432 # JV-01 */
#endif
#if (ETH_GET_RX_STATS_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpRxStats);                                                     /* PRQA S 3432 # JV-01 */
#endif
#if (ETH_GET_TX_STATS_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpTxStats);                                                     /* PRQA S 3432 # JV-01 */
#endif
#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpTxErrorCounterValues);                           /* PRQA S 3432 # JV-01 */
#endif
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwMainFunction(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#if (ETH_CTRL_ENABLE_TX_POLLING == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwTxConfirmation(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif
#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_RSW_HwCheckFifoIndex(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulFifoIdx);
#endif
#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
extern FUNC(Eth_RxStatusType, ETH_PRIVATE_CODE) Eth_RSW_HwReceive(CONST(uint32, AUTOMATIC) LulCtrlIdx
                      , CONST(uint32, AUTOMATIC) LulFifoIdx
                    );
#endif

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwSetIncrementTimeForGptp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIncVal);

extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwSetOffsetTimeForGptp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeOffsetPtr);
#endif

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetCurrentTime(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                                                  /* PRQA S 3432 # JV-01 */

FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetCurrentTimeTuple(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) LpCurrentTimeTuplePtr);                                                /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetEgressTimeStamp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx,
  CONSTP2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                                                  /* PRQA S 3432 # JV-01 */
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetIngressTimeStamp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpDataPtr,
  CONSTP2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                                                  /* PRQA S 3432 # JV-01 */
#endif

#if (ETH_CTRL_ENABLE_MII == STD_ON)
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_RSW_HwReadMii(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
                   CONST(uint8, AUTOMATIC) LucRegIdx, CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr);        /* PRQA S 3432 # JV-01 */
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE)
    Eth_RSW_HwWriteMii(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
                   CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusRegVal);
#endif

extern FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_ResetRxDesc(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode);

extern FUNC(Eth_ExtRxStatusType, ETH_PRIVATE_CODE) Eth_RSW_RxQueueProcess(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucFifoIdx);
#if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON))
extern FUNC(void, ETH_PRIVATE_CODE) Eth_Gwca_DIS_Common_Isr(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);
#endif
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_Gwca_TSDIS_Common_Isr(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);
#endif

#if ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON))
extern FUNC(void, ETH_PRIVATE_CODE) Eth_Gwca_ERR_Common_Isr(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);
#endif

#if (ETH_COMA_ERR_ISR == STD_ON)
extern FUNC(void, ETH_PRIVATE_CODE) Eth_Coma_ERR_Common_Isr(void);
#endif

#if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) \
|| (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) \
|| (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) \
|| (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) \
|| (ETH_ETHA12_ERR_ISR == STD_ON))
extern FUNC(void, ETH_PRIVATE_CODE) Eth_Etha_ERR_Common_Isr(
  CONST(uint32, AUTOMATIC) LulETHAIdx);
#endif

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#endif /* !ETH_RSW3_LLDRIVER_H_ */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
