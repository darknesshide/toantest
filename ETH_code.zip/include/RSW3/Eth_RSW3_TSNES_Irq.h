/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_TSNES_Irq.h                                                                                */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2025 Renesas Electronics Corporation. All rights reserved.                                            */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of prototypes for Interrupt service routine for ethernet driver.                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.0.0: 09/09/2025    : Initial Version
 */
/**********************************************************************************************************************/
#ifndef ETH_RSW3_TSNES_IRQ_H
#define ETH_RSW3_TSNES_IRQ_H
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth_Types.h"
/* Included for version information macros */
#include "Os.h"

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions and do not conflict in linkage.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#if (ETH_MACRO_ETND == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETND_IRQ_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_ETND_IRQ_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_ETND_IRQ_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_ETND_IRQ_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_ETND_IRQ_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
#define ETH_DATAISR0                             0x00000000UL                                                           /* PRQA S 1710 # JV-01 */

#define ETH_ETND_EIS0_ECCFES_MASK               0x00000002UL
#define ETH_ETND_EIS0_AEIS_MASK                 0x00000001UL

#define ETH_ETND_TCIS_ERROR_MASK                 0x00000400UL
#define ETH_ETND_TCIS_CLEAR_ERROR_MASK           0x00000000UL
#define ETH_ETND_TIS2_ERROR_MASK                 0xFF010000UL
#define ETH_ETND_TIS2_CLEAR_ERROR_MASK           0x00000000UL
#define ETH_ETND_RIS_ERROR_MASK                  0x00000010UL
#define ETH_ETNE_EAEIE0_ERROR_MASK               0x00130000UL
#define ETH_ETNE_FWEIS1_ERROR_MASK               0x00000380UL

#define ETH_ETND_TSDIS_0_MASK                   0x00000001UL

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_CODE_FAST
#include "Eth_MemMap.h"
#if ((ETH_TSN0_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN0_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN1_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN1_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN2_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN2_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN2_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN3_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN3_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN3_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN4_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN4_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN4_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN5_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN5_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN5_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN6_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN6_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN6_DATAISR0(void);
#endif
#endif

#if ((ETH_TSN7_DATA0_ISR == STD_ON))
#if defined(Os_ETH_TSN7_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN7_DATAISR0(void);
#endif
#endif


#if (ETH_TSN0_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN0_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN1_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN1_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN2_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN2_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN2_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN3_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN3_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN3_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN4_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN4_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN4_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN5_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN5_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN5_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN6_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN6_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN6_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_TSN7_GENERAL_ISR == STD_ON)
#if defined(Os_ETH_TSN7_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN7_GENERALISR(void);                                                 /* PRQA S 1710 # JV-01 */
#endif
#endif

#define ETH_STOP_SEC_CODE_FAST
#include "Eth_MemMap.h"
#endif /* ETH_MACRO_ETND == STD_ON */
#endif /* ETH_RSW3_TSNES_IRQ_H */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/

