/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_Irq.h                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of prototypes for Interrupt service routine for ethernet driver.                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.0.3: 30/10/2025    : Corrected the function name of GWCA data and ETHA error interrupt service routine
 * 1.0.2: 16/09/2025    : Update correct macro vesion
 * 1.0.1: 24/11/2023    : Update to fix QAC violation
 * 1.0.0: 16/08/2023    : Initial Version
 */
/**********************************************************************************************************************/

#ifndef ETH_RSW3_IRQ_H
#define ETH_RSW3_IRQ_H

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth_Types.h"
/* Included for version information macros */
#include "Os.h"

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions and do not conflict in linkage.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_IRQ_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_RSW3_IRQ_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION
#define ETH_RSW3_IRQ_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_RSW3_IRQ_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION
#define ETH_RSW3_IRQ_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/
#define ETH_RSW3_TOP_TIM_GWDISIM_MASK       0x00000001UL
#define ETH_RSW3_TOP_TIM_GWTSDISIM_MASK     0x00000002UL
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/

#define ETH_START_SEC_CODE_FAST
#include "Eth_MemMap.h"

#if (ETH_GWCA0_DATA_ISR == STD_ON) || (ETH_GWCA1_DATA_ISR == STD_ON) || (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
#if defined (Os_ETH_GWCA0DISISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_GWCADISISR(void);
#endif
#endif

#if (ETH_GWCA0_ERR_ISR == STD_ON)
#if defined (Os_ETH_GWCA0ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_GWCA0ERRISR(void);                                                     /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_GWCA1_ERR_ISR == STD_ON)
#if defined (Os_ETH_GWCA1ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_GWCA1ERRISR(void);                                                     /* PRQA S 1710 # JV-01 */
#endif
#endif

#if (ETH_COMA_ERR_ISR == STD_ON)
#if defined (Os_ETH_COMAERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_COMAERRISR(void);                                                      /* PRQA S 1710 # JV-01 */
#endif
#endif

#if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) || \
     (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) || \
     (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) || \
     (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) || \
     (ETH_ETHA12_ERR_ISR == STD_ON))
#if defined (Os_ETH_ETHA0ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
#else
extern _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_ETHAERRISR(void);                                                      /* PRQA S 1710 # JV-01 */
#endif
#endif

#define ETH_STOP_SEC_CODE_FAST
#include "Eth_MemMap.h"

#endif  /* ETH_RSW3_IRQ_H */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
