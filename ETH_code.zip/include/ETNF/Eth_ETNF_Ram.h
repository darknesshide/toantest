/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETNF_Ram.h                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Ethernet driver global variables and the                                                        */
/* Ram Allocation functions                                                                                           */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *        25/06/2025    : Correct memmap mapping for Eth_Ctrl0_TxDescDataEtnf, Eth_Ctrl1_TxDescDataEtnf,
 *                        Eth_Ctrl0_RxDescDataEtnf, Eth_Ctrl1_RxDescDataEtnf.
 * 1.0.2: 13/03/2025    : Remove function Eth_ETNF_CheckProvideBuffer
 * 1.0.1: 24/02/2025    : Remove function Eth_ETNF_CheckBufferWithPiority.
 *                        Add function Eth_ETNF_GetImmTxBuffer.
 * 1.0.0: 21/10/2024    : Remove global variable Eth_GaaBufferLock since it is no longer used.
 *        28/09/2024    : Add new global variables Eth_Ctrl1_TxDescDataEtnf, Eth_Ctrl1_RxDescDataEtnf,
 *                        to support static memory.
 *        29/08/2024    : Add new global variables Eth_GaaLinkFixTable, Eth_Ctrl0_TxDescDataEtnf,
 *                        Eth_Ctrl0_RxDescDataEtnf, Eth_GaaTxDescTableEtnf, Eth_GaaRxDescTableEtnf
 *                        to support static memory.
 *                        Remove global variables Eth_GaaRxBufferIndex, Eth_GpRamManager
 *                        since dynamic memory is no long supported.
 *                        Remove functions Eth_Ram_Init, Eth_Ram_Alloc, Eth_Ram_Alloc, Eth_Ram_Free,
 *                        Eth_Ram_GetNextFreeAddr, Eth_Ram_SetCircularAddr since dynamic memory is no longer supported.
 *                        Add function Eth_ETNF_RamInit to support static memory.
 *                        Add function Eth_ETNF_CheckBufferWithPiority to support Eth_ImmediateTransmit API.
 *        09/04/2024    : Initial Version.
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/**********************************************************************************************************************/
#ifndef ETH_ETNF_RAM_H
#define ETH_ETNF_RAM_H
/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for utility definitions */
#include "Eth_Common_LLDriver.h"

/* Included for Type definitions */
#include "Eth_Types.h"

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#if (ETH_MACRO_ETNF == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETNF_RAM_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_ETNF_RAM_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_ETNF_RAM_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_ETNF_RAM_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_ETNF_RAM_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION
/***********************************************************************************************************************
**                                              MISRA C Rule Violations                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    QAC Warning                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"
/* LINKFIX table */
extern VAR(Eth_LinkDescType, ETH_VAR_NO_INIT)
    Eth_GaaLinkFixTable[ETH_TOTAL_CTRL_CONFIG][ETH_TXQ_NUM_ETNF + ETH_RXQ_NUM_ETNF];
#define ETH_STOP_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

extern VAR(Eth_RxChConfigType, ETH_VAR_NO_INIT) Eth_GaaRxConfig[ETH_TOTAL_CTRL_CONFIG][ETH_RXQ_NUM_ETNF];

extern VAR(Eth_AvbConfigType, ETH_VAR_NO_INIT) Eth_GaaAvbConfig[ETH_TOTAL_CTRL_CONFIG];

extern VAR(Eth_QConfigType, ETH_VAR_NO_INIT) Eth_GaaQConfig[ETH_TOTAL_CTRL_CONFIG][ETH_RXQ_NUM_ETNF];

#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

/* Tx Desc Data */
extern P2VAR(Eth_DataDescType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxDescTableEtnf[ETH_TOTAL_CTRL_CONFIG];              /* PRQA S 3432 # JV-01 */

/* Rx Desc Data */
extern P2VAR(Eth_ExtDataDescType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxDescTableEtnf[ETH_TOTAL_CTRL_CONFIG];           /* PRQA S 3432 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"
/* Function pointer variable for OSTM Unit configuration */
extern VAR(Eth_HwFuncTableType, ETH_VAR_INIT) Eth_EtnfFunc;
#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"

/***********************************************************************************************************************
**                                                   Macro Defines                                                    **
***********************************************************************************************************************/
#define ETH_DWORD_SIZE        4UL
#define ETH_ALIGN_TO_32BIT(n) ((((n) + ETH_DWORD_SIZE) - 1UL) & 0xFFFFFFFCUL)
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_InitializeBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_PreprocessBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_RamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx);
extern FUNC(BufReq_ReturnType, ETH_PRIVATE_CODE)
    Eth_ETNF_GetTxBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucPriority,
                    CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                   /* PRQA S 3432 # JV-01 */
                    CONSTP2VAR(uint8 *, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                             /* PRQA S 3432 # JV-01 */
                    CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr);                                           /* PRQA S 3432 # JV-01 */
extern FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE)
    Eth_ETNF_GetImmTxBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                    CONST(uint8, AUTOMATIC) LucPriority,
                    CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                   /* PRQA S 3432 # JV-01 */
                    P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                  /* PRQA S 3432 # JV-01 */
                    CONST(uint16, AUTOMATIC) LusFrameLength);
extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETNF_ReleaseTxBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx,
                        CONST(uint32, AUTOMATIC) LulBufIdx);
extern FUNC(void, ETH_PRIVATE_CODE)
    Eth_ETNF_PreprocessFrame(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
                        CONST(uint32, AUTOMATIC) LulFrameType,
                        CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
                        CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen);                                     /* PRQA S 3432 # JV-01 */

extern FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE)
    Eth_ETNF_FindTxBufferHandler(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
#endif /* ETH_ETNF_RAM_H  */
#endif /* ETH_MACRO_ETNF == STD_ON */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
