/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Util.h                                                                                          */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains software utility functions implementation of Eth Driver                                         */
/* Component.                                                                                                         */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.0: 01/08/2025    : Remove function Eth_Util_IniLinkedList, Eth_Util_EnqToList, Eth_Util_EnqToNode,
 *                        Eth_Util_PushToList, Eth_Util_PushToNode, Eth_Util_InsertToList, Eth_Util_InsertToNode,
 *                        Eth_Util_GetFromList, Eth_Util_GetFromNode, Eth_Util_RemoveToList, Eth_Util_RemoveToNode,
 *                        Eth_Util_AllRemoveToList, Eth_Util_AllRemoveToNode, Eth_Util_GetCountFromList,
 *                        Eth_Util_GetCountFromNode, Eth_Util_RamAlloc, Eth_Util_RamFree, Eth_Util_RamSetCircularAddr.
 * 1.0.0: 03/08/2024    : Add new function Eth_Util_MemCopy, Eth_Util_CalculateFrameLength
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/
#ifndef ETH_UTIL_H
#define ETH_UTIL_H

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/* AUTOSAR release version information */
#define ETH_UTIL_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_UTIL_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_UTIL_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* File version information */
#define ETH_UTIL_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_UTIL_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                   Global Symbols                                                   **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

extern FUNC(void, ETH_PRIVATE_CODE) Eth_Util_MemCopy(
  volatile P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDesPtr,                                                             /* PRQA S 3432 # JV-01 */
  volatile P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpSrcPtr,                                                             /* PRQA S 3432 # JV-01 */
  volatile CONSTP2CONST(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLength);

extern FUNC(uint16, ETH_PRIVATE_CODE) Eth_Util_CalculateFrameLength(ListElemStructType* HeaderListPtr,
                                                                    uint16 PayloadLength);

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"
#endif /* !ETH_UTIL_H */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
