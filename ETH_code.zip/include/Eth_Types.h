/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Types.h                                                                                         */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Provision of Ethernet Component specific types used within the module.                                             */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/
/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.4.2: 01/07/2026    : Update to add new type Eth_MeasurementIdxType.
 * 1.4.1: 24/04/2026    : Support Multicore for X5H
 * 1.4.0: 31/03/2026    : Update to add new elements ulCtrlConfigIdx and pCoreId2Index into type Eth_ConfigType
 *                        to support for multicore feature
 * 1.1.1: 16/09/2025    : Update to support TSN-ES
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 * 1.0.2: 12/05/2025    : Add define hardware device macro
 * 1.0.1: 13/03/2025    : Update to merging SingleMainline
 *                        + Commonize the type Eth_TxBufferType, Eth_BufHandlerType, Eth_RxFrameType,
 *                        Eth_RxBufManageType and move these type from Eth_<HWIP>_LLDriver.h to Eth_Types.h
 *                        + Update from ucIndex to ucHwipType
 * 1.0.0: 28/09/2024    : Add new type Eth_RxBufManageType.
 *                        Modify type Eth_HwFuncTableType to add element pResetRxDesc.
 *                        Modify type ETag_Eth_MediaInterfaceType to add element ETH_T1S.
 *        29/08/2024    : Modify type Eth_HwFuncTableType to add element pCheckBufferWithPiority.
 *        16/07/2024    : Add new types Eth_RateDeviationStatusType and Eth_RateDeviationType to support R23-11.
 *        09/04/2024    : Initial Version.
 */
/**********************************************************************************************************************/
#ifndef ETH_TYPES_H
#define ETH_TYPES_H

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0342)    : Using the glue operator '##'.                                                                */
/* Rule                : CERTCCM PRE05, MISRA C:2012 Rule-20.10                                                       */
/*                       REFERENCE - ISO:C90-6.8.3.3 The ## Operator                                                  */
/* JV-01 Justification : This can be accepted, due to the implementation is following AUTOSAR standard rule for SchM  */
/*                       module's name.                                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions and do not conflict in linkage.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3630)    : The implementation of this struct/union type should be hidden.                               */
/* Rule                :  MISRA C:2012 Dir-4.8                                                                        */
/* JV-01 Justification : This is accepted. Redundant of struct or union type has no affect to driver operation.       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1039)    : Treating array of length one as potentially flexible member.                                 */
/* Rule                : CERTCCM DCL38,  MISRA C:2012 Dir-1.1, Rule-1.2                                               */
/* JV-01 Justification : Use array of length as the final member has no problem by manual reviewing.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for Type definitions */
#include "Eth_GeneralTypes.h"

#include "Eth_Cfg.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#define ETH_AR_R23_11_VERSION                 490
#define ETH_AR_R22_11_VERSION                 480
#define ETH_AR_R21_11_VERSION                 470
#define ETH_AR_R19_11_VERSION                 450
#define ETH_AR_431_VERSION                    431
#define ETH_AR_422_VERSION                    422
/* AUTOSAR release version information */
#define ETH_TYPES_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION
#define ETH_TYPES_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION
#define ETH_TYPES_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION

/* Module Software version information */
#define ETH_TYPES_SW_MAJOR_VERSION            ETH_SW_MAJOR_VERSION
#define ETH_TYPES_SW_MINOR_VERSION            ETH_SW_MINOR_VERSION

/***********************************************************************************************************************
**                                                 GLOBAL DATA TYPES                                                  **
***********************************************************************************************************************/

/***********************************************************************************************************************
                        Section: MACROS
***********************************************************************************************************************/
/* Macros for boolean variables */
#define ETH_FALSE              (boolean)0
#define ETH_TRUE               (boolean)1

/* Byte length of Ethernet header */
#define ETH_HEADER_SIZE          14UL
/* Byte length of MAC address */
#define ETH_MACADDR_SIZE         6UL
#define ETH_SRC_DST_ADDRESS_SIZE 12UL
#define ETH_ETHERTYPE_SIZE       2UL
#define ETH_VLAN_SIZE            4UL
#define ETH_FCS_LENGTH           4UL

#define ETH_DEM_NOT_CONFIGURED   0x0000

/* Macros for hardware ip identifier */
#define ETH_HWIP_ETNC            0U
#define ETH_HWIP_ETNB            1U
#define ETH_HWIP_ETND            2U
#define ETH_HWIP_ETNE            3U
#define ETH_HWIP_ETNF            4U
#define ETH_HWIP_RSW2            5U
#define ETH_HWIP_RSW3            6U

/* Macros for hardware device identifier */
#define ETH_X5X                  0x00
#define ETH_U5X                  0x01

/* A valid rate deviaton value is available/calculated. */
#define ETH_RATE_OK                                       0x00
/* No valid rate deviation value available/calculated. */
#define ETH_RATE_NOT_AVAILABLE                            0xFE
/* The calculated rate deviation value exceeds limits. */
#define ETH_RATE_EXCEEDED                                 0xFF

#define Eth_TimeStampQualType                TimeStampQualType
#define Eth_TimeStampType                    TimeStampType
#define ETH_VALID                            VALID
#define ETH_INVALID                          INVALID
#define ETH_UNCERTAIN                        UNCERTAIN
/***********************************************************************************************************************
                        Section: Enumerators
***********************************************************************************************************************/

/***********************************************************************************************************************
**  Enum: Eth_MacLayerSpeedType                                                                                       **
**                                                                                                                    **
**  Mac speed                                                                                                         **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ETH_MAC_LAYER_SPEED_10M    - 10MBps                                                                             **
**    ETH_MAC_LAYER_SPEED_100M   - 100MBps                                                                            **
**    ETH_MAC_LAYER_SPEED_1G     - 1GBps                                                                              **
**    ETH_MAC_LAYER_SPEED_2500M  - 2.5GBps                                                                            **
**    ETH_MAC_LAYER_SPEED_5G     - 5GBps                                                                              **
**    ETH_MAC_LAYER_SPEED_10G    - 10GBps                                                                             **
***********************************************************************************************************************/
typedef enum ETag_Eth_MacLayerSpeedType
{
  ETH_MAC_LAYER_SPEED_10M = 0,
  ETH_MAC_LAYER_SPEED_100M,
  ETH_MAC_LAYER_SPEED_1G,
  ETH_MAC_LAYER_SPEED_2500M,
  ETH_MAC_LAYER_SPEED_5G,
  ETH_MAC_LAYER_SPEED_10G
} Eth_MacLayerSpeedType;

/***********************************************************************************************************************
**  Enum: Eth_DuplexModeType                                                                                          **
**                                                                                                                    **
**  Mac duplex mode                                                                                                   **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ETH_HALF_DUPLEX  - half duplex                                                                                  **
**    ETH_FULL_DUPLEX  - full duplex                                                                                  **
**    ETH_T1S_MODE     - t1s mode                                                                                     **
***********************************************************************************************************************/
typedef enum ETag_Eth_DuplexModeType
{
  ETH_HALF_DUPLEX = 0,
  ETH_FULL_DUPLEX,
  ETH_T1S_MODE
} Eth_DuplexModeType;

/***********************************************************************************************************************
**  Type: Eth_MediaInterfaceType                                                                                      **
**                                                                                                                    **
**  Setting option                                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ETH_MII   - select MII                                                                                          **
**    ETH_RMII  - select RMII                                                                                         **
**    ETH_SGMII - select SGMII                                                                                        **
**    ETH_T1S   - select T1S                                                                                          **
***********************************************************************************************************************/
typedef enum ETag_Eth_MediaInterfaceType
{
  ETH_MII = 0,
  ETH_RMII,
  ETH_SGMII,
  ETH_USXGMII,
  ETH_T1S,
  ETH_GMII,
} Eth_MediaInterfaceType;

/***********************************************************************************************************************
**  Type: Eth_HwMDIOType                                                                                              **
**                                                                                                                    **
**  Determine hardware support WriteMii or WriteMiiBit                                                                **
**                                                                                                                    **
**  Members:                                                                                                          **
***********************************************************************************************************************/
typedef enum ETag_Eth_HwMDIOType
{
  ETH_HW_WRITE_MII_BIT = 0,
  ETH_HW_WRITE_MII
} Eth_HwMDIOType;

/***********************************************************************************************************************
**  Type: Eth_OptionType                                                                                              **
**                                                                                                                    **
**  Setting option                                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ETH_DISABLE  - setting is disabled                                                                              **
**    ETH_ENABLE   - setting is enabled                                                                               **
***********************************************************************************************************************/
typedef enum ETag_Eth_OptionType
{
  ETH_DISABLE = 0,
  ETH_ENABLE
} Eth_OptionType;

#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
/***********************************************************************************************************************
**  Enum: Eth_MeasurementIdxType                                                                                      **
**                                                                                                                    **
**  Define the indices for the different measurement counters:                                                        **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ETH_MEAS_ALL                                    - Only usable if ResetNeeded is TRUE, will reset all            **
**                                                      measured data.                                                **
**    ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_TX_BUFFER  - Reset and/or retrieve number of denied Tx buffer              **
**                                                      provision requests.                                           **
**    ETH_MEAS_VENDOR_SPECIFIC_WARN_FULL_RX_BUFFER    - Reset and/or retrieve number of warning events which indicate **
**                                                      that all Rx buffers were occupied during frame reception.     **
**    ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_RX_BUFFER  - Reset and/or retrieve number of Rx frames dropped due to      **
**                                                      unavailable buffer.                                           **
***********************************************************************************************************************/
typedef enum ETag_Eth_MeasurementIdxType
{
  ETH_MEAS_ALL = 0,
  ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_TX_BUFFER,
  ETH_MEAS_VENDOR_SPECIFIC_WARN_FULL_RX_BUFFER,
  ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_RX_BUFFER
} Eth_MeasurementIdxType;
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
#endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */
/***********************************************************************************************************************
                        Section: Structures
***********************************************************************************************************************/

/***********************************************************************************************************************
**  Type: Eth_RxFrameType                                                                                       **
**                                                                                                                    **
**  Rx frame information structure (single frame single buffer)                                                       **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulFrameAddr    - frame address                                                                                  **
**    ulFrameLength  - frame length                                                                                   **
**    ulEthTypeAddr  - Ether type data pointer address                                                                **
**    stTimestamp    - timestamp if enabled                                                                           **
**    enTimeQual     - timestamp quality                                                                              **
**    ulTsns         - Timestamps nanosecond                                                                          **
**    ulTss          - Timestamp second                                                                               **
***********************************************************************************************************************/
typedef struct STag_Eth_RxFrameType
{
  uint32 ulFrameAddr;
  uint32 ulFrameLength;
  uint32 ulEthTypeAddr;
  #if ((ETH_GLOBAL_TIME_SUPPORT == STD_ON))
  Eth_TimeStampType stTimeStamp;                                                                                        /* PRQA S 1710 # JV-01 */
  Eth_TimeStampQualType enTimeQual;
  uint8 ucDummy1[3];
  #endif
} Eth_RxFrameType;

/***********************************************************************************************************************
**  Type: Eth_RxBufManageType                                                                                         **
**                                                                                                                    **
**  Setting option                                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulbufIdx      - The Index of buffer                                                                             **
**    ulbufAddr     - Pointer to the Frame in URAM  to be received                                                    **
**    ulRxDescAddr  - Address of Rx descriptor which shall use the buffer ulbufIdx                                    **
**    blLockedFlag  - Flag to store if TimeStamp shall be stored                                                      **
**    blRxConfirm   - The Rx Confirmation flag                                                                        **
**    ucQueueIdx    - Rx Queue index                                                                                  **
**    ucDummy       - Prevent miss alignment                                                                          **
***********************************************************************************************************************/
typedef struct STag_Eth_RxBufManageType                                                                                 /* PRQA S 3630 # JV-01 */
{
  uint32                        ulbufIdx;
  uint32                        ulbufAddr;
  uint32                        ulRxDescAddr;
  boolean                       blLockedFlag;
  boolean                       blRxConfirm;
  uint8                         ucRxQueueIdx;
  uint8                         ucDummy;
} Eth_RxBufManageType;
/***********************************************************************************************************************
**  Type: Eth_BufHandlerType                                                                                          **
**                                                                                                                    **
**  Setting option                                                                                                    **
**                                                                                                                    **
**  Members:                                                                                                          **
**    ulbufIdx      - the Index of buffer                                                                             **
**    ulbufAddr     - Pointer to the Frame in URAM  to be transmitted                                                 **
**    ulTxLength    - Transmit request size                                                                           **
**    ulEthTypeAddr - ether type address                                                                              **
**    ucPriority    - Buffer priority                                                                                 **
**    blEnableTS    - Flag to store if TimeStamp shall be stored                                                      **
**    blTxConfirm   - the Tx Confirmation flag                                                                        **
**    stTimeStamp   - Timestamp information                                                                           **
**    enTimeQual    - Timestamp quality                                                                               **
***********************************************************************************************************************/
typedef struct STag_Eth_BufHandlerType                                                                                  /* PRQA S 3630 # JV-01 */
{
  uint32             ulbufIdx;
  uint32             ulbufAddr;
  uint32             ulTxLength;
  uint32             ulEthTypeAddr;
  Eth_BufIdxType     ucTxHandleId;
  boolean            blbenableTS;
  boolean            blTxConfirm;
  boolean            blUsedFlag;
  boolean            blIsTxHandleId;
  uint8              ucTxQueueIdx;

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  TimeStampType stTimeStamp;
  TimeStampQualType enTimeQual;
  uint8 ucDummy1[3];
  #endif
} Eth_BufHandlerType;

/***********************************************************************************************************************
**  Type: Eth_TxBufferType                                                                                            **
**                                                                                                                    **
**  Transmission buffer structure                                                                                     **
**                                                                                                                    **
**  Members:                                                                                                          **
**    pBufferHdr   - Buffer Handler                                                                                   **
**    blTxOngoing  - Transmission flag in Buffer                                                                      **
***********************************************************************************************************************/
typedef struct STag_Eth_TxBufferType                                                                                    /* PRQA S 3630 # JV-01 */
{
  Eth_BufHandlerType    *pBufferHdr;
} Eth_TxBufferType;

/***********************************************************************************************************************
  Type: Eth_EthConfigType

  Structure for Ethernet Configuration
  Overall Module Configuration Data Structure

  Members:
    enEthSpeed              - Ethernet Speed configured
    enEthDuplex             - Ethernet Duplex Mode configured
    enInternalLoopBackMode  - Enable InternalLoopBack Mode
    enEthPHYInterface       - PHY Interface (MII/RMII/SGMII)
    enTxInterruptMode       - Tx interrupt enable.
    enRxInterruptMode       - Rx interrupt enable.
*/

typedef struct STag_Eth_EthConfigType                                                                                   /* PRQA S 3630 # JV-01 */
{
#if (ETH_MACRO_RSW2 == STD_ON) || (ETH_MACRO_RSW3 == STD_ON)
  Eth_OptionType enAutoNegotiation;
#endif
  Eth_MacLayerSpeedType enEthSpeed;
  Eth_DuplexModeType enEthDuplex;
  Eth_OptionType enInternalLoopBackMode;
  Eth_MediaInterfaceType enEthPHYInterface;
  Eth_OptionType enTxInterruptMode;
  Eth_OptionType enRxInterruptMode;
  Eth_HwMDIOType enHwMDIOType;
} Eth_EthConfigType;

#if (ETH_MACRO_RSW2 == STD_ON) || (ETH_MACRO_RSW3 == STD_ON)
typedef struct STagEth_TsnaRegValue
{
  uint32 ulEACTQCValue;
  uint32 ulEACTDQDCValue;
  uint32 ulEAVCCValue;
  uint32 ulEAVTCValue;
  uint32 ulEARTFCValue;
} Eth_TsnaRegValue;

typedef struct STag_Eth_SWConfigType
{
  Eth_TsnaRegValue stTsnaRegValue;
} Eth_SWConfigType;
#endif

typedef struct STag_Eth_CtrlConfigType                                                                                  /* PRQA S 3630 # JV-01 */
{
  uint8 aaEthMACAddr[6];
  P2CONST(Eth_EthConfigType, TYPEDEF, ETH_APPL_CONST) pEthConfig;                                                       /* PRQA S 3432 # JV-01 */
  P2CONST(void, TYPEDEF, ETH_APPL_CONST) pHwUnitConfig;                                                                 /* PRQA S 3432 # JV-01 */
  #if (ETH_MACRO_RSW2 == STD_ON) || (ETH_MACRO_RSW3 == STD_ON)
  Eth_SWConfigType stSWConfig;
  #endif
} Eth_CtrlConfigType;

/* Data Structure for ETH required for Initializing the ETH controller */
typedef struct STag_Eth_HWIPType
{
  /* Pointer to ETH driver ETH Unit configuration */
  uint8 ucHwipType;
} Eth_HWIPType;

/***********************************************************
Struct: Eth_SpiStatusType

Statistic counter for diagnostics.

Members:
SpiStatusRegister    - Bit mapped status defined by OA TC6 [26] to notify following information:
                       0x00: Transmit_Protocol_Error,
                       0x01: Transmit_Buffer_Overflow_Error,
                       0x02: Transmit_Buffer_Underflow_Error,
                       0x03: Receive_Buffer_Overflow_Error,
                       0x04: Loss_Framing_error,
                       0x05: Header_Error,
                       0x06: Reset_Complete,
                       0x07: PHY_Interrupt,
                       0x08: Transmit_Timestamp Capture_Available_A,
                       0x09: Transmit_Timestamp Capture_Available_B,
                       0x0A: Transmit_Timestamp Capture_Available_C,
                       0x0B: Transmit_Frame_Check_Sequence_Error,
                       0x0C: Control_Data_Protection_Error,
                       0x0D - 0xFF: Reserved.
Sync                 - Synchronization configuration as defined in the OA TC6 [26].
                       true: MACPHY has been reset and is not configured.
                       false: MACPHY is configured.
BufferStatusTxCredit - Contains the number of consecutive transmited data chunks of
                       Ethernet frame the SPI host can write without overflowing the MAC.
BufferStatusRxCredit - Contains the number of additional received data chunks of Ethernet
                       frame currently available for the SPI host to read.
*/
typedef struct
{
  uint32 SpiStatusRegister;
  boolean Sync;
  uint8 BufferStatusTxCredit;
  uint8 BufferStatusRxCredit;
} Eth_SpiStatusType;

/* SWS_Eth_91016 */
/* Type definition for Eth_RateDeviationStatusType */
typedef uint8 Eth_RateDeviationStatusType;

/* SWS_Eth_91015 */
/***********************************************************
Struct: Eth_RateDeviationType

Rate deviation value and status.

Members:
rateDeviationValue    - Rate deviation value (resolution: 2 -41).
rateDeviationStatus   - Current state of the rate deviation calculation.
*/
typedef struct
{
  sint32 rateDeviationValue;
  Eth_RateDeviationStatusType rateDeviationStatus;
} Eth_RateDeviationType;


#if (ETH_MACRO_RSW2 == STD_ON) || (ETH_MACRO_RSW3 == STD_ON)
/***********************************************************
  Type: Eth_GwcaRegValue

  Structure for GWCA register setting.

  Members:
    ulGWVCCValue    - GWCA VLAN Control Configuration.
    ulGWVTCValue    - GWCA VLAN TAG Configuration.
    ulGWTTFCValue   - GWCA Transmission TAG Filtering Configuration.
    ulGWSCR0Value   - GWCA Security Configuration Register 0.
    ulGWGRLCValue   - GWCA Global Rate Limiter Configuration.
    ulGWGRLULCValue - GWCA Global Rate Limiter Upper Limit Configuration.
*/
typedef struct STagEth_GwcaRegValue
{
  uint32 ulGWVCCValue;
  uint32 ulGWVTCValue;
  uint32 ulGWTTFCValue;
  uint32 ulGWSCR0Value;
  uint32 ulGWGRLCValue;
  uint32 ulGWGRLULCValue;
} Eth_GwcaRegValue;

typedef struct STagEth_GlobalPauseConfiguration
{
  Eth_OptionType enGlobalPause;
  uint32 ulPauseAssertionLevel;
  uint32 ulPauseDeAssertionLevel;
} Eth_GlobalPauseConfiguration;

typedef struct STagEth_BothCorePauseLevelType
{
  uint32 ulBothCorePauseAssertionLevel;
  uint32 ulBothCorePauseDeAssertionLevel;
} Eth_BothCorePauseLevelType;

typedef struct STagEth_BothCoreConfiguration
{
  uint32 ulBothCorePortFwdVectorId;
  uint32 aaBothCorePortFwdCsd[2];
  Eth_BothCorePauseLevelType stBothCorePauseLevelConfig[2];
} Eth_BothCoreConfiguration;

typedef struct STagEth_GwcaConfiguration
{
  Eth_GwcaRegValue stGwcaRegValue;
} Eth_GwcaConfiguration;

#endif /* ETH_MACRO_RSW2 == STD_ON || (ETH_MACRO_RSW3 == STD_ON) */

typedef struct STag_Eth_ConfigType
{
  /* Database start value - ETH_DBTOC_VALUE */
  uint32 ulStartOfDbToc;
  P2CONST(Eth_CtrlConfigType, TYPEDEF, ETH_APPL_CONST) pCtrlConfig;                                                     /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventAccess;                                                             /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventRxFramesLost;                                                       /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventCRC;                                                                /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventUnderSizeFrame;                                                     /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventOverSizeFrame;                                                      /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventAlignment;                                                          /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventSinglecollision;                                                    /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventMultiplecollision;                                                  /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventLatecollision;                                                      /* PRQA S 3432 # JV-01 */
  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventIntInconsistent;
  #endif
  #if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventUnintendedIntChk;                                                   /* PRQA S 3432 # JV-01 */
  #endif
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventDmaError;                                                           /* PRQA S 3432 # JV-01 */
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventEccError;                                                           /* PRQA S 3432 # JV-01 */
  #if (ETH_MACRO_ETNB == STD_ON || ETH_MACRO_ETNF ==STD_ON)
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventTimerincFailed;
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventTimeroffsetFailed;
  #endif
  #if ((ETH_REGISTER_CHECK_INITTIME == STD_ON) || (ETH_REGISTER_CHECK_RUNTIME == STD_ON))
  P2CONST(uint16, AUTOMATIC, ETH_VAR_INIT) pDemEventRegisterCorruption;
  #endif
  #endif
  P2CONST(uint32, AUTOMATIC, ETH_CONFIG_DATA) pTotalCtrlConfig;                                                         /* PRQA S 3432 # JV-01 */
  uint32 ulCtrlConfigIdx[ETH_TOTAL_CORE_CONFIG][ETH_TOTAL_CTRL_CONFIG];                                                 /* PRQA S 1039 # JV-01 */
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  P2CONST(uint8, AUTOMATIC, ETH_VAR_INIT) pCoreId2Index;                                                                /* PRQA S 3432 # JV-01 */
  #endif
  P2VAR(Eth_StateType, AUTOMATIC, ETH_VAR_INIT) pDriverState;                                                           /* PRQA S 3432 # JV-01 */
  #if (ETH_MACRO_RSW2 == STD_ON) || (ETH_MACRO_RSW3 == STD_ON)
  Eth_GwcaConfiguration stGwcaConfiguration[ETH_RSW3_GWCA_TOTAL_CONFIGURED];
  Eth_GlobalPauseConfiguration stGlobalPauseConfiguration[2];
  #if (ETH_BOTHCORE_ENABLE == STD_ON)
  Eth_BothCoreConfiguration stBothCoreConfiguration;
  #endif /* ETH_BOTHCORE_ENABLE */
  #endif /* ETH_MACRO_RSW2 == STD_ON || (ETH_MACRO_RSW3 == STD_ON) */
} Eth_ConfigType;

#if (ETH_DEVICE_NAME == ETH_U5X)
/* Type definition for function pointer which point to user call out function */
typedef void (*Eth_PreCtrlInitUserCalloutPtrType)(uint32 LulCtrlIdx);
typedef void (*Eth_PostCtrlInitUserCalloutPtrType)(uint32 LulCtrlIdx);
typedef void (*Eth_RxBufWarnLvlUserCalloutPtrType)(uint32 LulCtrlIdx, Eth_BufIdxType LulBufIdx);

#if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
/***********************************************************
Struct: Eth_BufferUsageStatType

Buffer statistic counter for diagnostics.

Members:
  ulDropInsuffTxBuffCnt    - The number of times a Tx buffer request was denied due to unavailable Tx buffers.
  ulWarnFullRxBuffCnt      - The number of times all Rx buffers were occupied during frame reception.
  ulDropInsuffRxBuffCnt    - The number of times a Rx frame was dropped due to unavailable Rx buffers.
*/
typedef struct
{
  uint32 ulDropInsuffTxBuffCnt;
  uint32 ulWarnFullRxBuffCnt;
  uint32 ulDropInsuffRxBuffCnt;
} Eth_BufferUsageStatType;
#endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */
#endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

/***********************************************************************************************************************
**                                      SchM Critical Section Protection Macros                                       **
***********************************************************************************************************************/
#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
#define ETH_ENTER_CRITICAL_SECTION(Exclusive_Area) SchM_Enter_Eth_##Exclusive_Area()                                    /* PRQA S 0342 # JV-01 */
#define ETH_EXIT_CRITICAL_SECTION(Exclusive_Area)  SchM_Exit_Eth_##Exclusive_Area()                                     /* PRQA S 0342 # JV-01 */
#else
#define ETH_ENTER_CRITICAL_SECTION(Exclusive_Area)
#define ETH_EXIT_CRITICAL_SECTION(Exclusive_Area)
#endif

/***********************************************************************************************************************
**                                                Dem interface Macros                                                **
***********************************************************************************************************************/
#define ETH_DEM_REPORT_ERROR (void)Dem_SetEventStatus

#endif /* ETH_TYPES_H */

/***********************************************************************************************************************
**                                                    End Of File                                                     **
***********************************************************************************************************************/
