/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Common_LLDriver.h                                                                               */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains common definitions among all low level drivers of Eth                                           */
/* Driver Component.                                                                                                  */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.2.1: 01/07/2026    : Update to add new element stMeasurementData into Eth_ControllerStatusType.
 * 1.2.0: 30/12/2025    : Update to add the justification for Misra C msg 1710.
 * 1.1.1: 16/09/2025    : Update to support TSN-ES
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 * 1.0.1: 24/04/2025    : Update to remove macro ETH_UPDATE_PHYS_ADDR_FILTER.
 * 1.0.0: 29/08/2024    : Modify type Eth_BufHandlerType to remove element blUsedFlag.
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/
#ifndef ETH_COMMON_LLDRIVER_H
#define ETH_COMMON_LLDRIVER_H

/***********************************************************************************************************************
**                                               Macro type definitions                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth_Types.h"
#include "Eth_Filter.h"
/* Include the LLDriver header file */
#if (ETH_MACRO_RSW3 == STD_ON)
#include "Eth_RSW3_LLDriver.h"
#include "Eth_Serdes_LLDriver.h"
#endif /* #if (ETH_MACRO_RSW3 == STD_ON) */
#if (ETH_MACRO_ETND == STD_ON)
#if (ETH_DEVICE_NAME == ETH_U5X)
/* U5x device */
#include "Eth_ETND_LLDriver.h"
#else
/* X5H device */
#include "Eth_RSW3_TSNES_LLDriver.h"
#endif
#endif /* #if (ETH_MACRO_ETND == STD_ON) */
#if (ETH_MACRO_ETNF == STD_ON)
#include "Eth_ETNF_LLDriver.h"
#endif /* #if (ETH_MACRO_ETNF == STD_ON) */

/***********************************************************************************************************************
**                                                General definitions                                                 **
***********************************************************************************************************************/
/* Bit length of byte */
#define ETH_BYTE_BITS            8UL
/* Byte length of Ethernet header */
#define ETH_HEADER_SIZE             14UL
#define ETH_SRC_DST_ADDRESS_SIZE    12UL
#define ETH_ETHERTYPE_SIZE           2UL

/* Maximum value of uint32 */
#define ETH_UINT32_MAXVALUE      0xFFFFFFFFUL

/* Copy the MAC address */
#define ETH_COPY_MAC_ADDRESS(src, dst)                                                                                  /* PRQA S 3472 # JV-01 */\
  do                                   \
  {                                    \
    (dst)[0] = (src)[0];               \
    (dst)[1] = (src)[1];               \
    (dst)[2] = (src)[2];               \
    (dst)[3] = (src)[3];               \
    (dst)[4] = (src)[4];               \
    (dst)[5] = (src)[5];               \
  } while (0)

#define ETH_INTERRUPT_STATUS_ACTIVE      1UL
#define ETH_INTERRUPT_STATUS_NOT_ACTIVE  0UL

/***********************************************************************************************************************
**                                      PHY management data reletive definitions                                      **
***********************************************************************************************************************/
#define ETH_PHY_MAX_PHYAD_IDX    31U
#define ETH_PHY_MAX_REGAD_IDX    31U
#define ETH_PHY_PREAMBLE_SIZE    32UL
#define ETH_PHY_HEADER_SIZE      14UL
#define ETH_PHY_DATA_SIZE        16UL
/* Create a header for read operation */
#define ETH_PHY_RHEADER(phyad, regad)                                                                                   /* PRQA S 3472 # JV-01 */\
  (0x1800UL | ((uint32)(phyad) << 5UL) | ((uint32)(regad)))
/* Create a header for write operation */
#define ETH_PHY_WHEADER(phyad, regad)                                                                                   /* PRQA S 3472 # JV-01 */\
  (0x1400UL | ((uint32)(phyad) << 5UL) | ((uint32)(regad)))

/***********************************************************************************************************************
**                                             MDIO reletive definitions                                              **
***********************************************************************************************************************/
#define ETH_MDIO_SETUP_TIME      10UL

/***********************************************************************************************************************
**                                      Offset addressed from the top of buffer                                       **
**                                  These are depending on each MACRO specification                                   **
***********************************************************************************************************************/
/* Destination MAC address */
#define ETH_DST_MACADDR_OFFSET ETH_TXRX_BUFFER_PRE_PADDING
/* Src MAC address */
#define ETH_SRC_MACADDR_OFFSET   (ETH_TXRX_BUFFER_PRE_PADDING + ETH_MACADDR_SIZE)
/* Frame type */
#define ETH_FRAMETYPE_OFFSET     (ETH_SRC_MACADDR_OFFSET + ETH_MACADDR_SIZE)
/* Payload */
#define ETH_PAYLOAD_OFFSET       (ETH_TXRX_BUFFER_PRE_PADDING + ETH_HEADER_SIZE + ETH_TXRX_BUFFER_IN_PADDING)

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3472)    : All toplevel uses of this function-like macro look like they could be replaced by            */
/*                       equivalent function calls.                                                                   */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3630)    : The implementation of this struct/union type should be hidden.                               */
/* Rule                :  MISRA C:2012 Dir-4.8                                                                        */
/* JV-01 Justification : This is accepted. Redundant of struct or union type has no affect to driver operation.       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted; the identifiers share the same matching pattern due to QAC normalization,  */
/*                       but they represent different functions (internal function) and do not conflict in linkage.   */
/*       Verification  : The code has been manually reviewed, and this has no impact on functionality or safety.      */
/**********************************************************************************************************************/
 
/***********************************************************************************************************************
**                                                 Global Data Types                                                  **
***********************************************************************************************************************/
/* Order of the drop count information for Eth_GetDropCount */
typedef enum ETag_Eth_EtherDropType
{
  ETH_DROP_BUFF_OVER_RUN = 0,
  ETH_DROP_CRC_ERR,
  ETH_DROP_UNDERSIZE,
  ETH_DROP_OVERSIZE,
  ETH_DROP_ALIGNMENT_ERR,
  ETH_DROP_SQE_TEST_ERR,
  ETH_DROP_RECEIVE_DISCARD,
  ETH_DROP_ERRONEOUS_INBOUND,
  ETH_DROP_TRANSMIT_DISCARD,
  ETH_DROP_ERRONESOUS_OUTBOUND,
  ETH_DROP_SINGLE_COLLISION,
  ETH_DROP_MULTIPLE_COLLISTION,
  ETH_DROP_DEFERRED_TRANSMIT,
  ETH_DROP_LATE_COLLISION
} Eth_EtherDropType;

/* Order of the error statuses for Eth_GetEtherStats */
typedef enum ETag_Eth_EtherStatsType
{
  ETH_STATS_DROP_EVENTS = 0,
  ETH_STATS_OCTETS,
  ETH_STATS_PKTS,
  ETH_STATS_BROADCAST_PKTS,
  ETH_STATS_MULTICAST_PKTS,
  ETH_STATS_CRC_ALIGN_ERRORS,
  ETH_STATS_UNDERSIZE_PKTS,
  ETH_STATS_OVERSIZE_PKTS,
  ETH_STATS_FRAGMENTS,
  ETH_STATS_JABBERS,
  ETH_STATS_COLLISIONS,
  ETH_STATS_PKTS_64_OCTETS,
  ETH_STATS_PKTS_65_TO_127_OCTETS,
  ETH_STATS_PKTS_128_TO_255_OCTETS,
  ETH_STATS_PKTS_256_TO_511_OCTETS,
  ETH_STATS_PKTS_512_TO_1023_OCTETS,
  ETH_STATS_PKTS_1024_TO_1518_OCTETS,
  ETH_STATS_MAX_VALUE /* stopper */
} Eth_EtherStatsType;

/* Status of each controller */
typedef struct Stag_Eth_ControllerStatusType
{
  /* MAC address of this controller */
  Eth_MacAddressType stMacAddr;
  /* Current mode, DOWN or ACTIVE */
  Eth_ModeType enMode;
  /* Whether a controller is in promiscuous mode.
  This is the logical state, not necessarily equal to the HW state. */
  boolean blPromiscuous;
  /* Whether the filter operation is activated */
  uint32 ulActiveFilterBits;
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* Pointer to the tail of ts descriptor ring */
  uint32 ulTsDescTail;
#endif
#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_CounterType stCounter;
#endif
#if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_RxStatsType stRxStat;
#endif
#if (ETH_GET_TX_STATS_API == STD_ON)
  Eth_TxStatsType stTxStat;
#endif
#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
  Eth_TxErrorCounterValuesType stTxError;
#endif
  /* LLDriver specific status */
#if (ETH_MACRO_ETNF == STD_ON)
  Eth_HwStatusTypeEtnf stHwStatEtnf;
#endif
#if (ETH_MACRO_ETND == STD_ON) || (ETH_MACRO_RSW3 == STD_ON)
  Eth_HwStatusType stHwStat;
#endif
#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
  Eth_BufferUsageStatType stMeasurementData;
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
#endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */
} Eth_ControllerStatusType;

/* A dummy value for unsupported items by HW */
#define ETH_NOT_AVAILABLE 0xFFFFFFFFUL

/* Data Structure for ETH function Table */
typedef struct STag_Eth_HwFuncTableType                                                                                 /* PRQA S 3630 # JV-01 */
{
  P2FUNC(void, ETH_PRIVATE_CODE, pInitializeBuffer)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                               /* PRQA S 3432 # JV-01 */
  P2FUNC(void, ETH_PRIVATE_CODE, pPreprocessBuffer)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                               /* PRQA S 3432 # JV-01 */
  P2FUNC(BufReq_ReturnType, ETH_PRIVATE_CODE, pGetTxBuffer)                                                             /* PRQA S 3432 # JV-01 */
                   (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucPriority,
                    CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                   /* PRQA S 3432 # JV-01 */
                    CONSTP2VAR(uint8 *, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                             /* PRQA S 3432 # JV-01 */
                    CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr);                                           /* PRQA S 3432 # JV-01 */
  P2FUNC(void, ETH_PRIVATE_CODE, pReleaseTxBuffer)                                                                      /* PRQA S 3432 # JV-01 */
        (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);
  P2FUNC(void, ETH_PRIVATE_CODE, pPreprocessFrame)                                                                      /* PRQA S 3432 # JV-01 */
                       (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
                        CONST(uint32, AUTOMATIC) LulFrameType,
                        CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
                        CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen);                                     /* PRQA S 3432 # JV-01 */
  P2FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE, pFindTxBufferHandler)                                                  /* PRQA S 3432 # JV-01 */
        (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx);
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwInit)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                               /* PRQA S 3432 # JV-01 */
  #ifdef ETH_HW_DEINIT
  #if (ETH_DEINIT_API == STD_ON)
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwDeInit)                                                                   /* PRQA S 3432 # JV-01 */
        (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(boolean, AUTOMATIC) ForceReset);
  #endif
  #endif
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwDisableController)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                  /* PRQA S 3432 # JV-01 */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwEnableController)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                   /* PRQA S 3432 # JV-01 */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwTransmit)                                                                 /* PRQA S 3432 # JV-01 */
        (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
         CONST(uint32, AUTOMATIC) LulLenByte, CONST(boolean, AUTOMATIC) LblConfirmation);
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  P2FUNC(void, ETH_PRIVATE_CODE, pHwGetCounterValues)(CONST(uint32, AUTOMATIC) LulCtrlIdx,                              /* PRQA S 3432 # JV-01 */
                           CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounterPtr);                         /* PRQA S 3432 # JV-01 */
  #endif
  #if (ETH_GET_RX_STATS_API == STD_ON)
  P2FUNC(void, ETH_PRIVATE_CODE, pHwGetRxStats)(CONST(uint32, AUTOMATIC) LulCtrlIdx,                                    /* PRQA S 3432 # JV-01 */
                                                CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpRxStats);       /* PRQA S 3432 # JV-01 */
  #endif
  #if (ETH_GET_TX_STATS_API == STD_ON)
  P2FUNC(void, ETH_PRIVATE_CODE, pHwGetTxStats)(CONST(uint32, AUTOMATIC) LulCtrlIdx,                                    /* PRQA S 3432 # JV-01 */
                                                CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpTxStats);       /* PRQA S 3432 # JV-01 */
  #endif
  #if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
  P2FUNC(void, ETH_PRIVATE_CODE, pHwGetTxErrorCounterValues)                                                            /* PRQA S 3432 # JV-01 */
      (CONST(uint32, AUTOMATIC) LulCtrlIdx,
       CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpTxErrorCounterValues);                      /* PRQA S 3432 # JV-01 */
  #endif
  P2FUNC(void, ETH_PRIVATE_CODE, pHwMainFunction)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                                 /* PRQA S 3432 # JV-01 */
  P2FUNC(void, ETH_PRIVATE_CODE, pHwTxConfirmation)(CONST(uint32, AUTOMATIC) LulCtrlIdx);                               /* PRQA S 3432 # JV-01 */
  #if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwCheckFifoIndex)(CONST(uint32, AUTOMATIC) LulCtrlIdx,                      /* PRQA S 3432 # JV-01 */
                                                              CONST(uint32, AUTOMATIC) LulQueueIdx);
  #endif
  P2FUNC(Eth_RxStatusType, ETH_PRIVATE_CODE, pHwReceive)(CONST(uint32, AUTOMATIC) LulCtrlIdx,                           /* PRQA S 3432 # JV-01 */
                                                         CONST(uint32, AUTOMATIC) LulQueueIdx);
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwSetIncrementTimeForGptp)                                                  /* PRQA S 3432 # JV-01 */
      (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIncVal);

  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwSetOffsetTimeForGptp)                                                     /* PRQA S 3432 # JV-01 */
    (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeOffsetPtr);
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwGetCurrentTime)                                                           /* PRQA S 3432 # JV-01 */
                        (CONST(uint32, AUTOMATIC) LulCtrlIdx,
                         CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                     /* PRQA S 3432 # JV-01 */
                         CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                       /* PRQA S 3432 # JV-01 */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwGetCurrentTimeTuple)                                                      /* PRQA S 3432 # JV-01 */
                        (CONST(uint32, AUTOMATIC) LulCtrlIdx,
                         CONSTP2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) LpCurrentTimeTuplePtr);                    /* PRQA S 3432 # JV-01 */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwGetEgressTimeStamp)                                                       /* PRQA S 3432 # JV-01 */
                              (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx,
                               CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,               /* PRQA S 3432 # JV-01 */
                               CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                 /* PRQA S 3432 # JV-01 */

  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwGetIngressTimeStamp)                                                      /* PRQA S 3432 # JV-01 */
                               (CONST(uint32, AUTOMATIC) LulCtrlIdx,
                                CONSTP2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpDataPtr,
                                CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,              /* PRQA S 3432 # JV-01 */
                                CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr);                /* PRQA S 3432 # JV-01 */
  #endif
  #if (ETH_CTRL_ENABLE_MII == STD_ON)
  #if defined ETH_HW_NOT_LEGACY_MDIO
  /* HwReadMii/HwWriteMii: ETND, ETNE, RSW2, RSW3  */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwReadMii)                                                                  /* PRQA S 3432 # JV-01 */
    (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
                   CONST(uint8, AUTOMATIC) LucRegIdx, CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr);        /* PRQA S 3432 # JV-01 */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwWriteMii)                                                                 /* PRQA S 3432 # JV-01 */
    (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
                   CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusRegVal);
  #endif
  #if defined ETH_HW_LEGACY_MDIO
  /* HwReadMiibit/HwWriteMiibit: ETNB, ETNC, ETNF, AVB  */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwReadMiibit)                                                               /* PRQA S 3432 # JV-01 */
    (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr);                    /* PRQA S 3432 # JV-01 */
  P2FUNC(Std_ReturnType, ETH_PRIVATE_CODE, pHwWriteMiibit)                                                              /* PRQA S 3432 # JV-01 */
    (CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBit);
  #endif
  #endif

  P2FUNC(BufReq_ReturnType, ETH_PRIVATE_CODE, pGetImmTxBuffer)                                                          /* PRQA S 3432 # JV-01 */
    (CONST(uint32, AUTOMATIC) LulCtrlIdx,
    CONST(uint8, AUTOMATIC) LucPriority,
    CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                   /* PRQA S 3432 # JV-01 */
    P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                                  /* PRQA S 3432 # JV-01 */
    CONST(uint16, AUTOMATIC) LusFrameLength);

  P2FUNC(void, ETH_PRIVATE_CODE, pResetRxDesc) (                                                                        /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode);
} Eth_HwFuncTableType;
/***********************************************************************************************************************
**                                                Function Prototypes                                                 **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#ifdef ETH_HW_PRE_COMMON_INIT
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwPreCommonInit(void);                                                /* PRQA S 1710 # JV-01 */
#endif

#ifdef ETH_HW_POST_COMMON_INIT
extern FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwPostCommonInit(void);                                               /* PRQA S 1710 # JV-01 */
#endif

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

#endif /* !ETH_COMMON_LLDIVER_H */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
