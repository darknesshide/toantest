/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Ram.c                                                                                           */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Global RAM variable definitions for Eth Driver an RAM allocation functions                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.4.1: 24/04/2026    : Support Multicore for X5H
 * 1.4.0: 31/03/2026    : Update to add new pointer Eth_GpCoreId2Index and new global variable Eth_CtrlConfigIdx.
 *                        Update to use Eth_GpDriverState instead of Eth_GenDriverState to support multi variant.
 * 1.1.1: 16/09/2025    : Update to support TSN-ES
 * 1.1.0: 08/08/2025    : Remove variable Eth_GaaTimeTuple.
 *        25/07/2025    : Update to use macro constant instead of hard code.
 * 1.0.2: 25/06/2025    : Correct memmap mapping for Eth_GaaTimeTuple.
 * 1.0.1: 17/03/2025    : Update to merging SingleMainline
 *                        + Add Eth_GenDriverState
 * 1.0.0: 28/09/2024    : Add new global variables Eth_Ctrl1_TxBufferData, Eth_Ctrl1_RxBufferData,
 *                        Eth_Ctrl1_TxBufferNode, Eth_Ctrl1_RxBufferNode.
 *                        Update global variables Eth_GaaTxBufferDataTable, Eth_GaaRxBufferDataTable,
 *                        Eth_GaaTxBufferNodes, Eth_GaaTxBufferNodes to support STATIC memory.
 *                        Change variable name
 *                        from Eth_GbDemEventAccess to Eth_GpDemEventAccess,
 *                        from Eth_GbDemEventRxFramesLost to Eth_GpDemEventRxFramesLost,
 *                        from Eth_GbDemEventCRC to Eth_GpDemEventCRC,
 *                        from Eth_GbDemEventUnderSizeFrame to Eth_GpDemEventUnderSizeFrame,
 *                        from Eth_GbDemEventOverSizeFrame to Eth_GpDemEventOverSizeFrame,
 *                        from Eth_GbDemEventAlignment to Eth_GpDemEventAlignment,
 *                        from Eth_GbDemEventSinglecollision to Eth_GpDemEventSinglecollision,
 *                        from Eth_GbDemEventMultiplecollision to Eth_GpDemEventMultiplecollision,
 *                        from Eth_GbDemEventLatecollision to Eth_GpDemEventLatecollision.
 *                        from Eth_GbDemEventDmaError to Eth_GpDemEventDmaError.
 *                        from Eth_GbDemEventEccError to Eth_GpDemEventEccError.
 *                        from Eth_GbDemEventTimerincFailed to Eth_GpDemEventTimerincFailed.
 *                        from Eth_GbDemEventTimeroffset to Eth_GpDemEventTimeroffset.
 *                        from Eth_GbDemEventRegisterCorruption to Eth_GpDemEventRegisterCorruption.
 *        29/08/2024    : Add new global variables Eth_Ctrl0_TxBufferData, Eth_Ctrl0_RxBufferData,
 *                        Eth_Ctrl0_TxBufferNode, Eth_Ctrl0_RxBufferNode, Eth_GaaTxBufferDataTable,
 *                        Eth_GaaRxBufferDataTable, Eth_GaaTxBufferNodes, Eth_GaaTxBufferNodes to support static memory.
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for Eth.h inclusion and macro definitions */
#include "Eth.h"
/* Header file inclusion */
#include "Eth_Ram.h"
#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
/* Included for the declaration of the critical section protection functions */
#include "SchM_Eth.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RAM_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_RAM_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_RAM_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_RAM_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_RAM_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/

#if (ETH_RAM_AR_RELEASE_MAJOR_VERSION != ETH_RAM_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_Ram.c : Mismatch in Release Major Version"
#endif
#if (ETH_RAM_AR_RELEASE_MINOR_VERSION != ETH_RAM_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_Ram.c : Mismatch in Release Minor Version"
#endif
#if (ETH_RAM_AR_RELEASE_REVISION_VERSION != ETH_RAM_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_Ram.c : Mismatch in Release Revision Version"
#endif


#if (ETH_RAM_SW_MAJOR_VERSION != ETH_RAM_C_SW_MAJOR_VERSION)
   #error "Eth_Ram.c : Mismatch in Software Major Version"
#endif
#if (ETH_RAM_SW_MINOR_VERSION != ETH_RAM_C_SW_MINOR_VERSION)
   #error "Eth_Ram.c : Mismatch in Software Minor Version"
#endif
/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (7:0791)    : Macro identifier does not differ from other macro identifier(s) (e.g. '%1s') within the      */
/*                       specified number of significant characters.                                                  */
/* Rule                : CERTCCM DCL23, MISRA C:2012 Rule-5.4                                                         */
/*                       REFERENCE - ISO:C90-6.1.2 Identifiers - Implementation Limits                                */
/* JV-01 Justification : This macro identifier is following AUTOSAR standard rule (Symbolic Name or Published         */
/*                       Macro's name), so this is accepted.                                                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1504)    : The object '%1s' is only referenced in the translation unit where it is defined.             */
/* Rule                : CERTCCM DCL15, DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                      */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1533)    : The object '%1s' is only referenced by function '%2s'.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.9                                            */
/* JV-01 Justification : This is accepted, due to the object is defined in separated source C file to followed        */
/*                       coding rule                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/


/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"

VAR(Eth_RxFrameType, ETH_VAR_NO_INIT) Eth_GaaRxFrame[ETH_TOTAL_CTRL_CONFIG];

VAR(uint32, ETH_VAR_NO_INIT) Eth_CtrlConfigIdx[ETH_TOTAL_CORE_CONFIG][ETH_MAX_CTRL_CONFIG_PER_CORE];                                          

#define ETH_STOP_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_CONST_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
CONST(uint32, ETH_VAR_INIT) Eth_CtrlTxMaxFrameLengthMapping[ETH_TOTAL_CTRL_CONFIG] =
{
  ETH_MAX_TX_FRAME_LENGTH_0,
  #if defined(ETH_TX_BUF_TOTAL_1)
  ETH_MAX_TX_FRAME_LENGTH_1,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_2)
  ETH_MAX_TX_FRAME_LENGTH_2,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_3)
  ETH_MAX_TX_FRAME_LENGTH_3,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_4)
  ETH_MAX_TX_FRAME_LENGTH_4,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_5)
  ETH_MAX_TX_FRAME_LENGTH_5,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_6)
  ETH_MAX_TX_FRAME_LENGTH_6,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_7)
  ETH_MAX_TX_FRAME_LENGTH_7,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_8)
  ETH_MAX_TX_FRAME_LENGTH_8,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_9)
  ETH_MAX_TX_FRAME_LENGTH_9,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_10)
  ETH_MAX_TX_FRAME_LENGTH_10,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_11)
  ETH_MAX_TX_FRAME_LENGTH_11,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_12)
  ETH_MAX_TX_FRAME_LENGTH_12,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_13)
  ETH_MAX_TX_FRAME_LENGTH_13,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_14)
  ETH_MAX_TX_FRAME_LENGTH_14,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_15)
  ETH_MAX_TX_FRAME_LENGTH_15,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_16)
  ETH_MAX_TX_FRAME_LENGTH_16,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_17)
  ETH_MAX_TX_FRAME_LENGTH_17,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_18)
  ETH_MAX_TX_FRAME_LENGTH_18,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_19)
  ETH_MAX_TX_FRAME_LENGTH_19,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_20)
  ETH_MAX_TX_FRAME_LENGTH_20,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_21)
  ETH_MAX_TX_FRAME_LENGTH_21,
  #endif
  #if defined(ETH_TX_BUF_TOTAL_22)
  ETH_MAX_TX_FRAME_LENGTH_22,
  #endif
};

CONST(uint32, ETH_VAR_INIT) Eth_CtrlRxMaxFrameLengthMapping[ETH_TOTAL_CTRL_CONFIG] =                                    /* PRQA S 1533 # JV-01 */
{
  ETH_MAX_RX_FRAME_LENGTH_0,
  #if defined(ETH_RX_BUF_TOTAL_1)
  ETH_MAX_RX_FRAME_LENGTH_1,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_2)
  ETH_MAX_RX_FRAME_LENGTH_2,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_3)
  ETH_MAX_RX_FRAME_LENGTH_3,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_4)
  ETH_MAX_RX_FRAME_LENGTH_4,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_5)
  ETH_MAX_RX_FRAME_LENGTH_5,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_6)
  ETH_MAX_RX_FRAME_LENGTH_6,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_7)
  ETH_MAX_RX_FRAME_LENGTH_7,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_8)
  ETH_MAX_RX_FRAME_LENGTH_8,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_9)
  ETH_MAX_RX_FRAME_LENGTH_9,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_10)
  ETH_MAX_RX_FRAME_LENGTH_10,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_11)
  ETH_MAX_RX_FRAME_LENGTH_11,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_12)
  ETH_MAX_RX_FRAME_LENGTH_12,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_13)
  ETH_MAX_RX_FRAME_LENGTH_13,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_14)
  ETH_MAX_RX_FRAME_LENGTH_14,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_15)
  ETH_MAX_RX_FRAME_LENGTH_15,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_16)
  ETH_MAX_RX_FRAME_LENGTH_16,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_17)
  ETH_MAX_RX_FRAME_LENGTH_17,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_18)
  ETH_MAX_RX_FRAME_LENGTH_18,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_19)
  ETH_MAX_RX_FRAME_LENGTH_19,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_20)
  ETH_MAX_RX_FRAME_LENGTH_20,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_21)
  ETH_MAX_RX_FRAME_LENGTH_21,
  #endif
  #if defined(ETH_RX_BUF_TOTAL_22)
  ETH_MAX_RX_FRAME_LENGTH_22,
  #endif
};

#define ETH_STOP_SEC_CONST_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
** Transmit/Receieve buffer data                                                                                      **
** Array to store Ethernet frame of all buffer of each queue on a controller                                          **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_PORT_BUFFER_0
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl0_TxBufferData[ETH_TX_BUF_TOTAL_0][ETH_MAX_TX_FRAME_LENGTH_0];
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl0_RxBufferData[ETH_RX_BUF_TOTAL_0][ETH_MAX_RX_FRAME_LENGTH_0];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_0
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if defined(ETH_TX_BUF_TOTAL_1)
#define ETH_START_SEC_VAR_PORT_BUFFER_1
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl1_TxBufferData[ETH_TX_BUF_TOTAL_1][ETH_MAX_TX_FRAME_LENGTH_1];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_1
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_1)
#define ETH_START_SEC_VAR_PORT_BUFFER_1
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl1_RxBufferData[ETH_RX_BUF_TOTAL_1][ETH_MAX_RX_FRAME_LENGTH_1];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_1
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_2)
#define ETH_START_SEC_VAR_PORT_BUFFER_2
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl2_TxBufferData[ETH_TX_BUF_TOTAL_2][ETH_MAX_TX_FRAME_LENGTH_2];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_2
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_2)
#define ETH_START_SEC_VAR_PORT_BUFFER_2
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl2_RxBufferData[ETH_RX_BUF_TOTAL_2][ETH_MAX_RX_FRAME_LENGTH_2];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_2
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_3)
#define ETH_START_SEC_VAR_PORT_BUFFER_3
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl3_TxBufferData[ETH_TX_BUF_TOTAL_3][ETH_MAX_TX_FRAME_LENGTH_3];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_3
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_3)
#define ETH_START_SEC_VAR_PORT_BUFFER_3
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl3_RxBufferData[ETH_RX_BUF_TOTAL_3][ETH_MAX_RX_FRAME_LENGTH_3];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_3
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_4)
#define ETH_START_SEC_VAR_PORT_BUFFER_4
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl4_TxBufferData[ETH_TX_BUF_TOTAL_4][ETH_MAX_TX_FRAME_LENGTH_4];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_4
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_4)
#define ETH_START_SEC_VAR_PORT_BUFFER_4
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl4_RxBufferData[ETH_RX_BUF_TOTAL_4][ETH_MAX_RX_FRAME_LENGTH_4];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_4
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_5)
#define ETH_START_SEC_VAR_PORT_BUFFER_5
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl5_TxBufferData[ETH_TX_BUF_TOTAL_5][ETH_MAX_TX_FRAME_LENGTH_5];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_5
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_5)
#define ETH_START_SEC_VAR_PORT_BUFFER_5
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl5_RxBufferData[ETH_RX_BUF_TOTAL_5][ETH_MAX_RX_FRAME_LENGTH_5];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_5
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_6)
#define ETH_START_SEC_VAR_PORT_BUFFER_6
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl6_TxBufferData[ETH_TX_BUF_TOTAL_6][ETH_MAX_TX_FRAME_LENGTH_6];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_6
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_6)
#define ETH_START_SEC_VAR_PORT_BUFFER_6
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl6_RxBufferData[ETH_RX_BUF_TOTAL_6][ETH_MAX_RX_FRAME_LENGTH_6];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_6
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_7)
#define ETH_START_SEC_VAR_PORT_BUFFER_7
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl7_TxBufferData[ETH_TX_BUF_TOTAL_7][ETH_MAX_TX_FRAME_LENGTH_7];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_7
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_7)
#define ETH_START_SEC_VAR_PORT_BUFFER_7
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl7_RxBufferData[ETH_RX_BUF_TOTAL_7][ETH_MAX_RX_FRAME_LENGTH_7];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_7
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_8)
#define ETH_START_SEC_VAR_PORT_BUFFER_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl8_TxBufferData[ETH_TX_BUF_TOTAL_8][ETH_MAX_TX_FRAME_LENGTH_8];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_8)
#define ETH_START_SEC_VAR_PORT_BUFFER_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl8_RxBufferData[ETH_RX_BUF_TOTAL_8][ETH_MAX_RX_FRAME_LENGTH_8];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_9)
#define ETH_START_SEC_VAR_PORT_BUFFER_9
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl9_TxBufferData[ETH_TX_BUF_TOTAL_9][ETH_MAX_TX_FRAME_LENGTH_9];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_9
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_9)
#define ETH_START_SEC_VAR_PORT_BUFFER_9
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl9_RxBufferData[ETH_RX_BUF_TOTAL_9][ETH_MAX_RX_FRAME_LENGTH_9];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_9
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_10)
#define ETH_START_SEC_VAR_PORT_BUFFER_10                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl10_TxBufferData[ETH_TX_BUF_TOTAL_10][ETH_MAX_TX_FRAME_LENGTH_10];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_10
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_10)
#define ETH_START_SEC_VAR_PORT_BUFFER_10                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl10_RxBufferData[ETH_RX_BUF_TOTAL_10][ETH_MAX_RX_FRAME_LENGTH_10];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_10
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_11)
#define ETH_START_SEC_VAR_PORT_BUFFER_11                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl11_TxBufferData[ETH_TX_BUF_TOTAL_11][ETH_MAX_TX_FRAME_LENGTH_11];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_11
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_11)
#define ETH_START_SEC_VAR_PORT_BUFFER_11                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl11_RxBufferData[ETH_RX_BUF_TOTAL_11][ETH_MAX_RX_FRAME_LENGTH_11];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_11
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_12)
#define ETH_START_SEC_VAR_PORT_BUFFER_12                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl12_TxBufferData[ETH_TX_BUF_TOTAL_12][ETH_MAX_TX_FRAME_LENGTH_12];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_12
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_12)
#define ETH_START_SEC_VAR_PORT_BUFFER_12                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl12_RxBufferData[ETH_RX_BUF_TOTAL_12][ETH_MAX_RX_FRAME_LENGTH_12];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_12
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_13)
#define ETH_START_SEC_VAR_PORT_BUFFER_13                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl13_TxBufferData[ETH_TX_BUF_TOTAL_13][ETH_MAX_TX_FRAME_LENGTH_13];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_13
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_13)
#define ETH_START_SEC_VAR_PORT_BUFFER_13                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl13_RxBufferData[ETH_RX_BUF_TOTAL_13][ETH_MAX_RX_FRAME_LENGTH_13];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_13
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_14)
#define ETH_START_SEC_VAR_PORT_BUFFER_14                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl14_TxBufferData[ETH_TX_BUF_TOTAL_14][ETH_MAX_TX_FRAME_LENGTH_14];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_14
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_14)
#define ETH_START_SEC_VAR_PORT_BUFFER_14                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl14_RxBufferData[ETH_RX_BUF_TOTAL_14][ETH_MAX_RX_FRAME_LENGTH_14];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_14
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_15)
#define ETH_START_SEC_VAR_PORT_BUFFER_15                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl15_TxBufferData[ETH_TX_BUF_TOTAL_15][ETH_MAX_TX_FRAME_LENGTH_15];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_15
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_15)
#define ETH_START_SEC_VAR_PORT_BUFFER_15                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl15_RxBufferData[ETH_RX_BUF_TOTAL_15][ETH_MAX_RX_FRAME_LENGTH_15];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_15
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_16)
#define ETH_START_SEC_VAR_PORT_BUFFER_16                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl16_TxBufferData[ETH_TX_BUF_TOTAL_16][ETH_MAX_TX_FRAME_LENGTH_16];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_16)
#define ETH_START_SEC_VAR_PORT_BUFFER_16                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl16_RxBufferData[ETH_RX_BUF_TOTAL_16][ETH_MAX_RX_FRAME_LENGTH_16];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_17)
#define ETH_START_SEC_VAR_PORT_BUFFER_17                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl17_TxBufferData[ETH_TX_BUF_TOTAL_17][ETH_MAX_TX_FRAME_LENGTH_17];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_17
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_17)
#define ETH_START_SEC_VAR_PORT_BUFFER_17                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl17_RxBufferData[ETH_RX_BUF_TOTAL_17][ETH_MAX_RX_FRAME_LENGTH_17];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_17
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_18)
#define ETH_START_SEC_VAR_PORT_BUFFER_18                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl18_TxBufferData[ETH_TX_BUF_TOTAL_18][ETH_MAX_TX_FRAME_LENGTH_18];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_18
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_18)
#define ETH_START_SEC_VAR_PORT_BUFFER_18                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl18_RxBufferData[ETH_RX_BUF_TOTAL_18][ETH_MAX_RX_FRAME_LENGTH_18];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_18
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_19)
#define ETH_START_SEC_VAR_PORT_BUFFER_19                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl19_TxBufferData[ETH_TX_BUF_TOTAL_19][ETH_MAX_TX_FRAME_LENGTH_19];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_19
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_19)
#define ETH_START_SEC_VAR_PORT_BUFFER_19                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl19_RxBufferData[ETH_RX_BUF_TOTAL_19][ETH_MAX_RX_FRAME_LENGTH_19];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_19
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_20)
#define ETH_START_SEC_VAR_PORT_BUFFER_20                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl20_TxBufferData[ETH_TX_BUF_TOTAL_20][ETH_MAX_TX_FRAME_LENGTH_20];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_20
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_20)
#define ETH_START_SEC_VAR_PORT_BUFFER_20                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl20_RxBufferData[ETH_RX_BUF_TOTAL_20][ETH_MAX_RX_FRAME_LENGTH_20];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_20
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_TX_BUF_TOTAL_21)
#define ETH_START_SEC_VAR_PORT_BUFFER_21                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl21_TxBufferData[ETH_TX_BUF_TOTAL_21][ETH_MAX_TX_FRAME_LENGTH_21];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_21
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_21)
#define ETH_START_SEC_VAR_PORT_BUFFER_21                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl21_RxBufferData[ETH_RX_BUF_TOTAL_21][ETH_MAX_RX_FRAME_LENGTH_21];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_21
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif
#if defined(ETH_TX_BUF_TOTAL_22)
#define ETH_START_SEC_VAR_PORT_BUFFER_22                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl22_TxBufferData[ETH_TX_BUF_TOTAL_22][ETH_MAX_TX_FRAME_LENGTH_22];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_22
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

#if defined(ETH_RX_BUF_TOTAL_22)
#define ETH_START_SEC_VAR_PORT_BUFFER_22                                                                                /* PRQA S 0791 # JV-01 */
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC VAR(uint8, ETH_VAR_NO_INIT) Eth_Ctrl22_RxBufferData[ETH_RX_BUF_TOTAL_22][ETH_MAX_RX_FRAME_LENGTH_22];
#define ETH_STOP_SEC_VAR_PORT_BUFFER_22
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif

/***********************************************************************************************************************
** Transmit/Receieve buffer node                                                                                      **
** Array to store Buffer information of all buffer of each queue on a controller                                      **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl0_TxBufferNode[ETH_TX_BUF_TOTAL_0];
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl0_RxBufferNode[ETH_RX_BUF_TOTAL_0];

#if defined(ETH_TX_BUF_TOTAL_1)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl1_TxBufferNode[ETH_TX_BUF_TOTAL_1];
#endif

#if defined(ETH_RX_BUF_TOTAL_1)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl1_RxBufferNode[ETH_RX_BUF_TOTAL_1];
#endif

#if defined(ETH_TX_BUF_TOTAL_2)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl2_TxBufferNode[ETH_TX_BUF_TOTAL_2];
#endif

#if defined(ETH_RX_BUF_TOTAL_2)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl2_RxBufferNode[ETH_RX_BUF_TOTAL_2];
#endif

#if defined(ETH_TX_BUF_TOTAL_3)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl3_TxBufferNode[ETH_TX_BUF_TOTAL_3];
#endif

#if defined(ETH_RX_BUF_TOTAL_3)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl3_RxBufferNode[ETH_RX_BUF_TOTAL_3];
#endif

#if defined(ETH_TX_BUF_TOTAL_4)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl4_TxBufferNode[ETH_TX_BUF_TOTAL_4];
#endif

#if defined(ETH_RX_BUF_TOTAL_4)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl4_RxBufferNode[ETH_RX_BUF_TOTAL_4];
#endif

#if defined(ETH_TX_BUF_TOTAL_5)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl5_TxBufferNode[ETH_TX_BUF_TOTAL_5];
#endif

#if defined(ETH_RX_BUF_TOTAL_5)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl5_RxBufferNode[ETH_RX_BUF_TOTAL_5];
#endif

#if defined(ETH_TX_BUF_TOTAL_6)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl6_TxBufferNode[ETH_TX_BUF_TOTAL_6];
#endif

#if defined(ETH_RX_BUF_TOTAL_6)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl6_RxBufferNode[ETH_RX_BUF_TOTAL_6];
#endif

#if defined(ETH_TX_BUF_TOTAL_7)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl7_TxBufferNode[ETH_TX_BUF_TOTAL_7];
#endif

#if defined(ETH_RX_BUF_TOTAL_7)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl7_RxBufferNode[ETH_RX_BUF_TOTAL_7];
#endif

#if defined(ETH_TX_BUF_TOTAL_8)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl8_TxBufferNode[ETH_TX_BUF_TOTAL_8];
#endif

#if defined(ETH_RX_BUF_TOTAL_8)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl8_RxBufferNode[ETH_RX_BUF_TOTAL_8];
#endif

#if defined(ETH_TX_BUF_TOTAL_9)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl9_TxBufferNode[ETH_TX_BUF_TOTAL_9];
#endif

#if defined(ETH_RX_BUF_TOTAL_9)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl9_RxBufferNode[ETH_RX_BUF_TOTAL_9];
#endif

#if defined(ETH_TX_BUF_TOTAL_10)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl10_TxBufferNode[ETH_TX_BUF_TOTAL_10];
#endif

#if defined(ETH_RX_BUF_TOTAL_10)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl10_RxBufferNode[ETH_RX_BUF_TOTAL_10];
#endif

#if defined(ETH_TX_BUF_TOTAL_11)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl11_TxBufferNode[ETH_TX_BUF_TOTAL_11];
#endif

#if defined(ETH_RX_BUF_TOTAL_11)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl11_RxBufferNode[ETH_RX_BUF_TOTAL_11];
#endif

#if defined(ETH_TX_BUF_TOTAL_12)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl12_TxBufferNode[ETH_TX_BUF_TOTAL_12];
#endif

#if defined(ETH_RX_BUF_TOTAL_12)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl12_RxBufferNode[ETH_RX_BUF_TOTAL_12];
#endif

#if defined(ETH_TX_BUF_TOTAL_13)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl13_TxBufferNode[ETH_TX_BUF_TOTAL_13];
#endif

#if defined(ETH_RX_BUF_TOTAL_13)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl13_RxBufferNode[ETH_RX_BUF_TOTAL_13];
#endif

#if defined(ETH_TX_BUF_TOTAL_14)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl14_TxBufferNode[ETH_TX_BUF_TOTAL_14];
#endif

#if defined(ETH_RX_BUF_TOTAL_14)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl14_RxBufferNode[ETH_RX_BUF_TOTAL_14];
#endif

#if defined(ETH_TX_BUF_TOTAL_15)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl15_TxBufferNode[ETH_TX_BUF_TOTAL_15];
#endif

#if defined(ETH_RX_BUF_TOTAL_15)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl15_RxBufferNode[ETH_RX_BUF_TOTAL_15];
#endif

#if defined(ETH_TX_BUF_TOTAL_16)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl16_TxBufferNode[ETH_TX_BUF_TOTAL_16];
#endif

#if defined(ETH_RX_BUF_TOTAL_16)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl16_RxBufferNode[ETH_RX_BUF_TOTAL_16];
#endif

#if defined(ETH_TX_BUF_TOTAL_17)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl17_TxBufferNode[ETH_TX_BUF_TOTAL_17];
#endif

#if defined(ETH_RX_BUF_TOTAL_17)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl17_RxBufferNode[ETH_RX_BUF_TOTAL_17];
#endif

#if defined(ETH_TX_BUF_TOTAL_18)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl18_TxBufferNode[ETH_TX_BUF_TOTAL_18];
#endif

#if defined(ETH_RX_BUF_TOTAL_18)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl18_RxBufferNode[ETH_RX_BUF_TOTAL_18];
#endif

#if defined(ETH_TX_BUF_TOTAL_19)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl19_TxBufferNode[ETH_TX_BUF_TOTAL_19];
#endif

#if defined(ETH_RX_BUF_TOTAL_19)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl19_RxBufferNode[ETH_RX_BUF_TOTAL_19];
#endif

#if defined(ETH_TX_BUF_TOTAL_20)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl20_TxBufferNode[ETH_TX_BUF_TOTAL_20];
#endif

#if defined(ETH_RX_BUF_TOTAL_20)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl20_RxBufferNode[ETH_RX_BUF_TOTAL_20];
#endif

#if defined(ETH_TX_BUF_TOTAL_21)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl21_TxBufferNode[ETH_TX_BUF_TOTAL_21];
#endif

#if defined(ETH_RX_BUF_TOTAL_21)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl21_RxBufferNode[ETH_RX_BUF_TOTAL_21];
#endif

#if defined(ETH_TX_BUF_TOTAL_22)
STATIC VAR(Eth_BufHandlerType, ETH_VAR_NO_INIT) Eth_Ctrl22_TxBufferNode[ETH_TX_BUF_TOTAL_22];
#endif
#if defined(ETH_RX_BUF_TOTAL_22)
STATIC VAR(Eth_RxBufManageType, ETH_VAR_NO_INIT) Eth_Ctrl22_RxBufferNode[ETH_RX_BUF_TOTAL_22];
#endif


#define ETH_STOP_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Global variable to store pointer to Configuration */
P2CONST(Eth_CtrlConfigType, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpCtrlConfigPtr;                                  /* PRQA S 3432 # JV-01 */
P2CONST(Eth_EthConfigType, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpEthConfigPtr;                                    /* PRQA S 3432 # JV-01 */
P2CONST(uint32, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpTotalCtrlConfig;                                            /* PRQA S 3432 # JV-01 */
P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventAccess;                                                      /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventRxFramesLost;                                                /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventCRC;                                                         /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventUnderSizeFrame;                                              /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventOverSizeFrame;                                               /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventAlignment;                                                   /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventSinglecollision;                                             /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventMultiplecollision;                                           /* PRQA S 3432 # JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventLatecollision;                                               /* PRQA S 3432 # JV-01 */

#if ( ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventIntInconsistent;
#endif

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventUnintendedIntChk;                                            /* PRQA S 3432 # JV-01 */
#endif

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventDmaError;                                                    /* PRQA S 1533, 3432 # JV-01, JV-01 */

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventEccError;                                                    /* PRQA S 1533, 3432 # JV-01, JV-01 */

#if (ETH_MACRO_ETNB == STD_ON || ETH_MACRO_ETNF ==STD_ON)
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventTimerincFailed;

P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventTimeroffsetFailed;
#endif
#if ((ETH_REGISTER_CHECK_INITTIME == STD_ON) || (ETH_REGISTER_CHECK_RUNTIME == STD_ON))
P2CONST(uint16, ETH_CONST, ETH_CONFIG_CONST) Eth_GpDemEventRegisterCorruption;
#endif
#endif
#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Multicast address filter list */
VAR(Eth_MacAddressType, ETH_VAR_NO_INIT) Eth_GaaAddressFilters[ETH_TOTAL_CTRL_CONFIG][ETH_MAX_FILTERS];

/* Status of controller(s) */
VAR(Eth_ControllerStatusType, ETH_VAR_NO_INIT) Eth_GaaCtrlStat[ETH_TOTAL_CTRL_CONFIG];

#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Tx Buffer Data of Controller */
P2VAR(uint8, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxBufferDataTable[ETH_TOTAL_CTRL_CONFIG] =                             /* PRQA S 3432 # JV-01 */
{
  &Eth_Ctrl0_TxBufferData[ETH_ZERO][ETH_ZERO],

  #if defined(ETH_TX_BUF_TOTAL_1)
  &Eth_Ctrl1_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_1) */

  #if defined(ETH_TX_BUF_TOTAL_2)
  &Eth_Ctrl2_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_2) */

  #if defined(ETH_TX_BUF_TOTAL_3)
  &Eth_Ctrl3_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_3) */

  #if defined(ETH_TX_BUF_TOTAL_4)
  &Eth_Ctrl4_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_4) */

  #if defined(ETH_TX_BUF_TOTAL_5)
  &Eth_Ctrl5_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_5) */

  #if defined(ETH_TX_BUF_TOTAL_6)
  &Eth_Ctrl6_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_6) */

  #if defined(ETH_TX_BUF_TOTAL_7)
  &Eth_Ctrl7_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_7) */

  #if defined(ETH_TX_BUF_TOTAL_8)
  &Eth_Ctrl8_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_8) */

  #if defined(ETH_TX_BUF_TOTAL_9)
  &Eth_Ctrl9_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_9) */

  #if defined(ETH_TX_BUF_TOTAL_10)
  &Eth_Ctrl10_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_10) */

  #if defined(ETH_TX_BUF_TOTAL_11)
  &Eth_Ctrl11_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_11) */

  #if defined(ETH_TX_BUF_TOTAL_12)
  &Eth_Ctrl12_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_12) */

  #if defined(ETH_TX_BUF_TOTAL_13)
  &Eth_Ctrl13_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_13) */

  #if defined(ETH_TX_BUF_TOTAL_14)
  &Eth_Ctrl14_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_14) */

  #if defined(ETH_TX_BUF_TOTAL_15)
  &Eth_Ctrl15_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_15) */

  #if defined(ETH_TX_BUF_TOTAL_16)
  &Eth_Ctrl16_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_16) */

  #if defined(ETH_TX_BUF_TOTAL_17)
  &Eth_Ctrl17_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_17) */

  #if defined(ETH_TX_BUF_TOTAL_18)
  &Eth_Ctrl18_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_18) */

  #if defined(ETH_TX_BUF_TOTAL_19)
  &Eth_Ctrl19_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_19) */

  #if defined(ETH_TX_BUF_TOTAL_20)
  &Eth_Ctrl20_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_20) */

  #if defined(ETH_TX_BUF_TOTAL_21)
  &Eth_Ctrl21_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_21) */

  #if defined(ETH_TX_BUF_TOTAL_22)
  &Eth_Ctrl22_TxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_22) */
};

/* Array of pointers to manage Tx buffer data */
P2VAR(uint8, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxBufferDataTable[ETH_TOTAL_CTRL_CONFIG] =                             /* PRQA S 1533, 3432 # JV-01, JV-01 */
{
  &Eth_Ctrl0_RxBufferData[ETH_ZERO][ETH_ZERO],

  #if defined(ETH_RX_BUF_TOTAL_1)
  &Eth_Ctrl1_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_1 */

  #if defined(ETH_RX_BUF_TOTAL_2)
  &Eth_Ctrl2_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_2 */

  #if defined(ETH_RX_BUF_TOTAL_3)
  &Eth_Ctrl3_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_3 */

  #if defined(ETH_RX_BUF_TOTAL_4)
  &Eth_Ctrl4_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_4 */

  #if defined(ETH_RX_BUF_TOTAL_5)
  &Eth_Ctrl5_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_5 */

  #if defined(ETH_RX_BUF_TOTAL_6)
  &Eth_Ctrl6_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_6 */

  #if defined(ETH_RX_BUF_TOTAL_7)
  &Eth_Ctrl7_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_7 */

  #if defined(ETH_RX_BUF_TOTAL_8)
  &Eth_Ctrl8_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_8 */

  #if defined(ETH_RX_BUF_TOTAL_9)
  &Eth_Ctrl9_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_9 */

  #if defined(ETH_RX_BUF_TOTAL_10)
  &Eth_Ctrl10_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_10 */

  #if defined(ETH_RX_BUF_TOTAL_11)
  &Eth_Ctrl11_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_11 */

  #if defined(ETH_RX_BUF_TOTAL_12)
  &Eth_Ctrl12_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_12 */

  #if defined(ETH_RX_BUF_TOTAL_13)
  &Eth_Ctrl13_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_13 */

  #if defined(ETH_RX_BUF_TOTAL_14)
  &Eth_Ctrl14_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_14 */

  #if defined(ETH_RX_BUF_TOTAL_15)
  &Eth_Ctrl15_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_15 */

  #if defined(ETH_RX_BUF_TOTAL_16)
  &Eth_Ctrl16_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_16 */

  #if defined(ETH_RX_BUF_TOTAL_17)
  &Eth_Ctrl17_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_17 */

  #if defined(ETH_RX_BUF_TOTAL_18)
  &Eth_Ctrl18_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_18 */

  #if defined(ETH_RX_BUF_TOTAL_19)
  &Eth_Ctrl19_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_19 */

  #if defined(ETH_RX_BUF_TOTAL_20)
  &Eth_Ctrl20_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_20 */

  #if defined(ETH_RX_BUF_TOTAL_21)
  &Eth_Ctrl21_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_21 */

  #if defined(ETH_RX_BUF_TOTAL_22)
  &Eth_Ctrl22_RxBufferData[ETH_ZERO][ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_22 */

};

/* Array of pointers to manage Tx buffer node */
P2VAR(Eth_BufHandlerType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaTxBufferNodes[ETH_TOTAL_CTRL_CONFIG] =                    /* PRQA S 3432 # JV-01 */
{
  &Eth_Ctrl0_TxBufferNode[ETH_ZERO],

  #if defined(ETH_TX_BUF_TOTAL_1)
  &Eth_Ctrl1_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_1) */

  #if defined(ETH_TX_BUF_TOTAL_2)
  &Eth_Ctrl2_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_2) */

  #if defined(ETH_TX_BUF_TOTAL_3)
  &Eth_Ctrl3_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_3) */

  #if defined(ETH_TX_BUF_TOTAL_4)
  &Eth_Ctrl4_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_4) */

  #if defined(ETH_TX_BUF_TOTAL_5)
  &Eth_Ctrl5_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_5) */

  #if defined(ETH_TX_BUF_TOTAL_6)
  &Eth_Ctrl6_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_6) */

  #if defined(ETH_TX_BUF_TOTAL_7)
  &Eth_Ctrl7_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_7) */

  #if defined(ETH_TX_BUF_TOTAL_8)
  &Eth_Ctrl8_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_8) */

  #if defined(ETH_TX_BUF_TOTAL_9)
  &Eth_Ctrl9_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_9) */

  #if defined(ETH_TX_BUF_TOTAL_10)
  &Eth_Ctrl10_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_10) */

  #if defined(ETH_TX_BUF_TOTAL_11)
  &Eth_Ctrl11_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_11) */

  #if defined(ETH_TX_BUF_TOTAL_12)
  &Eth_Ctrl12_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_12) */

  #if defined(ETH_TX_BUF_TOTAL_13)
  &Eth_Ctrl13_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_13) */

  #if defined(ETH_TX_BUF_TOTAL_14)
  &Eth_Ctrl14_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_14) */

  #if defined(ETH_TX_BUF_TOTAL_15)
  &Eth_Ctrl15_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_15) */

  #if defined(ETH_TX_BUF_TOTAL_16)
  &Eth_Ctrl16_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_16) */

  #if defined(ETH_TX_BUF_TOTAL_17)
  &Eth_Ctrl17_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_17) */

  #if defined(ETH_TX_BUF_TOTAL_18)
  &Eth_Ctrl18_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_18) */

  #if defined(ETH_TX_BUF_TOTAL_19)
  &Eth_Ctrl19_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_19) */

  #if defined(ETH_TX_BUF_TOTAL_20)
  &Eth_Ctrl20_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_20) */

  #if defined(ETH_TX_BUF_TOTAL_21)
  &Eth_Ctrl21_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_21) */

  #if defined(ETH_TX_BUF_TOTAL_22)
  &Eth_Ctrl22_TxBufferNode[ETH_ZERO],
  #endif /* #if defined(ETH_TX_BUF_TOTAL_22) */

};


/* Array of pointers to manage Rx buffer node */
P2VAR(Eth_RxBufManageType, ETH_VAR_INIT, ETH_APPL_DATA) Eth_GaaRxBufferNodes[ETH_TOTAL_CTRL_CONFIG] =                   /* PRQA S 3432 # JV-01 */
{
  &Eth_Ctrl0_RxBufferNode[ETH_ZERO],

  #if defined(ETH_RX_BUF_TOTAL_1)
  &Eth_Ctrl1_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_1 */

  #if defined(ETH_RX_BUF_TOTAL_2)
  &Eth_Ctrl2_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_2 */

  #if defined(ETH_RX_BUF_TOTAL_3)
  &Eth_Ctrl3_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_3 */

  #if defined(ETH_RX_BUF_TOTAL_4)
  &Eth_Ctrl4_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_4 */

  #if defined(ETH_RX_BUF_TOTAL_5)
  &Eth_Ctrl5_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_5 */

  #if defined(ETH_RX_BUF_TOTAL_6)
  &Eth_Ctrl6_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_6 */

  #if defined(ETH_RX_BUF_TOTAL_7)
  &Eth_Ctrl7_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_7 */

  #if defined(ETH_RX_BUF_TOTAL_8)
  &Eth_Ctrl8_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_8 */

  #if defined(ETH_RX_BUF_TOTAL_9)
  &Eth_Ctrl9_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_9 */

  #if defined(ETH_RX_BUF_TOTAL_10)
  &Eth_Ctrl10_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_10 */

  #if defined(ETH_RX_BUF_TOTAL_11)
  &Eth_Ctrl11_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_11 */

  #if defined(ETH_RX_BUF_TOTAL_12)
  &Eth_Ctrl12_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_12 */

  #if defined(ETH_RX_BUF_TOTAL_13)
  &Eth_Ctrl13_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_13 */

  #if defined(ETH_RX_BUF_TOTAL_14)
  &Eth_Ctrl14_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_14 */

  #if defined(ETH_RX_BUF_TOTAL_15)
  &Eth_Ctrl15_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_15 */

  #if defined(ETH_RX_BUF_TOTAL_16)
  &Eth_Ctrl16_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_16 */

  #if defined(ETH_RX_BUF_TOTAL_17)
  &Eth_Ctrl17_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_17 */

  #if defined(ETH_RX_BUF_TOTAL_18)
  &Eth_Ctrl18_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_18 */

  #if defined(ETH_RX_BUF_TOTAL_19)
  &Eth_Ctrl19_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_19 */

  #if defined(ETH_RX_BUF_TOTAL_20)
  &Eth_Ctrl20_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_20 */

  #if defined(ETH_RX_BUF_TOTAL_21)
  &Eth_Ctrl21_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_21 */

  #if defined(ETH_RX_BUF_TOTAL_22)
  &Eth_Ctrl22_RxBufferNode[ETH_ZERO],
  #endif /* end of ETH_RX_BUF_TOTAL_22 */
};

P2VAR(Eth_StateType, ETH_VAR_INIT, ETH_VAR_INIT) Eth_GpDriverState;                                                     /* PRQA S 3432 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if (ETH_MULTI_CORE_SUPPORT == STD_ON)
#define ETH_START_SEC_CONST_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/* Global variable to store core index */
P2CONST(uint8, ETH_VAR_INIT, ETH_CONFIG_CONST) Eth_GpCoreId2Index;                                                      /* PRQA S 3432 # JV-01 */                                                     

#define ETH_STOP_SEC_CONST_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif
/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
