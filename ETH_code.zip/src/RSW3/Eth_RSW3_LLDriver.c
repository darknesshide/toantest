/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_LLDriver.c                                                                                 */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains RSW3 specific operations of Eth Driver Component.                                               */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.30: 29/06/2026   : Update to support multicore type-II:
 *                        + Function Eth_HwPreCommonInit(), remove redundant initial variable, move initial
 *                        Eth_GaaLinkFixTable from this function to gentool generate
 *                        + Function Eth_RSW_HwInit(), move initial Eth_GaaRsw3PortValid and Eth_GaaRsw3PortCtrlIdx
 *                        from this function to gentool generate
 *                        + Function Eth_RSW_TxRxDescConfig(), remove intial Eth_GstDescChainMap, move initial
 *                        Eth_GstDescChainMap from this function to gentool generate
 *                        + Function Eth_RSW_TxRxDescConfig(), add initial for all element of Eth_GaaLinkFixTable
 * 1.1.29: 04/02/2026   : Update to change function Eth_GetTimeOutValue, change the condition check init time and
 *                        current time
 * 1.1.28: 26/02/2026   : Update to change function name as following:
 *                        + from Eth_RxCallEthIf to Eth_RSW_RxCallEthIf
 *                        + from Eth_IsRxFrameValid to Eth_RSW_IsRxFrameValid
 *                        + from Eth_TxRxDescConfig to Eth_RSW_TxRxDescConfig
 *                        + from Eth_TsDescConfig to Eth_RSW_TsDescConfig
 *                        Update to set MXGMIIC with force idle for ETHA set mode from Operation to Disable
 * 1.1.27: 18/11/2025   : Update to apply new implementation for TSUN field in Descriptor:
 *                        + bit7 will handle indicate that Tx Desc is from ETHA controller or GWCA controller
 *                        + bit6 will handle GWCA index when Tx Desc is from GWCA controller
 *                        Update to support RxStatsPkts64Octets, RxStatsPkts65to127Octets,
 *                         RxStatsPkts128to255Octets, RxStatsPkts256to511Octets, RxStatsPkts512to1023Octets,
 *                         RxStatsPkts1024to1518Octets in fucntions:
 *                        + Eth_InitRxStats
 *                        + Eth_HwRMAC_CountRxStats
 *                        + Eth_RSW_HwMainFunction
 *                        + Eth_RSW_RxQueueProcess
 * 1.1.26: 30/10/2025   : Update to replace X5H_VDK_ETH_USED with X5H_VDK_PLATFORM_USED
 * 1.1.25: 16/09/2025   : Update to support TSN-ES
 *                      : Support Config MAC Loopback mode
 *                      : Support setting MRSCE, MRSCP
 * 1.1.24: 25/07/2025   : Remove macro for old AUTOSAR version.
 * 1.1.23: 21/07/2025   : Move Link Verification from CONFIG_MODE into OPERATION_MODE
 * 1.1.22: 03/07/2025   : Update to write into PTPTIVC.TIVt with a common approach, instead of fixed value.
 *                        Add Data Cache Flush and Data Cache Invalidate to support cache.
 * 1.1.21: 09/06/2025   : Update RMAC_InitializationFlow(), to initial register MIOC, MRAFC
 * 1.1.20: 12/03/2025   : Update to merging SingleMainline
 *                        + Function Eth_RSW_HwTransmit() remove call Eth_RSW_CheckProvideBuffer() because
 *                        the static memory already have machenism to protect memory leak at get transmit buffer.
 *                        + Function Eth_RSW_HwTransmit() remove blTxOngoing
 *                        + Function Eth_RSW_HwTransmit() change ucPriority to ucTxQueueIdx
 *                        + Function Eth_RSW_HwGetEgressTimeStamp(), add critical section
 *                        + Fucntion Eth_TxRxDescConfig(), Eth_RxQueueProcess() change pRxDesc to ulRxDescAddr.
 *                        + Fucntion Eth_RxQueueProcess() change from stTimestamp to stTimeStamp.nanoseconds,
 *                        stTimeStamp.seconds, enTimeQual
 *                        + Function Eth_TxConfirmationQueueProcess() add checking blIsTxHandleId is True.
 *                        It is in case when tx confirmation of immediate transmit
 *                        + Function Eth_Gwca_TSDIS_Common_Isr() change ucPriority to ucTxQueueIdx
 * 1.1.19: 13/09/2024   : Update new implement for ETHA_FullSettingFlow
 *                        Update implementation for Eth_RxQueueProcess, Eth_TxRxDescConfig, Eth_RxCallEthIf
 *                        + Eth_RxQueueProcess: Update to correct calcalation for LpRxBuffer
 *                        + Eth_TxRxDescConfig: Update to release descriptor for invalid frame
 *                        + Eth_RxCallEthIf: Set time stamp to INVALID if ETH_GLOBAL_TIME_SUPPORT is STD_OFF
 *                        + Eth_IsRxFrameValid: Update to correct verification destination address of Rx Frame
 * 1.1.17: 13/08/2024   : Update implementation for Eth_RxQueueProcess, Eth_TxRxDescConfig, Eth_RxCallEthIf
 * 1.1.16: 28/07/2024   : Update implementation for Eth_HwInit, Eth_TxRxDescConfig
 * 1.1.16: 19/06/2024   : Add new function Eth_HwGetCurrentTimeTuple to support R23-11
 *                        Update datatype for TimeStampQualType, TimeStampType
 *                        Update new enum value for TimeStampQualType
 * 1.0.2: 21/12/2023    : Change process to support 2GWCA operate in the same time in functions:
 *                         Eth_HwCommonPostInit, Eth_HwTransmit, Eth_HwEnableInterrupt,
 *                         Eth_HwTOP_SwitchInitializationFlow, Eth_HwMFWD_PortISettingFlow,
 *                         Eth_HwMFWD_PortIPortBasedSettingFlow, COMA_BufferPoolnitializationFlow,
 *                         GWCA_FullSettingFlow, Eth_Gwca_TSDIS_Common_Isr
 *                       : Correct Eth_GaaRSW3_ETHARegs index in funtion Eth_HwEnableErrorInterrupt
 * 1.0.2: 21/12/2023    : Remove macro ETH_VPF and X5H_VDK_ETH_USED in functions:
 *                         Eth_GetTimeOutValue, Eth_HwMFWD_Layer3TableResetFlow, Eth_HwMFWD_MacTableResetFlow,
 *                         Eth_HwMFWD_MacTableResetFlow, Eth_HwMFWD_VlanTableResetFlow, Eth_HwMFWD_GateRamResetFlow,
 *                         Eth_HwGWCA_ModeTransitionFlow, Eth_HwGWCA_MulticastTableResetFlow, Eth_HwGWCA_AxiRamResetFlow
 *                         Eth_HwETHA_ModeTransitionFlow, Eth_HwETHA_TasRamResetFlow, Eth_HwRMAC_PhyMdioWriteAccessFlow,
 *                         Eth_HwRMAC_PhyMdioReadAccessFlow, COMA_BufferPoolnitializationFlow, GWCA_FullSettingFlow.
 *                         Define macro for error interrupt enable for RSW3
 * 1.0.1: 22/11/2023    : Support R22-11, update implementation of
 *                        Eth_HwReadMii, Eth_HwRMAC_PhyMdioReadAccessFlow,
 *                        Eth_HwCheckFifoIndex
 *                        Update QAC violation
 * 1.0.0: 16/08/2023    : Initial Version
 */

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0310)    : Casting to different object pointer type.                                                    */
/* Rule                : CERTCCM EXP39, EXP11, CWE Rule CWE-188, CWE-468, CWE-1157, CWE-398, CWE-465, CWE-569,        */
/*                       CWE-588, MISRA C:2012 Rule-11.3                                                              */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : For accessing 8-bit and 16-bit PNOT and JPNOT register respectively, the 32-bit pointer is   */
/*                       typecasted.                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0317)    : Implicit conversion from a pointer to void to a pointer to object type.                      */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : This is done as per implementation requirement.                                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact               */
/**********************************************************************************************************************/
/* Message (7:0326)    : Cast between a pointer to void and an integral type.                                         */
/* Rule                : CERTCCM EXP36, INT36, MISRA C:2012 Rule-11.6, CWE-398, CWE-569, CWE-738                      */
/* JV-01 Justification : Using void due to specific requirement of input parameter. So, this can be skipped.          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0404)    : More than one read access to volatile objects between sequence points.                       */
/* Rule                : CERTCCM EXP30, EXP10, CWE Rule CWE-1157, CWE-758, CWE-682, MISRA C:2012 Rule-1.3, Rule-13.2  */
/*                       REFERENCE - ISO:C90-6.3 Expressions                                                          */
/* JV-01 Justification : This is to get element in array of struct, volatile of counter variable of 'for' loop is     */
/*                       used to ensure no optimization. It is accepted                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1502)    : The object '%1s' is defined but is not used within this project.                             */
/* Rule                : CERTCCM MSC13, CWE Rule CWE-398, CWE-569,                                                    */
/* JV-01 Justification : This is accepted, due to the module's object is exported for usage.                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-2.1                             */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1504)    : The object '%1s' is only referenced in the translation unit where it is defined.             */
/* Rule                : CERTCCM DCL15, DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                      */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1533)    : The object '%1s' is only referenced by function '%2s'.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.9                                            */
/* JV-01 Justification : This is accepted, due to the object is defined in separated source C file to followed        */
/*                       coding rule                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2877)    : This loop will never be executed more than once.                                             */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-670,  MISRA C:2012 Dir-4.1                                       */
/* JV-01 Justification : This loop will only be executed at least once, depends on user configuration.                */
/*       Verification  : This is Hardware Specification, X2x only provides 1 Unit. So it is not having any impact.    */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2983)    : This assignment is redundant. The value of this object is never subsequently used.           */
/* Rule                : CERTCCM MSC07, MSC13, MISRA C:2012 Rule-2.2                                                  */
/* JV-01 Justification : The value is to increment the pointer to the next item.                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-561, CWE-569,  MISRA C:2012 Rule-2.2             */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2986)    : This operation is redundant. The value of the result is always that of the right-hand        */
/*                       operand.                                                                                     */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-561, CWE-569,  MISRA C:2012 Rule-2.2             */
/* JV-01 Justification : The operation is correct                                                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2991)    : The value of this 'if' controlling expression is always 'true'.                              */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2995)    : The result of this logical operation is always 'true'.                                       */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3200)    : '%1s' returns a value which is not being used.                                               */
/* Rule                : CERTCCM ERR33, POS54, EXP12, CWE Rule CWE-391, CWE-1167, CWE-252, CWE-1171, CWE-389,         */
/*                       CWE-398, CWE-569,  MISRA C:2012 Rule-17.7                                                    */
/* JV-01 Justification : The value is not required since the call is from a wrapper function.                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3387)    : A full expression containing an increment (++) or decrement (--) operator should have no     */
/*                       potential side effects other than that caused by the increment or decrement operator.        */
/* Rule                : MISRA C:2012 Rule-13.3                                                                       */
/*                       REFERENCE - ISO:C90-5.1.2.3 Program Execution                                                */
/* JV-01 Justification : An increment/decrement is created a side affect. In this case it's accessing a volatile      */
/*                       object. This can be accepted.                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-1157, CWE-398, CWE-569,                                          */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%1s' is not modified and so the pointer       */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.13                     */
/* JV-01 Justification : Pointer variable is used to modify the value at the address so the pointer cannot be         */
/*                       declared as 'pointer to const' type.                                                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4322)    : An expression of 'essentially enum' type (ETag_Eth_RxExtStatusType) is being cast to a       */
/*                       different enum type, 'ETag_Eth_RxStatusType'.                                                */
/* Rule                : MISRA C:2012 Rule-10.5                                                                       */
/* JV-01 Justification : It is confirmed that no data loss occurs during the type casting process, so it is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_Ram.h"
#include "Eth_RSW3_Ram.h"
#include "Eth_RSW3_LLDriver.h"
#include "Eth_Serdes_LLDriver.h"

#include "EthIf.h"

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
/* Included for the declaration of the critical section protection functions */
#include "SchM_Eth.h"
#endif
#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif
#if (ETH_MACRO_RSW3 == STD_ON)

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_RSW3_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_RSW3_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_RSW3_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_RSW3_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (ETH_RSW3_AR_RELEASE_MAJOR_VERSION != ETH_RSW3_C_AR_RELEASE_MAJOR_VERSION)
#error "Eth_RSW3_LLDriver.c : Mismatch in Release Major Version"
#endif
#if (ETH_RSW3_AR_RELEASE_MINOR_VERSION != ETH_RSW3_C_AR_RELEASE_MINOR_VERSION)
#error "Eth_RSW3_LLDriver.c : Mismatch in Release Minor Version"
#endif
#if (ETH_RSW3_AR_RELEASE_REVISION_VERSION != ETH_RSW3_C_AR_RELEASE_REVISION_VERSION)
#error "Eth_RSW3_LLDriver.c : Mismatch in Release Revision Version"
#endif

#if (ETH_RSW3_SW_MAJOR_VERSION != ETH_RSW3_C_SW_MAJOR_VERSION)
#error "Eth_RSW3_LLDriver.c : Mismatch in Software Major Version"
#endif
#if (ETH_RSW3_SW_MINOR_VERSION != ETH_RSW3_C_SW_MINOR_VERSION)
#error "Eth_RSW3_LLDriver.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/
#define ETH_START_SEC_CONST_UNSPECIFIED
#include "Eth_MemMap.h"

/* RSW3 TOP module register */
CONSTP2VAR(volatile Eth_RSW3_TOPRegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_TOPRegs = (Eth_RSW3_TOPRegType *)ETH_RSW3_TOP_ADDRESS;                                                     /* PRQA S 0306, 1502, 1533 # JV-01, JV-01, JV-01 */

/* RSW3 COMA module register */
CONSTP2VAR(volatile Eth_RSW3_COMARegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_COMARegs = (Eth_RSW3_COMARegType *)ETH_RSW3_COMA_ADDRESS;                                                  /* PRQA S 0306, 1504 # JV-01, JV-01 */

/* RSW3 MFWD module register */
CONSTP2VAR(volatile Eth_RSW3_MFWDRegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_MFWDRegs = (Eth_RSW3_MFWDRegType *)ETH_RSW3_MFWD_ADDRESS;                                                  /* PRQA S 0306, 1504 # JV-01, JV-01 */

/* RSW3 GWCA module register */
CONSTP2VAR(volatile Eth_RSW3_GWCARegType, ETH_CONST, REGSPACE) Eth_GaaRSW3_GWCARegs[ETH_MAX_GWCA_SUPPORTED] =           /* PRQA S 1504 # JV-01 */
{
  (Eth_RSW3_GWCARegType *)ETH_RSW3_GWCA0_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_GWCARegType *)ETH_RSW3_GWCA1_ADDRESS                                                                        /* PRQA S 0306 # JV-01 */
};

/* RSW3 ETHA module register */
CONSTP2VAR(volatile Eth_RSW3_ETHARegType, ETH_CONST, REGSPACE) Eth_GaaRSW3_ETHARegs[ETH_MAX_TSNA_SUPPORTED] =           /* PRQA S 1504 # JV-01 */
{
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA0_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA1_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA2_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA3_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA4_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA5_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA6_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA7_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA8_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA9_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA10_ADDRESS,                                                                      /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA11_ADDRESS,                                                                      /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_ETHARegType *)ETH_RSW3_TSNA12_ADDRESS                                                                       /* PRQA S 0306 # JV-01 */
};

/* RSW3 RMAC module register */
CONSTP2VAR(volatile Eth_RSW3_RMACRegType, ETH_CONST, REGSPACE) Eth_GaaRSW3_RMACRegs[ETH_MAX_RMAC_SUPPORTED] =           /* PRQA S 1504 # JV-01 */
{
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC0_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC1_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC2_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC3_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC4_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC5_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC6_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC7_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC8_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC9_ADDRESS,                                                                       /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC10_ADDRESS,                                                                      /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC11_ADDRESS,                                                                      /* PRQA S 0306 # JV-01 */
  (Eth_RSW3_RMACRegType *)ETH_RSW3_RMAC12_ADDRESS                                                                       /* PRQA S 0306 # JV-01 */
};

/* RSW3 gPTP module register */
CONSTP2VAR(volatile Eth_RSW3_gPTPRegType, ETH_CONST, REGSPACE)
  Eth_GpRSW3_GPTPRegs = (Eth_RSW3_gPTPRegType *)ETH_RSW3_GPTP_ADDRESS;                                                  /* PRQA S 0306, 1502, 1504 # JV-01, JV-01, JV-01 */

CONST(uint32, ETH_CONST)
  Eth_GaaRsw3PortType[ETH_RACE_PORT_N] =                                                                                /* PRQA S 1504 # JV-01 */
{
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_ETHA,
  ETH_RSW3_PORT_TYPE_GWCA,
  ETH_RSW3_PORT_TYPE_GWCA
};

CONST(uint32, ETH_CONST)
  Eth_GaaRsw3PortMap[ETH_RACE_PORT_N] =                                                                                 /* PRQA S 1504 # JV-01 */
{
  ETH_RACE_PORT_ETHA0,
  ETH_RACE_PORT_ETHA1,
  ETH_RACE_PORT_ETHA2,
  ETH_RACE_PORT_ETHA3,
  ETH_RACE_PORT_ETHA4,
  ETH_RACE_PORT_ETHA5,
  ETH_RACE_PORT_ETHA6,
  ETH_RACE_PORT_ETHA7,
  ETH_RACE_PORT_ETHA8,
  ETH_RACE_PORT_ETHA9,
  ETH_RACE_PORT_ETHA10,
  ETH_RACE_PORT_ETHA11,
  ETH_RACE_PORT_ETHA12,
  ETH_RACE_PORT_GWCA0,
  ETH_RACE_PORT_GWCA1
};

#define ETH_STOP_SEC_CONST_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_TsDescConfig(void);
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

FUNC(void, ETH_PRIVATE_CODE) Eth_WaitNanoSec(CONST(uint32, AUTOMATIC) LulNanosec);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_TxRxDescConfig(CONST(uint32, AUTOMATIC) LulCtrlIdx);

#if (ETH_UPDATE_PHYS_ADDR_FILTER == STD_ON)
STATIC FUNC(boolean, ETH_PRIVATE_CODE) Eth_RSW_IsRxFrameValid(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulFrameAddr);
#endif  /* (ETH_UPDATE_PHYS_ADDR_FILTER == STD_ON) */

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_RxCallEthIf(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulQueueIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpFrame,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_TxConfirmationQueueProcess(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQIdx);


STATIC FUNC(TickType, ETH_PRIVATE_CODE) Eth_RSW_GetElapsedTimeValue(
  P2VAR(TickType, AUTOMATIC, ETH_APPL_DATA) LpTimeOutCount);                                                            /* PRQA S 3432 # JV-01 */


#if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON))
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwEnableInterrupt(void);
#endif /* ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)) */

#if ((ETH_GWCA_ERR_ISR == STD_ON) || (ETH_COMA_ERR_ISR == STD_ON) || (ETH_ETHA_ERR_ISR == STD_ON))
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwEnableErrorInterrupt(void);
#endif /* ((ETH_GWCA_ERR_ISR == STD_ON) || (ETH_COMA_ERR_ISR == STD_ON) || (ETH_ETHA_ERR_ISR == STD_ON)) */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwTOP_SwitchInitializationFlow(void);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwTOP_SwitchResetFlow(void);
#endif /* (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION) */

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwMFWD_PortISettingFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_Layer3TableResetFlow(void);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_MacTableResetFlow(void);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_VlanTableResetFlow(void);
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwMFWD_PortIPortBasedSettingFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwMFWD_PortIPortBasedDisableFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_Layer2Layer3UpdateTableResetFlow(void);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_GateRamResetFlow(void);
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_ModeTransitionFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx,
  CONST(uint32, AUTOMATIC) LenMode);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_InitializationFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_MulticastTableResetFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_AxiRamResetFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_ModeTransitionFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx,
  CONST(uint32, AUTOMATIC) LenMode);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_InitializationFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasRamResetFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwETHA_CbsQSettingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasSettingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasDisablingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwETHA_TasEnablingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasEntryILearnFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx,
  CONST(uint32, AUTOMATIC) LulSaveTasConfigAddr,
  CONSTP2CONST(Eth_TASEntryType, AUTOMATIC, ETH_APPL_DATA) LpCtrlConfig);
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

#if (ETH_CTRL_ENABLE_MII == STD_ON)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwRMAC_PhyMdioWriteAccessFlow(
  CONST(uint32, AUTOMATIC) LulRMACIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
  CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusWriteVal);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwRMAC_PhyMdioReadAccessFlow(
  CONST(uint32, AUTOMATIC) LulRMACIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx, CONST(uint8, AUTOMATIC) LucRegIdx,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr);                                                            /* PRQA S 3432 # JV-01 */
#endif /* (ETH_CTRL_ENABLE_MII == STD_ON) */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwRMAC_LinkVerification(
  CONST(uint32, AUTOMATIC) LulRMACIdx);

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwGPTP_TimerTOffsetSettingFlow(
  CONST(uint32, AUTOMATIC) LulTimerIdx,
  CONST(uint32, AUTOMATIC) LulNanoSeconds,
  CONST(uint32, AUTOMATIC) LulSecondsLower,
  CONST(uint16, AUTOMATIC) LusSecondsHigher);

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwGPTP_Avtp64TimerTReadingFlow(
  CONST(uint32, AUTOMATIC) LulTimerIdx,
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) ulAVTP_Upper,                                                            /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) ulAVTP_Downer);                                                          /* PRQA S 3432 # JV-01 */

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwGPTP_gPTPTimerTReadingFlow(
  CONST(uint32, AUTOMATIC) LulTimerIdx,
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpNanoSeconds,                                                           /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpSecondsLower,                                                          /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpSecondsHigher);                                                        /* PRQA S 3432 # JV-01 */
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) COMA_BufferPoolnitializationFlow(void);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_RSwitchResetFlow(void);
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_AgentIClockEnableFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_AgentIClockDisableFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx);

STATIC FUNC(boolean, ETH_PRIVATE_CODE) COMA_AgentIClockStatusCheckFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_SwitchClockEnableFlow(void);
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_FullSettingFlow(void);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_Layer3ForwardingRoutingFilteringSettingFlow(void);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_Layer2ForwardingSettingFlow(void);
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

STATIC FUNC(void, ETH_PRIVATE_CODE) MFWD_PortBasedForwardingSettingFlow(void);

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_Layer2Layer3UpdateSettingFlow(void);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_PsfpSettingFlow(void);
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) GWCA_FullSettingFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) ETHA_FullSettingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) RMAC_InitializationFlow(
  CONST(uint32, AUTOMATIC) LulRMACIdx);

#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats);                                                 /* PRQA S 3432 # JV-01 */
#endif /* (ETH_GET_COUNTER_VALUES_API == STD_ON) */

#if (ETH_GET_RX_STATS_API == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats);                                                 /* PRQA S 3432 # JV-01 */
#endif /* (ETH_GET_RX_STATS_API == STD_ON) */

#if (ETH_GET_TX_STATS_API == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats);                                                 /* PRQA S 3432 # JV-01 */
#endif /* (ETH_GET_TX_STATS_API == STD_ON) */

#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats);                                                 /* PRQA S 3432 # JV-01 */
#endif /* (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_HwPreCommonInit (RSW3)
**
** Service ID            : N/A
**
** Description           : Pre-Initialize the common parts of RSW3 HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaLinkFixTable, Eth_GstDescChainMap
**                         Eth_GaaRsw3GWCACtrlValid, Eth_GulRxMaxFrameSize
**                         Eth_GaaRsw3PortType, Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : Eth_RSW_TsDescConfig
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3002
** Reference ID          : ETH_DUD_ACT_3002_GBL001, ETH_DUD_ACT_3002_GBL002, ETH_DUD_ACT_3002_GBL003
** Reference ID          : ETH_DUD_ACT_3002_GBL004, ETH_DUD_ACT_3002_GBL005, ETH_DUD_ACT_3002_GBL006
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwPreCommonInit(void)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult;
  uint32 LulCtrlIdx;
  uint32 LulQueueIdx;

  LucResult = E_OK;

  for (LulCtrlIdx = 0U; LulCtrlIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulCtrlIdx++)                                       /* PRQA S 2877 # JV-01 */
  {
    LpHwUnitConfig =
      (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;             /* PRQA S 0316, 3432 # JV-01, JV-01 */
    if (ETH_RSW3_PORT_TYPE_GWCA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
    {
      Eth_GaaRsw3GWCACtrlValid = ETH_TRUE;
    }

    /*
     * NOTE:
     *
     * In PDF, the maximum received frame size can be specified for each queues.
     * But, this driver uses the smallest frame size provided in the configuration
     * for the following reasons.
     * - RSW3's RMAC can not set maximum receive frame size by queue.
     * - RSW3 has switching function, so frames received by RMAC do not always
     *   reach the appropriate controller.
     * - RSW3 splits DESCR when it receives frames larger than the size set in DESCR.DS,
     *   but this driver does not support DESCR splitting.
     *   So if it occurs, the reception process will stop and the only recovery method is reset.
     */
     /* Find minimum setting of Eth_RxQueueMaxFrameSize */
     /* to ensure uniform maximum frame size across all controllers. */
    for (LulQueueIdx = 0UL; LulQueueIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LulQueueIdx++)
    {
      if (Eth_GulRxMaxFrameSize > LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulQueueIdx].ulMaxFrameSize)
      {
        Eth_GulRxMaxFrameSize = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulQueueIdx].ulMaxFrameSize;
      }
    }
  }

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* Ts descriptor chain setting */
  Eth_RSW_TsDescConfig();
  #endif

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwPostCommonInit (RSW3)
**
** Service ID            : N/A
**
** Description           : Post-Initialize the common parts of RSW3 HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3GWCACtrlValid, Eth_GpRSW3_GPTPRegs,
**                         Eth_GaaRSW3_GWCARegs, Eth_GpGwcaCfgPtr
**
** Function(s) invoked   : Eth_HwTOP_SwitchResetFlow,Eth_HwTOP_SwitchInitializationFlow,
**                         Eth_HwEnableInterrupt,Eth_HwEnableErrorInterrupt,
**                         Eth_HwGWCA_ModeTransitionFlow
**
** Registers Used        : PTPTIVCt, PTPTMEC, GWTSDIE, GWSCR0
**
** Reference ID          : ETH_DUD_ACT_3003
** Reference ID          : ETH_DUD_ACT_3003_GBL001, ETH_DUD_ACT_3003_GBL002, ETH_DUD_ACT_3003_GBL003
** Reference ID          : ETH_DUD_ACT_3003_GBL004, ETH_DUD_ACT_3003_GBL005, ETH_DUD_ACT_3003_REG001
** Reference ID          : ETH_DUD_ACT_3003_REG002, ETH_DUD_ACT_3003_REG003, ETH_DUD_ACT_3003_REG004
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwPostCommonInit(void)
{
  Std_ReturnType LucResult;
  uint32 LulGWCAIdx;
  uint32 lucID;
  /**** Initialize RSW3 *****************************************************/
  #if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
  /* [TOP] Switch Reset Flow */
  LucResult = Eth_HwTOP_SwitchResetFlow();

  if (E_OK == LucResult)
  {
    /* [TOP] Switch Initialization Flow */
    LucResult = Eth_HwTOP_SwitchInitializationFlow();
  }
  else
  {
    /* No action required */
  }
  #else
  /* [TOP] Switch Initialization Flow */
  LucResult = Eth_HwTOP_SwitchInitializationFlow();
  #endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

  #if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON))
  if (E_OK == LucResult)
  {
    /* Enable GWCA Interrupt */
    Eth_HwEnableInterrupt();
  }
  else
  {
    /* No action required */
  }
  #endif /* ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)) */

  #if ((ETH_GWCA_ERR_ISR == STD_ON) || (ETH_COMA_ERR_ISR == STD_ON) || (ETH_ETHA_ERR_ISR == STD_ON))
  if (E_OK == LucResult)
  {
    /* Enable GWCA / COMA / ETHA Error Interrupt */
    Eth_HwEnableErrorInterrupt();
  }
  else
  {
    /* No action required */
  }
  #endif /* ((ETH_GWCA_ERR_ISR == STD_ON) || (ETH_COMA_ERR_ISR == STD_ON) || (ETH_ETHA_ERR_ISR == STD_ON)) */

  if (E_OK == LucResult)
  {
    #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
    Eth_GpRSW3_GPTPRegs->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTIVCt =
             ETH_GPTP_PTPTIVC_BIT0_TO_BIT26(ETH_PERI_CLOCK_HZ) | ETH_GPTP_PTPTIVC_BIT27_TO_BIT31(ETH_PERI_CLOCK_HZ);    /* PRQA S 3469 # JV-01 */
    Eth_GpRSW3_GPTPRegs->ulPTPTMEC = ETH_GPTP_TIMER_DOMAIN_ENABLE << ETH_GPTP_TIMER_DOMAIN;
    #endif /* ETH_GLOBAL_TIME_SUPPORT == STD_ON */

    for(lucID = 0; lucID < ETH_RSW3_GWCA_TOTAL_CONFIGURED; lucID++)                                                     /* PRQA S 2877 # JV-01 */
    {
      LulGWCAIdx = Eth_GaaGWCAValid[lucID];
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWTSDIE = ETH_GPTP_TIMER_DOMAIN_ENABLE << ETH_GPTP_TIMER_DOMAIN;
      #endif /* ETH_GLOBAL_TIME_SUPPORT == STD_ON */
      Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWSCR0 = Eth_GpGwcaCfgPtr[lucID].stGwcaRegValue.ulGWSCR0Value;

      if (ETH_TRUE != Eth_GaaRsw3GWCACtrlValid)
      {
        /* Mode transition flow to OPERATION mode */
        LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_DISABLE_MODE);
        if (E_OK == LucResult)
        {
          LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_OPERATION_MODE);
        }
        else
        {
          /* No action required */
        }
      }
    }
  }
  else
  {
    /* No action required */
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwInit (RSW3)
**
** Service ID            : N/A
**
** Description           : Initialize a RSW3 HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortValid,
**                         Eth_GaaRsw3PortCtrlIdx
**
** Function(s) invoked   : Eth_InitCounterValues,Eth_InitRxStats,
**                         Eth_InitTxStats,Eth_InitTxErrorCounterValues,
**                         Eth_Util_RamInit, Eth_RSW_TxRxDescConfig,
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3001
** Reference ID          : ETH_DUD_ACT_3001_GBL001, ETH_DUD_ACT_3001_GBL002, ETH_DUD_ACT_3001_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwInit(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult = E_NOT_OK;

  LpHwUnitConfig =                                                                                                      /* PRQA S 2983 # JV-01 */
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Initialize Statistics */
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_InitCounterValues(LulCtrlIdx);
  #endif
  #if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_InitRxStats(LulCtrlIdx);
  #endif
  #if (ETH_GET_TX_STATS_API == STD_ON)
  Eth_InitTxStats(LulCtrlIdx);
  #endif
  #if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
  Eth_InitTxErrorCounterValues(LulCtrlIdx);
  #endif

  Eth_RSW_RamInit(LulCtrlIdx);

  /* Tx/Rx descriptor chain setting */
  LucResult = Eth_RSW_TxRxDescConfig(LulCtrlIdx);

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwDisableController (RSW3)
**
** Service ID            : N/A
**
** Description           : Changes the state of an RSW3 controller as DOWN
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortType
**                         Eth_GaaTxBufferTotal, Eth_GaaTxBufferMgrTable, Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_HwETHA_ModeTransitionFlow, Eth_HwETHA_TasDisablingFlow
**                         Eth_HwGWCA_ModeTransitionFlow, Eth_RSW_ReleaseTxBuffer
**
** Registers Used        : TSNS, TSV, TSD, TSS
**
** Reference ID          : ETH_DUD_ACT_3005
** Reference ID          : ETH_DUD_ACT_3005_GBL001, ETH_DUD_ACT_3005_GBL002, ETH_DUD_ACT_3005_GBL003
** Reference ID          : ETH_DUD_ACT_3005_GBL004, ETH_DUD_ACT_3005_GBL005
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwDisableController(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtTxDirDescType, AUTOMATIC, ETH_APPL_DATA) LpTxDirDesc;                                                    /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA) LpRxEthDesc;                                                    /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult = E_OK;
  uint32 LulCnt;
  uint32 LulETHAIdx;
  uint32 LulGWCAIdx;
  uint32 LulQIdx;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {

    LulETHAIdx = ETH_CONV_PORTID_TO_ETHAID(LpHwUnitConfig->ulEthPortId);                                                /* PRQA S 3469 # JV-01 */

    /* Set to CONFIG mode to enable MDIO communication.  */
    LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_DISABLE_MODE);
    if (E_OK == LucResult)
    {
      LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_CONFIG_MODE);
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      if ((ETH_ENABLE == LpHwUnitConfig->stTASConfig.enTasEnable) && (E_OK == LucResult))
      {
        /* Set to TAS disable. */
        LucResult = Eth_HwETHA_TasDisablingFlow(LulETHAIdx);
      }
      else
      {
        /* No action required */
      }
      #endif /* ETH_GLOBAL_TIME_SUPPORT == STD_ON */
    }
    else
    {
      /* No action required */
    }

    /* When DISABLE of ETHA is requested, ETHA discards any subsequent Descriptors.
     * In addition, ETHA waits until the processing of all Descriptors being processed is
     * completed before transitioning to DISBALE.
     * This Descriptor is a Descriptor for ETHA, not the GWCA's Descriptor used by the driver.
     * That is, after exiting the above function, all ETHA Descriptors are FEMPTY,
     * but GWCA Descriptors are not always FEMPTY.
     * Since GWCA continues to move even after ETHA becomes DISABLE,
     * GWCA's Descriptor will also be FEMPTY at the end, but the timing will be different.
     * The order of changes in ETHA status and changes in GWCA Descriptor is in no particular order. */
  }
  else /* GWCA */
  {
    /* Set to CONFIG mode to enable MDIO communication.  */
    LulGWCAIdx = ETH_CONV_PORTID_TO_GWCAID(LpHwUnitConfig->ulEthPortId);                                                /* PRQA S 3383, 3432 # JV-01, JV-01 */
    LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_DISABLE_MODE);
    if (E_OK == LucResult)
    {
      LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_CONFIG_MODE);
    }
    else
    {
      /* No action required */
    }

    /* When DISABLE of GWCA is requested, GWCA waits until the processing of
     * all GWCA Descriptors being processed is completed before transitioning to DISBALE.
     * That is, after exiting the above function, all GWCA Descriptors are FEMPTY. */
  }


  if (E_OK == LucResult)
  {
    /* Release all Tx Buffer */
    for (LulCnt = 0UL; LulCnt < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulCnt++)
    {
      if (NULL_PTR != Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulCnt].pBufferHdr)
      {
        Eth_RSW_ReleaseTxBuffer(LulCtrlIdx, Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulCnt].pBufferHdr->ulbufIdx);
      }
      else
      {
        /* No action required */
      }
    }

    /* Release all Tx Descriptor */
    for (LulQIdx = 0UL; LulQIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulQIdx++)
    {
      LpTxDirDesc = (Eth_ExtTxDirDescType *) Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulQIdx];                /* PRQA S 0316 # JV-01 */
      while (LpTxDirDesc != Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LulQIdx])
      {
        /* Clear Tx Descriptor */
        LpTxDirDesc->stHeader.ulDs    = 0U;
        LpTxDirDesc->stHeader.ulInfo0 = 0U;
        LpTxDirDesc->stHeader.ulErr   = 0U;
        LpTxDirDesc->stHeader.ulDse   = 0U;
        LpTxDirDesc->stHeader.ulAxie  = 0U;
        LpTxDirDesc->stHeader.ulDie   = 0U;
        LpTxDirDesc->stHeader.ulDptrH = 0U;
        LpTxDirDesc->stHeader.ulDptr  = 0U;
        LpTxDirDesc->ulTxc = 0U;
        LpTxDirDesc->ulTsun = 0U;
        LpTxDirDesc->stHeader.ulDt    = ETH_DESC_FEMPTY;

        /* Set next descriptor */
        LpTxDirDesc++;
        while (LpTxDirDesc->stHeader.ulDt == ETH_DESC_LINKFIX)
        {
          LpTxDirDesc = (Eth_ExtTxDirDescType *)LpTxDirDesc->stHeader.ulDptr;                                           /* PRQA S 0306 # JV-01 */
        }
      }
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulQIdx] = LpTxDirDesc;
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulQIdx] = 0UL;
    }

    /* Release all Rx Descriptor */
    for (LulQIdx = 0UL; LulQIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LulQIdx++)
    {
      LpRxEthDesc = (Eth_ExtRxEthDescType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextRxDesc[LulQIdx];                 /* PRQA S 0316 # JV-01 */
      while (ETH_DESC_FSINGLE == LpRxEthDesc->stHeader.ulDt)
      {
        /* Clear Rx Descriptor */
        LpRxEthDesc->stHeader.ulDs      = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulQIdx].ulMaxFrameSize;
        LpRxEthDesc->stHeader.ulInfo0   = 0U;
        LpRxEthDesc->stHeader.ulAxie    = 0U;
        LpRxEthDesc->stHeader.ulDse     = 0U;
        LpRxEthDesc->stHeader.ulErr     = 0U;
        #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
          LpRxEthDesc->stTimestamp.ulTSNS = (uint32)0UL;
        LpRxEthDesc->stTimestamp.ulTSV  = 0U;
        LpRxEthDesc->stTimestamp.ulTSD  = 0U;
        LpRxEthDesc->stTimestamp.ulTSS  = 0U;
        #endif /* ETH_GLOBAL_TIME_SUPPORT */
        LpRxEthDesc->stHeader.ulDt      = ETH_DESC_FEMPTY;

        /* Set next descriptor */
        LpRxEthDesc++;
        while (LpRxEthDesc->stHeader.ulDt == ETH_DESC_LINKFIX)
        {
          LpRxEthDesc = (Eth_ExtRxEthDescType *)LpRxEthDesc->stHeader.ulDptr;                                           /* PRQA S 0306 # JV-01 */
        }
      }
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextRxDesc[LulQIdx] = LpRxEthDesc;
    }
  }
  else
  {
    Eth_GaaCtrlStat[LulCtrlIdx].enMode = ETH_MODE_ACTIVE;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwEnableController (RSW3)
**
** Service ID            : N/A
**
** Description           : Changes the state of an RSW3 controller as ACTIVE
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GpCtrlConfigPtr,
**                         Eth_GaaRsw3PortType, Eth_GaaRSW3_RMACRegs,
**                         Eth_GaaRSW3_GWCARegs
**
** Function(s) invoked   : Eth_HwETHA_TasSettingFlow,Eth_HwETHA_TasEnablingFlow,
**                         Eth_HwETHA_ModeTransitionFlow,Eth_HwGWCA_ModeTransitionFlow, Eth_HwRMAC_LinkVerification
**
** Registers Used        : MRMAC0, MRMAC1, GWMAC0, GWMAC1
**
** Reference ID          : ETH_DUD_ACT_3006
** Reference ID          : ETH_DUD_ACT_3006_GBL001, ETH_DUD_ACT_3006_GBL002, ETH_DUD_ACT_3006_GBL003
** Reference ID          : ETH_DUD_ACT_3006_GBL004, ETH_DUD_ACT_3006_GBL005, ETH_DUD_ACT_3006_REG001
** Reference ID          : ETH_DUD_ACT_3006_REG002, ETH_DUD_ACT_3006_REG003, ETH_DUD_ACT_3006_REG004
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwEnableController(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult = E_OK;
  uint32 LulETHAIdx;
  uint32 LulGWCAIdx;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LulETHAIdx = ETH_CONV_PORTID_TO_ETHAID(LpHwUnitConfig->ulEthPortId);                                                /* PRQA S 3469 # JV-01 */

    /* Set MAC address */
    /* MRAMAC0 Set */
    Eth_GaaRSW3_RMACRegs[LulETHAIdx]->ulMRMAC0 =
      Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 >> 16UL;
    /* MRAMAC1 Set */
    Eth_GaaRSW3_RMACRegs[LulETHAIdx]->ulMRMAC1 =
      (Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 << 16UL) | Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulL16;

    #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
    if (ETH_ENABLE == LpHwUnitConfig->stTASConfig.enTasEnable)
    {
      /*TAS setting flow*/
      LucResult = Eth_HwETHA_TasSettingFlow(LulETHAIdx);
      if (E_OK == LucResult)
      {
        /*TAS enabling flow*/
        Eth_HwETHA_TasEnablingFlow(LulETHAIdx);
      }
      else
      {
        /* No action required */
      }
    }
    else
    {
      /* No action required */
    }
    #endif /* ETH_GLOBAL_TIME_SUPPORT */

    if (E_OK == LucResult)                                                                                              /* PRQA S 2991, 2995 # JV-01, JV-01 */
    {
      /* Set EAMC mode to OPERATION */
      LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_DISABLE_MODE);
      if (E_OK == LucResult)
      {
        LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_OPERATION_MODE);
        if (E_OK == LucResult)
        {
          /* Link Verification */
          LucResult = Eth_HwRMAC_LinkVerification(LulETHAIdx);
        } /* else no action required */
      }
      else
      {
        /* No action required */
      }
    }
    else
    {
      /* No action required */
    }
  }
  else /* GWCA */
  {
    LulGWCAIdx = ETH_CONV_PORTID_TO_GWCAID(LpHwUnitConfig->ulEthPortId);                                                /* PRQA S 3383, 3432 # JV-01, JV-01 */

    /* Set MAC address */
    /* GWMAC0 Set */
    Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWMAC0 =
      Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 >> 16UL;
    /* GWMAC1 Set */
    Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWMAC1 =
      (Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 << 16UL) | Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulL16;

    /* Set GWCA mode to OPERATION */
    LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_DISABLE_MODE);
    if (E_OK == LucResult)
    {
      LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_OPERATION_MODE);
    }
    else
    {
      /* No action required */
    }
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwTransmit (RSW3)
**
** Service ID            : N/A
**
** Description           : Initiates a transmission on an RSW3 controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulBufIdx      : index of a tx buffer
**                         LulLenByte     : byte length of a payload
**                         LblConfirmation: Whether TxConfirmation is required when a transmission finished
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortType
**                         Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable
**                         Eth_GaaGWCAValid, Eth_GaaRSW3_GWCARegs
**
** Function(s) invoked   : EthSwt_EthTxFinishedIndication
**                         ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : GWTRCi
**
** Reference ID          : ETH_DUD_ACT_3007
** Reference ID          : ETH_DUD_ACT_3007_CRT001, ETH_DUD_ACT_3007_CRT002, ETH_DUD_ACT_3007_GBL001
** Reference ID          : ETH_DUD_ACT_3007_GBL002, ETH_DUD_ACT_3007_GBL003, ETH_DUD_ACT_3007_GBL004
** Reference ID          : ETH_DUD_ACT_3007_GBL005, ETH_DUD_ACT_3007_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwTransmit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulLenByte, CONST(boolean, AUTOMATIC) LblConfirmation)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtTxDirDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                     /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucReturnValue;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                  /* PRQA S 3432 # JV-01 */
  uint32 LulChainId;
  uint32 LulRegSet;
  uint32 LulRegSetBit;
  uint32 LulGWCAIdx;
  uint8 LucTsunValue;

  LucReturnValue = E_OK;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Get Tx buffer handler */
  LpBufHandlerPtr = Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Set Tx request length */
  LpBufHandlerPtr->ulTxLength = (uint32)ETH_HEADER_SIZE + LulLenByte;                                                   /* PRQA S 3383 # JV-01 */

  /* Set Tx confirmation flag */
  LpBufHandlerPtr->blTxConfirm = LblConfirmation;

  /* Get next free descriptor */
  LpDataDesc = (Eth_ExtTxDirDescType*)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LpBufHandlerPtr->ucTxQueueIdx]; /* PRQA S 0316 # JV-01 */

  if (ETH_DESC_FEMPTY == LpDataDesc->stHeader.ulDt)
  {
#if (ETH_DCACHE == STD_ON)
    /* Data Cache Flush */
    CR7_Flush_DCache_By_Addr((uint32)LpBufHandlerPtr->ulbufAddr,
                             ETH_BUF_LEN_CACHE_ALIGN(LpBufHandlerPtr->ulTxLength));                                     /* PRQA S 3383, 3384, 3432 # JV-01, JV-01, JV-01 */
#endif
    /* build the descriptor */
    LpDataDesc->stHeader.ulInfo0 = 0x0U;
    LpDataDesc->stHeader.ulDs    = LpBufHandlerPtr->ulTxLength;
    LpDataDesc->stHeader.ulDptrH = 0x0U;
    LpDataDesc->stHeader.ulDptr  = LpBufHandlerPtr->ulbufAddr;
    if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
    {
      /* Transmit from ETHA controller, set ETHA indicate bit */
      LucTsunValue = (uint8)((uint8)(LpBufHandlerPtr->ulbufIdx) | (uint8)(1U << ETH_TX_DESCR_TSUN_ETHA_INDICATE_BIT));
      LpDataDesc->ulTsun         = LucTsunValue;
      LpDataDesc->ulDv           = (1UL << LpHwUnitConfig->ulEthPortId);
      LpDataDesc->ulIpv          = LpBufHandlerPtr->ucTxQueueIdx;
    }
    else
    {
      LulGWCAIdx = ETH_CONV_PORTID_TO_GWCAID(LpHwUnitConfig->ulEthPortId);                                              /* PRQA S 3383, 3432 # JV-01, JV-01 */
      /* Transmit from GWCA controller, set GWCA index into Tsun */
      LucTsunValue = (uint8)((uint8)(LpBufHandlerPtr->ulbufIdx) | (uint8)(LulGWCAIdx << ETH_TX_DESCR_TSUN_GWCA_ID_BIT));
      /* Transmit from GWCA controller, clear ETHA indicate bit */
      LucTsunValue = (LucTsunValue & (uint8)(~ETH_TX_DESCR_TSUN_ETHA_INDICATE_MASK));
      LpDataDesc->ulTsun         = LucTsunValue;
    }

    if (ETH_TRUE == LpBufHandlerPtr->blbenableTS)
    {
      LpDataDesc->ulTxc = 0x1U; /* TX Timestamp capture */
      LpDataDesc->ulTn = ETH_GPTP_TIMER_DOMAIN;
    }
    else
    {
      LpDataDesc->ulTxc = 0x0U;
    }

    if (ETH_ENABLE == Eth_GpCtrlConfigPtr[LulCtrlIdx].pEthConfig->enTxInterruptMode)                                    /* PRQA S 3416 # JV-01 */
    {
      LpDataDesc->stHeader.ulDie = 0x1U;
    }
    else
    {
      LpDataDesc->stHeader.ulDie = 0x0U;
    }
    LpDataDesc->stHeader.ulDt    = ETH_DESC_FSINGLE;

    /* Set next descriptor */
    LpDataDesc++;
    while (LpDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX)
    {
      LpDataDesc = (P2VAR(Eth_ExtTxDirDescType, AUTOMATIC, ETH_APPL_DATA)) LpDataDesc->stHeader.ulDptr;                 /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }

    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LpBufHandlerPtr->ucTxQueueIdx] = LpDataDesc;

    ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Increase the number of buffer of current Tx queue */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LpBufHandlerPtr->ucTxQueueIdx]++;                                   /* PRQA S 3383 # JV-01 */

    ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Transmit start request */
    LulChainId = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LpBufHandlerPtr->ucTxQueueIdx].ulChainId;
    LulRegSet = LulChainId / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG;
    LulRegSetBit = LulChainId % ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG;

    if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId]) //TSN-A
    {
        #if(ETH_RSW3_GWCA_TOTAL_CONFIGURED < ETH_RACE_PORT_GWCA_N)
        LulGWCAIdx = Eth_GaaGWCAValid[0];
        Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWTRCi[LulRegSet] = (uint32)(1UL << LulRegSetBit);
        #else
        if(((LpHwUnitConfig->ulFwdVectorId) & ETH_FWD_VECTOR_GWCA0) == ETH_FWD_VECTOR_GWCA0)
        {
          Eth_GaaRSW3_GWCARegs[ETH_RACE_ID_GWCA0]->ulGWTRCi[LulRegSet] = (uint32)(1UL << LulRegSetBit);
        }

        if(((LpHwUnitConfig->ulFwdVectorId) & ETH_FWD_VECTOR_GWCA1) == ETH_FWD_VECTOR_GWCA1)
        {
          Eth_GaaRSW3_GWCARegs[ETH_RACE_ID_GWCA1]->ulGWTRCi[LulRegSet] = (uint32)(1UL << LulRegSetBit);
        }
        #endif
    }
    else //GWCA
    {
      LulGWCAIdx = ETH_CONV_PORTID_TO_GWCAID(LpHwUnitConfig->ulEthPortId);                                              /* PRQA S 3383, 3432 # JV-01, JV-01 */
      Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWTRCi[LulRegSet] = (uint32)(1UL << LulRegSetBit);
    }

    #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
    /* Indication for a finished transmit process for a specific Ethernet frame. */
    /* Since the maximum value of controller index is 4, casting to uint8 does no problem. */
    (void)EthSwt_EthTxFinishedIndication((uint8)LulCtrlIdx, (Eth_BufIdxType)LpBufHandlerPtr->ulbufIdx);
    #endif
  }
  else
  {
    LucReturnValue = E_NOT_OK;
  }

  return LucReturnValue;
}

#if (ETH_CTRL_ENABLE_TX_POLLING == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_HwTxConfirmation (RSW3)
**
** Service ID            : N/A
**
** Description           : Performs transmission processing, notifies the upper layer
**                         of transmission completion and releases the Tx buffer.
**                         This function scans all queues.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_TxConfirmationQueueProcess
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3008
** Reference ID          : ETH_DUD_ACT_3008_GBL001, ETH_DUD_ACT_3008_GBL002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwTxConfirmation(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulQIdx;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Check the status of the tx descriptor */
  for (LulQIdx = 0UL; LulQIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulQIdx++)
  {
    if (Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulQIdx] > 0UL)
    {
      Eth_TxConfirmationQueueProcess(LulCtrlIdx, LulQIdx);
    }
  }
}
#endif /* (ETH_CTRL_ENABLE_TX_POLLING == STD_ON) */

#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwReceive (RSW3)
**
** Service ID            : N/A
**
** Description           : Performs reception processing in polling mode.
**                         When polling mode:
**                           Receive one frame and indicate it EthIf
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulFifoIdx     : Index of a Fifo
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : When polling mode:
**                           ETH_NOT_RECEIVED : there was no received frame
**                           ETH_RECEIVED     : there was one received frame
**                           ETH_RECEIVED_MORE_DATA_AVAILABLE:
**                                 there were more than one received frames
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_RSW_RxQueueProcess
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3009
***********************************************************************************************************************/
FUNC(Eth_RxStatusType, ETH_PRIVATE_CODE) Eth_RSW_HwReceive(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulFifoIdx)
{
  Eth_ExtRxStatusType LenRetValue;

  /* Receive the specified queue */
  do
  {
    LenRetValue = Eth_RSW_RxQueueProcess(LulCtrlIdx, (uint8)LulFifoIdx);
  } while (ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue);
  return (Eth_RxStatusType)LenRetValue;                                                                                 /* PRQA S 4322 # JV-01 */
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwCheckFifoIndex (RSW3)
**
** Service ID            : N/A
**
** Description           : Check the validity of the FIFO index specified
**                         in the Eth_Receive.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulFifoIdx     : the FIFO index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3010
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwCheckFifoIndex(
CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulFifoIdx)
{
  Std_ReturnType LucReturnValue;
  (void)LulCtrlIdx;
  LucReturnValue = E_OK;

  /* Validity check for the FIFO index */
  if (ETH_RXQ_NUM <= LulFifoIdx)
  {
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }

  return LucReturnValue;
}
#endif /* (ETH_CTRL_ENABLE_RX_POLLING == STD_ON) */

#if (ETH_CTRL_ENABLE_MII == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwReadMii (RSW3)
**
** Service ID            : N/A
**
** Description           : Read data from the PHY management interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LucTrcvIdx     : Index of the transceiver on the MII
**                         LucRegIdx      : Index of the transceiver register on the MII
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LusRetData (Read data from PHY)
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortType, Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : Eth_HwRMAC_PhyMdioReadAccessFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3011
** Reference ID          : ETH_DUD_ACT_3011_GBL001, ETH_DUD_ACT_3011_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwReadMii(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx, CONST(uint8, AUTOMATIC) LucRegIdx,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr)                                                             /* PRQA S 3432 # JV-01 */
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LucResult = Eth_HwRMAC_PhyMdioReadAccessFlow(
      ETH_CONV_PORTID_TO_RMACID(LpHwUnitConfig->ulEthPortId), LucTrcvIdx, LucRegIdx, LpRegValPtr);                      /* PRQA S 3469 # JV-01 */
  }
  else
  {
    *LpRegValPtr = (uint16)0x0UL;
    LucResult = E_NOT_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwWriteMii (RSW3)
**
** Service ID            : N/A
**
** Description           : Write data to the PHY management interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LucTrcvIdx     : Index of the transceiver on the MII
**                         LucRegIdx      : Index of the transceiver register on the MII
**                         LusRegVal      : Value to be written into the indexed
**                                          register
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LucResult (E_OK / E_NOT_OK)
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortType, Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : Eth_HwRMAC_PhyMdioWriteAccessFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3012
** Reference ID          : ETH_DUD_ACT_3012_GBL001, ETH_DUD_ACT_3012_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwWriteMii(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
  CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusRegVal)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult = E_NOT_OK;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LucResult = Eth_HwRMAC_PhyMdioWriteAccessFlow(
      ETH_CONV_PORTID_TO_RMACID(LpHwUnitConfig->ulEthPortId), LucTrcvIdx, LucRegIdx, LusRegVal);                        /* PRQA S 3469 # JV-01 */
  }
  else
  {
    /* TODO DET */
  }

  return LucResult;
}
#endif /* (ETH_CTRL_ENABLE_MII == STD_ON) */

#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetCounterValues (RSW3)
**
** Service ID            : N/A
**
** Description           : Get drop frame counts for each error factor
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx: Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpCounterPtr: Drop frame counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_InitCounterValues
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3013
** Reference ID          : ETH_DUD_ACT_3013_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounterPtr)                                                   /* PRQA S 3432 # JV-01 */
{
  CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432, 3678 # JV-01, JV-01 */
    (Eth_CounterType *)&Eth_GaaCtrlStat[LulCtrlIdx].stCounter;

  LpCounterPtr->DropPktBufOverrun = LpCounter->DropPktBufOverrun;
  LpCounterPtr->DropPktCrc        = LpCounter->DropPktCrc;
  LpCounterPtr->UndersizePkt      = LpCounter->UndersizePkt;
  LpCounterPtr->OversizePkt       = LpCounter->OversizePkt;
  LpCounterPtr->AlgnmtErr         = LpCounter->AlgnmtErr;
  LpCounterPtr->SqeTestErr        = LpCounter->SqeTestErr;
  LpCounterPtr->DiscInbdPkt       = LpCounter->DiscInbdPkt;
  LpCounterPtr->ErrInbdPkt        = LpCounter->ErrInbdPkt;
  LpCounterPtr->DiscOtbdPkt       = LpCounter->DiscOtbdPkt;
  LpCounterPtr->ErrOtbdPkt        = LpCounter->ErrOtbdPkt;
  LpCounterPtr->SnglCollPkt       = LpCounter->SnglCollPkt;
  LpCounterPtr->MultCollPkt       = LpCounter->MultCollPkt;
  LpCounterPtr->DfrdPkt           = LpCounter->DfrdPkt;
  LpCounterPtr->LatCollPkt        = LpCounter->LatCollPkt;
  LpCounterPtr->HwDepCtr0         = LpCounter->HwDepCtr0;
  LpCounterPtr->HwDepCtr1         = LpCounter->HwDepCtr1;
  LpCounterPtr->HwDepCtr2         = LpCounter->HwDepCtr2;
  LpCounterPtr->HwDepCtr3         = LpCounter->HwDepCtr3;

  /* Initialize Statistics */
  Eth_InitCounterValues(LulCtrlIdx);
}

/***********************************************************************************************************************
** Function Name         : Eth_InitCounterValues (RSW3)
**
** Service ID            : N/A
**
** Description           : Initialize information that drop frame counts for each error factor
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortType
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3014
** Reference ID          : ETH_DUD_ACT_3014_GBL001, ETH_DUD_ACT_3014_GBL002, ETH_DUD_ACT_3014_GBL003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432 # JV-01 */
    (Eth_CounterType *)&Eth_GaaCtrlStat[LulCtrlIdx].stCounter;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LpCounter->DropPktBufOverrun = 0UL;
    LpCounter->DropPktCrc        = 0UL;
    LpCounter->UndersizePkt      = 0UL;
    LpCounter->OversizePkt       = 0UL;
    LpCounter->AlgnmtErr         = 0UL;
  }
  else
  {
    /* GWCA controller is not supported */
    LpCounter->DropPktBufOverrun = ETH_NOT_AVAILABLE;
    LpCounter->DropPktCrc        = ETH_NOT_AVAILABLE;
    LpCounter->UndersizePkt      = ETH_NOT_AVAILABLE;
    LpCounter->OversizePkt       = ETH_NOT_AVAILABLE;
    LpCounter->AlgnmtErr         = ETH_NOT_AVAILABLE;
  }

  /* not supported parameters */
  LpCounter->SqeTestErr          = ETH_NOT_AVAILABLE;
  LpCounter->DiscInbdPkt         = ETH_NOT_AVAILABLE;
  LpCounter->ErrInbdPkt          = ETH_NOT_AVAILABLE;
  LpCounter->DiscOtbdPkt         = ETH_NOT_AVAILABLE;
  LpCounter->ErrOtbdPkt          = ETH_NOT_AVAILABLE;
  LpCounter->SnglCollPkt         = ETH_NOT_AVAILABLE;
  LpCounter->MultCollPkt         = ETH_NOT_AVAILABLE;
  LpCounter->DfrdPkt             = ETH_NOT_AVAILABLE;
  LpCounter->LatCollPkt          = ETH_NOT_AVAILABLE;
  LpCounter->HwDepCtr0           = ETH_NOT_AVAILABLE;
  LpCounter->HwDepCtr1           = ETH_NOT_AVAILABLE;
  LpCounter->HwDepCtr2           = ETH_NOT_AVAILABLE;
  LpCounter->HwDepCtr3           = ETH_NOT_AVAILABLE;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_CountCounterValues (RSW3)
**
** Service ID            : N/A
**
** Description           : Add count information that drop frame counts for each error factor
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                         LpStats    : Statistics counter register values
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3015
** Reference ID          : ETH_DUD_ACT_3015_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats)                                                  /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432 # JV-01 */
    (Eth_CounterType *)&Eth_GaaCtrlStat[LulCtrlIdx].stCounter;

  /* DropPktBufOverrun: dropped packets due to buffer overrun */
  if ((ETH_UINT32_MAXVALUE - LpCounter->DropPktBufOverrun) >= LpStats->ulMROVFC)
  {
    /* MROVFC : Receive overflow Counter */
    LpCounter->DropPktBufOverrun = ETH_STATISTICS_LIMIT(LpCounter->DropPktBufOverrun + LpStats->ulMROVFC);              /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->DropPktBufOverrun = ETH_STATISTICS_MAXVALUE;
  }

  /* DropPktCrc: dropped packets due to CRC errors */
  if ((ETH_UINT32_MAXVALUE - LpCounter->DropPktCrc) >= LpStats->ulMRFMEFC)
  {
    /* MRFMEFC : RMAC Received FCS/mCRC error frame count */
    LpCounter->DropPktCrc = ETH_STATISTICS_LIMIT(LpCounter->DropPktCrc + LpStats->ulMRFMEFC);                           /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->DropPktCrc = ETH_STATISTICS_MAXVALUE;
  }

  /* UndersizePkt: number of undersize packets which were less than 64 octets long      */
  /* (excluding framing bits, but including FCS octets) and were otherwise well formed. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->UndersizePkt) >= LpStats->ulMRGUEFC)
  {
    /* MRGUEFC : RMAC Received good undersize error frame count */
    LpCounter->UndersizePkt = ETH_STATISTICS_LIMIT(LpCounter->UndersizePkt + LpStats->ulMRGUEFC);                       /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->UndersizePkt = ETH_STATISTICS_MAXVALUE;
  }

  if ((ETH_UINT32_MAXVALUE - LpCounter->UndersizePkt) >= LpStats->ulMRBUEFC)
  {
    /* MRBUEFC : RMAC Received bad undersize error frame count */
    LpCounter->UndersizePkt = ETH_STATISTICS_LIMIT(LpCounter->UndersizePkt + LpStats->ulMRBUEFC);                       /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->UndersizePkt = ETH_STATISTICS_MAXVALUE;
  }

  /* OversizePkt: number of oversize packets which are longer than 1518 octets          */
  /* (excluding framing bits, but including FCS octets) and were otherwise well formed. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->OversizePkt) >= LpStats->ulMRGOEFC)
  {
    /* MRGOEFC : RMAC Received good oversize error frame count */
    LpCounter->OversizePkt = ETH_STATISTICS_LIMIT(LpCounter->OversizePkt + LpStats->ulMRGOEFC);                         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->OversizePkt = ETH_STATISTICS_MAXVALUE;
  }

  if ((ETH_UINT32_MAXVALUE - LpCounter->OversizePkt) >= LpStats->ulMRBOEFC)
  {
    /* MRBOEFC : RMAC Received bad oversize error frame count */
    LpCounter->OversizePkt = ETH_STATISTICS_LIMIT(LpCounter->OversizePkt + LpStats->ulMRBOEFC);                         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->OversizePkt = ETH_STATISTICS_MAXVALUE;
  }

  /* AlgnmtErr: number of alignment errors, i.e. packets which are received and */
  /* are not an integral number of octets in length and do not pass the CRC.    */
  if ((ETH_UINT32_MAXVALUE - LpCounter->AlgnmtErr) >= LpStats->ulMRNEFC)
  {
    /* MRNEFC : RMAC Received nibble error frame count */
    LpCounter->AlgnmtErr = ETH_STATISTICS_LIMIT(LpCounter->AlgnmtErr + LpStats->ulMRNEFC);                              /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->AlgnmtErr = ETH_STATISTICS_MAXVALUE;
  }
}
#endif /* (ETH_GET_COUNTER_VALUES_API == STD_ON) */

#if (ETH_GET_RX_STATS_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetRxStats (RSW3)
**
** Service ID            : N/A
**
** Description           : Get Rx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpRxStats: Rx statistics counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_InitRxStats
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3016
** Reference ID          : ETH_DUD_ACT_3016_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpRxStats)                                                      /* PRQA S 3432 # JV-01 */
{
  CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432, 3678 # JV-01, JV-01 */
    (Eth_RxStatsType *)&Eth_GaaCtrlStat[LulCtrlIdx].stRxStat;

  LpRxStats->RxStatsDropEvents           = LpCounter->RxStatsDropEvents;
  LpRxStats->RxStatsOctets               = LpCounter->RxStatsOctets;
  LpRxStats->RxStatsPkts                 = LpCounter->RxStatsPkts;
  LpRxStats->RxStatsBroadcastPkts        = LpCounter->RxStatsBroadcastPkts;
  LpRxStats->RxStatsMulticastPkts        = LpCounter->RxStatsMulticastPkts;
  LpRxStats->RxStatsCrcAlignErrors       = LpCounter->RxStatsCrcAlignErrors;
  LpRxStats->RxStatsUndersizePkts        = LpCounter->RxStatsUndersizePkts;
  LpRxStats->RxStatsOversizePkts         = LpCounter->RxStatsOversizePkts;
  LpRxStats->RxStatsFragments            = LpCounter->RxStatsFragments;
  LpRxStats->RxStatsJabbers              = LpCounter->RxStatsJabbers;
  LpRxStats->RxStatsCollisions           = LpCounter->RxStatsCollisions;
  LpRxStats->RxStatsPkts64Octets         = LpCounter->RxStatsPkts64Octets;
  LpRxStats->RxStatsPkts65to127Octets    = LpCounter->RxStatsPkts65to127Octets;
  LpRxStats->RxStatsPkts128to255Octets   = LpCounter->RxStatsPkts128to255Octets;
  LpRxStats->RxStatsPkts256to511Octets   = LpCounter->RxStatsPkts256to511Octets;
  LpRxStats->RxStatsPkts512to1023Octets  = LpCounter->RxStatsPkts512to1023Octets;
  LpRxStats->RxStatsPkts1024to1518Octets = LpCounter->RxStatsPkts1024to1518Octets;
  LpRxStats->RxUnicastFrames             = LpCounter->RxUnicastFrames;

  /* Initialize Statistics */
  Eth_InitRxStats(LulCtrlIdx);
}

/***********************************************************************************************************************
** Function Name         : Eth_InitRxStats (RSW3)
**
** Service ID            : N/A
**
** Description           : Initialize Rx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortType
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3017
** Reference ID          : ETH_DUD_ACT_3017_GBL001, ETH_DUD_ACT_3017_GBL002, ETH_DUD_ACT_3017_GBL003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432 # JV-01 */
    (Eth_RxStatsType *)&Eth_GaaCtrlStat[LulCtrlIdx].stRxStat;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LpCounter->RxStatsOctets               = 0UL;
    LpCounter->RxStatsPkts                 = 0UL;
    LpCounter->RxStatsBroadcastPkts        = 0UL;
    LpCounter->RxStatsMulticastPkts        = 0UL;
    LpCounter->RxStatsCrcAlignErrors       = 0UL;
    LpCounter->RxStatsUndersizePkts        = 0UL;
    LpCounter->RxStatsOversizePkts         = 0UL;
    LpCounter->RxStatsFragments            = 0UL;
    LpCounter->RxUnicastFrames             = 0UL;
    LpCounter->RxStatsPkts64Octets         = 0UL;
    LpCounter->RxStatsPkts65to127Octets    = 0UL;
    LpCounter->RxStatsPkts128to255Octets   = 0UL;
    LpCounter->RxStatsPkts256to511Octets   = 0UL;
    LpCounter->RxStatsPkts512to1023Octets  = 0UL;
    LpCounter->RxStatsPkts1024to1518Octets = 0UL;
  }
  else
  {
    /* GWCA controller is not supported */
    LpCounter->RxStatsOctets               = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts                 = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsBroadcastPkts        = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsMulticastPkts        = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsCrcAlignErrors       = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsUndersizePkts        = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsOversizePkts         = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsFragments            = ETH_NOT_AVAILABLE;
    LpCounter->RxUnicastFrames             = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts64Octets         = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts65to127Octets    = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts128to255Octets   = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts256to511Octets   = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts512to1023Octets  = ETH_NOT_AVAILABLE;
    LpCounter->RxStatsPkts1024to1518Octets = ETH_NOT_AVAILABLE;
  }

  /* not supported parameters */
  LpCounter->RxStatsDropEvents           = ETH_NOT_AVAILABLE;
  LpCounter->RxStatsJabbers              = ETH_NOT_AVAILABLE;
  LpCounter->RxStatsCollisions           = ETH_NOT_AVAILABLE;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_CountRxStats (RSW3)
**
** Service ID            : N/A
**
** Description           : Add count Rx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                         LpStats    : Statistics counter register values
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3018
** Reference ID          : ETH_DUD_ACT_3018_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats)                                                  /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432 # JV-01 */
    (Eth_RxStatsType *)&Eth_GaaCtrlStat[LulCtrlIdx].stRxStat;

  /* RxStatsPkts: The total number of packets (including bad packets, broadcast packets,
     and multicast packets) received. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsPkts) >= (LpStats->ulMRGFCE + LpStats->ulMRGFCP))                        /* PRQA S 3383 # JV-01 */
  {
    /* MRFC : RMAC Received fragment count error frame count */
    LpCounter->RxStatsPkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsPkts + (LpStats->ulMRGFCE + LpStats->ulMRGFCP));    /* PRQA S 3383, 3384, 3469 # JV-01, JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsPkts = ETH_STATISTICS_MAXVALUE;
  }

  /* RxStatsBroadcastPkts: The total number of good packets received that were directed to the broadcast address. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsBroadcastPkts) >= LpStats->ulMRBFC)
  {
    /* MRBFC : RMAC Received good broadcast frame counter */
    LpCounter->RxStatsBroadcastPkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsBroadcastPkts + LpStats->ulMRBFC);         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsBroadcastPkts = ETH_STATISTICS_MAXVALUE;
  }

  /* RxStatsMulticastPkts: The total number of good packets received that were directed to a multicast address. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsMulticastPkts) >= LpStats->ulMRMFC)
  {
    /* MRMFC : RMAC Received good multicast frame counter */
    LpCounter->RxStatsMulticastPkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsMulticastPkts + LpStats->ulMRMFC);         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsMulticastPkts = ETH_STATISTICS_MAXVALUE;
  }

  /* RxStatsCrcAlignErrors: The total number of packets received that had a length of bertween 64 and 1518 octets */
  /* that had either a bad Frame Check Sequence (FCS) with an integral number of octets (FCS Error) or            */
  /* a bad FCS with a non-integral number of octets (Alignment Error).                                            */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsCrcAlignErrors) >= LpStats->ulMRFMEFC)
  {
    /* MRFMEFC : RMAC Received FCS/mCRC error frame count */
    LpCounter->RxStatsCrcAlignErrors = ETH_STATISTICS_LIMIT(LpCounter->RxStatsCrcAlignErrors + LpStats->ulMRFMEFC);     /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsCrcAlignErrors = ETH_STATISTICS_MAXVALUE;
  }
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsCrcAlignErrors) >= LpStats->ulMRNEFC)
  {
    /* MRNEFC : RMAC Received nibble error frame count */
    LpCounter->RxStatsCrcAlignErrors = ETH_STATISTICS_LIMIT(LpCounter->RxStatsCrcAlignErrors + LpStats->ulMRNEFC);      /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsCrcAlignErrors = ETH_STATISTICS_MAXVALUE;
  }

  /* RxStatsUndersizePkts: The total number of packets received that were less than 64 octets long */
  /* (excluding framing bits, but including FCS octets) and were otherwise well formed.            */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsUndersizePkts) >= LpStats->ulMRGUEFC)
  {
    /* MRGUEFC : RMAC Received good undersize error frame count */
    LpCounter->RxStatsUndersizePkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsUndersizePkts + LpStats->ulMRGUEFC);       /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsUndersizePkts = ETH_STATISTICS_MAXVALUE;
  }
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsUndersizePkts) >= LpStats->ulMRBUEFC)
  {
    /* MRBUEFC : RMAC Received bad undersize error frame count */
    LpCounter->RxStatsUndersizePkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsUndersizePkts + LpStats->ulMRBUEFC);       /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsUndersizePkts = ETH_STATISTICS_MAXVALUE;
  }

  /* RxStatsOversizePkts: The total number of packets received that were longer than 1518 octets */
  /* (excluding framing bits, but including FCS octets) and were otherwise well formed.          */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsOversizePkts) >= LpStats->ulMRGOEFC)
  {
    /* MRGOEFC : RMAC Received good oversize error frame count */
    LpCounter->RxStatsOversizePkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsOversizePkts + LpStats->ulMRGOEFC);         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsOversizePkts = ETH_STATISTICS_MAXVALUE;
  }

  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsOversizePkts) >= LpStats->ulMRBOEFC)
  {
    /* MRBOEFC : RMAC Received bad oversize error frame count */
    LpCounter->RxStatsOversizePkts = ETH_STATISTICS_LIMIT(LpCounter->RxStatsOversizePkts + LpStats->ulMRBOEFC);         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsOversizePkts = ETH_STATISTICS_MAXVALUE;
  }

  /* RxStatsFragments: The total number of packets received that were less than 64 octets in length                   */
  /* (excluding framing bits but including FCS octets) and had either a bad Frame Check Sequence (FCS)                */
  /* with an integral number of octets (FCS Error) or a bad FCS with a non-integral number of octets (Alignment Error)*/
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxStatsFragments) >= LpStats->ulMRFCEFC)
  {
    /* MRFCEFC : RMAC Received fragment count error frame count */
    LpCounter->RxStatsFragments = ETH_STATISTICS_LIMIT(LpCounter->RxStatsFragments + LpStats->ulMRFCEFC);               /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxStatsFragments = ETH_STATISTICS_MAXVALUE;
  }

  /* RxUnicastFrames: The number of subnetwork-unicast packets delivered to a higher-layer protocol. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->RxUnicastFrames) >= LpStats->ulMRUFC)
  {
    /* MRUFC : RMAC Received good unicast frame counter */
    LpCounter->RxUnicastFrames = ETH_STATISTICS_LIMIT(LpCounter->RxUnicastFrames + LpStats->ulMRUFC);                   /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->RxUnicastFrames = ETH_STATISTICS_MAXVALUE;
  }
}
#endif /* (ETH_GET_RX_STATS_API == STD_ON) */

#if (ETH_GET_TX_STATS_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetTxStats (RSW3)
**
** Service ID            : N/A
**
** Description           : Get Tx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTxStats: Tx statistics counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_InitTxStats
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3019
** Reference ID          : ETH_DUD_ACT_3019_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpTxStats)                 /* PRQA S 3432 # JV-01 */
{
  CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432, 3678 # JV-01, JV-01 */
    (Eth_TxStatsType *)&Eth_GaaCtrlStat[LulCtrlIdx].stTxStat;

  LpTxStats->TxNumberOfOctets = LpCounter->TxNumberOfOctets;
  LpTxStats->TxNUcastPkts     = LpCounter->TxNUcastPkts;
  LpTxStats->TxUniCastPkts    = LpCounter->TxUniCastPkts;

  /* Initialize Statistics */
  Eth_InitTxStats(LulCtrlIdx);
}

/***********************************************************************************************************************
** Function Name         : Eth_InitTxStats (RSW3)
**
** Service ID            : N/A
**
** Description           : Initialize Tx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortType
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3020
** Reference ID          : ETH_DUD_ACT_3020_GBL001, ETH_DUD_ACT_3020_GBL002, ETH_DUD_ACT_3020_GBL003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432 # JV-01 */
    (Eth_TxStatsType *)&Eth_GaaCtrlStat[LulCtrlIdx].stTxStat;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LpCounter->TxNumberOfOctets = 0UL;
    LpCounter->TxNUcastPkts     = 0UL;
    LpCounter->TxUniCastPkts    = 0UL;
  }
  else
  {
    /* GWCA controller is not supported */
    LpCounter->TxNumberOfOctets = ETH_NOT_AVAILABLE;
    LpCounter->TxNUcastPkts     = ETH_NOT_AVAILABLE;
    LpCounter->TxUniCastPkts    = ETH_NOT_AVAILABLE;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_CountTxStats (RSW3)
**
** Service ID            : N/A
**
** Description           : Add count Tx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                         LpStats    : Statistics counter register values
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3021
** Reference ID          : ETH_DUD_ACT_3021_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats)                                                  /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                                     /* PRQA S 3432 # JV-01 */
    (Eth_TxStatsType *)&Eth_GaaCtrlStat[LulCtrlIdx].stTxStat;

  /* TxNumberOfOctets: The total number of octets transmitted out of the interface, including framing characters. */
  if ((0UL < LpStats->ulMTXBCEU) || (0UL < LpStats->ulMTXBCPU))
  {
    /* MTXBCEU : RMAC Transmitted byte counter E-frames upper side */
    /* MTXBCPU : RMAC Transmitted byte counter E-frames lower side */
    LpCounter->TxNumberOfOctets = ETH_STATISTICS_MAXVALUE;
  }
  else
  {
    if ((ETH_UINT32_MAXVALUE - LpCounter->TxNumberOfOctets) >= LpStats->ulMTXBCEL)
    {
      /* MTXBCEL : RMAC Transmitted byte counter P-frames upper side */
      LpCounter->TxNumberOfOctets = ETH_STATISTICS_LIMIT(LpCounter->TxNumberOfOctets + LpStats->ulMTXBCEL);             /* PRQA S 3384, 3469 # JV-01, JV-01 */
    }
    else
    {
      LpCounter->TxNumberOfOctets = ETH_STATISTICS_MAXVALUE;
    }
    if ((ETH_UINT32_MAXVALUE - LpCounter->TxNumberOfOctets) >= LpStats->ulMTXBCPL)
    {
      /* MTXBCPL : RMAC Transmitted byte counter P-frames lower side */
      LpCounter->TxNumberOfOctets = ETH_STATISTICS_LIMIT(LpCounter->TxNumberOfOctets + LpStats->ulMTXBCPL);             /* PRQA S 3384, 3469 # JV-01, JV-01 */
    }
    else
    {
      LpCounter->TxNumberOfOctets = ETH_STATISTICS_MAXVALUE;
    }
  }

  /* TxNUcastPkts: The total number of packets that higher-level protocols requested be transmitted to a non-unicast  */
  /* (i.e., a subnetwork-broadcast or subnetwork-multicast) address, including those that were discarded or not sent. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->TxNUcastPkts) >= LpStats->ulMTBFC)
  {
    /* MTBFC : RMAC Transmitted broadcast frame counter */
    LpCounter->TxNUcastPkts = ETH_STATISTICS_LIMIT(LpCounter->TxNUcastPkts + LpStats->ulMTBFC);                         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->TxNUcastPkts = ETH_STATISTICS_MAXVALUE;
  }

  if ((ETH_UINT32_MAXVALUE - LpCounter->TxNUcastPkts) >= LpStats->ulMTMFC)
  {
    /* MTMFC : RMAC Transmitted multicast frame counter */
    LpCounter->TxNUcastPkts = ETH_STATISTICS_LIMIT(LpCounter->TxNUcastPkts + LpStats->ulMTMFC);                         /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->TxNUcastPkts = ETH_STATISTICS_MAXVALUE;
  }

  /* TxUniCastPkts: The total number of packets that higher-level protocols requested be transmitted */
  /* to a subnetwork-unicast address, including those that were discarded or not sent.               */
  if ((ETH_UINT32_MAXVALUE - LpCounter->TxUniCastPkts) >= LpStats->ulMTUFC)
  {
    /* MTUFC : RMAC Transmitted unicast frame counter */
    LpCounter->TxUniCastPkts = ETH_STATISTICS_LIMIT(LpCounter->TxUniCastPkts + LpStats->ulMTUFC);                       /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->TxUniCastPkts = ETH_STATISTICS_MAXVALUE;
  }
}
#endif /* (ETH_GET_TX_STATS_API == STD_ON) */

#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetTxErrorCounterValues (RSW3)
**
** Service ID            : N/A
**
** Description           : Get error statuses
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx: Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTxErrorCounterValues: Tx error counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_InitTxErrorCounterValues
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3022
** Reference ID          : ETH_DUD_ACT_3022_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwGetTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpTxErrorCounterValues)                            /* PRQA S 3432 # JV-01 */
{
  CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                        /* PRQA S 3432, 3678 # JV-01, JV-01 */
    (Eth_TxErrorCounterValuesType *)&Eth_GaaCtrlStat[LulCtrlIdx].stTxError;

  LpTxErrorCounterValues->TxDroppedNoErrorPkts = LpCounter->TxDroppedNoErrorPkts;
  LpTxErrorCounterValues->TxDroppedErrorPkts   = LpCounter->TxDroppedErrorPkts;
  LpTxErrorCounterValues->TxDeferredTrans      = LpCounter->TxDeferredTrans;
  LpTxErrorCounterValues->TxSingleCollision    = LpCounter->TxSingleCollision;
  LpTxErrorCounterValues->TxMultipleCollision  = LpCounter->TxMultipleCollision;
  LpTxErrorCounterValues->TxLateCollision      = LpCounter->TxLateCollision;
  LpTxErrorCounterValues->TxExcessiveCollison  = LpCounter->TxExcessiveCollison;

  /* Initialize Statistics */
  Eth_InitTxErrorCounterValues(LulCtrlIdx);
}

/***********************************************************************************************************************
** Function Name         : Eth_InitTxErrorCounterValues (RSW3)
**
** Service ID            : N/A
**
** Description           : Initialize error statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRsw3PortType, Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3023
** Reference ID          : ETH_DUD_ACT_3023_GBL001, ETH_DUD_ACT_3023_GBL002, ETH_DUD_ACT_3023_GBL003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_InitTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                        /* PRQA S 3432 # JV-01 */
    (Eth_TxErrorCounterValuesType *)&Eth_GaaCtrlStat[LulCtrlIdx].stTxError;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LpCounter->TxDroppedErrorPkts = 0UL;
  }
  else
  {
    /* GWCA controller is not supported */
    LpCounter->TxDroppedErrorPkts = ETH_NOT_AVAILABLE;
  }

  /* not supported parameters */
  LpCounter->TxDroppedNoErrorPkts = ETH_NOT_AVAILABLE;
  LpCounter->TxDeferredTrans      = ETH_NOT_AVAILABLE;
  LpCounter->TxSingleCollision    = ETH_NOT_AVAILABLE;
  LpCounter->TxMultipleCollision  = ETH_NOT_AVAILABLE;
  LpCounter->TxLateCollision      = ETH_NOT_AVAILABLE;
  LpCounter->TxExcessiveCollison  = ETH_NOT_AVAILABLE;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_CountTxErrorCounterValues (RSW3)
**
** Service ID            : N/A
**
** Description           : Add count error statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                         LpStats    : Statistics counter register values
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3024
** Reference ID          : ETH_DUD_ACT_3024_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwRMAC_CountTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_StatsRegValueType, AUTOMATIC, ETH_APPL_DATA) LpStats)                                                  /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpCounter =                                        /* PRQA S 3432 # JV-01 */
    (Eth_TxErrorCounterValuesType *)&Eth_GaaCtrlStat[LulCtrlIdx].stTxError;

  /* TxDroppedErrorPkts: transmitted because of errors. */
  if ((ETH_UINT32_MAXVALUE - LpCounter->TxDroppedErrorPkts) >= LpStats->ulMTEFC)
  {
    /* MTEFC : RMAC Transmitted error frame counter */
    LpCounter->TxDroppedErrorPkts = ETH_STATISTICS_LIMIT(LpCounter->TxDroppedErrorPkts + LpStats->ulMTEFC);             /* PRQA S 3384, 3469 # JV-01, JV-01 */
  }
  else
  {
    LpCounter->TxDroppedErrorPkts = ETH_STATISTICS_MAXVALUE;
  }
}
#endif /* (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwMainFunction (RSW3)
**
** Service ID            : N/A
**
** Description           : Check receive errors and report DEM if exist
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRSW3_RMACRegs
**                         Eth_GaaRsw3PortType, Eth_GpDemEventRxFramesLost
**                         Eth_GpDemEventCRC, Eth_GpDemEventUnderSizeFrame
**                         Eth_GpDemEventOverSizeFrame, Eth_GpDemEventAlignment
**
** Function(s) invoked   : Eth_HwRMAC_CountCounterValues,Eth_HwRMAC_CountRxStats,
**                         Eth_HwRMAC_CountTxStats,Eth_HwRMAC_CountTxErrorCounterValues,
**                         Eth_DemConfigCheck
**
** Registers Used        : MROVFC
                           MRFMEFC, MRGUEFC, MRBUEFC, MRGOEFC, MRBOEFC, MRNEFC
                           MRFCEFC, MRXBCEU, MRXBCEL, MRXBCPU, MRXBCPL, MRFC
                           MRBFC, MRUFC, MRMFC, MTXBCEU, MTXBCEL, MTXBCPU
                           MTXBCPL, MTBFC, MTMFC, MTUFC, MTEFC, MRPEFC
**
** Reference ID          : ETH_DUD_ACT_3025
** Reference ID          : ETH_DUD_ACT_3025_ERR001, ETH_DUD_ACT_3025_ERR002, ETH_DUD_ACT_3025_ERR003
** Reference ID          : ETH_DUD_ACT_3025_ERR004, ETH_DUD_ACT_3025_ERR005, ETH_DUD_ACT_3025_GBL001
** Reference ID          : ETH_DUD_ACT_3025_GBL002, ETH_DUD_ACT_3025_GBL003, ETH_DUD_ACT_3025_GBL004
** Reference ID          : ETH_DUD_ACT_3025_GBL005, ETH_DUD_ACT_3025_GBL006, ETH_DUD_ACT_3025_GBL007
** Reference ID          : ETH_DUD_ACT_3025_GBL008, ETH_DUD_ACT_3025_REG001, ETH_DUD_ACT_3025_REG002
** Reference ID          : ETH_DUD_ACT_3025_REG003, ETH_DUD_ACT_3025_REG004, ETH_DUD_ACT_3025_REG005
** Reference ID          : ETH_DUD_ACT_3025_REG006, ETH_DUD_ACT_3025_REG007, ETH_DUD_ACT_3025_REG008
** Reference ID          : ETH_DUD_ACT_3025_REG009, ETH_DUD_ACT_3025_REG010, ETH_DUD_ACT_3025_REG011
** Reference ID          : ETH_DUD_ACT_3025_REG012, ETH_DUD_ACT_3025_REG013, ETH_DUD_ACT_3025_REG014
** Reference ID          : ETH_DUD_ACT_3025_REG015, ETH_DUD_ACT_3025_REG016, ETH_DUD_ACT_3025_REG017
** Reference ID          : ETH_DUD_ACT_3025_REG018, ETH_DUD_ACT_3025_REG019, ETH_DUD_ACT_3025_REG020
** Reference ID          : ETH_DUD_ACT_3025_REG021, ETH_DUD_ACT_3025_REG022, ETH_DUD_ACT_3025_REG023
** Reference ID          : ETH_DUD_ACT_3025_REG024, ETH_DUD_ACT_3025_REG025
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_HwMainFunction(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(volatile Eth_RSW3_RMACRegType, AUTOMATIC, REGSPACE) LpRmacsRegs;                                                /* PRQA S 3432, 3678 # JV-01, JV-01 */
  /* Report Extended DEM (if any) */
  Eth_StatsRegValueType LstStats;
  uint32 LulETHAIdx;

  LpHwUnitConfig =
      (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;             /* PRQA S 0316, 3432 # JV-01, JV-01 */

  if (ETH_RSW3_PORT_TYPE_ETHA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
  {
    LulETHAIdx = ETH_CONV_PORTID_TO_ETHAID(LpHwUnitConfig->ulEthPortId);                                                /* PRQA S 3469 # JV-01 */
    LpRmacsRegs = (volatile Eth_RSW3_RMACRegType *)Eth_GaaRSW3_RMACRegs[LulETHAIdx];

    /* Read RMAC counter register (and register clear) */
    #if ((ETH_GET_COUNTER_VALUES_API == STD_ON) || (ETH_GET_RX_STATS_API == STD_ON) || \
         (ETH_GET_TX_STATS_API == STD_ON) || (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON))
    /* These register read for increase statistic counter only */
    LstStats.ulMROVFC  = LpRmacsRegs->ulMROVFC;  /* Receive overflow Counter */
    LstStats.ulMRFCEFC = LpRmacsRegs->ulMRFCEFC; /* RMAC Received fragment count error frame count */
    LstStats.ulMRGFCE  = LpRmacsRegs->ulMRGFCE;  /* RMAC Received good frame count E-frames */
    LstStats.ulMRGFCP  = LpRmacsRegs->ulMRGFCP;  /* RMAC Received good frame count P-frames */
    LstStats.ulMRBFC   = LpRmacsRegs->ulMRBFC;   /* RMAC Received good broadcast frame counter */
    LstStats.ulMRUFC   = LpRmacsRegs->ulMRUFC;   /* RMAC Received good unicast frame counter */
    LstStats.ulMRMFC   = LpRmacsRegs->ulMRMFC;   /* RMAC Received good multicast frame counter */
    LstStats.ulMTXBCEU = LpRmacsRegs->ulMTXBCEU; /* RMAC Transmitted byte counter E-frames upper side */
    LstStats.ulMTXBCEL = LpRmacsRegs->ulMTXBCEL; /* RMAC Transmitted byte counter E-frames lower side */
    LstStats.ulMTXBCPU = LpRmacsRegs->ulMTXBCPU; /* RMAC Transmitted byte counter P-frames upper side */
    LstStats.ulMTXBCPL = LpRmacsRegs->ulMTXBCPL; /* RMAC Transmitted byte counter P-frames lower side */
    LstStats.ulMTBFC   = LpRmacsRegs->ulMTBFC;   /* RMAC Transmitted broadcast frame counter */
    LstStats.ulMTMFC   = LpRmacsRegs->ulMTMFC;   /* RMAC Transmitted multicast frame counter */
    LstStats.ulMTUFC   = LpRmacsRegs->ulMTUFC;   /* RMAC Transmitted unicast frame counter */
    LstStats.ulMTEFC   = LpRmacsRegs->ulMTEFC;   /* RMAC Transmitted error frame counter */
    #endif

    /* These register read for raise DEM Event and increase statistic counter */
    LstStats.ulMRFMEFC = LpRmacsRegs->ulMRFMEFC; /* RMAC Received FCS/mCRC error frame count */
    LstStats.ulMRGUEFC = LpRmacsRegs->ulMRGUEFC; /* RMAC Received good undersize error frame count */
    LstStats.ulMRBUEFC = LpRmacsRegs->ulMRBUEFC; /* RMAC Received bad undersize error frame count */
    LstStats.ulMRGOEFC = LpRmacsRegs->ulMRGOEFC; /* RMAC Received good oversize error frame count */
    LstStats.ulMRBOEFC = LpRmacsRegs->ulMRBOEFC; /* RMAC Received bad oversize error frame count */
    LstStats.ulMRNEFC  = LpRmacsRegs->ulMRNEFC;  /* RMAC Received nibble error frame count */
    LstStats.ulMRPEFC  = LpRmacsRegs->ulMRPEFC;  /* RMAC Received PHY error frame count */

    #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
    /* Add count information that drop frame counts for each error factor */
    Eth_HwRMAC_CountCounterValues(LulCtrlIdx, &LstStats);
    #endif /* (ETH_GET_COUNTER_VALUES_API == STD_ON) */

    #if (ETH_GET_RX_STATS_API == STD_ON)
    /* Add count Rx statistics information */
    Eth_HwRMAC_CountRxStats(LulCtrlIdx, &LstStats);
    #endif /* (ETH_GET_RX_STATS_API == STD_ON) */

    #if (ETH_GET_TX_STATS_API == STD_ON)
    /* Add count Tx statistics information */
    Eth_HwRMAC_CountTxStats(LulCtrlIdx, &LstStats);
    #endif /* (ETH_GET_TX_STATS_API == STD_ON) */

    #if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
    /* Add count error statistics information */
    Eth_HwRMAC_CountTxErrorCounterValues(LulCtrlIdx, &LstStats);
    #endif /* (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON) */

    /* MRPEFC - Received PHY error frame counter */
    if (0UL < LstStats.ulMRPEFC)
    {
      /* Call DEM */
      Eth_DemConfigCheck(Eth_GpDemEventRxFramesLost[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
    }
    else
    {
      /* No action required */
    }

    /* MRFMEFC - Received FCS/mCRC error frame counter */
    if (0UL < LstStats.ulMRFMEFC)
    {
      /* Call DEM */
      Eth_DemConfigCheck(Eth_GpDemEventCRC[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
    }
    else
    {
      /* No action required */
    }

    /* MRGUEFC - Received good undersize error frame counter */
    /* MRBUEFC - Received bad undersize error frame counter */
    if ((0UL < LstStats.ulMRGUEFC) || (0UL < LstStats.ulMRBUEFC))
    {
      /* Call DEM */
      Eth_DemConfigCheck(Eth_GpDemEventUnderSizeFrame[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
    }
    else
    {
      /* No action required */
    }

    /* MRGOEFC - Received good oversize error frame counter */
    /* MRBOEFC - Received bad oversize error frame counter */
    if ((0UL < LstStats.ulMRGOEFC) || (0UL < LstStats.ulMRBOEFC))
    {
      /* Call DEM */
      Eth_DemConfigCheck(Eth_GpDemEventOverSizeFrame[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
    }
    else
    {
      /* No action required */
    }

    /* MRNEFC - Received nibble error frame counter */
    if (0UL < LstStats.ulMRNEFC)
    {
      /* Call DEM */
      Eth_DemConfigCheck(Eth_GpDemEventAlignment[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
    }
    else
    {
      /* No action required */
    }
  }
  else
  {
    /* GWCA controller is not supported */
  }
}

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetCurrentTime
**
** Service ID            : NA
**
** Description           : Return TimeStamp from the HW register
**                         previously started.
**                       : It returns adjusted gPTP timer value
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the HW TimeStamp returned
**                       : LpTimeStampPtr : Current TimeStamp value
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : Eth_HwGPTP_gPTPTimerTReadingFlow
**
** Registers Used        : PTPTMEC
**
** Reference ID          : ETH_DUD_ACT_3026
** Reference ID          : ETH_DUD_ACT_3026_GBL001, ETH_DUD_ACT_3026_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetCurrentTime(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr)                                                   /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;

  /* Remove warning message */
  (void)LulCtrlIdx;

  /* gPTP timer status check */
  if (0UL != (Eth_GpRSW3_GPTPRegs->ulPTPTMEC & ETH_GPTP_TIMER_DOMAIN_MASK))
  {
    *LpTimeQualPtr = VALID;
    LucReturnValue = E_OK;
  }
  else
  {
    *LpTimeQualPtr = INVALID;
    LucReturnValue = E_NOT_OK;
  }

  if (E_OK == LucReturnValue)
  {
    Eth_HwGPTP_gPTPTimerTReadingFlow(
      ETH_GPTP_TIMER_DOMAIN, &LpTimeStampPtr->nanoseconds,
      &LpTimeStampPtr->seconds, &LpTimeStampPtr->secondsHi);
  }
  else
  {
    /* No action required */
  }

  return (LucReturnValue);
}
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetCurrentTimeTuple
**
** Service ID            : NA
**
** Description           : Return TimeStamp from the HW register
**                         previously started.
**                       : It returns adjusted gPTP timer value
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the HW TimeStamp returned
**                       : LpTimeStampPtr : Current TimeStamp value
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : Eth_HwGPTP_gPTPTimerTReadingFlow
**
** Registers Used        : PTPTMEC
**
** Reference ID          : ETH_DUD_ACT_3027
** Reference ID          : ETH_DUD_ACT_3027_GBL001, ETH_DUD_ACT_3027_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetCurrentTimeTuple(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) LpCurrentTimeTuplePtr)                                                 /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;

  /* Remove warning message */
  (void)LulCtrlIdx;

  /* gPTP timer status check */
  if (0UL != (Eth_GpRSW3_GPTPRegs->ulPTPTMEC & ETH_GPTP_TIMER_DOMAIN_MASK))
  {
    LpCurrentTimeTuplePtr->timeQuality = VALID;
    LucReturnValue = E_OK;
  }
  else
  {
    LpCurrentTimeTuplePtr->timeQuality = INVALID;
    LucReturnValue = E_NOT_OK;
  }

  if (E_OK == LucReturnValue)
  {
    Eth_HwGPTP_gPTPTimerTReadingFlow(
      ETH_GPTP_TIMER_DOMAIN, &LpCurrentTimeTuplePtr->timestampClockValue.nanoseconds,
      &LpCurrentTimeTuplePtr->timestampClockValue.seconds, &LpCurrentTimeTuplePtr->timestampClockValue.secondsHi);
  }
  else
  {
    /* No action required */
  }

  return (LucReturnValue);
}
/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetEgressTimeStamp
**
** Service ID            : NA
**
** Description           : Read TimeStamp from a message just transmitted
**                         if tag match with Buf idx
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                       : LulBufIdx      : Index of the message buffer
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the Read TS
**                       : LpTimeStampPtr : Value passed above
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3028
** Reference ID          : ETH_DUD_ACT_3028_CRT001, ETH_DUD_ACT_3028_GBL001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetEgressTimeStamp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx,
  CONSTP2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr)                                                   /* PRQA S 3432 # JV-01 */
{
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                   /* PRQA S 3432, 3678 # JV-01, JV-01 */

  /* Critical section is required to protect updating of enTimeQual from DataIsr0 interrupt
  during getting egress time stamp in buffer. */
  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Initialize pointer to timestamp buffer */
  LpTxBufferNode = (Eth_BufHandlerType *)Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

  *LpTimeQualPtr = LpTxBufferNode->enTimeQual;

  *LpTimeStampPtr = LpTxBufferNode->stTimeStamp;

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  return (E_OK);
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwGetIngressTimeStamp
**
** Service ID            : NA
**
** Description           : Read TimeStamp from a message received and
**                         store in Autosar Format
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LpDataPtr      : Pointer to the message buffer,
**                                          where Application expects ingress time stamping
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the Time Stamp
**                       : LpTimeStampPtr : TS read from the Rx Descriptor.
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variables Used : Eth_GaaRxFrame
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3029
** Reference ID          : ETH_DUD_ACT_3029_GBL001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwGetIngressTimeStamp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpDataPtr,
  CONSTP2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr)                                                   /* PRQA S 3432 # JV-01 */
{
  P2VAR(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpCompPtr;                                                              /* PRQA S 3432, 3678 # JV-01, JV-01 */
  Std_ReturnType LucReturnValue = E_NOT_OK;
  /* Read TimeStamp from the rxframe.Timestamp */
  LpCompPtr = (Eth_DataType *)(Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr + (uint32)ETH_ETHERTYPE_SIZE);                  /* PRQA S 0306, 3383 # JV-01, JV-01 */
  if (LpCompPtr == LpDataPtr)
  {
    LpTimeStampPtr->nanoseconds = Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds;
    LpTimeStampPtr->seconds = Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds;

    /* In RSW3, secondsHi is invalid. */
    /* Table 8-25: Reception ethernet descriptor format INFO and TS field descriptions */
    /*  TSS's Restrictions: The 16-upper bits of the gPTP [PTP] second part are truncated. */
    LpTimeStampPtr->secondsHi = 0;

    /* TimeStamp is valid  */
    *LpTimeQualPtr = VALID;
    LucReturnValue = E_OK;
  }
  else
  {
    LpTimeStampPtr->nanoseconds = 0U;
    LpTimeStampPtr->seconds = 0U;
    LpTimeStampPtr->secondsHi = 0U;
    /* TimeStamp is invalid  */
    *LpTimeQualPtr = INVALID;
  }
  return (LucReturnValue);
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_HwSetIncrementTimeForGptp
**
** Service ID            : NA
**
** Description           : Set a value to PTPTIVCt and issue a load request
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulIncVal      : New increment value for the gPTP timer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - PTPTIVCt update success
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : PTPTIVCt
**
** Reference ID          : ETH_DUD_ACT_3030
** Reference ID          : ETH_DUD_ACT_3030_GBL001, ETH_DUD_ACT_3030_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwSetIncrementTimeForGptp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIncVal)
{
  /* Remove warning message */
  (void)LulCtrlIdx;

  /* R-Switch should use only one gPTP timer domain */
  Eth_GpRSW3_GPTPRegs->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTIVCt= LulIncVal;
  return E_OK;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwSetOffsetTimeForGptp
**
** Service ID            : NA
**
** Description           : Adjust gPTP with an given delta
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                       : LpTimeOffsetPtr: Delta TimeStamp
**
** InOut Parameters      : None
**
** Output Parameters     : E_OK - gPTP Request is completed w/o timeout
**                       : E_NOT_OK - gPTP Request not completed due to timeout
**
** Return parameter      : LucReturnValue - E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit.
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwGPTP_TimerTOffsetSettingFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3031
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_HwSetOffsetTimeForGptp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeOffsetPtr)
{
  /* Remove warning message */
  (void)LulCtrlIdx;

  Eth_HwGPTP_TimerTOffsetSettingFlow(
    ETH_GPTP_TIMER_DOMAIN, LpTimeOffsetPtr->nanoseconds,
    LpTimeOffsetPtr->seconds, LpTimeOffsetPtr->secondsHi);

  return E_OK;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_TsDescConfig
**
** Service ID            : NA
**
** Description           : Create timestamp descriptor chain & lerning descriptor.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTsDescChain, Eth_GpNextTsDesc
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3032
** Reference ID          : ETH_DUD_ACT_3032_GBL001, ETH_DUD_ACT_3032_GBL002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_TsDescConfig(void)
{
  P2VAR(Eth_BasicDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDesc;                                                        /* PRQA S 3432 # JV-01 */
  uint32 LulCnt;

  /* TS descriptor chain setting */
  for (LulCnt = 0UL; LulCnt < ETH_MAX_TS_DESCRIPTOR; LulCnt++)
  {
    /* Set frame empty type */
    Eth_GaaTsDescChain[LulCnt].ulDs    = 0U;
    Eth_GaaTsDescChain[LulCnt].ulInfo0 = 0U;
    Eth_GaaTsDescChain[LulCnt].ulErr   = 0U;
    Eth_GaaTsDescChain[LulCnt].ulDse   = 0U;
    Eth_GaaTsDescChain[LulCnt].ulAxie  = 0U;
    Eth_GaaTsDescChain[LulCnt].ulDie   = 1U;
    Eth_GaaTsDescChain[LulCnt].stTimestamp.ulTSNS    = 0U;
    Eth_GaaTsDescChain[LulCnt].stTimestamp.ulTSS     = 0U;
    Eth_GaaTsDescChain[LulCnt].ulDt    = ETH_DESC_FEMPTY_ND;
  }
  LpLinkDesc = (P2VAR(Eth_BasicDescType, AUTOMATIC, ETH_APPL_DATA))&Eth_GaaTsDescChain[LulCnt];                         /* PRQA S 0310, 3432 # JV-01, JV-01 */
  /* Set link type for cyclic descriptor */
  LpLinkDesc->ulDs    = 0U;
  LpLinkDesc->ulInfo0 = 0U;
  LpLinkDesc->ulErr   = 0U;
  LpLinkDesc->ulDse   = 0U;
  LpLinkDesc->ulAxie  = 0U;
  LpLinkDesc->ulDie   = 0U;
  LpLinkDesc->ulDptrH = 0U;
  LpLinkDesc->ulDptr  = (uint32)&Eth_GaaTsDescChain[0];                                                                 /* PRQA S 0306 # JV-01 */
  LpLinkDesc->ulDt    = ETH_DESC_LINKFIX;

  Eth_GpNextTsDesc = &Eth_GaaTsDescChain[0];
}
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_WaitNanoSec
**
** Service ID            : NA
**
** Description           : Wait for the specified nanosecond.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulNanosec     : Waiting time (nano sec)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3033
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_WaitNanoSec(CONST(uint32, AUTOMATIC) LulNanosec)                                       /* PRQA S 1503 # JV-01 */
{
  CONST(uint32, AUTOMATIC) LulCycle = ETH_NS2HZ(LulNanosec) + 1UL;                                                      /* PRQA S 3383, 3469 # JV-01, JV-01 */
  volatile uint32 LulCount;

  for (LulCount = 0UL; LulCount < LulCycle; LulCount++)                                                                 /* PRQA S 3387, 3416 # JV-01, JV-01 */
  {
    /* No action required */
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_TxRxDescConfig
**
** Service ID            : NA
**
** Description           : Create descriptor chain & lerning descriptor.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - Success in lerning Tx/Rx descriptor.
**                         E_NOT_OK - Faile in lerning Tx/Rx descriptor.
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaCtrlStat,
**                         Eth_GaaLinkFixTable, Eth_GaaRsw3PortType
**                         Eth_GstDescChainMap, Eth_GaaTxDescTable,
**                         Eth_GaaRxDescTable, Eth_GaaRxBufferNodes
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3034
** Reference ID          : ETH_DUD_ACT_3034_GBL001, ETH_DUD_ACT_3034_GBL002, ETH_DUD_ACT_3034_GBL003
** Reference ID          : ETH_DUD_ACT_3034_GBL004, ETH_DUD_ACT_3034_GBL005, ETH_DUD_ACT_3034_GBL006
** Reference ID          : ETH_DUD_ACT_3034_GBL007, ETH_DUD_ACT_3034_GBL008
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RSW_TxRxDescConfig(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtTxDirDescType, AUTOMATIC, ETH_APPL_DATA) LpTxDescChain;                                                  /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA) LpRxDescChain;                                                  /* PRQA S 3432 # JV-01 */
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpRxBuffer;                                                                    /* PRQA S 3432, 3678 # JV-01, JV-01 */
  uint32 LulChainId;
  uint32 LulCntJ;
  uint32 LulCntK;
  uint32 LulRxBufIdx;
  uint8 LucCntI;
  Std_ReturnType LucResult;
  P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDesc;                                                         /* PRQA S 3432 # JV-01 */

  LucResult = E_OK;
  LulCntK = 0;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Create Tx descriptor */
  for (LucCntI = 0U; LucCntI < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucCntI++)
  {
    /* Get Tx descriptor table address */
    LpTxDescChain = &Eth_GaaTxDescTable[LulCtrlIdx][LulCntK];

    /* Move to the correct index with the next queue */
    LulCntK += LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucCntI].ulQueueBufs + ETH_CYCLIC_DESC_NUM;                 /* PRQA S 3383, 3384 # JV-01, JV-01 */

    /* Access to the invalid index of array */
    if (NULL_PTR == LpTxDescChain)
    {
      LucResult = E_NOT_OK;
      break;
    }
    else
    {
      /* No action required */
    }

    /* Store the head Tx descriptor address */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LucCntI] = LpTxDescChain;
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LucCntI] = LpTxDescChain;

    /* Set Tx descriptor chain to LINKFIX table */
    LpLinkDesc = &Eth_GaaLinkFixTable[0];

    /* Get Target Chain Id */
    LulChainId = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucCntI].ulChainId;
    LpLinkDesc[LulChainId].ulDs    = 0U;
    LpLinkDesc[LulChainId].ulInfo0 = 0U;
    LpLinkDesc[LulChainId].ulErr   = 0U;
    LpLinkDesc[LulChainId].ulDse   = 0U;
    LpLinkDesc[LulChainId].ulAxie  = 0U;
    LpLinkDesc[LulChainId].ulDie   = 0U;
    LpLinkDesc[LulChainId].ulDt    = ETH_DESC_LINKFIX;
    LpLinkDesc[LulChainId].ulDptrH = 0U;
    LpLinkDesc[LulChainId].ulDptr = (uint32)LpTxDescChain;                                                              /* PRQA S 0306 # JV-01 */

    /* Set descriptor chain */
    for (LulCntJ = 0UL; LulCntJ < LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucCntI].ulQueueBufs; LulCntJ++)
    {
      /* Set frame empty type */
      LpTxDescChain->stHeader.ulErr = 0U;
      LpTxDescChain->stHeader.ulDse = 0U;
      LpTxDescChain->stHeader.ulAxie = 0U;
      LpTxDescChain->stHeader.ulInfo0 = 0U;
      LpTxDescChain->stHeader.ulDie = 0U;
      /* It will be set only during Transmission at run time */
      LpTxDescChain->stHeader.ulDs = 0U;
      LpTxDescChain->stHeader.ulDptrH = 0U;
      LpTxDescChain->stHeader.ulDptr = 0U;

      if (ETH_RSW3_PORT_TYPE_GWCA == Eth_GaaRsw3PortType[LpHwUnitConfig->ulEthPortId])
      {
        LpTxDescChain->ulFmt = 0U; /* Format Ethernet Descpriter */
      }
      else
      {
        LpTxDescChain->ulFmt = 1U; /* Format Direct Descpriter */
      }
      LpTxDescChain->stHeader.ulDt = ETH_DESC_FEMPTY;

      /* Next data descriptor */
      LpTxDescChain++;
    }
    /* Set link type for cyclic descriptor */
    LpTxDescChain->stHeader.ulDie    = 0U;
    LpTxDescChain->stHeader.ulDptrH  = 0U;
    LpTxDescChain->stHeader.ulDptr   = (uint32)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LucCntI];              /* PRQA S 0326 # JV-01 */
    LpTxDescChain->stHeader.ulInfo0  = 0U;
    LpTxDescChain->stHeader.ulAxie   = 0U;
    LpTxDescChain->stHeader.ulDse    = 0U;
    LpTxDescChain->stHeader.ulErr    = 0U;
    LpTxDescChain->stHeader.ulDt     = ETH_DESC_LINKFIX;
  }

  /* Create Rx descriptor */
  LulCntK = 0;
  LulRxBufIdx = 0;
  for (LucCntI = 0U; (LucCntI < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue) && (E_OK == LucResult); LucCntI++)
  {
    /* Get Rx descriptor table address */
    LpRxDescChain = &Eth_GaaRxDescTable[LulCtrlIdx][LulCntK];

    /* Move to the correct index with the next queue */
    LulCntK += LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCntI].ulQueueBufs + ETH_CYCLIC_DESC_NUM;                 /* PRQA S 3383, 3384 # JV-01, JV-01 */

    if (NULL_PTR == LpRxDescChain)
    {
      LucResult = E_NOT_OK;
      break;
    }
    else
    {
      /* No action required */
    }

    /* Store the head Rx descriptor address */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LucCntI] = LpRxDescChain;
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextRxDesc[LucCntI] = LpRxDescChain;

    /* Set Rx descriptor chain to LINKFIX table */
    LpLinkDesc = &Eth_GaaLinkFixTable[0];

    /* Get Target Chain Id */
    LulChainId = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCntI].ulChainId;
    LpLinkDesc[LulChainId].ulDs    = 0U;
    LpLinkDesc[LulChainId].ulInfo0 = 0U;
    LpLinkDesc[LulChainId].ulErr   = 0U;
    LpLinkDesc[LulChainId].ulDse   = 0U;
    LpLinkDesc[LulChainId].ulAxie  = 0U;
    LpLinkDesc[LulChainId].ulDie   = 0U;
    LpLinkDesc[LulChainId].ulDt    = ETH_DESC_LINKFIX;
    LpLinkDesc[LulChainId].ulDptrH = 0U;
    LpLinkDesc[LulChainId].ulDptr = (uint32)LpRxDescChain;                                                              /* PRQA S 0306 # JV-01 */

    /* Set Rx descriptor chain */
    for (LulCntJ = 0UL; LulCntJ < LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCntI].ulQueueBufs; LulCntJ++)
    {
      /* Get the Rx buffer address base on Queue Id and Buffer Id */
      LpRxBuffer = (uint8 *)Eth_GaaRxBufferNodes[LulCtrlIdx][LulRxBufIdx].ulbufAddr;                                    /* PRQA S 0306 # JV-01 */
      if (NULL_PTR == LpRxBuffer)
      {
        /* Access to the invalid index of array */
        LucResult = E_NOT_OK;
        break;
      }
      else
      {
        /* No action required */
      }

      /* Set frame empty type */
      LpRxDescChain->stHeader.ulErr   = 0U;
      LpRxDescChain->stHeader.ulDse   = 0U;
      LpRxDescChain->stHeader.ulAxie  = 0U;
      LpRxDescChain->stHeader.ulInfo0 = 0U;
      LpRxDescChain->stHeader.ulDs    = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCntI].ulMaxFrameSize;
      LpRxDescChain->stHeader.ulDptrH = 0U;
      LpRxDescChain->stHeader.ulDptr  = (uint32)LpRxBuffer;                                                             /* PRQA S 0306 # JV-01 */

      if (ETH_ENABLE == Eth_GpCtrlConfigPtr[LulCtrlIdx].pEthConfig->enRxInterruptMode)                                  /* PRQA S 3416 # JV-01 */
      {
        LpRxDescChain->stHeader.ulDie = 1U;
      }
      else
      {
        LpRxDescChain->stHeader.ulDie = 0U;
      }
      LpRxDescChain->stHeader.ulDt    = ETH_DESC_FEMPTY;

      /* Hold the Rx descriptor address according to with Rx buffer for future manage */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulRxBufIdx].ulRxDescAddr = (uint32)LpRxDescChain;                               /* PRQA S 0306 # JV-01 */

      /* Next data descriptor */
      LpRxDescChain++;
      /* Increase Rx Buffer index */
      LulRxBufIdx++;                                                                                                    /* PRQA S 3383 # JV-01 */
    }
    /* Set link type for cyclic descriptor */
    LpRxDescChain->stHeader.ulDie   = 0U;
    LpRxDescChain->stHeader.ulDptrH = 0U;
    LpRxDescChain->stHeader.ulDptr  = (uint32)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LucCntI];               /* PRQA S 0326 # JV-01 */
    LpRxDescChain->stHeader.ulInfo0 = 0U;
    LpRxDescChain->stHeader.ulAxie  = 0U;
    LpRxDescChain->stHeader.ulDse   = 0U;
    LpRxDescChain->stHeader.ulErr   = 0U;
    LpRxDescChain->stHeader.ulDt    = ETH_DESC_LINKFIX;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_RxQueueProcess
**
** Service ID            : NA
**
** Description           : Process Receive Queue.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx  - Instance number
**                       : LucFifoIdx - Rx queue index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : When polling mode:
**                           ETH_EXT_NOT_RECEIVED : there was no received frame
**                           ETH_EXT_RECEIVED     : there was one received frame
**                           ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE:
**                                 there were more than one received frames
**                           ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE:
**                                 there was no received, but there are still receive frames.
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr Eth_GaaCtrlStat, Eth_GaaRxDescTable,
**                         Eth_GaaRxBufferNodes, Eth_GaaRxFrame
**
** Function(s) invoked   : Eth_RSW_IsRxFrameValid, EthSwt_EthRxProcessFrame,
**                         Eth_RSW_RxCallEthIf, EthSwt_EthRxFinishedIndication
**
** Registers Used        : TSNS, TSV, TSD, TSS
**
** Reference ID          : ETH_DUD_ACT_3035
** Reference ID          : ETH_DUD_ACT_3035_GBL001, ETH_DUD_ACT_3035_GBL002, ETH_DUD_ACT_3035_GBL003
** Reference ID          : ETH_DUD_ACT_3035_GBL004, ETH_DUD_ACT_3035_GBL005
** Reference ID          : ETH_DUD_ACT_3035_REG001, ETH_DUD_ACT_3035_REG002
** Reference ID          : ETH_DUD_ACT_3035_REG003, ETH_DUD_ACT_3035_REG004
***********************************************************************************************************************/
FUNC(Eth_ExtRxStatusType, ETH_PRIVATE_CODE) Eth_RSW_RxQueueProcess(                                                         /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucFifoIdx)
{
  P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                     /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA) LpTempDesc;                                                     /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode;                                                  /* PRQA S 3432 # JV-01 */
  boolean LblRxFrameValid = ETH_TRUE;
  Eth_ExtRxStatusType LenRetValue;
  Eth_BufIdxType LulBufIdx;

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  boolean LblIsMgmtFrameOnlyPtr;
  uint16 LusLength;
  Std_ReturnType LucReturnValue;
  #endif

  #if (ETH_GET_RX_STATS_API == STD_ON)
  uint32 LulLengthWithFCS;
  #endif

  /* Assign return value*/
  LenRetValue = ETH_EXT_NOT_RECEIVED;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Get descriptor for read */
  LpDataDesc = (Eth_ExtRxEthDescType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextRxDesc[LucFifoIdx];                   /* PRQA S 0316 # JV-01 */
  LpTempDesc = LpDataDesc;

  if (ETH_DESC_FSINGLE == LpDataDesc->stHeader.ulDt)
  {
    /* Set descriptor to be read next */
    LpTempDesc++;
    while (LpTempDesc->stHeader.ulDt == ETH_DESC_LINKFIX)
    {
      LpTempDesc = (P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA))LpTempDesc->stHeader.ulDptr;                  /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }

    /* Get Buffer index infor base on descriptor address
    The index of descriptor is also buffer index as static memory mapping design */
    LulBufIdx = (Eth_BufIdxType)(LpDataDesc - Eth_GaaRxDescTable[LulCtrlIdx]);                                          /* PRQA S 0488 # JV-01 */
    /* Minus the total LINK FIX based on Queue ID (each queue has one LINK FIX) */
    LulBufIdx -= (Eth_BufIdxType)LucFifoIdx;                                                                            /* PRQA S 3384 # JV-01 */
    /* Get the Rx Buffer Node infor */
    LpRxBufferNode = &Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx];

    /* Verify the status of buffer and descriptor mapping */
    if ((LpRxBufferNode->blLockedFlag == ETH_FALSE) && (LpRxBufferNode->ulRxDescAddr == (uint32)LpDataDesc))            /* PRQA S 0306 # JV-01 */
    {
      #if (ETH_DCACHE == STD_ON)
        /* Data Cache Invalidate */
        CR7_Invalidate_DCache_By_Addr((uint32)(LpDataDesc->stHeader.ulDptr),
                                      ETH_BUF_LEN_CACHE_ALIGN(LpDataDesc->stHeader.ulDs));                              /* PRQA S 3383, 3384, 3432 # JV-01, JV-01, JV-01 */
      #endif

      #if (ETH_UPDATE_PHYS_ADDR_FILTER == STD_ON)
      /* check whether received frame is valid or not */
      LblRxFrameValid = Eth_RSW_IsRxFrameValid(LulCtrlIdx, LpDataDesc->stHeader.ulDptr);
      #endif

      if (ETH_TRUE == LblRxFrameValid)
      {
        /* Lock Rx buffer */
        LpRxBufferNode->blLockedFlag = ETH_TRUE;

        /* Set Rx descriptor info */
        Eth_GaaRxFrame[LulCtrlIdx].ulFrameAddr = LpDataDesc->stHeader.ulDptr;
        Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = LpDataDesc->stHeader.ulDptr + ETH_SRC_DST_ADDRESS_SIZE;              /* PRQA S 3383 # JV-01 */
        Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = LpDataDesc->stHeader.ulDs;
        #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
        Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds = LpDataDesc->stTimestamp.ulTSNS;
        Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds     = LpDataDesc->stTimestamp.ulTSS;
        Eth_GaaRxFrame[LulCtrlIdx].enTimeQual              = VALID;
        #endif

        if (ETH_DESC_FSINGLE == LpTempDesc->stHeader.ulDt)
        {
          /* More frames are available */
          LenRetValue = ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE;
        }
        else
        {
          /* Frame valid - Update status */
          LenRetValue = ETH_EXT_RECEIVED;
        }

        #if (ETH_GET_RX_STATS_API == STD_ON)
        LulLengthWithFCS = Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength + ETH_FCS_LENGTH;                                   /* PRQA S 3383 # JV-01 */
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOctets += LulLengthWithFCS;                                         /* PRQA S 3383 # JV-01 */
        if (LulLengthWithFCS <= (uint32)ETH_LENGTH_64B)
        {
          /* Since the receive data size that does not include padding data is set in the receive descriptor,
            frames of 64 or less are collected by the statistical counter. */
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts64Octets++;                                                   /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_127B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts65to127Octets++;                                              /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_255B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts128to255Octets++;                                             /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_511B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts256to511Octets++;                                             /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_1023B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts512to1023Octets++;                                            /* PRQA S 3383 # JV-01 */
        }
        else
        {
          /* When VLAN tag is supported, the maximum data size is 1522. */
          /* The maximum frame size that HW can receive is set to 1522. */
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts1024to1518Octets++;                                           /* PRQA S 3383 # JV-01 */
        }
        #endif

        #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
        LpDataPtr = (P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr;                   /* PRQA S 0306, 3432 # JV-01, JV-01 */
        /* Since the maximum value of buffer size is 1518, casting to uint16 does no problem. */
        LusLength = (uint16)(Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength - ETH_HEADER_SIZE);                               /* PRQA S 3383 # JV-01 */
        LblIsMgmtFrameOnlyPtr = ETH_FALSE;
        /* Since the maximum value of controller index is 4, casting to uint8 does no problem. */
        LucReturnValue = EthSwt_EthRxProcessFrame((uint8)LulCtrlIdx, LulBufIdx, &LpDataPtr,
                                                  &LusLength, &LblIsMgmtFrameOnlyPtr);
        if (E_OK == LucReturnValue)
        {
          Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = (uint32)LpDataPtr;                                                 /* PRQA S 0306 # JV-01 */
          Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = (uint32)(LusLength + ETH_HEADER_SIZE);                             /* PRQA S 3383 # JV-01 */

          if (ETH_FALSE == LblIsMgmtFrameOnlyPtr)
          {
            /* Call EthIf if the Frame Received is valid */
            Eth_RSW_RxCallEthIf(LulCtrlIdx, LucFifoIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
          }
          else
          {
            /* Must not be the Rx processed */
            /* Since the maximum value of controller index is 4, casting to uint8 does no problem. */
            (void)EthSwt_EthRxFinishedIndication((uint8)LulCtrlIdx, LulBufIdx);
          }
        }
        else
        {
          /* Normal operation if E_NOT_OK */
          Eth_RSW_RxCallEthIf(LulCtrlIdx, LucFifoIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
        }
        #else
        /* Call EthIf if the Frame Received is valid */
        Eth_RSW_RxCallEthIf(LulCtrlIdx, LucFifoIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
        #endif
      }
      else
      {
        /* Frame Invalid - E.g. Multicast to be discarded */
        /* No Call of EthIf */
        if (ETH_DESC_FSINGLE == LpTempDesc->stHeader.ulDt)
        {
          /* Not received, but more frames are available */
          LenRetValue = ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE;
        }
        else
        {
          /* No action required */
        }

        /* Internal reset Rx descriptor since invalid frame does not require block Rx buffer */
        LpDataDesc->stHeader.ulDs      = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucFifoIdx].ulMaxFrameSize;
        LpDataDesc->stHeader.ulInfo0   = 0U;
        LpDataDesc->stHeader.ulAxie    = 0U;
        LpDataDesc->stHeader.ulDse     = 0U;
        LpDataDesc->stHeader.ulErr     = 0U;
        #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
        LpDataDesc->stTimestamp.ulTSNS = (uint32)0UL;
        LpDataDesc->stTimestamp.ulTSV  = 0U;
        LpDataDesc->stTimestamp.ulTSD  = 0U;
        LpDataDesc->stTimestamp.ulTSS  = 0U;
        #endif /* ETH_GLOBAL_TIME_SUPPORT */
        LpDataDesc->stHeader.ulDt      = ETH_DESC_FEMPTY;
      }
      /* Assign next descriptor address */
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextRxDesc[LucFifoIdx] = LpTempDesc;
    }
    /* else - The Rx buffer is locked */
  }
  else
  {
    /* No action required */
  }

  return LenRetValue;
}

#if (ETH_UPDATE_PHYS_ADDR_FILTER == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_RSW_IsRxFrameValid
**
** Service ID            : NA
**
** Description           : Compare Mac Address Frame just received with
**                         Broadcast and Controller Mac Address.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controller / Channel Index
**                         LulFrameAddr. The destination address of the Frame just received
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LblPass
**                         True : Frame DA is Broadcast or
**                         matches with the Source Address of this Controller
**                         False : Otherwise
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GstBroadcastAddr, Eth_GaaAddressFilters
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3036
** Reference ID          : ETH_DUD_ACT_3036_GBL001, ETH_DUD_ACT_3036_GBL002, ETH_DUD_ACT_3036_GBL003
***********************************************************************************************************************/
STATIC FUNC(boolean, ETH_PRIVATE_CODE) Eth_RSW_IsRxFrameValid(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulFrameAddr)
{
  Eth_MacAddressType LstDstAddress;
  boolean LblPass;
  uint32 LulFilterIdx;
  uint32 LulRemainBits;

  LblPass = ETH_FALSE;
  ETH_PACK_ADDRESS_FROM_8(((P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))LulFrameAddr), LstDstAddress);                       /* PRQA S 0306, 3432, 3469 # JV-01, JV-01, JV-01 */

  /* Check whether promiscuous mode, broadcast, own unicast, multicast address is not registed */
  if ((ETH_TRUE == Eth_GaaCtrlStat[LulCtrlIdx].blPromiscuous) ||
      (0UL == ETH_COMPARE_MAC(LstDstAddress, Eth_GstBroadcastAddr)) ||                                                  /* PRQA S 3469 # JV-01 */
      (0UL == ETH_COMPARE_MAC(LstDstAddress, Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr)))                                   /* PRQA S 3469 # JV-01 */
  {
    LblPass = ETH_TRUE;
  }
  else
  {
    /* Otherwise, do the filter operation */

    /* To skip empty filters efficiently, copy active bits to the local var */
    LulRemainBits = Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits;
    LulFilterIdx = 0UL;
    /* Loop until any filter hits or pass all active filters */
    while (0UL != LulRemainBits)
    {
      if ((0UL != (LulRemainBits & (1UL << LulFilterIdx))) &&
          (0UL == ETH_COMPARE_MAC(LstDstAddress, Eth_GaaAddressFilters[LulCtrlIdx][LulFilterIdx])))                     /* PRQA S 3469 # JV-01 */
      {
        LblPass = ETH_TRUE;
        break;
      } /* else: No action required */

      /* Clear the compared filter bit */
      LulRemainBits &= ~(1UL << LulFilterIdx);
      LulFilterIdx++;                                                                                                   /* PRQA S 3383 # JV-01 */
    }
  }

  return LblPass;
}
#endif  /* (ETH_UPDATE_PHYS_ADDR_FILTER == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_RSW_RxCallEthIf
**
** Service ID            : NA
**
** Description           : Wrapper for the Callback to the Eth Interface
**                         for each frame received
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controller / Channel Index
**                       : LulQueueIdx - Queue Index
**                       : LpFrame - Address of the Received Frame in URAM
**                       : LulBufIdx - Buffer Index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : NA
**
** Global Variables Used : Eth_GstBroadcastAddr
**
** Function(s) invoked   : Eth_RSW_HwGetIngressTimeStamp
**                         EthIf_RxIndication, EthSwt_EthRxFinishedIndication
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3037
** Reference ID          : ETH_DUD_ACT_3037_GBL001, ETH_DUD_ACT_3037_GBL002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_RxCallEthIf(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulQueueIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpFrame,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx)
{
  boolean LblBroadcast;
  P2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpFrameType;                                                          /* PRQA S 3432 # JV-01 */
  Eth_FrameType LddFrameType;
  Eth_MacAddressType LstMacAddr;
  P2CONST(Eth_EtherFrameType, AUTOMATIC, ETH_APPL_DATA) LstEtherFrame;                                                  /* PRQA S 3432 # JV-01 */
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA)LpTimeTuplePtr;                                                         /* PRQA S 3432 # JV-01 */

  LpTimeTuplePtr = &Eth_GaaTimeTuple[LulCtrlIdx][LulQueueIdx];
  LstEtherFrame = (P2CONST(Eth_EtherFrameType, AUTOMATIC, ETH_APPL_DATA)) LpFrame->ulFrameAddr;                         /* PRQA S 0306, 3432 # JV-01, JV-01 */

  ETH_PACK_ADDRESS_FROM_8(LstEtherFrame->ucDstAddr, LstMacAddr);                                                        /* PRQA S 3469 # JV-01 */

  if (0UL == ETH_COMPARE_MAC(LstMacAddr, Eth_GstBroadcastAddr))                                                         /* PRQA S 3469 # JV-01 */
  {
    LblBroadcast = ETH_TRUE;
  }
  else
  {
    LblBroadcast = ETH_FALSE;
  }

  LpFrameType = (const Eth_DataType *)LpFrame->ulEthTypeAddr;                                                           /* PRQA S 0306 # JV-01 */
  LddFrameType = (Eth_FrameType)((uint32)LpFrameType[0] << ETH_BYTE_BITS);
  LddFrameType |= (Eth_FrameType)LpFrameType[1];

  /* Since the maximum value of Controller Index is 4, casting to uint8 does no problem. */
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_RSW_HwGetIngressTimeStamp((uint8)LulCtrlIdx, LpFrameType + ETH_ETHERTYPE_SIZE,                                    /* PRQA S 0488, 3200 # JV-01, JV-01 */
                              &LpTimeTuplePtr->timeQuality, &LpTimeTuplePtr->timestampClockValue);
  #endif
  EthIf_RxIndication((uint8)LulCtrlIdx, LddFrameType, LblBroadcast, LstEtherFrame->ucSrcAddr,
    LpFrameType + ETH_ETHERTYPE_SIZE, (uint16)(LpFrame->ulFrameLength - ETH_HEADER_SIZE),                               /* PRQA S 0488, 3383 # JV-01, JV-01 */
    LpTimeTuplePtr, LulBufIdx);

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  (void)EthSwt_EthRxFinishedIndication((uint8)LulCtrlIdx, LulBufIdx);
  #endif
}

/***********************************************************************************************************************
** Function Name         : Eth_TxConfirmationQueueProcess (RSW3)
**
** Service ID            : N/A
**
** Description           : Performs transmission processing, notifies the upper layer
**                         of transmission completion and releases the Tx buffer.
**                         This function scans the specified queue.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulQIdx        : Index of a Tx Queue
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable, Eth_GaaTxBufferNodes
**
** Function(s) invoked   : EthIf_TxConfirmation, Eth_RSW_ReleaseTxBuffer
**                         ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3038
** Reference ID          : ETH_DUD_ACT_3038_CRT001, ETH_DUD_ACT_3038_GBL001, ETH_DUD_ACT_3038_GBL002
** Reference ID          : ETH_DUD_ACT_3038_GBL003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_TxConfirmationQueueProcess(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQIdx)
{
  uint32 LulCnt;
  uint32 LulTxCnt;
  uint32 LulBufIdx;
  P2VAR(Eth_ExtTxDirDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                     /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                  /* PRQA S 3432, 3678 # JV-01, JV-01 */

  /* Get on-transmit count */
  LulTxCnt = Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulQIdx];
  LpDataDesc = (Eth_ExtTxDirDescType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulQIdx];                      /* PRQA S 0316 # JV-01 */
  for (LulCnt = 0UL; (LulCnt < LulTxCnt) && (ETH_DESC_FEMPTY == LpDataDesc->stHeader.ulDt); LulCnt++)
  {
    /* Get Tx buffer handler */
    LulBufIdx = (LpDataDesc->ulTsun & ~(ETH_TX_DESCR_TSUN_ETHA_INDICATE_MASK | ETH_TX_DESCR_TSUN_GWCA_ID_MASK));        /* PRQA S 3383 # JV-01 */
    LpBufHandlerPtr = Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

    /* Check whether the transmission confirmation was enabled */
    if (ETH_TRUE == LpBufHandlerPtr->blTxConfirm)
    {
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      if ((ETH_TRUE == LpBufHandlerPtr->blbenableTS) && (INVALID == LpBufHandlerPtr->enTimeQual))
      {
        /* Transmit is complete, but TS doesn't exist yet */
        break;
      }
      else
      {
        /* No action required */
      }
      #endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

      if (ETH_TRUE == Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId)
      {
        /* SWS_Eth_00321 */
        /* Call the callback function */
        /* Since the maximum value of controller index is always less than 255, casting to uint8 does no problem. */
        EthIf_TxConfirmation((uint8)LulCtrlIdx,
                            (Eth_BufIdxType)Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId, E_OK);
      }
      else
      {
        /* Call the callback function */
        /* Since the maximum value of controller index is always less than 255, casting to uint8 does no problem. */
        EthIf_TxConfirmation((uint8)LulCtrlIdx, (Eth_BufIdxType)LpBufHandlerPtr->ulbufIdx, E_OK);
      }
    }
    else
    {
      /* No action required */
    }

    ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Release the tx buffer resource */
    Eth_RSW_ReleaseTxBuffer(LulCtrlIdx, LulBufIdx);

    /* Decrease the number of on-transmission buffer of current Tx queue */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulQIdx]--;                                                         /* PRQA S 3383 # JV-01 */

    ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Clear tx descriptor */
    LpDataDesc->stHeader.ulDs    = 0U;
    LpDataDesc->stHeader.ulInfo0 = 0U;
    LpDataDesc->stHeader.ulErr   = 0U;
    LpDataDesc->stHeader.ulDse   = 0U;
    LpDataDesc->stHeader.ulAxie  = 0U;
    LpDataDesc->stHeader.ulDie   = 0U;
    LpDataDesc->stHeader.ulDptrH = 0U;
    LpDataDesc->stHeader.ulDptr  = 0U;
    LpDataDesc->ulTxc = 0U;
    LpDataDesc->ulTsun = 0U;
    LpDataDesc->stHeader.ulDt    = ETH_DESC_FEMPTY;

    /* Update start descriptor */
    LpDataDesc++;
    while (LpDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX)
    {
      LpDataDesc = (Eth_ExtTxDirDescType *)LpDataDesc->stHeader.ulDptr;                                                 /* PRQA S 0306 # JV-01 */
    }
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulQIdx] = LpDataDesc;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_GetElapsedTimeValue
**
** Service ID            : NA
**
** Description           : This returns the elapsed timeout value of  Os timer
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LusTimeOutCount_Init
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LulTimeOutCount_Elapsed - TickType
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : GetCounterValue
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3039
***********************************************************************************************************************/
STATIC FUNC(TickType, ETH_PRIVATE_CODE) Eth_RSW_GetElapsedTimeValue(
  P2VAR(TickType, AUTOMATIC, ETH_APPL_DATA) LpTimeOutCount)                                                             /* PRQA S 3432 # JV-01 */
{
  TickType LulTimeOutCount_Curr;
  TickType LulTimeOutCount_Elapsed;
  TickType LusTimeOutCount_Init;

  LusTimeOutCount_Init = *LpTimeOutCount;

  LulTimeOutCount_Curr = 0UL;

  /* Get the current tick value from OS Counter */
  (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTimeOutCount_Curr);

  /* Check whether current time out exceeds initial time out value */
  if (LulTimeOutCount_Curr >= LusTimeOutCount_Init)
  {
    /* Get elapsed time out count */
    LulTimeOutCount_Elapsed = LulTimeOutCount_Curr - LusTimeOutCount_Init;                                              /* PRQA S 3383 # JV-01 */
  }
  else
  {
    /* Get elapsed time out count */
    LulTimeOutCount_Elapsed = ((uint32)ETH_OS_COUNTER_MAX_VALUE - LusTimeOutCount_Init) + LulTimeOutCount_Curr;         /* PRQA S 3383 # JV-01 */
  }

  /* Update new time out counter */
  *LpTimeOutCount = LulTimeOutCount_Curr;

  return LulTimeOutCount_Elapsed;
}


#if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON))
/***********************************************************************************************************************
** Function Name         : Eth_HwEnableInterrupt (RSW3)
**
** Service ID            : N/A
**
** Description           : Enable GWCA Interrupt
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Control index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
**                         || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
**
** Global Variable(s)    : Eth_GstDescChainMap, Eth_GaaGWCAValid, Eth_GaaRSW3_GWCARegs
**
** Function(s) invoked   : None
**
** Registers Used        : GWDIEi
**
** Reference ID          : ETH_DUD_ACT_3044
** Reference ID          : ETH_DUD_ACT_3044_GBL001, ETH_DUD_ACT_3044_GBL002, ETH_DUD_ACT_3044_GBL003
** Reference ID          : ETH_DUD_ACT_3044_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwEnableInterrupt(void)
{
  uint32 LulRegVal[ETH_RACE_AXI_CHAIN_N / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG];
  uint32 LulIdx;
  uint8  LucTargetChainId;
  uint32 LulGWCAIdx;
  uint32 lucID;

  /* Init Register Value */
  for (LulIdx = 0UL; LulIdx < (ETH_RACE_AXI_CHAIN_N / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG); LulIdx++)
  {
    LulRegVal[LulIdx] = 0UL;
  }

  /* Set GWDIEi Register Value */
  for (LulIdx = 0UL;  LulIdx < Eth_GstDescChainMap.ulValidChainNum; LulIdx++)
  {
    /* Get Target Chain Id */
    LucTargetChainId = Eth_GstDescChainMap.ucValidChainId[LulIdx];

    if (ETH_ENABLE == Eth_GstDescChainMap.aaChainInfo[LulIdx].enInterrupt)
    {
      LulRegVal[LucTargetChainId / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG] |=
                                                      (1UL << (LucTargetChainId % ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG));
    }
  }

  for (LulIdx = 0; LulIdx < (ETH_RACE_AXI_CHAIN_N / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG); LulIdx++)
  {
    for(lucID = 0; lucID < ETH_RSW3_GWCA_TOTAL_CONFIGURED; lucID++)                                                     /* PRQA S 2877 # JV-01 */
    {
      LulGWCAIdx = Eth_GaaGWCAValid[lucID];
      Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->GWDI[LulIdx].ulGWDIEi = LulRegVal[LulIdx];
    }
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_Gwca_DIS_Common_Isr (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA Data ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : GWCA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
**                         || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
**
** Global Variable(s)    : Eth_GstDescChainMap, Eth_GaaRSW3_GWCARegs,
**                       : Eth_GpDemEventUnintendedIntChk
**
** Function(s) invoked   : Eth_RSW_RxQueueProcess, Eth_TxConfirmationQueueProcess
**                       : Eth_DemConfigCheck
**
** Registers Used        : GWDISi, GWDIEi
**
** Reference ID          : ETH_DUD_ACT_3123
** Reference ID          : ETH_DUD_ACT_3123_ERR001, ETH_DUD_ACT_3123_GBL001, ETH_DUD_ACT_3123_GBL002
** Reference ID          : ETH_DUD_ACT_3123_GBL003, ETH_DUD_ACT_3123_REG001, ETH_DUD_ACT_3123_REG002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Gwca_DIS_Common_Isr(
  CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  Eth_ExtRxStatusType LenRetValue;
  P2CONST(Eth_DescChainInfo, AUTOMATIC, ETH_APPL_DATA) LpChainInfo;                                                     /* PRQA S 3432 # JV-01 */
  uint32 LulRegVal[ETH_RACE_AXI_CHAIN_N / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG];
  uint32 LulIdx;
  uint8 LucTargetChainId;
#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  boolean LblStatusFail;
  boolean LblEnableFail;
  uint32 LulUnintBit;

  LblStatusFail = ETH_TRUE;
  LblEnableFail = ETH_FALSE;
#endif


  for (LulIdx = 0; LulIdx < (ETH_RACE_AXI_CHAIN_N / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG); LulIdx++)
  {
    /* Get GWCA Data Interrupt Status */
    LulRegVal[LulIdx] = Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->GWDI[LulIdx].ulGWDISi;

    /* Clear GWCA Data Interrupt Status */
    Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->GWDI[LulIdx].ulGWDISi = LulRegVal[LulIdx];

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
    /* Unintended Interrupt Check */
    if (0UL != LulRegVal[LulIdx])
    {
      /* Status Check is successful */
      LblStatusFail = ETH_FALSE;

      LulUnintBit = (~(Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->GWDI[LulIdx].ulGWDIEi)) & LulRegVal[LulIdx];
      if (0UL != LulUnintBit)
      {
        /* Enable Check is failed */
        LblEnableFail = ETH_TRUE;

        /* Mask to avoid handling unintended interrupts */
        LulRegVal[LulIdx] &= ~(LulUnintBit);
      }
      else
      {
        /* No Action Required */
      }
    }
    else
    {
      /* No Action Required */
    }
#endif
  }

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  if ((ETH_TRUE == LblStatusFail) || (ETH_TRUE == LblEnableFail))
  {
    /* Issue DEM Error to all Controller */
    for (LulIdx = 0; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventUnintendedIntChk[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }
#endif

  for (LulIdx = 0UL;  LulIdx < Eth_GstDescChainMap.ulValidChainNum; LulIdx++)
  {
    /* Get Target Chain Id */
    LucTargetChainId = Eth_GstDescChainMap.ucValidChainId[LulIdx];

    /* Check the Data Interrupt Status bit for Target Chain */
    if (0UL != (LulRegVal[LucTargetChainId / ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG]
              & (1UL << (LucTargetChainId % ETH_RSW3_GWCA_NUM_OF_CHAIN_PER_REG))))
    {
      LpChainInfo = &Eth_GstDescChainMap.aaChainInfo[LulIdx];

      if (ETH_RX == LpChainInfo->enDir)
      {
        do
        {
          /* Update Descriptor */
          LenRetValue = Eth_RSW_RxQueueProcess(LpChainInfo->ulCtrlIdx, (uint8)LpChainInfo->ulFifoIdx);
        } while ((ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue) ||
                 (ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue));
      }
      else
      {
        /* Tx Confirmation Process */
        Eth_TxConfirmationQueueProcess(LpChainInfo->ulCtrlIdx, (uint8)LpChainInfo->ulFifoIdx);
      }
    }
  }
}
#endif /* ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)) */


#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_Gwca_TSDIS_Common_Isr
**
** Service ID            : NA
**
** Description           : GWCA TS Data ISR
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTsDescChain, Eth_GpNextTsDesc,
**                         Eth_GaaRSW3_GWCARegs, Eth_GpCtrlConfigPtr
**                         Eth_GpDemEventUnintendedIntChk
**
** Function(s) invoked   : Eth_TxConfirmationQueueProcess, Eth_DemConfigCheck
**
** Registers Used        : GWTSDIS, GWTSDIE
**
** Reference ID          : ETH_DUD_ACT_3040
** Reference ID          : ETH_DUD_ACT_3040_ERR001, ETH_DUD_ACT_3040_GBL001, ETH_DUD_ACT_3040_GBL002
** Reference ID          : ETH_DUD_ACT_3040_GBL003, ETH_DUD_ACT_3040_GBL004, ETH_DUD_ACT_3040_GBL005
** Reference ID          : ETH_DUD_ACT_3040_REG001, ETH_DUD_ACT_3040_REG002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Gwca_TSDIS_Common_Isr(CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                   /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_BasicDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDesc;                                                        /* PRQA S 3432, 3678 # JV-01, JV-01 */
  uint32 LulCtrlIdx;
  uint32 LulPortIdx;
  uint32 LulBufIdx;
  uint32 LulReg;
  uint32 LulTsunGWCAId;
  uint32 LulETHAIndicateBit;
  uint8 LucTsunValue;
#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  boolean LblStatusFail;
  boolean LblEnableFail;

  LblStatusFail = ETH_FALSE;
  LblEnableFail = ETH_FALSE;
#endif

  LulReg = Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWTSDIS;

  /* Clear the TS Descriptor Data Interrupt Status bit */
  Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWTSDIS = LulReg;

  if (0UL != (LulReg & (ETH_GPTP_TIMER_DOMAIN_ENABLE << ETH_GPTP_TIMER_DOMAIN)))
  {
#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
    if (0UL == (Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWTSDIE & ETH_GPTP_TIMER_DOMAIN_MASK))
    {
      /* Enable Check is failed */
      LblEnableFail = ETH_TRUE;
    }
    else
#endif
    {
      /* Search timestamp descriptor */
      while (ETH_DESC_FSINGLE == Eth_GpNextTsDesc->ulDt)
      {
        LucTsunValue = Eth_GpNextTsDesc->ulTsun;
        LulBufIdx = (LucTsunValue & ~(ETH_TX_DESCR_TSUN_ETHA_INDICATE_MASK | ETH_TX_DESCR_TSUN_GWCA_ID_MASK));          /* PRQA S 3383 # JV-01 */
        LulETHAIndicateBit = (uint32)(((uint32)LucTsunValue >> ETH_TX_DESCR_TSUN_ETHA_INDICATE_BIT) & 1UL);             /* PRQA S 2985 # JV-01 */
        LulTsunGWCAId = (uint32)(((uint32)LucTsunValue >> ETH_TX_DESCR_TSUN_GWCA_ID_BIT) & 1UL);                        /* PRQA S 2985 # JV-01 */
        /*
         * If descriptor from ETHA (ETHAIndicateBit=1), get port from DPN.
         * If descriptor from GWCA (ETHAIndicateBit=0), get port from bit6 of TSUN.
         */
        LulPortIdx = (((uint32)LulETHAIndicateBit * (uint32)(Eth_GpNextTsDesc->ulDpn)) |                                /* PRQA S 3384 # JV-01 */
                      ((uint32)(1UL - (uint32)LulETHAIndicateBit) * (ETH_CONV_GWCAID_TO_PORTID(LulTsunGWCAId))));       /* PRQA S 3383, 3384, 3432 # JV-01, JV-01, JV-01 */
        LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[LulPortIdx];
        if (NULL_PTR != Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr)
        {
          LpTxBufferNode = (Eth_BufHandlerType *)Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

          /* Read timestamp value to Tx buffer */
          LpTxBufferNode->stTimeStamp.nanoseconds = Eth_GpNextTsDesc->stTimestamp.ulTSNS;
          LpTxBufferNode->stTimeStamp.seconds     = Eth_GpNextTsDesc->stTimestamp.ulTSS;
          LpTxBufferNode->stTimeStamp.secondsHi   = (uint16)0U;

          /* Set timestamp quality information as VALID */
          LpTxBufferNode->enTimeQual = VALID;

          if (ETH_ENABLE == Eth_GpCtrlConfigPtr[LulCtrlIdx].pEthConfig->enTxInterruptMode)                              /* PRQA S 3416 # JV-01 */
          {
            Eth_TxConfirmationQueueProcess(LulCtrlIdx, LpTxBufferNode->ucTxQueueIdx);
          }
        }
        /* Release timestamp descriptor */
        Eth_GpNextTsDesc->ulDs    = 0U;
        Eth_GpNextTsDesc->ulInfo0 = 0U;
        Eth_GpNextTsDesc->ulErr   = 0U;
        Eth_GpNextTsDesc->ulDse   = 0U;
        Eth_GpNextTsDesc->ulAxie  = 0U;
        Eth_GpNextTsDesc->ulDie   = 1U;
        Eth_GpNextTsDesc->stTimestamp.ulTSNS    = 0U;
        Eth_GpNextTsDesc->stTimestamp.ulTSS     = 0U;
        Eth_GpNextTsDesc->ulDt = ETH_DESC_FEMPTY_ND;

        /* Set descriptor to be read next */
        Eth_GpNextTsDesc++;
        while (Eth_GpNextTsDesc->ulDt == ETH_DESC_LINKFIX)
        {
          LpLinkDesc = (P2VAR(Eth_BasicDescType, AUTOMATIC, ETH_APPL_DATA))Eth_GpNextTsDesc;                            /* PRQA S 0310, 3432 # JV-01, JV-01 */
          Eth_GpNextTsDesc = (P2VAR(Eth_TSDescType, AUTOMATIC, ETH_APPL_DATA))LpLinkDesc->ulDptr;                       /* PRQA S 0306, 3432 # JV-01, JV-01 */
        }
      }
    }
  }
  else
  {
#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
    /* Status Check is failed */
    LblStatusFail = ETH_TRUE;
#else
    /* No Action Required */
#endif
  }

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  if ((ETH_TRUE == LblStatusFail) || (ETH_TRUE == LblEnableFail))
  {
    /* Issue DEM Error to all Controller */
    for (LulCtrlIdx = 0; LulCtrlIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulCtrlIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventUnintendedIntChk[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }
#endif
}
#endif /* ETH_GLOBAL_TIME_SUPPORT == STD_ON */

#if ((ETH_GWCA_ERR_ISR == STD_ON) || (ETH_COMA_ERR_ISR == STD_ON) || (ETH_ETHA_ERR_ISR == STD_ON))
/***********************************************************************************************************************
** Function Name         : Eth_HwEnableErrorInterrupt (RSW3)
**
** Service ID            : N/A
**
** Description           : Enable GWCA / COMA / ETHA Error Interrupt
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : void
**
** Preconditions         : (ETH_GWCA_ERR_ISR == STD_ON)
**                         || (ETH_COMA_ERR_ISR == STD_ON)
**                         || (ETH_ETHA_ERR_ISR == STD_ON)
**
** Global Variable(s)    : Eth_GaaRSW3_GWCARegs, Eth_GpRSW3_COMARegs
**                         Eth_GaaRSW3_ETHARegs
**
** Function(s) invoked   : None
**
** Registers Used        : GWEIE0, CAEIE0, EAEIE0
**
** Reference ID          : ETH_DUD_ACT_3041
** Reference ID          : ETH_DUD_ACT_3041_GBL001, ETH_DUD_ACT_3041_GBL002, ETH_DUD_ACT_3041_GBL003
** Reference ID          : ETH_DUD_ACT_3041_REG001, ETH_DUD_ACT_3041_REG002, ETH_DUD_ACT_3041_REG003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwEnableErrorInterrupt(void)
{
  uint32 LulRegVal;

  #if ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON))
  /* Enable GWCA Error Interrupt */
  LulRegVal = ETH_RSW3_GWCA_DMA_ERROR_MASK | ETH_RSW3_GWCA_ECC_ERROR_MASK;
  #if (ETH_GWCA0_ERR_ISR == STD_ON)
  Eth_GaaRSW3_GWCARegs[ETH_RACE_ID_GWCA0]->ulGWEIE0 |= LulRegVal;
  #endif
  #if (ETH_GWCA1_ERR_ISR == STD_ON)
  Eth_GaaRSW3_GWCARegs[ETH_RACE_ID_GWCA1]->ulGWEIE0 |= LulRegVal;
  #endif
  #endif /* ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON)) */

  #if (ETH_COMA_ERR_ISR == STD_ON)
  /* Enable COMA Error Interrupt */
  LulRegVal = ETH_RSW3_COMA_ECC_ERROR_MASK;
  Eth_GpRSW3_COMARegs->ulCAEIE0 |= LulRegVal;
  #endif

  #if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) \
  || (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) \
  || (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) \
  || (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) \
  || (ETH_ETHA12_ERR_ISR == STD_ON))
  /* Enable ETHA Error Interrupt */
  LulRegVal = ETH_RSW3_ETHA_ECC_ERROR_MASK;
  #if (ETH_ETHA0_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA0]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA1_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA1]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA2_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA2]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA3_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA3]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA4_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA4]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA5_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA5]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA6_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA6]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA7_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA7]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA8_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA8]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA9_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA9]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA10_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA10]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA11_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA11]->ulEAEIE0 |= LulRegVal;
  #endif
  #if (ETH_ETHA12_ERR_ISR == STD_ON)
  Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA12]->ulEAEIE0 |= LulRegVal;
  #endif
  #endif /* ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) \
  || (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) \
  || (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) \
  || (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) \
  || (ETH_ETHA12_ERR_ISR == STD_ON)) */
}
#endif /* ((ETH_GWCA_ERR_ISR == STD_ON) || (ETH_COMA_ERR_ISR == STD_ON) || (ETH_ETHA_ERR_ISR == STD_ON)) */

#if ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON))
/***********************************************************************************************************************
** Function Name         : Eth_Gwca_ERR_Common_Isr (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA Error ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : Index of a GWCA
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : void
**
** Preconditions         : (ETH_GWCA0_ERR_ISR == STD_ON)
**                         || (ETH_GWCA1_ERR_ISR == STD_ON)
**
** Global Variable(s)    : Eth_GaaRSW3_GWCARegs, Eth_GpDemEventUnintendedIntChk
**                         Eth_GpDemEventDmaError, Eth_GpDemEventEccError
**
** Function(s) invoked   : Eth_DemConfigCheck
**
** Registers Used        : GWEIS0
**
** Reference ID          : ETH_DUD_ACT_3120
** Reference ID          : ETH_DUD_ACT_3120_ERR001, ETH_DUD_ACT_3120_ERR002, ETH_DUD_ACT_3120_ERR003
** Reference ID          : ETH_DUD_ACT_3120_GBL001, ETH_DUD_ACT_3120_GBL002, ETH_DUD_ACT_3120_GBL003
** Reference ID          : ETH_DUD_ACT_3120_GBL004, ETH_DUD_ACT_3120_REG001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Gwca_ERR_Common_Isr(
  CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  uint32 LulRegVal;
  uint32 LulIdx;

  /* Get GWCA Error Interrupt Status */
  LulRegVal = Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWEIS0;

  /* Clear GWCA Error Interrupt Status */
  Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWEIS0 = LulRegVal;

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  /* Unintended Interrupt Check */
  if (0UL == LulRegVal)
  {
    /* Issue DEM Error to all Controller */
    for (LulIdx = 0; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventUnintendedIntChk[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }
#endif

  /* Check AXI Bus Error */
  if (0UL != (LulRegVal & ETH_RSW3_GWCA_DMA_ERROR_MASK))
  {
    /* Issue DEM Error to all Controller */
    for (LulIdx = 0; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventDmaError[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }

  /* Check ECC Error */
  if (0UL != (LulRegVal & ETH_RSW3_GWCA_ECC_ERROR_MASK))
  {
    /* Issue DEM Error to all Controller */
    for (LulIdx = 0; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }
}
#endif /* ((ETH_GWCA0_ERR_ISR == STD_ON) || (ETH_GWCA1_ERR_ISR == STD_ON)) */

#if (ETH_COMA_ERR_ISR == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_Coma_ERR_Common_Isr (RSW3)
**
** Service ID            : N/A
**
** Description           : COMA Error ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : void
**
** Preconditions         : (ETH_COMA_ERR_ISR == STD_ON)
**
** Global Variable(s)    : Eth_GpRSW3_COMARegs, Eth_GpDemEventUnintendedIntChk
**                         Eth_GpDemEventEccError
**
** Function(s) invoked   : Eth_DemConfigCheck
**
** Registers Used        : CAEIS0
**
** Reference ID          : ETH_DUD_ACT_3122
** Reference ID          : ETH_DUD_ACT_3122_ERR001, ETH_DUD_ACT_3122_ERR002, ETH_DUD_ACT_3122_GBL001
** Reference ID          : ETH_DUD_ACT_3122_GBL002, ETH_DUD_ACT_3122_GBL003, ETH_DUD_ACT_3122_REG001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Coma_ERR_Common_Isr(void)
{
  uint32 LulRegVal;
  uint32 LulIdx;

  /* Get COMA Error Interrupt Status */
  LulRegVal = Eth_GpRSW3_COMARegs->ulCAEIS0;

  /* Clear COMA Error Interrupt Status */
  Eth_GpRSW3_COMARegs->ulCAEIS0 = LulRegVal;

#if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
  /* Unintended Interrupt Check */
  if (0UL == LulRegVal)
  {
    /* Issue DEM Error to all Controller */
    for (LulIdx = 0; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventUnintendedIntChk[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }
#endif

  /* Check ECC Error */
  if (0UL != (LulRegVal & ETH_RSW3_COMA_ECC_ERROR_MASK))
  {
    /* Issue DEM Error to all Controller */
    for (LulIdx = 0; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)
    {
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
  }
  else
  {
    /* No Action Required */
  }
}
#endif /* (ETH_COMA_ERR_ISR == STD_ON) */

#if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) \
|| (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) \
|| (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) \
|| (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) \
|| (ETH_ETHA12_ERR_ISR == STD_ON))
/***********************************************************************************************************************
** Function Name         : Eth_Etha_ERR_Common_Isr (RSW3)
**
** Service ID            : N/A
**
** Description           : ETHA Error ISR
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : Index of a ETHA
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : void
**
** Preconditions         : (ETH_ETHA0_ERR_ISR == STD_ON)
**                         || (ETH_ETHA1_ERR_ISR == STD_ON)
**                         || (ETH_ETHA2_ERR_ISR == STD_ON)
**                         || (ETH_ETHA3_ERR_ISR == STD_ON)
**                         || (ETH_ETHA4_ERR_ISR == STD_ON)
**                         || (ETH_ETHA5_ERR_ISR == STD_ON)
**                         || (ETH_ETHA6_ERR_ISR == STD_ON)
**                         || (ETH_ETHA7_ERR_ISR == STD_ON)
**                         || (ETH_ETHA8_ERR_ISR == STD_ON)
**                         || (ETH_ETHA9_ERR_ISR == STD_ON)
**                         || (ETH_ETHA10_ERR_ISR == STD_ON)
**                         || (ETH_ETHA11_ERR_ISR == STD_ON)
**                         || (ETH_ETHA12_ERR_ISR == STD_ON)
**
** Global Variable(s)    : Eth_GaaRSW3_ETHARegs, Eth_GaaRsw3PortValid
**                         Eth_GaaRsw3PortCtrlIdx, Eth_GpDemEventUnintendedIntChk
**                         Eth_GpDemEventEccError
**
** Function(s) invoked   : Eth_DemConfigCheck
**
** Registers Used        : EAEIS0
**
** Reference ID          : ETH_DUD_ACT_3121
** Reference ID          : ETH_DUD_ACT_3121_ERR001, ETH_DUD_ACT_3121_ERR002, ETH_DUD_ACT_3121_GBL001
** Reference ID          : ETH_DUD_ACT_3121_GBL002, ETH_DUD_ACT_3121_GBL003, ETH_DUD_ACT_3121_GBL004
** Reference ID          : ETH_DUD_ACT_3121_GBL005, ETH_DUD_ACT_3121_REG001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Etha_ERR_Common_Isr(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  uint32 LulRegVal;
  uint32 LulIdx;

  /* Get ETHA Error Interrupt Status */
  LulRegVal = Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAEIS0;
  /* Clear ETHA Error Interrupt Status */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAEIS0 = LulRegVal;
  if (ETH_TRUE == Eth_GaaRsw3PortValid[ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx)])                                          /* PRQA S 3469 # JV-01 */
  {
    LulIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx)];                                             /* PRQA S 3469 # JV-01 */

    #if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
    /* Unintended Interrupt Check */
    if (0UL == LulRegVal)
    {
      /* Issue DEM Error to corresponding Controller */
      Eth_DemConfigCheck(Eth_GpDemEventUnintendedIntChk[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
    else
    {
      /* No Action Required */
    }
    #endif

    /* Check ECC Error */
    if (0UL != (LulRegVal & ETH_RSW3_ETHA_ECC_ERROR_MASK))
    {
      /* Issue DEM Error to corresponding Controller */
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulIdx], DEM_EVENT_STATUS_FAILED);
    }
    else
    {
      /* No Action Required */
    }
  }
  else
  {
    /* No action required */
  }
}
#endif /* ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) \
|| (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) \
|| (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) \
|| (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) \
|| (ETH_ETHA12_ERR_ISR == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : Eth_HwTOP_SwitchInitializationFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : TOP Switch Initialization Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaGWCAValid, Eth_GaaRsw3PortValid
**
** Function(s) invoked   : COMA_SwitchClockEnableFlow,COMA_BufferPoolnitializationFlow,
**                         MFWD_FullSettingFlow,Eth_HwGWCA_InitializationFlow,
**                         Eth_HwGWCA_ModeTransitionFlow,Eth_HwETHA_InitializationFlow,
**                         Eth_HwETHA_ModeTransitionFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3043
** Reference ID          : ETH_DUD_ACT_3043_GBL001, ETH_DUD_ACT_3043_GBL002
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwTOP_SwitchInitializationFlow(void)
{
  Std_ReturnType LucResult;
  uint32 LulPortIdx;
  uint32 LulETHAIdx;
  uint32 LulGWCAIdx;
  uint32 lucID;
  LucResult = E_OK;                                                                                                     /* PRQA S 2982 # JV-01 */

  #if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
  /* Common agent Switch clock enable flow [COMA] */
  COMA_SwitchClockEnableFlow();
  #endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

  /* Common agent Buffer pool initialization flow [COMA] */
  LucResult = COMA_BufferPoolnitializationFlow();

  if (E_OK == LucResult)
  {
    /* Forwarding engine Full setting flow [FWD] */
    MFWD_FullSettingFlow();                                                                                             /* PRQA S 3200 # JV-01 */

    for(lucID = 0; lucID < ETH_RSW3_GWCA_TOTAL_CONFIGURED; lucID++)                                                     /* PRQA S 2877 # JV-01 */
    {
      /* For all agents,  initialization flow [GWCA] */
      LulGWCAIdx = Eth_GaaGWCAValid[lucID];
      LucResult = Eth_HwGWCA_InitializationFlow(LulGWCAIdx);
      if (E_OK == LucResult)
      {
        LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_CONFIG_MODE);
      }
      else
      {
        /* No action required */
      }
    }

    /* For all agents,  initialization flow [ETHA] */
    for (LulPortIdx = 0; (LulPortIdx < ETH_RACE_PORT_TSNA_N) && (E_OK == LucResult); LulPortIdx++)
    {
      if (ETH_TRUE == Eth_GaaRsw3PortValid[LulPortIdx])
      {
        LulETHAIdx = ETH_CONV_PORTID_TO_ETHAID(LulPortIdx);                                                             /* PRQA S 3469 # JV-01 */
        LucResult = Eth_HwETHA_InitializationFlow(LulETHAIdx);

        if (E_OK == LucResult)
        {
          LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_CONFIG_MODE);
        }
        else
        {
          /* No action required */
        }
      }
      else
      {
        /* No action required */
      }
    }
  }
  else
  {
    /* No action required */
  }

  return LucResult;
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : Eth_HwTOP_SwitchResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : TOP Switch Initialization Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwGWCA_ModeTransitionFlow,
**                         Eth_HwETHA_ModeTransitionFlow,
**                         COMA_RSwitchResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3045
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwTOP_SwitchResetFlow(void)
{
  Std_ReturnType LucResult;
  uint32 LulGWCAIdx;
  uint32 LulETHAIdx;
  LucResult = E_OK;

  /* For all Agents, Mode transition flow to DISABLE */
  for (LulGWCAIdx = 0; (LulGWCAIdx < ETH_RACE_PORT_GWCA_N) && (E_OK == LucResult); LulGWCAIdx++)
  {
    LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_DISABLE_MODE);
  }
  for (LulETHAIdx = 0; (LulETHAIdx < ETH_RACE_PORT_TSNA_N) && (E_OK == LucResult); LulETHAIdx++)
  {
    LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_DISABLE_MODE);
  }
  /* Common agent R-Switch reset flow */
  if (E_OK == LucResult)
  {
    COMA_RSwitchResetFlow();
  }

  return LucResult;
}
#endif /* (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION) */

/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_PortISettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Port i  Setting Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortType, Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : None
**
** Registers Used        : FWPC1i
**
** Reference ID          : ETH_DUD_ACT_3046
** Reference ID          : ETH_DUD_ACT_3046_GBL001, ETH_DUD_ACT_3046_GBL002
** Reference ID          : ETH_DUD_ACT_3046_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwMFWD_PortISettingFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx)
{
  uint32 LulRegVal;
  /* Set FWPC1i */

  /* Set FWPC1i */
  if (ETH_RSW3_PORT_TYPE_GWCA == Eth_GaaRsw3PortType[LulPortIdx])
  {
    LulRegVal = Eth_GpRSW3_MFWDRegs->FWPC[LulPortIdx].ulFWPC1i;
    LulRegVal = (LulRegVal & ~ETH_RSW3_MFWD_FWPC1_DDE_DDSL_MASK);
    Eth_GpRSW3_MFWDRegs->FWPC[LulPortIdx].ulFWPC1i =
    (LulRegVal | ETH_RSW3_MFWD_FWPC1_DDE | ETH_RSW3_MFWD_FWPC1_DDSL);
  }
  else
  {
    /* No action required */
  }

  /* Set FWPC2i */
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_Layer3TableResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Layer 3 table reset flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : FWLTHTIM
**
** Reference ID          : ETH_DUD_ACT_3047
** Reference ID          : ETH_DUD_ACT_3047_GBL001, ETH_DUD_ACT_3047_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_Layer3TableResetFlow(void)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;
  /* Set FWLTHTIM.LTHTIOG */
  Eth_GpRSW3_MFWDRegs->ulFWLTHTIM = ETH_RSW3_MFWD_FWLTHTIM_LTHTIOG;
  /* Read FWLTHTIM.LTHTR */
  /* Wait until FWLTHTIM.LTHTR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GpRSW3_MFWDRegs->ulFWLTHTIM & ETH_RSW3_MFWD_FWLTHTIM_LTHTR)
      != ETH_RSW3_MFWD_FWLTHTIM_LTHTR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_MacTableResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD MAC table reset flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : FWMACTIM
**
** Reference ID          : ETH_DUD_ACT_3048
** Reference ID          : ETH_DUD_ACT_3048_GBL001, ETH_DUD_ACT_3048_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_MacTableResetFlow(void)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Set FWMACTIM.MACTIOG */
  Eth_GpRSW3_MFWDRegs->ulFWMACTIM = ETH_RSW3_MFWD_FWMACTIM_MACTIOG;

  /* Read FWMACTIM.MACTR */
  /* Wait until FWMACTIM.MACTR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GpRSW3_MFWDRegs->ulFWMACTIM & ETH_RSW3_MFWD_FWMACTIM_MACTR)
      != ETH_RSW3_MFWD_FWMACTIM_MACTR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_VlanTableResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD VLAN table reset flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : FWVLANTIM
**
** Reference ID          : ETH_DUD_ACT_3049
** Reference ID          : ETH_DUD_ACT_3049_GBL001, ETH_DUD_ACT_3049_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_VlanTableResetFlow(void)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Set FWVLANTIM.VLANTIOG */
  Eth_GpRSW3_MFWDRegs->ulFWVLANTIM = ETH_RSW3_MFWD_FWVLANTIM_VLANTIOG;

  /* Read FWVLANTIM.VLANTR */
  /* Wait until FWVLANTIM.VLANTR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GpRSW3_MFWDRegs->ulFWVLANTIM & ETH_RSW3_MFWD_FWVLANTIM_VLANTR)
      != ETH_RSW3_MFWD_FWVLANTIM_VLANTR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_PortIPortBasedSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Port i Port Based Setting Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulPortIdx : RSW3 port index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortValid, Eth_GaaRsw3PortCtrlIdx,
**                         Eth_GpCtrlConfigPtr, Eth_GpRSW3_MFWDRegs,
**                         Eth_GaaRsw3PortType
**
** Function(s) invoked   : Eth_HwMFWD_PortIPortBasedDisableFlow
**
** Registers Used        : FWPBFCSDCji, FWPBFCi
**
** Reference ID          : ETH_DUD_ACT_3050
** Reference ID          : ETH_DUD_ACT_3050_GBL001, ETH_DUD_ACT_3050_GBL002, ETH_DUD_ACT_3050_GBL003
** Reference ID          : ETH_DUD_ACT_3050_GBL004, ETH_DUD_ACT_3050_GBL005, ETH_DUD_ACT_3050_REG001
** Reference ID          : ETH_DUD_ACT_3050_REG002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwMFWD_PortIPortBasedSettingFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2CONST(uint32, AUTOMATIC, ETH_APPL_DATA) LpCsd;                                                                      /* PRQA S 3432 # JV-01 */
  uint32 LulRegVal;
  uint32 LulIdx;
  uint32 LulCtrlIdx;
  uint32 LulFwdVectorId;

  LpCsd = NULL_PTR;
  LulFwdVectorId = 0x00000000UL;

  if (ETH_TRUE == Eth_GaaRsw3PortValid[LulPortIdx])
  {
    LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[LulPortIdx];
    LpHwUnitConfig = Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;                                                     /* PRQA S 0317 # JV-01 */
    LpCsd = &LpHwUnitConfig->aaFwdCsd[0];
    LulFwdVectorId = LpHwUnitConfig->ulFwdVectorId;
  }
  else
  {
    #if (ETH_BOTHCORE_ENABLE == STD_ON)
      if (ETH_RSW3_BOTH_CORE_PORT_ID == LulPortIdx)
      {
        LpCsd = &Eth_GpBothCoreCfgPtr->aaBothCorePortFwdCsd[0];
        LulFwdVectorId = Eth_GpBothCoreCfgPtr->ulBothCorePortFwdVectorId;
      }
      else
      {
        /* No action required */
      }
    #endif /* ETH_BOTHCORE_ENABLE */
  }

  /* This function needs to be reexamined when supporting multi-queue */

  /* Port i port-based disable flow*/
  Eth_HwMFWD_PortIPortBasedDisableFlow(LulPortIdx);

  /* Set FWPBFCSDCi Set CPU sub destinations */
  if (NULL_PTR != LpCsd)
  {
    /* Forwarding using FWPBFCSDCi applies */
    for (LulIdx = 0; LulIdx < ETH_RACE_PORT_GWCA_N; LulIdx++)
    {
      Eth_GpRSW3_MFWDRegs->ulFWPBFCSDCji[LulPortIdx][LulIdx] = LpCsd[LulIdx];
    }
  }
  else
  {
    /* No action required */
  }

  /* Set FWPBFCi */
  if (0x00000000UL != LulFwdVectorId)
  {
    LulRegVal = Eth_GpRSW3_MFWDRegs->FWPBF[LulPortIdx].ulFWPBFC0i;
    Eth_GpRSW3_MFWDRegs->FWPBF[LulPortIdx].ulFWPBFC0i = LulRegVal | LulFwdVectorId;
  }
  else
  {
    /* No action required */
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_PortIPortBasedDisableFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Port l Port Based Disable Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulPortIdx : RSW3 port index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : None
**
** Registers Used        : FWPBFCi
**
** Reference ID          : ETH_DUD_ACT_3051
** Reference ID          : ETH_DUD_ACT_3051_GBL001, ETH_DUD_ACT_3051_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwMFWD_PortIPortBasedDisableFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx)
{
  uint32 LulRegVal;

  LulRegVal = Eth_GpRSW3_MFWDRegs->FWPBF[LulPortIdx].ulFWPBFC0i;
  Eth_GpRSW3_MFWDRegs->FWPBF[LulPortIdx].ulFWPBFC0i = LulRegVal & ~ETH_RACE_PORT_ALL;
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_Layer2Layer3UpdateTableResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Layer 2/Layer 3 update table reset flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : FWL23UTIM
**
** Reference ID          : ETH_DUD_ACT_3052
** Reference ID          : ETH_DUD_ACT_3052_GBL001, ETH_DUD_ACT_3052_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_Layer2Layer3UpdateTableResetFlow(void)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Set FWL23UTIM.L23UTIOG */
  Eth_GpRSW3_MFWDRegs->ulFWL23UTIM = ETH_RSW3_MFWD_FWL23UTIM_L23UTIOG;

  /* Read FWL23UTIM.L23UTR */
  /* Wait until FWL23UTIM.L23UTR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GpRSW3_MFWDRegs->ulFWL23UTIM & ETH_RSW3_MFWD_FWL23UTIM_L23UTR)
      != ETH_RSW3_MFWD_FWL23UTIM_L23UTR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwMFWD_GateRamResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Gate Ram Reset Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_MFWDRegs
**
** Function(s) invoked   : Eth_RSW_GetElapsedTimeValue,
**                         GetCounterValue
**
** Registers Used        : FWPGFRIM
**
** Reference ID          : ETH_DUD_ACT_3053
** Reference ID          : ETH_DUD_ACT_3053_GBL001, ETH_DUD_ACT_3053_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwMFWD_GateRamResetFlow(void)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Set FWPGFRIM.GFRIOG */
  Eth_GpRSW3_MFWDRegs->ulFWPGFRIM = ETH_RSW3_MFWD_FWPGFRIM_GFRIOG;

  /* Read FWPGFRIM.GFRR */
  /* Wait until FWPGFRIM.GFRR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GpRSW3_MFWDRegs->ulFWPGFRIM & ETH_RSW3_MFWD_FWPGFRIM_GFRR)
      != ETH_RSW3_MFWD_FWPGFRIM_GFRR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

/***********************************************************************************************************************
** Function Name         : Eth_HwGWCA_ModeTransitionFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA Mode Transition Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : GWCA index
**                         LenMode    : new mode
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_GWCARegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue,
**                         COMA_AgentIClockStatusCheckFlow,
**                         COMA_AgentIClockEnableFlow,
**                         COMA_AgentIClockDisableFlow
**
** Registers Used        : GWMC, GWMS
**
** Reference ID          : ETH_DUD_ACT_3054
** Reference ID          : ETH_DUD_ACT_3054_GBL001, ETH_DUD_ACT_3054_REG001, ETH_DUD_ACT_3054_REG002
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_ModeTransitionFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx,
  CONST(uint32, AUTOMATIC) LenMode)
{
  Std_ReturnType LucResult = E_OK;
  boolean LblClockEnabled;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Agent i clock status check */
  LblClockEnabled = COMA_AgentIClockStatusCheckFlow(ETH_CONV_GWCAID_TO_PORTID(LulGWCAIdx));                             /* PRQA S 3383, 3432 # JV-01, JV-01 */

  /* TSNA clock enabled? */
  if (ETH_FALSE == LblClockEnabled)
  {
    /* Agent i clock enable flow */
    COMA_AgentIClockEnableFlow(ETH_CONV_GWCAID_TO_PORTID(LulGWCAIdx));                                                  /* PRQA S 3383, 3432 # JV-01, JV-01 */
  }
  /* Set GWMC.OPC */
  Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWMC = LenMode;

  /* Read GWMS.OPS */
  /* Wait until GWMS.OPS returns to "new mode" */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWMS & ETH_RSW3_GWCA_GWMS_OPS_MASK) != LenMode)
      && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  /* Next_mode = DISABLE? */
  if (ETH_RSW3_GWCA_DISABLE_MODE == LenMode)
  {
    /* Agent i clock disable flow [COMA] */
    COMA_AgentIClockDisableFlow(ETH_CONV_GWCAID_TO_PORTID(LulGWCAIdx));                                                 /* PRQA S 3383, 3432 # JV-01, JV-01 */
  }
  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwGWCA_InitializationFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA Initialization Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : GWCA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwGWCA_ModeTransitionFlow
**                         GWCA_FullSettingFlow
**                         Eth_HwGWCA_MulticastTableResetFlow
**                         Eth_HwGWCA_AxiRamResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3055
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_InitializationFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  Std_ReturnType LucResult;

  /* Mode transition flow to DISABLE mode */
  LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_DISABLE_MODE);

  if (E_OK == LucResult)
  {
    /* Mode transition flow to CONFIG mode */
    LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_CONFIG_MODE);

    if (E_OK == LucResult)
    {
      /* Multicast table reset flow */
      LucResult = Eth_HwGWCA_MulticastTableResetFlow(LulGWCAIdx);
      /* AXI RAM reset flow */
      if (E_OK == LucResult)
      {
        LucResult = Eth_HwGWCA_AxiRamResetFlow(LulGWCAIdx);
        if (E_OK == LucResult)
        {
          /* Full setting flow */
          LucResult = GWCA_FullSettingFlow(LulGWCAIdx);
          if (E_OK == LucResult)
          {
            /* Mode transition flow to DISABLE mode */
            LucResult = Eth_HwGWCA_ModeTransitionFlow(LulGWCAIdx, ETH_RSW3_GWCA_DISABLE_MODE);
          }
          else
          {
            /* No action required */
          }
        }
        else
        {
          /* No action required */
        }
      }
      else
      {
        /* No action required */
      }
    }
    else
    {
      /* No action required */
    }
  }
  else
  {
    /* No action required */
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwGWCA_MulticastTableResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA Multicast Table Reset Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : GWCA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_GWCARegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : GWMTIRM
**
** Reference ID          : ETH_DUD_ACT_3056
** Reference ID          : ETH_DUD_ACT_3056_GBL001, ETH_DUD_ACT_3056_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_MulticastTableResetFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* GWMTIRM.MTIOG Set */
  Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWMTIRM = ETH_RSW3_GWCA_GWMTIRM_MTIOG;

  /* Read GWMTIRM.MTR */
  /* Wait until GWMTIRM.MTR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWMTIRM & ETH_RSW3_GWCA_GWMTIRM_MTR)
      != ETH_RSW3_GWCA_GWMTIRM_MTR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwGWCA_AxiRamResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA AXI RAM reset Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : GWCA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_GWCARegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : GWARIRM
**
** Reference ID          : ETH_DUD_ACT_3057
** Reference ID          : ETH_DUD_ACT_3057_GBL001, ETH_DUD_ACT_3057_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwGWCA_AxiRamResetFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* GWARIRM.ARIOG Set */
  Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWARIRM = ETH_RSW3_GWCA_GWARIRM_ARIOG;

  /* Read GWARIRM.ARR */
  /* Wait until GWARIRM.ARR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_GWCARegs[LulGWCAIdx]->ulGWARIRM & ETH_RSW3_GWCA_GWARIRM_ARR)
      != ETH_RSW3_GWCA_GWARIRM_ARR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_ModeTransitionFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : ETHA Mode Transition Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**                         LenMode    : new mode
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_ETHARegs, Eth_GaaRSW3_RMACRegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue,
**                         COMA_AgentIClockStatusCheckFlow,
**                         COMA_AgentIClockEnableFlow,
**                         COMA_AgentIClockDisableFlow
**
** Registers Used        : EAMC, EAMS
**
** Reference ID          : ETH_DUD_ACT_3058
** Reference ID          : ETH_DUD_ACT_3058_GBL001, ETH_DUD_ACT_3058_GBL002
** Reference ID          : ETH_DUD_ACT_3058_REG001, ETH_DUD_ACT_3058_REG002, ETH_DUD_ACT_3058_REG003
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_ModeTransitionFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx,
  CONST(uint32, AUTOMATIC) LenMode)
{
  Std_ReturnType LucResult = E_OK;
  boolean LblClockEnabled;
  boolean LblXGMIIControl = ETH_FALSE;
  uint32 LulCtrlIdx;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Agent i clock status check [COMA] */
  LblClockEnabled = COMA_AgentIClockStatusCheckFlow(ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx));                             /* PRQA S 3469 # JV-01 */
  /* TSNA clock enabled? */
  if (ETH_FALSE == LblClockEnabled)
  {
    /* Agent i clock enable flow [COMA] */
    COMA_AgentIClockEnableFlow(ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx));                                                  /* PRQA S 3469 # JV-01 */
  }

  /* if the interface is other than USXGMII, to ignore FAULTs caused by disconnected external devices,
   * write 3'b100 to MXGMIIC register before changing ETHA from OPERATION to DISABLE. */
  LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx)];                                           /* PRQA S 3469 # JV-01 */
  if ((ETH_USXGMII != Eth_GpEthConfigPtr[LulCtrlIdx].enEthPHYInterface) &&                                              /* PRQA S 3416 # JV-01 */
       (ETH_RSW3_ETHA_OPERATION_MODE == (Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAMS & ETH_RSW3_ETHA_EAMS_OPS_MASK)) &&
       (ETH_RSW3_ETHA_DISABLE_MODE == LenMode))
  {
    Eth_GaaRSW3_RMACRegs[LulETHAIdx]->ulMXGMIIC =
        (Eth_GaaRSW3_RMACRegs[LulETHAIdx]->ulMXGMIIC & ~ETH_RSW3_RMAC_MXGMIIC_RXBFM_MASK) |
         ETH_RSW3_RMAC_MXGMIIC_RXBFM_FORCE_IDLE;
    LblXGMIIControl = ETH_TRUE;
  } /* else do nothing */

  /* Set EAMC.OPC */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAMC = LenMode;

  /* Read EAMS.OPS */
  /* Wait until EAMS.OPS is "new mode" */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAMS & ETH_RSW3_ETHA_EAMS_OPS_MASK) != LenMode)
      && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  /* Next_mode = DISABLE? */
  if (ETH_RSW3_ETHA_DISABLE_MODE == LenMode)
  {
    /* if the interface is other than USXGMII, to ignore FAULTs caused by disconnected external devices,
     * after changing ETHA from OPERATION to DISABLE, write 3'b000 to MXGMIIC register. */
    if(ETH_TRUE == LblXGMIIControl)
    {
      Eth_GaaRSW3_RMACRegs[LulETHAIdx]->ulMXGMIIC &= ~ETH_RSW3_RMAC_MXGMIIC_RXBFM_MASK;
    }

    /* Agent i clock disable flow [COMA] */
    COMA_AgentIClockDisableFlow(ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx));                                                 /* PRQA S 3469 # JV-01 */
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_InitializationFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : ETHA Initialization Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwETHA_ModeTransitionFlow
**                         ETHA_FullSettingFlow
**                         RMAC_InitializationFlow
**                         Eth_HwETHA_TasRamResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3059
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_InitializationFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  Std_ReturnType LucResult;

  /* Mode transition flow to DISABLE mode */
  LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_DISABLE_MODE);

  if (E_OK == LucResult)
  {
    /* Mode transition flow to CONFIG mode */
    LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_CONFIG_MODE);

    if (E_OK == LucResult)
    {
      /* TAS RAM reset flow */
      LucResult = Eth_HwETHA_TasRamResetFlow(LulETHAIdx);
      if (E_OK == LucResult)
      {
        /* Full setting flow */
        ETHA_FullSettingFlow(LulETHAIdx);

        /* RMAC setting flow */
        RMAC_InitializationFlow(LulETHAIdx);

        /* Mode transition flow to DISABLE mode */
        LucResult = Eth_HwETHA_ModeTransitionFlow(LulETHAIdx, ETH_RSW3_ETHA_DISABLE_MODE);
      }
      else
      {
        /* No action required */
      }
    }
    else
    {
      /* No action required */
    }
  }
  else
  {
    /* No action required */
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_TasRamResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : ETHA TAS RAM reset Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_ETHARegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : EATASRIRM
**
** Reference ID          : ETH_DUD_ACT_3060
** Reference ID          : ETH_DUD_ACT_3060_GBL001, ETH_DUD_ACT_3060_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasRamResetFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* EATASRIRM.TASRIOG Set */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASRIRM = ETH_RSW3_ETHA_TASRIRM_TASRIOG;

  /* Read EATASRIRM.TASRR */
  /* Wait until EATASRIRM.TASRR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASRIRM & ETH_RSW3_ETHA_TASRIRM_TASRR)
      != ETH_RSW3_ETHA_TASRIRM_TASRR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_CbsQSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : CBS q setting flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRSW3_ETHARegs
**                       : Eth_GaaRsw3PortCtrlIdx
**
** Function(s) invoked   : None
**
** Registers Used        : EACAIVCq, EACAULCq, EACAEC, EACC
**
** Reference ID          : ETH_DUD_ACT_3061
** Reference ID          : ETH_DUD_ACT_3061_GBL001, ETH_DUD_ACT_3061_GBL002, ETH_DUD_ACT_3061_GBL003
** Reference ID          : ETH_DUD_ACT_3061_REG001, ETH_DUD_ACT_3061_REG002, ETH_DUD_ACT_3061_REG003
** Reference ID          : ETH_DUD_ACT_3061_REG004
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwETHA_CbsQSettingFlow (
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulCnt;
  uint32 LulCtrlIdx;

  LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx)];                                           /* PRQA S 3469 # JV-01 */

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  for (LulCnt = 0UL; LulCnt < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulCnt++)
  {
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEACAIVCq[LulCnt] =
      LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.ulCIV;
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEACAULCq[LulCnt] =
      LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.ulCUL;
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEACAEC |=
      (uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.enCE << LulCnt;
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEACC |= 1UL << LulCnt;
  }
}

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_TasSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : TAS setting flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRSW3_ETHARegs,
**                         Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : Eth_TASEntryLearnFlow,GetCounterValue
**                         Eth_HwGPTP_Avtp64TimerTReadingFlow
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : EATASC, EATASENCi,
**                         EATASCSTC0, EATASCSTC1, EATASCTC
**
** Reference ID          : ETH_DUD_ACT_3062
** Reference ID          : ETH_DUD_ACT_3062_GBL001, ETH_DUD_ACT_3062_GBL002, ETH_DUD_ACT_3062_GBL003
** Reference ID          : ETH_DUD_ACT_3062_REG001, ETH_DUD_ACT_3062_REG002, ETH_DUD_ACT_3062_REG003
** Reference ID          : ETH_DUD_ACT_3062_REG004, ETH_DUD_ACT_3062_REG005
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasSettingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint64 LulCycleStartTime;
  TickType LulTickStart;
  TickType LulTickElap;
  uint32 LulSaveTasConfigAddr;
  uint32 LulTasTableIdx;
  uint32 LulQIdx;
  uint32 LulAVTP_Upper;
  uint32 LulAVTP_Downer;
  uint32 LulETHARegsTmp;
  uint32 LulCtrlIdx;
  Std_ReturnType LucResult;

  LulAVTP_Upper = 0UL;
  LulAVTP_Downer = 0UL;

  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC & ETH_RSW3_ETHA_EATASC_TASCI)
    == ETH_RSW3_ETHA_EATASC_TASCI) && (LulTickElap <= ETH_TIMEOUT_COUNT));
  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
    /*Save TAS config address in i variable*/
    LulSaveTasConfigAddr = ((Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC & ETH_RSW3_ETHA_EATASC_TASCA) >> 16UL );
    /* Set gate entry numbers */
    LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx)];                                         /* PRQA S 3469 # JV-01 */
    LpHwUnitConfig =
      (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;             /* PRQA S 0316, 3432 # JV-01, JV-01 */
    for (LulQIdx = 0UL; LulQIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulQIdx++)
    {
      if (LpHwUnitConfig->stTASConfig.aaEntryNumber[LulQIdx] != 0UL)
      {
        Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASENCi[LulQIdx] =
          (uint32)(LpHwUnitConfig->stTASConfig.aaEntryNumber[LulQIdx] - 1UL);
      }
      else
      {
        /* No action required */
      }
    }

    /* Set EATASCTENC Set cut-through gate entry number. **/

    /* Set cycle start time */
    Eth_HwGPTP_Avtp64TimerTReadingFlow(ETH_AVTP_TIMER_DOMAIN, &LulAVTP_Upper, &LulAVTP_Downer);
    LulCycleStartTime =
             ((((uint64)LulAVTP_Upper << ETH_RSW3_64_TO_32_SHIFT) | (uint64)LulAVTP_Downer) + ETH_RSW3_SETCYCLE_START)  /* PRQA S 3383 # JV-01 */
                       - (uint64)(LpHwUnitConfig->stTASConfig.ulTxMiniLatency);                                         /* PRQA S 3384 # JV-01 */

    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASCSTC0 = (uint32)(LulCycleStartTime & ETH_RSW3_64_TO_32_LOW);

    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASCSTC1 = (uint32)((LulCycleStartTime & ETH_RSW3_64_TO_32_HIGH) >>
                                                              ETH_RSW3_64_TO_32_SHIFT);

    /* ulCycleTime will be the same for all Queue, so enter the value for the first Queue. */
    LulQIdx = 0UL;
    /* Set cycle time */
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASCTC = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQIdx].ulCycleTime;
    /* learn an entry */
    for (LulTasTableIdx = 0; LulTasTableIdx < (uint32)LpHwUnitConfig->stTASConfig.ulNumberOfTasTable; LulTasTableIdx++)
    {
      LucResult = Eth_HwETHA_TasEntryILearnFlow(LulETHAIdx,
                                                LulSaveTasConfigAddr,
                                                LpHwUnitConfig->stTASConfig.pTasTable + LulTasTableIdx);                /* PRQA S 0488 # JV-01 */
      if (E_OK == LucResult)
      {
        LulSaveTasConfigAddr = LulSaveTasConfigAddr + 1UL;                                                              /* PRQA S 3383 # JV-01 */
      }
      else
      {
        break;
      }
    }

    if (E_OK == LucResult)
    {
      /* EATASC.TASE == 1'b1? */
      /* Note */
      /* - The TSNA hardware manual has specifications for both cases where TASE is 1 and 0, */
      /* - but MCAL's operational case is only for TASE 0. */
      /* - Therefore, only the case where TASE is 0 is implemented. */
      if (ETH_RSW3_ETHA_EATASC_TASE != (ETH_RSW3_ETHA_EATASC_TASE & Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC))
      {
        /*Set EATASC register with TASE to 1'b1 and TASCC to 1'b0*/
        LulETHARegsTmp = Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC;
        LulETHARegsTmp |= ETH_RSW3_ETHA_EATASC_TASE;
        LulETHARegsTmp &= ~ETH_RSW3_ETHA_EATASC_TASCC;
        Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC = LulETHARegsTmp;
      }
      else
      {
        /* No action required */
      }
    }
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_TasDisablingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : TAS disabling flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_ETHARegs
**
** Function(s) invoked   : GetCounterValue, Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : EATASC
**
** Reference ID          : ETH_DUD_ACT_3063
** Reference ID          : ETH_DUD_ACT_3063_GBL001, ETH_DUD_ACT_3063_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasDisablingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;
  /* Read TAS status */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC & ETH_RSW3_ETHA_EATASC_TASCI)
      == ETH_RSW3_ETHA_EATASC_TASCI) && (LulTickElap <= ETH_TIMEOUT_COUNT));
  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
    /*Set EATASC register with TASE to 1'b0 and TASCC to 1'b0*/
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC &= ~(ETH_RSW3_ETHA_EATASC_TASE | ETH_RSW3_ETHA_EATASC_TASCC);
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_TasEnablingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : TAS enabling flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_ETHARegs
**
** Function(s) invoked   : None
**
** Registers Used        : EATASC
**
** Reference ID          : ETH_DUD_ACT_3064
** Reference ID          : ETH_DUD_ACT_3064_GBL001, ETH_DUD_ACT_3064_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwETHA_TasEnablingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  uint32 LulETHARegsTmp;
  /*Set EATASC register with TASE to 1'b1 and TASCC to 1'b0*/
  LulETHARegsTmp = Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC;
  LulETHARegsTmp |= ETH_RSW3_ETHA_EATASC_TASE;
  LulETHARegsTmp &= ~ETH_RSW3_ETHA_EATASC_TASCC;

  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASC = LulETHARegsTmp;

}

/***********************************************************************************************************************
** Function Name         : Eth_HwETHA_TasEntryILearnFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : The TAS entry i learn flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_ETHARegs
**
** Function(s) invoked   : GetCounterValue,Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : EATASGL0, EATASGL1, EATASGLR
**
** Reference ID          : ETH_DUD_ACT_3065
** Reference ID          : ETH_DUD_ACT_3065_GBL001, ETH_DUD_ACT_3065_REG001, ETH_DUD_ACT_3065_REG002
** Reference ID          : ETH_DUD_ACT_3065_REG003
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwETHA_TasEntryILearnFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx,
  CONST(uint32, AUTOMATIC) LulSaveTasConfigAddr,
  CONSTP2CONST(Eth_TASEntryType, AUTOMATIC, ETH_APPL_DATA) LpCtrlConfig)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;
  /* Set address to be learnt to i */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASGL0 = LulSaveTasConfigAddr;
  /* Set entry to be learnt */

  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASGL1 =
    (((uint32)LpCtrlConfig->enGateState << 28UL) | LpCtrlConfig->ulTimeInterval);
  /* Read Ethernet Agent TAS Gate Learn Result */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASGLR & ETH_RSW3_ETHA_EATASGLR_GL)
      == ETH_RSW3_ETHA_EATASGLR_GL) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}
#endif  /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */
#if (ETH_CTRL_ENABLE_MII == STD_ON)

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_PhyMdioWriteAccessFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : Write data from the PHY management interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulRMACIdx : Index of a RMAC
**                         LucTrcvIdx : Index of the transceiver on the MII
**                         LucRegIdx  : Index of the transceiver register on the MII
**                         LusWriteVal: Value to be written into the indexed register
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LusRetData (Read data from PHY)
**
** Preconditions         : (ETH_CTRL_ENABLE_MII == STD_ON)
**
** Global Variable(s)    : Eth_GaaRSW3_RMACRegs
**
** Function(s) invoked   : GetCounterValue, Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : MPSM
**
** Reference ID          : ETH_DUD_ACT_3066
** Reference ID          : ETH_DUD_ACT_3066_GBL001, ETH_DUD_ACT_3066_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwRMAC_PhyMdioWriteAccessFlow(
  CONST(uint32, AUTOMATIC) LulRMACIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
  CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusWriteVal)
{
  Std_ReturnType LucResult = E_OK;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Request a write access */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMPSM =
    ETH_RSW3_MPSM_SET(LucRegIdx, LucTrcvIdx, ETH_RSW3_RMAC_MPSM_POP_WRITE, LusWriteVal);                                /* PRQA S 2985, 3432 # JV-01, JV-01 */

  /* Wait until MPSM.PSME returns to 0 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMPSM & ETH_RSW3_RMAC_MPSM_PSME) != 0UL)
      && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_PhyMdioReadAccessFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : Read data from the PHY management interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulRMACIdx     : Index of a RMAC
**                         LucTrcvIdx     : Index of the transceiver on the MII
**                         LucRegIdx      : Index of the transceiver register on the MII
**                         LpRegValPtr    : Value of indexed register
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LusRetData (Read data from PHY)
**
** Preconditions         : (ETH_CTRL_ENABLE_MII == STD_ON)
**
** Global Variable(s)    : Eth_GaaRSW3_RMACRegs
**
** Function(s) invoked   : GetCounterValue, Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : MPSM
**
** Reference ID          : ETH_DUD_ACT_3067
** Reference ID          : ETH_DUD_ACT_3067_GBL001, ETH_DUD_ACT_3067_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwRMAC_PhyMdioReadAccessFlow(
  CONST(uint32, AUTOMATIC) LulRMACIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx, CONST(uint8, AUTOMATIC) LucRegIdx,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr)                                                             /* PRQA S 3432 # JV-01 */
{
  TickType LulTickStart;
  TickType LulTickElap;
  uint32 LulRdata;
  Std_ReturnType LucResult = E_OK;

  /* Request a read access */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMPSM =
    ETH_RSW3_MPSM_SET(LucRegIdx, LucTrcvIdx, ETH_RSW3_RMAC_MPSM_POP_READ, 0x0U);                                        /* PRQA S 2985, 2986, 3432 # JV-01, JV-01, JV-01 */

  /* Wait until MPSM.PSME returns to 0 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMPSM & ETH_RSW3_RMAC_MPSM_PSME) != 0UL)
      && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    *LpRegValPtr = (uint16)0x0UL;
    LucResult = E_NOT_OK;
  }
  else
  {
    LulRdata = Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMPSM;
    *LpRegValPtr = ETH_RSW3_SET_MPSM_PRD_READ(LulRdata);                                                                /* PRQA S 3469 # JV-01 */
  }

  return LucResult;
}
#endif /* (ETH_CTRL_ENABLE_MII == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_HwRMAC_LinkVerification (RSW3)
**
** Service ID            : N/A
**
** Description           : RMAC Link Verification
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulRMACIdx : RMAC index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRSW3_RMACRegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : MLVC
**
** Reference ID          : ETH_DUD_ACT_3068
** Reference ID          : ETH_DUD_ACT_3068_GBL001, ETH_DUD_ACT_3068_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwRMAC_LinkVerification(
  CONST(uint32, AUTOMATIC) LulRMACIdx)
{
  Std_ReturnType LucResult = E_OK;
  #if !defined X5H_RFS_PLATFORM_USED && !defined X5H_VDK_PLATFORM_USED
  TickType LulTickStart;
  TickType LulTickElap;

  /* Request Link Verification */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMLVC =
    (ETH_RSW3_RMAC_MLVC_PLV | ETH_RSW3_RMAC_MLVC_PASE | ETH_RSW3_RMAC_MLVC_LVT);

  /* Complete Link Verification */
  /* Wait until MLVC.PLV returns to 0 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMLVC & ETH_RSW3_RMAC_MLVC_PLV) != 0UL)
      && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }
  #else
  /* In VPF, PLV does not change */
  (void)LulRMACIdx;
  #endif /* ETH_VPF && X5H_VDK_ETH_USED */

  return LucResult;
}

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_HwGPTP_TimerTOffsetSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : Timer Offset Setting Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulTimerIdx : gPTP index
**                       : LulNanoSeconds : gPTP timer NanoSeconds
**                       : LulSecondsLower : gPTP timer Seconds
**                       : LusSecondsHigher : gPTP timer Seconds High
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
**
** Global Variable(s)    : Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : PTPTOVC0t, PTPTOVC1t, PTPTOVC2t
**
** Reference ID          : ETH_DUD_ACT_3069
** Reference ID          : ETH_DUD_ACT_3069_GBL001, ETH_DUD_ACT_3069_REG001, ETH_DUD_ACT_3069_REG002
** Reference ID          : ETH_DUD_ACT_3069_REG003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwGPTP_TimerTOffsetSettingFlow(
  CONST(uint32, AUTOMATIC) LulTimerIdx,
  CONST(uint32, AUTOMATIC) LulNanoSeconds,
  CONST(uint32, AUTOMATIC) LulSecondsLower,
  CONST(uint16, AUTOMATIC) LusSecondsHigher)
{
  Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPTOVC2t = (uint32)LusSecondsHigher;
  Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPTOVC1t = LulSecondsLower;
  if (LulNanoSeconds > ETH_GPTP_OFFSET_NANOSEC_MAXVALUE)
  {
    /* The upper limit is 0x3B9AC9FF */
    Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPTOVC0t = ETH_GPTP_OFFSET_NANOSEC_MAXVALUE;
  }
  else
  {
    Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPTOVC0t = LulNanoSeconds;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_HwGPTP_Avtp64TimerTReadingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : AVTP Timer Reading Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulTimerIdx  : AVTP index
**                         ulAVTP_Upper : AVTP Timer upper bits
**                         ulAVTP_Downer: AVTP Timer lower bits
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : PTPAVTPTM0t, PTPAVTPTM1t
**
** Reference ID          : ETH_DUD_ACT_3070
** Reference ID          : ETH_DUD_ACT_3070_GBL001, ETH_DUD_ACT_3070_REG001, ETH_DUD_ACT_3070_REG002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwGPTP_Avtp64TimerTReadingFlow(
  CONST(uint32, AUTOMATIC) LulTimerIdx,
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) ulAVTP_Upper,                                                            /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) ulAVTP_Downer)                                                           /* PRQA S 3432 # JV-01 */
{
  /*Read 64-bit AVTP timer downer 32 bits */
  *ulAVTP_Downer = Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPAVTPTM0t;

  /* Read 64-bit AVTP timer upper 32 bits */
  *ulAVTP_Upper  = Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPAVTPTM1t;
}

/***********************************************************************************************************************
** Function Name         : Eth_HwGPTP_gPTPTimerTReadingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : gPTP Timer Reading Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulTimerIdx : gPTP index
**                       : LpNanoSeconds : gPTP timer NanoSeconds
**                       : LpSecondsLower : gPTP timer Seconds
**                       : LpSecondsHigher : gPTP timer Seconds High
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
**
** Global Variable(s)    : Eth_GpRSW3_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : PTPGPTPTM0t, PTPGPTPTM1t, PTPGPTPTM2t
**
** Reference ID          : ETH_DUD_ACT_3124
** Reference ID          : ETH_DUD_ACT_3124_GBL001, ETH_DUD_ACT_3124_REG001, ETH_DUD_ACT_3124_REG002
** Reference ID          : ETH_DUD_ACT_3124_REG003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_HwGPTP_gPTPTimerTReadingFlow(
  CONST(uint32, AUTOMATIC) LulTimerIdx,
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpNanoSeconds,                                                           /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpSecondsLower,                                                          /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpSecondsHigher)                                                         /* PRQA S 3432 # JV-01 */
{
  uint32 LulseconHi;

  *LpNanoSeconds = Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPGPTPTM0t;
  *LpSecondsLower = Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPGPTPTM1t;
  LulseconHi = Eth_GpRSW3_GPTPRegs->PTP[LulTimerIdx].ulPTPGPTPTM2t;
  /* In PTPGPTPTM2t, only the lower 16 bits are valid, casting to uint16 does no problem. */
  *LpSecondsHigher = (uint16)LulseconHi;
}
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

/***********************************************************************************************************************
** Function Name         : COMA_BufferPoolnitializationFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : COMA Switch Clock Enable Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_COMARegs
**
** Function(s) invoked   : GetCounterValue,
**                         Eth_RSW_GetElapsedTimeValue
**
** Registers Used        : CABPIRM, CABPPFLCi, CABPPPFLCij
**
** Reference ID          : ETH_DUD_ACT_3072
** Reference ID          : ETH_DUD_ACT_3072_GBL001, ETH_DUD_ACT_3072_GBL002, ETH_DUD_ACT_3072_GBL003
** Reference ID          : ETH_DUD_ACT_3072_GBL004, ETH_DUD_ACT_3072_GBL005, ETH_DUD_ACT_3072_GBL006
** Reference ID          : ETH_DUD_ACT_3072_REG001, ETH_DUD_ACT_3072_REG002, ETH_DUD_ACT_3072_REG003
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) COMA_BufferPoolnitializationFlow(void)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucResult = E_OK;
  uint32 LulCtrlIdx;
  uint32 LulPasLvl;
  uint32 LulPortIdx;
  #if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
  TickType LulTickStart;
  TickType LulTickElap;
  #endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

  /* CABPIBWMCi Set */

  /* CABPWMLC Set */

  /* CABPPFLCi Set */
  for (LulPasLvl = 0; LulPasLvl < ETH_RACE_PAS_LVL_N; LulPasLvl++)
  {
    if (ETH_ENABLE == Eth_GpGlobalPauseCfgPtr[LulPasLvl].enGlobalPause)                                                 /* PRQA S 3416 # JV-01 */
    {
      /* CABPPFLCi register
       * bit PALi=ulPauseAssertionLevel   : Pause Assertion Level
       * bit PDLi=ulPauseDeAssertionLevel : De-assertion Level
       */
      Eth_GpRSW3_COMARegs->ulCABPPFLCi[LulPasLvl] =                                                                     /* PRQA S 0404 # JV-01 */
                            (uint32)(((uint32)Eth_GpGlobalPauseCfgPtr[LulPasLvl].ulPauseAssertionLevel << 16UL) |
                                     ((uint32)Eth_GpGlobalPauseCfgPtr[LulPasLvl].ulPauseDeAssertionLevel));
    }
    else
    {
      /* No action required */
    }
  }
  /* CABPPWMLCi Set */

  /* CABPPPFLCij Set */
  for (LulPortIdx = 0; LulPortIdx < ETH_RACE_PORT_N; LulPortIdx++)
  {
    if (ETH_TRUE == Eth_GaaRsw3PortValid[LulPortIdx])
    {
      LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[LulPortIdx];
      LpHwUnitConfig =
        (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;           /* PRQA S 0316, 3432 # JV-01, JV-01 */
      if (ETH_ENABLE == LpHwUnitConfig->stFlowControlConfig.enPauseFrame)
      {
        /* When RMAC is PAUSE mode, set only level 0 */
        /* CABPPPFLCij register
         * bit PPALij=ulPauseAssertionLevel   : Per Port Pause Assertion Level
         * bit PPDLij=ulPauseDeAssertionLevel : Per Port Pause De-assertion Level
         */
        Eth_GpRSW3_COMARegs->ulCABPPPFLCij[LulPortIdx][0] =
          (uint32)(((uint32)LpHwUnitConfig->stFlowControlConfig.stPauseLevelConfig.ulPauseAssertionLevel << 16UL) |
                   ((uint32)LpHwUnitConfig->stFlowControlConfig.stPauseLevelConfig.ulPauseDeAssertionLevel));
      }
      else if (ETH_ENABLE == LpHwUnitConfig->stPFCConfig.enPFCFrame)
      {
        /* When RMAC is PFC mode, set levels 0 and 1 */
        /* CABPPPFLCij register
         * bit PPALij=ulPauseAssertionLevel   : Per Port Pause Assertion Level
         * bit PPDLij=ulPauseDeAssertionLevel : Per Port Pause De-assertion Level
         */
        for (LulPasLvl = 0; LulPasLvl < ETH_RACE_PAS_LVL_N; LulPasLvl++)
        {
          Eth_GpRSW3_COMARegs->ulCABPPPFLCij[LulPortIdx][LulPasLvl] = (uint32)(
                ((uint32)LpHwUnitConfig->stPFCConfig.stPFCPauseLevelConfig[LulPasLvl].ulPauseAssertionLevel << 16UL) |
                ((uint32)LpHwUnitConfig->stPFCConfig.stPFCPauseLevelConfig[LulPasLvl].ulPauseDeAssertionLevel));
        }
      }
      else
      {
        /* No action required */
      }
    }
    #if (ETH_BOTHCORE_ENABLE == STD_ON)
    else if (ETH_RSW3_BOTH_CORE_PORT_ID == LulPortIdx)
    {
      for (LulPasLvl = 0; LulPasLvl < ETH_RACE_PAS_LVL_N; LulPasLvl++)
      {
        /* CABPPPFLCij register
         * bit PPALij=ulBothCorePauseAssertionLevel   : Per Port Pause Assertion Level
         * bit PPDLij=ulBothCorePauseDeAssertionLevel : Per Port Pause De-assertion Level
         */
        Eth_GpRSW3_COMARegs->ulCABPPPFLCij[LulPortIdx][LulPasLvl] = (uint32)(                                           /* PRQA S 0404 # JV-01 */
          ((uint32)Eth_GpBothCoreCfgPtr->stBothCorePauseLevelConfig[LulPasLvl].ulBothCorePauseAssertionLevel << 16UL) |
          ((uint32)Eth_GpBothCoreCfgPtr->stBothCorePauseLevelConfig[LulPasLvl].ulBothCorePauseDeAssertionLevel));
      }
    }
    #endif /* ETH_BOTHCORE_ENABLE */
    else
    {
      /* No action required */
    }
  }

  #if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
  /* CABPULCi Set */

  /* CABPIRM.BPIOG Set */
  Eth_GpRSW3_COMARegs->ulCABPIRM = ETH_RSW3_COMA_CABPIRM_BPIOG;

  /* Read CABPIRM.BPR */
  /* Wait until CABPIRM.BPR returns to 1 */
  LulTickStart = 0UL;
  LulTickElap = 0UL;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                             /* PRQA S 3383 # JV-01 */
  } while (((Eth_GpRSW3_COMARegs->ulCABPIRM & ETH_RSW3_COMA_CABPIRM_BPR)
      != ETH_RSW3_COMA_CABPIRM_BPR) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }
  #endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

  return LucResult;
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : COMA_RSwitchResetFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : R-Switch Reset Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_COMARegs
**
** Function(s) invoked   : None
**
** Registers Used        : RRC
**
** Reference ID          : ETH_DUD_ACT_3073
** Reference ID          : ETH_DUD_ACT_3073_GBL001, ETH_DUD_ACT_3073_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_RSwitchResetFlow(void)
{
  volatile uint32 i, loopLimit;
  loopLimit = 1;

  /* Set R-Switch reset */
  Eth_GpRSW3_COMARegs->ulRRC = 0x00000001UL;

  for (i=0; i < loopLimit; i++)                                                                                         /* PRQA S 0404, 3387, 3416 # JV-01, JV-01, JV-01 */
  {
    /* wait for 1 clock */
  }

  /* Release R-Switch reset */
  Eth_GpRSW3_COMARegs->ulRRC = 0x00000000UL;
}
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

/***********************************************************************************************************************
** Function Name         : COMA_AgentIClockEnableFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : COMA agent i clock enable flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulPortIdx : RSW3 port index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortMap, Eth_GpRSW3_COMARegs
**
** Function(s) invoked   : None
**
** Registers Used        : RCEC
**
** Reference ID          : ETH_DUD_ACT_3074
** Reference ID          : ETH_DUD_ACT_3074_GBL001, ETH_DUD_ACT_3074_GBL002, ETH_DUD_ACT_3074_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_AgentIClockEnableFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx)
{
  uint32 LulRegVal;

  LulRegVal = Eth_GpRSW3_COMARegs->ulRCEC;
  LulRegVal = (LulRegVal | Eth_GaaRsw3PortMap[LulPortIdx] | ETH_RSW3_COMA_RCEC_RCE);
  Eth_GpRSW3_COMARegs->ulRCEC = LulRegVal;
}

/***********************************************************************************************************************
** Function Name         : COMA_AgentIClockDisableFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : COMA agent i clock disable flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulPortIdx : RSW3 port index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortMap, Eth_GpRSW3_COMARegs
**
** Function(s) invoked   : None
**
** Registers Used        : RCDC
**
** Reference ID          : ETH_DUD_ACT_3075
** Reference ID          : ETH_DUD_ACT_3075_GBL001, ETH_DUD_ACT_3075_GBL002, ETH_DUD_ACT_3075_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_AgentIClockDisableFlow(CONST(uint32, AUTOMATIC) LulPortIdx)
{
  Eth_GpRSW3_COMARegs->ulRCDC = Eth_GaaRsw3PortMap[LulPortIdx];
}

/***********************************************************************************************************************
** Function Name         : COMA_AgentIClockStatusCheckFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : COMA agent i clock status check flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulPortIdx : RSW3 port index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : ETH_TRUE : clock enabled
**                         ETH_FALSE :clock disabled
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortMap, Eth_GpRSW3_COMARegs
**
** Function(s) invoked   : None
**
** Registers Used        : RCEC
**
** Reference ID          : ETH_DUD_ACT_3076
** Reference ID          : ETH_DUD_ACT_3076_GBL001, ETH_DUD_ACT_3076_GBL002, ETH_DUD_ACT_3076_REG001
***********************************************************************************************************************/
STATIC FUNC(boolean, ETH_PRIVATE_CODE) COMA_AgentIClockStatusCheckFlow(
  CONST(uint32, AUTOMATIC) LulPortIdx)
{
  uint32 LulRegVal;
  boolean LblClockEnabled;

  LulRegVal = Eth_GpRSW3_COMARegs->ulRCEC;

  if ((LulRegVal & (ETH_RSW3_COMA_RCEC_RCE | Eth_GaaRsw3PortMap[LulPortIdx])) ==
      (ETH_RSW3_COMA_RCEC_RCE | Eth_GaaRsw3PortMap[LulPortIdx]))
  {
    LblClockEnabled = ETH_TRUE;
  }
  else
  {
    LblClockEnabled = ETH_FALSE;
  }

  return LblClockEnabled;
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : COMA_SwitchClockEnableFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : COMA Switch Clock Enable Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpRSW3_COMARegs
**
** Function(s) invoked   : None
**
** Registers Used        : RCEC
**
** Reference ID          : ETH_DUD_ACT_3077
** Reference ID          : ETH_DUD_ACT_3077_GBL001, ETH_DUD_ACT_3077_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) COMA_SwitchClockEnableFlow(void)
{
  Eth_GpRSW3_COMARegs->ulRCEC = ETH_RSW3_COMA_RCEC_RCE;
}
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

/***********************************************************************************************************************
** Function Name         : MFWD_FullSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Full Setting Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : MFWD_PortBasedForwardingSettingFlow,
**                         Eth_HwMFWD_PortISettingFlow,
**                         MFWD_Layer3ForwardingRoutingFilteringSettingFlow,
**                         MFWD_Layer2ForwardingSettingFlow,
**                         MFWD_Layer2Layer3UpdateSettingFlow,
**                         MFWD_PsfpSettingFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3078
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_FullSettingFlow(void)
{
  Std_ReturnType LucResult = E_OK;
  uint32 LulPortIdx;

  #if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
  /* General function setting flow */

  /* Layer 3 forearding/routing/filtering setting flow */
  LucResult = MFWD_Layer3ForwardingRoutingFilteringSettingFlow();

  /* Layer 2 forwarding setting flow */
  if (E_OK == LucResult)
  {
    LucResult = MFWD_Layer2ForwardingSettingFlow();
  }
  else
  {
    /* No action required */
  }
  #endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

  /* Port-based forwarding setting flow */
  if (E_OK == LucResult)                                                                                                /* PRQA S 2991, 2995 # JV-01, JV-01 */
  {
    MFWD_PortBasedForwardingSettingFlow();
  }
  else
  {
    /* No action required */
  }

  #if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
  /* Layer 2/Layer 3 update setting flow */
  if (E_OK == LucResult)
  {
    LucResult = MFWD_Layer2Layer3UpdateSettingFlow();
  }
  else
  {
    /* No action required */
  }

  /* PSFP setting flow */
  if (E_OK == LucResult)
  {
    LucResult = MFWD_PsfpSettingFlow();
  }
  else
  {
    /* No action required */
  }
  #endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

  /* Port i setting flow */
  if (E_OK == LucResult)                                                                                                /* PRQA S 2991, 2995 # JV-01, JV-01 */
  {
    for (LulPortIdx = 0; LulPortIdx < ETH_RACE_PORT_N; LulPortIdx++)
    {
      /* Port i setting flow  */
      Eth_HwMFWD_PortISettingFlow(LulPortIdx);
    }
  }
  else
  {
    /* No action required */
  }

  return LucResult;
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : MFWD_Layer3ForwardingRoutingFilteringSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Layer 3 forearding/routing/filtering setting flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwMFWD_Layer3TableResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3079
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_Layer3ForwardingRoutingFilteringSettingFlow(void)
{
  Std_ReturnType LucResult;

  /* Layer 3 table reset flow */
  LucResult = Eth_HwMFWD_Layer3TableResetFlow();

  /* Subsequent processing is not processed by MCAL/ETH */

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : MFWD_Layer2ForwardingSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Layer 2 forwarding setting flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwMFWD_MacTableResetFlow
**                         Eth_HwMFWD_VlanTableResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3080
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_Layer2ForwardingSettingFlow(void)
{
  Std_ReturnType LucResult;

  /* MAC table reset flow  */
  LucResult = Eth_HwMFWD_MacTableResetFlow();

  if (E_OK == LucResult)
  {
    /* VLAN table reset flow  */
    LucResult = Eth_HwMFWD_VlanTableResetFlow();
  }
  else
  {
    /* No action required */
  }

  /* Subsequent processing is not processed by MCAL/ETH */

  return LucResult;
}
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

/***********************************************************************************************************************
** Function Name         : MFWD_PortBasedForwardingSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Port Based Forwarding Setting Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwMFWD_PortIPortBasedSettingFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3081
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) MFWD_PortBasedForwardingSettingFlow(void)
{
  uint32 LulPortIdx;

  for (LulPortIdx = 0; LulPortIdx < ETH_RACE_PORT_N; LulPortIdx++)
  {
    /* Port i port-based setting flow  */
    Eth_HwMFWD_PortIPortBasedSettingFlow(LulPortIdx);
  }
}

#if (ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION)
/***********************************************************************************************************************
** Function Name         : MFWD_Layer2Layer3UpdateSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD Layer 2/Layer 3 update setting flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwMFWD_Layer2Layer3UpdateTableResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3082
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_Layer2Layer3UpdateSettingFlow(void)
{
  Std_ReturnType LucResult;

  /* Layer 2/Layer 3 update table reset flow */
  LucResult = Eth_HwMFWD_Layer2Layer3UpdateTableResetFlow();

  /* Subsequent processing is not processed by MCAL/ETH */

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : MFWD_PsfpSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : MFWD PSFP setting flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_HwMFWD_GateRamResetFlow
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3083
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) MFWD_PsfpSettingFlow(void)
{
  Std_ReturnType LucResult;

  /* Gate RAM reset flow */
  LucResult = Eth_HwMFWD_GateRamResetFlow();

  /* Subsequent processing is not processed by MCAL/ETH */

  return LucResult;
}
#endif /* ETH_SWITCHING_MODE == ETH_SWMODE_ENDSTATION */

/***********************************************************************************************************************
** Function Name         : GWCA_FullSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : GWCA Full Setting Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulGWCAIdx : GWCA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTSDescTableAddr, Eth_GaaLinkFixTable,
**                         Eth_GaaRsw3PortValid, Eth_GaaRsw3PortCtrlIdx,
**                         Eth_GaaCtrlStat, Eth_GaaTsDescChain,
**                         Eth_GpGwcaCfgPtr, Eth_GaaRSW3_GWCARegs,
**                         Eth_GstDescChainMap
**
** Function(s) invoked   : Eth_RSW_GetElapsedTimeValue,
**                         GetCounterValue
**
** Registers Used        : GWMAC0, GWMAC1, GWVCC, GWVTC, GWTTFC,
**                         GWDCBAC0, GWDCBAC1, GWTSDCCs, GWDCCi
**                         GWRMFSCq, GWTDCAC0s, GWTDCAC1s,
**                         GWGRLC, GWGRLULC, GWRLCi, GWRLULCi
**
** Reference ID          : ETH_DUD_ACT_3084
** Reference ID          : ETH_DUD_ACT_3084_GBL001, ETH_DUD_ACT_3084_GBL002, ETH_DUD_ACT_3084_GBL003
** Reference ID          : ETH_DUD_ACT_3084_GBL004, ETH_DUD_ACT_3084_GBL005, ETH_DUD_ACT_3084_GBL006
** Reference ID          : ETH_DUD_ACT_3084_GBL007, ETH_DUD_ACT_3084_GBL008, ETH_DUD_ACT_3084_GBL009
** Reference ID          : ETH_DUD_ACT_3084_GBL010, ETH_DUD_ACT_3084_REG001, ETH_DUD_ACT_3084_REG002
** Reference ID          : ETH_DUD_ACT_3084_REG003, ETH_DUD_ACT_3084_REG004, ETH_DUD_ACT_3084_REG005
** Reference ID          : ETH_DUD_ACT_3084_REG006, ETH_DUD_ACT_3084_REG007, ETH_DUD_ACT_3084_REG008
** Reference ID          : ETH_DUD_ACT_3084_REG009, ETH_DUD_ACT_3084_REG010, ETH_DUD_ACT_3084_REG011
** Reference ID          : ETH_DUD_ACT_3084_REG012, ETH_DUD_ACT_3084_REG013, ETH_DUD_ACT_3084_REG014
** Reference ID          : ETH_DUD_ACT_3084_REG015, ETH_DUD_ACT_3084_REG016
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) GWCA_FullSettingFlow(
  CONST(uint32, AUTOMATIC) LulGWCAIdx)
{
  P2VAR(volatile Eth_RSW3_GWCARegType, AUTOMATIC, REGSPACE) LpGwcaReg;                                                  /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  TickType LulTickStart;
  TickType LulTickElap;
  uint32 LulRegVal;
  uint32 LulCtrlIdx;
  uint32 LulFifoIdx;
  uint8 LucChainId;
  uint32 LulIdx;
  uint8 LucResult;
  uint32 LulChainId;
  uint32 LulGWRLIdx;
  uint32 lucID;

  LucResult = E_OK;
  LpGwcaReg = Eth_GaaRSW3_GWCARegs[LulGWCAIdx];

  LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_GWCAID_TO_PORTID(LulGWCAIdx)];                                           /* PRQA S 3383, 3432 # JV-01, JV-01 */

  /* Set GWIRC Set queue priority remapping */

  /* Set GWRDQSC Set queue security level */

  /* Set GWRDQAC Set Queue arbitration */

  /* Set GWRGC Set CRC reception */

  /* Set GWRMFSCq Set queue max frame size */
  for (LulFifoIdx = 0UL; LulFifoIdx < (uint32)ETH_GWCA_FRM_PRIO_N; LulFifoIdx++)
  {
    /* Add FCS size becouse PDF setting value dosen't include FCS size */
    LpGwcaReg->ulGWRMFSCq[LulFifoIdx] = Eth_GulRxMaxFrameSize + ETH_FCS_LENGTH;                                         /* PRQA S 3383 # JV-01 */
  }

  /* Set GWRDRC Set Descriptor RAM Mode. **/

  /* Set GWCSDRC Set CSD remapping. **/

  /* Set GWRDQDCq Set descriptor queue depths */

  /* Set GWMAC0/1 Set MAC address */
  if (ETH_TRUE == Eth_GaaRsw3PortValid[ETH_CONV_GWCAID_TO_PORTID(LulGWCAIdx)])                                          /* PRQA S 3383, 3432 # JV-01, JV-01 */
  {
    /* GWMAC0 Set */
    LpGwcaReg->ulGWMAC0 = Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 >> 16UL;
    /* GWMAC1 Set */
    LpGwcaReg->ulGWMAC1 =
      (Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 << 16UL) | Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulL16;
  }
  else
  {
    /* No action required */
  }

  #if(ETH_RSW3_GWCA_TOTAL_CONFIGURED < ETH_RACE_PORT_GWCA_N)
  lucID = 0UL;
  #else
  lucID = LulGWCAIdx;
  #endif

  /* Set GWVCC Set VLAN modes */
  LpGwcaReg->ulGWVCC = Eth_GpGwcaCfgPtr[lucID].stGwcaRegValue.ulGWVCCValue;

  /* Set GWVTC Set VLAN TAGs */
  LpGwcaReg->ulGWVTC = Eth_GpGwcaCfgPtr[lucID].stGwcaRegValue.ulGWVTCValue;

  /* Set GWICD0-1RC, GWICRD0-1RC, GWECD0-1RC, GWERD0-1RC Set TAG remapping. **/

  /* Set GWTTFC Set TAG filtering */
  LpGwcaReg->ulGWTTFC = Eth_GpGwcaCfgPtr[lucID].stGwcaRegValue.ulGWTTFCValue;

  /* Set GWTDCA0s/1s Set timestamp chain address */
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  LulRegVal = (uint32)&Eth_GaaTsDescChain[0];;                                                                          /* PRQA S 0306 # JV-01 */
  LpGwcaReg->GWTDCAC[ETH_GPTP_TIMER_DOMAIN].ulGWTDCAC1s = LulRegVal;
  LpGwcaReg->GWTDCAC[ETH_GPTP_TIMER_DOMAIN].ulGWTDCAC0s = 0x0UL;
  #endif

  /* Set GWTSDCCs Set timestamp queues */
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  LpGwcaReg->ulGWTSDCCs[ETH_GPTP_TIMER_DOMAIN] = 0x1UL;
  #endif

  /* Multicast table setting flow */

  /* LINKFIX table setting */
  /* This process is skipped because "LINKFIX table" has already been created. */

  /* Set GWDCBAC0/1 Set AXI base address */
  LpGwcaReg->ulGWDCBAC0 = 0x0UL;

  LulRegVal = (uint32)&Eth_GaaLinkFixTable[0];                                                                          /* PRQA S 0306 # JV-01 */
  LpGwcaReg->ulGWDCBAC1 = LulRegVal;

  /* Set GWIICBSC Set inter-IP block size -> HW unsupport. */

  /* Set GWMDNC Set maximum descriptor limits */

  /* Set GWTPCp Set queue pause */

  /* Set GWDCCi Set descriptor chains */
  for (LulIdx = 0; LulIdx < Eth_GstDescChainMap.ulValidChainNum; LulIdx++)
  {
    LulRegVal = ETH_RSW3_GWCA_GWDCC_EDE;
    LucChainId = Eth_GstDescChainMap.ucValidChainId[LulIdx];

    if (ETH_TX == Eth_GstDescChainMap.aaChainInfo[LulIdx].enDir)
    {
      LulRegVal |= ETH_RSW3_GWCA_GWDCC_TX;
      LulRegVal |= ETH_RSW3_GWCA_GWDCC_DCP_SET(Eth_GstDescChainMap.aaChainInfo[LulIdx].ulFifoIdx);                  /* PRQA S 3432 # JV-01 */
    }
    else
    {
      LulRegVal |= ETH_RSW3_GWCA_GWDCC_RX;
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      LulRegVal |= ETH_RSW3_GWCA_GWDCC_ETS;
#endif
    }

    LpGwcaReg->ulGWDCCi[LucChainId] = LulRegVal;
    LpGwcaReg->ulGWDCCi[LucChainId] |= ETH_RSW3_GWCA_GWDCC_BALR;

    /* Wait until BALR returns to 0 */
    LulTickStart = 0UL;
    LulTickElap = 0UL;
    (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_RSW_GetElapsedTimeValue(&LulTickStart);                                           /* PRQA S 3383 # JV-01 */
    } while (((LpGwcaReg->ulGWDCCi[LucChainId] & ETH_RSW3_GWCA_GWDCC_BALR) != 0UL)
        && (LulTickElap <= ETH_TIMEOUT_COUNT));

    if (ETH_TIMEOUT_COUNT < LulTickElap)
    {
       LucResult = E_NOT_OK;
       break;
    }
    else
    {
       LucResult = E_OK;
    }
  }

  /* Global rate limiter setting flow */
  LpGwcaReg->ulGWGRLULC = Eth_GpGwcaCfgPtr[lucID].stGwcaRegValue.ulGWGRLULCValue;
  LpGwcaReg->ulGWGRLC = Eth_GpGwcaCfgPtr[lucID].stGwcaRegValue.ulGWGRLCValue;


  /* Rate limiter i setting flow (i from 0 to AXI_TLIM_N) */
  for (LulIdx = 0UL; LulIdx < (uint32)ETH_TOTAL_CTRL_CONFIG; LulIdx++)                                                  /* PRQA S 2877 # JV-01 */
  {
    LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulIdx].pHwUnitConfig;                   /* PRQA S 0316, 3432 # JV-01, JV-01 */
    for (LulFifoIdx = 0UL; LulFifoIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulFifoIdx++)
    {
      LulChainId = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulFifoIdx].ulChainId;
      if ((ETH_RACE_AXI_CHAIN_RLMIN_N <= LulChainId))
      {
        LulGWRLIdx = (ETH_RACE_AXI_CHAIN_N - 1UL) - LulChainId;                                                         /* PRQA S 3383 # JV-01 */
        LpGwcaReg->GWRL[LulGWRLIdx].ulGWRLULCi =
          LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulFifoIdx].stPerQueRLConfig.ulGWRLULCiValue;

        LpGwcaReg->GWRL[LulGWRLIdx].ulGWRLCi =
          LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulFifoIdx].stPerQueRLConfig.ulGWRLCiValue;
      }
    }
  }
  /* Set GWCOC Set CBS operation enabling. **/

  /* Set CBSq seting flow (q from 0 to FRM_PRIO_N-1). **/

  /* Set GWIDPC Set interrupt delay prescaler */

  /* Set GWIDCi Set interrupt delays */

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : ETHA_FullSettingFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : Full Setting HWUnit(ETHA)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulETHAIdx : ETHA index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRsw3PortCtrlIdx, Eth_GaaRSW3_ETHARegs,
**                         Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : Eth_HwETHA_CbsQSettingFlow
**
** Registers Used        : EAVCC, EAVTC, EARTFC, EATASIGSC, EATASHCC
**                       : EATMFSCq, EATPEC
**
** Reference ID          : ETH_DUD_ACT_3085
** Reference ID          : ETH_DUD_ACT_3085_GBL001, ETH_DUD_ACT_3085_GBL002, ETH_DUD_ACT_3085_GBL003
** Reference ID          : ETH_DUD_ACT_3085_REG001, ETH_DUD_ACT_3085_REG002, ETH_DUD_ACT_3085_REG003
** Reference ID          : ETH_DUD_ACT_3085_REG004, ETH_DUD_ACT_3085_REG005, ETH_DUD_ACT_3085_REG006
** Reference ID          : ETH_DUD_ACT_3085_REG007, ETH_DUD_ACT_3085_REG008, ETH_DUD_ACT_3085_REG009
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) ETHA_FullSettingFlow(
  CONST(uint32, AUTOMATIC) LulETHAIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulCtrlIdx;
  uint32 LulPriority;
  uint32 LulQIdx;
  uint32 LulInitGateState;
  uint32 LulRegVal;

  LulInitGateState = 0;
  LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_ETHAID_TO_PORTID(LulETHAIdx)];                                           /* PRQA S 3469 # JV-01 */

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Set EAIRC Set queue priority remapping */

  /* Set EATDQSC Set queue security level */

  /* Set EATDQAC Set Queue arbitration */

  /* Set EATPEC Set queue type */
  LulRegVal = 0UL;
  for (LulPriority = 0UL; LulPriority < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulPriority++)
  {
    LulRegVal |= ((uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulPriority].enFrameType << LulPriority);
  }
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATPEC = ((uint32)LpHwUnitConfig->enTxFragment << 16UL) | LulRegVal;

  /* Set EATMFSCq Set queue max frame size */
  for (LulPriority = 0UL; LulPriority < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulPriority++)
  {
    /* Add FCS size becouse PDF setting value dosen't include FCS size */
    Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATMFSCq[LulPriority] =
      LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulPriority].ulMaxFrameSize + ETH_FCS_LENGTH;                        /* PRQA S 3383 # JV-01 */
  }
  /* Set EATDRC Set descriptor RAM mode. **/

  /* Set EATDQDCq Set descriptor queue depths */

  /* Set EACTQC EACTQCSet Cut-through delay */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEACTQC =
    Eth_GpCtrlConfigPtr[LulCtrlIdx].stSWConfig.stTsnaRegValue.ulEACTQCValue;

  /* Set EACTDQDC Cut-through queue depthCBS */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEACTDQDC =
    Eth_GpCtrlConfigPtr[LulCtrlIdx].stSWConfig.stTsnaRegValue.ulEACTDQDCValue;

  /* Set EAVCC Set VLAN modes */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAVCC =
    Eth_GpCtrlConfigPtr[LulCtrlIdx].stSWConfig.stTsnaRegValue.ulEAVCCValue;

  /* Set EAVTC Set VLAN TAGs */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEAVTC =
    Eth_GpCtrlConfigPtr[LulCtrlIdx].stSWConfig.stTsnaRegValue.ulEAVTCValue;

  /* Set EAICD0-1RC, EAISD0-1RC, EAECD0-1RC, EAESD0-1RC set TAG remapping. **/

  /* Set EARTFC Set VLAN TAGs */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEARTFC =
    Eth_GpCtrlConfigPtr[LulCtrlIdx].stSWConfig.stTsnaRegValue.ulEARTFCValue;

  /* Set EACKSC Set Checksum handing. **/

    /* CBS q setting flow (q from 0 to FRM_PRIO_N-1) */
    Eth_HwETHA_CbsQSettingFlow(LulETHAIdx);

  /* Set EATASIGSC Set TAS initial gate states */
  for (LulQIdx = 0; LulQIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulQIdx++)
  {
    LulInitGateState |= ((uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQIdx].enInitGateState << LulQIdx);
  }
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASIGSC = LulInitGateState;

  /* Set EATASHCC Set TAS jitter */
  Eth_GaaRSW3_ETHARegs[LulETHAIdx]->ulEATASHCC = LpHwUnitConfig->stTASConfig.ulTxJitter;
  /* TAS setting flow */
  /* In order for TAS to function, it is necessary to acquire the AVTP timer value. */
  /* At this timing, the AVTP timer value cannot be obtained, */
  /* so the TAS setting flow is executed every time the controller is activated. */
}

/***********************************************************************************************************************
** Function Name         : RMAC_InitializationFlow (RSW3)
**
** Service ID            : N/A
**
** Description           : RMAC Initialization Flow
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulRMACIdx : RMAC index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaRsw3PortCtrlIdx,
**                         Eth_GpEthConfigPtr, Eth_GaaRSW3_RMACRegs,
**                         Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : MRMAC0, MRMAC1, MPIC, MTFFC, MTPFC, MTPFC2,
**                         MTPFC3t, MRGC, MRFSCE, MRFSCP, MTRC
**
** Reference ID          : ETH_DUD_ACT_3086
** Reference ID          : ETH_DUD_ACT_3086_GBL001, ETH_DUD_ACT_3086_GBL002, ETH_DUD_ACT_3086_GBL003
** Reference ID          : ETH_DUD_ACT_3086_GBL004, ETH_DUD_ACT_3086_GBL005, ETH_DUD_ACT_3086_GBL006
** Reference ID          : ETH_DUD_ACT_3086_REG001, ETH_DUD_ACT_3086_REG002, ETH_DUD_ACT_3086_REG003
** Reference ID          : ETH_DUD_ACT_3086_REG004, ETH_DUD_ACT_3086_REG005, ETH_DUD_ACT_3086_REG006
** Reference ID          : ETH_DUD_ACT_3086_REG007, ETH_DUD_ACT_3086_REG008, ETH_DUD_ACT_3086_REG009
** Reference ID          : ETH_DUD_ACT_3086_REG010, ETH_DUD_ACT_3086_REG011, ETH_DUD_ACT_3086_REG012
** Reference ID          : ETH_DUD_ACT_3086_REG013
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) RMAC_InitializationFlow(
  CONST(uint32, AUTOMATIC) LulRMACIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */

  uint32 LulRegVal = ETH_RSW3_RMAC_MPIC_2_5GB;
  uint32 LulCtrlIdx;
  Eth_MediaInterfaceType LenEthPHYInterface;
  Eth_MacLayerSpeedType LenEthSpeed;
  Eth_OptionType LenInternalLoopBackMode;

  LulCtrlIdx = Eth_GaaRsw3PortCtrlIdx[ETH_CONV_RMACID_TO_PORTID(LulRMACIdx)];                                           /* PRQA S 3469 # JV-01 */
  /* Set MAC address write MRMAC0/MRMAC1 */
  /* MRAMAC0 Set */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRMAC0 =
    Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 >> 16UL;
  /* MRAMAC1 Set */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRMAC1 =
    (Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 << 16UL) | Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulL16;

  /* Config MAC Loopback mode */
  LenInternalLoopBackMode = Eth_GpEthConfigPtr[LulCtrlIdx].enInternalLoopBackMode;
  if (ETH_ENABLE == LenInternalLoopBackMode)
  {
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMLBC = ETH_RSW3_RMAC_MLBC_LBM;
  } /* else: No action required */

  /* Set xMII type write MPIC.PIS, MPIC.LSC */
  LenEthSpeed = Eth_GpEthConfigPtr[LulCtrlIdx].enEthSpeed;
  if (ETH_MAC_LAYER_SPEED_10G == LenEthSpeed)
  {
    LulRegVal = ETH_RSW3_RMAC_MPIC_10GB;
  }
  else if (ETH_MAC_LAYER_SPEED_5G == LenEthSpeed)
  {
    LulRegVal = ETH_RSW3_RMAC_MPIC_5GB;
  }
  else if (ETH_MAC_LAYER_SPEED_2500M == LenEthSpeed)
  {
    LulRegVal = ETH_RSW3_RMAC_MPIC_2_5GB;
  }
  else if (ETH_MAC_LAYER_SPEED_1G == LenEthSpeed)
  {
    LulRegVal = ETH_RSW3_RMAC_MPIC_1GB;
  }
  else if (ETH_MAC_LAYER_SPEED_100M == LenEthSpeed)
  {
    LulRegVal = ETH_RSW3_RMAC_MPIC_100MB;
  }
  else
  {
    LulRegVal = ETH_RSW3_RMAC_MPIC_10MB;
  }
  /* PHY Interface Setting  */
  LenEthPHYInterface = Eth_GpEthConfigPtr[LulCtrlIdx].enEthPHYInterface;
  if (ETH_USXGMII == LenEthPHYInterface)
  {
    LulRegVal |= ETH_RSW3_RMAC_MPIC_XGMII;
  }
  else if ((ETH_SGMII == LenEthPHYInterface) || (ETH_GMII == LenEthPHYInterface))
  {
    LulRegVal |= ETH_RSW3_RMAC_MPIC_GMII;
  }
  else
  {
    /* No action required */
  }

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Set Station Management Clock write MPIC.PSMCS */
  LulRegVal |=
    (uint32)(((uint32)LpHwUnitConfig->stPHYConfig.enPSMCaptureTime    << 28UL) |  /* Capture time    */
             ((uint32)LpHwUnitConfig->stPHYConfig.enPSMHoldTime       << 24UL) |  /* Hold time       */
             (LpHwUnitConfig->stPHYConfig.ulPSMClockSelection << 16UL));          /* Clock Selection */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMPIC = LulRegVal;

  /* Set RMAC IO configuration */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMIOC |= LpHwUnitConfig->stRMACIOConfig.ulMIOCConfigValue;

  /* Set Interrupt enable write MEIE, MMIE0, MMIE1, MMEI2 */

  /* Set Tx function write MTFFC, MTPFC, MTPFC2, MTPFC3_t, MTATCt */
  if (ETH_ENABLE == LpHwUnitConfig->stFlowControlConfig.enPauseFrame)
  {
    /* PAUSE mode */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTFFC = (uint32)(ETH_RSW3_RMAC_MTFFC_PAUSE << 1UL);
    /* MTPFC register
     * bit PFM=0                    : Automatic mode
     * bit PFRT=ulRetransmissionTime: Pause frame retransmission time
     * bit PT=ulPauseTime           : Pause Time
     */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC =
                                    (uint32)((LpHwUnitConfig->stFlowControlConfig.ulRetransmissionTime << 16UL) |
                                             (LpHwUnitConfig->stFlowControlConfig.ulPauseTime));
    /*
     * MTPFC2 register
     * bit PFTTZ=enPauseTimeZero : Pause Frame Transmission with TIME = 0
     */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC2 =
                                    (uint32)(((uint32)LpHwUnitConfig->stFlowControlConfig.enPauseTimeZero << 16UL));

    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC3t[0] = 0x01UL; /* level0 */
  }
  else if (ETH_ENABLE == LpHwUnitConfig->stPFCConfig.enPFCFrame)
  {
    /* PFC mode */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTFFC = (uint32)(ETH_RSW3_RMAC_MTFFC_PFC << 1UL);
    /* MTPFC register
     * bit PFM=0                    : Automatic mode
     * bit PFRT=ulRetransmissionTime: Pause frame retransmission time(PFC)
     * bit PT=ulPauseTime           : Pause Time(PFC)
     */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC =
                                    (uint32)((LpHwUnitConfig->stPFCConfig.ulRetransmissionTime << 16UL) |
                                             (LpHwUnitConfig->stPFCConfig.ulPauseTime ));
    /* MTPFC2 register
     * bit PFCTTZ[1]=enPauseTimeZero : PFC Frame Transmission with TIME = 0 PRO LVL 1
     * bit PFCTTZ[0]=enPauseTimeZero : PFC Frame Transmission with TIME = 0 PRO LVL 0
     */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC2 =
                                    (uint32)(((uint32)LpHwUnitConfig->stPFCConfig.enPauseTimeZero << 1UL) |
                                             ((uint32)LpHwUnitConfig->stPFCConfig.enPauseTimeZero));
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC3t[0] =
                                    LpHwUnitConfig->stPFCConfig.stPFCPauseLevelConfig[0].ulPausePriority; /* level0 */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTPFC3t[1] =
                                    LpHwUnitConfig->stPFCConfig.stPFCPauseLevelConfig[1].ulPausePriority; /* level1 */
  }
  else
  {
    /* No action required */
  }

  /* Set Rx function write MRGC, MRFSCE, MRFSCP, MTRC */
  if (ETH_ENABLE == LpHwUnitConfig->stFlowControlConfig.enPauseFrame)
  {
    /* PAUSE mode */
    /* MRGC register
     * bit PFRTZ=enPauseTimeZero : Pause or PFC Frame Reception with Time = 0
     * bit PFRC=enPauseFrame     : Pause Frame Reception Control
     */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRGC =
                                    (uint32)(((uint32)LpHwUnitConfig->stFlowControlConfig.enPauseTimeZero << 2UL) |
                                             ((uint32)LpHwUnitConfig->stFlowControlConfig.enPauseFrame    << 1UL));
  }
  else if (ETH_ENABLE == LpHwUnitConfig->stPFCConfig.enPFCFrame)
  {
    /* PFC mode */
    /* MRGC register
     * bit PFCRC=ulPausePriority : PFC Frame Reception Control
     * bit PFRTZ=enPauseTimeZero : Pause or PFC Frame Reception with Time = 0
     */
    Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRGC =
                  (uint32)(((LpHwUnitConfig->stPFCConfig.stPFCPauseLevelConfig[0].ulPausePriority |
                             (uint32)LpHwUnitConfig->stPFCConfig.stPFCPauseLevelConfig[1].ulPausePriority) << 16UL) |
                           ((uint32)LpHwUnitConfig->stPFCConfig.enPauseTimeZero << 2UL));
  }
  else
  {
    /* No action required */
  }

  /* Correct FCS is not passed to the MHD on current RMAC settings. (MRGC register) */
  /* So, no need to add FCS size */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRFSCE = Eth_GulRxMaxFrameSize;
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRFSCP = Eth_GulRxMaxFrameSize;

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMTRC = ETH_RSW3_RMAC_MTRC_TRHFME_ENABLE << ETH_GPTP_TIMER_DOMAIN;
  #endif

  /* Set Address Filtering function write MRSCE, MRSCP, MRAFC */
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRSCE =
    (LpHwUnitConfig->stRxConfig.ulBcastThreshold << (uint32)16U) | LpHwUnitConfig->stRxConfig.ulMcastThreshold;
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRSCP =
    (LpHwUnitConfig->stRxConfig.ulBcastThreshold << (uint32)16U) | LpHwUnitConfig->stRxConfig.ulMcastThreshold;
  LulRegVal = (((uint32)LpHwUnitConfig->stRxConfig.enBcastStormFilter << (uint32)20U) |
               ((uint32)LpHwUnitConfig->stRxConfig.enMcastStormFilter << (uint32)19U) |
               ((uint32)LpHwUnitConfig->stRxConfig.enBcastStormFilter << (uint32)4U) |
               ((uint32)LpHwUnitConfig->stRxConfig.enMcastStormFilter << (uint32)3U));
  LulRegVal |= ETH_RSW3_RMAC_MRAFC_ENABLE;
  Eth_GaaRSW3_RMACRegs[LulRMACIdx]->ulMRAFC = (uint32)(LulRegVal);

  /* Set PTP Filtering function write MPFCt */

  /* Set XGMII function write MXGMIIC, MPCH, MANMt */
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_ResetRxDesc
**
** Service ID            : NA
**
** Description           : Reset the RX descriptor
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LpRxBufferNode : Pointer to Rx buffer node
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3087
** Reference ID          : ETH_DUD_ACT_3087_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_ResetRxDesc(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode)
{
  P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                     /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint8 LucRxQueueIdx = LpRxBufferNode->ucRxQueueIdx;
  /* Get the HW config information */
  LpHwUnitConfig =
           (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;        /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Get the Rx descriptor address */
  LpDataDesc = (P2VAR(Eth_ExtRxEthDescType, AUTOMATIC, ETH_APPL_DATA)) (LpRxBufferNode->ulRxDescAddr);                  /* PRQA S 0306, 3432 # JV-01, JV-01 */

  /* Reset Rx descriptor to available for next receive */
  LpDataDesc->stHeader.ulDs =
                    LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucRxQueueIdx].ulMaxFrameSize;
  LpDataDesc->stHeader.ulInfo0 = 0U;
  LpDataDesc->stHeader.ulAxie = 0U;
  LpDataDesc->stHeader.ulDse = 0U;
  LpDataDesc->stHeader.ulErr = 0U;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  LpDataDesc->stTimestamp.ulTSNS = (uint32)0UL;
  LpDataDesc->stTimestamp.ulTSV = 0U;
  LpDataDesc->stTimestamp.ulTSD = 0U;
  LpDataDesc->stTimestamp.ulTSS = 0U;
  #endif /* ETH_GLOBAL_TIME_SUPPORT */
  LpDataDesc->stHeader.ulDt = ETH_DESC_FEMPTY;
}

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#endif /* (ETH_USING_MACRO == ETH_MACRO_ETNE) */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
