/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_Ram.c                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Global RAM variable definitions for Eth Driver an RAM allocation functions                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.25: 29/06/2026   : Update to support multicore type-II:
 *                        + Move global var Eth_GstDescChainMap, Eth_GaaRsw3PortValid and Eth_GaaRsw3PortCtrlIdx
 *                        to gentool generate
 * 1.1.24: 16/09/2025   : Update to support TSN-ES
 * 1.1.23: 25/07/2025   : Remove macro for old AUTOSAR version.
 *                      : Update Eth_GaaTxBufferMgrTable to correct the range to the same with the definition
 * 1.1.22: 03/07/2025   : Move Eth_GaaRsw3PortCtrlIdx into section VAR_NO_INIT_32
 * 1.1.21: 12/03/2025   : Update to merging SingleMainline
                          + Update global variable Eth_RswFunc remove Eth_RSW_CheckProvideBuffer,
                          Eth_RSW_CheckBufferWithPiority and add Eth_RSW_GetImmTxBuffer
                          + Function Eth_RSW_InitializeBuffer() change from stTimestamp to stTimeStamp.nanoseconds,
                          stTimeStamp.seconds, stTimeStamp.secondsHi, enTimeQual
                          + Function Eth_RSW_InitializeBuffer(), Eth_RSW_GetTxBuffer() remove blTxOngoing
                          + Function Eth_RSW_GetTxBuffer() change ucPriority to ucTxQueueIdx
                          + Add function Eth_RSW_GetImmTxBuffer() to get transmit buffer incase immediate transmit
                          + Function Eth_RSW_ReleaseTxBuffer() add release all struct items of
                          the variable Eth_GaaTxBufferNodes
                          + Remove function Eth_RSW_CheckProvideBuffer(), Eth_RSW_CheckBufferWithPiority()
                          + Function Eth_RSW_RamInit() change Eth_GaaTxBufferNodes[LulCtrlIdx][LucBufIdx].ucPriority
                          to Eth_GaaTxBufferNodes[LulCtrlIdx][LucBufIdx].ucTxQueueIdx
                          and Eth_GaaRxBufferNodes[LulCtrlIdx][LucBufIdx].ucPriority
                          to Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ucRxQueueIdx
                          + Function Eth_RSW_RamInit() add initial for blIsTxHandleId and ucTxHandleId
 * 1.1.20: 18/10/2024   : Improve implementation for Eth_CheckBufferWithPiority
 * 1.1.19: 12/09/2024   : Update to support zero TX buffer
 * 1.1.18: 13/08/2024   : Update implementation for Eth_CheckBufferWithPiority
 * 1.1.17: 28/07/2024   : Add new arrays Eth_Ctrl<n>_TxBufferData, Eth_Ctrl<n>_RxBufferData, Eth_Ctrl<n>_TxDescData,
 *                        Eth_Ctrl<n>_RxDescData, Eth_Ctrl<n>_TxBufferNode, Eth_Ctrl<n>_RxBufferNode
 *                        Eth_GaaRxBufferTotal.
 *                        Add new array of pointers Eth_GaaTxBufferNodes, Eth_GaaTxBufferDataTable, Eth_GaaTxDescTable
 *                        Eth_GaaRxBufferDataTable, Eth_GaaRxDescTable, Eth_GaaRxBufferNodes.
 *                        Remove unnecessary array Eth_GaaHeap, Eth_GaaRamSize, Eth_GaaMemPoolBuffer_<n>
 *                        Eth_GaaMemPoolBufferTable, Eth_GaaTxAllocCnt.
 *                        Update function Eth_GetTxBuffer, Eth_ReleaseTxBuffer, Eth_InitializeBuffer,
*                         Eth_CheckProvideBuffer for support static memory
 *                        Add new function Eth_CheckBufferWithPiority to support immediate transmission
 * 1.1.16: 19/06/2024   : Update new enum value for datatype TimeStampQualType
 * 1.0.2: 04/03/2024    : Remove Eth_GpGwcaRegPtr, define Eth_GpGwcaCfgPtr, Define Eth_GawcaValid
 *                        Add ETH_BOTHCORE_ENABLE to enable/disable Eth_GpBothCoreCfgPtr
 *                        Define section to support Eth port 14
 * 1.0.1: 24/11/2023    : Update to fix QAC violation
 *                        Re-Define Eth_GaaSerdesChConfig range using ETH_SERDES_CH_NUM
 * 1.0.0: 16/08/2023    : Initial Version
 */

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1502)    : The object '%1s' is defined but is not used within this project.                             */
/* Rule                : CERTCCM MSC13, CWE Rule CWE-398, CWE-569,                                                    */
/* JV-01 Justification : This is accepted, due to the module's object is exported for usage.                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1504)    : The object '%1s' is only referenced in the translation unit where it is defined.             */
/* Rule                : CERTCCM DCL15, DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                      */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1514)    : The object '%1s' is only referenced by function '%2s', in the translation unit where it is   */
/*                       defined                                                                                      */
/* Rule                : CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.9                                            */
/* JV-01 Justification : This object is used outside of this translation unit and  in other  translation unit         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-561, CWE-569,  MISRA C:2012 Rule-2.2             */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3408)    : '%1s' has external linkage and is being defined without any previous declaration.            */
/* Rule                : CERTCCM DCL07, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.4                             */
/* JV-01 Justification : It is accepted, due to the declaration will be taken care by Os                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%1s' is not modified and so the pointer       */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.13                     */
/* JV-01 Justification : Pointer variable is used to modify the value at the address so the pointer cannot be         */
/*                       declared as 'pointer to const' type.                                                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4391)    : A composite expression of 'essentially unsigned' type (%1s) is being cast to a wider         */
/*                       unsigned type, '%2s'.                                                                        */
/* Rule                : CWE Rule CWE-136,  MISRA C:2012 Rule-10.8                                                    */
/* JV-01 Justification : This casting is for the lower operator which requires wider type.                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for Eth.h inclusion and macro definitions */
#include "Eth.h"
/* Header file inclusion */
#include "Eth_RSW3_Ram.h"
#include "Eth_Ram.h"

#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
/* Included for the declaration of the critical section protection functions */
#include "SchM_Eth.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_RAM_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_RSW3_RAM_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_RSW3_RAM_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_RSW3_RAM_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_RSW3_RAM_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/

#if (ETH_RSW3_RAM_AR_RELEASE_MAJOR_VERSION != ETH_RSW3_RAM_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_RSW3_Ram.c : Mismatch in Release Major Version"
#endif
#if (ETH_RSW3_RAM_AR_RELEASE_MINOR_VERSION != ETH_RSW3_RAM_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_RSW3_Ram.c : Mismatch in Release Minor Version"
#endif
#if (ETH_RSW3_RAM_AR_RELEASE_REVISION_VERSION != ETH_RSW3_RAM_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_RSW3_Ram.c : Mismatch in Release Revision Version"
#endif


#if (ETH_RSW3_RAM_SW_MAJOR_VERSION != ETH_RSW3_RAM_C_SW_MAJOR_VERSION)
   #error "Eth_RSW3_Ram.c : Mismatch in Software Major Version"
#endif
#if (ETH_RSW3_RAM_SW_MINOR_VERSION != ETH_RSW3_RAM_C_SW_MINOR_VERSION)
   #error "Eth_RSW3_Ram.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* Global variable to store pointer to Configuration */
P2CONST(Eth_GwcaConfiguration, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpGwcaCfgPtr;                                  /* PRQA S 3432 # JV-01 */

P2CONST(Eth_GlobalPauseConfiguration, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpGlobalPauseCfgPtr;                    /* PRQA S 3432 # JV-01 */

#if (ETH_BOTHCORE_ENABLE == STD_ON)
P2CONST(Eth_BothCoreConfiguration, ETH_CONST, ETH_CONFIG_CONST) volatile Eth_GpBothCoreCfgPtr;                          /* PRQA S 3432 # JV-01 */
#endif /* ETH_BOTHCORE_ENABLE */

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/* Global variable that stores the pointer of Time Stamp Descriptor */
P2VAR(Eth_TSDescType, ETH_VAR_FAST_NO_INIT, ETH_VAR_FAST_NO_INIT) Eth_GpNextTsDesc;                                     /* PRQA S 3432 # JV-01 */
#endif

#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */


#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

VAR(boolean, ETH_VAR_INIT)Eth_GaaRsw3ETHAValid[ETH_RACE_PORT_TSNA_N] =                                                  /* PRQA S 1502, 3408 # JV-01, JV-01 */
{
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE,
  ETH_FALSE
};

VAR(boolean, ETH_VAR_INIT)Eth_GaaRsw3GWCACtrlValid = ETH_FALSE;

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

VAR(uint8, ETH_VAR_INIT)Eth_GaaGWCAValid[ETH_RSW3_GWCA_TOTAL_CONFIGURED] =
{
    #ifdef ETH_RSW3_GWCA0_USED
    ETH_RACE_ID_GWCA0,
    #endif
    #ifdef ETH_RSW3_GWCA1_USED
    ETH_RACE_ID_GWCA1
    #endif
};

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
VAR(uint32, ETH_VAR_INIT) Eth_GulRxMaxFrameSize = ETH_GWCA_MAX_PAYLOAD_SIZE;
#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_CONST_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#define ETH_STOP_SEC_CONST_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* LINKFIX table */
VAR(Eth_LinkDescType, ETH_VAR_NO_INIT) Eth_GaaLinkFixTable[ETH_RACE_AXI_CHAIN_N];

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/* Timestamp descriptor chain */
VAR(Eth_TSDescType, ETH_VAR_NO_INIT) Eth_GaaTsDescChain[ETH_MAX_TS_DESCRIPTOR + ETH_CYCLIC_DESC_NUM];
#endif

#define ETH_STOP_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */


#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

P2CONST(Eth_EthConfigType, ETH_VAR_INIT, ETH_CONFIG_CONST) volatile Eth_GaaSerdesChConfig[ETH_SERDES_CH_NUM] =          /* PRQA S 3432 # JV-01 */
{
  /* ETH_SERDES_XPCS_CH0 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH1 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH2 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH3 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH4 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH5 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH6 */
  NULL_PTR,
  /* ETH_SERDES_XPCS_CH7 */
  NULL_PTR,
};
#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* The Function table for ETND*/
VAR(Eth_HwFuncTableType, ETH_VAR_INIT) Eth_RswFunc =
{
  /* pInitializeBuffer */
  &Eth_RSW_InitializeBuffer,
  /* pPreprocessBuffer */
  &Eth_RSW_PreprocessBuffer,
  /* pGetTxBuffer */
  &Eth_RSW_GetTxBuffer,
  /* pReleaseTxBuffer */
  &Eth_RSW_ReleaseTxBuffer,
  /* pPreprocessFrame */
  &Eth_RSW_PreprocessFrame,
  /* pFindTxBufferHandler */
  &Eth_RSW_FindTxBufferHandler,
  /* pHwInit */
  &Eth_RSW_HwInit,
  /* pHwDisableController */
  &Eth_RSW_HwDisableController,
  /* pHwEnableController */
  &Eth_RSW_HwEnableController,
  /* pHwTransmit */
  &Eth_RSW_HwTransmit,
  /* pHwGetCounterValues */
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  &Eth_RSW_HwGetCounterValues,
  #endif
  /* pHwGetRxStats */
  #if (ETH_GET_RX_STATS_API == STD_ON)
  &Eth_RSW_HwGetRxStats,
  #endif
  /* pHwGetTxStats */
  #if (ETH_GET_TX_STATS_API == STD_ON)
  &Eth_RSW_HwGetTxStats,
  #endif
  /* pHwGetTxErrorCounterValues */
  #if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
  &Eth_RSW_HwGetTxErrorCounterValues,
  #endif
  /* pHwMainFunction */
  &Eth_RSW_HwMainFunction,
  /* pHwTxConfirmation */
  #if (ETH_CTRL_ENABLE_TX_POLLING == STD_ON)
  &Eth_RSW_HwTxConfirmation,
  #else
  NULL_PTR,
  #endif
  /* pHwCheckFifoIndex */
  #if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
  &Eth_RSW_HwCheckFifoIndex,
  #endif
  /* pHwReceive */
  #if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
  &Eth_RSW_HwReceive,
  #else
  NULL_PTR,
  #endif
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* pHwSetIncrementTimeForGptp */
  &Eth_RSW_HwSetIncrementTimeForGptp,
  /* pHwSetOffsetTimeForGptp */
  &Eth_RSW_HwSetOffsetTimeForGptp,
  /* pHwGetCurrentTime */
  &Eth_RSW_HwGetCurrentTime,
  /* pHwGetCurrentTimeTuple */
  &Eth_RSW_HwGetCurrentTimeTuple,
  /* pHwGetEgressTimeStamp */
  &Eth_RSW_HwGetEgressTimeStamp,
  /* pHwGetIngressTimeStamp */
  &Eth_RSW_HwGetIngressTimeStamp,
  #endif
  #if (ETH_CTRL_ENABLE_MII == STD_ON)
  /* pHwReadMii */
  &Eth_RSW_HwReadMii,
  /* pHwWriteMii */
  &Eth_RSW_HwWriteMii,
  #endif
  /* pGetImmTxBuffer */
  &Eth_RSW_GetImmTxBuffer,
  /* pResetRxDesc */
  &Eth_RSW_ResetRxDesc,
};

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_CLEARED_USER_RAM_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Eth_RSW_InitializeBuffer
**
** Service ID            : N/A
**
** Description           : Initialize the Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaRxBufferIndex
**                         Eth_GaaRxFrame, Eth_GaaTxBufferTotal
**                         Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3088
** Reference ID          : ETH_DUD_ACT_3088_GBL002, ETH_DUD_ACT_3088_GBL003
** Reference ID          : ETH_DUD_ACT_3088_GBL004, ETH_DUD_ACT_3088_GBL005
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_InitializeBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx)                              /* PRQA S 1505 # JV-01 */
{
  uint32 LulCnt;
  P2VAR(Eth_TxBufferType, AUTOMATIC, ETH_APPL_DATA) LpTxBuffer;                                                         /* PRQA S 3432 # JV-01 */

  /* Initialize resource information */
  Eth_GaaRxFrame[LulCtrlIdx].ulFrameAddr = 0UL;
  Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = 0UL;
  Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = 0UL;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds = 0UL;
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds     = 0UL;
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.secondsHi   = (uint16)0U;
  Eth_GaaRxFrame[LulCtrlIdx].enTimeQual              = INVALID;
  #endif
  /* Initialize Tx buffer index list */
  for (LulCnt = 0UL; LulCnt < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulCnt++)
  {
    LpTxBuffer = (P2VAR(Eth_TxBufferType, AUTOMATIC, ETH_APPL_DATA))&Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulCnt];       /* PRQA S 3432 # JV-01 */
    LpTxBuffer->pBufferHdr = NULL_PTR;
  }

  /* Initialize buffer counter */
  for (LulCnt = 0UL; LulCnt < ETH_TXQ_NUM; LulCnt++)
  {
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulCnt] = 0UL;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_PreprocessBuffer
**
** Service ID            : N/A
**
** Description           : Write source address to all Tx Buffers in advance
**                         because source address is never changed while
**                         a controller mode is ACTIVE.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3089
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_PreprocessBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx)                              /* PRQA S 1505 # JV-01 */
{
  /* No action required because this function is retained for RSW3 compatibility. */
  (void)LulCtrlIdx;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_GetTxBuffer
**
** Service ID            : N/A
**
** Description           : Get a buffer from the Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LucPriority
**
** InOut Parameters      : LenBytePtr
**
** Output Parameters     : LpBufIdxPtr
**                         LpBufPtr
**
** Return parameter      : BUFREQ_OK
**                         BUFREQ_E_NOT_OK
**                         BUFREQ_E_OVFL
**                         BUFREQ_E_BUSY
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GpCtrlConfigPtr
**                         Eth_GaaTxBufferTotal, Eth_GaaTxBufferNodes
**
** Function(s) invoked   : EthSwt_EthTxAdaptBufferLength,
**                         EthSwt_EthTxPrepareFrame
**                         ETH_ENTER_CRITICAL_SECTION
**                         ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3090
** Reference ID          : ETH_DUD_ACT_3090_CRT001, ETH_DUD_ACT_3090_GBL001, ETH_DUD_ACT_3090_GBL002
** Reference ID          : ETH_DUD_ACT_3090_GBL003, ETH_DUD_ACT_3090_GBL004
***********************************************************************************************************************/
FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_RSW_GetTxBuffer(                                                         /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint8*, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr)                                                              /* PRQA S 3432 # JV-01 */
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  BufReq_ReturnType LenReturnValue;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode = NULL_PTR;                                        /* PRQA S 3432 # JV-01 */
  uint32 LulRingIdx;
  uint32 LulTxBufferMax;
  uint16 LusTxPayloadMax;
  uint16 LusReqSize;
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucReturnValue;
  #endif

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Verify the input of LucPriority */
  if(LucPriority < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue)
  {
    LulTxBufferMax = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulQueueBufs;
    LusTxPayloadMax =
      (uint16)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulMaxFrameSize - ETH_HEADER_SIZE);             /* PRQA S 3383 # JV-01 */

    /* If the requested size is smaller than the minimum size, expand it to the minimum size */
    if ((uint16)ETH_MIN_PAYLOAD_SIZE > *LenBytePtr)
    {
      *LenBytePtr = (uint16)ETH_MIN_PAYLOAD_SIZE;
    } /* else no action required */

    LusReqSize = *LenBytePtr;
    #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
    /* Added Switch Management information */
    EthSwt_EthTxAdaptBufferLength(&LusReqSize);
    #endif

    if (0UL == LulTxBufferMax)
    {
      LenReturnValue = BUFREQ_E_NOT_OK;
    }
    else if (LusReqSize > LusTxPayloadMax)
    {
      /* If the requested size is larger than the buffer, return error */
      *LenBytePtr = LusTxPayloadMax - (LusReqSize - *LenBytePtr);                                                       /* PRQA S 2985 # JV-01 */
      LenReturnValue = BUFREQ_E_OVFL;
    }
    else
    {
      /* Enter the critical section protection */
      ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Get tx buffer index */
      for (LulRingIdx = 0; LulRingIdx < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulRingIdx++)
      {
        if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].ucTxQueueIdx  == LucPriority)
        {
          if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag == ETH_FALSE)
          {
            LpTxBufferNode = &Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx];
            Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag = ETH_TRUE;
            break;
          } /* else no action required */
        } /* else no action required */
      }

      /* Get the Tx buffer management node and Tx buffer */
      if (NULL_PTR != LpTxBufferNode)
      {
        /* Set next buffer index */
        Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulRingIdx].pBufferHdr = LpTxBufferNode;

        /* Get Tx buffer inforamtion based on Tx buffer node */
        *LpBufIdxPtr = (Eth_BufIdxType)LpTxBufferNode->ulbufIdx;
        *LpBufPtr = (uint8 *)(LpTxBufferNode->ulbufAddr + (uint32)ETH_HEADER_SIZE);                                     /* PRQA S 0306, 3383 # JV-01, JV-01 */
        LpTxBufferNode->ulEthTypeAddr = LpTxBufferNode->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE;                           /* PRQA S 3383 # JV-01 */

        #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
        LpDataPtr = (uint8 *)(LpTxBufferNode->ulEthTypeAddr);                                                           /* PRQA S 0306 # JV-01 */
        /* Added Switch Management information */
        LusReqSize = *LenBytePtr;
        /* Since the maximum value of controller index is 4, casting to uint8 does no problem. */
        LucReturnValue = EthSwt_EthTxPrepareFrame((uint8)LulCtrlIdx, *LpBufIdxPtr, &LpDataPtr, &LusReqSize);
        if (E_OK == LucReturnValue)
        {
          LpTxBufferNode->ulEthTypeAddr  = (uint32)LpDataPtr;                                                           /* PRQA S 0306 # JV-01 */
          *LpBufPtr = (uint8 *)((uint32)LpDataPtr + ETH_ETHERTYPE_SIZE);                                                /* PRQA S 0306, 3383 # JV-01, JV-01 */
        }
        else
        {
          /* If it is not a switch frame, use it as a normal frame */
        }
        #endif

        LenReturnValue = BUFREQ_OK;
      }
      else
      {
        LenReturnValue = BUFREQ_E_BUSY;
      }
      /* Exit the critical section protection */
      ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
    }
  }
  else
  {
    LenReturnValue = BUFREQ_E_NOT_OK;
  }

  return LenReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_GetImmTxBuffer
**
** Service ID            : N/A
**
** Description           : This function gets a buffer from the Tx buffer ring for direct transmission
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : Controller index
**                         LucPriority    : Frame priority for transmit buffer
**                         LusFrameLength : Frame length
**
** InOut Parameters      : None
**
** Output Parameters     : LpBufIdxPtr    : Pointer to the index of granted buffer resource
**                         LpBufPtr       : Pointer to the granted buffer
**
** Return parameter      : A index of acquired buffer
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GaaTxBufferTotal,
**                         Eth_GpCtrlConfigPtr, Eth_GaaTxBufferNodes
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION
**                         ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3091
** Reference ID          : ETH_DUD_ACT_3091_CRT001, ETH_DUD_ACT_3091_GBL001, ETH_DUD_ACT_3091_GBL002
** Reference ID          : ETH_DUD_ACT_3091_GBL003, ETH_DUD_ACT_3091_GBL004
***********************************************************************************************************************/
FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_RSW_GetImmTxBuffer(                                                      /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                                    /* PRQA S 3432 # JV-01 */
  CONST(uint16, AUTOMATIC) LusFrameLength)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  BufReq_ReturnType LenReturnValue;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode = NULL_PTR;                                        /* PRQA S 3432 # JV-01 */

  uint32 LulRingIdx;
  uint32 LulTxBufferMax;
  uint16 LusTxFrameLengthMax;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  
  /* Verify the input of LucPriority */
  if(LucPriority < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue)
  {
    LulTxBufferMax = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulQueueBufs;
    LusTxFrameLengthMax =
      (uint16)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulMaxFrameSize);

    if (0UL == LulTxBufferMax)
    {
      LenReturnValue = BUFREQ_E_NOT_OK;
    }
    else if (LusFrameLength > LusTxFrameLengthMax)
    {
      /* If the requested size is larger than the buffer, return error */
      LenReturnValue = BUFREQ_E_OVFL;
    }
    else
    {
      /* Enter the critical section protection */
      ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Get tx buffer index */
      for (LulRingIdx = 0; LulRingIdx < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulRingIdx++)
      {
        if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].ucTxQueueIdx  == LucPriority)
        {
          if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag == ETH_FALSE)
          {
            LpTxBufferNode = &Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx];
            Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag = ETH_TRUE;
            break;
          } /* else no action required */
        } /* else no action required */
      }

      if (NULL_PTR != LpTxBufferNode)
      {
        /* Set next buffer index */
        Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulRingIdx].pBufferHdr = LpTxBufferNode;

        /* Get Tx buffer information based on Tx buffer node */
        *LpBufIdxPtr = (Eth_BufIdxType)LpTxBufferNode->ulbufIdx;
        *LpBufAddr = LpTxBufferNode->ulbufAddr;
        LpTxBufferNode->ulEthTypeAddr = LpTxBufferNode->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE;                           /* PRQA S 3383 # JV-01 */

        LenReturnValue = BUFREQ_OK;
      }
      else
      {
        LenReturnValue = BUFREQ_E_BUSY;
      }

      /* Exit the critical section protection */
      ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
    }
  }
  else
  {
    LenReturnValue = BUFREQ_E_NOT_OK;
  }

  return LenReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_ReleaseTxBuffer
**
** Service ID            : N/A
**
** Description           : Release a Tx buffer and store it to the tail of the
**                         Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LulBufIdx      : index to the buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GaaTxBufferNodes
**                         Eth_GaaTxBufferDataTable, Eth_CtrlTxMaxFrameLengthMapping
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3092
** Reference ID          : ETH_DUD_ACT_3092_GBL001, ETH_DUD_ACT_3092_GBL002, ETH_DUD_ACT_3092_GBL003
** Reference ID          : ETH_DUD_ACT_3092_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_ReleaseTxBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx)
{
  /* Release tx buffer handler */
  Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr = NULL_PTR;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
        (uint32)&Eth_GaaTxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlTxMaxFrameLengthMapping[LulCtrlIdx]]; /* PRQA S 0306, 3384 # JV-01, JV-01 */
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulTxLength  = 0UL;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blbenableTS = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blTxConfirm = ETH_FALSE;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].enTimeQual = INVALID;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.nanoseconds = (uint32)0UL;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.seconds     = (uint32)0UL;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.secondsHi   = (uint16)0U;
  #endif
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulEthTypeAddr = 0xFFFFFFFFUL;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blUsedFlag = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId = 0UL;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_PreprocessFrame
**
** Service ID            : N/A
**
** Description           : This function sets the destination MAC address
**                         and Ethernet type for the Tx buffer.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LulBufIdx      : index to the buffer
**                         LulFrameType   : ether type
**                         LpPhysAddrPtr  : destination mac address
**                         LpPayloadLen   : payload length
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GaaCtrlStat
**
** Function(s) invoked   : EthSwt_EthTxProcessFrame
**                         ETH_ENTER_CRITICAL_SECTION
**                         ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3093
** Reference ID          : ETH_DUD_ACT_3093_CRT001, ETH_DUD_ACT_3093_GBL001, ETH_DUD_ACT_3093_GBL002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_PreprocessFrame(                                                                   /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulFrameType,
  CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen)                                                            /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  P2VAR(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpBufPtr;                                                               /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                  /* PRQA S 3432, 3678 # JV-01, JV-01 */
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  uint16 LusTxLength;
  Std_ReturnType LucReturnValue;
  #endif

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Get Tx buffer address */
  LpBufHandlerPtr = Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  LpBufPtr = (Eth_DataType *)LpBufHandlerPtr->ulbufAddr;                                                                /* PRQA S 0306 # JV-01 */

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  LpDataPtr = (P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))(LpBufHandlerPtr->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE);          /* PRQA S 0306, 3383, 3432 # JV-01, JV-01, JV-01 */
  /* Since the maximum value of buffer size is 1518, casting to uint16 does no problem. */
  LusTxLength = *LpPayloadLen;
  /* decreased by the management information length */
  /* Since the maximum value of controller index is 4, casting to uint8 does no problem. */
  LucReturnValue = EthSwt_EthTxProcessFrame((uint8)LulCtrlIdx, LpBufHandlerPtr->ulbufIdx, &LpDataPtr, &LusTxLength);
  if (E_OK == LucReturnValue)
  {
    LpBufPtr = (Eth_DataType *)(LpBufHandlerPtr->ulEthTypeAddr -                                                        /* PRQA S 0306, 3383 # JV-01, JV-01 */
                    (ETH_SRC_DST_ADDRESS_SIZE + (uint32)(LusTxLength - *LpPayloadLen)));                                /* PRQA S 3383, 4391 # JV-01, JV-01 */
    LpBufHandlerPtr->ulbufAddr = (uint32)LpBufPtr;                                                                      /* PRQA S 0306 # JV-01 */
    *LpPayloadLen = LusTxLength;
  }
  else
  {
    /* If EthSwt_SetMgmtInfo is not called, normal operation */
  }
  #else
  (void)LpPayloadLen;
  #endif

  /* Copy destination address */
  ETH_COPY_MAC_ADDRESS((CONST(uint8, AUTOMATIC) *)LpPhysAddrPtr, (uint8 *)LpBufPtr);                                    /* PRQA S 3469 # JV-01 */
  LpBufPtr = LpBufPtr + ETH_MACADDR_SIZE;                                                                               /* PRQA S 0488 # JV-01 */

  ETH_UNPACK_ADDRESS_TO_8(Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr, LpBufPtr);                                             /* PRQA S 3469 # JV-01 */
  LpBufPtr = LpBufPtr + ETH_MACADDR_SIZE;                                                                               /* PRQA S 0488, 2982 # JV-01, JV-01 */

  /* Casted to uint8 to extract the required 1 byte. */
  LpBufPtr = (Eth_DataType *)LpBufHandlerPtr->ulEthTypeAddr;                                                            /* PRQA S 0306 # JV-01 */
  *LpBufPtr = (Eth_DataType)((uint8)(LulFrameType >> ETH_BYTE_BITS));
  LpBufPtr++;
  /* Casted to uint8 to extract the required 1 byte. */
  *LpBufPtr = (Eth_DataType)((uint8)LulFrameType);

}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_FindTxBufferHandler
**
** Service ID            : NA
**
** Description           : This get the tx buffer handler associated with
**                         the specified buffer index.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of controller
**                         LulBufIdx  - Index of tx buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Pointer of Buffer handle
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3094
** Reference ID          : ETH_DUD_ACT_3094_GBL001
***********************************************************************************************************************/
FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE) Eth_RSW_FindTxBufferHandler(                                               /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx)
{
  return Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;
}

/***********************************************************************************************************************
** Function Name         : Eth_RSW_RamInit
**
** Service ID            : NA
**
** Description           : This Initialize base address of RAM for application
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LpBaseAddr - Start Address for the Ram
**                       : LulRamSize - size of all available memory (in Byte)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr
**                         Eth_GaaTxBufferNodes, Eth_GaaRxBufferNodes
**                         Eth_GaaTxBufferDataTable, Eth_CtrlTxMaxFrameLengthMapping
**                         Eth_GaaRxBufferDataTable, Eth_CtrlRxMaxFrameLengthMapping
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3095
** Reference ID          : ETH_DUD_ACT_3095_GBL001, ETH_DUD_ACT_3095_GBL002, ETH_DUD_ACT_3095_GBL003
** Reference ID          : ETH_DUD_ACT_3095_GBL004, ETH_DUD_ACT_3095_GBL005, ETH_DUD_ACT_3095_GBL006
** Reference ID          : ETH_DUD_ACT_3095_GBL007
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RSW_RamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulBufIdx;
  uint8 LucQueIdx;
  uint8 LucLoopIdx;

  LpHwUnitConfig =
    (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  LulBufIdx = 0;

  /* Seting initial value for each Tx buffer node to manage each Tx buffer */
  for (LucQueIdx = 0; LucQueIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucQueIdx++)
  {
    for (LucLoopIdx = 0; LucLoopIdx < LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucQueIdx].ulQueueBufs; LucLoopIdx++)
    {
      /* Init node information */
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufIdx = LulBufIdx;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
        (uint32)&Eth_GaaTxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlTxMaxFrameLengthMapping[LulCtrlIdx]]; /* PRQA S 0306, 3384 # JV-01, JV-01 */
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulTxLength  = 0U;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxQueueIdx  = LucQueIdx;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blbenableTS = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blTxConfirm = ETH_FALSE;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].enTimeQual = INVALID;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.nanoseconds = (uint32)0UL;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.seconds     = (uint32)0UL;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.secondsHi   = (uint16)0U;
      #endif
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulEthTypeAddr = 0xFFFFFFFFUL;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blUsedFlag = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId = 0UL;
      LulBufIdx++;                                                                                                      /* PRQA S 3383 # JV-01 */
    }
  }

  LulBufIdx = 0;
  /* Seting initial value for each Rx buffer node to manage each Rx buffer */
  for (LucQueIdx = 0; LucQueIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LucQueIdx++)
  {
    for (LucLoopIdx = 0; LucLoopIdx < LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucQueIdx].ulQueueBufs; LucLoopIdx++)
    {
      /* Init node information */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufIdx = LulBufIdx;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
        (uint32)&Eth_GaaRxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlRxMaxFrameLengthMapping[LulCtrlIdx]]; /* PRQA S 0306, 3384 # JV-01, JV-01 */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ucRxQueueIdx = LucQueIdx;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].blLockedFlag = ETH_FALSE;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].blRxConfirm = ETH_FALSE;
      LulBufIdx++;                                                                                                      /* PRQA S 3383 # JV-01 */
    }
  }
}
#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
