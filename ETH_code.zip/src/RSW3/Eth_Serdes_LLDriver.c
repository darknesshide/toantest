/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Serdes_LLDriver.c                                                                               */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Ethernet SERDES specific operations of                                                          */
/* Eth Driver Component.                                                                                              */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.23: 16/09/2025    : Update correct macro vesion
 * 1.1.22: 09/06/2025    : Remove function: Eth_Serdes_AssertSRstPhy(), Eth_Serdes_WaitForUpdate(),
 *                          Eth_Serdes_ChBpsSet_SGMII_ANON(), Eth_Serdes_ChBpsSet_SGMII_ANOFF(),
 *                          Eth_Serdes_ChBpsSet_USXGMII_ANON(), Eth_Serdes_ChBpsSet_USXGMII_ANOFF(),
 *                          Eth_Serdes_Combination_SettingSGMII(), Eth_Serdes_Combination_SettingUSXGMII(),
 *                          Eth_Serdes_Combination_Setting()
 *                         Add function: Eth_Serdes_PollingBit(), Eth_Serdes_ChXSet_USXGMII_ANOFF()
 *                         Update function: Eth_Serdes_InitializeSRAM(), Eth_Serdes_ChXSet_USXGMII_common(),
 *                          Eth_Serdes_ChXSet_USXGMII_ANON(), Eth_Serdes_ChXSet_SGMII_common(),
 *                          Eth_Serdes_ChXSet_SGMII_ANON()
 * 1.1.21: 19/11/2024    : Update new function Eth_Serdes_ChXSet_USXGMII_ANON, Eth_Serdes_ChXSet_USXGMII_common
                           Eth_Serdes_ChBpsSet_USXGMII_ANOFF, Eth_Serdes_Initialize
 * 1.0.1: 12/21/2023     : Define macro for RSW3: ETH_SERDES_XPCSn(n=0..7)_BASE
 *                         Define macro for RSW3: ETH_SERDES_XPCSn(n=0..7)_BANK
 *                         Remove use ETH_VPF and  X5H_VDK_ETH_USED macro
 * 1.0.0: 16/08/2023     : Initial Version
 */
/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0303)    : Cast between a pointer to volatile object and an integral type.                              */
/* Rule                : CERTCCM INT36, CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-11.4                             */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-561, CWE-569,  MISRA C:2012 Rule-2.2             */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_Types.h"
#include "Eth_Ram.h"
#include "Eth_RSW3_Ram.h"
#include "Eth_RSW3_LLDriver.h"
#include "Eth_Serdes_LLDriver.h"

#if (ETH_MACRO_RSW3 == STD_ON)

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_RSW3_SERDES_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_RSW3_SERDES_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_RSW3_SERDES_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_RSW3_SERDES_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_RSW3_SERDES_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (ETH_RSW3_SERDES_AR_RELEASE_MAJOR_VERSION != ETH_RSW3_SERDES_C_AR_RELEASE_MAJOR_VERSION)
#error "Eth_Serdes_LLDriver.c : Mismatch in Release Major Version"
#endif
#if (ETH_RSW3_SERDES_AR_RELEASE_MINOR_VERSION != ETH_RSW3_SERDES_C_AR_RELEASE_MINOR_VERSION)
#error "Eth_Serdes_LLDriver.c : Mismatch in Release Minor Version"
#endif
#if (ETH_RSW3_SERDES_AR_RELEASE_REVISION_VERSION != ETH_RSW3_SERDES_C_AR_RELEASE_REVISION_VERSION)
#error "Eth_Serdes_LLDriver.c : Mismatch in Release Revision Version"
#endif

#if (ETH_RSW3_SERDES_SW_MAJOR_VERSION != ETH_RSW3_SERDES_C_SW_MAJOR_VERSION)
#error "Eth_Serdes_LLDriver.c : Mismatch in Software Major Version"
#endif
#if (ETH_RSW3_SERDES_SW_MINOR_VERSION != ETH_RSW3_SERDES_C_SW_MINOR_VERSION)
#error "Eth_Serdes_LLDriver.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                              MISRA C Rule Violations                                               **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    QAC Warning                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/

#define ETH_START_SEC_CONST_UNSPECIFIED
#include "Eth_MemMap.h"

/* Ethernet SERDES register Base Address */
STATIC CONST(uint32, ETH_CONST) Eth_GaaSerdesBaseAddr[ETH_SERDES_CH_NUM] =
{
  ETH_SERDES_XPCS0_BASE,
  ETH_SERDES_XPCS1_BASE,
  ETH_SERDES_XPCS2_BASE,
  ETH_SERDES_XPCS3_BASE,
  ETH_SERDES_XPCS4_BASE,
  ETH_SERDES_XPCS5_BASE,
  ETH_SERDES_XPCS6_BASE,
  ETH_SERDES_XPCS7_BASE
};

STATIC CONST(uint32, ETH_CONST) Eth_GaaSerdesBankAddr[ETH_SERDES_CH_NUM] =
{
  ETH_SERDES_XPCS0_BANK,
  ETH_SERDES_XPCS1_BANK,
  ETH_SERDES_XPCS2_BANK,
  ETH_SERDES_XPCS3_BANK,
  ETH_SERDES_XPCS4_BANK,
  ETH_SERDES_XPCS5_BANK,
  ETH_SERDES_XPCS6_BANK,
  ETH_SERDES_XPCS7_BANK
};


#define ETH_STOP_SEC_CONST_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_PollingBit(
  CONST(uint32, AUTOMATIC) LulChannel,
  CONST(uint32, AUTOMATIC) LulBank,
  CONST(uint32, AUTOMATIC) LulOffset,
  CONST(uint32, AUTOMATIC) LulMask,
  CONST(uint32, AUTOMATIC) LulExpVal);
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_InitializeSRAM(CONST(uint32, AUTOMATIC) LulChannel);
STATIC  FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_USXGMII_common(CONST(uint32, AUTOMATIC) LulChannel);
STATIC  FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_USXGMII_ANON(
  CONST(uint32, AUTOMATIC) LulChannel,
  CONST(Eth_MacLayerSpeedType, AUTOMATIC) LenSpeed
);
STATIC  FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_USXGMII_ANOFF(
  CONST(uint32, AUTOMATIC) LulChannel,
  CONST(Eth_MacLayerSpeedType, AUTOMATIC) LenSpeed
);
STATIC  FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_SGMII_common(CONST(uint32, AUTOMATIC) LulChannel);
STATIC  FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_SGMII_ANON(CONST(uint32, AUTOMATIC) LulChannel);

/***********************************************************************************************************************
** Function Name         : Eth_Serdes_PollingBit
**
** Service ID            : N/A
**
** Description           : Wait for the register to be updated
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : GetCounterValue, GetElapsedValue
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3100
** Reference ID          : ETH_DUD_ACT_3100_GBL001, ETH_DUD_ACT_3100_GBL002
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_PollingBit(
  CONST(uint32, AUTOMATIC) LulChannel,
  CONST(uint32, AUTOMATIC) LulBank,
  CONST(uint32, AUTOMATIC) LulOffset,
  CONST(uint32, AUTOMATIC) LulMask,
  CONST(uint32, AUTOMATIC) LulExpVal)
{
  TickType LulStartCount;
  TickType LulElapCount;
  TickType LulCurTime;
  Std_ReturnType LucRetVal;
  uint32 LulRegVal;
  
  ETH_SERDES_SEL_BANK(LulChannel, LulBank);                                                                             /* PRQA S 0303, 3432 # JV-01, JV-01 */
  LulStartCount = 0;
  LulElapCount = 0;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulStartCount);
  do
  {
    LulCurTime = LulStartCount;
    LulRegVal = ETH_SERDES_REG_READ(LulChannel, LulOffset);                                                             /* PRQA S 0303, 3383, 3432 # JV-01, JV-01, JV-01 */
    (void)GetElapsedValue(ETH_OS_COUNTER_ID, &LulCurTime, &LulElapCount);
  } while (((LulRegVal & LulMask) != LulExpVal) && (ETH_TIMEOUT_COUNT > LulElapCount));

  if ((LulRegVal & LulMask) != LulExpVal)
  {
    /* Timeout */
    LucRetVal = E_NOT_OK;
  }
  else
  {
    LucRetVal = E_OK;
  }

  return LucRetVal;
}
/***********************************************************************************************************************
** Function Name         : Eth_Serdes_Initialize
**
** Service ID            : N/A
**
** Description           : Initialize a Ethernet SERDES HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaSerdesChConfig
**
** Function(s) invoked   : Eth_Serdes_InitializeSRAM, Eth_Serdes_ChXSet_USXGMII_common
**                         Eth_Serdes_ChXSet_USXGMII_ANON, Eth_Serdes_ChXSet_USXGMII_ANOFF
**                         Eth_Serdes_ChXSet_SGMII_common, Eth_Serdes_ChXSet_SGMII_ANON
**                         Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H03C0
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H03D0
**
** Reference ID          : ETH_DUD_ACT_3096
** Reference ID          : ETH_DUD_ACT_3096_GBL001, ETH_DUD_ACT_3096_GBL002, ETH_DUD_ACT_3096_GBL003
** Reference ID          : ETH_DUD_ACT_3096_REG001, ETH_DUD_ACT_3096_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_Initialize(CONST(uint32, AUTOMATIC) LulChannel)
{
  Std_ReturnType LucRetVal;
  LucRetVal = E_OK;                                                                                                     /* PRQA S 2982 # JV-01 */

  /* Step 1: Initialize SRAM, (for each lane) */
  LucRetVal = Eth_Serdes_InitializeSRAM(LulChannel);
  if (LucRetVal == E_OK)
  {
    if (ETH_USXGMII == Eth_GaaSerdesChConfig[LulChannel]->enEthPHYInterface)
    {
      /* In the case of using all ch as USXGMII mode (common setting) (Step U.2.1 to U.2.18) */
      LucRetVal = Eth_Serdes_ChXSet_USXGMII_common(LulChannel);
      if (LucRetVal == E_OK)
      {
        if (ETH_ENABLE == Eth_GaaSerdesChConfig[LulChannel]->enAutoNegotiation)
        {
          /* In the case of using all ch as USXGMII mode for Auto negotiation ON (Step UA.2.1 to UA.2.10) */
          LucRetVal = Eth_Serdes_ChXSet_USXGMII_ANON(LulChannel, Eth_GaaSerdesChConfig[LulChannel]->enEthSpeed);
        }
        else
        {
          /* In the case of using all ch as USXGMII mode for Auto negotiation OFF (Step U.2.19 to UA.2.21) */
          LucRetVal = Eth_Serdes_ChXSet_USXGMII_ANOFF(LulChannel, Eth_GaaSerdesChConfig[LulChannel]->enEthSpeed);
        }
      } /* Do nothing */
    }
    else
    {
      /* In the case of using all ch as SGMII mode (common setting) (Step S.2.1 to S.2.14) */
      LucRetVal = Eth_Serdes_ChXSet_SGMII_common(LulChannel);
      if (LucRetVal == E_OK)
      {
        if (ETH_ENABLE == Eth_GaaSerdesChConfig[LulChannel]->enAutoNegotiation)
        {
          /* In the case of using all ch as SGMII mode with Auto negotiation ON (Step SA.2.1 to SA.2.4) */
          LucRetVal = Eth_Serdes_ChXSet_SGMII_ANON(LulChannel);
        }
        else
        {
          /* In the case of using all ch as SGMII mode with Auto negotiation OFF (Step S.2.1 to S.2.14) */
          /* TODO: Eth_Serdes_ChXSet_SGMII_ANOFF(); */
        }
      } /* Do nothing */
    }
  } /* Do nothing */


  if (LucRetVal == E_OK)
  {
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H03C0, 0x0000U);                              /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */

    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H03D0, 0x0000U);                              /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  }

  return LucRetVal;
}

/***********************************************************************************************************************
** Function Name         : Eth_Serdes_ChXSet_SGMII_common
**
** Service ID            : N/A
**
** Description           : Set ch X settings for SGMII
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulChannel     : XPCS Channel No.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H001C
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0258
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H01DC
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00F8
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0248
**                         ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0040
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0014
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00D8
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00DC
**
** Reference ID          : ETH_DUD_ACT_3101
** Reference ID          : ETH_DUD_ACT_3101_GBL001, ETH_DUD_ACT_3101_GBL002, ETH_DUD_ACT_3101_REG001
** Reference ID          : ETH_DUD_ACT_3101_REG002, ETH_DUD_ACT_3101_REG003, ETH_DUD_ACT_3101_REG004
** Reference ID          : ETH_DUD_ACT_3101_REG005, ETH_DUD_ACT_3101_REG006, ETH_DUD_ACT_3101_REG007
** Reference ID          : ETH_DUD_ACT_3101_REG008, ETH_DUD_ACT_3101_REG009, ETH_DUD_ACT_3101_REG010
** Reference ID          : ETH_DUD_ACT_3101_REG011, ETH_DUD_ACT_3101_REG012
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_SGMII_common(CONST(uint32, AUTOMATIC) LulChannel)
{
  Std_ReturnType LucRetVal;

  /* Step S.2.1: ch X bank = H0300, (ch X Base Address + H001c) = H0000_0001 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H001C, 0x0001U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.2: ch X bank = H0380, (ch X Base Address + H0000) = H0000_2000 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000, 0x2000U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.3: ch X bank = H1f00, (ch X Base Address + H0000) = H0000_0140 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x0140U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.4: ch X bank = H0180, (ch X Base Address + H0258) = H0000_0018 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0258, 0x0018U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.5: ch X bank = H0180, (ch X Base Address + H01dc) = H0000_000d */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H01DC, 0x000DU);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.6: ch X bank = H0180, (ch X Base Address + H00f8) = H0000_0016 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00F8, 0x0016U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.7: ch X bank = H0180, (ch X Base Address + H0248) = H0000_0016 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0248, 0x0016U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.8: ch X bank = H0300, (ch X Base Address + H0000) = H0000_0c40 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000, 0x0C40U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step S.2.9: ch X bank = H0380, (ch X Base Address + H0040) polling bit[4:2] till 3b110 */
  LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0040,
                                            (uint32)(ETH_BIT(4UL) | ETH_BIT(3UL) | ETH_BIT(2UL)), (uint32)(6UL << 2UL));
  if(E_OK == LucRetVal)
  {
    /* Step S.2.10: ch X bank = H0300, (ch X Base Address + H0000) = H0000_0440 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000, 0x0440U);                              /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    /* Step S.2.11: ch X bank = H0380, (ch X Base Address + H0040) polling bit[4:2] till 3b100 */
    LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0040,
                                            (uint32)(ETH_BIT(4UL) | ETH_BIT(3UL) | ETH_BIT(2UL)), (uint32)(4UL << 2UL));
    if(E_OK == LucRetVal)
    {
      /* Step S.2.12: ch X bank = H0380, (ch X Base Address + H0014) = H0000_0050 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0014, 0x0050U);                            /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
      /* Step S.2.13: ch X bank = H0180, (ch X Base Address + H00d8) = H0000_3000 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00D8, 0x3000U);                            /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
      /* Step S.2.14: ch X bank = H0180, (ch X Base Address + H00dc) = H0000_0000 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00DC, 0x0000U);                            /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
    }
  }

  return LucRetVal;
}
/***********************************************************************************************************************
** Function Name         : Eth_Serdes_ChXSet_SGMII_ANON
**
** Service ID            : N/A
**
** Description           : Set ch X settings for SGMII (AN ON)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulChannel     : XPCS Channel No.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0004
**                         ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0008
**
** Reference ID          : ETH_DUD_ACT_3102
** Reference ID          : ETH_DUD_ACT_3102_GBL001, ETH_DUD_ACT_3102_GBL002, ETH_DUD_ACT_3102_REG001
** Reference ID          : ETH_DUD_ACT_3102_REG002, ETH_DUD_ACT_3102_REG003, ETH_DUD_ACT_3102_REG004
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_SGMII_ANON(CONST(uint32, AUTOMATIC) LulChannel)
{
  Std_ReturnType LucRetVal;
  /* Step SA.2.1: ch X bank = H1f80, (ch X Base Address + H0004) = H0000_0005 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0004, 0x0005U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step SA.2.2: ch X bank = H1f80, (ch X Base Address + H0000) = H0000_2200 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0000, 0x2200U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step SA.2.3: ch X bank = H1f00, (ch X Base Address + H0000) = H0000_3140 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x3140U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step SA.2.4: ch X bank = H1f80, (ch X Base Address + H0008) polling bit[0] till 1 */
  LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0008, ETH_BIT(0UL), 1UL);
  return LucRetVal;
}

/***********************************************************************************************************************
** Function Name         : Eth_Serdes_ChXSet_USXGMII_common
**
** Service ID            : N/A
**
** Description           : Set ch X settings for USXGMII
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulChannel     : XPCS Channel No.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H001C
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H001C
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0258
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H01DC
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00F8
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0248
**                         ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0040
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0014
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00D8
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00DC
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0080
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0170
**                         ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0260
**
** Reference ID          : ETH_DUD_ACT_3103
** Reference ID          : ETH_DUD_ACT_3103_GBL001, ETH_DUD_ACT_3103_GBL002, ETH_DUD_ACT_3103_REG001
** Reference ID          : ETH_DUD_ACT_3103_REG002, ETH_DUD_ACT_3103_REG003, ETH_DUD_ACT_3103_REG004
** Reference ID          : ETH_DUD_ACT_3103_REG005, ETH_DUD_ACT_3103_REG006, ETH_DUD_ACT_3103_REG007
** Reference ID          : ETH_DUD_ACT_3103_REG008, ETH_DUD_ACT_3103_REG009, ETH_DUD_ACT_3103_REG010
** Reference ID          : ETH_DUD_ACT_3103_REG011, ETH_DUD_ACT_3103_REG012, ETH_DUD_ACT_3103_REG013
** Reference ID          : ETH_DUD_ACT_3103_REG014, ETH_DUD_ACT_3103_REG015
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_USXGMII_common(
  CONST(uint32, AUTOMATIC) LulChannel
)
{
  Std_ReturnType LucRetVal;
  /* Step U.2.1: ch X bank = H0300, (ch X Base Address + H001c) = H0000_0000 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H001C, 0x0000U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.2: ch X bank = H0380, (ch X Base Address + H001c) = H0000_0000 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H001C, 0x0000U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.3: ch X bank = H0380, (ch X Base Address + H0000) = H0000_2200 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000, 0x2200U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.4: ch X bank = H0180, (ch X Base Address + H0258) = H0000_0018 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0258, 0x0018U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.5: ch X bank = H0180, (ch X Base Address + H01dc) = H0000_000d */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H01DC, 0x000DU);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.6: ch X bank = H0180, (ch X Base Address + H00f8) = H0000_001b */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00F8, 0x001BU);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.7: ch X bank = H0180, (ch X Base Address + H0248) = H0000_001b */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0248, 0x001BU);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.8: ch X bank = H0300, (ch X Base Address + H0000) = H0000_0c40 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000, 0x0C40U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step U.2.9: ch X bank = H0380, (ch X Base Address + H0040) polling bit[4:2] till 3b110 */
  LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0040,
                                            (uint32)(ETH_BIT(4UL) | ETH_BIT(3UL) | ETH_BIT(2UL)), (uint32)(6UL << 2UL));
  if(E_OK == LucRetVal)
  {
    /* Step U.2.10: ch X bank = H0300, (ch X Base Address + H0000) = H0000_0440 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000, 0x0440U);                              /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    /* Step U.2.11: ch X bank = H0380, (ch X Base Address + H0040) polling bit[4:2] till 3b100 */
    LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0040,
                                            (uint32)(ETH_BIT(4UL) | ETH_BIT(3UL) | ETH_BIT(2UL)), (uint32)(4UL << 2UL));
    if(E_OK == LucRetVal)
    {
      /* Step U.2.12: ch X bank = H0380, (ch X Base Address + H0014) = H0000_0050 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0014, 0x0050U);                            /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
      /* Step U.2.13: ch X bank = H0180, (ch X Base Address + H00d8) = H0000_1800 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00D8, 0x1800U);                            /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
      /* Step U.2.14: ch X bank = H0180, (ch X Base Address + H00dc) = H0000_0012 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H00DC, 0x0012U);                            /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
      /* Step U.2.15: ch X bank = H0180, (ch X Base Address + H0080) polling bit[12] till 1 */
      LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0080,
                                                                  ETH_BIT(12UL), (uint32)(1UL << 12UL));
      if(E_OK == LucRetVal)
      {
        /* Step U.2.16: ch X bank = H0180, (ch X Base Address + H0170) = H0000_1000 */
        ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0170, 0x01000U);                         /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
        /* Step U.2.17: ch X bank = H0180, (ch X Base Address + H0260) polling bit[12] till 1 */
        LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0260,
                                                                  ETH_BIT(12UL), (uint32)(1UL << 12UL));
        if(E_OK == LucRetVal)
        {
          /* Step U.2.18: ch X bank = H0180, (ch X Base Address + H0170) = H0000_0000 */
          ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H0170, 0x00000U);                       /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
        }
      }
    }
  }
  return LucRetVal;
}

/***********************************************************************************************************************
** Function Name         : Eth_Serdes_ChXSet_USXGMII_ANON
**
** Service ID            : N/A
**
** Description           : Set ch X settings for USXGMII (AN ON)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulChannel     : XPCS Channel No.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0004
**                         ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0028
**                         ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0008
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000
**
** Reference ID          : ETH_DUD_ACT_3104
** Reference ID          : ETH_DUD_ACT_3104_GBL001, ETH_DUD_ACT_3104_GBL002, ETH_DUD_ACT_3104_REG001
** Reference ID          : ETH_DUD_ACT_3104_REG002, ETH_DUD_ACT_3104_REG003, ETH_DUD_ACT_3104_REG004
** Reference ID          : ETH_DUD_ACT_3104_REG005, ETH_DUD_ACT_3104_REG006
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_USXGMII_ANON(
  CONST(uint32, AUTOMATIC) LulChannel,
  CONST(Eth_MacLayerSpeedType, AUTOMATIC) LenSpeed
)
{
  Std_ReturnType LucRetVal = E_NOT_OK;
  /* Step UA.2.1: ch X bank = H1f80, (ch X Base Address + H0004) = H0000_0001 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0004, 0x0001U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step UA.2.2: ch X bank = H1f80, (ch X Base Address + H0028) = H0000_0001 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0028, 0x0001U);                                /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
  /* Step UA.2.3: ch X bank = H1f80, (ch X Base Address + H0000) = H0000_2008 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0000, 0x2008U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step UA.2.4: ch X bank = H1f00, (ch X Base Address + H0000) = H0000_3140 */
  ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x3140U);                                /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
  /* Step UA.2.5: ch X bank = H1f80, (ch X Base Address + H0008) polling bit[0] till 1 */
  LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0008, ETH_BIT(0UL), 1UL);
  if(E_OK == LucRetVal)
  {
    /* Step UA.2.6: ch X bank = H1f80, (ch X Base Address + H0008) = H0000_0000 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F80, ETH_SERDES_OFS_H0008, 0x0000U);                              /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */

    if (ETH_MAC_LAYER_SPEED_10G == LenSpeed)
    {
      /* Step UA.2.7: ch X bank = H1f00, (ch X Base Address + H0000) = H0000_2140 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x2140U);                            /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    }
    else if (ETH_MAC_LAYER_SPEED_2500M == LenSpeed)
    {
      /* Step UA.2.8: ch X bank = H1f00, (ch X Base Address + H0000) = H0000_0120 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x0120U);                            /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    }
    else
    {
      /* invalid config */
      LucRetVal = E_NOT_OK;
    }

    if(E_OK == LucRetVal)
    {
      /* Step UA.2.9: ch X bank = H0380, (ch X Base Address + H0000) = H0000_2600 */
      ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000, 0x2600U);                            /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
      /* Step UA.2.10: ch X bank = H0380, (ch X Base Address + H0000) polling bit[10] till 0 */
      LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000,
                                                                                  ETH_BIT(10UL), (uint32)(0UL << 10UL));
    }
  }

  return LucRetVal;
}

/***********************************************************************************************************************
** Function Name         : Eth_Serdes_ChXSet_USXGMII_ANOFF
**
** Service ID            : N/A
**
** Description           : Set ch X settings for USXGMII (AN OFF)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulChannel     : XPCS Channel No.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000
**                         ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000
**
** Reference ID          : ETH_DUD_ACT_3105
** Reference ID          : ETH_DUD_ACT_3105_GBL001, ETH_DUD_ACT_3105_GBL002, ETH_DUD_ACT_3105_REG001
** Reference ID          : ETH_DUD_ACT_3105_REG002
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_ChXSet_USXGMII_ANOFF(
  CONST(uint32, AUTOMATIC) LulChannel,
  CONST(Eth_MacLayerSpeedType, AUTOMATIC) LenSpeed
)
{
  Std_ReturnType LucRetVal = E_NOT_OK;
  if (ETH_MAC_LAYER_SPEED_10G == LenSpeed)
  {
    /* Step U.2.19: ch X bank = H1f00, (ch X Base Address + H0000) = H0000_2140 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x2140U);                              /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    LucRetVal = E_OK;
  }
  else if (ETH_MAC_LAYER_SPEED_2500M == LenSpeed)
  {
    /* Step : ch X bank = H1f00, (ch X Base Address + H0000) = H0000_0120 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H1F00, ETH_SERDES_OFS_H0000, 0x0120U);                              /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    LucRetVal = E_OK;
  }
  else
  {
    /* invalid config */
    LucRetVal = E_NOT_OK;
  }

  if(E_OK == LucRetVal)
  {
    /* Step U.2.20: ch X bank = H0380, (ch X Base Address + H0000) = H0000_2600 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000, 0x2600U);                              /* PRQA S 0303, 2985, 3469 # JV-01, JV-01, JV-01 */
    /* Step U.2.21: ch X bank = H0380, (ch X Base Address + H0000) polling bit[10] till 0 */
    LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0380, ETH_SERDES_OFS_H0000, ETH_BIT(10UL), (uint32)(0UL << 10UL));
  }
  return LucRetVal;
}
/***********************************************************************************************************************
** Function Name         : Eth_Serdes_InitializeSRAM
**
** Service ID            : N/A
**
** Description           : Initialize SERDES SRAM
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Serdes_PollingBit
**
** Registers Used        : ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H026C
**                         ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000
**
** Reference ID          : ETH_DUD_ACT_3098
** Reference ID          : ETH_DUD_ACT_3098_GBL001, ETH_DUD_ACT_3098_GBL002
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Serdes_InitializeSRAM(CONST(uint32, AUTOMATIC) LulChannel)
{
  Std_ReturnType LucRetVal = E_NOT_OK;
  /* Initialize SRAM: ch X bank = H0180, (ch X Base Address + H026C) polling bit[0] till 1 */
  LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H026C, ETH_BIT(0UL), 1UL);
  if(LucRetVal == E_OK)
  {
    /* Step : ch X bank = H0180, (ch X Base Address + H026C) = H0000_0003 */
    ETH_SERDES_WRITE(LulChannel, ETH_SERDES_BANKVAL_H0180, ETH_SERDES_OFS_H026C, 0x0003U);                              /* PRQA S 0303, 3383, 3469 # JV-01, JV-01, JV-01 */
    /* Step : ch X bank = H0300, (ch X Base Address + H0000) polling bit[15] till 0 */
    LucRetVal = Eth_Serdes_PollingBit(LulChannel, ETH_SERDES_BANKVAL_H0300, ETH_SERDES_OFS_H0000, ETH_BIT(15UL), 0UL);
  } /* No action required */

  return LucRetVal;
}
#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#endif /* (ETH_MACRO_RSW3 == STD_ON) */

/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
