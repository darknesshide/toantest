/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_RSW3_Irq.c                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2023 Renesas Electronics Corporation. All rights reserved.                                            */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Interrupt Service Routine for  Ethernet Driver Component                                        */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   X5H                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.0.3: 30/10/2025    : Corrected the function name of GWCA data and ETHA error interrupt service routine
 * 1.0.2: 16/09/2025    : Update correct macro vesion
 * 1.0.1: 24/11/2023    : Update QAC violation
 * 1.0.0: 16/08/2023    : Initial Version
 */

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-2.1                             */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3408)    : '%1s' has external linkage and is being defined without any previous declaration.            */
/* Rule                : CERTCCM DCL07, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.4                             */
/* JV-01 Justification : It is accepted, due to the declaration will be taken care by Os                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_RSW3_Irq.h"
#include "Eth_RSW3_Ram.h"
/* Included for declaration of the function Dem_ReportErrorStatus() */
#include "Dem.h"
/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/

/* AUTOSAR release version information */
#define ETH_RSW3_IRQ_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_RSW3_IRQ_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_RSW3_IRQ_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_RSW3_IRQ_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_RSW3_IRQ_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/

/* Functionality related to R4.0 */
#if (ETH_RSW3_IRQ_AR_RELEASE_MAJOR_VERSION != ETH_RSW3_IRQ_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_RSW3_Irq.c : Mismatch in Release Major Version"
#endif
#if (ETH_RSW3_IRQ_AR_RELEASE_MINOR_VERSION != ETH_RSW3_IRQ_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_RSW3_Irq.c : Mismatch in Release Minor Version"
#endif
#if (ETH_RSW3_IRQ_AR_RELEASE_REVISION_VERSION != ETH_RSW3_IRQ_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_RSW3_Irq.c : Mismatch in Release Revision Version"
#endif

#if (ETH_RSW3_IRQ_SW_MAJOR_VERSION != ETH_RSW3_IRQ_C_SW_MAJOR_VERSION)
  #error "Eth_RSW3_Irq.c : Mismatch in Software Major Version"
#endif
#if (ETH_RSW3_IRQ_SW_MINOR_VERSION != ETH_RSW3_IRQ_C_SW_MINOR_VERSION)
  #error "Eth_RSW3_Irq.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/
/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_CODE_FAST
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
** Function Name         : ETH_GWCADISISR
**
** Service ID            : NA
**
** Description           : Data Interrupt and Time Stamp Data Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Gwca_DIS_Common_Isr, Eth_Gwca_TSDIS_Common_Isr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3112
** Reference ID          : ETH_DUD_ACT_3112_GBL001, ETH_DUD_ACT_3112_REG001
***********************************************************************************************************************/
#if (ETH_GWCA0_DATA_ISR == STD_ON) || (ETH_GWCA1_DATA_ISR == STD_ON) || (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_GWCADISISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_GWCADISISR_CAT2)                                                                                                /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
 _INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_GWCADISISR(void)                                                             /* PRQA S 1503 # JV-01 */
#endif
{

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  if(0UL != (Eth_GpRSW3_TOPRegs->ulTGIM[ETH_RSW3_GWCA0] & ETH_RSW3_TOP_TIM_GWTSDISIM_MASK))
  {
    Eth_Gwca_TSDIS_Common_Isr(ETH_RSW3_GWCA0);
  } /* else do nothing */

  if(0UL != (Eth_GpRSW3_TOPRegs->ulTGIM[ETH_RSW3_GWCA1] & ETH_RSW3_TOP_TIM_GWTSDISIM_MASK))
  {
    Eth_Gwca_TSDIS_Common_Isr(ETH_RSW3_GWCA1);
  } /* else do nothing */
  #endif  /* ETH_GLOBAL_TIME_SUPPORT */

  #if (ETH_GWCA0_DATA_ISR == STD_ON)
  if(0UL != (Eth_GpRSW3_TOPRegs->ulTGIM[ETH_RSW3_GWCA0] & ETH_RSW3_TOP_TIM_GWDISIM_MASK))
  {
    Eth_Gwca_DIS_Common_Isr(ETH_RSW3_GWCA0);
  }
  #endif  /* ETH_GWCA0_DATA_ISR */

  #if (ETH_GWCA1_DATA_ISR == STD_ON)
  if(0UL != (Eth_GpRSW3_TOPRegs->ulTGIM[ETH_RSW3_GWCA1] & ETH_RSW3_TOP_TIM_GWDISIM_MASK))
  {
    Eth_Gwca_DIS_Common_Isr(ETH_RSW3_GWCA1);
  }
  #endif  /* ETH_GWCA1_DATA_ISR */
}
#endif /* #if (ETH_GWCA0_DATA_ISR == STD_ON) || (ETH_GWCA1_DATA_ISR == STD_ON) || (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_GWCAnERRISR (n: 0..1)
**
** Service ID            : NA
**
** Description           : Error Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Gwca_ERR_Common_Isr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3116
***********************************************************************************************************************/
/* Function define: GWCA0 Error Interrupt */
#if (ETH_GWCA0_ERR_ISR == STD_ON)
#if defined (Os_ETH_GWCA0ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_GWCA0ERRISR_CAT2)                                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_GWCA0ERRISR(void)                                                             /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_Gwca_ERR_Common_Isr(ETH_RACE_ID_GWCA0);
}
#endif /* (ETH_GWCA0_ERR_ISR == STD_ON) */

/* Function define: GWCA1 Error Interrupt */
#if (ETH_GWCA1_ERR_ISR == STD_ON)
#if defined (Os_ETH_GWCA1ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_GWCA1ERRISR_CAT2)                                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_GWCA1ERRISR(void)                                                             /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_Gwca_ERR_Common_Isr(ETH_RACE_ID_GWCA1);
}
#endif /* (ETH_GWCA1_ERR_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_COMAERRISR
**
** Service ID            : NA
**
** Description           : Error Interrupt Service Handler (COMA)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Coma_ERR_Common_Isr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3118
***********************************************************************************************************************/
/* Function define: COMA Error Interrupt */
#if (ETH_COMA_ERR_ISR == STD_ON)
#if defined (Os_ETH_COMAERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_COMAERRISR_CAT2)                                                                                                /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_COMAERRISR(void)                                                              /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_Coma_ERR_Common_Isr();
}
#endif /* (ETH_COMA_ERR_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_ETHAERRISR
**
** Service ID            : NA
**
** Description           : Error Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_Etha_ERR_Common_Isr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_3119
** Reference ID          : ETH_DUD_ACT_3119_GBL001, ETH_DUD_ACT_3119_REG001
***********************************************************************************************************************/
/* Function define: ETHA Error Interrupt */
#if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) || \
     (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) || \
     (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) || \
     (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) || \
     (ETH_ETHA12_ERR_ISR == STD_ON))
#if defined (Os_ETH_ETHAERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_ETHAERRISR_CAT2)                                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_ETHAERRISR(void)                                                              /* PRQA S 1503 # JV-01 */
#endif
{

  #if (ETH_ETHA0_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA0]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA0);
  } /* else do nothing */
  #endif /* (ETH_ETHA0_ERR_ISR == STD_ON) */

  #if (ETH_ETHA1_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA1]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA1);
  } /* else do nothing */
  #endif /* (ETH_ETHA1_ERR_ISR == STD_ON) */

  #if (ETH_ETHA2_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA2]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA2);
  } /* else do nothing */
  #endif /* (ETH_ETHA2_ERR_ISR == STD_ON) */

  #if (ETH_ETHA3_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA3]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA3);
  } /* else do nothing */
  #endif /* (ETH_ETHA3_ERR_ISR == STD_ON) */

  #if (ETH_ETHA4_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA4]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA4);
  } /* else do nothing */
  #endif /* (ETH_ETHA4_ERR_ISR == STD_ON) */

  #if (ETH_ETHA5_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA5]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA5);
  } /* else do nothing */
  #endif /* (ETH_ETHA5_ERR_ISR == STD_ON) */

  #if (ETH_ETHA6_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA6]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA6);
  } /* else do nothing */
  #endif /* (ETH_ETHA6_ERR_ISR == STD_ON) */

  #if (ETH_ETHA7_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA7]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA7);
  } /* else do nothing */
  #endif /* (ETH_ETHA7_ERR_ISR == STD_ON) */

  #if (ETH_ETHA8_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA8]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA8);
  } /* else do nothing */
  #endif /* (ETH_ETHA8_ERR_ISR == STD_ON) */

  #if (ETH_ETHA9_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA9]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA9);
  } /* else do nothing */
  #endif /* (ETH_ETHA9_ERR_ISR == STD_ON) */

  #if (ETH_ETHA10_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA10]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA10);
  } /* else do nothing */
  #endif /* (ETH_ETHA10_ERR_ISR == STD_ON) */

  #if (ETH_ETHA11_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA11]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA11);
  } /* else do nothing */
  #endif /* (ETH_ETHA11_ERR_ISR == STD_ON) */

  #if (ETH_ETHA12_ERR_ISR == STD_ON)
  if(0UL != Eth_GaaRSW3_ETHARegs[ETH_RACE_ID_ETHA12]->ulEAEIS0)
  {
    Eth_Etha_ERR_Common_Isr(ETH_RACE_ID_ETHA12);
  } /* else do nothing */
  #endif /* (ETH_ETHA12_ERR_ISR == STD_ON) */

}
#endif /* #if ((ETH_ETHA0_ERR_ISR == STD_ON) || (ETH_ETHA1_ERR_ISR == STD_ON) || (ETH_ETHA2_ERR_ISR == STD_ON) || \
        *      (ETH_ETHA3_ERR_ISR == STD_ON) || (ETH_ETHA4_ERR_ISR == STD_ON) || (ETH_ETHA5_ERR_ISR == STD_ON) || \
        *      (ETH_ETHA6_ERR_ISR == STD_ON) || (ETH_ETHA7_ERR_ISR == STD_ON) || (ETH_ETHA8_ERR_ISR == STD_ON) || \
        *      (ETH_ETHA9_ERR_ISR == STD_ON) || (ETH_ETHA10_ERR_ISR == STD_ON) || (ETH_ETHA11_ERR_ISR == STD_ON) || \
        *      (ETH_ETHA12_ERR_ISR == STD_ON))
        */

#define ETH_STOP_SEC_CODE_FAST
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
