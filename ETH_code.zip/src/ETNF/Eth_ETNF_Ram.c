/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETNF_Ram.c                                                                                      */
/*====================================================================================================================*/
/*                                                COPYRIGHT                                                           */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Global RAM variable definitions for Eth Driver an RAM allocation functions                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                            Revision Control History                                                **
***********************************************************************************************************************/
/*
 * 1.1.1: 01/07/2026    : Update function Eth_ETNF_GetTxBuffer to implement the counter for Tx buffer check.
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *                        Update to use macro constant instead of hard code.
 * 1.0.2: 12/03/2025    : Update to merging SingleMainline
 *                        + Update source code after commonize the type Eth_TxBufferType, Eth_BufHandlerType,
 *                        Eth_RxFrameType, Eth_RxBufManageType
 * 1.0.1: 21/02/2025    : Remove function Eth_ETNF_CheckProvideBuffer.
 *                        Update function table Eth_EtnfFunc to remove function Eth_ETNF_CheckBufferWithPiority and
 *                        add function Eth_ETNF_GetImmTxBuffer.
 * 1.0.0: 21/10/2024    : Remove global variable Eth_GaaBufferLock since it is no longer used.
 *        28/09/2024    : Add new global variables Eth_Ctrl1_TxDescDataEtnf, Eth_Ctrl1_RxDescDataEtnf,
 *                        to support static memory.
 *                        Update global variables Eth_GaaTxDescTableEtnf, Eth_GaaRxDescTableEtnf.
 *                        Update function table Eth_EtnfFunc to add functions Eth_ETNF_CheckBufferWithPiority and
 *                        Eth_ETNF_ResetRxDesc.
 *        29/08/2024    : Add new global variables Eth_GaaLinkFixTable, Eth_Ctrl0_TxDescDataEtnf,
 *                        Eth_Ctrl0_RxDescDataEtnf, Eth_GaaTxDescTableEtnf, Eth_GaaRxDescTableEtnf
 *                        to support static memory.
 *                        Remove global variables Eth_GaaRxBufferIndex, Eth_GpRamManager
 *                        since dynamic memory is no long supported.
 *                        Remove functions Eth_Ram_Init, Eth_Ram_Alloc, Eth_Ram_Alloc, Eth_Ram_Free,
 *                        Eth_Ram_GetNextFreeAddr, Eth_Ram_SetCircularAddr since dynamic memory is no longer supported.
 *                        Modify Eth_EtnfFunc to add element Eth_ETNF_CheckBufferWithPiority.
 *                        Add function Eth_ETNF_RamInit to support static memory.
 *                        Add function Eth_ETNF_CheckBufferWithPiority to support Eth_ImmediateTransmit API.
 *                        Modify functions Eth_ETNF_InitializeBuffer, Eth_ETNF_GetTxBuffer, Eth_ETNF_ReleaseTxBuffer,
 *                        Eth_ETNF_CheckProvideBuffer to support static memory.
 *        03/08/2024    : Add new function Eth_ETNF_HwGetCurrentTimeTuple into Eth_EtnfFunc.
 *        09/04/2024    : Initial Version.
 */
/******************************************************************************/

/***********************************************************************************************************************
**                                               Include Section                                                      **
***********************************************************************************************************************/
/* Included for Eth.h inclusion and macro definitions */
#include "Eth.h"
/* Header file inclusion */
#include "Eth_ETNF_Ram.h"
#include "Eth_Ram.h"
#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
/* Included for the declaration of the critical section protection functions */
#include "SchM_Eth.h"
#endif

/***********************************************************************************************************************
**                                              Version Information                                                   **
***********************************************************************************************************************/
#if (ETH_MACRO_ETNF == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETNF_RAM_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_ETNF_RAM_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_ETNF_RAM_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_ETNF_RAM_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_ETNF_RAM_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                 Version Check                                                      **
***********************************************************************************************************************/

#if (ETH_ETNF_RAM_AR_RELEASE_MAJOR_VERSION != ETH_ETNF_RAM_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_ETNF_Ram.c : Mismatch in Release Major Version"
#endif
#if (ETH_ETNF_RAM_AR_RELEASE_MINOR_VERSION != ETH_ETNF_RAM_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_ETNF_Ram.c : Mismatch in Release Minor Version"
#endif
#if (ETH_ETNF_RAM_AR_RELEASE_REVISION_VERSION != ETH_ETNF_RAM_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_ETNF_Ram.c : Mismatch in Release Revision Version"
#endif


#if (ETH_ETNF_RAM_SW_MAJOR_VERSION != ETH_ETNF_RAM_C_SW_MAJOR_VERSION)
   #error "Eth_ETNF_Ram.c : Mismatch in Software Major Version"
#endif
#if (ETH_ETNF_RAM_SW_MINOR_VERSION != ETH_ETNF_RAM_C_SW_MINOR_VERSION)
   #error "Eth_ETNF_Ram.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1504)    : The object '%1s' is only referenced in the translation unit where it is defined.             */
/* Rule                : CERTCCM DCL15, DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                      */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1533)    : The object '%1s' is only referenced by function '%2s'.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.9                                            */
/* JV-01 Justification : This is accepted, due to the object is defined in separated source C file to followed        */
/*                       coding rule                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2963)    : Suspicious: Using value of uninitialized automatic object '%s'.                              */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-457, CWE-1157, CWE-908, CWE-452, CWE-465, CWE-824,               */
/* JV-01 Justification : It will be initialized based on scope of 'if' statements where at least an 'if' statement    */
/*                       will be executed that will initialize the variable in question.                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3206)    : The parameter '%1s' is not used in this function.                                            */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-563, CWE-569,  MISRA C:2012 Rule-2.7             */
/* JV-01 Justification : This is done as per implementation requirement                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4391)    : A composite expression of 'essentially unsigned' type (%1s) is being cast to a wider         */
/*                       unsigned type, '%2s'.                                                                        */
/* Rule                : CWE Rule CWE-136,  MISRA C:2012 Rule-10.8                                                    */
/* JV-01 Justification : This casting is for the lower operator which requires wider type.                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Global Data                                                          **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"
/* LINKFIX table */
VAR(Eth_LinkDescType, ETH_VAR_NO_INIT) 
                Eth_GaaLinkFixTable[ETH_TOTAL_CTRL_CONFIG][ETH_TXQ_NUM_ETNF + ETH_RXQ_NUM_ETNF];                        /* PRQA S 1533 # JV-01 */
#define ETH_STOP_SEC_VAR_CLEARED_DESCRIPTOR_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#define ETH_START_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#define ETH_STOP_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

VAR(Eth_RxChConfigType, ETH_VAR_NO_INIT) Eth_GaaRxConfig[ETH_TOTAL_CTRL_CONFIG][ETH_RXQ_NUM_ETNF];

VAR(Eth_QConfigType, ETH_VAR_NO_INIT) Eth_GaaQConfig[ETH_TOTAL_CTRL_CONFIG][ETH_RXQ_NUM_ETNF];

VAR(Eth_AvbConfigType, ETH_VAR_NO_INIT) Eth_GaaAvbConfig[ETH_TOTAL_CTRL_CONFIG];


#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_PORT_BUFFER_0
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_PORT_BUFFER_0
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_PORT_BUFFER_1
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_PORT_BUFFER_1
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* The Function table for ETNF */
VAR(Eth_HwFuncTableType, ETH_VAR_INIT) Eth_EtnfFunc =
{
  &Eth_ETNF_InitializeBuffer,
  &Eth_ETNF_PreprocessBuffer,
  &Eth_ETNF_GetTxBuffer,
  &Eth_ETNF_ReleaseTxBuffer,
  &Eth_ETNF_PreprocessFrame,
  &Eth_ETNF_FindTxBufferHandler,
  &Eth_ETNF_HwInit,
  #ifdef ETH_HW_DEINIT
  #if (ETH_DEINIT_API == STD_ON)
  NULL_PTR, /* pHwDeInit */
  #endif
  #endif
  &Eth_ETNF_HwDisableController,
  &Eth_ETNF_HwEnableController,
  &Eth_ETNF_HwTransmit,
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  &Eth_ETNF_HwGetCounterValues,
  #endif
  #if (ETH_GET_RX_STATS_API == STD_ON)
  &Eth_ETNF_HwGetRxStats,
  #endif
  #if (ETH_GET_TX_STATS_API == STD_ON)
  &Eth_ETNF_HwGetTxStats,
  #endif
  #if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
  &Eth_ETNF_HwGetTxErrorCounterValues,
  #endif
  &Eth_ETNF_HwMainFunction,
  &Eth_ETNF_HwTxConfirmation,
  #if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
  &Eth_ETNF_HwCheckFifoIndex,
  #endif
  #if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
  &Eth_ETNF_HwReceive,
  #else
  NULL_PTR, /* pHwReceive */
  #endif
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  &Eth_ETNF_HwSetIncrementTimeForGptp,
  &Eth_ETNF_HwSetOffsetTimeForGptp,
  &Eth_ETNF_HwGetCurrentTime,
  &Eth_ETNF_HwGetCurrentTimeTuple,
  &Eth_ETNF_HwGetEgressTimeStamp,
  &Eth_ETNF_HwGetIngressTimeStamp,
  #endif
  #if (ETH_CTRL_ENABLE_MII == STD_ON)
  #if defined ETH_HW_NOT_LEGACY_MDIO
  NULL_PTR, /* pHwReadMii */
  NULL_PTR, /* pHwWriteMii */
  #endif
  #if defined ETH_HW_LEGACY_MDIO
  &Eth_HwReadMiiBit,
  &Eth_HwWriteMiiBit,
  #endif
  #endif
  &Eth_ETNF_GetImmTxBuffer,
  &Eth_ETNF_ResetRxDesc,
};

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                         Function Definitions                                                       **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#if (ETH_QOS_SUPPORT == STD_ON)
STATIC FUNC(uint8, ETH_PRIVATE_CODE) FindTxQueue(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucPriority);
#endif

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_InitializeBuffer
**
** Service ID            : N/A
**
** Description           : Initialize the Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable, Eth_GaaRxFrame
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1062,
** Reference ID          : ETH_DUD_ACT_1062_GBL001, ETH_DUD_ACT_1062_GBL002
** Reference ID          : ETH_DUD_ACT_1062_GBL003, ETH_DUD_ACT_1062_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_InitializeBuffer(                                                                 /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  uint16 LusCnt;
  P2VAR(Eth_TxBufferType, AUTOMATIC, ETH_APPL_DATA) LpTxBuffer;                                                         /* PRQA S 3432 # JV-01 */

  /* Initialize resource information */
  Eth_GaaRxFrame[LulCtrlIdx].ulFrameAddr = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = (uint32)ETH_ZERO;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.secondsHi = (uint16)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].enTimeQual = ETH_INVALID;
  #endif

  /* Initialize Tx buffer index list */
  for (LusCnt = (uint16)ETH_ZERO; LusCnt < Eth_GaaTxBufferTotal[LulCtrlIdx]; LusCnt++)
  {
    LpTxBuffer = (Eth_TxBufferType *)&Eth_GaaTxBufferMgrTable[LulCtrlIdx][LusCnt];
    LpTxBuffer->pBufferHdr = NULL_PTR;
  }

  /* Initialize buffer counter */
  for (LusCnt = (uint16)ETH_ZERO; LusCnt < ETH_TXQ_NUM_ETNF; LusCnt++)
  {
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaBufTxCnt[LusCnt] = (uint32)ETH_ZERO;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_PreprocessBuffer
**
** Service ID            : N/A
**
** Description           : Write source address to all Tx Buffers in advance
**                         because source address is never changed while
**                         a controller mode is ACTIVE.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_PreprocessBuffer(                                                                 /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx)                                                                                  /* PRQA S 3206 # JV-01 */
{
  /* No action required because this function is retained for ETNC compatibility. */
}

/*******************************************************************************
** Function Name         : Eth_ETNF_RamInit
**
** Service ID            : NA
**
** Description           : This Initialize base address of RAM for application
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr,
**                         Eth_GaaTxBufferNodes, Eth_GaaTxBufferDataTable,
**                         Eth_CtrlTxMaxFrameLengthMapping, Eth_GaaRxBufferNodes,
**                         Eth_GaaRxBufferDataTable,
**                         Eth_CtrlRxMaxFrameLengthMapping
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1064
** Reference ID          : ETH_DUD_ACT_1064_GBL001, ETH_DUD_ACT_1064_GBL002
** Reference ID          : ETH_DUD_ACT_1064_GBL003, ETH_DUD_ACT_1064_GBL004
** Reference ID          : ETH_DUD_ACT_1064_GBL005, ETH_DUD_ACT_1064_GBL006
** Reference ID          : ETH_DUD_ACT_1064_GBL007
*******************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_RamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  uint32 LulBufIdx;
  uint8 LucQueIdx;
  uint8 LucLoopIdx;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316 # JV-01 */
  LulBufIdx = 0;

  /* Seting initial value for each Tx buffer node to manage each Tx buffer */
  for (LucQueIdx = 0; LucQueIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucQueIdx++)
  {
    for (LucLoopIdx = 0; LucLoopIdx < LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucQueIdx].usEthTxQueueBufs;
                                                                                                          LucLoopIdx++)
    {
      /* Init node information */
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufIdx = LulBufIdx;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
       (uint32)&Eth_GaaTxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)(Eth_CtrlTxMaxFrameLengthMapping[LulCtrlIdx])];/* PRQA S 0306, 3384 # JV-01, JV-01 */
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulTxLength  = (uint32)ETH_ZERO;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blbenableTS = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blTxConfirm = ETH_FALSE;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].enTimeQual = INVALID;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.nanoseconds = (uint32)ETH_ZERO;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.seconds     = (uint32)ETH_ZERO;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.secondsHi   = (uint16)ETH_ZERO;
      #endif
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxQueueIdx   = (uint8)LucQueIdx;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulEthTypeAddr = ETH_NOT_AVAILABLE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blUsedFlag = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId = (uint32)ETH_ZERO;
      LulBufIdx++;                                                                                                      /* PRQA S 3383 # JV-01 */
    }
  }

  LulBufIdx = 0;
  /* Seting initial value for each Rx buffer node to manage each Rx buffer */
  for (LucQueIdx = 0; LucQueIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LucQueIdx++)
  {
    for (LucLoopIdx = 0; LucLoopIdx < LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucQueIdx].usEthRxQueueBufs;
                                                                                                          LucLoopIdx++)
    {
      /* Init node information */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufIdx = LulBufIdx;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
         (uint32)&Eth_GaaRxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlRxMaxFrameLengthMapping[LulCtrlIdx]];/* PRQA S 0306, 3384 # JV-01, JV-01 */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].blLockedFlag = ETH_FALSE;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].blRxConfirm = ETH_FALSE;
      LulBufIdx++;                                                                                                      /* PRQA S 3383 # JV-01 */
    }

    #if(ETH_DEVICE_NAME == ETH_U5X)
    /* Initialize the Buffer warning level counter */
    Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LucQueIdx] = ETH_ZERO;
    #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_GetTxBuffer
**
** Service ID            : N/A
**
** Description           : Get a buffer from the Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : A index of acquired buffer
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferTotal, Eth_GaaTxBufferNodes, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**                         FindTxQueue, EthSwt_EthTxAdaptBufferLength
**                         EthSwt_EthTxPrepareFrame
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1065
** Reference ID          : ETH_DUD_ACT_1065_GBL001, ETH_DUD_ACT_1065_GBL002
** Reference ID          : ETH_DUD_ACT_1065_GBL003
** Reference ID          : ETH_DUD_ACT_1065_CRT001, ETH_DUD_ACT_1065_CRT002
***********************************************************************************************************************/
FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_ETNF_GetTxBuffer(                                                        /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,                                                                                  /* PRQA S 3206 # JV-01 */
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint8*, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr)                                                              /* PRQA S 3432 # JV-01 */
{
  BufReq_ReturnType LenReturnValue;
  uint8 LenQid;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                   /* PRQA S 3432 # JV-01 */
  uint32 LulRingIdx;
  uint16 LusReqSize;
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucReturnValue;
  #endif
  LpTxBufferNode = NULL_PTR;

  /* If the requested size is smaller than the minimum size, expand it to the minimum size */
  if ((uint16)ETH_MIN_PAYLOAD_SIZE_AVB > *LenBytePtr)
  {
    *LenBytePtr = (uint16)ETH_MIN_PAYLOAD_SIZE_AVB;
  }
  else
  {
    /* No action required */
  }

  LusReqSize = *LenBytePtr;
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  /* Added Switch Management Information */
  EthSwt_EthTxAdaptBufferLength(&LusReqSize);
  #endif

  /* If the requested size is larger than the buffer, return error */
  if (LusReqSize > (uint16)ETH_MAX_TX_PAYLOAD_LENGTH)
  {
    *LenBytePtr = (uint16)((uint16)ETH_MAX_TX_PAYLOAD_LENGTH - (LusReqSize - *LenBytePtr));
    LenReturnValue = BUFREQ_E_OVFL;
  }
  else
  {
    #if (ETH_QOS_SUPPORT == STD_ON)
    LenQid = FindTxQueue(LulCtrlIdx, LucPriority);
    #else
    /* Use BE Queue for any Traffic */
    LenQid = (uint8)ETH_TX_BE;
    #endif
    /* Enter the critical section protection */
    ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Get tx buffer index */
    for (LulRingIdx = 0; LulRingIdx < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulRingIdx++)
    {
      if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].ucTxQueueIdx  == LenQid)
      {
        if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag == ETH_FALSE)
        {
          LpTxBufferNode = &Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx];
          Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag = ETH_TRUE;
          break;
        } /* else no action required */
      } /* else no action required */
    }

    /* Get the Tx buffer management node and Tx buffer */
    if (NULL_PTR != LpTxBufferNode)                                                                                     /* PRQA S 2963 # JV-01 */
    {
      /* Set next buffer index */
      Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulRingIdx].pBufferHdr = LpTxBufferNode;

      /* Get Tx buffer information based on Tx buffer node */
      *LpBufIdxPtr = (Eth_BufIdxType)LpTxBufferNode->ulbufIdx;
      *LpBufPtr = (uint8 *)(LpTxBufferNode->ulbufAddr + (uint32)ETH_HEADER_SIZE);                                       /* PRQA S 0306, 2963, 3383 # JV-01, JV-01, JV-01 */
      LpTxBufferNode->ulEthTypeAddr = LpTxBufferNode->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE;                             /* PRQA S 2963, 3383 # JV-01, JV-01 */

      #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
      LpDataPtr = (uint8 *)LpTxBufferNode->ulEthTypeAddr;                                                               /* PRQA S 0306 # JV-01 */
      /* Added Switch Management Information */
      LusReqSize = *LenBytePtr;
      /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
      LucReturnValue = EthSwt_EthTxPrepareFrame((uint8)LulCtrlIdx, *LpBufIdxPtr, &LpDataPtr, &LusReqSize);
      if (E_OK == LucReturnValue)
      {
        LpTxBufferNode->ulEthTypeAddr = (uint32)LpDataPtr;                                                              /* PRQA S 0306 # JV-01 */
        *LpBufPtr = (uint8 *)((uint32)LpDataPtr + ETH_ETHERTYPE_SIZE);                                                  /* PRQA S 0306, 3383 # JV-01, JV-01 */
      }
      else
      {
        /* If it is not a switch frame, use it as a normal frame */
      }
      #endif

      LenReturnValue = BUFREQ_OK;
    }
    else
    {
      #if(ETH_DEVICE_NAME == ETH_U5X)
      #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
      /* Increase the Measurement counter for unavailable Tx buffers */
      Eth_GaaCtrlStat[LulCtrlIdx].stMeasurementData.ulDropInsuffTxBuffCnt++;
      #endif
      #endif

      LenReturnValue = BUFREQ_E_BUSY;
    }
    /* Exit the critical section protection */
    ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
  }

  return LenReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_GetImmTxBuffer
**
** Service ID            : N/A
**
** Description           : This function gets a buffer from the Tx buffer ring for direct transmission
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : Controller index
**                         LucPriority    : Frame priority for transmit buffer
**                         LusFrameLength : Frame length
**
** InOut Parameters      : None
**
** Output Parameters     : LpBufIdxPtr    : Pointer to the index of granted buffer resource
**                         LpBufAddr      : Pointer to the granted buffer address
**
** Return parameter      : A index of acquired buffer
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferTotal, Eth_GaaTxBufferNodes, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1066
** Reference ID          : ETH_DUD_ACT_1066_CRT001, ETH_DUD_ACT_1066_CRT002
** Reference ID          : ETH_DUD_ACT_1066_GBL001, ETH_DUD_ACT_1066_GBL002, ETH_DUD_ACT_1066_GBL003
***********************************************************************************************************************/
FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_ETNF_GetImmTxBuffer(                                                     /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,                                                                                  /* PRQA S 3206 # JV-01 */
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                                    /* PRQA S 3432 # JV-01 */
  CONST(uint16, AUTOMATIC) LusFrameLength)
{
  BufReq_ReturnType LenReturnValue;
  uint8 LenQid;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode = NULL_PTR;                                        /* PRQA S 3432 # JV-01 */
  uint32 LulRingIdx;

  /* If the requested size is larger than the buffer, return error */
  if (LusFrameLength > (uint16)ETH_MAX_TX_PAYLOAD_LENGTH)
  {
    LenReturnValue = BUFREQ_E_OVFL;
  }
  else
  {
    #if (ETH_QOS_SUPPORT == STD_ON)
    LenQid = FindTxQueue(LulCtrlIdx, LucPriority);
    #else
    /* Use BE Queue for any Traffic */
    LenQid = (uint8)ETH_TX_BE;
    #endif
    /* Enter the critical section protection */
    ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
    
    /* Get tx buffer index */
    for (LulRingIdx = 0; LulRingIdx < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulRingIdx++)
    {
      if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].ucTxQueueIdx  == LenQid)
      {
        if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag == ETH_FALSE)
        {
          LpTxBufferNode = &Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx];
          Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag = ETH_TRUE;
          break;
        } /* else no action required */
      } /* else no action required */
    }

    /* Get the Tx buffer management node and Tx buffer */
    if (NULL_PTR != LpTxBufferNode)
    {
      /* Set next buffer index */
      Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulRingIdx].pBufferHdr = LpTxBufferNode;

      /* Get Tx buffer information based on Tx buffer node */
      *LpBufIdxPtr = (Eth_BufIdxType)LpTxBufferNode->ulbufIdx;
      *LpBufAddr = LpTxBufferNode->ulbufAddr;
      LpTxBufferNode->ulEthTypeAddr = LpTxBufferNode->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE;                             /* PRQA S 3383 # JV-01 */

      LenReturnValue = BUFREQ_OK;
    }
    else
    {
      LenReturnValue = BUFREQ_E_BUSY;
    }
    /* Exit the critical section protection */
    ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
  }

  return LenReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_ReleaseTxBuffer
**
** Service ID            : N/A
**
** Description           : Release a Tx buffer and store it to the tail of the
**                         Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LulBufIdx      : index of a tx buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GaaTxBufferNodes
**                         Eth_GaaTxBufferDataTable, Eth_CtrlTxMaxFrameLengthMapping
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1067
** Reference ID          : ETH_DUD_ACT_1067_GBL001, ETH_DUD_ACT_1067_GBL002, ETH_DUD_ACT_1067_GBL003
** Reference ID          : ETH_DUD_ACT_1067_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_ReleaseTxBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx)
{
  /* Release tx buffer handler */
  Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr = NULL_PTR;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
       (uint32)&Eth_GaaTxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)(Eth_CtrlTxMaxFrameLengthMapping[LulCtrlIdx])];/* PRQA S 0306, 3384 # JV-01, JV-01 */
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulTxLength  = (uint32)ETH_ZERO;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blbenableTS = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blTxConfirm = ETH_FALSE;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].enTimeQual = INVALID;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.nanoseconds = (uint32)ETH_ZERO;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.seconds     = (uint32)ETH_ZERO;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.secondsHi   = (uint16)ETH_ZERO;
  #endif
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulEthTypeAddr = ETH_NOT_AVAILABLE; 
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blUsedFlag = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId = (uint32)ETH_ZERO;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_PreprocessFrame
**
** Service ID            : N/A
**
** Description           : This function sets the destination MAC address
**                         and Ethernet type for the Tx buffer.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LulBufIdx      : index to the buffer
**                         LulFrameType   : ether type
**                         LpPhysAddrPtr  : destination mac address
**                         LpPayloadLen   : payload length
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Function(s) invoked   : Eth_FindTxBufferHandler, EthSwt_EthTxProcessFrame,
**                         ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1068
** Reference ID          : ETH_DUD_ACT_1068_GBL001
** Reference ID          : ETH_DUD_ACT_1068_CRT001, ETH_DUD_ACT_1068_CRT002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETNF_PreprocessFrame(                                                                  /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulFrameType,
  CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen)                                                            /* PRQA S 3206, 3432 # JV-01, JV-01 */
{
  P2VAR(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpBufPtr;                                                               /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                  /* PRQA S 3432, 3678 # JV-01, JV-01 */
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  uint16 LusTxLength;
  Std_ReturnType LucReturnValue;
  #endif

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Get Tx buffer address */
  LpBufHandlerPtr = Eth_ETNF_FindTxBufferHandler(LulCtrlIdx, LulBufIdx);

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  LpBufPtr = (Eth_DataType *)LpBufHandlerPtr->ulbufAddr;                                                                /* PRQA S 0306 # JV-01 */

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  LpDataPtr = (P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))(LpBufHandlerPtr->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE);          /* PRQA S 0306, 3383, 3432 # JV-01, JV-01, JV-01 */
  /* Since the maximum value of buffer size is 1518, casting to uint16 does no problem. */
  LusTxLength = *LpPayloadLen;
  /* decreased by the management information length */
  /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
  LucReturnValue = EthSwt_EthTxProcessFrame((uint8)LulCtrlIdx, LpBufHandlerPtr->ulbufIdx, &LpDataPtr, &LusTxLength);
  if (E_OK == LucReturnValue)
  {
    /* Adjusted for switch processing */
    LpBufPtr = (Eth_DataType *)(LpBufHandlerPtr->ulEthTypeAddr -                                                        /* PRQA S 0306, 3383 # JV-01, JV-01 */
                                (ETH_SRC_DST_ADDRESS_SIZE + (uint32)(LusTxLength - *LpPayloadLen)));                    /* PRQA S 3383, 4391 # JV-01, JV-01 */
    LpBufHandlerPtr->ulbufAddr = (uint32)LpBufPtr;                                                                      /* PRQA S 0306 # JV-01 */
    *LpPayloadLen = LusTxLength;
  }
  else
  {
    /* If EthSwt_SetMgmtInfo is not called, normal operation */
  }
  #endif

  /* Copy destination address */
  ETH_COPY_MAC_ADDRESS((CONST(uint8, AUTOMATIC) *)LpPhysAddrPtr, (uint8 *)LpBufPtr);                                    /* PRQA S 3469 # JV-01 */
  LpBufPtr = LpBufPtr + ETH_MACADDR_SIZE;                                                                               /* PRQA S 0488 # JV-01 */

  ETH_UNPACK_ADDRESS_TO_8(Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr, LpBufPtr);                                             /* PRQA S 3469 # JV-01 */

  /* Casted to uint8 to extract the required 1 byte. */
  LpBufPtr = (Eth_DataType *)LpBufHandlerPtr->ulEthTypeAddr;                                                            /* PRQA S 0306 # JV-01 */
  *LpBufPtr = (Eth_DataType)((uint8)(LulFrameType >> ETH_BYTE_BITS));
  LpBufPtr++;
  /* Casted to uint8 to extract the required 1 byte. */
  *LpBufPtr = (Eth_DataType)((uint8)LulFrameType);
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_FindTxBufferHandler
**
** Service ID            : NA
**
** Description           : This get the tx buffer handler associated with
**                         the specified buffer index.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of controller
**                         LulBufIdx  - Index of tx buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1069
** Reference ID          : ETH_DUD_ACT_1069_GBL001
***********************************************************************************************************************/
FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE) Eth_ETNF_FindTxBufferHandler(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx)
{
  return Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;
}

/***********************************************************************************************************************
** Function Name         : FindTxQueue
**
** Service ID            : NA
**
** Description           : This function find the Tx Queue associated
**                         with the passed priority. Otherwise return the default Queue.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LucPriority
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LucRetQidx
**
** Preconditions         : None
**
** Global Variables Used : Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1070
** Reference ID          : ETH_DUD_ACT_1070_GBL001
***********************************************************************************************************************/
#if (ETH_QOS_SUPPORT == STD_ON)
STATIC FUNC(uint8, ETH_PRIVATE_CODE) FindTxQueue(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucPriority)
{
  uint8 LucRetQidx;
  uint8 LucIdx;
  uint8 LucTotalPriorities;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  LucRetQidx = LpHwUnitConfig->stCtrlPriority.ucDflTxQueue;
  LucTotalPriorities = LpHwUnitConfig->stCtrlPriority.ucNumberOfPriorities;

  for (LucIdx = (uint8)ETH_ZERO; LucIdx < LucTotalPriorities; LucIdx++)
  {
    if (LpHwUnitConfig->stCtrlPriority.pPriorityTable[LucIdx].ucEthCtrlPriorityValue == LucPriority)
    {
      /* Found Traffic associated to the passed Priority */
      /* Return Corresponding Tx Queue and exit */
      LucRetQidx = LpHwUnitConfig->stCtrlPriority.pPriorityTable[LucIdx].ucEthCtrlTxQueueId;
      /* Exit the loop */
      break;
    }
    else
    {
      /* No action required */
    }
  }

  return ((uint8)LucRetQidx);
}
#endif

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* ETH_MACRO_ETNF == STD_ON */
/***********************************************************************************************************************
**                                               End of File                                                          **
***********************************************************************************************************************/
