/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETNF_Dma.c                                                                                      */
/*====================================================================================================================*/
/*                                            COPYRIGHT                                                               */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains DMAC functions implementation of Ethernet Driver  Component.                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                     Revision Control History                                                       **
***********************************************************************************************************************/
/*
 * 1.4.2: 01/07/2026    : Update function Eth_Hw_ETNF_RxQueueProcess to implement the counter for Rx buffer check.
 * 1.4.0: 09/04/2026    : Update to add MISRA-C Justification comment.
 * 1.2.0: 30/12/2025    : Update to add the justification for Misra C msg 1710.
 * 1.1.1: 13/10/2025    : Update function Eth_Hw_ETNF_DisableController to refactor code.
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *                        Update to use macro constant instead of hard code.
 * 1.0.2: 24/04/2025    : Update to remove macro ETH_UPDATE_PHYS_ADDR_FILTER
 *        12/03/2025    : Update to merging SingleMainline
 *                        + Update source code after commonize the type Eth_TxBufferType, Eth_BufHandlerType,
 *                        Eth_RxFrameType, Eth_RxBufManageType
 *                        + Update function RxCallEthIf() to remove define LucHWIPType because of redundant
 * 1.0.1: 27/02/2025    : Change name of function Eth_ETNF_GetTimeOutValue to Eth_ETNF_GetElapsedTimeValue.
 *                        Update function Eth_ETNF_GetElapsedTimeValue to fix issue ARDAACJ-695.
 *                        Change name of variable LulTimeOutCountInit to LulTickStart and
 *                        LulTimeoutCountElap to LulTickElap to unify with other HWIP.
 *                        Remove WA() implementation.
 * 1.0.0: 21/10/2024    : Add WA() in function Eth_Hw_ETNF_DisableController to workaround for HW defect.
 *        29/08/2024    : Modify function RxCallEthIf to add new input argument LulBufIdx.
 *                        Remove function AllocMemForDesc, Eth_Hw_ETNF_RxMemAlloc
 *                        since dynamic memory is no longer supported.
 *                        Modify functions Eth_Hw_ETNF_RxQueueProcess, SetDescChain, SetFempty, SetExtFempty,
 *                        Eth_Hw_ETNF_SYS_AllocDescBuffer to support static memory.
 *        16/07/2024    : Update function RxCallEthIf to support R23-11.
 *        09/04/2024    : Initial Version.
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                        Include Section                                                             **
***********************************************************************************************************************/
/* Included for module version information and other types declarations */
#include "Eth.h"
/* Included for prototypes for internal functions of Ethernet Component */
#include "Eth_ETNF_Dma.h"
/* Included for Ethernet Component register types used within the module */
#include "Eth_ETNF_Ram.h"
#include "Eth_Ram.h"
#include "EthIf.h"

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
#include "SchM_Eth.h"
#endif

#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif

/***********************************************************************************************************************
**                                          Version Information                                                       **
***********************************************************************************************************************/
#if (ETH_MACRO_ETNF == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETNF_DMA_C_AR_RELEASE_MAJOR_VERSION  ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_ETNF_DMA_C_AR_RELEASE_MINOR_VERSION  ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_ETNF_DMA_C_AR_RELEASE_REVISION_VERSION  ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_ETNF_DMA_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_ETNF_DMA_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                          Version Check                                                             **
***********************************************************************************************************************/

/* Functionality related to R4.0 */
#if (ETH_ETNF_DMA_AR_RELEASE_MAJOR_VERSION !=  ETH_ETNF_DMA_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_ETNF_Dma.c : Mismatch in Release Major Version"
#endif
#if (ETH_ETNF_DMA_AR_RELEASE_MINOR_VERSION !=  ETH_ETNF_DMA_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_ETNF_Dma.c : Mismatch in Release Minor Version"
#endif
#if (ETH_ETNF_DMA_AR_RELEASE_REVISION_VERSION !=  ETH_ETNF_DMA_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_ETNF_Dma.c : Mismatch in Release Revision Version"
#endif

#if (ETH_ETNF_DMA_SW_MAJOR_VERSION != ETH_ETNF_DMA_C_SW_MAJOR_VERSION)
  #error "Eth_ETNF_Dma.c : Mismatch in Software Major Version"
#endif
#if (ETH_ETNF_DMA_SW_MINOR_VERSION != ETH_ETNF_DMA_C_SW_MINOR_VERSION)
  #error "Eth_ETNF_Dma.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0759)    : An object of union type has been defined.                                                    */
/* Rule                : CWE Rule CWE-843,  MISRA C:2012 Rule-19.2                                                    */
/* JV-01 Justification : Data access of larger data types is used to achieve better throughput.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:2961)    : Definite: Using value of uninitialized automatic object '%s'.                                */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-457, CWE-1157, CWE-908, CWE-452, CWE-465, CWE-824,  MISRA        */
/*                       C:2012 Rule-9.1                                                                              */
/* JV-01 Justification : This message would mean having to remove the pre-compile macro in Port_InitConfig            */
/*                       initialization which will increase memory consumption and affect driver performance.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2962)    : Apparent: Using value of uninitialized automatic object '%s'.                                */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-457, CWE-1157, CWE-908, CWE-452, CWE-465, CWE-824,  MISRA        */
/*                       C:2012 Rule-9.1                                                                              */
/* JV-01 Justification : It will be initialized based on scope of 'if' statements  where at least an 'if' statement   */
/*                       will be executed that will initialize the variable.                                          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2963)    : Suspicious: Using value of uninitialized automatic object '%s'.                              */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-457, CWE-1157, CWE-908, CWE-452, CWE-465, CWE-824,               */
/* JV-01 Justification : It will be initialized based on scope of 'if' statements where at least an 'if' statement    */
/*                       will be executed that will initialize the variable in question.                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3206)    : The parameter '%1s' is not used in this function.                                            */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-563, CWE-569,  MISRA C:2012 Rule-2.7             */
/* JV-01 Justification : This is done as per implementation requirement                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-1157, CWE-398, CWE-569,                                          */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%1s' is not modified and so the pointer       */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.13                     */
/* JV-01 Justification : Pointer variable is used to modify the value at the address so the pointer cannot be         */
/*                       declared as 'pointer to const' type.                                                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4391)    : A composite expression of 'essentially unsigned' type (%1s) is being cast to a wider         */
/*                       unsigned type, '%2s'.                                                                        */
/* Rule                : CWE Rule CWE-136,  MISRA C:2012 Rule-10.8                                                    */
/* JV-01 Justification : This casting is for the lower operator which requires wider type.                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions.                                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2991)    : The value of this 'if' controlling expression is always 'true'.                              */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2992)    : The value of this 'if' controlling expression is always 'false'.                             */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'true'.     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2995)    : The result of this logical operation is always 'true'.                                       */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'false'.    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2996)    : The result of this logical operation is always 'false'.                                      */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'true'.     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                              Global Data                                                           **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                              Function Definitions                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

STATIC FUNC(void, ETH_PRIVATE_CODE) RxBeProcess(CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpSingleRxFramePtr,                                             /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulDescPtr);

STATIC FUNC(void, ETH_PRIVATE_CODE) RxNcProcess(CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpSingleRxFramePtr,                                             /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulDescPtr);

STATIC FUNC(void, ETH_PRIVATE_CODE) RxSProcess(CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpSingleRxFramePtr,                                             /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulChannelNum, CONST(uint32, AUTOMATIC) LulDescPtr);

STATIC FUNC(void, ETH_PRIVATE_CODE) SetDescChain(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulAddr, CONST(uint8, AUTOMATIC) LucQidx,
  CONST(Eth_DirectionType, AUTOMATIC) LenDir);

STATIC FUNC(void, ETH_PRIVATE_CODE) SetFempty(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDescr,                  /* PRQA S 3432 # JV-01 */
  CONST(uint8, AUTOMATIC) LucQidx, CONST(Eth_DirectionType, AUTOMATIC) LenQdir,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) SetExtFempty(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpDescr,               /* PRQA S 3432 # JV-01 */
  CONST(uint8, AUTOMATIC) LucQidx, CONST(Eth_DirectionType, AUTOMATIC) LenQdir,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) SetLinkFix(
  CONST(uint32, AUTOMATIC) LulLinkDesc, CONST(uint32, AUTOMATIC) LulAddrToLink);

STATIC FUNC(void, ETH_PRIVATE_CODE) TxRxConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_TxConfigType, AUTOMATIC, ETH_APPL_DATA) LpTxConfig,
  CONSTP2CONST(Eth_RxConfigTypeEtnf, AUTOMATIC, ETH_APPL_DATA) LpRxConfig);

STATIC FUNC(uint32, ETH_PRIVATE_CODE) DescUpdate(
  CONST(uint32, AUTOMATIC) LulDescPtr);

STATIC FUNC(uint32, ETH_PRIVATE_CODE) DescTsUpdate(
  CONST(uint32, AUTOMATIC) LulDescPtr);

STATIC FUNC(void, ETH_PRIVATE_CODE) RxQueueSet(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) RxCallEthIf(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulQueueIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC,ETH_APPL_DATA) LpFrame,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) TxRxIntConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);

STATIC FUNC(void, ETH_PRIVATE_CODE) FillDescMemory(
  CONSTP2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDescr, CONST(uint32, AUTOMATIC) LulDescAddr);            /* PRQA S 3432 # JV-01 */

STATIC FUNC(boolean, ETH_PRIVATE_CODE) IsQueueConfigured(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucQidx,
  CONST(Eth_DirectionType, AUTOMATIC) LenDir);

#if (ETH_STREAM_FILTERING == STD_ON)
STATIC FUNC(void,  ETH_PRIVATE_CODE) SetRxFilter(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif

STATIC FUNC(boolean, ETH_PRIVATE_CODE) IsRxFrameValid(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpRxFrame);

#if (ETH_QOS_SUPPORT == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) SetCbsParameter(
  CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif

/***********************************************************************************************************************
** Function Name         : RxBeProcess
**
** Service ID            : NA
**
** Description           : This process best effort queue
**                         (The PS bit isn't checked.)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Ethernet channel number
**                       : LulRxFramePtr - pointer to rx frame
**                       : LulDescPtr - pointer to rx Descriptor
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1002,
** Reference ID          : ETH_DUD_ACT_1002_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) RxBeProcess(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpSingleRxFramePtr,                                             /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulDescPtr)
{
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                         /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpExtDataDesc;                                                   /* PRQA S 3432, 3678 # JV-01, JV-01 */
  Eth_OptionType LenRxBeTimestamp;

  LenRxBeTimestamp = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxBeTimestamp;

  /* single frame single buffer */
  if (ETH_ENABLE == LenRxBeTimestamp)
  {
    /* timestamp enabled */
    LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                  /* PRQA S 0306, 3432 # JV-01, JV-01 */

    if (ETH_DESC_FSINGLE_AVB == LpExtDataDesc->stHeader.ulDt)
    {
      /* descriptor type correct */
      LpSingleRxFramePtr->ulFrameAddr   = LpExtDataDesc->ulDptr;
      LpSingleRxFramePtr->ulEthTypeAddr = LpExtDataDesc->ulDptr + ETH_SRC_DST_ADDRESS_SIZE;                             /* PRQA S 3383 # JV-01 */
      LpSingleRxFramePtr->ulFrameLength = LpExtDataDesc->stHeader.ulDs;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      LpSingleRxFramePtr->stTimeStamp.nanoseconds   = LpExtDataDesc->stTimestamp.ulTimestamp0;
      LpSingleRxFramePtr->stTimeStamp.seconds       = LpExtDataDesc->stTimestamp.ulTimestamp1;
      LpSingleRxFramePtr->stTimeStamp.secondsHi     = LpExtDataDesc->stTimestamp.usTimestamp2;
      LpSingleRxFramePtr->enTimeQual    = ETH_VALID;
      #endif
    }
    else
    {
      /* descriptor type incorrect */
      LpSingleRxFramePtr->ulFrameAddr   = (uint32)ETH_ZERO;
      LpSingleRxFramePtr->ulFrameLength = (uint32)ETH_ZERO;
    }
    LpExtDataDesc++;
    while ((LpExtDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
      (LpExtDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
    {
      LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LpExtDataDesc->ulDptr;                     /* PRQA S 0306, 3432 # JV-01, JV-01 */

    }

    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[(uint32)ETH_BECHANNEL] = (uint32)LpExtDataDesc;               /* PRQA S 0306 # JV-01 */
  }
  else
  {
    /* timestamp disabled */
    LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                        /* PRQA S 0306, 3432 # JV-01, JV-01 */

    if (ETH_DESC_FSINGLE_AVB == LpDataDesc->stHeader.ulDt)
    {
      /* descriptor type correct */
      LpSingleRxFramePtr->ulFrameAddr   = LpDataDesc->ulDptr;
      LpSingleRxFramePtr->ulEthTypeAddr = LpDataDesc->ulDptr + ETH_SRC_DST_ADDRESS_SIZE;                                /* PRQA S 3383 # JV-01 */
      LpSingleRxFramePtr->ulFrameLength = LpDataDesc->stHeader.ulDs;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      LpSingleRxFramePtr->enTimeQual    = ETH_INVALID;
      #endif
    }
    else
    {
      /* descriptor type incorrect */
      LpSingleRxFramePtr->ulFrameAddr   = (uint32)ETH_ZERO;
      LpSingleRxFramePtr->ulFrameLength = (uint32)ETH_ZERO;
    }
    LpDataDesc++;

    while ((LpDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
      (LpDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
    {
      LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LpDataDesc->ulDptr;                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }

    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[(uint32)ETH_BECHANNEL] = (uint32)LpDataDesc;                  /* PRQA S 0306 # JV-01 */
  }

}

/***********************************************************************************************************************
** Function Name         : RxNcProcess
**
** Service ID            : NA
**
** Description           : This  process network control queue
**                         (The PS bit isn't checked.)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Ethernet channel number
**                       : LulRxFramePtr - pointer to rx frame
**                       : LulDescPtr - pointer to rx Descriptor
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1003,
** Reference ID          : ETH_DUD_ACT_1003_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) RxNcProcess(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpSingleRxFramePtr,                                             /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulDescPtr)
{
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpExtDataDesc;                                                   /* PRQA S 3432, 3678 # JV-01, JV-01 */

  LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                    /* PRQA S 0306, 3432 # JV-01, JV-01 */

  if (ETH_DESC_FSINGLE_AVB == LpExtDataDesc->stHeader.ulDt)
  {
    /* Descriptor type correct */
    LpSingleRxFramePtr->ulFrameAddr   = LpExtDataDesc->ulDptr;
    LpSingleRxFramePtr->ulEthTypeAddr = LpExtDataDesc->ulDptr + ETH_SRC_DST_ADDRESS_SIZE;                               /* PRQA S 3383 # JV-01 */
    LpSingleRxFramePtr->ulFrameLength = LpExtDataDesc->stHeader.ulDs;
    #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
    LpSingleRxFramePtr->stTimeStamp.nanoseconds   = LpExtDataDesc->stTimestamp.ulTimestamp0;
    LpSingleRxFramePtr->stTimeStamp.seconds       = LpExtDataDesc->stTimestamp.ulTimestamp1;
    LpSingleRxFramePtr->stTimeStamp.secondsHi     = LpExtDataDesc->stTimestamp.usTimestamp2;
    LpSingleRxFramePtr->enTimeQual    = ETH_VALID;
    #endif
  }
  else
  {
    /* Descriptor type incorrect */
    LpSingleRxFramePtr->ulFrameAddr   = (uint32)ETH_ZERO;
    LpSingleRxFramePtr->ulFrameLength = (uint32)ETH_ZERO;
  }

  LpExtDataDesc++;
  while ((LpExtDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
    (LpExtDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
  {
    LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LpExtDataDesc->ulDptr;                       /* PRQA S 0306, 3432 # JV-01, JV-01 */
  }

  Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[(uint32)ETH_NCCHANNEL] = (uint32)LpExtDataDesc;                 /* PRQA S 0306 # JV-01 */
}

/***********************************************************************************************************************
** Function Name         : RxSProcess
**
** Service ID            : NA
**
** Description           : This  process stream queue
**                         (The PS bit isn't checked.)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx       - Instance number
**                       : LulRxFramePtr - pointer to rx frame
**                       : LulChannelNum - stream channel number
**                       : LulDescPtr - pointer to rx Descriptor
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1004,
** Reference ID          : ETH_DUD_ACT_1004_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) RxSProcess(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpSingleRxFramePtr,                                             /* PRQA S 3432 # JV-01 */
  CONST(uint32, AUTOMATIC) LulChannelNum, CONST(uint32, AUTOMATIC) LulDescPtr)
{
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                         /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpExtDataDesc;                                                   /* PRQA S 3432, 3678 # JV-01, JV-01 */
  Eth_OptionType LenRxSTimestamp;

  LenRxSTimestamp = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxSTimestamp;

  /* single frame single buffer */
  if (ETH_ENABLE == LenRxSTimestamp)
  {
    /* timestamp enabled */
    LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                  /* PRQA S 0306, 3432 # JV-01, JV-01 */

    if (ETH_DESC_FSINGLE_AVB == LpExtDataDesc->stHeader.ulDt)
    {
      /* descriptor type correct */
      LpSingleRxFramePtr->ulFrameAddr   = LpExtDataDesc->ulDptr;
      LpSingleRxFramePtr->ulEthTypeAddr = LpExtDataDesc->ulDptr + ETH_SRC_DST_ADDRESS_SIZE;                             /* PRQA S 3383 # JV-01 */
      LpSingleRxFramePtr->ulFrameLength = LpExtDataDesc->stHeader.ulDs;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      LpSingleRxFramePtr->stTimeStamp.nanoseconds   = LpExtDataDesc->stTimestamp.ulTimestamp0;
      LpSingleRxFramePtr->stTimeStamp.seconds       = LpExtDataDesc->stTimestamp.ulTimestamp1;
      LpSingleRxFramePtr->stTimeStamp.secondsHi     = LpExtDataDesc->stTimestamp.usTimestamp2;
      LpSingleRxFramePtr->enTimeQual    = ETH_VALID;
      #endif
    }
    else
    {
      /* descriptor type incorrect */
      LpSingleRxFramePtr->ulFrameAddr   = (uint32)ETH_ZERO;
      LpSingleRxFramePtr->ulFrameLength = (uint32)ETH_ZERO;
    }
    LpExtDataDesc++;
    while ((LpExtDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
      (LpExtDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
    {
      LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LpExtDataDesc->ulDptr;                     /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }

    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LulChannelNum] = (uint32)LpExtDataDesc;                       /* PRQA S 0306 # JV-01 */
  }
  else
  {
    /* timestamp disabled */
    LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                        /* PRQA S 0306, 3432 # JV-01, JV-01 */

    if (ETH_DESC_FSINGLE_AVB == LpDataDesc->stHeader.ulDt)
    {
      /* descriptor type correct */
      LpSingleRxFramePtr->ulFrameAddr   = LpDataDesc->ulDptr;
      LpSingleRxFramePtr->ulEthTypeAddr = LpDataDesc->ulDptr + ETH_SRC_DST_ADDRESS_SIZE;                                /* PRQA S 3383 # JV-01 */
      LpSingleRxFramePtr->ulFrameLength = LpDataDesc->stHeader.ulDs;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      LpSingleRxFramePtr->enTimeQual    = ETH_INVALID;
      #endif
    }
    else
    {
      /* descriptor type incorrect */
      LpSingleRxFramePtr->ulFrameAddr   = (uint32)ETH_ZERO;
      LpSingleRxFramePtr->ulFrameLength = (uint32)ETH_ZERO;
    }

    LpDataDesc++;
    while ((LpDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
      (LpDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
    {
      LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LpDataDesc->ulDptr;                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }

    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LulChannelNum] = (uint32)LpDataDesc;                          /* PRQA S 0306 # JV-01 */
  }

}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_DMACStructConfig
**
** Service ID            : NA
**
** Description           : This Initializes and enables Ethernet peripheral.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaAvbConfig
**                         Eth_GaaRxConfig, Eth_GaaQConfig
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1005,
** Reference ID          : ETH_DUD_ACT_1005_GBL001, ETH_DUD_ACT_1005_GBL002
** Reference ID          : ETH_DUD_ACT_1005_GBL003, ETH_DUD_ACT_1005_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE)Eth_Hw_ETNF_DMACStructConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  uint32 LulIdx;
  uint8 LucQidx;                                                                                                        /* PRQA S 1710 # JV-01 */
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  /* AVB part */
  Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enEncf = LpHwUnitConfig->stRxConfig.enEncf;
  Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enEsf  = LpHwUnitConfig->stRxConfig.enEsf;
  Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enEts0 = LpHwUnitConfig->stRxConfig.enEts0;
  Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enEts2 = LpHwUnitConfig->stRxConfig.enEts2;
  Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.ulRfcl = ETH_RX_FIFO_CRIT_LVL;
  #if (ETH_STREAM_FILTERING == STD_ON)
  Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enSRPTalkerFiltering = LpHwUnitConfig->stRxConfig.enSRPTalkerFiltering;
  #endif
  Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig.enTsm0 = ETH_TXNORMAL;
  Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig.enTsm1 = ETH_TXNORMAL;
  Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig.enTsm2 = ETH_TXNORMAL;
  Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig.enTsm3 = ETH_TXNORMAL;
  Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig.enEcbs = LpHwUnitConfig->enEcbs;
  Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig.enTqp = LpHwUnitConfig->enTxConfig;


  /* Read the number of Rx Queue Configured */
  for (LulIdx = (uint32)ETH_ZERO; LulIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LulIdx++)
  {
    LucQidx = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulIdx].ucEthRxQueueId;

    Eth_GaaRxConfig[LulCtrlIdx][LucQidx].ucChNum    = LucQidx;

    if (ETH_BECHANNEL == Eth_GaaRxConfig[LulCtrlIdx][LucQidx].ucChNum)
    {
      /* This is Rx BE */
      Eth_GaaRxConfig[LulCtrlIdx][LucQidx].enChType = ETH_RX_BE;
    }
    else if (ETH_NCCHANNEL == Eth_GaaRxConfig[LulCtrlIdx][LucQidx].ucChNum)
    {
      /* This is Rx NC */
      Eth_GaaRxConfig[LulCtrlIdx][LucQidx].enChType = ETH_RX_NC;
    }
    else
    {
      /* Rx Stream */
      Eth_GaaRxConfig[LulCtrlIdx][LucQidx].enChType = ETH_RX_S;
    }

    /* Queue Configuration */
    Eth_GaaQConfig[LulCtrlIdx][LulIdx].enPia = ETH_GAP32;
    Eth_GaaQConfig[LulCtrlIdx][LulIdx].enUfcc = ETH_UFCC0;
    Eth_GaaQConfig[LulCtrlIdx][LulIdx].enRsm = ETH_RXNORMAL;

    #if (ETH_STREAM_FILTERING == STD_ON)
    /* Save Pattern Address if Filtering is enabled */
    ETH_COPY_STREAM_ADDRESS(LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulIdx].aaEthPatternStream,                    /* PRQA S 3469 # JV-01 */
      Eth_GaaRxConfig[LulCtrlIdx][LucQidx].aaPatternStream);
    #endif
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_SingleDescFrameSend
**
** Service ID            : NA
**
** Description           : send frame (single frame single buffer)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LenQIndex - Queue Index
**                       : LpFrame - Tx Frame Pointer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LucReturnValue - E_OK / E_NOT_OK
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaETNFRegs
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION,
**                         ETH_EXIT_CRITICAL_SECTION,
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1006,
** Reference ID          : ETH_DUD_ACT_1006_CRT001, ETH_DUD_ACT_1006_CRT002
** Reference ID          : ETH_DUD_ACT_1006_GBL001, ETH_DUD_ACT_1006_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Hw_ETNF_SingleDescFrameSend(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufHdr)                                                  /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                         /* PRQA S 3432 # JV-01 */
  Eth_TxRxCtrl  LunTxCtrl;                                                                                              /* PRQA S 0759 # JV-01 */
  Std_ReturnType LucReturnValue;

  LucReturnValue = E_OK;

  /* Get next free descriptor */
  LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA))                                                      /* PRQA S 0306, 3432 # JV-01, JV-01 */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextTxDesc[LpTxBufHdr->ucTxQueueIdx];

  if (ETH_DESC_FEMPTY_AVB == LpDataDesc->stHeader.ulDt)
  {
    LunTxCtrl.ulWord = (uint32)ETH_ZERO;
    if (ETH_TRUE == LpTxBufHdr->blbenableTS)
    {
      LunTxCtrl.stTxCtrl.ulTsr = ETH_DESC_RETAIN_TS;
    }
    else
    {
      /* No action required */
    }
    /* Justify typecast to smaller datatype */
    LunTxCtrl.stTxCtrl.ulTag = LpTxBufHdr->ulbufIdx;

    /* Configures if MAC transmission status of the frame is stored in MAC status FIFO */
    LunTxCtrl.stTxCtrl.ulMsr = ETH_DESC_MAC_FIFO;

    /* build the descriptor */
    LpDataDesc->stHeader.ulDie  = (uint32)LpTxBufHdr->ucTxQueueIdx + (uint32)ETH_ONE;                                   /* PRQA S 3383 # JV-01 */
    LpDataDesc->stHeader.ulCtrl = LunTxCtrl.ulWord;
    LpDataDesc->stHeader.ulDs   = LpTxBufHdr->ulTxLength;
    LpDataDesc->ulDptr          = LpTxBufHdr->ulbufAddr;
    /* DT field is an exclusive control with HW, so it must be set at the end. */
    LpDataDesc->stHeader.ulDt   = ETH_DESC_FSINGLE_AVB;

    /* Set next descriptor */
    LpDataDesc++;
    while ((LpDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) || (LpDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
    {
      LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LpDataDesc->ulDptr;                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }

    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextTxDesc[LpTxBufHdr->ucTxQueueIdx] = (uint32)LpDataDesc;               /* PRQA S 0306 # JV-01 */

    ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Increase the number of buffer of current Tx queue */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaBufTxCnt[LpTxBufHdr->ucTxQueueIdx]++;                                    /* PRQA S 3383 # JV-01 */

    ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

    /* Transmit start request */
    Eth_GaaETNFRegs[LulCtrlIdx]->ulTCCR |= (uint32)((uint32)ETH_ONE << (uint32)LpTxBufHdr->ucTxQueueIdx);
  }
  else
  {
    LucReturnValue = E_NOT_OK;
  }

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_RxQueueProcess
**
** Service ID            : NA
**
** Description           : Process Receive Queue.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx  - Instance number
**                       : LucQidx - Rx queue index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaRxConfig
                           Eth_GaaCtrlStat, Eth_GaaRxBufferDataTable
                           Eth_CtrlRxMaxFrameLengthMapping, Eth_GaaRxBufferNodes
                           Eth_GaaRxFrame, Eth_GaaETNFRegs
**
** Function(s) invoked   : RxBeProcess
**                         IsRxFrameValid, RxNcProcess, RxSProcess
**                         EthSwt_EthRxProcessFrame, RxCallEthIf
**                         EthSwt_EthRxFinishedIndication, RxDescChainUpdate
**
** Registers Used        : UFCD
**
** Reference ID          : ETH_DUD_ACT_1007,
** Reference ID          : ETH_DUD_ACT_1007_REG001
** Reference ID          : ETH_DUD_ACT_1007_GBL001, ETH_DUD_ACT_1007_GBL002
** Reference ID          : ETH_DUD_ACT_1007_GBL003, ETH_DUD_ACT_1007_GBL004
** Reference ID          : ETH_DUD_ACT_1007_GBL005, ETH_DUD_ACT_1007_GBL006
** Reference ID          : ETH_DUD_ACT_1007_GBL007
***********************************************************************************************************************/
FUNC(boolean, ETH_PRIVATE_CODE) Eth_Hw_ETNF_RxQueueProcess(                                                             /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucQidx)
{
  uint32 LulDescAddr;
  boolean LblRxFrameValid;
  boolean LblRxFrameProcessed;
  Eth_BufIdxType LulBufIdx;
  P2CONST(Eth_RxChConfigType, AUTOMATIC, ETH_APPL_DATA) LpChConfig;
  P2VAR(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode;                                                  /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpCurrentDataDesc;                                                  /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpCurrentExtDataDesc;                                            /* PRQA S 3432, 3678 # JV-01, JV-01 */
  Eth_OptionType LenRxTimestamp;
  #if (ETH_GET_RX_STATS_API == STD_ON)
  uint32 LulLengthWithFCS;
  #endif

  #if (ETH_DEVICE_NAME == ETH_U5X)
  Eth_RxBufWarnLvlUserCalloutPtrType LpRxBufWarnLvlUserCallout;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  boolean LblIsMgmtFrameOnlyPtr;
  uint16 LusLength;
  Std_ReturnType LucReturnValue;
  #endif

  LblRxFrameValid = ETH_TRUE;                                                                                           /* PRQA S 2982 # JV-01 */
  LblRxFrameProcessed = ETH_FALSE;
  LpCurrentDataDesc = NULL_PTR;                                                                                         /* PRQA S 2982 # JV-01 */
  LpCurrentExtDataDesc = NULL_PTR;                                                                                      /* PRQA S 2982 # JV-01 */

  #if (ETH_DEVICE_NAME == ETH_U5X)
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

  /*Get Rx queue configuration */
  LpChConfig = &Eth_GaaRxConfig[LulCtrlIdx][LucQidx];

  if (ETH_BECHANNEL == LpChConfig->ucChNum)
  {
    /* Timestamp for best effort channel */
    LenRxTimestamp = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxBeTimestamp;
  }
  else if (ETH_NCCHANNEL == LpChConfig->ucChNum)
  {
    /* Timestamp for network control channel is always on */
    LenRxTimestamp = ETH_ENABLE;
  }
  else
  {
    /* Timestamp for stream channel */
    LenRxTimestamp = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxSTimestamp;
  }

  LulDescAddr = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum];

  /* Get Buffer index infor base on buffer address */
  if (ETH_ENABLE == LenRxTimestamp)
  {
    LpCurrentExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) (LulDescAddr);                        /* PRQA S 0306, 3432 # JV-01, JV-01 */
    LulBufIdx = (Eth_BufIdxType)((uint8*)(LpCurrentExtDataDesc->ulDptr)                                                 /* PRQA S 0306 # JV-01 */
                  - Eth_GaaRxBufferDataTable[LulCtrlIdx]) / Eth_CtrlRxMaxFrameLengthMapping[LulCtrlIdx];                /* PRQA S 0488 # JV-01 */
  }
  else
  {
    LpCurrentDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) (LulDescAddr);                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
    LulBufIdx = (Eth_BufIdxType)((uint8*)(LpCurrentDataDesc->ulDptr)                                                    /* PRQA S 0306 # JV-01 */
                  - Eth_GaaRxBufferDataTable[LulCtrlIdx]) / Eth_CtrlRxMaxFrameLengthMapping[LulCtrlIdx];                /* PRQA S 0488 # JV-01 */
  }

  /* Get the Rx Buffer Node infor */
  LpRxBufferNode = &Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx];

  /* Verify the status of buffer and descriptor mapping */
  if ((LpRxBufferNode->blLockedFlag == ETH_FALSE) && (LpRxBufferNode->ulRxDescAddr == LulDescAddr))
  {
    LblRxFrameProcessed = ETH_TRUE;

    if (ETH_BECHANNEL == LpChConfig->ucChNum)
    {
      /* best effort channel */
      RxBeProcess(LulCtrlIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulDescAddr);

      /* check whether received frame is valid or not */
      LblRxFrameValid = IsRxFrameValid(LulCtrlIdx, &Eth_GaaRxFrame[LulCtrlIdx]);
    }
    else if (ETH_NCCHANNEL == LpChConfig->ucChNum)
    {
      /* network control channel */
      RxNcProcess(LulCtrlIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulDescAddr);
    }
    else
    {
      /* stream channel */
      RxSProcess(LulCtrlIdx, &Eth_GaaRxFrame[LulCtrlIdx], (uint32)LpChConfig->ucChNum, LulDescAddr);

      /* check whether received frame is valid or not */
      LblRxFrameValid = IsRxFrameValid(LulCtrlIdx, &Eth_GaaRxFrame[LulCtrlIdx]);
    }
    /* Decrement ETNFnUFCD.DVr by 1 */
    Eth_GaaETNFRegs[LulCtrlIdx]->ulUFCD[ETH_ETNF_GET_UFCDi(LucQidx)] = ETH_ETNF_SET_UFCDi_DVr((uint32)ETH_ONE, LucQidx);/* PRQA S 3384, 3469 # JV-01, JV-01 */

    if (ETH_TRUE == LblRxFrameValid)
    {
      /* Lock Rx buffer */
      LpRxBufferNode->blLockedFlag = ETH_TRUE;

      #if (ETH_DEVICE_NAME == ETH_U5X)
      /* Increase the Buffer warning level counter */
      Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LucQidx] = 
                    Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LucQidx] + ETH_ONE;                                          /* PRQA S 3383 # JV-01 */

      #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
      /* Increase the Measurement counter for Buffer warning level */
      Eth_GaaCtrlStat[LulCtrlIdx].stMeasurementData.ulWarnFullRxBuffCnt++;
      #endif

      if (LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucQidx].usEthRxQueueBufs < 
                                        Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LucQidx])
      {
        /* All Rx buffers are occupied: */
        LpRxBufWarnLvlUserCallout = ETH_GET_USER_RXBUFF_WARNING_CALLOUT;
        if (NULL_PTR != LpRxBufWarnLvlUserCallout)                                                                      /* PRQA S 2991, 2992, 2995, 2996 # JV-01, JV-01, JV-01, JV-01 */
        {
          /* Call to the user Rx buffer warning call out function */
          LpRxBufWarnLvlUserCallout(LulCtrlIdx, LucQidx);
        }/* else No action required */
      }/* else No action required */
      #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

      #if (ETH_GET_RX_STATS_API == STD_ON)
      Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts++;                                                               /* PRQA S 3383 # JV-01 */
      LulLengthWithFCS = Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength + ETH_FCS_LENGTH;                                     /* PRQA S 3383 # JV-01 */
      Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOctets += LulLengthWithFCS;                                           /* PRQA S 3383 # JV-01 */
      if (LulLengthWithFCS <= (uint32)ETH_LENGTH_64B)
      {
        /* Since the receive data size that does not include padding data is set in the receive descriptor,
          frames of 64 or less are collected by the statistical counter. */
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts64Octets++;                                                     /* PRQA S 3383 # JV-01 */
      }
      else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_127B)
      {
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts65to127Octets++;                                                /* PRQA S 3383 # JV-01 */
      }
      else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_255B)
      {
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts128to255Octets++;                                               /* PRQA S 3383 # JV-01 */
      }
      else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_511B)
      {
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts256to511Octets++;                                               /* PRQA S 3383 # JV-01 */
      }
      else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_1023B)
      {
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts512to1023Octets++;                                              /* PRQA S 3383 # JV-01 */
      }
      else
      {
        /* When VLAN tag is supported, the maximum data size is 1522. */
        /* The maximum frame size that HW can receive is set to 1522. */
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts1024to1518Octets++;                                             /* PRQA S 3383 # JV-01 */
      }
      #endif

      #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
      LpDataPtr = (P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr;                     /* PRQA S 0306, 3432 # JV-01, JV-01 */
      /* Since the maximum value of buffer size is 1518, casting to uint16 does no problem. */
      LusLength = (uint16)(Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength - ETH_HEADER_SIZE);                                 /* PRQA S 3383 # JV-01 */
      LblIsMgmtFrameOnlyPtr = ETH_FALSE;
      /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
      LucReturnValue = EthSwt_EthRxProcessFrame((uint8)LulCtrlIdx, LulBufIdx, &LpDataPtr,
        &LusLength, &LblIsMgmtFrameOnlyPtr);
      if (E_OK == LucReturnValue)
      {
        Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = (uint32)LpDataPtr;                                                   /* PRQA S 0306 # JV-01 */
        Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = (uint32)(LusLength + ETH_HEADER_SIZE);                               /* PRQA S 3383 # JV-01 */

        if (ETH_FALSE == LblIsMgmtFrameOnlyPtr)
        {
          /* Call EthIf if the Frame Received is valid */
          RxCallEthIf(LulCtrlIdx, LucQidx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
        }
        else
        {
          /* Must not be the Rx processed */
          /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
          (void)EthSwt_EthRxFinishedIndication((uint8)LulCtrlIdx, LulBufIdx);
        }
      }
      else
      {
        /* Normal operation if E_NOT_OK */
        RxCallEthIf(LulCtrlIdx, LucQidx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
      }
      #else
      /* Call EthIf if the Frame Received is valid */
      RxCallEthIf(LulCtrlIdx, LucQidx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
      #endif
    }
    else
    {
      /* Frame Invalid - E.g. Multicast to be discarded */
      /* No Call of EthIf */
      /* Update descriptor chain */
      (void)RxDescChainUpdate(LulCtrlIdx, LulDescAddr, LpChConfig);
    }
  }
  else
  {
    /* The Rx buffer is locked */
    /* Set the next Rx descriptor */
    if (ETH_ENABLE == LenRxTimestamp)
    {

      LpCurrentExtDataDesc++;
      while ((LpCurrentExtDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
      (LpCurrentExtDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
      {
        LpCurrentExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LpCurrentExtDataDesc->ulDptr;     /* PRQA S 0306, 3432 # JV-01, JV-01 */
      }

      Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum] = (uint32)LpCurrentExtDataDesc;        /* PRQA S 0306 # JV-01 */
    }
    else
    {
      LpCurrentDataDesc++;
      while ((LpCurrentDataDesc->stHeader.ulDt == ETH_DESC_LINKFIX) ||
      (LpCurrentDataDesc->stHeader.ulDt == ETH_DESC_LINK_AVB))
      {
        LpCurrentDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LpCurrentDataDesc->ulDptr;              /* PRQA S 0306, 3432 # JV-01, JV-01 */
      }

      Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum] = (uint32)LpCurrentDataDesc;           /* PRQA S 0306 # JV-01 */
    }
  }

  return LblRxFrameProcessed;
}

/***********************************************************************************************************************
** Function Name         : RxCallEthIf
**
** Service ID            : NA
**
** Description           : Wrapper for the Callback to the Eth Interface for each frame received
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controller / Channel Index
**                       : LpFrame - Address of the Received Frame in URAM
**                       : LulBufIdx - Buffer index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : NA
**
** Global Variables Used : Eth_GaaTimeTuple, Eth_GstBroadcastAddr, Eth_GaaCtrlStat
**
** Function(s) invoked   : EthIf_RxIndication, EthSwt_EthRxFinishedIndication,
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1008,
** Reference ID          : ETH_DUD_ACT_1008_GBL001, ETH_DUD_ACT_1008_GBL002, ETH_DUD_ACT_1008_GBL003
***********************************************************************************************************************/
STATIC FUNC (void, ETH_PRIVATE_CODE) RxCallEthIf(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulQueueIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpFrame,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx)
{
  boolean LblBroadcast;
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) LpTimeTuplePtr;                                                        /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpFrameType;
  Eth_FrameType LddFrameType;
  Eth_MacAddressType LstMacAddr;
  P2CONST(Eth_EtherFrameTypeEtnf, AUTOMATIC, ETH_APPL_DATA) LstEtherFrame;

  LpTimeTuplePtr = &Eth_GaaTimeTuple[LulCtrlIdx][LulQueueIdx];

  LstEtherFrame = (P2CONST(Eth_EtherFrameTypeEtnf, AUTOMATIC, ETH_APPL_DATA)) LpFrame->ulFrameAddr;                     /* PRQA S 0306 # JV-01 */
  ETH_PACK_ADDRESS_FROM_8(LstEtherFrame->ucDstAddr, LstMacAddr);                                                        /* PRQA S 3469 # JV-01 */
  if ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstBroadcastAddr))                                            /* PRQA S 3469 # JV-01 */
  {
    LblBroadcast = ETH_TRUE;
    #if (ETH_GET_RX_STATS_API == STD_ON)
    Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsBroadcastPkts++;                                                        /* PRQA S 3383 # JV-01 */
    #endif
  }
  else
  {
    LblBroadcast = ETH_FALSE;
    #if (ETH_GET_RX_STATS_API == STD_ON)
    if ((uint32)ETH_ZERO == ETH_CHECK_MULTICAST(LstMacAddr))                                                            /* PRQA S 3469 # JV-01 */
    {
      /* Unicast frame */
      Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsDropEvents++;                                                         /* PRQA S 3383 # JV-01 */
    }
    else
    {
      /* No action required */
    }
    #endif
  }

  LpFrameType = (const Eth_DataType *)LpFrame->ulEthTypeAddr;                                                           /* PRQA S 0306 # JV-01 */
  LddFrameType = (Eth_FrameType)((uint32)LpFrameType[ETH_ZERO] << ETH_BYTE_BITS);
  LddFrameType |= (Eth_FrameType)LpFrameType[ETH_ONE];

  /* SWS_Eth_00327 */
  /* SWS_Eth_00323 */
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* Get the ingress timestamp from current RxFrame */
  LpTimeTuplePtr->timestampClockValue.nanoseconds   = LpFrame->stTimeStamp.nanoseconds;
  LpTimeTuplePtr->timestampClockValue.seconds       = LpFrame->stTimeStamp.seconds;
  LpTimeTuplePtr->timestampClockValue.secondsHi     = LpFrame->stTimeStamp.secondsHi;
  /* Since there is no xtimestamp support */
  LpTimeTuplePtr->disciplinedClockValue.nanoseconds = LpTimeTuplePtr->timestampClockValue.nanoseconds;
  LpTimeTuplePtr->disciplinedClockValue.seconds     = LpTimeTuplePtr->timestampClockValue.seconds;
  LpTimeTuplePtr->disciplinedClockValue.secondsHi   = LpTimeTuplePtr->timestampClockValue.secondsHi;

  LpTimeTuplePtr->timeQuality = LpFrame->enTimeQual;
  /* SWS_Eth_00324 */
  #else
  /* Set the timestamp as invalid */
  LpTimeTuplePtr->timestampClockValue.nanoseconds   = (uint32)ETH_ZERO;
  LpTimeTuplePtr->timestampClockValue.seconds       = (uint32)ETH_ZERO;
  LpTimeTuplePtr->timestampClockValue.secondsHi     = (uint16)ETH_ZERO;
  /* Since there is no xtimestamp support */
  LpTimeTuplePtr->disciplinedClockValue.nanoseconds = LpTimeTuplePtr->timestampClockValue.nanoseconds;
  LpTimeTuplePtr->disciplinedClockValue.seconds     = LpTimeTuplePtr->timestampClockValue.seconds;
  LpTimeTuplePtr->disciplinedClockValue.secondsHi   = LpTimeTuplePtr->timestampClockValue.secondsHi;
  LpTimeTuplePtr->timeQuality = ETH_INVALID;
  #endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

  /* Since the maximum value of Controller Index is 1, casting to uint8 does no problem. */
  EthIf_RxIndication((uint8)LulCtrlIdx, LddFrameType, LblBroadcast, LstEtherFrame->ucSrcAddr,
    LpFrameType + ETH_ETHERTYPE_SIZE, (uint16)(LpFrame->ulFrameLength - ETH_HEADER_SIZE),                               /* PRQA S 0488, 3383 # JV-01, JV-01 */
    LpTimeTuplePtr, LulBufIdx);

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  (void)EthSwt_EthRxFinishedIndication((uint8)LulCtrlIdx, LulBufIdx);
  #endif /* (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON) */
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_DescConfig
**
** Service ID            : NA
**
** Description           : Configure descriptor.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controlled Id
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : SetDescChain
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1009
** Reference ID          : ETH_DUD_ACT_1009_GBL001, ETH_DUD_ACT_1009_GBL002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Hw_ETNF_DescConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  uint8 LucQid; /* Index for the Queue */
  uint8 LucCnt;
  P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkAddr;                                                         /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpTargetAddr;                                                       /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  /* init link descriptor */
  LpLinkAddr = (P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA))                                                      /* PRQA S 0306, 3432 # JV-01, JV-01 */
    (Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.ulDescTableAddr);

  /*======TX Queues ========*/
  for (LucCnt = ETH_ZERO; LucCnt < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucCnt++)
  {
    /* Calculate target descriptor table address */
    LpTargetAddr = LpLinkAddr + LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucCnt].ucEthTxQueueId;                    /* PRQA S 0488 # JV-01 */
    if ((uint32)ETH_ZERO != LpTargetAddr->ulDptr)
    {
      /* Get Tx LucQid */
      LucQid = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucCnt].ucEthTxQueueId;
      SetDescChain(LulCtrlIdx, (LpTargetAddr->ulDptr), LucQid, ETH_TX);
    }
    else
    {
      /* This Queue is not configured */
    }
  }

  /* Set Rx Queues start position */
  LpLinkAddr = LpLinkAddr + ETH_RXBEQ_OFFSET;                                                                           /* PRQA S 0488 # JV-01 */

  /*======RX Queues ========*/
  for (LucCnt = ETH_ZERO; LucCnt < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LucCnt++)
  {
    /* Calculate target descriptor table address */
    LpTargetAddr = LpLinkAddr + LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCnt].ucEthRxQueueId;                    /* PRQA S 0488 # JV-01 */
    if ((uint32)ETH_ZERO != LpTargetAddr->ulDptr)
    {
      LucQid = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCnt].ucEthRxQueueId;
      SetDescChain(LulCtrlIdx, (LpTargetAddr->ulDptr), LucQid, ETH_RX);
    }
    else
    {
      /* This Queue is not configured */
    }
  }
}

/***********************************************************************************************************************
** Function Name         : SetDescChain
**
** Service ID            : NA
**
** Description           : Configured the Descriptor chain for each Queue (Circular Chain).
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controlled Id
**                       : LulAddr - Addr of the first descriptor in Queue
**                       : LucQidx - Index of the Queue (0..3 for Tx 0..17 for Rx)
**                       : LenDir - Queue Direction (e.g. TX or RX)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : SetFempty, SetLinkFix, SetExtFempty,
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1010
** Reference ID          : ETH_DUD_ACT_1010_GBL001, ETH_DUD_ACT_1010_GBL002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) SetDescChain(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulAddr,
  CONST(uint8, AUTOMATIC) LucQidx, CONST(Eth_DirectionType, AUTOMATIC) LenDir)                                          /* PRQA S 1710 # JV-01 */
{
  uint32 LulIdx;
  uint32 LulCfgIdx;
  Eth_OptionType LenRxTimestamp;
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpCurrentDataDesc;                                                  /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpCurrentExtDataDesc;                                            /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  /* Initialize the counter for any Queue */
  LulIdx = (uint32)ETH_ZERO;

  if ((uint32)ETH_ZERO != LulAddr)
  {
    if (ETH_TX == LenDir)
    {
      /* TX */
      /* Search for Tx configuration index */
      for (LulCfgIdx = (uint32)ETH_ZERO; LulCfgIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulCfgIdx++)
      {
        if (LucQidx == LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCfgIdx].ucEthTxQueueId)
        {
          break;
        }
        else
        {
          /* No action required */
        }
      }

      LpCurrentDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) (LulAddr);                                /* PRQA S 0306, 3432 # JV-01, JV-01 */
      do
      {
        if ((uint32)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCfgIdx].usEthTxQueueBufs -                         /* PRQA S 4391 # JV-01 */
          (uint16)ETH_CYCLIC_DESC_NUM) >= LulIdx)
        {
          /* Set FEmpty */
          SetFempty(LulCtrlIdx, LpCurrentDataDesc, LucQidx, ETH_TX, LulIdx);
        }
        else
        {
          /* Set LinkFix */
          SetLinkFix((uint32)LpCurrentDataDesc, LulAddr);                                                               /* PRQA S 0306 # JV-01 */
        }

        LpCurrentDataDesc++;
        LulIdx++;                                                                                                       /* PRQA S 3383 # JV-01 */
      }
      while (LulIdx <= (uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCfgIdx].usEthTxQueueBufs);
    }
    else
    {
      /* RX */
     /* Search for Rx configuration index */
      for (LulCfgIdx = (uint32)ETH_ZERO; LulCfgIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LulCfgIdx++)
      {
        if (LucQidx == LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCfgIdx].ucEthRxQueueId)
        {
          break;
        }
        else
        {
          /* No action required */
        }
      }

      /* Get Time Stamp status */
      if (ETH_NCCHANNEL == LucQidx)
      {
        LenRxTimestamp = ETH_ENABLE;
      }
      else if (ETH_BECHANNEL == LucQidx)
      {
        LenRxTimestamp = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxBeTimestamp;
      }
      else
      {
        LenRxTimestamp = Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxSTimestamp;
      }

      if (ETH_ENABLE == LenRxTimestamp)
      {
        /* TS Enable */
        LpCurrentExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) (LulAddr);                        /* PRQA S 0306, 3432 # JV-01, JV-01 */

        do
        {
          if ((uint32)LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCfgIdx].usEthRxQueueBufs > LulIdx)
          {
            /* Extended Data Descriptor */
            SetExtFempty(LulCtrlIdx, LpCurrentExtDataDesc, LucQidx, ETH_RX, LulIdx);
          }
          else
          {
            SetLinkFix((uint32)LpCurrentExtDataDesc, LulAddr);                                                          /* PRQA S 0306 # JV-01 */
          }
          LulIdx++;                                                                                                     /* PRQA S 3383 # JV-01 */
          LpCurrentExtDataDesc++;
        }
        while (LulIdx <= (uint32)LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCfgIdx].usEthRxQueueBufs);
      }
      else
      {
       /* TS Disable */
        LpCurrentDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) (LulAddr);                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
        do
        {
          if ((uint32)LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCfgIdx].usEthRxQueueBufs > LulIdx)
          {
            SetFempty(LulCtrlIdx, LpCurrentDataDesc, LucQidx, ETH_RX, LulIdx);
          }
          else
          {
            SetLinkFix((uint32)LpCurrentDataDesc, LulAddr);                                                             /* PRQA S 0306 # JV-01 */
          }
          LpCurrentDataDesc++;

          LulIdx++;                                                                                                     /* PRQA S 3383 # JV-01 */
        }
        while (LulIdx <= (uint32)LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCfgIdx].usEthRxQueueBufs);
        /* Better to repeat this code for any Queue */
        /* as in future we may have different No of buffers */
      }
    }
  }
}

/***********************************************************************************************************************
** Function Name         : SetFempty
**
** Service ID            : NA
**
** Description           : Set Fempty in the standard (8Bytes) descriptor
**                         chain for passed Queue and Buffer Index
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controlled Id
**                       : LpDescr - Pointer to a Data Descriptor
**                       : LucQidx-Index of the Queue (0..3 for Tx 0..17 for Rx)
**                       : LenQdir - Queue Direction (e.g. TX or RX)
**                       : LusBufidx - Index ot the TX or RX buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaRxBufferNodes
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1011
** Reference ID          : ETH_DUD_ACT_1011_GBL001, ETH_DUD_ACT_1011_GBL002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) SetFempty(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDescr,                  /* PRQA S 3432 # JV-01 */
  CONST(uint8, AUTOMATIC) LucQidx, CONST(Eth_DirectionType, AUTOMATIC) LenQdir,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx)
{
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpRxBuffer;                                                                    /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  uint16 LusBufIdxTmp;
  uint8 LucQIdxCnt;

  LusBufIdxTmp = (uint16)ETH_ZERO;
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;

  if (NULL_PTR != LpDescr)
  {
    if (ETH_TX == LenQdir)
    {
      /* TX Queue */
      LpDescr->stHeader.ulDie = (uint32)ETH_ZERO;
      LpDescr->stHeader.ulCtrl = (uint32)ETH_ZERO;
      /* It will be set only during Transmission at run time */
      LpDescr->stHeader.ulDs = (uint32)ETH_ZERO;
      LpDescr->ulDptr = (uint32)ETH_ZERO;
      LpDescr->stHeader.ulDt = ETH_DESC_FEMPTY_AVB;
    }
    else if (ETH_NCCHANNEL == LucQidx)
    {
      /* RX NC is always Extended Descriptor */
    }
    else
    {
      /* RX BE and S */
      LpDescr->stHeader.ulDie = (uint32)ETH_ZERO;
      LpDescr->stHeader.ulCtrl = (uint32)ETH_ZERO;
      LpDescr->stHeader.ulDs = ETH_RX_BUF_LENGTH;

      /* Caculate the base buffer index for the current queue */
      for (LucQIdxCnt = (uint8)ETH_ZERO; LucQIdxCnt < LucQidx; LucQIdxCnt++)
      {
        LusBufIdxTmp += LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucQIdxCnt].usEthRxQueueBufs;                      /* PRQA S 3383 # JV-01 */
      }
      LpRxBuffer = (uint8 *)Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulBufIdx].ulbufAddr;                       /* PRQA S 0306, 3383 # JV-01, JV-01 */

      LpDescr->ulDptr = (uint32)LpRxBuffer;                                                                             /* PRQA S 0306 # JV-01 */
      LpDescr->stHeader.ulDt = ETH_DESC_FEMPTY_AVB;

      /* Hold the Qidx, Rx descriptor address according to with Rx buffer for future manage */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulBufIdx].ucRxQueueIdx = LucQidx;                                /* PRQA S 3383 # JV-01 */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulBufIdx].ulRxDescAddr = (uint32)LpDescr;                        /* PRQA S 0306, 3383 # JV-01, JV-01 */
    }
  }
  else
  {
    /* Cannot Set Fempty for NULL Address */
  }
}

/***********************************************************************************************************************
** Function Name       : SetExtFempty
**
** Service ID          : NA
**
** Description         : Set Fempty in the extended (20Bytes) descriptor
**                       chain for passed Queue and Buffer Index
**
** Sync/Async          : Synchronous
**
** Reentrancy          : Non-Reentrant
**
** Input Parameters    : LulCtrlIdx - Controlled Id
**                     : LpDescr - Pointer to a Data Descriptor
**                     : LucQidx - Index of the Queue (0..3 for Tx 0..17 for Rx)
**                     : LenQdir - Queue Direction (e.g. TX or RX)
**                     : LulBufIdx - Index ot the TX or RX buffer
**
** InOut Parameters    : None
**
** Output Parameters   : None
**
** Return parameter    : None
**
** Preconditions       : None
**
** Global Variable(s)  : Eth_GpCtrlConfigPtr, Eth_GaaRxBufferNodes
**
** Function(s) invoked : None
**
** Registers Used      : None
**
** Reference ID        : ETH_DUD_ACT_1012
** Reference ID        : ETH_DUD_ACT_1012_GBL001, ETH_DUD_ACT_1012_GBL002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) SetExtFempty(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpDescr,                                                    /* PRQA S 3432 # JV-01 */
  CONST(uint8, AUTOMATIC) LucQidx, CONST(Eth_DirectionType, AUTOMATIC) LenQdir,                                         /* PRQA S 3206 # JV-01 */
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx)
{
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpRxBuffer;                                                                    /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  uint16 LusBufIdxTmp;
  uint8 LucQIdxCnt;

  LusBufIdxTmp = (uint16)ETH_ZERO;
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;

  if (NULL_PTR != LpDescr)
  {
    LpDescr->stHeader.ulDie = (uint32)ETH_ZERO;
    LpDescr->stHeader.ulCtrl = (uint32)ETH_ZERO;
    LpDescr->stHeader.ulDs = ETH_RX_BUF_LENGTH;
    LpDescr->stTimestamp.ulTimestamp0 = (uint32)ETH_ZERO;
    LpDescr->stTimestamp.ulTimestamp1 = (uint32)ETH_ZERO;
    LpDescr->stTimestamp.usTimestamp2 = (uint16)ETH_ZERO;

    /* Caculate the base buffer index for the current queue */
    for (LucQIdxCnt = (uint8)ETH_ZERO; LucQIdxCnt < LucQidx; LucQIdxCnt++)
    {
      LusBufIdxTmp += LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucQIdxCnt].usEthRxQueueBufs;                        /* PRQA S 3383 # JV-01 */
    }
    LpRxBuffer = (uint8 *)Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulBufIdx].ulbufAddr;                         /* PRQA S 0306, 3383 # JV-01, JV-01 */

    LpDescr->ulDptr = (uint32)LpRxBuffer;                                                                               /* PRQA S 0306 # JV-01 */
    LpDescr->stHeader.ulDt = ETH_DESC_FEMPTY_AVB;

    /* Hold the Qidx, Rx descriptor address according to with Rx buffer for future manage */
    Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulBufIdx].ucRxQueueIdx = LucQidx;                                  /* PRQA S 3383 # JV-01 */
    Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulBufIdx].ulRxDescAddr = (uint32)LpDescr;                          /* PRQA S 0306, 3383 # JV-01, JV-01 */
  }
  else
  {
    /* Cannot Set Fempty for NULL Address */
    /* Error as TX Descr are always Standard and not extended */
  }
}

/***********************************************************************************************************************
** Function Name         : SetLinkFix
**
** Service ID            : NA
**
** Description           : Set LinkFix in the descriptor chain passed as first Argument
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulLinkDesc - Pointer to the Descriptor to be set
**                       : LulAddrToLink - Link Address to be set
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1013
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) SetLinkFix(
  CONST(uint32, AUTOMATIC) LulLinkDesc, CONST(uint32, AUTOMATIC) LulAddrToLink)
{
  P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDesc;                                                         /* PRQA S 3432 # JV-01 */
  LpLinkDesc = (P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA)) LulLinkDesc;                                         /* PRQA S 0306, 3432 # JV-01, JV-01 */

  LpLinkDesc->stHeader.ulDie = (uint32)ETH_ZERO;
  LpLinkDesc->stHeader.ulRes = (uint32)ETH_ZERO;
  LpLinkDesc->ulDptr         = LulAddrToLink;
  LpLinkDesc->stHeader.ulDt  = ETH_DESC_LINKFIX;
}

/***********************************************************************************************************************
** Function Name         : DescUpdate
**
** Service ID            : NA
**
** Description           : update descriptor chain (without timestamp support).
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulDescPtr - pointer to descriptor to be updated
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LpDataDesc - last descriptor address
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1014
***********************************************************************************************************************/
STATIC FUNC(uint32, ETH_PRIVATE_CODE) DescUpdate(
  CONST(uint32, AUTOMATIC) LulDescPtr)
{
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                         /* PRQA S 3432 # JV-01 */
  LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                          /* PRQA S 0306, 3432 # JV-01, JV-01 */

  LpDataDesc->stHeader.ulDie  = (uint32)ETH_ZERO;
  LpDataDesc->stHeader.ulCtrl = (uint32)ETH_ZERO;
  LpDataDesc->stHeader.ulDs   = ETH_RX_BUF_LENGTH;
  LpDataDesc->stHeader.ulDt   = ETH_DESC_FEMPTY_AVB;

  return ((uint32)LpDataDesc);                                                                                          /* PRQA S 0306 # JV-01 */
}

/***********************************************************************************************************************
** Function Name         : DescTsUpdate
**
** Service ID            : NA
**
** Description           : update descriptor chain (with timestamp support).
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulDescPtr - pointer to descriptor to be updated
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LpExtDataDesc - last descriptor address
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1015
***********************************************************************************************************************/
STATIC FUNC(uint32, ETH_PRIVATE_CODE) DescTsUpdate(
  CONST(uint32, AUTOMATIC) LulDescPtr)
{
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpExtDataDesc;                                                   /* PRQA S 3432 # JV-01 */
  LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA)) LulDescPtr;                                    /* PRQA S 0306, 3432 # JV-01, JV-01 */

  LpExtDataDesc->stHeader.ulDie  = (uint32)ETH_ZERO;
  LpExtDataDesc->stHeader.ulCtrl = (uint32)ETH_ZERO;
  LpExtDataDesc->stHeader.ulDs   = ETH_RX_BUF_LENGTH;
  LpExtDataDesc->stTimestamp.ulTimestamp0 = (uint32)ETH_ZERO;
  LpExtDataDesc->stTimestamp.ulTimestamp1 = (uint32)ETH_ZERO;
  LpExtDataDesc->stTimestamp.usTimestamp2 = (uint16)ETH_ZERO;
  LpExtDataDesc->stHeader.ulDt   = ETH_DESC_FEMPTY_AVB;

  return ((uint32)LpExtDataDesc);                                                                                       /* PRQA S 0306 # JV-01 */
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_DMACInit
**
** Service ID            : NA
**
** Description           : Initialize DMAC
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaAvbConfig, Eth_GaaETNFRegs
**
** Function(s) invoked   : TxRxConfig, TxRxIntConfig, SetCbsParameter,
**                         RxQueueSet, SetRxFilter
**
** Registers Used        : CCC, EIC, GIC, RPC
**
** Reference ID          : ETH_DUD_ACT_1016,
** Reference ID          : ETH_DUD_ACT_1016_REG002, ETH_DUD_ACT_1016_REG002
** Reference ID          : ETH_DUD_ACT_1016_REG003, ETH_DUD_ACT_1016_REG004
** Reference ID          : ETH_DUD_ACT_1016_GBL001, ETH_DUD_ACT_1016_GBL002, ETH_DUD_ACT_1016_GBL003
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Hw_ETNF_DMACInit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  /* configure CCC register */
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enInternalLoopBackMode)                                              /* PRQA S 3416 # JV-01 */
  {
    Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC |= ETH_ETNF_CCC_LBME;
  }
  else
  {
    /* No action required */
  }

  /* configure Error interrupt mask - EIC register */
  Eth_GaaETNFRegs[LulCtrlIdx]->ulEIC = ETH_ETNF_EIC_ERROR;
  /* configure reception part - RCR register */
  /* configure transmission part - TGC register */
  TxRxConfig(LulCtrlIdx, &(Eth_GaaAvbConfig[LulCtrlIdx].stTxConfig), &(Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig));

  TxRxIntConfig(LulCtrlIdx);

  #if (ETH_QOS_SUPPORT == STD_ON)
  /* Set CBS Counter parameters (CIV and CDV)  */
  SetCbsParameter(LulCtrlIdx);
  #endif

  /* set GIC interrupt */
  Eth_GaaETNFRegs[LulCtrlIdx]->ulGIC = (uint32)ETH_ZERO;

  /* Set RQCi register */
  RxQueueSet(LulCtrlIdx);

  /* Set padding to zero - Padding Not used */
  Eth_GaaETNFRegs[LulCtrlIdx]->ulRPC = (uint32)ETH_ZERO;

  /* Set Common RX Filter if enabled */
  #if (ETH_STREAM_FILTERING == STD_ON)
  SetRxFilter(LulCtrlIdx);
  #endif
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_OpModeChange
**
** Service ID            : NA
**
** Description           : To change Operating Mode.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LenMode - Mode to change
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Ethernet Error
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaETNFRegs
**
** Function(s) invoked   : GetCounterValue, Eth_ETNF_GetElapsedTimeValue
**
** Registers Used        : CCC, CSR
**
** Reference ID          : ETH_DUD_ACT_1017,
** Reference ID          : ETH_DUD_ACT_1017_REG001, ETH_DUD_ACT_1017_REG002
** Reference ID          : ETH_DUD_ACT_1017_GBL001, ETH_DUD_ACT_1017_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Hw_ETNF_OpModeChange(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(Eth_OpStatusType, AUTOMATIC) LenMode)
{
  Std_ReturnType LucReturnValue;
  uint32 LulRegVal;
  TickType LulTickStart;
  TickType LulTickElap;

  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;

  if (Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enDevStatus != LenMode)
  {
    LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC & ~ETH_ETNF_CCC_OPC_MASK;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC = LulRegVal | (uint32)LenMode;

    (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
      LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCSR & ETH_ETNF_CSR_OPS;
    } while ((LulRegVal != ((uint32)ETH_ONE << (uint32)LenMode)) && (LulTickElap <= ETH_TIMEOUT_COUNT));

    if (((uint32)ETH_ONE << (uint32)LenMode) == LulRegVal)
    {
      /* No Time-out - mode changed  */
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enDevStatus = LenMode;
      LucReturnValue = E_OK;
    }
    else
    {
      /* Return Error - as mode not changed */
      LucReturnValue = E_NOT_OK;
    }
  }
  else
  {
    /* Controller is already in the requested state */
    LucReturnValue = E_OK;
  }

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : RxQueueSet
**
** Service ID            : NA
**
** Description           : Set Receive Queue
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LpQconfig  - Queue config structure pointer
**                       : LulQIndex - Queue Index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaETNFRegs,
**                         Eth_GaaQConfig
**
** Function(s) invoked   : None
**
** Registers Used        : RQCi
**
** Reference ID          : ETH_DUD_ACT_1018
** Reference ID          : ETH_DUD_ACT_1018_GBL001, ETH_DUD_ACT_1018_GBL002, ETH_DUD_ACT_1018_GBL001
** Reference ID          : ETH_DUD_ACT_1018_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) RxQueueSet(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  uint32 LulIdx;
  uint32 LulQIndex;
  uint32 LulConfig;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;

  for (LulIdx = (uint32)ETH_ZERO; LulIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LulIdx++)
  {
    LulQIndex = (uint32) (LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulIdx].ucEthRxQueueId);

    LulConfig = (uint32)(ETH_ETNF_SET_RQCi_RSMr(Eth_GaaQConfig[LulCtrlIdx][LulIdx].enRsm, LulQIndex) |                  /* PRQA S 3384, 3469 # JV-01, JV-01 */
      ETH_ETNF_SET_RQCi_UFCCr(Eth_GaaQConfig[LulCtrlIdx][LulIdx].enUfcc, LulQIndex) |                                   /* PRQA S 3383, 3384, 3469 # JV-01, JV-01, JV-01 */
      ETH_ETNF_SET_RQCi_PIAr(Eth_GaaQConfig[LulCtrlIdx][LulIdx].enPia, LulQIndex));                                     /* PRQA S 3383, 3384, 3469 # JV-01, JV-01, JV-01 */
    Eth_GaaETNFRegs[LulCtrlIdx]->ulRQC[ETH_ETNF_GET_RQCi(LulQIndex)] = LulConfig;                                       /* PRQA S 3469 # JV-01 */
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_UFCounterGet
**
** Service ID            : NA
**
** Description           : Get Unread Frame Counter
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LulQIndex - Queue Index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LulUFCount - Number of unread frames
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaETNFRegs
**
** Function(s) invoked   : None
**
** Registers Used        : UFCVi
**
** Reference ID          : ETH_DUD_ACT_1019
** Reference ID          : ETH_DUD_ACT_1019_REG001
** Reference ID          : ETH_DUD_ACT_1019_GBL001
***********************************************************************************************************************/
FUNC(uint32, ETH_PRIVATE_CODE) Eth_Hw_ETNF_UFCounterGet(                                                                /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQIndex)
{
  uint32  LulUfcv;
  uint32  LulUFCount;
  LulUfcv = Eth_GaaETNFRegs[LulCtrlIdx]->ulUFCV[ETH_ETNF_GET_UFCVi(LulQIndex)];                                         /* PRQA S 3469 # JV-01 */
  LulUFCount = ETH_ETNF_GET_UFCVi_CVr(LulUfcv, LulQIndex);                                                              /* PRQA S 3384 # JV-01 */
  return (LulUFCount);
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_RxDescChainConfig
**
** Service ID            : NA
**
** Description           : configure Rx descriptor chain
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LpChConfig - Channel Config Pointer Index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaETNFRegs
**
** Function(s) invoked   : RxDescChainUpdate,
**
** Registers Used        : DLR
**
** Reference ID          : ETH_DUD_ACT_1020,
** Reference ID          : ETH_DUD_ACT_1020_REG001,
** Reference ID          : ETH_DUD_ACT_1020_GBL001, ETH_DUD_ACT_1020_GBL002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Hw_ETNF_RxDescChainConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_RxChConfigType, AUTOMATIC, ETH_APPL_DATA) LpChConfig)
{
  P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkAddr;                                                         /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                         /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA) LpExtDataDesc;                                                   /* PRQA S 3432, 3678 # JV-01, JV-01 */
  LpLinkAddr = (P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA))                                                      /* PRQA S 0306, 3432 # JV-01, JV-01 */
    (Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.ulDescTableAddr);

  LpLinkAddr += (ETH_RXBEQ_OFFSET + LpChConfig->ucChNum);                                                               /* PRQA S 0488 # JV-01 */
  Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum] = (uint32)(LpLinkAddr->ulDptr);

  if (ETH_BECHANNEL == LpChConfig->ucChNum)
  {
    /* best effort channel */
    if (ETH_DISABLE == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxBeTimestamp)
    {
      LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA))                                                  /* PRQA S 0306, 3432 # JV-01, JV-01 */
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum];
      do
      {
        LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA))                                                /* PRQA S 0306, 3432 # JV-01, JV-01 */
          RxDescChainUpdate(LulCtrlIdx, (uint32)LpDataDesc, LpChConfig);                                                /* PRQA S 0306 # JV-01 */
        LpDataDesc++;
      } while (LpDataDesc->stHeader.ulDt != ETH_DESC_LINKFIX);
    }
    else
    {
      LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA))                                            /* PRQA S 0306, 3432 # JV-01, JV-01 */
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum];
      do
      {
        LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA))                                          /* PRQA S 0306, 3432 # JV-01, JV-01 */
          RxDescChainUpdate(LulCtrlIdx, (uint32)LpExtDataDesc, LpChConfig);                                             /* PRQA S 0306 # JV-01 */
        LpExtDataDesc++;
      } while (LpExtDataDesc->stHeader.ulDt != ETH_DESC_LINKFIX);
    }
  }
  else if (ETH_NCCHANNEL == LpChConfig->ucChNum)
  {
    /* network control channel */
    LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum];
    do
    {
      LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA))                                            /* PRQA S 0306, 3432 # JV-01, JV-01 */
        RxDescChainUpdate(LulCtrlIdx, (uint32)LpExtDataDesc, LpChConfig);                                               /* PRQA S 0306 # JV-01 */
      LpExtDataDesc++;
    } while (LpExtDataDesc->stHeader.ulDt != ETH_DESC_LINKFIX);

  }
  else
  {
    /* stream channel */
    if (ETH_DISABLE == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxSTimestamp)
    {
      LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA))                                                  /* PRQA S 0306, 3432 # JV-01, JV-01 */
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum];
      do
      {
        LpDataDesc = (P2VAR(Eth_DataDescType, AUTOMATIC, ETH_APPL_DATA))                                                /* PRQA S 0306, 3432 # JV-01, JV-01 */
          RxDescChainUpdate(LulCtrlIdx, (uint32)LpDataDesc, LpChConfig);                                                /* PRQA S 0306 # JV-01 */

        LpDataDesc++;
      } while (LpDataDesc->stHeader.ulDt != ETH_DESC_LINKFIX);
    }
    else
    {
      LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA))                                            /* PRQA S 0306, 3432 # JV-01, JV-01 */
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LpChConfig->ucChNum];
      do
      {
        LpExtDataDesc = (P2VAR(Eth_ExtDataDescType, AUTOMATIC, ETH_APPL_DATA))                                          /* PRQA S 0306, 3432 # JV-01, JV-01 */
          RxDescChainUpdate(LulCtrlIdx, (uint32)LpExtDataDesc, LpChConfig);                                             /* PRQA S 0306 # JV-01 */

        LpExtDataDesc++;
      } while (LpExtDataDesc->stHeader.ulDt != ETH_DESC_LINKFIX);
    }
  }
  /* reload desc. base address */
  if (ETH_OPERATION == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enDevStatus)
  {
    Eth_GaaETNFRegs[LulCtrlIdx]->ulDLR = ((uint32)ETH_ONE << (LpChConfig->ucChNum + ETH_RXBEQ_OFFSET));
  }
  else
  {
    /* No action required */
  }
}

/***********************************************************************************************************************
** Function Name         : RxDescChainUpdate
**
** Service ID            : NA
**
** Description           : Update receive descriptor chain
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LulDescPtr - Descriptor pointer
**                       : LpChConfig - Channel Config Pointer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LulLastDesc - Last processed descriptor address
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : DescUpdate, DescTsUpdate
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1021
** Reference ID          : ETH_DUD_ACT_1021_GBL001
***********************************************************************************************************************/
FUNC(uint32, ETH_PRIVATE_CODE) RxDescChainUpdate(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulDescPtr,
  CONSTP2CONST(Eth_RxChConfigType, AUTOMATIC, ETH_APPL_DATA) LpChConfig)
{
  uint32 LulLastDesc;

  switch (LpChConfig->enChType)
  {
  case ETH_RX_BE:
    if (ETH_DISABLE == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxBeTimestamp)
    {
      LulLastDesc = DescUpdate(LulDescPtr);
    }
    else
    {
      LulLastDesc = DescTsUpdate(LulDescPtr);
    }
    break;
  case ETH_RX_S:
    if (ETH_DISABLE == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxSTimestamp)
    {
      LulLastDesc = DescUpdate(LulDescPtr);
    }
    else
    {
      LulLastDesc = DescTsUpdate(LulDescPtr);
    }
    break;
  /* ETH_RX_NC */
  default:
    LulLastDesc = DescTsUpdate(LulDescPtr);
    break;
  }
  return (LulLastDesc);
}

/***********************************************************************************************************************
** Function Name         : TxRxConfig
**
** Service ID            : NA
**
** Description           : Tx parameters Config
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LpTxConfig - Tx Config Pointer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaETNFRegs
**
** Function(s) invoked   : None
**
** Registers Used        : RCR, TGC
**
** Reference ID          : ETH_DUD_ACT_1022,
** Reference ID          : ETH_DUD_ACT_1022_REG001, ETH_DUD_ACT_1022_REG002
** Reference ID          : ETH_DUD_ACT_1022_GBL001, ETH_DUD_ACT_1022_GBL002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) TxRxConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_TxConfigType, AUTOMATIC, ETH_APPL_DATA) LpTxConfig,
  CONSTP2CONST(Eth_RxConfigTypeEtnf, AUTOMATIC, ETH_APPL_DATA) LpRxConfig)
{
  uint32 LulRegVal;
  LulRegVal = (uint32)(((uint32)LpRxConfig->enEncf << ETH_ETNF_RCR_ENCF_SHIFT) |
              ((uint32)LpRxConfig->enEsf << ETH_ETNF_RCR_ESF_SHIFT) |
              ((uint32)LpRxConfig->enEts0 << ETH_ETNF_RCR_ETS0_SHIFT) |
              ((uint32)LpRxConfig->enEts2 << ETH_ETNF_RCR_ETS2_SHIFT) |
              ((uint32)LpRxConfig->ulRfcl << ETH_ETNF_RCR_RFCL_SHIFT));

  Eth_GaaETNFRegs[LulCtrlIdx]->ulRCR = LulRegVal;

  Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxBeTimestamp = LpRxConfig->enEts0;
  Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enRxSTimestamp = LpRxConfig->enEts2;
  LulRegVal = (uint32)(((uint32)LpTxConfig->enTsm0) |
              ((uint32)LpTxConfig->enTsm1 << ETH_ETNF_TGC_TSM1_SHIFT) |
              ((uint32)LpTxConfig->enTsm2 << ETH_ETNF_TGC_TSM2_SHIFT) |
              ((uint32)LpTxConfig->enTsm3 << ETH_ETNF_TGC_TSM3_SHIFT) |
              ((uint32)LpTxConfig->enEcbs << ETH_ETNF_TGC_TQP0_SHIFT) |
              ((uint32)LpTxConfig->enTqp << ETH_ETNF_TGC_TQP1_SHIFT) |
               ETH_ETNF_TGC_TBDn_VALUE);

  Eth_GaaETNFRegs[LulCtrlIdx]->ulTGC = LulRegVal;
}

/***********************************************************************************************************************
** Function Name         : TxRxIntConfig
**
** Service ID            : NA
**
** Description           : Tx/Rx Interrupt config
**
** Sync/Async            : NA
**
** Reentrancy            : NA
**
** Input Parameters      : LulCtrlIdx - Instance number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaETNFRegs
**                         Eth_GpEthConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : RICx, DIC, TIC
**
** Reference ID          : ETH_DUD_ACT_1023,
** Reference ID          : ETH_DUD_ACT_1023_GBL001, ETH_DUD_ACT_1023_GBL002, ETH_DUD_ACT_1023_GBL003
** Reference ID          : ETH_DUD_ACT_1023_REG001, ETH_DUD_ACT_1023_REG002, ETH_DUD_ACT_1023_REG001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) TxRxIntConfig(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)                                                                                  /* PRQA S 3206 # JV-01 */
{
  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON || ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  uint8 LucIdx;
  #endif
  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
  uint8 LucQIdx;                                                                                                        /* PRQA S 1710 # JV-01 */
  #endif
  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  uint8 LucBitNo;
  #endif

  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON || ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  #endif

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enRxInterruptMode)                                                   /* PRQA S 3416 # JV-01 */
  {
    /* set RIC0 interrupt */
    for (LucIdx = (uint8)ETH_ZERO; LucIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LucIdx++)
    {
      LucBitNo = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucIdx].ucEthRxQueueId;
      Eth_GaaETNFRegs[LulCtrlIdx]->ulRIC0 |= ((uint32)ETH_ONE << LucBitNo);
    }
  }
  else
  {
    /* No action required */
  }
  #endif

  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enTxInterruptMode)                                                   /* PRQA S 3416 # JV-01 */
  {
    /* set descriptor interrupt */
    for (LucIdx = (uint8)ETH_ZERO; LucIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucIdx++)
    {
      /* Get Tx queue id */
      LucQIdx = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucIdx].ucEthTxQueueId;
      /* Enable descriptor interrupt
      Queue n (n = 0..3): corresponding to descriptor interrupt (n + 1) */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulDIC |= ((uint32)ETH_ONE << (LucQIdx + (uint32)ETH_ONE));                           /* PRQA S 3383 # JV-01 */
    }
  }
  else
  {
    /* No action required */
  }
  #endif

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaETNFRegs[LulCtrlIdx]->ulTIC = ETH_TIC_TFUE;
  #endif
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_SYS_AllocDescBuffer
**
** Service ID            : NA
**
** Description           : Allocate memory for DBA (Descriptor Base Address)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaTxDescTableEtnf
**                         Eth_GaaCtrlStat, Eth_GaaRxDescTableEtnf
**
** Function(s) invoked   : FillDescMemory, IsQueueConfigured
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1024
** Reference ID          : ETH_DUD_ACT_1024_GBL001, ETH_DUD_ACT_1024_GBL002, ETH_DUD_ACT_1024_GBL003
** Reference ID          : ETH_DUD_ACT_1024_GBL004
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Hw_ETNF_SYS_AllocDescBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  Eth_DirectionType LenQdirection; /* Direction Tx or Rx of the Queue */
  uint8 LucQid;                   /* Index of the Queue  */
  uint8 LucIdx;
  boolean LblQueueConfig;
  Std_ReturnType LucReturnValue;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDesc;                                                         /* PRQA S 3432 # JV-01 */
  uint32 LulTxDescAddr;
  uint32 LulRxDescAddr;
  uint16 LulCntK;

  LucReturnValue = E_OK;
  LulCntK = (uint16)ETH_ZERO;
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;

  /* TX Queue */
  for (LucIdx = (uint8)ETH_ZERO; LucIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucIdx++)
  {
    LenQdirection = ETH_TX;
    LucQid = LucIdx;
    LblQueueConfig = IsQueueConfigured(LulCtrlIdx, LucQid, LenQdirection);

    if (ETH_TRUE == LblQueueConfig)
    {
      /* Queue has been configured */
      /* Alloc Desc Chain Memory */
      /* Get Tx descriptor table address */
      LulTxDescAddr = (uint32)(&Eth_GaaTxDescTableEtnf[LulCtrlIdx][LulCntK]);                                           /* PRQA S 0306 # JV-01 */

      /* Move to the correct index with the next queue */
      LulCntK += LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucIdx].usEthTxQueueBufs + ETH_CYCLIC_DESC_NUM;           /* PRQA S 3383, 3384 # JV-01, JV-01 */

      /* Access to the invalid index of array */
      if ((uint32)ETH_ZERO != LulTxDescAddr)
      {
        /* Store the head Tx descriptor address */
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextTxDesc[LucIdx] = LulTxDescAddr;
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaHeadTxDesc[LucIdx] = LulTxDescAddr;

        LpLinkDesc = (P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA))                                                /* PRQA S 0306, 3432 # JV-01, JV-01 */
          (Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.ulDescTableAddr)
            + (uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucIdx].ucEthTxQueueId;                              /* PRQA S 0488 # JV-01 */

        FillDescMemory(LpLinkDesc, LulTxDescAddr);
      }
      else
      {
        LucReturnValue = E_NOT_OK;
        break;
      }
    }/* else No action required */
  } /* end loop for all Tx Queues  */

  LulCntK = (uint16)ETH_ZERO;
  /* Rx Queue */
  for (LucIdx = (uint8)ETH_ZERO; LucIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LucIdx++)
  {
    LenQdirection = ETH_RX;
    LucQid = LucIdx;

    LblQueueConfig = IsQueueConfigured(LulCtrlIdx, LucQid, LenQdirection);

    if (ETH_TRUE == LblQueueConfig)
    {
      /* Queue has been configured */
      /* Alloc Desc Chain Memory */
      /* Get Rx descriptor table address */
      LulRxDescAddr = (uint32)(&Eth_GaaRxDescTableEtnf[LulCtrlIdx][LulCntK]);                                           /* PRQA S 0306 # JV-01 */

      /* Move to the correct index with the next queue */
      LulCntK += LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucIdx].usEthRxQueueBufs + ETH_CYCLIC_DESC_NUM;           /* PRQA S 3383, 3384 # JV-01, JV-01 */

      #if(ETH_DEVICE_NAME == ETH_U5X)
      /* Reset the Buffer warning level counter */
      Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LucIdx] = ETH_ZERO;
      #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

      /* Access to the invalid index of array */
      if ((uint32)ETH_ZERO != LulRxDescAddr)
      {
        /* Store the next Rx descriptor address */
        Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.aaNextRxDesc[LucIdx] = LulRxDescAddr;

        LpLinkDesc = (P2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA))                                                /* PRQA S 0306, 3432 # JV-01, JV-01 */
          (Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.ulDescTableAddr) + ETH_TXQ_NUM_ETNF                                 /* PRQA S 0488 # JV-01 */
           + (uint32)LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucIdx].ucEthRxQueueId;                               /* PRQA S 0488 # JV-01 */

        FillDescMemory(LpLinkDesc, LulRxDescAddr);
      }
      else
      {
        LucReturnValue = E_NOT_OK;
        break;
      }
    }/* else No action required */
  } /* end loop for all Rx Queues  */

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : FillDescMemory
**
** Service ID            : NA
**
** Description           : Set LinkFix for all DBA for each Queue
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulDescAddr
**
** InOut Parameters      : LpLinkDescr
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1025
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) FillDescMemory(
  CONSTP2VAR(Eth_LinkDescType, AUTOMATIC, ETH_APPL_DATA) LpLinkDescr, CONST(uint32, AUTOMATIC) LulDescAddr)             /* PRQA S 3432 # JV-01 */
{
  if (NULL_PTR != LpLinkDescr)
  {
    LpLinkDescr->stHeader.ulDie  = (uint32)ETH_ZERO;
    LpLinkDescr->stHeader.ulRes  = (uint32)ETH_ZERO;
    LpLinkDescr->ulDptr          = LulDescAddr;
    LpLinkDescr->stHeader.ulDt   = ETH_DESC_LINKFIX;
  }
  else
  {
    /* No action at this level */
  }
}

/***********************************************************************************************************************
** Function Name         : IsQueueConfigured
**
** Service ID            : NA
**
** Description           : Use the Binary Search Algo to discover if
**                         a Queue is configured and in this case return
**                         Direction otherwise return false and
**                         Direction is irrelevant
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LucQidx - Queue Index to see if configured
**                       : LenDir - Direction Type
**
** InOut Parameters      : None
**
** Output Parameters     : pDir Direction of the Queue Configured
**
** Return parameter      : True: Qidx found in config structure
**                       : False: Qidx not found in config struct
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1026
** Reference ID          : ETH_DUD_ACT_1026_GBL001
***********************************************************************************************************************/
STATIC FUNC(boolean, ETH_PRIVATE_CODE) IsQueueConfigured(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucQidx, CONST(Eth_DirectionType, AUTOMATIC) LenDir)     /* PRQA S 1710 # JV-01 */
{
  uint8 LucVal;
  boolean LblReturnVal;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  LucVal = (uint8)ETH_ZERO;
  LblReturnVal = ETH_FALSE;

  if (ETH_TX == LenDir)
  {
    /* Tx Queues */
    do
    {
      if (LucQidx == LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucVal].ucEthTxQueueId)
      {
        LblReturnVal = ETH_TRUE;
      }
      else
      {
        LucVal++;                                                                                                       /* PRQA S 3383 # JV-01 */
      }
    }
    while ((ETH_FALSE == LblReturnVal) && (LucVal < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue));
  }
  else
  {
    /* Rx Queues */
    do
    {
      if (LucQidx == LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucVal].ucEthRxQueueId)
      {
        LblReturnVal = ETH_TRUE;
      }
      else
      {
        LucVal++;                                                                                                       /* PRQA S 3383 # JV-01 */
      }
    }
    while ((ETH_FALSE == LblReturnVal) && (LucVal < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue));
  }

  return (LblReturnVal);
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_DisableController
**
** Service ID            : NA
**
** Description           : This Disables the indexed Ethernet Controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Ethernet Controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaETNFRegs, Eth_GaaCtrlStat
**
** Function(s) invoked   : GetCounterValue, Eth_ETNF_GetElapsedTimeValue,
**                         Eth_Hw_ETNF_OpModeChange
**
** Registers Used        : ETNFnCCC, ETNFnECMR, ETNFnTCCR, ETNFnCSR
**
** Reference ID          : ETH_DUD_ACT_1027,
** Reference ID          : ETH_DUD_ACT_1027_REG001, ETH_DUD_ACT_1027_REG002
** Reference ID          : ETH_DUD_ACT_1027_REG003, ETH_DUD_ACT_1027_REG004
** Reference ID          : ETH_DUD_ACT_1027_GBL001, ETH_DUD_ACT_1027_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Hw_ETNF_DisableController(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  Std_ReturnType LucErrorValue;
  TickType LulTickStart;
  TickType LulTickElap;
  uint32 LulRegVal;

  if (ETH_OPERATION == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enDevStatus)
  {
    /* Disable the DMAC and MAC of Controller for pending Tx or Rx */
    LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulECMR;
    LulRegVal &= ~ETH_ETNF_ECMR_RE_TE;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulECMR = LulRegVal;

    /* Wait for completion of transmission request */
    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
      LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulTCCR & ETH_TCCR_TSRQX_MASK;                                            
    } while ((LulRegVal != (uint32)ETH_ZERO) && (LulTickElap <= ETH_TIMEOUT_COUNT));
    /* Wait for completion of reception/transmit process */
    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
      LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCSR & ETH_CSR_TDUO_RPO_TPOX_MASK;                                      
    } while ((LulRegVal != (uint32)ETH_ZERO) && (LulTickElap <= ETH_TIMEOUT_COUNT));

    /* Process all required status information */
    /* In ETNF, necessary information is not reset in CONFIG and STANDBY mode.*/
    Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC |= ETH_ETNF_CCC_DTSR;

    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
      LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCSR & ETH_ETNF_CSR_DTS;                                                
    } while ((LulRegVal != ETH_ETNF_CSR_DTS) && (LulTickElap <= ETH_TIMEOUT_COUNT));
  }
  else
  {
    /* No action required */
  }

  LucErrorValue = Eth_Hw_ETNF_OpModeChange(LulCtrlIdx, ETH_CONFIG);

  if (ETH_CONFIG != Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enDevStatus)
  {
    LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC & ~ETH_ETNF_CCC_OPC_MASK;                                            
    Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC = LulRegVal | ETH_ETNF_CCC_OPC_OPERATION;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC = Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC & ~ETH_ETNF_CCC_DTSR;                       

    /* Wait for completion of reception/transmit process */
    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
      LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCSR & ETH_ETNF_CSR_TDUO_RPO;
    } while ((LulRegVal != (uint32)ETH_ZERO) && (LulTickElap <= ETH_TIMEOUT_COUNT));

    Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC = Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC | ETH_ETNF_CCC_DTSR;                        

    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
      LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulCSR & ETH_ETNF_CSR_DTS;
    } while ((LulRegVal != ETH_ETNF_CSR_DTS) && (LulTickElap <= ETH_TIMEOUT_COUNT));

    LucErrorValue = Eth_Hw_ETNF_OpModeChange(LulCtrlIdx, ETH_CONFIG);
  }
  else
  {
    /* No action required */
  }
  Eth_GaaETNFRegs[LulCtrlIdx]->ulCCC &= ~ETH_ETNF_CCC_DTSR;

  return LucErrorValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETNF_GetElapsedTimeValue
**
** Service ID            : NA
**
** Description           : This returns the elapsed timeout value of  Os timer
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LusTimeOutCount_Init
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LulTimeOutCount_Elapsed - TickType
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : GetCounterValue
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1028
***********************************************************************************************************************/
FUNC(TickType, ETH_PRIVATE_CODE) Eth_ETNF_GetElapsedTimeValue(
  P2VAR(TickType, AUTOMATIC, ETH_APPL_DATA) LusTimeOutCount)                                                            /* PRQA S 3432 # JV-01 */
{
  TickType LulTimeOutCount_Curr;
  TickType LulTimeOutCount_Elapsed;
  TickType LusTimeOutCount_Init;

  LusTimeOutCount_Init = *LusTimeOutCount;

  LulTimeOutCount_Curr = (uint32)ETH_ZERO;

  /* Get the current tick value from OS Counter */
  (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTimeOutCount_Curr);

  /* Check whether current time out exceeds initial time out value */
  if (LulTimeOutCount_Curr >= LusTimeOutCount_Init)
  {
    /* Get elapsed time out count */
    LulTimeOutCount_Elapsed = LulTimeOutCount_Curr - LusTimeOutCount_Init;
  }
  else
  {
    /* Get elapsed time out count */
    LulTimeOutCount_Elapsed = ((uint32)ETH_OS_COUNTER_MAX_VALUE - LusTimeOutCount_Init) + LulTimeOutCount_Curr;         /* PRQA S 3383 # JV-01 */
  }

  *LusTimeOutCount = LulTimeOutCount_Curr;

  return LulTimeOutCount_Elapsed;
}

#if (ETH_STREAM_FILTERING == STD_ON)
/***********************************************************************************************************************
** Function Name         : SetRxFilter
**
** Service ID            : NA
**
** Description           : Configure SFO, SFM, SFP
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Ethernet Controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : void
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaETNFRegs, Eth_GaaAvbConfig
**                         Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : Eth_Hw_ETNF_WriteIntoSFPReg
**
** Registers Used        : SFO, SFMx
**
** Reference ID          : ETH_DUD_ACT_1029,
** Reference ID          : ETH_DUD_ACT_1029_GBL001, ETH_DUD_ACT_1029_GBL002, ETH_DUD_ACT_1029_GBL003
** Reference ID          : ETH_DUD_ACT_1029_REG001, ETH_DUD_ACT_1029_REG002
***********************************************************************************************************************/
STATIC FUNC (void,  ETH_PRIVATE_CODE) SetRxFilter(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  #if (ETH_STREAM_FILTERING == STD_ON)
  VAR(uint8, AUTOMATIC) LucNumberOfRxQueue;
  VAR(uint8, AUTOMATIC) LucCount;
  VAR(uint8, AUTOMATIC) LucQidx;                                                                                        /* PRQA S 1710 # JV-01 */
  #endif
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  Eth_GaaETNFRegs[LulCtrlIdx]->ulSFO = ETH_ETNF_SFO_FBP_VALUE;
  if (ETH_ENABLE == Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enSRPTalkerFiltering)
  {
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFM[ETH_ZERO] = ETH_ETNF_SFM0_TALKERFILTER;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFM[ETH_ONE] = ETH_ETNF_SFM1_TALKERFILTER;
  }
  else
  {
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFM[ETH_ZERO] = ETH_ETNF_SFM0_LISNERFILTER;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFM[ETH_ONE] = ETH_ETNF_SFM1_LISNERFILTER;
  }

  #if (ETH_STREAM_FILTERING == STD_ON)
  /* Get number of configured queues */
  LucNumberOfRxQueue = LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue;
  for (LucCount = ETH_ZERO; LucCount < LucNumberOfRxQueue; LucCount++)
  {
    LucQidx = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCount].ucEthRxQueueId;

    /* If Rx Queue is Stream set corresponding SPFI register */
    if (ETH_NCCHANNEL < LucQidx)
    {
      /* Write into SFP Register */
      Eth_Hw_ETNF_WriteIntoSFPReg(
        LulCtrlIdx, LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucCount].aaEthPatternStream, LucQidx);
    }
    else
    {
      /* NO action as this is not a RX Stream Queue */
    }
  }
  #endif
}

/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_WriteIntoSFPReg
**
** Service ID            : NA
**
** Description           : Write In corresponding SFPi the passed address
**                         (for Rx Filter)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Ethernet Controller index
**                       : LpMacAddrPtr - Pointer to the address to be stored
**                       : LucQueueIdx - In case of clear this is the index of
**                         the SFP register minus offset
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : AVB shall be into Config Mode
**
** Global Variable(s)    : Eth_GaaAvbConfig, Eth_GaaCtrlStat, Eth_GaaETNFRegs
**
** Function(s) invoked   : None
**
** Registers Used        : SFV, SFL, SFPi i = 0,1..31
**
** Reference ID          : ETH_DUD_ACT_1030,
** Reference ID          : ETH_DUD_ACT_1030_REG001, ETH_DUD_ACT_1030_REG002, ETH_DUD_ACT_1030_REG003
** Reference ID          : ETH_DUD_ACT_1030_GBL001, ETH_DUD_ACT_1030_GBL002, ETH_DUD_ACT_1030_GBL003
***********************************************************************************************************************/
FUNC (void, ETH_PRIVATE_CODE) Eth_Hw_ETNF_WriteIntoSFPReg(
  CONST(uint32,AUTOMATIC) LulCtrlIdx, CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpMacAddrPtr,
  CONST(uint8,AUTOMATIC) LucQueueIdx)
{
  uint32 LulValHigh;
  uint32 LulValLow;
  uint32 LulVal;
  uint8 LucSFPidx;
  /************ Little Endian Core **************/
  LucSFPidx = LucQueueIdx - ETH_RX_QUEUE_INDEX_AVAILABLE_FILTER;                                                        /* PRQA S 3383 # JV-01 */
  /* Write into SFP1,3,...31 */
  if (ETH_ENABLE == Eth_GaaAvbConfig[LulCtrlIdx].stRxConfig.enSRPTalkerFiltering)
  {
    LulValHigh = ((uint32)LpMacAddrPtr[ETH_FIVE] << ETH_EIGHT) | ((uint32)LpMacAddrPtr[ETH_FOUR]);
  }
  else
  {
    LulValHigh = ((uint32)LpMacAddrPtr[ETH_SEVEN] << ETH_TWENTLY_FOUR) |
      ((uint32)LpMacAddrPtr[ETH_SIX] << ETH_SIXTEEN) | ((uint32)LpMacAddrPtr[ETH_FIVE] << ETH_EIGHT) |
      ((uint32)LpMacAddrPtr[ETH_FOUR]);
  }
  /* Write into SFP0,2,..30 */
  LulValLow = ((uint32)LpMacAddrPtr[ETH_THREE] << ETH_TWENTLY_FOUR) | ((uint32)LpMacAddrPtr[ETH_TWO] << ETH_SIXTEEN) |
    ((uint32)LpMacAddrPtr[ETH_ONE] << ETH_EIGHT) | ((uint32)LpMacAddrPtr[ETH_ZERO]);
  /* Read Opc */
  if (ETH_OPERATION == Eth_GaaCtrlStat[LulCtrlIdx].stHwStatEtnf.enDevStatus)
  {
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFV[ETH_ZERO] = LulValLow;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFV[ETH_ONE] = LulValHigh;
    /* Check it can be updated */

    do
    {
      LulVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulSFL;
    } while (ETH_NO_LOAD_REQ != (LulVal & ETH_SFL_MASK));

    /* SFP update request */
    LulVal = (uint32)LucSFPidx;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFL = LulVal;
  }
  else
  {
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFP[ETH_ETNF_GET_LOW_SFPi(LucSFPidx)] = LulValLow;                                   /* PRQA S 3383, 3469 # JV-01, JV-01 */
    Eth_GaaETNFRegs[LulCtrlIdx]->ulSFP[ETH_ETNF_GET_HIGH_SFPi(LucSFPidx)] = LulValHigh;                                 /* PRQA S 3383, 3469 # JV-01, JV-01 */
  }

}
#endif /* (ETH_STREAM_FILTERING == STD_ON) */

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_WaitPTPRequestIsComplete
**
** Service ID            : NA
**
** Description           : Service Api to wait a Gptp request is complete
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx   Index of the controller within the
**                         context of the Ethernet Driver
**                       : LucBit Which Bit to poll in GCCR Register
**
** InOut Parameters      : None
**
** Output Parameters     : E_OK   gPTP Request is completed w/o timeout
**                       : E_NOT_OK gPTP Request not completed due to timeout
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GaaETNFRegs
**
** Function(s) invoked   : GetCounterValue, Eth_ETNF_GetElapsedTimeValue
**
** Registers Used        : GCCR
**
** Reference ID          : ETH_DUD_ACT_1031
** Reference ID          : ETH_DUD_ACT_1031_GBL001
** Reference ID          : ETH_DUD_ACT_1031_REG001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_Hw_ETNF_WaitPTPRequestIsComplete(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32,AUTOMATIC) LulMask)
{
  Std_ReturnType LucReturnValue;
  uint32 LulRegValue;
  TickType LulTickStart;
  TickType LulTickElap;

  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;

  (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETNF_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
    LulRegValue = Eth_GaaETNFRegs[LulCtrlIdx]->ulGCCR & LulMask;
  } while ((LulRegValue != (uint32)ETH_ZERO) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    /* Timeout Occurred */
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* Success */
    LucReturnValue = E_OK;
  }
 return (LucReturnValue);
}

#endif /* ETH_GLOBAL_TIME_SUPPORT */

/***********************************************************************************************************************
** Function Name         : IsRxFrameValid
**
** Service ID            : NA
**
** Description           : Compare Mac Address Frame just received with
**                         Broadcast and Controller Mac Address.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LpRxFrame. Pointer to the Frame just received
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LblPass
**                         True : Frame DA is Broadcast or
**                         matches with the Source Address of this Controller
**                         False : Otherwise
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GaaCtrlFilterAddr,
**                         Eth_GaaAddressFilters
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1032
** Reference ID          : ETH_DUD_ACT_1032_GBL001, ETH_DUD_ACT_1032_GBL002, ETH_DUD_ACT_1032_GBL003
***********************************************************************************************************************/
STATIC FUNC(boolean, ETH_PRIVATE_CODE) IsRxFrameValid(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpRxFrame)
{
  Eth_MacAddressType LstDstAddress;
  boolean LblPass;
  uint32 LulFilterIdx;
  uint32 LulRemainBits;

  LblPass = ETH_FALSE;
  ETH_PACK_ADDRESS_FROM_8(((P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))LpRxFrame->ulFrameAddr), LstDstAddress);             /* PRQA S 0306, 3432, 3469 # JV-01, JV-01, JV-01 */

  /* Check whether promiscuous mode, broadcast, own unicast, multicast address is not registed */
  if ((ETH_TRUE == Eth_GaaCtrlStat[LulCtrlIdx].blPromiscuous) ||
      ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstDstAddress, Eth_GstBroadcastAddr)) ||                                     /* PRQA S 3469 # JV-01 */
      ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstDstAddress, Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr)))                      /* PRQA S 3469 # JV-01 */
  {
    LblPass = ETH_TRUE;
  }
  else
  {
    /* Otherwise, do the filter operation */

    /* To skip empty filters efficiently, copy active bits to the local var */
    LulRemainBits = Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits;
    LulFilterIdx = (uint32)ETH_ZERO;
    /* Loop until any filter hits or pass all active filters */
    while ((uint32)ETH_ZERO != LulRemainBits)
    {
      if (((uint32)ETH_ZERO != (LulRemainBits & ((uint32)ETH_ONE << LulFilterIdx))) &&
          ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstDstAddress, Eth_GaaAddressFilters[LulCtrlIdx][LulFilterIdx])))        /* PRQA S 3469 # JV-01 */
      {
        LblPass = ETH_TRUE;
        break;
      }
      else
      {
        /* No action required */
      }
      /* Clear the compared filter bit */
      LulRemainBits &= ~((uint32)ETH_ONE << LulFilterIdx);
      LulFilterIdx++;                                                                                                   /* PRQA S 3383 # JV-01 */
    }
  }

  return (LblPass);
}

#if (ETH_QOS_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : SetCbsParameter
**
** Service ID            : NA
**
** Description           : Set Tx queues configured
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of the controller within the
**                         context of the Ethernet Driver
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaETNFRegs, Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : CIVRx, CDVRx, CULx, CLLx
**
** Reference ID          : ETH_DUD_ACT_1033,
** Reference ID          : ETH_DUD_ACT_1033_GBL001, ETH_DUD_ACT_1033_GBL002,
** Reference ID          : ETH_DUD_ACT_1033_REG001, ETH_DUD_ACT_1033_REG002,
** Reference ID          : ETH_DUD_ACT_1033_REG003, ETH_DUD_ACT_1033_REG004,
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) SetCbsParameter(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  uint32 LulQidx;                                                                                                       /* PRQA S 1710 # JV-01 */
  uint32 LulCIV_tmp;
  uint32 LulCDV_tmp; /* negative number represented in 2'complement */
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  /* loop through all Tx Queues configured */
  LulQidx = (uint32)ETH_ZERO;
  do
  {
    if (((uint8)(ETH_TX_SB) == LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].ucEthTxQueueId) &&
      (ETH_CBS == LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].stTxQueueShaper.enTxQPolicy))
    {
      /* Q2 */
      LulCIV_tmp = (uint32)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].stTxQueueShaper.ulCiv);

      LulCDV_tmp = (uint32)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].stTxQueueShaper.slCdv);
      /* Write into CIVR0 , CDVR0 */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCIVR[ETH_ZERO] = LulCIV_tmp;
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCDVR[ETH_ZERO] = LulCDV_tmp;
      /* Set Upper Limit => 65535 */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCUL[ETH_ZERO] = ETH_MAX_CIV;
      /* Set Lower Limit => -65536 */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCLL[ETH_ZERO] = ETH_MIN_CDV;
    }
    else if (((uint8)(ETH_TX_SA) == LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].ucEthTxQueueId) &&
      (ETH_CBS == LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].stTxQueueShaper.enTxQPolicy))
    {
      /* Q3 */
      LulCIV_tmp = (uint32)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].stTxQueueShaper.ulCiv);

      LulCDV_tmp = (uint32)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulQidx].stTxQueueShaper.slCdv);

      /* Write into CIVR1 , CDVR1 */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCIVR[ETH_ONE] = LulCIV_tmp;
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCDVR[ETH_ONE] = LulCDV_tmp;
      /* Set Upper Limit => 65535 */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCUL[ETH_ONE] = ETH_MAX_CIV;
      /* Set Lower Limit => -65536 */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulCLL[ETH_ONE] = ETH_MIN_CDV;
    }
    else
    {
      /* Nothing to set for this Tx Queue */
    }

    LulQidx++;                                                                                                          /* PRQA S 3383 # JV-01 */
  } while (LulQidx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue);
}
#endif

#if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_Hw_ETNF_RxIrqHdlr
**
** Service ID            : NA
**
** Description           : This API Handles frame reception interrupts
**                         of the indexed controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variables Used : Eth_GpCtrlConfigPtr, Eth_GaaETNFRegs
**
** Function(s) invoked   : Eth_Hw_ETNF_UFCounterGet,
**                         Eth_Hw_ETNF_RxQueueProcess
**
** Registers Used        : RIS0
**
** Reference ID          : ETH_DUD_ACT_1034
** Reference ID          : ETH_DUD_ACT_1034_GBL001, ETH_DUD_ACT_1034_GBL002
** Reference ID          : ETH_DUD_ACT_1034_REG001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_Hw_ETNF_RxIrqHdlr(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  uint32 LulRIS0;
  uint32 LulIdx;
  uint8 LucQidx;                                                                                                        /* PRQA S 1710 # JV-01 */
  uint32 LulCnt;
  uint32 LulUnreadFrameCnt;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;
  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  /* Initialize the counter */
  LulIdx = (uint32)ETH_ZERO;
  /* Get receive interrupt status */
  LulRIS0 = Eth_GaaETNFRegs[LulCtrlIdx]->ulRIS0 & ETH_RX_INT_MASK;

  while ((uint32)ETH_ZERO != LulRIS0)
  {
    LucQidx = LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulIdx].ucEthRxQueueId;
    if (ETH_BIT1_SET_32 == ((LulRIS0 >> LucQidx) & ETH_BIT1_SET_32))
    {
      LulUnreadFrameCnt = Eth_Hw_ETNF_UFCounterGet(LulCtrlIdx, (uint32)LucQidx);

      /* Queue that has received some frame/s */
      for (LulCnt = (uint32)ETH_ZERO; LulCnt < LulUnreadFrameCnt; LulCnt++)
      {
        /* Rx frame data processing */
        (void)Eth_Hw_ETNF_RxQueueProcess(LulCtrlIdx, LucQidx);
      }
    }
    else
    {
      /* No action required */
    }

    if (LulIdx < (uint32)(LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue - (uint32)ETH_ONE))                           /* PRQA S 3383, 4391 # JV-01, JV-01 */
    {
      /* Next configured queue */
      LulIdx++;
    }
    else
    {
      /* Clear the flag to exit loop */
      LulRIS0 = (uint32)ETH_ZERO;
    }
  }
}
#endif /* (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) */

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* (ETH_MACRO_ETNF == STD_ON) */
/***********************************************************************************************************************
**                                               End of File                                                          **
***********************************************************************************************************************/
