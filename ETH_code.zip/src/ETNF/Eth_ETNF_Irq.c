/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETNF_Irq.c                                                                                      */
/*====================================================================================================================*/
/*                                             COPYRIGHT                                                              */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Interrupt Service Routine for  Ethernet Driver Component                                        */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x                                                                                        */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                       Revision Control History                                                     **
***********************************************************************************************************************/
/*
 * 1.4.0  26/03/2026    : Update functions ETH_AVB0DATAISR, ETH_AVB0ERRISR, ETH_AVB0MNGISR and add functions
 *                        ETH_AVB1DATAISR, ETH_AVB1ERRISR, ETH_AVB1MNGISR, Eth_AvbDataIsr, Eth_AvbErrIsr, Eth_AvbMngIsr
 *                        as new to support for new instance of ETNF.
 * 1.0.1: 27/02/2025    : Remove WA() implementation.
 *                        Update function ETH_AVB0MNGISR to add code clear the interrupt flag.
 * 1.0.0: 21/10/2024    : Add WA() in function ETH_AVB0ERRISR, ETH_AVB0MNGISR to workaround for HW defect.
 *        29/08/2024    : Modify function ETH_AVB0MNGISR to use Eth_GaaTxBufferMgrTable instead of Eth_GaaTxBufferIndex.
 *        25/06/2024    : Support Interrupt ARDAACL-46847.
 *        09/04/2024    : Initial Version.
 */
/******************************************************************************/

/***********************************************************************************************************************
**                                       Include Section                                                              **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_Ram.h"
#include "Eth_ETNF_Irq.h"
#include "Eth_ETNF_Dma.h"
#include "Eth_ETNF_Ram.h"
/* Included for declaration of the function Dem_ReportErrorStatus() */
#include "Dem.h"
/***********************************************************************************************************************
**                                      Version Information                                                           **
***********************************************************************************************************************/
#if (ETH_MACRO_ETNF == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETNF_IRQ_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_ETNF_IRQ_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_ETNF_IRQ_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_ETNF_IRQ_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_ETNF_IRQ_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                      Version Check                                                                 **
***********************************************************************************************************************/

/* Functionality related to R4.0 */
#if (ETH_AR_RELEASE_MAJOR_VERSION != ETH_ETNF_IRQ_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_ETNF_Irq.c : Mismatch in Release Major Version"
#endif
#if (ETH_AR_RELEASE_MINOR_VERSION != ETH_ETNF_IRQ_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_ETNF_Irq.c : Mismatch in Release Minor Version"
#endif
#if (ETH_AR_RELEASE_REVISION_VERSION != ETH_ETNF_IRQ_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_ETNF_Irq.c : Mismatch in Release Revision Version"
#endif

#if (ETH_SW_MAJOR_VERSION != ETH_ETNF_IRQ_C_SW_MAJOR_VERSION)
  #error "Eth_ETNF_Irq.c : Mismatch in Software Major Version"
#endif
#if (ETH_SW_MINOR_VERSION != ETH_ETNF_IRQ_C_SW_MINOR_VERSION)
  #error "Eth_ETNF_Irq.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1006)    : This in-line assembler construct is a language extension. The code has been ignored.         */
/* Rule                : CERTCCM MSC14, MISRA C:2012 Dir-1.1, Rule-1.2, Dir-4.2                                       */
/* JV-01 Justification : This is accepted, due to the Synchronization Processing Instruction is following hardware    */
/*                       specification.                                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-2.1                             */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2996)    : The result of this logical operation is always 'false'.                                      */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on device status, there is case where the 'if' will return 'true'.                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3006)    : This function contains a mixture of in-line assembler statements and C statements.           */
/* Rule                : MISRA C:2012 Dir-4.3, CWE Rule CWE-398, CWE-569                                              */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3408)    : '%1s' has external linkage and is being defined without any previous declaration.            */
/* Rule                : CERTCCM DCL07, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.4                             */
/* JV-01 Justification : It is accepted, due to the declaration will be taken care by Os                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3415)    : Right hand operand of '&&' or '||' is an expression with persistent side effects.            */
/* Rule                : CERTCCM EXP02, CWE Rule CWE-398, CWE-569, CWE-768, MISRA C:2012 Rule-13.5                    */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Although it is a volatile object, it is not a direct access to the HW register, and there    */
/*                       is no side effect.                                                                           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-1157, CWE-398, CWE-569,                                          */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:4404)    : An expression of 'essentially Boolean' type (%1s) is being converted to unsigned type,       */
/*                       '%2s' on assignment.                                                                         */
/* Rule                : CWE Rule CWE-192, CWE-681, CWE-136,  MISRA C:2012 Rule-10.3                                  */
/* JV-01 Justification : This is accepted, due to value assignments of variables of type boolean is following         */
/*                       AUTOSAR rule.                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:4558)    : An expression of 'essentially unsigned' type (%1s) is being used as the %2s operand of this  */
/*                       logical operator (%3s).                                                                      */
/* Rule                : CWE Rule CWE-136,  MISRA C:2012 Rule-10.1                                                    */
/* JV-01 Justification : This is accepted, due to value assignments of variables of type boolean is following         */
/*                       AUTOSAR rule.                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/***********************************************************************************************************************
**                                              Global Data                                                           **
***********************************************************************************************************************/
/***********************************************************************************************************************
**                                              Function Definitions                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_CODE_FAST
#include "Eth_MemMap.h"

#if ((ETH_AVB0_DATA_ISR == STD_ON) || (ETH_AVB1_DATA_ISR == STD_ON))
STATIC FUNC(void, ETH_CODE_FAST) Eth_AvbDataIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif /* ((ETH_AVB0_DATA_ISR == STD_ON) || (ETH_AVB1_DATA_ISR == STD_ON)) */

#if ((ETH_AVB0_ERR_ISR == STD_ON) || (ETH_AVB1_ERR_ISR == STD_ON))
STATIC FUNC(void, ETH_CODE_FAST) Eth_AvbErrIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif

#if ((ETH_AVB0_MNG_ISR == STD_ON) || (ETH_AVB1_MNG_ISR == STD_ON))
STATIC FUNC(void, ETH_CODE_FAST) Eth_AvbMngIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif /* ((ETH_AVB0_MNG_ISR == STD_ON) || (ETH_AVB1_MNG_ISR == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : ETH_AVB0DATAISR
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_AvbDataIsr
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
#if (ETH_AVB0_DATA_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_AVB0DATAISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_AVB0DATAISR_CAT2)                                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_AVB0DATAISR(void)                                                             /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_AvbDataIsr((uint32)ETHAVB0);
}
#endif /* (ETH_AVB0_DATA_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_AVB1DATAISR
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_AvbDataIsr
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
#if (ETH_AVB1_DATA_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_AVB1DATAISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_AVB1DATAISR_CAT2)                                                                                               /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_AVB1DATAISR(void)                                                             /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_AvbDataIsr((uint32)ETHAVB1);
}
#endif /* (ETH_AVB1_DATA_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_AVB0ERRISR
**
** Service ID            : NA
**
** Description           : Error Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_AvbErrIsr
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
#if (ETH_AVB0_ERR_ISR == STD_ON)
#if defined (Os_ETH_AVB0ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_AVB0ERRISR_CAT2)                                                                                                /* PRQA S 1503, 3006, 3408 # JV-01, JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_AVB0ERRISR(void)                                                              /* PRQA S 1503, 3006 # JV-01, JV-01 */
#endif
{
  Eth_AvbErrIsr((uint32)ETHAVB0);
}

#endif /* (ETH_AVB0_ERR_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_AVB1ERRISR
**
** Service ID            : NA
**
** Description           : Error Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_AvbErrIsr
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
#if (ETH_AVB1_ERR_ISR == STD_ON)
#if defined (Os_ETH_AVB1ERRISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_AVB1ERRISR_CAT2)                                                                                                /* PRQA S 1503, 3006, 3408 # JV-01, JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_AVB1ERRISR(void)                                                              /* PRQA S 1503, 3006 # JV-01, JV-01 */
#endif
{
  Eth_AvbErrIsr((uint32)ETHAVB1);
}

#endif /* (ETH_AVB1_ERR_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_AVB0MNGISR
**
** Service ID            : NA
**
** Description           : Other Management Interrupt
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_AvbMngIsr
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
#if (ETH_AVB0_MNG_ISR == STD_ON)
#if defined (Os_ETH_AVB0MNGISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_AVB0MNGISR_CAT2)                                                                                                /* PRQA S 1503, 3006, 3408 # JV-01, JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_AVB0MNGISR(void)                                                              /* PRQA S 1503, 3006 # JV-01, JV-01 */
#endif
{
  Eth_AvbMngIsr((uint32)ETHAVB0);
}
#endif /* (ETH_AVB0_MNG_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_AVB1MNGISR
**
** Service ID            : NA
**
** Description           : Other Management Interrupt
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_AvbMngIsr
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
#if (ETH_AVB1_MNG_ISR == STD_ON)
#if defined (Os_ETH_AVB1MNGISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_AVB1MNGISR_CAT2)                                                                                                /* PRQA S 1503, 3006, 3408 # JV-01, JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_AVB1MNGISR(void)                                                              /* PRQA S 1503, 3006 # JV-01, JV-01 */
#endif
{
  Eth_AvbMngIsr((uint32)ETHAVB1);
}
#endif /* (ETH_AVB1_MNG_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_AvbDataIsr
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaETNFRegs
**                         Eth_GpEthConfigPtr, Eth_GpDemEventIntInconsistent
**
** Function(s) invoked   : Eth_DemConfigCheck, Eth_ETNF_HwTxConfirmation, Eth_Hw_ETNF_RxIrqHdlr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_1071
** Reference ID          : ETH_DUD_ACT_1071_ERR001
** Reference ID          : ETH_DUD_ACT_1071_GBL001, ETH_DUD_ACT_1071_GBL002, ETH_DUD_ACT_1071_GBL003
** Reference ID          : ETH_DUD_ACT_1071_GBL004
***********************************************************************************************************************/
#if ((ETH_AVB0_DATA_ISR == STD_ON) || (ETH_AVB1_DATA_ISR == STD_ON))
STATIC FUNC(void, ETH_CODE_FAST) Eth_AvbDataIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx)                                    /* PRQA S 3006 # JV-01 */
{
  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  uint32 LulIntCheck;
  boolean LblRxIntCheckFailed;
  boolean LblTxIntCheckFailed;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;

  LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enDataInterruptID);;

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  LblRxIntCheckFailed = (((uint32)ETH_ZERO != (Eth_GaaETNFRegs[LulCtrlIdx]->ulRIS0 & (uint32)(~ETH_RX_QUEUE_CONFIG_0)))
    && (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enRxInterruptMode));                                               /* PRQA S 3415, 3416 # JV-01, JV-01 */
  #else
  LblRxIntCheckFailed = ETH_FALSE;
  #endif /* (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) */

  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
  LblTxIntCheckFailed = (((uint32)ETH_ZERO != (Eth_GaaETNFRegs[LulCtrlIdx]->ulDIS & (uint16)(~ETH_TX_QUEUE_CONFIG_0)))
    && (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enTxInterruptMode));                                               /* PRQA S 3415, 3416 # JV-01, JV-01 */
  #else
  LblTxIntCheckFailed = ETH_FALSE;
  #endif /* (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) */

  if ((ETH_INTERRUPT_STATUS_NOT_ACTIVE == LulIntCheck) ||
      (ETH_TRUE == LblRxIntCheckFailed) || (ETH_TRUE == LblTxIntCheckFailed))                                           /* PRQA S 2996 # JV-01 */
  {
    Eth_DemConfigCheck(Eth_GpDemEventIntInconsistent[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
  }
  else
#endif
  {
    if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enTxInterruptMode)                                                 /* PRQA S 3416 # JV-01 */
    {
      Eth_ETNF_HwTxConfirmation(LulCtrlIdx);
    } /* else do nothing */

    #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
    if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enRxInterruptMode)                                                 /* PRQA S 3416 # JV-01 */
    {
      Eth_Hw_ETNF_RxIrqHdlr(LulCtrlIdx);
    } /* else do nothing */
    #endif
  }
}
#endif /* #if ((ETH_AVB0_DATA_ISR == STD_ON) || (ETH_AVB1_DATA_ISR == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : Eth_AvbErrIsr
**
** Service ID            : NA
**
** Description           : Error Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaETNFEICRegs, Eth_GpDemEventIntInconsistent,
**                         Eth_GpDemEventDmaError, Eth_GaaETNFRegs
**
** Function(s) invoked   : Eth_DemConfigCheck
**
** Registers Used        : EIC, ETNFnESR, ETNFnEIS
**
** Reference ID          : ETH_DUD_ACT_1072
** Reference ID          : ETH_DUD_ACT_1072_ERR001, ETH_DUD_ACT_1072_ERR002
** Reference ID          : ETH_DUD_ACT_1072_REG001, ETH_DUD_ACT_1072_REG002
** Reference ID          : ETH_DUD_ACT_1072_GBL001, ETH_DUD_ACT_1072_GBL002
** Reference ID          : ETH_DUD_ACT_1072_GBL003, ETH_DUD_ACT_1072_GBL004
***********************************************************************************************************************/
#if ((ETH_AVB0_ERR_ISR == STD_ON) || (ETH_AVB1_ERR_ISR == STD_ON))
STATIC FUNC(void, ETH_CODE_FAST) Eth_AvbErrIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx)                                     /* PRQA S 3006 # JV-01 */
{
  uint32 LulRegVal;
  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  uint32 LulIntCheck;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;
  
  LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enErrInterruptID);

  if ((ETH_INTERRUPT_STATUS_NOT_ACTIVE == LulIntCheck) || 
                              ((uint32)ETH_ZERO == (Eth_GaaETNFRegs[LulCtrlIdx]->ulEIS & ETH_EIS_QEF_MASK)))
  {
    Eth_DemConfigCheck(Eth_GpDemEventIntInconsistent[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulESR & ETH_ETNF_ESR_ERROR_MASK;
    if (ETH_ETNF_ESR_ERROR_TX_BUFFER != LulRegVal)
    {
      /* No action required */
    }
    else
    {
      /* Critical error detection on the MAC controller */
      Eth_DemConfigCheck(Eth_GpDemEventDmaError[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
    }

    /* Clear Error Flag */
    LulRegVal = Eth_GaaETNFRegs[LulCtrlIdx]->ulEIS;
    Eth_GaaETNFRegs[LulCtrlIdx]->ulEIS = ~(LulRegVal & ETH_ETNF_EIC_ERROR);
    /* Execute the pipeline to avoid multiple interrupts */
    (void)Eth_GaaETNFRegs[LulCtrlIdx]->ulEIS;
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
  }
}

#endif /* #if ((ETH_AVB0_ERR_ISR == STD_ON) || (ETH_AVB1_ERR_ISR == STD_ON)) */

/***********************************************************************************************************************
** Function Name         : Eth_AvbMngIsr
**
** Service ID            : NA
**
** Description           : Other Management Interrupt
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaETNFRegs
**                         Eth_GpDemEventIntInconsistent, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : ETH_DUD_ACT_1073_ERR001
**
** Registers Used        : ETNFnTFA2, ETNFnTFA0, ETNFnTFA1, ETNFnTCCR, ETNFnTSR,
**                         ETNFnTIS
**
** Reference ID          : ETH_DUD_ACT_1073
** Reference ID          : ETH_DUD_ACT_1073_ERR001
** Reference ID          : ETH_DUD_ACT_1073_REG001, ETH_DUD_ACT_1073_REG002, ETH_DUD_ACT_1073_REG003
** Reference ID          : ETH_DUD_ACT_1073_REG004, ETH_DUD_ACT_1073_REG005, ETH_DUD_ACT_1073_REG006
** Reference ID          : ETH_DUD_ACT_1073_GBL001, ETH_DUD_ACT_1073_GBL002
** Reference ID          : ETH_DUD_ACT_1073_GBL003, ETH_DUD_ACT_1073_GBL004
***********************************************************************************************************************/
#if ((ETH_AVB0_MNG_ISR == STD_ON) || (ETH_AVB1_MNG_ISR == STD_ON))
STATIC FUNC(void, ETH_CODE_FAST) Eth_AvbMngIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx)                                     /* PRQA S 3006 # JV-01 */
{
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_OFF && ETH_INTERRUPT_CONSISTENCY_CHECK == STD_OFF)
  (void)LulCtrlIdx;
  #endif
  
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  uint8 LucFifoCount;
  uint16 LusTxBufferIdx;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                   /* PRQA S 3432 # JV-01 */
  #endif

  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  uint32 LulIntCheck;
  P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig = (P2CONST(Eth_ETNFConfigType, AUTOMATIC, ETH_APPL_DATA))                                              /* PRQA S 0316 # JV-01 */
    Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;

  LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enMngInterruptID);

  if((ETH_INTERRUPT_STATUS_NOT_ACTIVE == LulIntCheck) || 
                          ((uint32)ETH_ZERO == (Eth_GaaETNFRegs[LulCtrlIdx]->ulTIS & ETH_TIS_TFUF_MASK)))
  {
    Eth_DemConfigCheck(Eth_GpDemEventIntInconsistent[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
    if ((uint32)ETH_ZERO != (Eth_GaaETNFRegs[LulCtrlIdx]->ulTIS & ETH_TIS_TFUF_MASK))
    {
      /* Clear the TFUF flag */
      Eth_GaaETNFRegs[LulCtrlIdx]->ulTIS = Eth_GaaETNFRegs[LulCtrlIdx]->ulTIS & ~ETH_TIS_TFUF_MASK;                     /* PRQA S 4404, 4558 # JV-01, JV-01 */

      /* Get timestamp fifo counter */
      /* ETNFnTSR.TFFL is 8-10bit. so, casting to uint8 does no problem. */
      LucFifoCount = (uint8)(ETH_ETNF_GET_TFFL(Eth_GaaETNFRegs[LulCtrlIdx]->ulTSR));                                    /* PRQA S 3469 # JV-01 */

      do
      {
        /* Read buffer index from ETNFnTFA2.TST */
        LusTxBufferIdx = (uint16)(ETH_ETNF_GET_TST(Eth_GaaETNFRegs[LulCtrlIdx]->ulTFA2));                               /* PRQA S 3469 # JV-01 */
        if (NULL_PTR != Eth_GaaTxBufferMgrTable[LulCtrlIdx][LusTxBufferIdx].pBufferHdr)
        {
          /* Initialize pointer to timestamp buffer */
          LpTxBufferNode = (Eth_BufHandlerType *)Eth_GaaTxBufferMgrTable[LulCtrlIdx][LusTxBufferIdx].pBufferHdr;

          /* Read timestamp value to Tx buffer */
          LpTxBufferNode->stTimeStamp.nanoseconds = Eth_GaaETNFRegs[LulCtrlIdx]->ulTFA0;
          LpTxBufferNode->stTimeStamp.seconds = Eth_GaaETNFRegs[LulCtrlIdx]->ulTFA1;
          LpTxBufferNode->stTimeStamp.secondsHi = (uint16)(Eth_GaaETNFRegs[LulCtrlIdx]->ulTFA2 & ETH_TFA2_TSV_MASK);
          
          /* Set timestamp quality information as VALID */
          LpTxBufferNode->enTimeQual = ETH_VALID;
        } /* else do nothing */
        /* Release oldest entry in Timestamp FIFO - TCCR.TFR = 1 */
        Eth_GaaETNFRegs[LulCtrlIdx]->ulTCCR |= ETH_ETNF_TCCR_TFR;

        LucFifoCount--;                                                                                                 /* PRQA S 3383 # JV-01 */
      } while ((uint8)ETH_ZERO < LucFifoCount);

      /* Execute the pipeline to avoid multiple interrupts */
      (void)Eth_GaaETNFRegs[LulCtrlIdx]->ulTCCR;
      EXECUTE_SYNCP();                                                                                                  /* PRQA S 1006 # JV-01 */
    } /* else do nothing */
    #endif
  }
}
#endif /* #if ((ETH_AVB0_MNG_ISR == STD_ON) || (ETH_AVB1_MNG_ISR == STD_ON)) */

#define ETH_STOP_SEC_CODE_FAST
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* ETH_MACRO_ETNF == STD_ON */
/***********************************************************************************************************************
**                                           End of File                                                              **
***********************************************************************************************************************/
