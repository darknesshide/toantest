/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth.c                                                                                               */
/*====================================================================================================================*/
/*                                                  COPYRIGHT                                                         */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose: This file contains API implementations of Ethernet Driver Component.                                      */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                          Revision Control History                                                  **
***********************************************************************************************************************/
/*
 * 1.4.2: 25/06/2026    : Add new API Eth_GetAndResetMeasurementData.
 *        17/06/2026    : Update function Eth_InitSerdes to support multicore.
 *        05/06/2026    : Update Eth_Init function to resolve warning Pa-082 for MAC address process.
 * 1.4.1: 24/04/2026    : Support Multicore for X5H
 * 1.4.0: 31/03/2026    : Update function Eth_Init, Eth_MainFunction, Eth_Deinit to support multicore feature.
 * 1.1.1: 16/09/2025    : Update to support TSN-ES
 *                        Update Eth_UpdatePhysAddrFilter to correct condition when filter legacy
 * 1.1.0: 25/07/2025    : Remove Eth_GetDropCount, Eth_GetEtherStats API and macro for old AUTOSAR version.
 *                        Update to use macro constant instead of hard code.
 * 1.0.3: 09/06/2025    : Update function Eth_InitSerdes(), to initial each channel of SerDes
 * 1.0.2: 07/05/2025    : Update Eth_ImmediateTransmit, Eth_SetIncrementTimeForGptp, Eth_SetOffsetTimeForGptp,
 *                        Eth_CommonDetCheck API to improve DET check flow.
 *        28/04/2025    : Update the return value of Eth_Receive
 *        24/04/2025    : Update to remove macro ETH_UPDATE_PHYS_ADDR_FILTER
 *        17/03/2025    : Update to merging SingleMainline
 *                        + Update from ucIndex to ucHwipType.
 * 1.0.1  20/02/2025    : Update API Eth_WriteMii and Eth_ReadMii to support check and report runtime error for ETNF.
 * 1.0.0: 28/09/2024    : Update API Eth_ImmediateTransmit, Eth_ReleaseRxBuffer to implement check null for pointer.
 *        29/08/2024    : Add new API Eth_ImmediateTransmit, Eth_ReleaseRxBuffer to support R23-11.
 *        25/06/2024    : Add new API Eth_GetCurrentTimeTuple to support R23-11.
 *                        Update datatype for TimeStampQualType, TimeStampType.
 *                        Update new enum value for TimeStampQualType.
 *        09/04/2024    : Initial Version.
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                       Include Section                                                              **
***********************************************************************************************************************/
/* Included for module version information and other types declarations                                               */
#include "Eth.h"
#include "Eth_Ram.h"
#if (ETH_MACRO_RSW3 == STD_ON)
#include "Eth_RSW3_Ram.h"
#endif  /* #if (ETH_MACRO_RSW3 == STD_ON) */
#if (ETH_MACRO_ETND == STD_ON)
#if(ETH_DEVICE_NAME == ETH_U5X)
#include "Eth_ETND_Ram.h"
#elif(ETH_DEVICE_NAME == ETH_X5X)
#include "Eth_RSW3_TSNES_Ram.h"
#endif /* #if(ETH_DEVICE_NAME) */
#endif /* #if (ETH_MACRO_ETND == STD_ON) */
#if (ETH_MACRO_ETNF == STD_ON)
#include "Eth_ETNF_Ram.h"
#endif /* #if (ETH_MACRO_ETNF == STD_ON) */

#include "EthIf.h"
#include "EthTrcv.h"

/* Included for the declaration of Det_ReportError() */
#include "Det.h"

/* Included for declaration of the function Dem_ReportErrorStatus() */
#include "Dem.h"

#include "SchM_Eth.h"

/* Included for declaration of the function GetCoreID() */
#if (ETH_MULTI_CORE_SUPPORT == STD_ON)
#include "Os.h"
#endif /* #if (ETH_MULTI_CORE_SUPPORT == STD_ON) */
/***********************************************************************************************************************
**                      Version Information                                                                           **
***********************************************************************************************************************/

/* AUTOSAR release version information */
#define ETH_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_C_SW_MAJOR_VERSION      ETH_SW_MAJOR_VERSION_VALUE
#define ETH_C_SW_MINOR_VERSION      ETH_SW_MINOR_VERSION_VALUE

#define ETH_DBTOC_VALUE \
                         (((uint32)ETH_VENDOR_ID_VALUE << 22UL) | \
                         ((uint32)ETH_MODULE_ID_VALUE << 14UL) | \
                         ((uint32)ETH_SW_MAJOR_VERSION_VALUE << 8UL) | \
                         ((uint32)ETH_SW_MINOR_VERSION_VALUE << 3UL))

/***********************************************************************************************************************
**                      Version Check                                                                                 **
***********************************************************************************************************************/

#if (ETH_AR_RELEASE_MAJOR_VERSION != ETH_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth.c : Mismatch in Release Major Version"
#endif

#if (ETH_AR_RELEASE_MINOR_VERSION != ETH_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth.c : Mismatch in Release Minor Version"
#endif

#if (ETH_AR_RELEASE_REVISION_VERSION != ETH_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth.c : Mismatch in Release Revision Version"
#endif

#if (ETH_SW_MAJOR_VERSION != ETH_C_SW_MAJOR_VERSION)
  #error "Eth.c : Mismatch in Software Major Version"
#endif

#if (ETH_SW_MINOR_VERSION != ETH_C_SW_MINOR_VERSION)
  #error "Eth.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0303)    : Cast between a pointer to volatile object and an integral type.                              */
/* Rule                : CERTCCM INT36, CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-11.4                             */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0404)    : More than one read access to volatile objects between sequence points.                       */
/* Rule                : CERTCCM EXP30, EXP10, CWE Rule CWE-1157, CWE-758, CWE-682, MISRA C:2012 Rule-1.3, Rule-13.2  */
/*                       REFERENCE - ISO:C90-6.3 Expressions                                                          */
/* JV-01 Justification : This is to get element in array of struct, volatile of counter variable of 'for' loop is     */
/*                       used to ensure no optimization. It is accepted                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1339)    : Evaluating the address of the parameter '%1s'.                                               */
/* Rule                :  MISRA C:2012 Rule-17.8                                                                      */
/* JV-01 Justification : This is accepted, there is no issue at this LOC with current implementation                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-2.1                             */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2877)    : This loop will never be executed more than once.                                             */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-670,  MISRA C:2012 Dir-4.1                                       */
/* JV-01 Justification : This loop will only be executed at least once, depends on user configuration.                */
/*       Verification  : This is Hardware Specification, it need to loop all unit. So it is not having any impact.    */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2991)    : The value of this 'if' controlling expression is always 'true'.                              */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2995)    : The result of this logical operation is always 'true'.                                       */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3200)    : '%1s' returns a value which is not being used.                                               */
/* Rule                : CERTCCM ERR33, POS54, EXP12, CWE Rule CWE-391, CWE-1167, CWE-252, CWE-1171, CWE-389,         */
/*                       CWE-398, CWE-569,  MISRA C:2012 Rule-17.7                                                    */
/* JV-01 Justification : The value is not required since the call is from a wrapper function.                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3415)    : Right hand operand of '&&' or '||' is an expression with persistent side effects.            */
/* Rule                : CERTCCM EXP02, CWE Rule CWE-398, CWE-569, CWE-768, MISRA C:2012 Rule-13.5                    */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Although it is a volatile object, it is not a direct access to the HW register, and there    */
/*                       is no side effect.                                                                           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-1157, CWE-398, CWE-569,                                          */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3464)    : Argument to macro '%1s' contains a side effect that will be evaluated more than once.        */
/* Rule                : CERTCCM PRE31,                                                                               */
/* JV-01 Justification : This message is only emitted for expressions expanded from argument tokens written out at    */
/*                       the top level, that did not themselves originate from a macro expansion.                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2812)    : Apparent: Dereference of NULL pointer.                                                       */
/* Rule                : EXP34,CWE-476,CWE-465,CWE-737,5.8,Rule-1.3,Dir-4.1                                           */
/* JV-01 Justification : Although it is a volatile object, pointer checked before assign value,                       */
/*                       So it is not null pointer                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2992)    : The value of this 'if' controlling expression is always 'false'.                             */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'true'.     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2996)    : The result of this logical operation is always 'false'.                                      */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'true'.     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                      Function Definitions                                                                          **
***********************************************************************************************************************/

/* Static internal functions */
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_SetStatus(
  uint8 CoreId, CONST(Eth_StateType, AUTOMATIC) LenStatus);

#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_ResetMeasurementData(
  CONST(uint8, AUTOMATIC) LucCtrlIdx, CONST(Eth_MeasurementIdxType, AUTOMATIC)  LenMeasurementIdx);
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
#endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */

#if (ETH_DEV_ERROR_DETECT == STD_ON)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_CommonDetCheck(
  CONST(uint8, AUTOMATIC) LucSID, CONST(uint8, AUTOMATIC) LucCtrlIdx);
#endif

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_PUBLIC_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Eth_Init
**
** Service ID            : 0x01
**
** Description           : This API performs the initialization of the Ethernet Driver by initializing the configuration
**                         structure for subsequent API calls.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CfgPtr: Pointer to ETH Driver configuration set
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GpCoreId2Index, Eth_GpCtrlConfigPtr,Eth_GpEthConfigPtr
**                         Eth_GpDemEventAccess,Eth_GpDemEventRxFramesLost,Eth_GpDemEventLatecollision
**                         Eth_GpDemEventCRC,Eth_GpDemEventUnderSizeFrame,Eth_GpDemEventOverSizeFrame
**                         Eth_GpDemEventAlignment,Eth_GpDemEventSinglecollision,Eth_GpDemEventMultiplecollision
**                         Eth_GpDemEventIntInconsistent,Eth_GpDemEventUnintendedIntChk,Eth_GpDemEventDmaError
**                         Eth_GpDemEventEccError,Eth_GpDemEventTimerincFailed,Eth_GpDemEventTimeroffsetFailed,
**                         Eth_GpDemEventRegisterCorruption,Eth_GpGlobalPauseCfgPtr,Eth_GpGwcaCfgPtr,
**                         Eth_GpBothCoreCfgPtr,Eth_GpTotalCtrlConfig,Eth_GaaCtrlStat,Eth_GaaHWIP,
**                         Eth_GaaHwFunc,Eth_GpDemEventAccess
**
** Function(s) invoked   : GetCoreID, Det_ReportError, Eth_HwPreCommonInit, Eth_ClearAllAddressFilters,
**                         pInitializeBuffer (function pointer), pHwInit (function pointer)
**                         Eth_DemConfigCheck, Eth_HwPostCommonInit, Eth_SetStatus
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_001
** Reference ID          : ETH_DUD_ACT_001_ERR001, ETH_DUD_ACT_001_ERR002, ETH_DUD_ACT_001_ERR003
** Reference ID          : ETH_DUD_ACT_001_ERR004, ETH_DUD_ACT_001_GBL001, ETH_DUD_ACT_001_GBL002
** Reference ID          : ETH_DUD_ACT_001_GBL003, ETH_DUD_ACT_001_GBL004, ETH_DUD_ACT_001_GBL005
** Reference ID          : ETH_DUD_ACT_001_GBL006, ETH_DUD_ACT_001_GBL007, ETH_DUD_ACT_001_GBL008
** Reference ID          : ETH_DUD_ACT_001_GBL009, ETH_DUD_ACT_001_GBL010, ETH_DUD_ACT_001_GBL011
** Reference ID          : ETH_DUD_ACT_001_GBL012, ETH_DUD_ACT_001_GBL013, ETH_DUD_ACT_001_GBL014
** Reference ID          : ETH_DUD_ACT_001_GBL015, ETH_DUD_ACT_001_GBL016, ETH_DUD_ACT_001_GBL017
** Reference ID          : ETH_DUD_ACT_001_GBL018, ETH_DUD_ACT_001_GBL019, ETH_DUD_ACT_001_GBL020
** Reference ID          : ETH_DUD_ACT_001_GBL021, ETH_DUD_ACT_001_GBL022, ETH_DUD_ACT_001_GBL023
** Reference ID          : ETH_DUD_ACT_001_GBL024, ETH_DUD_ACT_001_GBL025, ETH_DUD_ACT_001_GBL026
** Reference ID          : ETH_DUD_ACT_001_GBL027
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_Init(                                                                                   /* PRQA S 1503 # JV-01 */
  P2CONST(Eth_ConfigType, AUTOMATIC, ETH_APPL_CONST) CfgPtr)                                                            /* PRQA S 3432 # JV-01 */
{
  uint32 LulIdx;
  Std_ReturnType LucResult;
  #if defined(ETH_HW_PRE_COMMON_INIT) || defined(ETH_HW_POST_COMMON_INIT)
  Std_ReturnType LucHwPreCommonInitResult;
  Std_ReturnType LucHwPostCommonInitResult;
  #endif
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr;                                                                 /* PRQA S 3432 # JV-01 */
  uint8 LucCoreIndex;
  uint32 LulCtrIdx;
  uint32 LuCoreCount;
  uint32 LulTotalCtrlConfig;
  #if defined(ETH_HW_PRE_COMMON_INIT) || defined(ETH_HW_POST_COMMON_INIT)
  LucHwPostCommonInitResult = E_OK;
  #endif
  #if (ETH_DEVICE_NAME == ETH_U5X)
  Eth_PreCtrlInitUserCalloutPtrType LpPreCtrlInitUserCallout;
  Eth_PostCtrlInitUserCalloutPtrType LpPostCtrlInitUserCallout;
  #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  uint8 LucCoreId;
  /* Get Core id for code branching */
  LucCoreId = (uint8)GetCoreID();

  Eth_GpCoreId2Index = CfgPtr->pCoreId2Index;                                                                           /* PRQA S 2812 # JV-01 */
  /* Covert Core Id to Core Index */
  LucCoreIndex = Eth_GpCoreId2Index[LucCoreId];
  #else
  /* if Multicore is not configude, defauld coreid is 0x00
     To optimize implementation */
  LucCoreIndex = ETH_ZERO;
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  /* Check invalid core */
  if(ETH_INVALID_CORE == LucCoreIndex)
  {
    /* Report to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_INIT_SID, ETH_E_INVALID_CORE);
  }
  else
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/
  {
    if (NULL_PTR == CfgPtr)
    {
      /* Report Error to DET */
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_INIT_SID, ETH_E_PARAM_POINTER);
    }
    /* Check whether the existing database is correct */
    else if (ETH_DBTOC_VALUE != CfgPtr->ulStartOfDbToc)
    {
      /* Report Error to DET */
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_INIT_SID, ETH_E_INVALID_DATABASE);
    }
    else
    #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
    {
      /* Assign the config pointer value to global pointer */
      Eth_GpCtrlConfigPtr = CfgPtr->pCtrlConfig;
      Eth_GpEthConfigPtr = Eth_GpCtrlConfigPtr->pEthConfig;
      Eth_GpDemEventAccess = CfgPtr->pDemEventAccess;
      Eth_GpDemEventRxFramesLost = CfgPtr->pDemEventRxFramesLost;
      Eth_GpDemEventCRC = CfgPtr->pDemEventCRC;
      Eth_GpDemEventUnderSizeFrame = CfgPtr->pDemEventUnderSizeFrame;
      Eth_GpDemEventOverSizeFrame = CfgPtr->pDemEventOverSizeFrame;
      Eth_GpDemEventAlignment = CfgPtr->pDemEventAlignment;
      Eth_GpDemEventSinglecollision = CfgPtr->pDemEventSinglecollision;
      Eth_GpDemEventMultiplecollision = CfgPtr->pDemEventMultiplecollision;
      Eth_GpDemEventLatecollision = CfgPtr->pDemEventLatecollision;
      #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
      Eth_GpDemEventIntInconsistent = CfgPtr->pDemEventIntInconsistent;
      #endif
      #if (ETH_UNINTENDED_INTERRUPT_CHECK == STD_ON)
      Eth_GpDemEventUnintendedIntChk = CfgPtr->pDemEventUnintendedIntChk;
      #endif
      Eth_GpDemEventDmaError = CfgPtr->pDemEventDmaError;
      Eth_GpDemEventEccError = CfgPtr->pDemEventEccError;
      #if (ETH_MACRO_ETNB == STD_ON || ETH_MACRO_ETNF ==STD_ON)
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      Eth_GpDemEventTimerincFailed = CfgPtr->pDemEventTimerincFailed;
      Eth_GpDemEventTimeroffsetFailed = CfgPtr->pDemEventTimeroffsetFailed;
      #endif
      #if ((ETH_REGISTER_CHECK_INITTIME == STD_ON) || (ETH_REGISTER_CHECK_RUNTIME == STD_ON))
      Eth_GpDemEventRegisterCorruption = CfgPtr->pDemEventRegisterCorruption;
      #endif
      #endif

      #if (ETH_MACRO_RSW3 == STD_ON)
      Eth_GpGlobalPauseCfgPtr = &CfgPtr->stGlobalPauseConfiguration[ETH_ZERO];
      Eth_GpGwcaCfgPtr = &CfgPtr->stGwcaConfiguration[ETH_ZERO];
      #if (ETH_BOTHCORE_ENABLE == STD_ON)
      Eth_GpBothCoreCfgPtr = &CfgPtr->stBothCoreConfiguration;
      #endif
      #endif /* ETH_MACRO_RSW3 == STD_ON */
      
      Eth_GpTotalCtrlConfig = CfgPtr->pTotalCtrlConfig;

      /* Get core mapping table */
      for (LuCoreCount = (uint32)ETH_ZERO; (LuCoreCount < (uint32)ETH_TOTAL_CORE_CONFIG); LuCoreCount++)                /* PRQA S 2877 # JV-01 */
      {
        for (LulIdx = (uint32)ETH_ZERO; (LulIdx < (uint32)ETH_MAX_CTRL_CONFIG_PER_CORE); LulIdx++)                      /* PRQA S 2877 # JV-01 */
        {
          Eth_CtrlConfigIdx[LuCoreCount][LulIdx] = CfgPtr->ulCtrlConfigIdx[LuCoreCount][LulIdx];
        }
      }

      Eth_GpDriverState = CfgPtr->pDriverState;
      
      /* Get total controller configured */
      LulTotalCtrlConfig = Eth_GpTotalCtrlConfig[LucCoreIndex];
      #ifdef ETH_HW_PRE_COMMON_INIT
      LucResult = Eth_HwPreCommonInit();
      LucHwPreCommonInitResult = LucResult;
      #else
      LucResult = E_OK;
      #endif

      for (LulIdx = (uint32)ETH_ZERO; (LulIdx < (uint32)LulTotalCtrlConfig) && (E_OK == LucResult); LulIdx++)
      {
        LulCtrIdx = Eth_CtrlConfigIdx[LucCoreIndex][LulIdx];

        #if (ETH_DEVICE_NAME == ETH_U5X)
        LpPreCtrlInitUserCallout = ETH_GET_USER_PRE_INIT_CALLOUT;
        if (NULL_PTR != LpPreCtrlInitUserCallout)                                                                       /* PRQA S 2991, 2992, 2995, 2996 # JV-01, JV-01, JV-01, JV-01 */
        {
          /* Call to the user Pre-ControllerInit Call out function */
          LpPreCtrlInitUserCallout(LulCtrIdx);
        }/* else No action required */
        #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

        /* Copy the configured MAC address as inital value */
        PhysAddrPtr = Eth_GpCtrlConfigPtr[LulCtrIdx].aaEthMACAddr;
        ETH_PACK_ADDRESS_FROM_8(PhysAddrPtr, Eth_GaaCtrlStat[LulCtrIdx].stMacAddr);                                     /* PRQA S 0404, 3464, 3469 # JV-01, JV-01, JV-01 */

        /* Initialize controller state as DOWN */
        Eth_GaaCtrlStat[LulCtrIdx].enMode = ETH_MODE_DOWN;
        /* Initialize address filter */
        Eth_ClearAllAddressFilters(LulCtrIdx);
        /* Get unit type */
        LucHWIPType = Eth_GaaHWIP[LulCtrIdx].ucHwipType;
        if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pInitializeBuffer)                                                  /* PRQA S 3416 # JV-01 */
        {
            /* Invoke Eth_InitializeBuffer to initialize Tx/Rx buffer pool */
          Eth_GaaHwFunc[LucHWIPType]->pInitializeBuffer(LulCtrIdx);
        }/* else No action required */

        if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwInit)                                                            /* PRQA S 3416 # JV-01 */
        {
          /* Initialize low-level driver */
          LucResult = Eth_GaaHwFunc[LucHWIPType]->pHwInit(LulCtrIdx);
        }/* else No action required */

        if (E_NOT_OK == LucResult)
        {
          Eth_DemConfigCheck(Eth_GpDemEventAccess[LulCtrIdx], DEM_EVENT_STATUS_PREFAILED);
        }/* else No action required */

        #if (ETH_DEVICE_NAME == ETH_U5X)
        LpPostCtrlInitUserCallout = ETH_GET_USER_POST_INIT_CALLOUT;
        if (NULL_PTR != LpPostCtrlInitUserCallout)                                                                      /* PRQA S 2991, 2992, 2995, 2996 # JV-01, JV-01, JV-01, JV-01 */
        {
          /* Call to the user Post-ControllerInit Call out function */
          LpPostCtrlInitUserCallout(LulCtrIdx);
        }/* else No action required */
        #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */
      }

      #ifdef ETH_HW_POST_COMMON_INIT
      if (E_OK == LucResult)
      {
        LucResult = Eth_HwPostCommonInit();
        LucHwPostCommonInitResult = LucResult;
      }
      #endif

      if (E_OK == LucResult)
      {
        for (LulIdx = (uint32)ETH_ZERO; LulIdx < (uint32)LulTotalCtrlConfig; LulIdx++)
        {
          LulCtrIdx = Eth_CtrlConfigIdx[LucCoreIndex][LulIdx];
          Eth_DemConfigCheck(Eth_GpDemEventAccess[LulCtrIdx], DEM_EVENT_STATUS_PREPASSED);
        }
        /* Initialize the Driver State to INIT */
        Eth_SetStatus(LucCoreIndex, ETH_STATE_INIT);
      }
      #if defined(ETH_HW_PRE_COMMON_INIT) || defined(ETH_HW_POST_COMMON_INIT)
      else if ((E_NOT_OK == LucHwPreCommonInitResult) || (E_NOT_OK == LucHwPostCommonInitResult))
      {
        for (LulIdx = (uint32)ETH_ZERO; LulIdx < (uint32)LulTotalCtrlConfig; LulIdx++)
        {
          LulCtrIdx = Eth_CtrlConfigIdx[LucCoreIndex][LulIdx];
          Eth_DemConfigCheck(Eth_GpDemEventAccess[LulCtrIdx], DEM_EVENT_STATUS_PREFAILED);
        }
      }
      #endif
      else
      {
        /* No action required */
      }
    }
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  }
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
} /* End of API Eth_Init */

#if (ETH_DEINIT_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_DeInit
**
** Service ID            : 0xA3
**
** Description           : This API performs the SW Reset process needed for the initialization of the Ethernet Driver
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : ForceReset: Indicate the reset flow to follow (normal/emergency)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: Success to SW Reset
**                         E_NOT_OK: Fail to SW Reset
**
** Preconditions         : The function requires previous controller initialization Eth_Init().
**
** Global Variables Used : Eth_GpCoreId2Index,Eth_GpDriverState,Eth_GpTotalCtrlConfig,
**                         Eth_CtrlConfigIdx,Eth_GaaHWIP,Eth_GaaHwFunc
**
** Function(s) invoked   : GetCoreID, Det_ReportError, Eth_SetStatus, pHwDeInit (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_002
** Reference ID          : ETH_DUD_ACT_002_ERR001, ETH_DUD_ACT_002_ERR002, ETH_DUD_ACT_002_GBL001
** Reference ID          : ETH_DUD_ACT_002_GBL002, ETH_DUD_ACT_002_GBL003, ETH_DUD_ACT_002_GBL004
** Reference ID          : ETH_DUD_ACT_002_GBL005, ETH_DUD_ACT_002_GBL006
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_DeInit(CONST(boolean, AUTOMATIC) ForceReset)                                  /* PRQA S 1503 # JV-01 */
{
  uint8 LucCoreIndex;
  Std_ReturnType LucResult;
  
  #ifdef ETH_HW_DEINIT
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  uint32 LulIdx;
  uint32 LulCtrIdx;
  uint32 LulTotalCtrlConfig;
  #else
  (void) ForceReset;
  #endif
  
  LucResult = E_OK;

  /* Index of HW IP Type */
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  uint8 LucCoreId;
  /* Get Core id for code branching */
  LucCoreId = (uint8)GetCoreID();
  /* Covert Core Id to Core Index */
  LucCoreIndex = Eth_GpCoreId2Index[LucCoreId];
  #else
  /* if Multicore is not configude, defauld coreid is 0x00
     To optimize implementation */
  LucCoreIndex = ETH_ZERO;
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  /* Check invalid core */
  if(ETH_INVALID_CORE == LucCoreIndex)
  {
    /* Report to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_DEINIT_SID, ETH_E_INVALID_CORE);
    LucResult = E_NOT_OK;
  }
  else
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/
  {
    if (ETH_STATE_INIT != Eth_GpDriverState[LucCoreIndex])
    {
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_DEINIT_SID, ETH_E_UNINIT);
      LucResult = E_NOT_OK;
    }
  }
  if (E_OK == LucResult)
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {

    #ifdef ETH_HW_DEINIT
    /* Get total controller configured */
    LulTotalCtrlConfig = Eth_GpTotalCtrlConfig[LucCoreIndex];
    for (LulIdx = (uint32)ETH_ZERO; (LulIdx < (uint32)LulTotalCtrlConfig) && (E_OK == LucResult); LulIdx++)
    {
      LulCtrIdx = Eth_CtrlConfigIdx[LucCoreIndex][LulIdx];
      /* Get unit type */
      LucHWIPType = Eth_GaaHWIP[LulCtrIdx].ucHwipType;
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwDeInit)                                                            /* PRQA S 3416 # JV-01 */
      {
        /* Invoke Eth_HwDeInit to initialize low-level driver */
        LucResult = Eth_GaaHwFunc[LucHWIPType]->pHwDeInit(LulCtrIdx, ForceReset);
      }/* else No action required */
    }

    if (E_OK == LucResult)
    {
    #endif
      Eth_SetStatus(LucCoreIndex, ETH_STATE_UNINIT);
    #ifdef ETH_HW_DEINIT
    } /* else: No action required */
    #endif

  } /* else: No action required */

  return LucResult;
} /* End of API Eth_DeInit */
#endif /* (ETH_DEINIT_API == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_SetControllerMode
**
** Service ID            : 0x03
**
** Description           : This API performs enabling / disabling  of the indexed controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx:  Index of an ether controller
**                         CtrlMode: Enable/Disable controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: success.
**                         E_NOT_OK: controller mode could not be changed.
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init. This API must not
**                         preempt Eth_MainFunction, to avoid the false detection of the registercorruption check.
**
** Global Variables Used : Eth_GaaHWIP,Eth_GaaCtrlStat
** Global Variables Used : Eth_GaaHwFunc,Eth_GpDemEventAccess,Eth_GpDemEventRxFramesLost,Eth_GpDemEventCRC
** Global Variables Used : Eth_GpDemEventUnderSizeFrame,Eth_GpDemEventOverSizeFrame,Eth_GpDemEventAlignment
** Global Variables Used : Eth_GpDemEventSinglecollision,Eth_GpDemEventMultiplecollision,Eth_GpDemEventLatecollision
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError
**                         Eth_DemConfigCheck, EthIf_CtrlModeIndication
**                         pHwEnableController (function pointer), pPreprocessBuffer (function pointer)
**                         pHwDisableController (function pointer), pInitializeBuffer (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_003
** Reference ID          : ETH_DUD_ACT_003_ERR001, ETH_DUD_ACT_003_ERR002, ETH_DUD_ACT_003_ERR003
** Reference ID          : ETH_DUD_ACT_003_ERR004, ETH_DUD_ACT_003_GBL001, ETH_DUD_ACT_003_GBL002
** Reference ID          : ETH_DUD_ACT_003_GBL003, ETH_DUD_ACT_003_GBL004, ETH_DUD_ACT_003_GBL005
** Reference ID          : ETH_DUD_ACT_003_GBL006, ETH_DUD_ACT_003_GBL007, ETH_DUD_ACT_003_GBL008
** Reference ID          : ETH_DUD_ACT_003_GBL009, ETH_DUD_ACT_003_GBL010, ETH_DUD_ACT_003_GBL011
** Reference ID          : ETH_DUD_ACT_003_GBL012
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_SetControllerMode(                                                            /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, Eth_ModeType CtrlMode)
{
  Std_ReturnType LucReturnValue;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_SETCONTROLLERMODE_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  #if (ETH_MACRO_ETNF == STD_ON)
  else if ((ETH_HWIP_ETNF == LucHWIPType) &&                                                                            /* PRQA S 3416 # JV-01 */
          ((ETH_MODE_STANDBY != CtrlMode) && (ETH_MODE_ACTIVE != CtrlMode) && (ETH_MODE_DOWN != CtrlMode)))
  {
    /* SWS_Eth_00301 */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETCONTROLLERMODE_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  else if ((ETH_HWIP_ETNF != LucHWIPType) && ((ETH_MODE_ACTIVE != CtrlMode) && (ETH_MODE_DOWN != CtrlMode)))            /* PRQA S 3416 # JV-01 */
  {
    /* SWS_Eth_00301 */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETCONTROLLERMODE_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  #else
  else if ((ETH_MODE_ACTIVE != CtrlMode) && (ETH_MODE_DOWN != CtrlMode))
  {
    /* SWS_Eth_00301 */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETCONTROLLERMODE_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  #endif
  else
  #endif
  {
    LucReturnValue = E_OK;
    if (Eth_GaaCtrlStat[CtrlIdx].enMode != CtrlMode)
    {
      if (ETH_MODE_ACTIVE == CtrlMode)
      {
        /* Invoke Eth_HwEnableController to activate HW */
        if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwEnableController)                                                /* PRQA S 3416 # JV-01 */
        {
          LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwEnableController((uint32)CtrlIdx);
        }/* else No action required */
        if (E_OK == LucReturnValue)
        {
          if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pPreprocessBuffer)                                                /* PRQA S 3416 # JV-01 */
          {
            /* Invoke Eth_PreprocessBuffer to set source MAC address to all Tx Buffers in advance */
            Eth_GaaHwFunc[LucHWIPType]->pPreprocessBuffer((uint32)CtrlIdx);
            /* To prevent MainFunction be executed during the transition,
            set the controller state as ACTIVE after the transition. */
            Eth_GaaCtrlStat[CtrlIdx].enMode = ETH_MODE_ACTIVE;
          }/* else No action required */
        }
        else
        {
          Eth_DemConfigCheck(Eth_GpDemEventAccess[CtrlIdx], DEM_EVENT_STATUS_PREFAILED);
        }
      }
      else
      {
        /* To prevent MainFunction be executed during the transition,
        set the controller state as DOWN before the transition. */
        Eth_GaaCtrlStat[CtrlIdx].enMode = CtrlMode;
        if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwDisableController))                                             /* PRQA S 3416 # JV-01 */
        {
          /* Invoke Eth_HwDisableController to stop HW */
          LucReturnValue= Eth_GaaHwFunc[LucHWIPType]->pHwDisableController((uint32)CtrlIdx);
        }
        /* Retreive all provided Tx Buffers */
        if (E_OK == LucReturnValue)
        {
          if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pInitializeBuffer)                                                /* PRQA S 3416 # JV-01 */
          {
            /* Invoke Eth_InitializeBuffer to initialize Tx/Rx buffer pool */
            Eth_GaaHwFunc[LucHWIPType]->pInitializeBuffer((uint32)CtrlIdx);
          }
        }
        else
        {
          Eth_DemConfigCheck(Eth_GpDemEventAccess[CtrlIdx], DEM_EVENT_STATUS_PREFAILED);
        }
      }
      if (E_OK == LucReturnValue)
      {
        /* Since this function is implemented as synchronous, indicate a mode switch to EthIf here */
        EthIf_CtrlModeIndication(CtrlIdx, CtrlMode);
        Eth_DemConfigCheck(Eth_GpDemEventAccess[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventRxFramesLost[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventCRC[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventUnderSizeFrame[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventOverSizeFrame[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventAlignment[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventSinglecollision[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventMultiplecollision[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
        Eth_DemConfigCheck(Eth_GpDemEventLatecollision[CtrlIdx], DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
        /* No action required */
      }
    }
    else
    {
       /* No action required */
    }
  }

  return(LucReturnValue);
} /* End of API Eth_SetControllerMode */

/***********************************************************************************************************************
** Function Name         : Eth_GetControllerMode
**
** Service ID            : 0x04
**
** Description           : This API Obtains the state of the indexed controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : CtrlModePtr: Pointer of the controller mode
**
** Return parameter      : Std_ReturnType
**                         E_OK: success.
**                         E_NOT_OK: controller mode could not be obtained.
**
** Preconditions         : The function requires previous controller initialization Eth_Init().
**
** Global Variables Used : Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck,
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_004
** Reference ID          : ETH_DUD_ACT_004_ERR001, ETH_DUD_ACT_004_ERR002, ETH_DUD_ACT_004_ERR003
** Reference ID          : ETH_DUD_ACT_004_GBL001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetControllerMode(                                                            /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2VAR(Eth_ModeType, AUTOMATIC, ETH_APPL_DATA) CtrlModePtr)                                             /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETCONTROLLERMODE_SID, CtrlIdx);
  /* Report Error to DET, if the CtrlModePtr pointer value is NULL */
  if (NULL_PTR == CtrlModePtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETCONTROLLERMODE_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    *CtrlModePtr = Eth_GaaCtrlStat[CtrlIdx].enMode;
    LucReturnValue = E_OK;
  }

  return(LucReturnValue);
} /* End of API Eth_GetControllerMode */

/***********************************************************************************************************************
** Function Name         : Eth_GetPhysAddr
**
** Service ID            : 0x08
**
** Description           : This API obtains the physical source address(MAC Address) configured for the
**                         indexed controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : PhysAddrPtr: Pointer to memory containing the physical source address (MAC address) in
**                         network byte order.
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_005
** Reference ID          : ETH_DUD_ACT_005_ERR001, ETH_DUD_ACT_005_ERR002, ETH_DUD_ACT_005_ERR003
** Reference ID          : ETH_DUD_ACT_005_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_GetPhysAddr(                                                                            /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr)                                                    /* PRQA S 3432 # JV-01 */
{
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucReturnValue;
  LucReturnValue = Eth_CommonDetCheck(ETH_GETPHYSADDR_SID, CtrlIdx);
  /* Report Error to DET, if the PhysAddrPtr pointer value is NULL */
  if (NULL_PTR == PhysAddrPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETPHYSADDR_SID, ETH_E_PARAM_POINTER);
     LucReturnValue  = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    ETH_UNPACK_ADDRESS_TO_8(Eth_GaaCtrlStat[CtrlIdx].stMacAddr, PhysAddrPtr);                                           /* PRQA S 3469 # JV-01 */
  }
} /* End of API Eth_GetPhysAddr */

/***********************************************************************************************************************
** Function Name         : Eth_SetPhysAddr
**
** Service ID            : 0x13
**
** Description           : Sets the physical source address used by the indexed controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same CtrlIdx,
**                         reentrant for different
**
** Input Parameters      : CtrlIdx:     Index of the controller
**                         PhysAddrPtr: Pointer to memory containing the physical source address (MAC address)
**                                      in network byte order.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_006
** Reference ID          : ETH_DUD_ACT_006_ERR001, ETH_DUD_ACT_006_ERR002, ETH_DUD_ACT_006_ERR003
** Reference ID          : ETH_DUD_ACT_006_ERR004, ETH_DUD_ACT_006_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_SetPhysAddr(                                                                            /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr)                                                  /* PRQA S 3432 # JV-01 */
{
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucReturnValue;
  LucReturnValue = Eth_CommonDetCheck(ETH_SETPHYSADDR_SID, CtrlIdx);
  /* Report Error to DET, if the PhysAddrPtr pointer value is NULL */
  if (NULL_PTR == PhysAddrPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETPHYSADDR_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    if (ETH_MODE_ACTIVE == Eth_GaaCtrlStat[CtrlIdx].enMode)
    {
      #if (ETH_DEV_ERROR_DETECT == STD_ON)
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETPHYSADDR_SID, ETH_E_INV_MODE);
      #endif
    }
    else
    {
      ETH_PACK_ADDRESS_FROM_8(PhysAddrPtr, Eth_GaaCtrlStat[CtrlIdx].stMacAddr);                                         /* PRQA S 3469 # JV-01 */
    }
  }
} /* End of API Eth_SetPhysAddr */

/***********************************************************************************************************************
** Function Name         : Eth_UpdatePhysAddrFilter
**
** Service ID            : 0x12
**
** Description           : Update the physical source address to/from the indexed controller filter.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same CtrlIdx,
**                         reentrant for different
**
** Input Parameters      : CtrlIdx:    Index of the controller
**                         PhyAddrPtr: Pointer to memory containing the physical destination address (MAC address)
**                                     in network byte order.
**                         Action:     Add or remove the address from the Ethernet controllers
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: filter was successfully changed
**                         E_NOT_OK: filter could not be changed and the DET is ON
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GstBroadcastAddr, Eth_GstNullAddr
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, Eth_ClearAllAddressFilters
**                         Eth_GetFilterIndex, Eth_AddAddressFilter, Eth_RemoveAddressFilte
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_007
** Reference ID          : ETH_DUD_ACT_007_ERR001, ETH_DUD_ACT_007_ERR002, ETH_DUD_ACT_007_ERR003
** Reference ID          : ETH_DUD_ACT_007_ERR004, ETH_DUD_ACT_007_ERR005, ETH_DUD_ACT_007_GBL001
** Reference ID          : ETH_DUD_ACT_007_GBL002, ETH_DUD_ACT_007_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_UpdatePhysAddrFilter(                                                         /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr, Eth_FilterActionType Action)                     /* PRQA S 3432 # JV-01 */
{
  Eth_MacAddressType LstMacAddr;
  Std_ReturnType LucReturnValue;
  uint32 LulFilterIdx;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_UPDATEPHYSADDRFILTER_SID, CtrlIdx);
  /* Report Error to DET, if the PhysAddrPtr pointer value is NULL */
  if (NULL_PTR == PhysAddrPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID,
      ETH_UPDATEPHYSADDRFILTER_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    /* Pack MAC address from user to the structure to be compared */
    ETH_PACK_ADDRESS_FROM_8(PhysAddrPtr, LstMacAddr);                                                                   /* PRQA S 3469 # JV-01 */

#if (ETH_UPDATE_PHYS_ADDR_FILTER_LEGACY == STD_ON)
    /* FF:..:FF and 00:..:00 are not allowed while the controller is ACTVIE */
    if ((ETH_MODE_ACTIVE == Eth_GaaCtrlStat[CtrlIdx].enMode) &&
      (((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstBroadcastAddr)) ||                                       /* PRQA S 3469 # JV-01 */
      ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstNullAddr))))                                              /* PRQA S 3469 # JV-01 */
    {
      #if (ETH_DEV_ERROR_DETECT == STD_ON)
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_UPDATEPHYSADDRFILTER_SID, ETH_E_INV_MODE);
      #endif
      LucReturnValue = E_NOT_OK;
    }
    else
#endif /* (ETH_UPDATE_PHYS_ADDR_FILTER_LEGACY == STD_ON) */
    {
      LucReturnValue = E_OK;

      if ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstBroadcastAddr))                                        /* PRQA S 3469 # JV-01 */
      {
        #if (ETH_UPDATE_PHYS_ADDR_FILTER_LEGACY == STD_OFF)
        if(ETH_ADD_TO_FILTER == Action)
        #endif
        {
          /* If FF:..:FF is specified, enter promiscuous mode */
          Eth_GaaCtrlStat[CtrlIdx].blPromiscuous = ETH_TRUE;
        }
        #if (ETH_UPDATE_PHYS_ADDR_FILTER_LEGACY == STD_OFF)
        else
        {
          /* Advanced Mode: If Action = ETH_REMOVE_FROM_FILTER and FF:..:FF is specified, exit promiscuous mode */
          Eth_GaaCtrlStat[CtrlIdx].blPromiscuous = ETH_FALSE;
        }
        #endif
      }
      else if ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstNullAddr))                                             /* PRQA S 3469 # JV-01 */
      {
        /* If 00:..:00 is specified, clear promisoucs mode and all filters */
        Eth_ClearAllAddressFilters((uint32)CtrlIdx);
      }
      else
      {
        if (ETH_ADD_TO_FILTER == Action)
        {
          #if (ETH_DEV_ERROR_DETECT == STD_ON)
          #if (ETH_UPDATE_PHYS_ADDR_FILTER_LEGACY == STD_OFF)
          /*
             Advanced Mode, Report DET error when:
             - The specified address is not a multicast address
             - The filter array is full
          */
          if (((uint32)ETH_ZERO == ETH_CHECK_MULTICAST(LstMacAddr)) ||                                                  /* PRQA S 3469 # JV-01 */
            (ETH_FILTER_FULL_VALUE == Eth_GaaCtrlStat[CtrlIdx].ulActiveFilterBits))
          #else
          /*
             Report DET error when:
             - The specified address is not a multicast address
             - The specified address has been already registered
             - The filter array is full
          */
          LulFilterIdx = Eth_GetFilterIndex((uint32)CtrlIdx, &LstMacAddr);
          if (((uint32)ETH_ZERO == ETH_CHECK_MULTICAST(LstMacAddr)) ||                                                  /* PRQA S 3469 # JV-01 */
            (ETH_INVALID_FILTER_INDEX != LulFilterIdx) ||
            (ETH_FILTER_FULL_VALUE == Eth_GaaCtrlStat[CtrlIdx].ulActiveFilterBits))
          #endif
          {
            (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID,
              ETH_UPDATEPHYSADDRFILTER_SID, ETH_E_INV_PARAM);
            LucReturnValue = E_NOT_OK;
          }
          else
          #endif
          {
            Eth_AddAddressFilter((uint32)CtrlIdx, &LstMacAddr);
          }
        }
        else
        {
          LulFilterIdx = Eth_GetFilterIndex((uint32)CtrlIdx, &LstMacAddr);
          #if (ETH_DEV_ERROR_DETECT == STD_ON)
          /* If the specified address is not registered, report error */
          if (ETH_INVALID_FILTER_INDEX == LulFilterIdx)
          {
            (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_UPDATEPHYSADDRFILTER_SID, ETH_E_INV_PARAM);
            LucReturnValue = E_NOT_OK;
          }
          else
          #endif
          {
            Eth_RemoveAddressFilter((uint32)CtrlIdx, LulFilterIdx);
          }
        }
      }
    }
  }

  return LucReturnValue;
}

#if (ETH_CTRL_ENABLE_MII == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_WriteMii
**
** Service ID            : 0x05
**
** Description           : This API Configures a transceiver register or triggers a function offered by the receiver by
**                         writing the specified transceiver register through the MII of the indexed controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         TrcvIdx: Index of the transceiver on the MII
**                         RegIdx:  Index of the transceiver register on the MII
**                         RegVal:  Value to be written into the indexed register
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: No error has occurred during execution of the API
**                         E_NOT_OK: An error has occurred during execution of the API
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthCtrlEnableMii.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GpEthConfigPtr
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, Det_ReportRuntimeError
**                         pHwWriteMii (function pointer), EthTrcv_WriteMiiIndication, pHwWriteMiibit (function pointer),
**                         pHwReadMiibit (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_021
** Reference ID          : ETH_DUD_ACT_021_ERR001, ETH_DUD_ACT_021_ERR002, ETH_DUD_ACT_021_ERR003
** Reference ID          : ETH_DUD_ACT_021_ERR004, ETH_DUD_ACT_021_GBL001, ETH_DUD_ACT_021_GBL002
** Reference ID          : ETH_DUD_ACT_021_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE)Eth_WriteMii(                                                                      /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, uint8 TrcvIdx, uint8 RegIdx, uint16 RegVal)
{
  #ifdef ETH_HW_LEGACY_MDIO
  uint32 LulBitCount;
  uint32 LulHeader;
  uint32 LulBit;
  uint16 LulRegVal;
  #endif
  Std_ReturnType LucReturnValue = E_NOT_OK;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  boolean LblDetErrorEvent = ETH_FALSE;
  Std_ReturnType LucCommonDetCheckValue;
  #endif
  /* Device MDIO type */
  Eth_HwMDIOType LenHwMDIOType;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  /* Get device MDIO type */
  LenHwMDIOType = Eth_GpEthConfigPtr[CtrlIdx].enHwMDIOType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucCommonDetCheckValue = Eth_CommonDetCheck(ETH_WRITEMII_SID, CtrlIdx);
  if (E_OK != LucCommonDetCheckValue)
  {
    LblDetErrorEvent = ETH_TRUE;
    /* Do nothing */
  }
  /* Check for the valid TrcvIdx  */
  else if (ETH_PHY_MAX_PHYAD_IDX < TrcvIdx)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_WRITEMII_SID, ETH_E_INV_PARAM);
    LblDetErrorEvent = ETH_TRUE;
  }
  /* Check for the valid RegIdx  */
  else if (ETH_PHY_MAX_REGAD_IDX < RegIdx)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_WRITEMII_SID, ETH_E_INV_PARAM);
    LblDetErrorEvent = ETH_TRUE;
  }
  else
  {
    /* No action required */
  }

  if(ETH_FALSE == LblDetErrorEvent)
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    #ifdef ETH_HW_NOT_LEGACY_MDIO
    if(ETH_HW_WRITE_MII == LenHwMDIOType)                                                                               /* PRQA S 2995 # JV-01 */
    {
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwWriteMii)                                                          /* PRQA S 3416 # JV-01 */
      {
        LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwWriteMii((uint32)CtrlIdx, TrcvIdx, RegIdx, RegVal);
      }/* else No action required */
      if (E_OK == LucReturnValue)
      {
        /* Since this function is implemented as synchronous, call EthTrcv here */
        EthTrcv_WriteMiiIndication(CtrlIdx, TrcvIdx, RegIdx);
      }
      else
      {
        (void)Det_ReportRuntimeError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_WRITEMII_SID, ETH_E_COMMUNICATION);
      }
    } /* else no action required */
    #endif

    #ifdef ETH_HW_LEGACY_MDIO
    if(ETH_HW_WRITE_MII_BIT == LenHwMDIOType)
    {
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit)                                                       /* PRQA S 3416 # JV-01 */
      {
          /* PRE */
        for (LulBitCount = (uint32)ETH_PHY_PREAMBLE_SIZE; LulBitCount > (uint32)ETH_ZERO; LulBitCount--)
        {
          LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, (uint32)ETH_ONE);
        }
        /* ST, OP, PHYAD, REGAD */
        LulHeader = ETH_PHY_WHEADER(TrcvIdx, RegIdx);                                                                   /* PRQA S 3469 # JV-01 */
        for (LulBitCount = (uint32)ETH_PHY_HEADER_SIZE; LulBitCount > (uint32)ETH_ZERO; LulBitCount--)
        {
          /* Pickup the bit which should be output next, MSB first */
          LulBit = (LulHeader >> (LulBitCount - (uint32)ETH_ONE)) & (uint32)ETH_ONE;                                    /* PRQA S 3383 # JV-01 */
          LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, LulBit);
        }

        /* TA: 10 */
        LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, (uint32)ETH_ONE);
        LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, (uint32)ETH_ZERO);

        /* DATA */
        for (LulBitCount = (uint32)ETH_PHY_DATA_SIZE; LulBitCount > (uint32)ETH_ZERO; LulBitCount--)
        {
          /* Pickup the bit which should be output next, MSB first */
          LulBit = ((uint32)RegVal >> (LulBitCount - (uint32)ETH_ONE)) & (uint32)ETH_ONE;                               /* PRQA S 3383 # JV-01 */
          LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, LulBit);
          }
      } /* else no action required */

      /* Bus release (MDIO = Z) and IDLE cycle, it is same as read cycle */
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwReadMiibit)                                                        /* PRQA S 3416 # JV-01 */
      {
        /* Dummy read */
        LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwReadMiibit((uint32)CtrlIdx, &LulRegVal);
      } /* else no action required */

      if (E_OK == LucReturnValue)
      {
        /* Since this function is implemented as synchronous, call EthTrcv here */
        EthTrcv_WriteMiiIndication(CtrlIdx, TrcvIdx, RegIdx);
      }
      else
      {
        /* Report Det Runtime error */
        (void)Det_ReportRuntimeError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_WRITEMII_SID, ETH_E_COMMUNICATION);
      }
    }
    #endif /* #ifdef ETH_HW_LEGACY_MDIO */
  }

  return LucReturnValue;
} /* End of API Eth_WriteMii */

/***********************************************************************************************************************
** Function Name         : Eth_ReadMii
**
** Service ID            : 0x06
**
** Description           : This API Reads the specified transceiver register through the MII of the indexed controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         TrcvIdx: Index of the transceiver on the MII
**                         RegIdx:  Index of the transceiver register on the MII
**
** InOut Parameters      : None
**
** Output Parameters     : RegValPtr: Filled with the register content of the indexed register
**
** Return parameter      : Std_ReturnType
**                         E_OK: No error has occurred during execution of the API
**                         E_NOT_OK: An error has occurred during execution of the API
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthCtrlEnableMii.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GpEthConfigPtr
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, Det_ReportRuntimeError, pHwReadMii (function pointer)
**                         EthTrcv_ReadMiiIndication, pHwWriteMiibit (function pointer), pHwReadMiibit (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_022
** Reference ID          : ETH_DUD_ACT_022_ERR001, ETH_DUD_ACT_022_ERR002, ETH_DUD_ACT_022_ERR003
** Reference ID          : ETH_DUD_ACT_022_ERR004, ETH_DUD_ACT_022_ERR005, ETH_DUD_ACT_022_GBL002
** Reference ID          : ETH_DUD_ACT_022_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_ReadMii(                                                                      /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, uint8 TrcvIdx, uint8 RegIdx,
  P2VAR(uint16, AUTOMATIC, ETH_APPL_DATA)RegValPtr)                                                                     /* PRQA S 3432 # JV-01 */
{
  #ifdef ETH_HW_LEGACY_MDIO
  uint32 LulBitCount;
  uint32 LulHeader;
  uint32 LulBit;
  uint32 LulRegVal;
  #endif

  /* Local variable to hold the DET return value */
  Std_ReturnType LucReturnValue = E_NOT_OK;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  boolean LblDetErrorEvent = ETH_FALSE;
  Std_ReturnType LucCommonDetCheckValue;
  #endif
  /* Device MDIO type */
  Eth_HwMDIOType LenHwMDIOType;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  /* Get device MDIO type */
  LenHwMDIOType = Eth_GpEthConfigPtr[CtrlIdx].enHwMDIOType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucCommonDetCheckValue = Eth_CommonDetCheck(ETH_READMII_SID, CtrlIdx);
  if (E_OK != LucCommonDetCheckValue)
  {
    LblDetErrorEvent = ETH_TRUE;
  }
  else if (NULL_PTR == RegValPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_READMII_SID, ETH_E_PARAM_POINTER);
    LblDetErrorEvent = ETH_TRUE;
  }
  else if ((ETH_PHY_MAX_PHYAD_IDX < TrcvIdx) || (ETH_PHY_MAX_REGAD_IDX < RegIdx))
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_READMII_SID, ETH_E_INV_PARAM);
    LblDetErrorEvent = ETH_TRUE;
  }
  else
  {
    /* No action required */
  }

  if(ETH_FALSE == LblDetErrorEvent)
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    #ifdef ETH_HW_NOT_LEGACY_MDIO
    if(ETH_HW_WRITE_MII == LenHwMDIOType)                                                                               /* PRQA S 2995 # JV-01 */
    {
      /* Read data from PHY */
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwReadMii)                                                           /* PRQA S 3416 # JV-01 */
      {
        LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwReadMii((uint32)CtrlIdx, TrcvIdx, RegIdx, RegValPtr);
      }/* else No action required */
      if (E_OK == LucReturnValue)
      {
        /* Since this function is implemented as synchronous, call EthTrcv here */
        EthTrcv_ReadMiiIndication(CtrlIdx, TrcvIdx, RegIdx, *RegValPtr);
      }
      else
      {
        (void)Det_ReportRuntimeError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_READMII_SID, ETH_E_COMMUNICATION);
      }
    }
    #endif /* #ifdef ETH_HW_NOT_LEGACY_MDIO */
    
    #ifdef ETH_HW_LEGACY_MDIO
    if(ETH_HW_WRITE_MII_BIT == LenHwMDIOType)
    {
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit)                                                       /* PRQA S 3416 # JV-01 */
      {
        /* PRE */
        for (LulBitCount = (uint32)ETH_PHY_PREAMBLE_SIZE; LulBitCount > (uint32)ETH_ZERO; LulBitCount--)
        {
          LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, (uint32)ETH_ONE);
        }
    
        /* ST, OP, PHYAD, REGAD */
        LulHeader = ETH_PHY_RHEADER(TrcvIdx, RegIdx);                                                                   /* PRQA S 3469 # JV-01 */
        for (LulBitCount = (uint32)ETH_PHY_HEADER_SIZE; LulBitCount > (uint32)ETH_ZERO; LulBitCount--)
        {
          /* Pickup the MSB which should be output next, MSB first */
          LulBit = (LulHeader >> (LulBitCount - (uint32)ETH_ONE)) & (uint32)ETH_ONE;                                    /* PRQA S 3383 # JV-01 */
          LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwWriteMiibit((uint32)CtrlIdx, LulBit);
        }
      } /* else No action required */
    
      if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwReadMiibit)                                                        /* PRQA S 3416 # JV-01 */
      {
        /* TA[0]: Turn MDIO to Z, it is same as Read cycle */
        LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwReadMiibit((uint32)CtrlIdx, RegValPtr);
        /* TA[1]: Read 0 from PHY, ignore it */
        LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwReadMiibit((uint32)CtrlIdx, RegValPtr);
    
        /* DATA */
        LulRegVal = (uint32)ETH_ZERO;
        for (LulBitCount = (uint32)ETH_PHY_DATA_SIZE; LulBitCount > (uint32)ETH_ZERO; LulBitCount--)
        {
          /* Since read data is MSB first, shift left the result */
          LulRegVal = LulRegVal << (uint32)ETH_ONE;
          /* Read data from PHY */
          LucReturnValue |= Eth_GaaHwFunc[LucHWIPType]->pHwReadMiibit((uint32)CtrlIdx, RegValPtr);
          LulRegVal |= *RegValPtr;
        }
    
        *RegValPtr = (uint16)LulRegVal;
      } /* else No action required */
    
      if (E_OK == LucReturnValue)
      {
        /* Since this function is implemented as synchronous, call EthTrcv here */
        EthTrcv_ReadMiiIndication(CtrlIdx, TrcvIdx, RegIdx, *RegValPtr);
      }
      else
      {
        /* Report Det Runtime error */
        (void)Det_ReportRuntimeError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_READMII_SID, ETH_E_COMMUNICATION);
      }
    }
    #endif /* #ifdef ETH_HW_LEGACY_MDIO */
  }
  return LucReturnValue;
} /* End of API Eth_ReadMii */
#endif /* (ETH_CTRL_ENABLE_MII == STD_ON) */

#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetCounterValues
**
** Service ID            : 0x14
**
** Description           : This API Reads a list with drop counter values of the corresponding controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : CounterPtr: counter values according to IETF RFC 1757, RFC 1643 and RFC 2233.
**
** Return parameter      : Std_ReturnType
**                         E_OK: success
**                         E_NOT_OK: counter values read failure
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGetCounterValuesApi
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwGetCounterValues (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_024
** Reference ID          : ETH_DUD_ACT_024_ERR001, ETH_DUD_ACT_024_ERR002, ETH_DUD_ACT_024_ERR003
** Reference ID          : ETH_DUD_ACT_024_GBL001, ETH_DUD_ACT_024_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetCounterValues(                                                             /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) CounterPtr)                                           /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETCOUNTERVALUES_SID, CtrlIdx);
  /* Report Error to DET, if the stherStats pointer value is NULL */
  if (NULL_PTR == CounterPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETCOUNTERVALUES_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetCounterValues))                                                  /* PRQA S 3416 # JV-01 */
    {
      /* Invoke Eth_HwGetCounterValues to Get drop frame counts for each error factor */
      Eth_GaaHwFunc[LucHWIPType]->pHwGetCounterValues((uint32)CtrlIdx, CounterPtr);
    }/* else No action required */
    LucReturnValue = E_OK;
  }

  return (LucReturnValue);
} /* End of API Eth_GetCounterValues */
#endif

#if (ETH_GET_RX_STATS_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetRxStats
**
** Service ID            : 0x15
**
** Description           : This API Returns the following list according to IETF RFC2819, where the maximal possible
**                         value shall denote an invalid value.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : RxStats: List of values according to IETF RFC 2819 (Remote Network Monitoring Management
**                                  Information Base).
**
** Return parameter      : Std_ReturnType
**                         E_OK: success
**                         E_NOT_OK: drop counter could not be obtained
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGetRxStatsApi.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, pHwGetTxStats (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_008
** Reference ID          : ETH_DUD_ACT_008_ERR001, ETH_DUD_ACT_008_ERR002, ETH_DUD_ACT_008_ERR003
** Reference ID          : ETH_DUD_ACT_008_GBL001, ETH_DUD_ACT_008_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetRxStats(                                                                   /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) RxStats)                                              /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
    /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETRXSTATS_SID, CtrlIdx);
  /* Report Error to DET, if the stherStats pointer value is NULL */
  if (NULL_PTR == RxStats)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETRXSTATS_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetRxStats))                                                        /* PRQA S 3416 # JV-01 */
    {
      /* Invoke Eth_HwGetRxStats to get Rx statistics information */
      Eth_GaaHwFunc[LucHWIPType]->pHwGetRxStats((uint32)CtrlIdx, RxStats);
    }/* else No action required */
    LucReturnValue = E_OK;
  }

  return (LucReturnValue);
} /* End of API Eth_GetRxStats */
#endif

#if (ETH_GET_TX_STATS_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetTxStats
**
** Service ID            : 0x1C
**
** Description           : This API Returns the list of Transmission Statistics out of IETF RFC1213 defined with
**                         Eth_TxStatsType, where the  maximal possible value shall denote an invalid value.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : TxStats: List of values to read statistic values for
**                                  transmission.
**
** Return parameter      : Std_ReturnType
**                         E_OK: success
**                         E_NOT_OK: Tx-statistics could not be obtained
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGetTxStatsApi.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, pHwGetTxStats (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_009
** Reference ID          : ETH_DUD_ACT_009_ERR001, ETH_DUD_ACT_009_ERR002, ETH_DUD_ACT_009_ERR003
** Reference ID          : ETH_DUD_ACT_009_GBL001, ETH_DUD_ACT_009_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetTxStats(                                                                   /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) TxStats)                                              /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETTXSTATS_SID, CtrlIdx);
  /* Report Error to DET, if the stherStats pointer value is NULL */
  if (NULL_PTR == TxStats)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETTXSTATS_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetTxStats))                                                        /* PRQA S 3416 # JV-01 */
    {
      /* Invoke Eth_HwGetTxStats to get Tx statistics information */
      Eth_GaaHwFunc[LucHWIPType]->pHwGetTxStats((uint32)CtrlIdx, TxStats);
    }/* else No action required */
    LucReturnValue = E_OK;
  }

  return (LucReturnValue);
} /* End of API Eth_GetTxStats */
#endif

#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetTxErrorCounterValues
**
** Service ID            : 0x1D
**
** Description           : This API Returns the list of Transmission Error Counters out of IETF RFC1213 and RFC1643
**                         defined with Eth_TxErrorCounterValuesType, where the maximal possible value shall denote
**                         an invalid value.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : TxErrorCounterValues: List of values to read statistic values for transmission.
**
** Return parameter      : Std_ReturnType
**                         E_OK: success
**                         E_NOT_OK: Tx-statistics could not be obtained
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGetTxErrorCounterValuesApi.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwGetTxErrorCounterValues (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_026
** Reference ID          : ETH_DUD_ACT_026_ERR001, ETH_DUD_ACT_026_ERR002, ETH_DUD_ACT_026_ERR003
** Reference ID          : ETH_DUD_ACT_026_GBL001, ETH_DUD_ACT_026_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetTxErrorCounterValues(                                                      /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) TxErrorCounterValues)                    /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETTXERRORCOUNTERVALUES_SID, CtrlIdx);
  /* Report Error to DET, if the stherStats pointer value is NULL */
  if (NULL_PTR == TxErrorCounterValues)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID,
      ETH_GETTXERRORCOUNTERVALUES_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  {
    /* No action required */
  }
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetTxErrorCounterValues))                                           /* PRQA S 3416 # JV-01 */
    {
      Eth_GaaHwFunc[LucHWIPType]->pHwGetTxErrorCounterValues((uint32)CtrlIdx, TxErrorCounterValues);
    }/* else No action required */
    LucReturnValue = E_OK;
  }

  return (LucReturnValue);
} /* End of API Eth_GetTxErrorCounterValues */
#endif

/***********************************************************************************************************************
** Function Name         : Eth_ProvideTxBuffer
**
** Service ID            : 0x09
**
** Description           : This API Provides access to a transmit buffer of the specified controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : CtrlIdx:  Index of the controller
**                         Priority: Frame priority for transmit buffer FIFO selection *This parameter is valid for
**                                   AUTOSAR R4.3.1 later
**
** InOut Parameters      : LenBytePtr: In:  desired length in bytes,
**                                     Out: granted length in bytes
**
** Output Parameters     : BufIdxPtr: Index to the granted buffer resource
**                         BufPtr:    Pointer to the granted buffer
**
** Return parameter      : BufReq_ReturnType
**                         BUFREQ_OK:       success
**                         BUFREQ_E_NOT_OK: development error detected
**                         BUFREQ_E_BUSY:   all buffers in use
**                         BUFREQ_E_OVFL:   the requested size is larger than the buffer
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc, Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pGetTxBuffer (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_027
** Reference ID          : ETH_DUD_ACT_027_ERR001, ETH_DUD_ACT_027_ERR002, ETH_DUD_ACT_027_ERR003
** Reference ID          : ETH_DUD_ACT_027_ERR004, ETH_DUD_ACT_027_GBL001, ETH_DUD_ACT_027_GBL002
** Reference ID          : ETH_DUD_ACT_027_GBL003
***********************************************************************************************************************/
FUNC(BufReq_ReturnType, ETH_PUBLIC_CODE) Eth_ProvideTxBuffer(                                                           /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx,
  uint8 Priority,
  P2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) BufIdxPtr,                                                            /* PRQA S 3432 # JV-01 */
  P2VAR(uint8*, AUTOMATIC, ETH_APPL_DATA) BufPtr,                                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr)                                                                   /* PRQA S 3432 # JV-01 */
{
  BufReq_ReturnType LenReturnValue;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucCommonResult;
  #endif

  LenReturnValue = BUFREQ_E_NOT_OK;                                                                                     /* PRQA S 2982 # JV-01 */
  
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucCommonResult = Eth_CommonDetCheck(ETH_PROVIDETXBUFFER_SID, CtrlIdx);
  if (E_OK != LucCommonResult)
  {
    /* Do nothing */
  }
  /* Report Error to DET, if the BufIdxPtr, BufPtr, LenBytePtr pointer value is NULL */
  else if ((NULL_PTR == BufIdxPtr) || (NULL_PTR == BufPtr) || (NULL_PTR == LenBytePtr))
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_PROVIDETXBUFFER_SID, ETH_E_PARAM_POINTER);
  }
  /* Report Error to DET, if the controller mode Is not Active */
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_PROVIDETXBUFFER_SID, ETH_E_INV_MODE);
  }
  else
  #endif
  {
    /* Get unit type */
    LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
    if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pGetTxBuffer)                                                           /* PRQA S 3416 # JV-01 */
    {
      /* Get a buffer from the TxBufferRing */
      LenReturnValue = Eth_GaaHwFunc[LucHWIPType]->pGetTxBuffer(
                                                      (uint32)CtrlIdx, Priority, BufIdxPtr, BufPtr, LenBytePtr);
    }
  }
  return(LenReturnValue);
} /* End of API Eth_ProvideTxBuffer */

/***********************************************************************************************************************
** Function Name         : Eth_Transmit
**
** Service ID            : 0x0A
**
** Description           : This API triggers transmission of a previously filled transmit buffer
**
** Sync/Async            : Asynchronous
**
** Reentrancy            : Reentrant for different buffer indexes and
**                         Ctrl indexes
**
** Input Parameters      : CtrlIdx:        Index of the controller
**                         BufIdx:         Index of the buffer resource
**                         FrameType:      Ethernet frame type
**                         TxConfirmation: Activates transmission confirmation
**                         LenByte:        Data length in byte
**                         PhysAddrPtr:    Physical target address (MAC address)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: Success.
**                         E_NOT_OK: Transmission failed.
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc, Eth_GaaTxBufferTotal, Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, pPreprocessFrame (function pointer), 
**                         pHwTransmit (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_010
** Reference ID          : ETH_DUD_ACT_010_ERR001, ETH_DUD_ACT_010_ERR002, ETH_DUD_ACT_010_ERR003
** Reference ID          : ETH_DUD_ACT_010_ERR004, ETH_DUD_ACT_010_GBL001, ETH_DUD_ACT_010_GBL002
** Reference ID          : ETH_DUD_ACT_010_GBL003, ETH_DUD_ACT_010_GBL004, ETH_DUD_ACT_010_GBL005
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_Transmit(                                                                     /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, Eth_BufIdxType BufIdx, Eth_FrameType FrameType, boolean TxConfirmation,
  uint16 LenByte, P2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) PhysAddrPtr)                                                 /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_TRANSMIT_SID, CtrlIdx);
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  /* Report Error to DET, if the PhysAddrPtr pointer value is NULL */
  else if (NULL_PTR == PhysAddrPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_TRANSMIT_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  /* Report Error to DET, if the BufIdx is out of range */
  /* 
     ETNB, ETNC: need buffer total mapping Eth_GaaTxBufferTotal
     ETNF, ETND, RSW: Eth_GaaTxBufferTotal[CtrlIdx]
     */
  else if ((uint32)Eth_GaaTxBufferTotal[CtrlIdx] <= BufIdx)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_TRANSMIT_SID, ETH_E_INV_PARAM);
    LucReturnValue = E_NOT_OK;
  }
  /* Report Error to DET, if the controller mode Is not Active */
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_TRANSMIT_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  /* Check whether the memory at the specified buffer index is valid */
  else if (NULL_PTR == Eth_GaaTxBufferMgrTable[CtrlIdx][BufIdx].pBufferHdr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_TRANSMIT_SID, ETH_E_INV_PARAM);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    /* Invoke Eth_PreprocessFrame to prepare a frame for transmission.*/
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pPreprocessFrame))                                                     /* PRQA S 3416 # JV-01 */
    {
      Eth_GaaHwFunc[LucHWIPType]->pPreprocessFrame((uint32)CtrlIdx, (uint32)BufIdx,
                                                    (uint32)FrameType, PhysAddrPtr, &LenByte);                          /* PRQA S 1339 # JV-01 */
    }/* else No action required */
    
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwTransmit))                                                          /* PRQA S 3416 # JV-01 */
    {
      /* Send a transmit request to the low level driver */
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwTransmit((uint32)CtrlIdx, (uint32)BufIdx,
                                                                (uint32)LenByte, TxConfirmation);
    }
    else
    {
      LucReturnValue = E_NOT_OK;
    }
  }
  return LucReturnValue;
} /* End of API Eth_Transmit */

#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_Receive
**
** Service ID            : 0x0B
**
** Description           : This API Triggers frame reception
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant for different FIFOs.
**                         Non Reentrant for the same FIFO.
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         QueueIdx: Specifies the related FIFO
**                             *This parameter is valid for AUTOSAR R4.3.1 later
**
** InOut Parameters      : None
**
** Output Parameters     : RxStatusPtr: Indicates whether a frame has been received and if so, whether more frames
**                                      are available or frames got lost.
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc, Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, pHwCheckFifoIndex (function pointer),
**                         pHwReceive (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_011
** Reference ID          : ETH_DUD_ACT_011_ERR001, ETH_DUD_ACT_011_ERR002, ETH_DUD_ACT_011_ERR003
** Reference ID          : ETH_DUD_ACT_011_ERR004, ETH_DUD_ACT_011_ERR005, ETH_DUD_ACT_011_GBL001
** Reference ID          : ETH_DUD_ACT_011_GBL002, ETH_DUD_ACT_011_GBL003
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_Receive(                                                                                /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx,
  uint8 QueueIdx,
  P2VAR(Eth_RxStatusType, AUTOMATIC, ETH_APPL_DATA) RxStatusPtr)                                                        /* PRQA S 3432 # JV-01 */
{
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucReturnValue;
  #endif
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_RECEIVE_SID, CtrlIdx);

  if (E_OK == LucReturnValue)
  {
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwCheckFifoIndex))                                                    /* PRQA S 3416 # JV-01 */
    {
      /* Invoke Eth_HwCheckFifoIndex to check the validity of the Queue index specified in the Eth_Receive*/
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwCheckFifoIndex((uint32)CtrlIdx, (uint32)QueueIdx);
    }/* else No action required */

    if (E_OK != LucReturnValue)
    {
      /* Report Error to DET, if the FifoIdx is out of range */
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_RECEIVE_SID, ETH_E_INV_PARAM);
    }/* else No action required */
  }/* else No action required */

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  /* Report Error to DET, if the RxStatusPtr pointer value is NULL */
  else if (NULL_PTR == RxStatusPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_RECEIVE_SID, ETH_E_PARAM_POINTER);
  }
  /* Report Error to DET, if the controller mode Is not Active */
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_RECEIVE_SID, ETH_E_INV_MODE);
  }
  else
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    /* Invoke Eth_HwReceive to update Descriptor */
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwReceive))                                                           /* PRQA S 3416 # JV-01 */
    {
      *RxStatusPtr = Eth_GaaHwFunc[LucHWIPType]->pHwReceive((uint32)CtrlIdx, (uint32)QueueIdx);
    }/* else No action required */
  }
}
#endif /* (ETH_CTRL_ENABLE_RX_POLLING == STD_ON) */

#if (ETH_CTRL_ENABLE_TX_POLLING == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_TxConfirmation
**
** Service ID            : 0x0C
**
** Description           : This API Triggers frame transmission confirmation
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller initialization
**                         using Eth_Init.
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GaaHWIP, Eth_GaaHwFunc
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, pHwTxConfirmation (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_012
** Reference ID          : ETH_DUD_ACT_012_ERR001, ETH_DUD_ACT_012_ERR002, ETH_DUD_ACT_012_ERR003
** Reference ID          : ETH_DUD_ACT_012_GBL001, ETH_DUD_ACT_012_GBL002, ETH_DUD_ACT_012_GBL003
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_TxConfirmation(                                                                         /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx)
{
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Index of HW IP Type */
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucReturnValue;
  LucReturnValue = Eth_CommonDetCheck(ETH_TXCONFIRMATION_SID, CtrlIdx);
  /* Do not execute at ETH_E_INV_CTRL_IDX */
  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  /* Report Error to DET, if the controller mode Is not Active */
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_TXCONFIRMATION_SID, ETH_E_INV_MODE);
  }
  else
  #endif
  {
    /* Get unit type */
    LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwTxConfirmation))                                                    /* PRQA S 3416 # JV-01 */
    {
      /* Invoke Eth_HwTxConfirmation to perform transmission processing, notify the upper layer of
      transmission completion and release the Tx buffer */
      Eth_GaaHwFunc[LucHWIPType]->pHwTxConfirmation((uint32)CtrlIdx);
    }/* else No Action required */
  }
}
#endif /* (ETH_CTRL_ENABLE_TX_POLLING == STD_ON) */

#if (ETH_VERSION_INFO_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetVersionInfo
**
** Service ID            : 0x0D
**
** Description           : This API returns the version information of Ethernet driver component.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : VersionInfoPtr : Pointer to where is stored the version information of this module
**
** Return parameter      : None
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter ETH_VERSION_INFO_API.
**
** Global Variables      : None
**
** Functions invoked     : Det_ReportError
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_028
** Reference ID          : ETH_DUD_ACT_028_ERR001
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_GetVersionInfo(                                                                         /* PRQA S 1503 # JV-01 */
  P2VAR(Std_VersionInfoType, AUTOMATIC, ETH_APPL_DATA)VersionInfoPtr)                                                   /* PRQA S 3432 # JV-01 */
{
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  /* Check if parameter passed is equal to Null pointer */
  if (NULL_PTR == VersionInfoPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GET_VERSION_INFO_SID, ETH_E_PARAM_POINTER);
  }
  else
  #endif
  {
    VersionInfoPtr->vendorID = (uint16)ETH_VENDOR_ID;
    VersionInfoPtr->moduleID = (uint16)ETH_MODULE_ID;
    VersionInfoPtr->sw_major_version = (uint8)ETH_SW_MAJOR_VERSION;
    VersionInfoPtr->sw_minor_version = (uint8)ETH_SW_MINOR_VERSION;
    VersionInfoPtr->sw_patch_version = (uint8)ETH_SW_PATCH_VERSION;
  }
}
#endif /* (STD_ON == ETH_VERSION_INFO_API ) */

/***********************************************************************************************************************
** Function Name         : Eth_MainFunction
**
** Service ID            : 0x20
**
** Description           : The function checks for controller errors and lost frames. Used for polling state changes.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables      : Eth_GaaHWIP, Eth_GaaHwFunc, Eth_GpCoreId2Index
**                         Eth_GpTotalCtrlConfig, Eth_CtrlConfigIdx, Eth_GpDriverState
**
** Functions invoked     : GetCoreID, Det_ReportError, pHwMainFunction (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_029
** Reference ID          : ETH_DUD_ACT_029_ERR001, ETH_DUD_ACT_029_GBL001, ETH_DUD_ACT_029_GBL002
** Reference ID          : ETH_DUD_ACT_029_GBL003, ETH_DUD_ACT_029_GBL004, ETH_DUD_ACT_029_GBL005
** Reference ID          : ETH_DUD_ACT_029_GBL006
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_MainFunction(void)                                                                      /* PRQA S 1503 # JV-01 */
{
  Eth_StateType LenState;
  uint32 LulIdx;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  uint8 LucCoreIndex;
  uint32 LulCtrIdx;
  uint32 LulTotalCtrlConfig;

  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  uint8 LucCoreId;

  /* Get Core id for code branching */
  LucCoreId = (uint8)GetCoreID();
  /* Covert Core Id to Core Index */
  LucCoreIndex = Eth_GpCoreId2Index[LucCoreId];
  #else
  /* if Multicore is not configude, defauld coreid is 0x00
     To optimize implementation */
  LucCoreIndex = ETH_ZERO;

  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  /* Check invalid core */
  if(ETH_INVALID_CORE == LucCoreIndex)
  {
    /* Report to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_MAINFUNCTION_SID, ETH_E_INVALID_CORE);
  }
  else
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/
  #endif /* End of #if (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    LenState = Eth_GpDriverState[LucCoreIndex];
    if (ETH_STATE_INIT != LenState)
    {
      /* No Action required */
    }
    else
    {
      /* Get total controller configured */
      LulTotalCtrlConfig = Eth_GpTotalCtrlConfig[LucCoreIndex];
      for (LulIdx = (uint32)ETH_ZERO; LulIdx < (uint32)LulTotalCtrlConfig; LulIdx++)
      {
        /* Get controller index configured */
        LulCtrIdx = Eth_CtrlConfigIdx[LucCoreIndex][LulIdx];
        /* Get unit type */
        LucHWIPType = Eth_GaaHWIP[LulCtrIdx].ucHwipType;
        if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwMainFunction))                                                  /* PRQA S 3416 # JV-01 */
        {
          /* Error check and device specific operations */
          Eth_GaaHwFunc[LucHWIPType]->pHwMainFunction(LulCtrIdx);
        }/* else No Action required */
      }
    }
  }
}

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetCurrentTime
**
** Service ID            : 0x16
**
** Description           : Returns a time value out of the HW registers according to the capability of the HW
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : timeQualPtr:  Quality of the HW TimeStamp returned
**                         timeStampPtr: Current TimeStamp value
**
** Return parameter      : Std_ReturnType
**                         E_OK: Success
**                         E_NOT_OK: Failed
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGlobalTimeSupport.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaHwFunc, Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwGetCurrentTime (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_030
** Reference ID          : ETH_DUD_ACT_030_ERR001, ETH_DUD_ACT_030_ERR002, ETH_DUD_ACT_030_ERR003
** Reference ID          : ETH_DUD_ACT_030_ERR004, ETH_DUD_ACT_030_GBL001, ETH_DUD_ACT_030_GBL002
** Reference ID          : ETH_DUD_ACT_030_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetCurrentTime(uint8 CtrlIdx,                                                 /* PRQA S 1503 # JV-01 */
  P2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) timeQualPtr,                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) timeStampPtr)                                                          /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETCURRENTTIME_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else if ((NULL_PTR == timeQualPtr) || (NULL_PTR == timeStampPtr))
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETCURRENTTIME_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETCURRENTTIME_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    /*Invoke Eth_HwGetCurrentTime to return TimeStamp from the HW register previously started.*/
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetCurrentTime))                                                    /* PRQA S 3416 # JV-01 */
    {
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwGetCurrentTime((uint32)CtrlIdx, timeQualPtr, timeStampPtr);
    }
    else
    {
      LucReturnValue = E_NOT_OK;
    }
  }
  return (LucReturnValue);
}

/***********************************************************************************************************************
** Function Name         : Eth_GetCurrentTimeTuple
**
** Service ID            : 0x21
**
** Description           : Returns a time value out of the HW registers according to the capability of the HW
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : currentTimeTuplePtr:  Value of timestamping and adjustable PHC
**
** Return parameter      : Std_ReturnType
**                         E_OK: Success
**                         E_NOT_OK: Failed
**
** Preconditions         : None.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwGetCurrentTimeTuple (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_031
** Reference ID          : ETH_DUD_ACT_031_ERR001, ETH_DUD_ACT_031_ERR002, ETH_DUD_ACT_031_ERR003
** Reference ID          : ETH_DUD_ACT_031_ERR004, ETH_DUD_ACT_031_GBL001, ETH_DUD_ACT_031_GBL002
** Reference ID          : ETH_DUD_ACT_031_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetCurrentTimeTuple(                                                          /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, uint8 ClkUnitIdx,
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) currentTimeTuplePtr)                                                   /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue;
  (void)ClkUnitIdx;

  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETCURRENTTIMETUPLE_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else if (NULL_PTR == currentTimeTuplePtr)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETCURRENTTIMETUPLE_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETCURRENTTIMETUPLE_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    /*Invoke pHwGetCurrentTimeTuple to return TimeStamp from the HW register previously started.*/
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetCurrentTimeTuple))                                               /* PRQA S 3416 # JV-01 */
    {
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwGetCurrentTimeTuple((uint32)CtrlIdx, currentTimeTuplePtr);
    }
    else
    {
      LucReturnValue = E_NOT_OK;
    }
  }
  return (LucReturnValue);
}

/***********************************************************************************************************************
** Function Name         : Eth_EnableEgressTimeStamp
**
** Service ID            : 0x17
**
** Description           : Enable TimeStamp capture for the message that will be transmitted
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         BufIdx:  Index of the message buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGlobalTimeSupport.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_013
** Reference ID          : ETH_DUD_ACT_013_ERR001, ETH_DUD_ACT_013_ERR002, ETH_DUD_ACT_013_ERR003
** Reference ID          : ETH_DUD_ACT_013_GBL001, ETH_DUD_ACT_013_GBL002, ETH_DUD_ACT_013_GBL003
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_EnableEgressTimeStamp(                                                                  /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, Eth_BufIdxType BufIdx)
{
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr = NULL_PTR;                                       /* PRQA S 3432 # JV-01 */
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucErrorValue;
  /* Local variable to hold the DET value */
  LucErrorValue = Eth_CommonDetCheck(ETH_ENEGRESSTS_SID, CtrlIdx);
  if (E_OK != LucErrorValue)
  {
    /* No action required */
  }
  else if (NULL_PTR == Eth_GaaTxBufferMgrTable[CtrlIdx][BufIdx].pBufferHdr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_ENEGRESSTS_SID, ETH_E_INV_PARAM);
  }
  else
  #endif
  {
    /* Get unit type */
    LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
    /* This will be written in the Ram Descriptor on the next Eth_Transmit call */
    if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pFindTxBufferHandler)                                                   /* PRQA S 3416 # JV-01 */
    {
      LpBufHandlerPtr = Eth_GaaHwFunc[LucHWIPType]->pFindTxBufferHandler((uint32)CtrlIdx, (uint32)BufIdx);
    } /* else No action required */
    if (NULL_PTR != LpBufHandlerPtr)
    {
      LpBufHandlerPtr->blbenableTS = ETH_TRUE;
    }
    else
    {
      /* No action required */
    }
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_GetEgressTimeStamp
**
** Service ID            : 0x18
**
** Description           : Reads back the egress time stamp on a dedicated message object.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         BufIdx:  Index of the message buffer
**
** InOut Parameters      : None
**
** Output Parameters     : timeQualPtr:  Quality of HW time stamp
**                         timeStampPtr: Current time stamp
**
** Return parameter      : None
**                         Std_ReturnType
**                         E_OK: Success
**                         E_NOT_OK: Failed
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGlobalTimeSupport.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc
**
** Function(s) invoked   : Eth_CommonDetCheck, Det_ReportError, pHwGetEgressTimeStamp(function pointer)
**
** Registers Used        : Eth_GaaCtrlStat
**
** Reference ID          : ETH_DUD_ACT_014
** Reference ID          : ETH_DUD_ACT_014_ERR001, ETH_DUD_ACT_014_ERR002, ETH_DUD_ACT_014_ERR003
** Reference ID          : ETH_DUD_ACT_014_ERR004, ETH_DUD_ACT_014_GBL001, ETH_DUD_ACT_014_GBL002
** Reference ID          : ETH_DUD_ACT_014_GBL003
***********************************************************************************\**************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetEgressTimeStamp(                                                           /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, Eth_BufIdxType BufIdx,
  P2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) timeQualPtr,                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) timeStampPtr)                                                          /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue = E_NOT_OK;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucCommonDetCheckValue;
  #endif
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  /* Local variable to hold the DET value */
  LucCommonDetCheckValue = Eth_CommonDetCheck(ETH_GETEGRESSTS_SID, CtrlIdx);

  if (E_OK != LucCommonDetCheckValue)
  {
    /* Do nothing */
  }
  else if ((NULL_PTR == timeQualPtr) || (NULL_PTR == timeStampPtr))
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETEGRESSTS_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
    {
      #if (ETH_DEV_ERROR_DETECT == STD_ON)
      /* Report Error to DET */
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETEGRESSTS_SID, ETH_E_INV_MODE);
      #endif
    }
    else
    {
      if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetEgressTimeStamp))                                              /* PRQA S 3416 # JV-01 */
      {
        LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwGetEgressTimeStamp((uint32)CtrlIdx, BufIdx,
                                                                                   timeQualPtr, timeStampPtr);
      }/* else no Action required */
    }
  }

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_GetIngressTimeStamp
**
** Service ID            : 0x19
**
** Description           : Return TimeStamp from the HW register
**                         previously started
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         DataPtr: Pointer to the message buffer
**
** InOut Parameters      : None
**
** Output Parameters     : timeQualPtr:  Quality of HW time stamp
**                         timeStampPtr: Current time stamp
**
** Return parameter      : None
**                         Std_ReturnType
**                         E_OK: Success
**                         E_NOT_OK: Failed
**
** Preconditions         : This function is pre-compile time configurable
**                        (STD_ON/STD_OFF) by the configuration parameter
**                         EthGlobalTimeSupport.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck,
**                         pHwGetIngressTimeStamp (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_015
** Reference ID          : ETH_DUD_ACT_015_ERR001, ETH_DUD_ACT_015_ERR002, ETH_DUD_ACT_015_ERR003
** Reference ID          : ETH_DUD_ACT_015_ERR004, ETH_DUD_ACT_015_GBL001, ETH_DUD_ACT_015_GBL002
** Reference ID          : ETH_DUD_ACT_015_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetIngressTimeStamp(                                                          /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx, P2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) DataPtr,                                               /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) timeQualPtr,                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(TimeStampType, AUTOMATIC, ETH_APPL_DATA) timeStampPtr)                                                          /* PRQA S 3432 # JV-01 */
{
  Std_ReturnType LucReturnValue = E_NOT_OK;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  Std_ReturnType LucCommonDetCheckValue;
  #endif
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  /* Local variable to hold the DET value */
  LucCommonDetCheckValue = Eth_CommonDetCheck(ETH_GETINGRESSTS_SID, CtrlIdx);
  if (E_OK != LucCommonDetCheckValue)
  {
    /* Do nothinig */
  }
  else if ((NULL_PTR == DataPtr) || (NULL_PTR == timeQualPtr) || (NULL_PTR == timeStampPtr))
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETINGRESSTS_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_GETINGRESSTS_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwGetIngressTimeStamp))                                               /* PRQA S 3416 # JV-01 */
    {
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwGetIngressTimeStamp((uint32)CtrlIdx, DataPtr,
                                                                          timeQualPtr, timeStampPtr);
    }/* else no Action required */
  }

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_SetIncrementTimeForGptp
**
** Service ID            : 0xA1
**
** Description           : Sets the gPTP timer increment with the specified value.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                         IncVal:  Increment value for gPTP timer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: gPTP increment register was successfully changed
**                         E_NOT_OK: gPTP increment register could not be changed and the DET is ON
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwSetIncrementTimeForGptp (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_032
** Reference ID          : ETH_DUD_ACT_032_ERR001, ETH_DUD_ACT_032_ERR002, ETH_DUD_ACT_032_ERR003
** Reference ID          : ETH_DUD_ACT_032_ERR004, ETH_DUD_ACT_032_GBL001, ETH_DUD_ACT_032_GBL002
** Reference ID          : ETH_DUD_ACT_032_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_SetIncrementTimeForGptp(                                                      /* PRQA S 1503 # JV-01 */
  CONST(uint8, AUTOMATIC) CtrlIdx, CONST(uint32, AUTOMATIC) IncVal)
{
  Std_ReturnType LucReturnValue = E_NOT_OK;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_SETINCREMENTTIMEFORGPTP_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No Action required */
  }
  #if (ETH_MACRO_ETNF == STD_ON)
  else if ((ETH_HWIP_ETNF == LucHWIPType) && ((ETH_GPTP_INC_MINVALUE > IncVal) || (ETH_GPTP_INC_MAXVALUE < IncVal)))    /* PRQA S 3416 # JV-01 */
  {
    /* Report Error to DET, if the increment value for gPTP timer out of range */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETINCREMENTTIMEFORGPTP_SID, ETH_E_INV_PARAM);

    LucReturnValue = E_NOT_OK;
  }
  #endif
  #if (ETH_MACRO_RSW3 == STD_ON)
  else if ((ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  && (ETH_MODE_DOWN != Eth_GaaCtrlStat[CtrlIdx].enMode))
  {
    /* Report Error to DET, if the controller mode Is Standby */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETINCREMENTTIMEFORGPTP_SID, ETH_E_INV_MODE);

    LucReturnValue = E_NOT_OK;
  }
  #endif
  else
  #endif
  {
    /* Invoke Eth_SetIncrementTimeForGptp to set a value to GTI and issue a load request*/
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwSetIncrementTimeForGptp))                                           /* PRQA S 3416 # JV-01 */
    {
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwSetIncrementTimeForGptp((uint32)CtrlIdx, IncVal);
    }/* else No action required */
  }
  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_SetOffsetTimeForGptp
**
** Service ID            : 0xA2
**
** Description           : Sets the gPTP timer offset with the specified value.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx:        Index of the controller
**                         pTimeOffsetPtr: Offset value for gPTP timer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: gPTP offset register was successfully changed
**                         E_NOT_OK: gPTP offset register could not be changed and the DET is ON
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwSetOffsetTimeForGptp (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_033
** Reference ID          : ETH_DUD_ACT_033_ERR001, ETH_DUD_ACT_033_ERR002, ETH_DUD_ACT_033_ERR003
** Reference ID          : ETH_DUD_ACT_033_ERR004, ETH_DUD_ACT_033_GBL001, ETH_DUD_ACT_033_GBL002
** Reference ID          : ETH_DUD_ACT_033_GBL003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_SetOffsetTimeForGptp(                                                         /* PRQA S 1503 # JV-01 */
  CONST(uint8, AUTOMATIC) CtrlIdx, CONSTP2CONST(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) pTimeOffsetPtr)
{
  Std_ReturnType LucReturnValue = E_NOT_OK;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  /* Local variable to hold the DET value */
  LucReturnValue = Eth_CommonDetCheck(ETH_SETOFFSETTIMEFORGPTP_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No Action required */
  }
  else if (NULL_PTR == pTimeOffsetPtr)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETOFFSETTIMEFORGPTP_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  #if (ETH_MACRO_RSW3 == STD_ON)
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETOFFSETTIMEFORGPTP_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  #endif
  else
  #endif
  {
    /* Invoke Eth_HwSetOffsetTimeForGptp to adjust gPTP with an given delta*/
    if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwSetOffsetTimeForGptp))                                              /* PRQA S 3416 # JV-01 */
    {
      LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwSetOffsetTimeForGptp((uint32)CtrlIdx, pTimeOffsetPtr);
    }/* else No action required */
  }
  return LucReturnValue;
}
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

#if (ETH_STREAM_FILTERING == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_UpdateStreamFilter
**
** Service ID            : 0xA0
**
** Description           : Update the stream ID for separate filtering with the specified AVB stream receive queue.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx:     Index of the controller
**                         QueIdx :     Index of the receive queue
**                         StreamIdPtr: Update the stream id for separate filtering
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK: filter was successfully changed
**                         E_NOT_OK: filter could not be changed and the DET is ON
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : Eth_GaaHWIP, Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, Eth_HwCheckRxStreamQueueIndex
**                         Eth_HwUpdateStreamFilter
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_034
** Reference ID          : ETH_DUD_ACT_034_ERR001, ETH_DUD_ACT_034_ERR002, ETH_DUD_ACT_034_ERR003
** Reference ID          : ETH_DUD_ACT_034_GBL001, ETH_DUD_ACT_034_GBL002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_UpdateStreamFilter(                                                           /* PRQA S 1503 # JV-01 */
  CONST(uint8, AUTOMATIC) CtrlIdx, CONST(uint8, AUTOMATIC) QueIdx,
  CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) StreamIdPtr)
{
  Std_ReturnType LucReturnValue = E_NOT_OK;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  LucReturnValue = Eth_CommonDetCheck(ETH_UPDATESTREAMFILTER_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No Action required */
  }
  else if (ETH_HWIP_ETNF != LucHWIPType)                                                                                /* PRQA S 3416 # JV-01 */
  {
    LucReturnValue = E_NOT_OK;
  }
  else if (NULL_PTR == StreamIdPtr)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_UPDATESTREAMFILTER_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  else if ((ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
        && (ETH_MODE_DOWN != Eth_GaaCtrlStat[CtrlIdx].enMode))
  {
    /* Report Error to DET, if the controller mode Is Standby */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_UPDATESTREAMFILTER_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    #if (ETH_DEV_ERROR_DETECT == STD_ON)
    LucReturnValue = Eth_HwCheckRxStreamQueueIndex((uint32)CtrlIdx, (uint32)QueIdx);
    if (E_OK != LucReturnValue)
    {
      
      /* Report Error to DET */
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_UPDATESTREAMFILTER_SID, ETH_E_INV_PARAM);
      
    }
    else
    #endif
    {
      /* Update Filter Pattern for the specific Rx queue */
      Eth_HwUpdateStreamFilter((uint32)CtrlIdx, (uint32)QueIdx, StreamIdPtr);
      LucReturnValue = E_OK;
    }
  }
  return LucReturnValue;
}
#endif /* (ETH_STREAM_FILTERING == STD_ON) */

#if (ETH_CTRL_ENABLE_SPI_INTERFACE_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetSpiStatus
**
** Service ID            : 0x1E
**
** Description           : This API returns the status defined by OA TC6 to identify if an error can occured at
**                         the SPI interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx: Index of the controller
**                       : SpiStatusType : Status of the Spi status type
**
** InOut Parameters      : None
**
** Output Parameters     : SpiStatusType
**
** Return parameter      : Std_ReturnType
**                         E_OK: success
**
** Preconditions         : Component Requires previous controller initialization using Eth_Init.
**
** Global Variables Used : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_018
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetSpiStatus(
  CONST(uint8, AUTOMATIC) CtrlIdx, P2VAR(Eth_SpiStatusType, AUTOMATIC, ETH_APPL_DATA) SpiStatusType)
{
  (void)CtrlIdx;
  (void)SpiStatusType;
  return E_OK;
}
#endif /* (ETH_CTRL_ENABLE_SPI_INTERFACE_API == STD_ON) */

#define ETH_STOP_SEC_PUBLIC_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
** Function Name         : Eth_DemConfigCheck
**
** Service ID            : N/A
**
** Description           : Checks if the EventId is configured, and if so, reports a DemEventReport.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : EventId : Identification of an event by assigned EventId.
**                         EventStatus : Monitor test result
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables      : None
**
** Functions invoked     : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_019
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_DemConfigCheck(
  CONST(Dem_EventIdType, AUTOMATIC) EventId,
  CONST(Dem_EventStatusType, AUTOMATIC) EventStatus)
{
  /* Report PASS to DEM */
  if ((Dem_EventIdType)ETH_DEM_NOT_CONFIGURED == EventId)
  {
    /* No action required */
  }
  else
  {
    ETH_DEM_REPORT_ERROR(EventId, EventStatus);
  }
}

/***********************************************************************************************************************
** Function Name       : Eth_SetStatus
**
** Service ID          : N/A
**
** Description         : This function updates Eth_GpDriverState.
**                       The purpose of this function is to prevent the order of
**                       instructions being changed by the compiler.
**
** Sync/Async          : Synchronous
**
** Reentrancy          : Non Reentrant
**
** Input Parameters    : LenStatus: New status value.
**                       CoreId: Code index.
**
** InOut Parameters    : None
**
** Output Parameters   : None
**
** Return parameter    : None
**
** Preconditions       : None
**
** Global Variable     : Eth_GpDriverState
**
** Function invoked    : Det_ReportError
**
** Registers Used      : None
**
** Reference ID        : ETH_DUD_ACT_020
** Reference ID        : ETH_DUD_ACT_020_ERR001, ETH_DUD_ACT_020_GBL001
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_SetStatus(
  uint8 CoreId, CONST(Eth_StateType, AUTOMATIC) LenStatus)
{
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  if(ETH_INVALID_CORE == CoreId)
  {
    /* Report to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_SETSTATUS_SID, ETH_E_INVALID_CORE);
  }
  else
  #endif
  #endif
  {
    Eth_GpDriverState[CoreId] = LenStatus;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_CommonDetCheck
**
** Service ID            : N/A
**
** Description           : This function performs DET checks which are common among almost all APIs.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LucSID:     Service ID of the caller
**                         LucCtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK     : No error is detected
**                         E_NOT_OK : Any error is detected
**
** Preconditions         : None
**
** Global Variables      : Eth_GpDriverState, Eth_GpCoreId2Index, Eth_GpTotalCtrlConfig, Eth_CtrlConfigIdx
**
** Functions invoked     : Det_ReportError, GetCoreID
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_035
** Reference ID          : ETH_DUD_ACT_035_ERR001, ETH_DUD_ACT_035_ERR002, ETH_DUD_ACT_035_ERR003
** Reference ID          : ETH_DUD_ACT_035_GBL001, ETH_DUD_ACT_035_GBL002, ETH_DUD_ACT_035_GBL003
** Reference ID          : ETH_DUD_ACT_035_GBL004
***********************************************************************************************************************/
#if (ETH_DEV_ERROR_DETECT == STD_ON)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_CommonDetCheck(
  CONST(uint8, AUTOMATIC) LucSID, CONST(uint8, AUTOMATIC) LucCtrlIdx)
{
  Std_ReturnType LucReturnValue;
  Eth_StateType LenState;
  uint8 LucCoreIndex;
  LucReturnValue = E_OK;
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  uint32 LulIdx;
  boolean LblValid;
  LblValid = ETH_FALSE;
  uint32 LulCtrIdx;
  uint32 LulTotalCtrlConfig;
  uint8 LucCoreId;
  /* Get Core id for code branching */
  LucCoreId = (uint8)GetCoreID();
  /* Covert Core Id to Core Index */
  LucCoreIndex = Eth_GpCoreId2Index[LucCoreId];
  #else
  /* if Multicore is not configured, defauld coreid is 0x00
     To optimize implementation */
  LucCoreIndex = ETH_ZERO;
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/

  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  /* Check invalid core */
  if(ETH_INVALID_CORE == LucCoreIndex)
  {
    /* Report to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, LucSID, ETH_E_INVALID_CORE);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    LenState = Eth_GpDriverState[LucCoreIndex];

    if (ETH_STATE_INIT != LenState)
    {
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, LucSID, ETH_E_UNINIT);
      LucReturnValue = E_NOT_OK;
    }
    else if ((uint32)ETH_TOTAL_CTRL_CONFIG <= LucCtrlIdx)
    {
      (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, LucSID, ETH_E_INV_CTRL_IDX);
      LucReturnValue = E_NOT_OK;
    }
    #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
    /* Check invalid core */
    else
    {
      /* Get total controller configured */
      LulTotalCtrlConfig = Eth_GpTotalCtrlConfig[LucCoreIndex];
      for (LulIdx = (uint32)ETH_ZERO; (LulIdx < (uint32)LulTotalCtrlConfig); LulIdx++)
      {
        /* Get controller index configured */
        LulCtrIdx = Eth_CtrlConfigIdx[LucCoreIndex][LulIdx];
        if (LulCtrIdx == LucCtrlIdx)
        {
          LblValid = ETH_TRUE;
        } /* else: No action required */
      }
      if (ETH_FALSE == LblValid)
      {
        /* Report to Det with invalid controller per core */
        (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, LucSID, ETH_E_INVALID_CORE);
        LucReturnValue = E_NOT_OK;
      }/* else: No action required */
    }
    #else
    else
    {
      /* No action required */
    }
    #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/
  }

  return LucReturnValue;
}
#endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_PUBLIC_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
/***********************************************************************************************************************
** Function Name         : Eth_ImmediateTransmit
**
** Service ID            : 0x26
**
** Description           : This API triggers immediate transmission of an input ETH frame.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : CtrlIdx:        Index of the controller
**                         TxHandleId:     Unique transmit handle id
**                         Priority:       Ethernet frame VLAN-priority
**                         HeaderListPtr:  Pointer to first Ethernet frame header of a single linked list
**                         PayloadPtr:     Pointer to the payload of the Ethernet frame
**                         PayloadLength:  Length of the payload
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK     : No error is detected
**                         E_NOT_OK : Any error is detected
**
** Preconditions         : None
**
** Global Variables      : Eth_GaaHWIP, Eth_GaaCtrlStat, Eth_GaaHwFunc, Eth_GaaTxBufferNodes
**
** Functions invoked     : Eth_CommonDetCheck, Det_ReportError, Det_ReportRuntimeError, 
**                         Eth_Util_CalculateFrameLength, Eth_Util_MemCopy, pGetImmTxBuffer (function pointer),
**                         pHwTransmit  (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_036
** Reference ID          : ETH_DUD_ACT_036_CRT001, ETH_DUD_ACT_036_ERR001, ETH_DUD_ACT_036_ERR002
** Reference ID          : ETH_DUD_ACT_036_ERR003, ETH_DUD_ACT_036_ERR004, ETH_DUD_ACT_036_ERR005
** Reference ID          : ETH_DUD_ACT_036_ERR006, ETH_DUD_ACT_036_GBL001, ETH_DUD_ACT_036_GBL002
** Reference ID          : ETH_DUD_ACT_036_GBL003, ETH_DUD_ACT_036_GBL004
***********************************************************************************************************************/
/* SWS_Eth_91022 */
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_ImmediateTransmit(                                                            /* PRQA S 1503 # JV-01 */
  uint8 CtrlIdx,
  Eth_BufIdxType TxHandleId,
  uint8 Priority,
  P2VAR(ListElemStructType , AUTOMATIC, ETH_APPL_DATA) HeaderListPtr,                                                   /* PRQA S 3432 # JV-01 */
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) PayloadPtr,                                                                    /* PRQA S 3432 # JV-01 */
  uint16 PayloadLength
)
{
  uint16 LusFrameLength;
  Std_ReturnType LucReturnValue = E_OK;
  uint32 LulBufAddr;
  Eth_BufIdxType LulBufIdx;
  BufReq_ReturnType LenReturnValue = BUFREQ_E_NOT_OK;
  ListElemStructType* current = HeaderListPtr;                                                                          /* PRQA S 3678 # JV-01 */
  boolean LucTxConfirmation = ETH_TRUE;
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;
  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_IMMEDIATETRANSMIT_SID, CtrlIdx);

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  /* Report Error to DET, if the PayloadPtr pointer value is NULL */
  else if (NULL_PTR == PayloadPtr)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_IMMEDIATETRANSMIT_SID, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }
  /* Report Error to DET, if the controller mode Is not Active */
  else if (ETH_MODE_ACTIVE != Eth_GaaCtrlStat[CtrlIdx].enMode)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_IMMEDIATETRANSMIT_SID, ETH_E_INV_MODE);
    LucReturnValue = E_NOT_OK;
  }
  else
  #endif
  {
    /* SWS_Eth_00314 */
    LusFrameLength = Eth_Util_CalculateFrameLength(HeaderListPtr, PayloadLength);

    if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pGetImmTxBuffer)                                                        /* PRQA S 3416 # JV-01 */
    {
      /* Get a buffer from the TxBufferRing */
      LenReturnValue = Eth_GaaHwFunc[LucHWIPType]->pGetImmTxBuffer(
                                                    (uint32)CtrlIdx, Priority, &LulBufIdx, &LulBufAddr, LusFrameLength);
    }/* else No action required */

    /* SWS_Eth_00313_2: Check if the element/buffer is available */
    if ((BUFREQ_E_BUSY == LenReturnValue) || (BUFREQ_E_NOT_OK == LenReturnValue))
    {
      Det_ReportRuntimeError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_IMMEDIATETRANSMIT_SID, ETH_E_EGRESS_QUEUE_OCCUPIED);   /* PRQA S 3200 # JV-01 */
      LucReturnValue = E_NOT_OK;
    }
    #if (ETH_DEV_ERROR_DETECT == STD_ON)
    /* SWS_Eth_00314 */
    else if (BUFREQ_E_OVFL == LenReturnValue)
    {
      Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_IMMEDIATETRANSMIT_SID, ETH_E_EXCEED_EGRESS_QUEUE_ELEMENT);    /* PRQA S 3200 # JV-01 */
      LucReturnValue = E_NOT_OK;
    }
    #endif
    else
    {
      /* Although the input ETH is included header but due to the old implementation,
      the header size will be added later */
      LusFrameLength = (uint16)(LusFrameLength - (uint16)ETH_HEADER_SIZE);

      ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Mark TxHandleId is used */
      Eth_GaaTxBufferNodes[CtrlIdx][LulBufIdx].blIsTxHandleId = ETH_TRUE;
      Eth_GaaTxBufferNodes[CtrlIdx][LulBufIdx].ucTxHandleId = TxHandleId;

      ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* SWS_Eth_00315: Prepare frame data to transmit */
      /* Copy header data in the linked list */
      while (NULL_PTR != current) {
        if (NULL_PTR != current->DataPtr)
        {
          Eth_Util_MemCopy((volatile uint8 *)LulBufAddr, (volatile uint8 *)current->DataPtr,                            /* PRQA S 0303 # JV-01 */
                                                              (volatile uint16 *)&current->DataLength);
          LulBufAddr += current->DataLength;                                                                            /* PRQA S 3383 # JV-01 */
          current = (ListElemStructType*) current->NextListElemPtr;
        }
        else
        {
          LucReturnValue = E_NOT_OK;
          break;
        }
      }
      if (E_NOT_OK != LucReturnValue)
      {
        /* Copy the payload data */
        Eth_Util_MemCopy((volatile uint8 *)LulBufAddr, PayloadPtr, (volatile uint16 *)&PayloadLength);                  /* PRQA S 0303, 1339 # JV-01, JV-01 */

        /* HW transmit */
        if (NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pHwTransmit)                                                        /* PRQA S 3416 # JV-01 */
        {
          /* Send a transmit request to the low level driver */
          LucReturnValue = Eth_GaaHwFunc[LucHWIPType]->pHwTransmit((uint32)CtrlIdx, LulBufIdx,
                                                                    (uint32)LusFrameLength, LucTxConfirmation);
        }/* else No action required */
      }/* else No action required */
    }
  }

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ReleaseRxBuffer
**
** Service ID            : N/A
**
** Description           : This function performs DET checks which are common
**                         among almost all APIs.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LucSID:     Service ID of the caller
**                         LucCtrlIdx: Index of the controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK     : No error is detected
**                         E_NOT_OK : Any error is detected
**
** Preconditions         : None
**
** Global Variables      : Eth_GaaHWIP, Eth_GaaRxBufferTotal, Eth_GaaRxBufferNodes, Eth_GaaHwFunc
**
** Functions invoked     : Eth_CommonDetCheck, Det_ReportError, pResetRxDesc (function pointer)
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_037
** Reference ID          : ETH_DUD_ACT_037_ERR001, ETH_DUD_ACT_037_ERR002, ETH_DUD_ACT_037_ERR003
** Reference ID          : ETH_DUD_ACT_037_GBL001, ETH_DUD_ACT_037_GBL002, ETH_DUD_ACT_037_GBL003
** Reference ID          : ETH_DUD_ACT_037_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PUBLIC_CODE) Eth_ReleaseRxBuffer(                                                                        /* PRQA S 1503 # JV-01 */
    CONST(uint8, AUTOMATIC) CtrlIdx,
    Eth_BufIdxType RxHandleId)
{
  P2VAR(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode;                                                  /* PRQA S 3432 # JV-01 */
  /* Index of HW IP Type */
  VAR(volatile uint8, AUTOMATIC) LucHWIPType;

  /* Get unit type */
  LucHWIPType = Eth_GaaHWIP[CtrlIdx].ucHwipType;

  /* Validate parameters if Dev Error Detect is enabled */
  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  /* Local variable to hold the DET value */
  Std_ReturnType LucErrorValue;

  LucErrorValue = Eth_CommonDetCheck(ETH_RELEASERXBUFFER_SID, CtrlIdx);

  if (E_OK != LucErrorValue)
  {
    /* No action required */
  }
  else if (RxHandleId >= Eth_GaaRxBufferTotal[CtrlIdx])
  {
    Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_RELEASERXBUFFER_SID, ETH_E_RX_HANDLE_ID_NOT_ASSOCIATED);        /* PRQA S 3200 # JV-01 */
  }
  else
  #endif
  {
    /* Fetch the Rx Buffer Node */
    LpRxBufferNode = &Eth_GaaRxBufferNodes[CtrlIdx][RxHandleId];

    /* Check if the RxHandleId is associated with the given CtrlIdx */
    if (((uint8 *)LpRxBufferNode->ulbufAddr != NULL_PTR) && (LpRxBufferNode->blLockedFlag == ETH_TRUE))                 /* PRQA S 0306 # JV-01 */
    {
      /* Reset Rx Descriptor */
      if ((NULL_PTR != Eth_GaaHwFunc[LucHWIPType]->pResetRxDesc))                                                       /* PRQA S 3416 # JV-01 */
      {
        /* Send a transmit request to the low level driver */
        Eth_GaaHwFunc[LucHWIPType]->pResetRxDesc((uint32)CtrlIdx, LpRxBufferNode);
      }/* else No action required */

      /* Release the Locked flag */
      LpRxBufferNode->blLockedFlag = ETH_FALSE;
    }/* else No action required */
  }
}

#if (ETH_INIT_SERDES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_InitSerdes
**
** Service ID            : 0xA6
**
** Description           : Initializes the Ethernet Serdes.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : CfgPtr : Pointer to ETH Driver configuration set
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : Std_ReturnType
**                         E_OK : Serdes Init successful
**                         E_NOT_OK : Serdes Init failed
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GpEthConfigPtr, Eth_GpDemEventAccess
**
** Function(s) invoked   : Det_ReportError, Eth_DemConfigCheck,
**                         Eth_Serdes_Initialize
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_038
** Reference ID          : ETH_DUD_ACT_038_ERR001, ETH_DUD_ACT_038_ERR002, ETH_DUD_ACT_038_ERR003
** Reference ID          : ETH_DUD_ACT_038_GBL001, ETH_DUD_ACT_038_GBL002, ETH_DUD_ACT_038_GBL003
** Reference ID          : ETH_DUD_ACT_038_GBL004
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_InitSerdes(                                                                   /* PRQA S 1503 # JV-01 */
  CONST(Eth_ConfigType*, AUTOMATIC) CfgPtr)
{
  uint32 LulCtrlIdx;
  uint32 LulSerDesChannel;
  Std_ReturnType LucResult;
  LucResult = E_OK;                                                                                                     /* PRQA S 2982 # JV-01 */
  
  uint32 LulIdx;
  uint8 LucCoreIndex;
  uint32 LulTotalCtrlConfig;
  P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */

  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  uint8 LucCoreId;
  /* Get Core id for code branching */
  LucCoreId = (uint8)GetCoreID();

  Eth_GpCoreId2Index = CfgPtr->pCoreId2Index;                                                                           /* PRQA S 2812 # JV-01 */
  /* Covert Core Id to Core Index */
  LucCoreIndex = Eth_GpCoreId2Index[LucCoreId];
  #else
  /* if Multicore is not configured, defauld coreid is 0x00
     To optimize implementation */
  LucCoreIndex = ETH_ZERO;
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  #if (ETH_MULTI_CORE_SUPPORT == STD_ON)
  /* Check invalid core */
  if(ETH_INVALID_CORE == LucCoreIndex)
  {
    /* Report to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_INIT_SID, ETH_E_INVALID_CORE);
    LucResult = E_NOT_OK;
  }
  else
  #endif /* End of #if (ETH_MULTI_CORE_SUPPORT == STD_ON)*/
  if (NULL_PTR == CfgPtr)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_INIT_SID, ETH_E_PARAM_POINTER);
    LucResult = E_NOT_OK;
  }
  /* Check whether the existing database is correct */
  else if (ETH_DBTOC_VALUE != CfgPtr->ulStartOfDbToc)
  {
    /* Report Error to DET */
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID, ETH_INIT_SID, ETH_E_INVALID_DATABASE);
    LucResult = E_NOT_OK;
  }
  else
  #endif /* (ETH_DEV_ERROR_DETECT == STD_ON) */
  {
    /* Assign the config pointer value to global pointer */
    Eth_GpCtrlConfigPtr = CfgPtr->pCtrlConfig;
    Eth_GpEthConfigPtr = Eth_GpCtrlConfigPtr->pEthConfig;
    Eth_GpDemEventAccess = CfgPtr->pDemEventAccess;
    Eth_GpTotalCtrlConfig = CfgPtr->pTotalCtrlConfig;

    /* Get total controller configured */
    LulTotalCtrlConfig = Eth_GpTotalCtrlConfig[LucCoreIndex];
    for (LulIdx = (uint32)ETH_ZERO; (LulIdx < (uint32)LulTotalCtrlConfig) && (E_OK == LucResult); LulIdx++)
    {
      LulCtrlIdx = CfgPtr->ulCtrlConfigIdx[LucCoreIndex][LulIdx];
      LpHwUnitConfig =
              (P2CONST(Eth_RSW3ConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;     /* PRQA S 0316, 3432 # JV-01, JV-01 */
      if(ETH_ENABLE == LpHwUnitConfig->stRMACIOConfig.enSerDesConnected)
      {
        /* For the case SerDes channel <n> connect with port ETHA/RMAC <n> */
        LulSerDesChannel = LpHwUnitConfig->ulEthPortId;
        Eth_GaaSerdesChConfig[LulSerDesChannel] = &Eth_GpEthConfigPtr[LulCtrlIdx];

        /**** Initialize SERDES ***************************************************/
        LucResult = Eth_Serdes_Initialize(LulSerDesChannel);
      }
    }

    /* Check Access error to Ethernet SERDES */
    if (E_OK != LucResult)
    {
      /* Issue DEM Error to all Controller */
      for (LulIdx = (uint32)ETH_ZERO; LulIdx < (uint32)LulTotalCtrlConfig; LulIdx++)
      {
        LulCtrlIdx = CfgPtr->ulCtrlConfigIdx[LucCoreIndex][LulIdx];
        Eth_DemConfigCheck(Eth_GpDemEventAccess[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
      }
    } /* No Action Required */
  }

  return LucResult;
} /* End of API Eth_InitSerdes */

#endif /* (ETH_INIT_SERDES_API == STD_ON) */

#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_GetAndResetMeasurementData
**
** Service ID            : 0x1D
**
** Description           : This API Returns the list of Transmission Error Counters out of IETF RFC1213 and RFC1643
**                         defined with Eth_TxErrorCounterValuesType, where the maximal possible value shall denote
**                         an invalid value.
**
** Sync/Async            : Synchronous.
**
** Reentrancy            : Non Reentrant.
**
** Input Parameters      : CtrlIdx: Index of the controller.
**                         MeasurementIdx: Indicate the measurement command.
**                         ResetNeeded: Indicate the reset command.
**
** InOut Parameters      : None
**
** Output Parameters     : MeasurementData: List of values to read statistic values
**
** Return parameter      : Std_ReturnType
**                         E_OK: success.
**                         E_NOT_OK: The measurement process could not be obtained.
**
** Preconditions         : This function is pre-compile time configurable (STD_ON/STD_OFF) by the configuration
**                         parameter EthGetAndResetMeasurementDataApi.
**
** Global Variables Used : Eth_GaaCtrlStat
**
** Function(s) invoked   : Det_ReportError, Eth_CommonDetCheck, pHwGetTxErrorCounterValues (function pointer)
**
** Registers Used        : None
**
** Reference ID          : 
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PUBLIC_CODE) Eth_GetAndResetMeasurementData (
uint8 CtrlIdx,
Eth_MeasurementIdxType MeasurementIdx,
boolean ResetNeeded,
P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) MeasurementData)
{
  Std_ReturnType LucReturnValue;

  #if (ETH_DEV_ERROR_DETECT == STD_ON)
  LucReturnValue = Eth_CommonDetCheck(ETH_GETANDRESETMEASUREMENTDATA_API, CtrlIdx);

  /* Report Error to DET, if the MeasurementIdx is ALL but ResetNeeded is false */
  if ((ETH_MEAS_ALL == MeasurementIdx) && (ETH_TRUE != ResetNeeded))
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID,
      ETH_GETANDRESETMEASUREMENTDATA_API, ETH_E_INV_PARAM);
    LucReturnValue = E_NOT_OK;
  }
  /* Report Error to DET, if the MeasurementIdx is not defined */
  else if (ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_RX_BUFFER < MeasurementIdx)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID,
      ETH_GETANDRESETMEASUREMENTDATA_API, ETH_E_INV_PARAM);
    LucReturnValue = E_NOT_OK;
  }
  /* Report Error to DET, if the MeasurementData pointer value is NULL */
  else if (NULL_PTR == MeasurementData)
  {
    (void)Det_ReportError(ETH_MODULE_ID, ETH_INSTANCE_ID,
      ETH_GETANDRESETMEASUREMENTDATA_API, ETH_E_PARAM_POINTER);
    LucReturnValue = E_NOT_OK;
  }/* else No action required */

  if (E_OK != LucReturnValue)
  {
    /* No action required */
  }
  else
  #endif
  {
    if (ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_TX_BUFFER == MeasurementIdx)
    {
      *MeasurementData = Eth_GaaCtrlStat[CtrlIdx].stMeasurementData.ulDropInsuffTxBuffCnt;
    }
    else if (ETH_MEAS_VENDOR_SPECIFIC_WARN_FULL_RX_BUFFER == MeasurementIdx)
    {
      *MeasurementData = Eth_GaaCtrlStat[CtrlIdx].stMeasurementData.ulWarnFullRxBuffCnt;
    }
    else if (ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_RX_BUFFER == MeasurementIdx)
    {
      *MeasurementData = ETH_NOT_AVAILABLE;
    } /* else No action required */
    
    if (ETH_TRUE == ResetNeeded)
    {
      Eth_ResetMeasurementData(CtrlIdx, MeasurementIdx);
    } /* else No action required */

    LucReturnValue = E_OK;
  }

  return (LucReturnValue);
} /* End of API Eth_GetAndResetMeasurementData */

/***********************************************************************************************************************
** Function Name       : Eth_ResetMeasurementData
**
** Service ID          : N/A
**
** Description         : Perform reset for the measurement counter
**
** Sync/Async          : Synchronous
**
** Reentrancy          : Non Reentrant
**
** Input Parameters    : LucCtrlIdx: Index of the controller.
**                       LenMeasurementIdx: Indicate the measurement command.
**
** InOut Parameters    : None
**
** Output Parameters   : None
**
** Return parameter    : None
**
** Preconditions       : None
**
** Global Variable     : Eth_GaaCtrlStat
**
** Function invoked    : None
**
** Registers Used      : None
**
** Reference ID        : 
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_ResetMeasurementData(
  CONST(uint8, AUTOMATIC) LucCtrlIdx, CONST(Eth_MeasurementIdxType, AUTOMATIC)  LenMeasurementIdx)
{
  if (ETH_MEAS_ALL == LenMeasurementIdx)
  {
    Eth_GaaCtrlStat[LucCtrlIdx].stMeasurementData.ulDropInsuffTxBuffCnt = (uint32)ETH_ZERO;
    Eth_GaaCtrlStat[LucCtrlIdx].stMeasurementData.ulWarnFullRxBuffCnt = (uint32)ETH_ZERO;
  }
  else if (ETH_MEAS_VENDOR_SPECIFIC_DROP_INSUFF_TX_BUFFER == LenMeasurementIdx)
  {
    Eth_GaaCtrlStat[LucCtrlIdx].stMeasurementData.ulDropInsuffTxBuffCnt = (uint32)ETH_ZERO;
  }
  else if (ETH_MEAS_VENDOR_SPECIFIC_WARN_FULL_RX_BUFFER == LenMeasurementIdx)
  {
    Eth_GaaCtrlStat[LucCtrlIdx].stMeasurementData.ulWarnFullRxBuffCnt = (uint32)ETH_ZERO;
  } /* else No action required */
}

#endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

#define ETH_STOP_SEC_PUBLIC_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                             End of File                                                            **
***********************************************************************************************************************/
