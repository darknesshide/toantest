/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Util.c                                                                                          */
/*====================================================================================================================*/
/*                                                    COPYRIGHT                                                       */
/*====================================================================================================================*/
/* Copyright(c) 2024-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains utility functions implementation of Ethernet Driver  Component.                                 */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                    Revision Control History                                                        **
***********************************************************************************************************************/
/*
 * 1.1.0: 01/08/2025    : Remove function Eth_Util_IniLinkedList, Eth_Util_EnqToList, Eth_Util_EnqToNode,
 *                        Eth_Util_PushToList, Eth_Util_PushToNode, Eth_Util_InsertToList, Eth_Util_InsertToNode,
 *                        Eth_Util_GetFromList, Eth_Util_GetFromNode, Eth_Util_RemoveToList, Eth_Util_RemoveToNode,
 *                        Eth_Util_AllRemoveToList, Eth_Util_AllRemoveToNode, Eth_Util_GetCountFromList,
 *                        Eth_Util_GetCountFromNode, Eth_Util_RamAlloc, Eth_Util_RamFree, Eth_Util_RamSetCircularAddr.
 * 1.0.0: 03/08/2024    : Add new function Eth_Util_MemCopy, Eth_Util_CalculateFrameLength
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                       Include Section                                                              **
***********************************************************************************************************************/
/* Included for prototypes for internal functions of Ethernet Component */
#include "Eth.h"
#include "Eth_Util.h"

/***********************************************************************************************************************
**                                       Version Information                                                          **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_UTIL_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_UTIL_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_UTIL_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_UTIL_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_UTIL_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                       Version Check                                                                **
***********************************************************************************************************************/
#if (ETH_UTIL_AR_RELEASE_MAJOR_VERSION != ETH_UTIL_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_Util.c : Mismatch in Release Major Version"
#endif
#if (ETH_UTIL_AR_RELEASE_MINOR_VERSION != ETH_UTIL_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_Util.c : Mismatch in Release Minor Version"
#endif
#if (ETH_UTIL_AR_RELEASE_REVISION_VERSION != ETH_UTIL_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_Util.c : Mismatch in Release Revision Version"
#endif

#if (ETH_UTIL_SW_MAJOR_VERSION != ETH_UTIL_C_SW_MAJOR_VERSION)
  #error "Eth_Util.c : Mismatch in Software Major Version"
#endif
#if (ETH_UTIL_SW_MINOR_VERSION != ETH_UTIL_C_SW_MINOR_VERSION)
  #error "Eth_Util.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0310)    : Casting to different object pointer type.                                                    */
/* Rule                : CERTCCM EXP39, EXP11, CWE Rule CWE-188, CWE-468, CWE-1157, CWE-398, CWE-465, CWE-569,        */
/*                       CWE-588, MISRA C:2012 Rule-11.3                                                              */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : For accessing 8-bit and 16-bit PNOT and JPNOT register respectively, the 32-bit pointer is   */
/*                       typecasted.                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0751)    : Casting to char pointer type.                                                                */
/* Rule                : CERTCCM EXP39, EXP11, CWE Rule CWE-188, CWE-468, CWE-1157, CWE-398, CWE-465, CWE-569,        */
/*                       CWE-588,                                                                                     */
/* JV-01 Justification : Using void due to specific requirement of input parameter. So, this can be skipped           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1338)    : The parameter '%1s' is being modified.                                                       */
/* Rule                :  MISRA C:2012 Rule-17.8                                                                      */
/* JV-01 Justification : This in case, parameter is not const, it could be accepted for modification                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-2.1                             */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:3305)    : Pointer cast to stricter alignment.                                                          */
/* Rule                : CERTCCM EXP36, EXP39, CWE Rule CWE-188, CWE-1157,  MISRA C:2012 Rule-11.3                    */
/* JV-01 Justification : Pointer alignment is changed by casting, but it's necessary for embedded programming         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%1s' is not modified and so the pointer       */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.13                     */
/* JV-01 Justification : Although the data in pointed address is not modified but the pointer type is defined by      */
/*                       AUTOSAR standard. It is accepted.                                                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Global Data                                                          **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                               Function Definitions                                                 **
***********************************************************************************************************************/
/*******************************************************************************
** Function Name         : Eth_Util_MemCopy
**
** Service ID            : NA
**
** Description           : Copy data from source to destination with input size
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LpDesPtr       : Destination address for data copy
**                         LpSrcPtr       : Source address for data copy
**                         LpPayloadLength: Length of data copy
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_100
*******************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(void, ETH_PRIVATE_CODE) Eth_Util_MemCopy(
  volatile P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDesPtr,                                                             /* PRQA S 3432 # JV-01 */
  volatile P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpSrcPtr,                                                             /* PRQA S 3432, 3673 # JV-01, JV-01 */
  volatile CONSTP2CONST(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLength)
{
  uint16 LusCounter;
  LusCounter = (uint16)ETH_ZERO;

  /* Copy memory byte to byte */
  do
  {
    *LpDesPtr = *LpSrcPtr;
    LpDesPtr++;                                                                                                         /* PRQA S 1338 # JV-01 */
    LpSrcPtr++;                                                                                                         /* PRQA S 1338 # JV-01 */
    LusCounter++;                                                                                                       /* PRQA S 3383 # JV-01 */
  } while (LusCounter < *LpPayloadLength);
}
#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/*******************************************************************************
** Function Name         : Eth_Util_CalculateFrameLength
**
** Service ID            : NA
**
** Description           : Calculate the frame length
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : HeaderListPtr: Pointer to first Ethernet frame
**                                        header of a single linked list.
**                         PayloadLength: Length of the payload
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_102
*******************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
FUNC(uint16, ETH_PRIVATE_CODE) Eth_Util_CalculateFrameLength(
  P2VAR(ListElemStructType, AUTOMATIC, ETH_APPL_DATA) HeaderListPtr, uint16 PayloadLength)                              /* PRQA S 3432, 3673, 3678 # JV-01, JV-01, JV-01 */
{
  uint16 LusTotalLength = PayloadLength;
  P2VAR(ListElemStructType , AUTOMATIC, ETH_APPL_DATA) current = HeaderListPtr;                                         /* PRQA S 3432, 3678 # JV-01, JV-01 */

  /* Calculate the frame length */
  while (current != NULL_PTR)
  {
    LusTotalLength += current->DataLength;                                                                              /* PRQA S 3383 # JV-01 */
    current = (ListElemStructType*) current->NextListElemPtr;
  }
  return LusTotalLength;
}
#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                End of File                                                         **
***********************************************************************************************************************/
