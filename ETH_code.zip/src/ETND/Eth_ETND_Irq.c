/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETND_Irq.c                                                                                      */
/*====================================================================================================================*/
/*                                             COPYRIGHT                                                              */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains Interrupt Service Routine for  Ethernet Driver Component                                        */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x, X5H                                                                                   */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                       Revision Control History                                                     **
***********************************************************************************************************************/
/*
 * 1.4.0: 09/04/2026    : Update to add MISRA-C Justification comment.
 * 1.1.1: 16/09/2025    : Update to support TSN-ES (RSW3)
 * 1.1.0: 25/07/2025    : Update to use macro constant instead of hard code.
 * 1.0.1: 14/02/2025    : Update Eth_DataIsr0 function to add macro cover pointer LpHwUnitConfig.
 * 1.0.0: 25/06/2024    : Support Interrupt ARDAACL-46847
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                       Include Section                                                              **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_Ram.h"
#if(ETH_DEVICE_NAME == ETH_U5X)
#include "Eth_ETND_Irq.h"
#include "Eth_ETND_Ram.h"
#elif(ETH_DEVICE_NAME == ETH_X5X)
#include "Eth_RSW3_TSNES_Irq.h"
#include "Eth_RSW3_TSNES_Ram.h"
#endif
/* Included for declaration of the function Dem_ReportErrorStatus() */
#include "Dem.h"
/***********************************************************************************************************************
**                                      Version Information                                                           **
***********************************************************************************************************************/
#if (ETH_MACRO_ETND == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETND_IRQ_C_AR_RELEASE_MAJOR_VERSION    ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_ETND_IRQ_C_AR_RELEASE_MINOR_VERSION    ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_ETND_IRQ_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_ETND_IRQ_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_ETND_IRQ_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                      Version Check                                                                 **
***********************************************************************************************************************/

/* Functionality related to R4.0 */
#if (ETH_AR_RELEASE_MAJOR_VERSION != ETH_ETND_IRQ_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_ETND_Irq.c : Mismatch in Release Major Version"
#endif
#if (ETH_AR_RELEASE_MINOR_VERSION != ETH_ETND_IRQ_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_ETND_Irq.c : Mismatch in Release Minor Version"
#endif
#if (ETH_AR_RELEASE_REVISION_VERSION != ETH_ETND_IRQ_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_ETND_Irq.c : Mismatch in Release Revision Version"
#endif

#if (ETH_SW_MAJOR_VERSION != ETH_ETND_IRQ_C_SW_MAJOR_VERSION)
  #error "Eth_ETND_Irq.c : Mismatch in Software Major Version"
#endif
#if (ETH_SW_MINOR_VERSION != ETH_ETND_IRQ_C_SW_MINOR_VERSION)
  #error "Eth_ETND_Irq.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1006)    : This in-line assembler construct is a language extension. The code has been ignored.         */
/* Rule                : CERTCCM MSC14, MISRA C:2012 Dir-1.1, Rule-1.2, Dir-4.2                                       */
/* JV-01 Justification : This is accepted, due to the Synchronization Processing Instruction is following hardware    */
/*                       specification.                                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1503)    : The function '%1s' is defined but is not used within this project.                           */
/* Rule                : CERTCCM MSC12, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-2.1                             */
/* JV-01 Justification : This is accepted, due to the module's API is exported for user's usage.                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2991)    : The value of this 'if' controlling expression is always 'true'.                              */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2995)    : The result of this logical operation is always 'true'.                                       */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3006)    : This function contains a mixture of in-line assembler statements and C statements.           */
/* Rule                : MISRA C:2012 Dir-4.3, CWE Rule CWE-398, CWE-569                                              */
/* JV-01 Justification : This is accepted, due to the implementation is following hardware specification.             */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3408)    : '%1s' has external linkage and is being defined without any previous declaration.            */
/* Rule                : CERTCCM DCL07, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.4                             */
/* JV-01 Justification : It is accepted, due to the declaration will be taken care by Os                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3415)    : Right hand operand of '&&' or '||' is an expression with persistent side effects.            */
/* Rule                : CERTCCM EXP02, CWE Rule CWE-398, CWE-569, CWE-768, MISRA C:2012 Rule-13.5                    */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Although it is a volatile object, it is not a direct access to the HW register, and there    */
/*                       is no side effect.                                                                           */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-1157, CWE-398, CWE-569,                                          */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/**********************************************************************************************************************/
/**                                              Global Data                                                          **
***********************************************************************************************************************/
/***********************************************************************************************************************
**                                              Function Definitions                                                  **
***********************************************************************************************************************/
#define ETH_START_SEC_CODE_FAST
#include "Eth_MemMap.h"
/* Prototypes for internal functions */
/* for U5x device */
#if(ETH_DEVICE_NAME == ETH_U5X)
#if ((ETH_TSN0_DATA1_ISR == STD_ON) || (ETH_TSN0_DATA2_ISR == STD_ON) || (ETH_TSN0_DATA3_ISR == STD_ON) || \
     (ETH_TSN1_DATA1_ISR == STD_ON) || (ETH_TSN1_DATA2_ISR == STD_ON) || (ETH_TSN1_DATA3_ISR == STD_ON))
#define ETH_CONTROLLER_DATA_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_DataIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIsr);
#endif

#if ((ETH_TSN0_DATA0_ISR == STD_ON) || (ETH_TSN1_DATA0_ISR == STD_ON))
#define ETH_CONTROLLER_DATA0_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_DataIsr0(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif

#if ((ETH_TSN0_GENERAL_ISR == STD_ON) || (ETH_TSN1_GENERAL_ISR == STD_ON))
#define ETH_CONTROLLER_GENERAL_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_GeneralIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

/* for X5H device */
#if(ETH_DEVICE_NAME == ETH_X5X)
#if ((ETH_TSN0_DATA0_ISR == STD_ON) || (ETH_TSN1_DATA0_ISR == STD_ON) || (ETH_TSN2_DATA0_ISR == STD_ON) || \
     (ETH_TSN3_DATA0_ISR == STD_ON) || (ETH_TSN4_DATA0_ISR == STD_ON) || (ETH_TSN5_DATA0_ISR == STD_ON) || \
     (ETH_TSN6_DATA0_ISR == STD_ON) || (ETH_TSN7_DATA0_ISR == STD_ON))
#define ETH_CONTROLLER_DATA0_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_DataIsr0(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif

#if ((ETH_TSN0_GENERAL_ISR == STD_ON) || (ETH_TSN1_GENERAL_ISR == STD_ON) || (ETH_TSN2_GENERAL_ISR == STD_ON) || \
     (ETH_TSN3_GENERAL_ISR == STD_ON) || (ETH_TSN4_GENERAL_ISR == STD_ON) || (ETH_TSN5_GENERAL_ISR == STD_ON) || \
     (ETH_TSN6_GENERAL_ISR == STD_ON) || (ETH_TSN7_GENERAL_ISR == STD_ON))
#define ETH_CONTROLLER_GENERAL_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_GeneralIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif
#endif /* #if(ETH_DEVICE_NAME == ETH_X5X) */

/***********************************************************************************************************************
** Function Name         : Eth_DataIsr0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs
**                         Eth_GpCtrlConfigPtr. Eth_GpEthConfigPtr
**                         Eth_GaaDescTsChainTable. Eth_GaaTsDescTotal
**                         Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : Eth_DemConfigCheck, Eth_ETND_HwTxConfirmation, Eth_HwReceive
**
** Registers Used        : TDISi, RDISi, TSDIS
**
** Reference ID          : ETH_DUD_ACT_2051
** Reference ID          : ETH_DUD_ACT_2051_GBL001, ETH_DUD_ACT_2051_GBL002, ETH_DUD_ACT_2051_GBL003
** Reference ID          : ETH_DUD_ACT_2051_GBL004, ETH_DUD_ACT_2051_GBL005, ETH_DUD_ACT_2051_GBL006
** Reference ID          : ETH_DUD_ACT_2051_GBL007
** Reference ID          : ETH_DUD_ACT_2051_REG001, ETH_DUD_ACT_2051_REG002, ETH_DUD_ACT_2051_REG001
** Reference ID          : ETH_DUD_ACT_2051_ERR001
***********************************************************************************************************************/
#ifdef ETH_CONTROLLER_DATA0_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_DataIsr0(CONST(uint32, AUTOMATIC) LulCtrlIdx)                                      /* PRQA S 3006 # JV-01 */
{
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI;

  #if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  uint32 LulTxIntStat;
  #endif

  #if ((ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  uint32 LulRxIntStat;
  #endif

  #if ((ETH_GLOBAL_TIME_SUPPORT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  uint32 LulTsIntStat;
  #endif

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  Eth_RxStatusType LenRetValue;
  uint32 LulTargetRxIntStat;
  uint32 LulRxQueueOffset;
  #if (ETH_DEVICE_NAME == ETH_X5X)
  uint32 LulRxFullStat = (uint32)ETH_ZERO;
  #endif
  #endif

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                   /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpDescTsChain;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpLinkDesc;                                                    /* PRQA S 3432 # JV-01 */
  Eth_BufIdxType LulBufIdx;
  uint32 LulRingIdx;
  #endif
  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  uint32 LulIntCheck;
  #endif

  #if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) \
        || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  #endif

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  LulRxQueueOffset = (uint32)LpHwUnitConfig->stQueueConfig.ucOffsetOfRxQueue;
  /* Get descriptor interrupt status */
  LulTargetRxIntStat = ETH_GET_RX_INT_STAT(0, LpAxiRegs->stRXDI[ETH_ZERO].ulRDISi, LulRxQueueOffset);                   /* PRQA S 3469 # JV-01 */
  #endif

  #if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  LulTxIntStat = (uint32)ETH_ZERO;
  #endif
  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enTxInterruptMode)                                                   /* PRQA S 3416 # JV-01 */
  {
    LulTxIntStat = (LpAxiRegs->stTXDI[ETH_ZERO].ulTDISi & LpHwUnitConfig->stQueueConfig.ulTxIntConfig)
                 & (uint32)ETH_ETND_TDIS_MASK(ETH_DATAISR0, LpHwUnitConfig->stQueueConfig.ucOffsetOfTxQueue);           /* PRQA S 3432 # JV-01 */
  } /* else: No action required */
  #endif

  #if ((ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  LulRxIntStat = (uint32)ETH_ZERO;
  #endif

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enRxInterruptMode)                                                   /* PRQA S 3416 # JV-01 */
  {
    LulRxIntStat = (LpAxiRegs->stRXDI[ETH_ZERO].ulRDISi & LpHwUnitConfig->stQueueConfig.ulRxIntConfig)
                 & (uint32)ETH_ETND_RDIS_MASK(ETH_DATAISR0, LpHwUnitConfig->stQueueConfig.ucOffsetOfRxQueue);           /* PRQA S 3432 # JV-01 */
    #if(ETH_DEVICE_NAME == ETH_X5X)
    LulRxFullStat = LpAxiRegs->stRXDFEI[ETH_ZERO].ulRFEISi;
    #endif
  } /* else: No action required */
  #endif

  #if ((ETH_GLOBAL_TIME_SUPPORT == STD_OFF) && (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  LulTsIntStat = (uint32)ETH_ZERO;                                                                                      /* PRQA S 2982 # JV-01 */
  #elif (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  LulTsIntStat = LpAxiRegs->ulTSDIS & ETH_ETND_TSDIS_0_MASK;
  #endif


  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enData0InterruptID);

  if ((ETH_INTERRUPT_STATUS_NOT_ACTIVE == LulIntCheck) ||
      (((uint32)ETH_ZERO == LulTxIntStat) && ((uint32)ETH_ZERO == LulRxIntStat) && ((uint32)ETH_ZERO == LulTsIntStat))) /* PRQA S 2995 # JV-01 */
  {
    Eth_DemConfigCheck(Eth_GpDemEventIntInconsistent[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif /* ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON */
  {
    #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
    if ((uint32)ETH_ZERO != LulTsIntStat)                                                                                            /* PRQA S 2991, 2995 # JV-01, JV-01 */
    {
      /* Clear the TS Descriptor Data Interrupt Status */
      LpAxiRegs->ulTSDIS = ETH_ETND_TSDIS_0_MASK;

      LpLinkDesc = &Eth_GaaDescTsChainTable[LulCtrlIdx][Eth_GaaTsDescTotal[LulCtrlIdx]];

      /* Check status of link descriptor */
      if (ETH_DESC_LEMPTY == LpLinkDesc->stHeader.ulDt)
      {
        /* Reset link descriptor status */
        LpLinkDesc->stHeader.ulDt = (uint32)ETH_DESC_LINK;
      } /* else: No action required */

      /* Search timestamp descriptor */
      LulRingIdx = Eth_GaaCtrlStat[LulCtrlIdx].ulTsDescTail;
      LpDescTsChain = &Eth_GaaDescTsChainTable[LulCtrlIdx][LulRingIdx];

      while (ETH_DESC_FSINGLE == LpDescTsChain->stHeader.ulDt)
      {
        LulBufIdx = (LpDescTsChain->stHeader.ulInfo0 & ETH_TX_DESCR_TSUN_MASK) >> (uint32)ETH_FOUR;
        if (NULL_PTR != Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr)
        {
          LpTxBufferNode = (Eth_BufHandlerType *)Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

          /* Read timestamp value to Tx buffer */
          LpTxBufferNode->stTimeStamp.nanoseconds = LpDescTsChain->ulTsns;
          LpTxBufferNode->stTimeStamp.seconds     = LpDescTsChain->ulTss;
          LpTxBufferNode->stTimeStamp.secondsHi   = (uint16)ETH_ZERO;

          /* Set timestamp quality information as VALID */
          LpTxBufferNode->enTimeQual = ETH_VALID;
        }

        /* Release timestamp descriptor */
        LpDescTsChain->stHeader.ulDie   = (uint32)ETH_TS_DESC_DIE_ENABLE;
        LpDescTsChain->stHeader.ulAxie  = (uint32)ETH_ZERO;
        LpDescTsChain->stHeader.ulDse   = (uint32)ETH_ZERO;
        LpDescTsChain->stHeader.ulInfo0 = (uint32)ETH_ZERO;
        LpDescTsChain->stHeader.ulDs    = (uint32)ETH_ZERO;
        LpDescTsChain->ulDptr     = (uint32)ETH_ZERO;
        LpDescTsChain->ulInfo1[(uint8)ETH_ZERO] = (uint32)ETH_ZERO;
        LpDescTsChain->ulInfo1[(uint8)ETH_ONE] = (uint32)ETH_ZERO;
        LpDescTsChain->ulTsns     = (uint32)ETH_ZERO;
        LpDescTsChain->ulTss      = (uint32)ETH_ZERO;

        LpDescTsChain->stHeader.ulDt = (uint32)ETH_DESC_FEMPTY_ND;
        LulRingIdx = (LulRingIdx + (uint32)ETH_ONE) % (uint32)(Eth_GaaTsDescTotal[LulCtrlIdx] + ETH_CYCLIC_DESC_NUM);   /* PRQA S 3383 # JV-01 */
        LpDescTsChain = &Eth_GaaDescTsChainTable[LulCtrlIdx][LulRingIdx];

        while ((ETH_DESC_LINK == LpDescTsChain->stHeader.ulDt) || (ETH_DESC_LEMPTY == LpDescTsChain->stHeader.ulDt))
        {
          LpDescTsChain->stHeader.ulDt = (uint32)ETH_DESC_LINK;
          LpDescTsChain = (Eth_ExtDescWithTsType *)LpDescTsChain->ulDptr;                                               /* PRQA S 0306 # JV-01 */
          LulRingIdx = (LulRingIdx + (uint32)ETH_ONE) % (uint32)(Eth_GaaTsDescTotal[LulCtrlIdx] + ETH_CYCLIC_DESC_NUM); /* PRQA S 3383 # JV-01 */
        }
      }

      Eth_GaaCtrlStat[LulCtrlIdx].ulTsDescTail = LulRingIdx;

      #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
      Eth_ETND_HwTxConfirmation(LulCtrlIdx);
      #endif /* ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON */
    } /* else: No action required */
    #endif /* ETH_GLOBAL_TIME_SUPPORT == STD_ON */

    #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
    if ((uint32)ETH_ZERO != LulTxIntStat)
    {
      /* Clear interrupt status */
      LpAxiRegs->stTXDI[(uint8)ETH_ZERO].ulTDISi = LulTxIntStat;
      Eth_ETND_HwTxConfirmation(LulCtrlIdx);
    } /* else: No action required */
    #endif /* ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON */

    #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
    #if (ETH_DEVICE_NAME == ETH_X5X)
    if (((uint32)ETH_ZERO != LulRxIntStat) || ((uint32)ETH_ZERO != LulRxFullStat))
    #elif(ETH_DEVICE_NAME == ETH_U5X)
    if ((uint32)ETH_ZERO != LulRxIntStat)
    #endif
    {
      /* Clear the RX Descriptor Data Interrupt Status */
      LpAxiRegs->stRXDI[ETH_ZERO].ulRDISi = LulTargetRxIntStat;
      do
      {
        LenRetValue = Eth_ETND_HwReceive(LulCtrlIdx, (uint32)ETH_ZERO);
      } while (ETH_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue);
    } /* else: No action required */
    #endif /* ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON */

    /* Execute the pipeline to avoid multiple interrupts */
    (void)LpAxiRegs->stTXDI[ETH_ZERO].ulTDISi;
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
  }
}
#endif /* ETH_CONTROLLER_DATA0_INTERRUPT_ON */

/***********************************************************************************************************************
** Function Name         : Eth_DataIsr
**
** Service ID            : Not Applicable
**
** Description           : Common part of each  ETH_DATAISR.
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx: The index of the controller
**                       : LulIsr: The index of the interrupt handler
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : The availability of the index must be guaranteed
**                         by the upper layer.
**
** Global Variables Used : Eth_GaaETND_EICRegs, Eth_GpDemEventIntInconsistent,
**                         Eth_GstETND_Regs, Eth_GaaETNE_EICRegs, Eth_GpETNE_MFWDRegs,
**                         Eth_GpCtrlConfigPtr, Eth_GpEthConfigPtr
**
** Function(s) invoked   : Eth_DemConfigCheck, Eth_ETND_HwTxConfirmation, Eth_HwReceive
**
** Registers Used        : EICn, TDISi, RDISi
**
** Reference ID          : ETH_DUD_ACT_2052
** Reference ID          : ETH_DUD_ACT_2052_GBL001, ETH_DUD_ACT_2052_GBL002, ETH_DUD_ACT_2052_GBL003
** Reference ID          : ETH_DUD_ACT_2052_GBL004
** Reference ID          : ETH_DUD_ACT_2052_REG001, ETH_DUD_ACT_2052_REG002
** Reference ID          : ETH_DUD_ACT_2052_ERR001
***********************************************************************************************************************/
#ifdef ETH_CONTROLLER_DATA_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_DataIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIsr)      /* PRQA S 3006 # JV-01 */
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  #if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  uint32 LulTxIntStat;
  #endif
  #if ((ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  uint32 LulRxIntStat;
  #endif

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  Eth_RxStatusType LenRetValue;
  uint32 LulTargetRxIntStat;
  uint32 LulRxQueueOffset;
  #endif

  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  uint32 LulIntCheck;
  #endif

  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316 # JV-01 */

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  LulRxQueueOffset = (uint32)LpHwUnitConfig->stQueueConfig.ucOffsetOfRxQueue;
  /* Get descriptor interrupt status */
  LulTargetRxIntStat = ETH_GET_RX_INT_STAT(0, LpAxiRegs->stRXDI[ETH_ZERO].ulRDISi, LulRxQueueOffset);                   /* PRQA S 3469 # JV-01 */
  #endif

  #if ((ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  LulTxIntStat = (uint32)ETH_ZERO;
  #endif

  #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enTxInterruptMode)                                                   /* PRQA S 3416 # JV-01 */
  {
    LulTxIntStat = (LpAxiRegs->stTXDI[ETH_ZERO].ulTDISi & LpHwUnitConfig->stQueueConfig.ulTxIntConfig)
               & (uint32)ETH_ETND_TDIS_MASK(LulIsr, LpHwUnitConfig->stQueueConfig.ucOffsetOfTxQueue);                   /* PRQA S 3432 # JV-01 */
  } /* else: No action required */
  #endif

  #if ((ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON) || (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON))
  LulRxIntStat = (uint32)ETH_ZERO;
  #endif

  #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enRxInterruptMode)                                                   /* PRQA S 3416 # JV-01 */
  {
    LulRxIntStat = (LpAxiRegs->stRXDI[ETH_ZERO].ulRDISi & LpHwUnitConfig->stQueueConfig.ulRxIntConfig)
               & (uint32)ETH_ETND_RDIS_MASK(LulIsr, LpHwUnitConfig->stQueueConfig.ucOffsetOfRxQueue);                   /* PRQA S 3432 # JV-01 */
  } /* else: No action required */
  #endif

  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  switch (LulIsr)
  {
    #if ((ETH_TSN0_DATA1_ISR == STD_ON) || (ETH_TSN1_DATA1_ISR == STD_ON))
    case ETH_DATAISR1:
      LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enData1InterruptID);
      break;
    #endif /* ((ETH_TSN0_DATA1_ISR == STD_ON) || (ETH_TSN1_DATA1_ISR == STD_ON)) */
    #if ((ETH_TSN0_DATA2_ISR == STD_ON) || (ETH_TSN1_DATA2_ISR == STD_ON))
    case ETH_DATAISR2:
      LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enData2InterruptID);
      break;
    #endif /* ((ETH_TSN0_DATA2_ISR == STD_ON) || (ETH_TSN1_DATA2_ISR == STD_ON)) */
    #if ((ETH_TSN0_DATA3_ISR == STD_ON) || (ETH_TSN1_DATA3_ISR == STD_ON))
    case ETH_DATAISR3:
      LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enData3InterruptID);
      break;
    #endif /* ((ETH_TSN0_DATA3_ISR == STD_ON) || (ETH_TSN1_DATA3_ISR == STD_ON)) */
    default:
      LulIntCheck = ETH_INTERRUPT_STATUS_NOT_ACTIVE;
      break;
  }

  if ((ETH_INTERRUPT_STATUS_NOT_ACTIVE == LulIntCheck) || (((uint32)ETH_ZERO == LulTxIntStat) &&
      ((uint32)ETH_ZERO == LulRxIntStat)))                                                                              /* PRQA S 2995 # JV-01 */
  {
    Eth_DemConfigCheck(Eth_GpDemEventIntInconsistent[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif /* ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON */
  {
    #if (ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON)
    if ((uint32)ETH_ZERO != LulTxIntStat)                                                                               /* PRQA S 2991, 2995 # JV-01, JV-01 */
    {
      /* Clear the TS Descriptor Data Interrupt Status bit */
      LpAxiRegs->stTXDI[ETH_ZERO].ulTDISi = LulTxIntStat;
      Eth_ETND_HwTxConfirmation(LulCtrlIdx);
    } /* else: No action required */
    #endif /* ETH_CTRL_ENABLE_TX_INTERRUPT == STD_ON */

    #if (ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON)
    if ((uint32)ETH_ZERO != LulRxIntStat)
    {
      /* Clear the RX Descriptor Data Interrupt Status */
      LpAxiRegs->stRXDI[ETH_ZERO].ulRDISi = LulTargetRxIntStat;
      do
      {
        LenRetValue = Eth_ETND_HwReceive(LulCtrlIdx, (uint32)ETH_ZERO);
      } while (ETH_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue);
    } /* else: No action required */
    #endif /* ETH_CTRL_ENABLE_RX_INTERRUPT == STD_ON */

    /* Execute the pipeline to avoid multiple interrupts */
    (void)LpAxiRegs->stTXDI[ETH_ZERO].ulTDISi;
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
  }
}
#endif /* ETH_CONTROLLER_DATA_INTERRUPT_ON */

/***********************************************************************************************************************
** Function Name         : Eth_GeneralIsr
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND/ETNE controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GpCtrlConfigPtr
**                         Eth_GpDemEventIntInconsistent, Eth_GpDemEventEccError
**                         Eth_GpDemEventDmaError
**
** Function(s) invoked   : Eth_DemConfigCheck
**
** Registers Used        : ETNDzSGINTS, ETNDzSGOPMS, MPIC, TCIS, TIS2, RIS, EIS0
**
** Reference ID          : ETH_DUD_ACT_2053
** Reference ID          : ETH_DUD_ACT_2053_GBL001, ETH_DUD_ACT_2053_GBL002, ETH_DUD_ACT_2053_GBL003
** Reference ID          : ETH_DUD_ACT_2053_GBL004, ETH_DUD_ACT_2053_GBL005
** Reference ID          : ETH_DUD_ACT_2053_REG001, ETH_DUD_ACT_2053_REG002, ETH_DUD_ACT_2053_REG003
** Reference ID          : ETH_DUD_ACT_2053_REG004, ETH_DUD_ACT_2053_REG005, ETH_DUD_ACT_2053_REG006
** Reference ID          : ETH_DUD_ACT_2053_REG007
** Reference ID          : ETH_DUD_ACT_2053_ERR001, ETH_DUD_ACT_2053_ERR002, ETH_DUD_ACT_2053_ERR003
** Reference ID          : ETH_DUD_ACT_2053_ERR004, ETH_DUD_ACT_2053_ERR005, ETH_DUD_ACT_2053_ERR006
***********************************************************************************************************************/
#ifdef ETH_CONTROLLER_GENERAL_INTERRUPT_ON
STATIC FUNC(void, ETH_CODE_FAST) Eth_GeneralIsr(CONST(uint32, AUTOMATIC) LulCtrlIdx)                                    /* PRQA S 3006 # JV-01 */
{
  #if (ETH_DEVICE_NAME == ETH_U5X)
  #if (ETH_ETND_SGMII_ISR == STD_ON)
  uint32 LulLinkState;
  uint32 LulRegVal;
  CONSTP2VAR(volatile Eth_ETND_SGMIIRegType, AUTOMATIC, REGSPACE) LpSgmiiRegs = Eth_GstETND_Regs.pSGMII;
  CONSTP2VAR(volatile Eth_ETND_RMACRegType, AUTOMATIC, REGSPACE) LpRmacRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC;
  #endif /* #if (ETH_ETND_SGMII_ISR == STD_ON) */
  #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  uint32 LulIntCheck;
  #endif

  #if (ETH_INTERRUPT_CONSISTENCY_CHECK == STD_ON)
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316 # JV-01 */

  LulIntCheck = NVIC_GetActive(LpHwUnitConfig->enGenInterruptID);

  if ((ETH_INTERRUPT_STATUS_NOT_ACTIVE == LulIntCheck)
    || (((uint32)ETH_ZERO == (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCIS    & (uint32)ETH_ETND_TCIS_ERROR_MASK))    /* PRQA S 3415, 3416 # JV-01, JV-01 */
    &&  ((uint32)ETH_ZERO == (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTIS2    & (uint32)ETH_ETND_TIS2_ERROR_MASK))    /* PRQA S 3415, 3416 # JV-01, JV-01 */
    &&  ((uint32)ETH_ZERO == (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRIS     & (uint32)ETH_ETND_RIS_ERROR_MASK))     /* PRQA S 3415, 3416 # JV-01, JV-01 */
    &&  ((uint32)ETH_ZERO == (Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0 & (uint32)ETH_ETND_EIS0_ECCFES_MASK))   /* PRQA S 3415, 3416 # JV-01, JV-01 */
    &&  ((uint32)ETH_ZERO == (Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0 & (uint32)ETH_ETND_EIS0_AEIS_MASK))     /* PRQA S 3415, 3416 # JV-01, JV-01 */
    #if (ETH_DEVICE_NAME == ETH_U5X)
    #if (ETH_ETND_SGMII_ISR == STD_ON)
    &&  ((uint32)ETH_ZERO == (Eth_GstETND_Regs.pSGMII->ulETNDzSGINTS           & (uint32)ETH_ETND_SGINTS_RDY_UNRDY))
    #endif /* #if (ETH_ETND_SGMII_ISR == STD_ON) */
    #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */
       )
    )
  {
    Eth_DemConfigCheck(Eth_GpDemEventIntInconsistent[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);
  }
  else
  #endif
  {
    #if (ETH_DEVICE_NAME == ETH_U5X)
    #if (ETH_ETND_SGMII_ISR == STD_ON)
    LulRegVal = LpSgmiiRegs->ulETNDzSGINTS;
    LulLinkState = LpSgmiiRegs->ulETNDzSGOPMS;
    if ((ETH_ETND_SGINTS_RDY == LulRegVal) ||
       ((ETH_ETND_SGINTS_RDY_UNRDY == LulRegVal) && (ETH_SGOPMS_DATA_COM == (LulLinkState & ETH_SGOPMS_XMIT_MASK))))
    {
      LpRmacRegs->ulMPIC = (LpRmacRegs->ulMPIC & ~ETH_SGOPMS_SPEED_MASK) | (LulLinkState & ETH_SGOPMS_SPEED_MASK);
    }
    else
    {
      LpRmacRegs->ulMPIC &= ~ETH_SGOPMS_SPEED_MASK;
    }
    LpSgmiiRegs->ulETNDzSGINTS = LulRegVal;
    #endif /* #if (ETH_ETND_SGMII_ISR == STD_ON) */
    #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

    if ((uint32)ETH_ZERO != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCIS & (uint32)ETH_ETND_TCIS_ERROR_MASK))        /* PRQA S 3416 # JV-01 */
    {
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);

      /* Clear Error Flag */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCIS &= (uint32)ETH_ETND_TCIS_CLEAR_ERROR_MASK;
    } /* else: No action required */

    if ((uint32)ETH_ZERO != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTIS2 & (uint32)ETH_ETND_TIS2_ERROR_MASK))        /* PRQA S 3416 # JV-01 */
    {
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);

      /* Clear Error Flag */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTIS2 &= (uint32)ETH_ETND_TIS2_CLEAR_ERROR_MASK;
    } /* else: No action required */

    if ((uint32)ETH_ZERO != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRIS & (uint32)ETH_ETND_RIS_ERROR_MASK))          /* PRQA S 3416 # JV-01 */
    {
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);

      /* Clear Error Flag */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRIS = (uint32)(ETH_ETND_RIS_ERROR_MASK);
    } /* else: No action required */

    if ((uint32)ETH_ZERO != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0 & (uint32)ETH_ETND_EIS0_ECCFES_MASK))    /* PRQA S 3416 # JV-01 */
    {
      Eth_DemConfigCheck(Eth_GpDemEventEccError[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);

      /* Clear Error Flag */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0 |= (uint32)ETH_ETND_EIS0_ECCFES_MASK;
    } /* else: No action required */

    if ((uint32)ETH_ZERO != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0 & (uint32)ETH_ETND_EIS0_AEIS_MASK))      /* PRQA S 3416 # JV-01 */
    {
      Eth_DemConfigCheck(Eth_GpDemEventDmaError[LulCtrlIdx], DEM_EVENT_STATUS_FAILED);

      /* Clear Error Flag */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0 |= (uint32)ETH_ETND_EIS0_AEIS_MASK;
    } /* else: No action required */

    /* Execute the pipeline to avoid multiple interrupts */
    (void)Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIS0;
    EXECUTE_SYNCP();                                                                                                    /* PRQA S 1006 # JV-01 */
  }
}
#endif /* ETH_CONTROLLER_GENERAL_INTERRUPT_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN0_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if ((ETH_TSN0_DATA0_ISR == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN0_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN0_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN0);
}
#endif
/***********************************************************************************************************************
** Function Name         : ETH_TSN1_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN1_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN1_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN1_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN1);
}
#endif /* ETH_TSN1_DATA0_ISR == STD_ON */

#if(ETH_DEVICE_NAME == ETH_X5X)
/***********************************************************************************************************************
** Function Name         : ETH_TSN2_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN2_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN2_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN2_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN2_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN2);
}
#endif /* ETH_TSN2_DATA0_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN3_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN3_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN3_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN3_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN3_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN3);
}
#endif /* ETH_TSN3_DATA0_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN4_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN4_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN4_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN4_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN4_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN4);
}
#endif /* ETH_TSN4_DATA0_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN5_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN5_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN5_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN5_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN5_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN5);
}
#endif /* ETH_TSN5_DATA0_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN6_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN6_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN6_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN6_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN6_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN6);
}
#endif /* ETH_TSN6_DATA0_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN7_DATAISR0
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler (only for ETND)
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr0
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2054
***********************************************************************************************************************/
#if (ETH_TSN7_DATA0_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN7_DATAISR0_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN7_DATAISR0_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN7_DATAISR0(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr0((uint32)ETHTSN7);
}
#endif /* ETH_TSN7_DATA0_ISR == STD_ON */
#endif /* #if(ETH_DEVICE_NAME == ETH_X5X) */

/***********************************************************************************************************************
** Function Name         : ETH_TSN0_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN0_GENERAL_ISR == STD_ON && ETH_MACRO_ETND == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN0_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN0_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN0);
}
#endif /* ETH_TSN0_GENERAL_ISR == STD_ON && ETH_MACRO_ETND == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN1_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN1_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN1_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN1_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN1);
}
#endif /* ETH_TSN1_GENERAL_ISR == STD_ON */

#if(ETH_DEVICE_NAME == ETH_X5X)
/***********************************************************************************************************************
** Function Name         : ETH_TSN2_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN2_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN2_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN2_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN2_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN2);
}
#endif /* ETH_TSN2_GENERAL_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN3_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN3_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN3_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN3_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN3_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN3);
}
#endif /* ETH_TSN3_GENERAL_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN4_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN4_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN4_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN4_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN4_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN4);
}
#endif /* ETH_TSN4_GENERAL_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN5_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN5_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN5_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN5_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN5_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN5);
}
#endif /* ETH_TSN5_GENERAL_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN6_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN6_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN6_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN6_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN6_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN6);
}
#endif /* ETH_TSN6_GENERAL_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN7_GENERALISR
**
** Service ID            : NA
**
** Description           : General Interrupt Service Handler for ETND controllers
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_GeneralIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2056
***********************************************************************************************************************/
#if (ETH_TSN7_GENERAL_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN7_GENERALISR_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN7_GENERALISR_CAT2)                                                                                           /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN7_GENERALISR(void)                                                         /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_GeneralIsr((uint32)ETHTSN7);
}
#endif /* ETH_TSN7_GENERAL_ISR == STD_ON */
#endif /* #if(ETH_DEVICE_NAME == ETH_X5X) */

/***********************************************************************************************************************
** Function Name         : ETH_TSN0_DATAISR1
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2055
***********************************************************************************************************************/
#if ((ETH_TSN0_DATA1_ISR == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN0_DATAISR1_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN0_DATAISR1_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_DATAISR1(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr((uint32)ETHTSN0, ETH_DATAISR1);
}
#endif /* ETH_TSN0_DATA1_ISR == STD_ON */

/***********************************************************************************************************************
** Function Name         : ETH_TSN0_DATAISR2
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2055
***********************************************************************************************************************/
#if ((ETH_TSN0_DATA2_ISR == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN0_DATAISR2_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN0_DATAISR2_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_DATAISR2(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr((uint32)ETHTSN0, ETH_DATAISR2);
}
#endif /* (ETH_TSN0_DATA2_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_TSN0_DATAISR3
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2055
***********************************************************************************************************************/
#if ((ETH_TSN0_DATA3_ISR == STD_ON))
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN0_DATAISR3_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN0_DATAISR3_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN0_DATAISR3(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr((uint32)ETHTSN0, ETH_DATAISR3);
}
#endif /* (ETH_TSN0_DATA3_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_TSN1_DATAISR1
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2055
***********************************************************************************************************************/
#if (ETH_TSN1_DATA1_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN1_DATAISR1_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN1_DATAISR1_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_DATAISR1(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr((uint32)ETHTSN1, ETH_DATAISR1);
}
#endif /* (ETH_TSN1_DATA1_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_TSN1_DATAISR2
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2055
***********************************************************************************************************************/
#if (ETH_TSN1_DATA2_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN1_DATAISR2_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN1_DATAISR2_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_DATAISR2(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr((uint32)ETHTSN1, ETH_DATAISR2);
}
#endif /* (ETH_TSN0_DATA2_ISR == STD_ON) */

/***********************************************************************************************************************
** Function Name         : ETH_TSN1_DATAISR3
**
** Service ID            : NA
**
** Description           : Data Interrupt Service Handler
**
** Sync/Async            : NA
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_DataIsr
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2055
***********************************************************************************************************************/
#if (ETH_TSN1_DATA3_ISR == STD_ON)
/* Defines the CAT2 interrupt mapping */
#if defined (Os_ETH_TSN1_DATAISR3_CAT2) || (ETH_ISR_CATEGORY_2 == STD_ON)
ISR(ETH_TSN1_DATAISR3_CAT2)                                                                                             /* PRQA S 1503, 3408 # JV-01, JV-01 */
#else
_INTERRUPT_ FUNC(void, ETH_CODE_FAST) ETH_TSN1_DATAISR3(void)                                                           /* PRQA S 1503 # JV-01 */
#endif
{
  Eth_DataIsr((uint32)ETHTSN1, ETH_DATAISR3);
}
#endif /* (ETH_TSN0_DATA3_ISR == STD_ON) */

#define ETH_STOP_SEC_CODE_FAST
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* (ETH_MACRO_ETND == STD_ON) */
/***********************************************************************************************************************
**                                           End of File                                                              **
***********************************************************************************************************************/
