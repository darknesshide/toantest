/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETND_Ram.c                                                                                      */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* Global RAM variable definitions for Eth Driver an RAM allocation functions                                         */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x, X5H                                                                                   */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.1.2: 01/07/2026    : Update function Eth_ETND_GetTxBuffer to implement the counter for Tx buffer check.
 * 1.1.1: 16/09/2025    : Update to support TSN-ES (RSW3)
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *                        Update to use macro constant instead of hard code.
 * 1.0.2: 12/03/2025    : Update to merging SingleMainline
 *                        + Update source code after Commonize the type Eth_TxBufferTypem, Eth_BufHandlerType,
 *                        Eth_RxFrameType, Eth_RxBufManageType
 *                        + Add global variable Eth_GaaTxRamInitState
 * 1.0.1: 21/02/2025    : Update function Eth_ETND_GetTxBuffer to add condition check for priority.
 *                        Remove function Eth_ETND_CheckProvideBuffer.
 *                        Update function table Eth_EtndFunc to remove function Eth_ETND_CheckBufferWithPiority and
 *                        add function Eth_ETND_GetImmTxBuffer.
 * 1.0.0: 28/09/2024    : Add new global variables Eth_Ctrl1_TxDescDataEtnd, Eth_Ctrl1_RxDescDataEtnd,
 *                        to support static memory.
 *                        Update global variables Eth_GaaTxDescTableEtnd, Eth_GaaRxDescTableEtnd.
 *                        Update function table Eth_EtndFunc to add functions Eth_ETND_CheckBufferWithPiority and
 *                        Eth_ETND_ResetRxDesc.
 *        29/08/2024    : Add new global variables Eth_Ctrl0_TxDescDataEtnd, Eth_Ctrl0_RxDescDataEtnd,
 *                        Eth_GaaTxDescTableEtnd, Eth_GaaRxDescTableEtnd to support static memory.
 *                        Add function Eth_ETND_RamInit to support static memory.
 *                        Add function Eth_ETND_CheckBufferWithPiority to support Eth_ImmediateTransmit API.
 *                        Modify functions Eth_ETND_InitializeBuffer, Eth_ETND_GetTxBuffer, Eth_ETND_ReleaseTxBuffer,
 *                        Eth_ETND_CheckProvideBuffer to support static memory.
 *        03/08/2024    : Add new function Eth_ETND_HwGetCurrentTimeTuple into Eth_EtndFunc
 *        09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
/* Included for Eth.h inclusion and macro definitions */
#include "Eth.h"
/* Header file inclusion */
#if(ETH_DEVICE_NAME == ETH_U5X)
#include "Eth_ETND_Ram.h"
#elif(ETH_DEVICE_NAME == ETH_X5X)
#include "Eth_RSW3_TSNES_Ram.h"
#endif
#include "Eth_Ram.h"
#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
/* Included for the declaration of the critical section protection functions */
#include "SchM_Eth.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#if (ETH_MACRO_ETND == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETND_RAM_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_ETND_RAM_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_ETND_RAM_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_ETND_RAM_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_ETND_RAM_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/

#if (ETH_ETND_RAM_AR_RELEASE_MAJOR_VERSION != ETH_ETND_RAM_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_ETND_Ram.c : Mismatch in Release Major Version"
#endif
#if (ETH_ETND_RAM_AR_RELEASE_MINOR_VERSION != ETH_ETND_RAM_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_ETND_Ram.c : Mismatch in Release Minor Version"
#endif
#if (ETH_ETND_RAM_AR_RELEASE_REVISION_VERSION != ETH_ETND_RAM_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_ETND_Ram.c : Mismatch in Release Revision Version"
#endif


#if (ETH_ETND_RAM_SW_MAJOR_VERSION != ETH_ETND_RAM_C_SW_MAJOR_VERSION)
   #error "Eth_ETND_Ram.c : Mismatch in Software Major Version"
#endif
#if (ETH_ETND_RAM_SW_MINOR_VERSION != ETH_ETND_RAM_C_SW_MINOR_VERSION)
   #error "Eth_ETND_Ram.c : Mismatch in Software Minor Version"
#endif
/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1504)    : The object '%1s' is only referenced in the translation unit where it is defined.             */
/* Rule                : CERTCCM DCL15, DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                      */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1533)    : The object '%1s' is only referenced by function '%2s'.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.9                                            */
/* JV-01 Justification : This is accepted, due to the object is defined in separated source C file to followed        */
/*                       coding rule                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2963)    : Suspicious: Using value of uninitialized automatic object '%s'.                              */
/* Rule                : CERTCCM EXP33, CWE Rule CWE-457, CWE-1157, CWE-908, CWE-452, CWE-465, CWE-824,               */
/* JV-01 Justification : It will be initialized based on scope of 'if' statements where at least an 'if' statement    */
/*                       will be executed that will initialize the variable in question.                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-561, CWE-569,  MISRA C:2012 Rule-2.2             */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3206)    : The parameter '%1s' is not used in this function.                                            */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-563, CWE-569,  MISRA C:2012 Rule-2.7             */
/* JV-01 Justification : This is done as per implementation requirement                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%1s' is not modified and so the pointer       */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.13                     */
/* JV-01 Justification : Pointer variable is used to modify the value at the address so the pointer cannot be         */
/*                       declared as 'pointer to const' type.                                                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4391)    : A composite expression of 'essentially unsigned' type (%1s) is being cast to a wider         */
/*                       unsigned type, '%2s'.                                                                        */
/* Rule                : CWE Rule CWE-136,  MISRA C:2012 Rule-10.8                                                    */
/* JV-01 Justification : This casting is for the lower operator which requires wider type.                            */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/
#define ETH_START_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_8
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_STOP_SEC_VAR_NO_INIT_16
#include "Eth_MemMap.h"

#define ETH_START_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"

/* Tx Desc Data for TxRam */
VAR(Eth_ExtDescType, ETH_VAR_NO_INIT) Eth_GaaTxRamDesc[(ETH_ETND_INIT_DESC_NUM + ETH_ETND_EOS_DESC_NUM)];               /* PRQA S 1533 # JV-01 */

#define ETH_STOP_SEC_VAR_DESC_BUFFER
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_NO_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */


#define ETH_STOP_SEC_VAR_NO_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

VAR(uint8, ETH_VAR_NO_INIT) Eth_GaaTxRamBuffer[ETH_ETND_2KB_FRAME_SIZE];                                                /* PRQA S 1533 # JV-01 */

#define ETH_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_BOOLEAN
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_8
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_16
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_STOP_SEC_VAR_INIT_PTR
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

#define ETH_START_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/* The Function table for ETND*/
VAR(Eth_HwFuncTableType, ETH_VAR_INIT) Eth_EtndFunc =
{
  /* pInitializeBuffer */
  &Eth_ETND_InitializeBuffer,
  /* pPreprocessBuffer */
  &Eth_ETND_PreprocessBuffer,
  /* pGetTxBuffer */
  &Eth_ETND_GetTxBuffer,
  /* pReleaseTxBuffer */
  &Eth_ETND_ReleaseTxBuffer,
  /* pPreprocessFrame */
  &Eth_ETND_PreprocessFrame,
  /* pFindTxBufferHandler */
  &Eth_ETND_FindTxBufferHandler,
  /* pHwInit */
  &Eth_ETND_HwInit,
  #ifdef ETH_HW_DEINIT
  #if (ETH_DEINIT_API == STD_ON)
  /* pHwDeInit */
  &Eth_ETND_HwDeInit,
  #endif
  #endif
  /* pHwDisableController */
  &Eth_ETND_HwDisableController,
  /* pHwEnableController */
  &Eth_ETND_HwEnableController,
  /* pHwTransmit */
  &Eth_ETND_HwTransmit,
  /* pHwGetCounterValues */
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  &Eth_ETND_HwGetCounterValues,
  #endif
  /* pHwGetRxStats */
  #if (ETH_GET_RX_STATS_API == STD_ON)
  &Eth_ETND_HwGetRxStats,
  #endif
  /* pHwGetTxStats */
  #if (ETH_GET_TX_STATS_API == STD_ON)
  &Eth_ETND_HwGetTxStats,
  #endif
  /* pHwGetTxErrorCounterValues */
  #if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
  &Eth_ETND_HwGetTxErrorCounterValues,
  #endif
  /* pHwMainFunction */
  &Eth_ETND_HwMainFunction,
  /* pHwTxConfirmation */
  &Eth_ETND_HwTxConfirmation,
  /* pHwCheckFifoIndex */
  #if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
  &Eth_ETND_HwCheckFifoIndex,
  #endif
  /* pHwReceive */
  &Eth_ETND_HwReceive,
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* pHwSetIncrementTimeForGptp*/
  &Eth_ETND_HwSetIncrementTimeForGptp,
  /* pHwSetOffsetTimeForGptp */
  &Eth_ETND_HwSetOffsetTimeForGptp,
  /* pHwGetCurrentTime */
  &Eth_ETND_HwGetCurrentTime,
  /* pHwGetCurrentTimeTuple */
  &Eth_ETND_HwGetCurrentTimeTuple,
  /* pHwGetEgressTimeStamp */
  &Eth_ETND_HwGetEgressTimeStamp,
  /* pHwGetIngressTimeStamp */
  &Eth_ETND_HwGetIngressTimeStamp,
  #endif
  #if (ETH_CTRL_ENABLE_MII == STD_ON)
  #if defined ETH_HW_NOT_LEGACY_MDIO
  /* pHwReadMii */
  &Eth_ETND_HwReadMii,
  /* pHwWriteMii */
  &Eth_ETND_HwWriteMii,
  #endif
  #if defined ETH_HW_LEGACY_MDIO
  /* HwReadMiibit */
  NULL_PTR,
  /* HwWriteMiibit */
  NULL_PTR,
  #endif
  #endif
  /* pGetImmTxBuffer */
  &Eth_ETND_GetImmTxBuffer,
  /* pResetRxDesc */
  &Eth_ETND_ResetRxDesc,
};

#define ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Eth_ETND_InitializeBuffer
**
** Service ID            : N/A
**
** Description           : Initialize the Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferTotal,
**                         Eth_GaaTxBufferMgrTable, Eth_GaaCtrlStat,
**                         Eth_GaaRxFrame
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2043,
** Reference ID          : ETH_DUD_ACT_2043_GBL001, ETH_DUD_ACT_2043_GBL002
** Reference ID          : ETH_DUD_ACT_2043_GBL003, ETH_DUD_ACT_2043_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_InitializeBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx)                             /* PRQA S 1505 # JV-01 */
{
  uint32 LulCnt;
  P2VAR(Eth_TxBufferType, AUTOMATIC, ETH_APPL_DATA) LpTxBuffer;                                                         /* PRQA S 3432 # JV-01 */

  /* Initialize resource information */
  Eth_GaaRxFrame[LulCtrlIdx].ulFrameAddr    = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr  = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength  = (uint32)ETH_ZERO;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds     = (uint32)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.secondsHi   = (uint16)ETH_ZERO;
  Eth_GaaRxFrame[LulCtrlIdx].enTimeQual              = ETH_INVALID;
  #endif
  /* Initialize Tx buffer index list */
  for (LulCnt = (uint32)ETH_ZERO; LulCnt < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulCnt++)
  {
    LpTxBuffer = (P2VAR(Eth_TxBufferType, AUTOMATIC, ETH_APPL_DATA))&Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulCnt];       /* PRQA S 3432 # JV-01 */
    LpTxBuffer->pBufferHdr = NULL_PTR;
  }

  /* Initialize buffer counter */
  for (LulCnt = (uint32)ETH_ZERO; LulCnt < ETH_TXQ_NUM_ETND; LulCnt++)
  {
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulCnt] = (uint32)ETH_ZERO;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_PreprocessBuffer
**
** Service ID            : N/A
**
** Description           : Write source address to all Tx Buffers in advance
**                         because source address is never changed while
**                         a controller mode is ACTIVE.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_PreprocessBuffer(CONST(uint32, AUTOMATIC) LulCtrlIdx)                             /* PRQA S 1505, 3206 # JV-01, JV-01 */
{
  (void)LulCtrlIdx;
  /* No action required because this function is retained for ETNC compatibility. */
}

/*******************************************************************************
** Function Name         : Eth_ETND_RamInit
**
** Service ID            : NA
**
** Description           : This Initialize base address of RAM for application
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaTxBufferNodes
**                         Eth_GaaTxBufferDataTable, Eth_CtrlTxMaxFrameLengthMapping
**                         Eth_GaaRxBufferNodes, Eth_GaaRxBufferDataTable
**                         Eth_CtrlRxMaxFrameLengthMapping
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2045
** Reference ID          : ETH_DUD_ACT_2045_GBL001, ETH_DUD_ACT_2045_GBL002,
** Reference ID          : ETH_DUD_ACT_2045_GBL003, ETH_DUD_ACT_2045_GBL004,
** Reference ID          : ETH_DUD_ACT_2045_GBL005, ETH_DUD_ACT_2045_GBL006,
** Reference ID          : ETH_DUD_ACT_2045_GBL007
*******************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_RamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulBufIdx;
  uint8 LucQueIdx;
  uint8 LucLoopIdx;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  LulBufIdx = (uint32)ETH_ZERO;

  /* Seting initial value for each Tx buffer node to manage each Tx buffer */
  for (LucQueIdx = ETH_ZERO; LucQueIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LucQueIdx++)
  {
    for (LucLoopIdx = ETH_ZERO;
                         LucLoopIdx < LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucQueIdx].ulQueueBufs; LucLoopIdx++)
    {
      /* Init node information */
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufIdx = LulBufIdx;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
        (uint32)&Eth_GaaTxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlTxMaxFrameLengthMapping[LulCtrlIdx]]; /* PRQA S 0306, 3384 # JV-01, JV-01 */
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulTxLength  = ETH_ZERO;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxQueueIdx  = LucQueIdx;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blbenableTS = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blTxConfirm = ETH_FALSE;
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].enTimeQual = INVALID;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.nanoseconds = (uint32)ETH_ZERO;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.seconds     = (uint32)ETH_ZERO;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.secondsHi   = (uint16)ETH_ZERO;
      #endif
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulEthTypeAddr = ETH_NOT_AVAILABLE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blUsedFlag = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId = ETH_FALSE;
      Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId = (uint32)ETH_ZERO;
      LulBufIdx++;                                                                                                      /* PRQA S 3383 # JV-01 */
    }
  }

  LulBufIdx = (uint32)ETH_ZERO;
  /* Seting initial value for each Rx buffer node to manage each Rx buffer */
  for (LucQueIdx = ETH_ZERO; LucQueIdx < LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LucQueIdx++)
  {
    for (LucLoopIdx = ETH_ZERO; LucLoopIdx < LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LucQueIdx].ulQueueBufs;
                                                                                                          LucLoopIdx++)
    {
      /* Init node information */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufIdx = LulBufIdx;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
        (uint32)&Eth_GaaRxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlRxMaxFrameLengthMapping[LulCtrlIdx]]; /* PRQA S 0306, 3384 # JV-01, JV-01 */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].blLockedFlag = ETH_FALSE;
      Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx].blRxConfirm = ETH_FALSE;
      LulBufIdx++;                                                                                                      /* PRQA S 3383 # JV-01 */
    }

    #if(ETH_DEVICE_NAME == ETH_U5X)
    /* Initialize the Buffer warning level counter */
    Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LucQueIdx] = ETH_ZERO;
    #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_GetTxBuffer
**
** Service ID            : N/A
**
** Description           : Get a buffer from the Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : A index of acquired buffer
**
** Preconditions         : None
**
** Global Variables Used : Eth_GpCtrlConfigPtr, Eth_GaaTxBufferTotal
**                         Eth_GaaTxBufferNodes, Eth_GaaTxBufferMgrTable, Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2046
** Reference ID          : ETH_DUD_ACT_2046_GBL001, ETH_DUD_ACT_2046_GBL002
** Reference ID          : ETH_DUD_ACT_2046_GBL003, ETH_DUD_ACT_2046_GBL004,
** Reference ID          : ETH_DUD_ACT_2046_CRT001, ETH_DUD_ACT_2046_CRT002
***********************************************************************************************************************/
FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_ETND_GetTxBuffer(                                                        /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint8*, AUTOMATIC, ETH_APPL_DATA) LpBufPtr,                                                                /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LenBytePtr)                                                              /* PRQA S 3432 # JV-01 */
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  BufReq_ReturnType LenReturnValue;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                   /* PRQA S 3432 # JV-01 */
  uint32 LulRingIdx;
  uint32 LulTxBufferMax;
  uint16 LusTxPayloadMax;
  uint16 LusReqSize;
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucReturnValue;
  #endif
  LpTxBufferNode = NULL_PTR;
  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Verify the input of LucPriority */
  if(LucPriority < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue)
  {
    LulTxBufferMax = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulQueueBufs;
    LusTxPayloadMax =
      (uint16)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulMaxFrameSize - ETH_HEADER_SIZE);             /* PRQA S 3383 # JV-01 */

    /* If the requested size is smaller than the minimum size, expand it to the minimum size */
    if ((uint16)ETH_MIN_PAYLOAD_SIZE_ETND > *LenBytePtr)
    {
      *LenBytePtr = (uint16)ETH_MIN_PAYLOAD_SIZE_ETND;
    } /* else: No action required */

    LusReqSize = *LenBytePtr;
    #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
    /* Added Switch Management Information */
    EthSwt_EthTxAdaptBufferLength(&LusReqSize);
    #endif

    if ((uint32)ETH_ZERO == LulTxBufferMax)
    {
      LenReturnValue = BUFREQ_E_NOT_OK;
    }
    else if (LusReqSize > LusTxPayloadMax)
    {
      /* If the requested size is larger than the buffer, return error */
      *LenBytePtr = LusTxPayloadMax - (LusReqSize - *LenBytePtr);                                                       /* PRQA S 2985 # JV-01 */
      LenReturnValue = BUFREQ_E_OVFL;
    }
    else
    {
      /* Enter the critical section protection */
      ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Get tx buffer index */
      for (LulRingIdx = (uint32)ETH_ZERO; LulRingIdx < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulRingIdx++)
      {
        if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].ucTxQueueIdx  == LucPriority)
        {
          if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag == ETH_FALSE)
          {
            LpTxBufferNode = &Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx];
            Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag = ETH_TRUE;
            break;
          } /* else no action required */
        } /* else no action required */
      }

      if (NULL_PTR != LpTxBufferNode)                                                                                   /* PRQA S 2963 # JV-01 */
      {
        /* Set next buffer index */
        Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulRingIdx].pBufferHdr = LpTxBufferNode;

        /* Get Tx buffer inforamtion based on Tx buffer node */
        *LpBufIdxPtr = (Eth_BufIdxType)LpTxBufferNode->ulbufIdx;
        *LpBufPtr = (uint8 *)(LpTxBufferNode->ulbufAddr + (uint32)ETH_HEADER_SIZE);                                     /* PRQA S 0306, 2963, 3383 # JV-01, JV-01, JV-01 */
        LpTxBufferNode->ulEthTypeAddr = LpTxBufferNode->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE;                           /* PRQA S 2963, 3383 # JV-01, JV-01 */

        #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
        LpDataPtr = (uint8 *)LpTxBufferNode->ulEthTypeAddr;                                                             /* PRQA S 0306 # JV-01 */
        /* Added Switch Management Information */
        LusReqSize = *LenBytePtr;
        /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
        LucReturnValue = EthSwt_EthTxPrepareFrame((uint8)LulCtrlIdx, *LpBufIdxPtr, &LpDataPtr, &LusReqSize);
        if (E_OK == LucReturnValue)
        {
          LpTxBufferNode->ulEthTypeAddr = (uint32)LpDataPtr;                                                            /* PRQA S 0306 # JV-01 */
          *LpBufPtr = (uint8 *)((uint32)LpDataPtr + ETH_ETHERTYPE_SIZE);                                                /* PRQA S 0306, 3383 # JV-01, JV-01 */
        } /* else: No action required. If it is not a switch frame, use it as a normal frame */
        #endif

        LenReturnValue = BUFREQ_OK;
      }
      else
      {
        #if(ETH_DEVICE_NAME == ETH_U5X)
        #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
        /* Increase the Measurement counter for unavailable Tx buffers */
        Eth_GaaCtrlStat[LulCtrlIdx].stMeasurementData.ulDropInsuffTxBuffCnt++;
        #endif
        #endif

        LenReturnValue = BUFREQ_E_BUSY;
      }

      /* Exit the critical section protection */
      ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
    }
  }
  else
  {
    LenReturnValue = BUFREQ_E_NOT_OK;
  }

  return LenReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_GetImmTxBuffer
**
** Service ID            : N/A
**
** Description           : This function gets a buffer from the Tx buffer ring for direct transmission
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : Controller index
**                         LucPriority    : Frame priority for transmit buffer
**                         LusFrameLength : Frame length
**
** InOut Parameters      : None
**
** Output Parameters     : LpBufIdxPtr    : Pointer to the index of granted buffer resource
**                         LpBufPtr       : Pointer to the granted buffer
**
** Return parameter      : A index of acquired buffer
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GaaTxBufferTotal,
**                         Eth_GpCtrlConfigPtr, Eth_GaaTxBufferNodes
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2047
** Reference ID          : ETH_DUD_ACT_2047_GBL001, ETH_DUD_ACT_2047_GBL002
** Reference ID          : ETH_DUD_ACT_2047_GBL003, ETH_DUD_ACT_2047_GBL004
** Reference ID          : ETH_DUD_ACT_2047_CRT001, ETH_DUD_ACT_2047_CRT002
***********************************************************************************************************************/
FUNC(BufReq_ReturnType , ETH_PRIVATE_CODE) Eth_ETND_GetImmTxBuffer(                                                     /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint8, AUTOMATIC) LucPriority,
  CONSTP2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA) LpBufIdxPtr,                                                     /* PRQA S 3432 # JV-01 */
  P2VAR(uint32, AUTOMATIC, ETH_APPL_DATA) LpBufAddr,                                                                    /* PRQA S 3432 # JV-01 */
  CONST(uint16, AUTOMATIC) LusFrameLength)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  BufReq_ReturnType LenReturnValue;
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode = NULL_PTR;                                        /* PRQA S 3432 # JV-01 */
  uint32 LulRingIdx;
  uint32 LulTxBufferMax;
  uint16 LusTxFrameLengthMax;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Verify the input of LucPriority */
  if(LucPriority < LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue)
  {
    LulTxBufferMax = LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulQueueBufs;
    LusTxFrameLengthMax =
      (uint16)(LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LucPriority].ulMaxFrameSize);

    if ((uint32)ETH_ZERO == LulTxBufferMax)
    {
      LenReturnValue = BUFREQ_E_NOT_OK;
    }
    else if (LusFrameLength > LusTxFrameLengthMax)
    {
      /* If the requested size is larger than the buffer, return error */
      LenReturnValue = BUFREQ_E_OVFL;
    }
    else
    {
      /* Enter the critical section protection */
      ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Get tx buffer index */
      for (LulRingIdx = (uint32)ETH_ZERO; LulRingIdx < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulRingIdx++)
      {
        if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].ucTxQueueIdx  == LucPriority)
        {
          if (Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag == ETH_FALSE)
          {
            LpTxBufferNode = &Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx];
            Eth_GaaTxBufferNodes[LulCtrlIdx][LulRingIdx].blUsedFlag = ETH_TRUE;
            break;
          } /* else no action required */
        } /* else no action required */
      }

      if (NULL_PTR != LpTxBufferNode)
      {
        /* Set next buffer index */
        Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulRingIdx].pBufferHdr = LpTxBufferNode;

        /* Get Tx buffer information based on Tx buffer node */
        *LpBufIdxPtr = (Eth_BufIdxType)LpTxBufferNode->ulbufIdx;
        *LpBufAddr = LpTxBufferNode->ulbufAddr;
        LpTxBufferNode->ulEthTypeAddr = LpTxBufferNode->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE;                           /* PRQA S 3383 # JV-01 */

        LenReturnValue = BUFREQ_OK;
      }
      else
      {
        LenReturnValue = BUFREQ_E_BUSY;
      }

      /* Exit the critical section protection */
      ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
    }
  }
  else
  {
    LenReturnValue = BUFREQ_E_NOT_OK;
  }

  return LenReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_ReleaseTxBuffer
**
** Service ID            : N/A
**
** Description           : Release a Tx buffer and store it to the tail of the
**                         Tx buffer ring
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LulBufIdx      : index of a tx buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaTxBufferMgrTable, Eth_GaaTxBufferNodes
**                         Eth_GaaTxBufferDataTable, Eth_CtrlTxMaxFrameLengthMapping
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2048,
** Reference ID          : ETH_DUD_ACT_2048_GBL001, ETH_DUD_ACT_2048_GBL002
** Reference ID          : ETH_DUD_ACT_2048_GBL003, ETH_DUD_ACT_2048_GBL004
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_ReleaseTxBuffer(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx)
{
  /* Release tx buffer handler */
  Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr = NULL_PTR;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulbufAddr =
       (uint32)&Eth_GaaTxBufferDataTable[LulCtrlIdx][LulBufIdx * (uint32)Eth_CtrlTxMaxFrameLengthMapping[LulCtrlIdx]];  /* PRQA S 0306, 3384 # JV-01, JV-01 */
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulTxLength  = (uint32)ETH_ZERO;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blbenableTS = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blTxConfirm = ETH_FALSE;
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].enTimeQual = INVALID;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.nanoseconds = (uint32)ETH_ZERO;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.seconds     = (uint32)ETH_ZERO;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].stTimeStamp.secondsHi   = (uint16)ETH_ZERO;
  #endif
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ulEthTypeAddr = ETH_NOT_AVAILABLE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blUsedFlag = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId = ETH_FALSE;
  Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId = (uint32)ETH_ZERO;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_PreprocessFrame
**
** Service ID            : N/A
**
** Description           : This function sets the destination MAC address
**                         and Ethernet type for the Tx buffer.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : controller index
**                         LulBufIdx      : index to the buffer
**                         LulFrameType   : ether type
**                         LpPhysAddrPtr  : destination mac address
**                         LpPayloadLen   : payload length
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : EthSwt_EthTxProcessFrame,
**                         ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2049,
** Reference ID          : ETH_DUD_ACT_2049_GBL001, ETH_DUD_ACT_2049_GBL002
** Reference ID          : ETH_DUD_ACT_2049_CRT001, ETH_DUD_ACT_2049_CRT002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_PreprocessFrame(                                                                  /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulFrameType,
  CONSTP2CONST(uint8, AUTOMATIC, ETH_APPL_DATA) LpPhysAddrPtr,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpPayloadLen)                                                            /* PRQA S 3206, 3432, 3673 # JV-01, JV-01, JV-01 */
{
  (void)LpPayloadLen;
  P2VAR(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpBufPtr;                                                               /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                  /* PRQA S 3432, 3678 # JV-01, JV-01 */
  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  uint16 LusTxLength;
  Std_ReturnType LucReturnValue;
  #endif

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Get Tx buffer address */
  LpBufHandlerPtr = Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  LpBufPtr = (Eth_DataType *)LpBufHandlerPtr->ulbufAddr;                                                                /* PRQA S 0306 # JV-01 */

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  LpDataPtr = (P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))(LpBufHandlerPtr->ulbufAddr + ETH_SRC_DST_ADDRESS_SIZE);          /* PRQA S 0306, 3383, 3432 # JV-01, JV-01, JV-01 */
  /* Since the maximum value of buffer size is 1518, casting to uint16 does no problem. */
  LusTxLength = *LpPayloadLen;
  /* decreased by the management information length */
  /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
  LucReturnValue = EthSwt_EthTxProcessFrame((uint8)LulCtrlIdx, LpBufHandlerPtr->ulbufIdx, &LpDataPtr, &LusTxLength);
  if (E_OK == LucReturnValue)
  {
    /* Adjusted for switch processing */
    LpBufPtr = (Eth_DataType *)(LpBufHandlerPtr->ulEthTypeAddr -                                                        /* PRQA S 0306, 3383 # JV-01, JV-01 */
                                (ETH_SRC_DST_ADDRESS_SIZE + (uint32)(LusTxLength - *LpPayloadLen)));                    /* PRQA S 3383, 4391 # JV-01, JV-01 */
    LpBufHandlerPtr->ulbufAddr = (uint32)LpBufPtr;                                                                      /* PRQA S 0306 # JV-01 */
    *LpPayloadLen = LusTxLength;
  } /* else: No action required. If EthSwt_SetMgmtInfo is not called, normal operation */
  #endif

  /* Copy destination address */
  ETH_COPY_MAC_ADDRESS((CONST(uint8, AUTOMATIC) *)LpPhysAddrPtr, (uint8 *)LpBufPtr);                                    /* PRQA S 3469 # JV-01 */
  LpBufPtr = LpBufPtr + ETH_MACADDR_SIZE;                                                                               /* PRQA S 0488 # JV-01 */

  ETH_UNPACK_ADDRESS_TO_8(Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr, LpBufPtr);                                             /* PRQA S 3469 # JV-01 */

  /* Casted to uint8 to extract the required 1 byte. */
  LpBufPtr = (Eth_DataType *)LpBufHandlerPtr->ulEthTypeAddr;                                                            /* PRQA S 0306 # JV-01 */
  *LpBufPtr = (Eth_DataType)((uint8)(LulFrameType >> ETH_BYTE_BITS));
  LpBufPtr++;
  /* Casted to uint8 to extract the required 1 byte. */
  *LpBufPtr = (Eth_DataType)((uint8)LulFrameType);
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_FindTxBufferHandler
**
** Service ID            : NA
**
** Description           : This get the tx buffer handler associated with
**                         the specified buffer index.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Index of controller
**                         LulBufIdx  - Index of tx buffer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2050
** Reference ID          : ETH_DUD_ACT_2050_GBL001
***********************************************************************************************************************/
FUNC(Eth_BufHandlerType *, ETH_PRIVATE_CODE) Eth_ETND_FindTxBufferHandler(                                              /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx)
{
  return Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;
}

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* (ETH_MACRO_ETND == STD_ON) */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/
