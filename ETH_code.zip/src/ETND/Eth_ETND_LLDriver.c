/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_ETND_LLDriver.c                                                                                 */
/*====================================================================================================================*/
/*                                                     COPYRIGHT                                                      */
/*====================================================================================================================*/
/* Copyright(c) 2024-2026 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains ETND specific operations of Eth Driver Component.                                               */
/*                                                                                                                    */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s) and/or */
/* the Application.                                                                                                   */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs of  */
/* program errors, compliance with applicable laws, damage to or loss of data, programs or equipment, and             */
/* unavailability or interruption of operations.                                                                      */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x, X5H                                                                                   */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                              Revision Control History                                              **
***********************************************************************************************************************/
/*
 * 1.4.2: 01/07/2026    : Update function Eth_ETND_HwInit to implement the reset for measurement counter.
 *                        Update function Eth_RxQueueProcess to implement the counter for Rx buffer check.
 * 1.4.1: 05/06/2026    : Update Eth_ETND_HwEnableController function to add macro enable/disable for preemption.
 *                        Update Eth_TxRamInit function to add setting for MPIC register.
 * 1.4.0: 26/03/2026    : Modify function Eth_ETND_HwInit to remove the enable interrupt implementation since interrupt 
 *                        will be handled by OS.
 * 1.2.1: 12/02/2026    : Update function Eth_ETND_HwInit to change the value that
 *                        written into ulPTPTIVCt for TSN-ES (RSW3)
 * 1.2.0: 30/12/2025    : Update to add the justification for Misra C msg 1710.
 * 1.1.1: 13/10/2025    : Update to add MisraC message.
 *        16/09/2025    : Update to support TSN-ES (RSW3)
 * 1.1.0: 25/07/2025    : Remove macro for old AUTOSAR version.
 *                        Update to use macro constant instead of hard code.
 *        04/07/2025    : Update function Eth_ETND_HwEnableController to modify formular for TAS start up time.
 *        12/06/2025    : Update function Eth_ETND_HwEnableController to move link verification step to OPERATION mode.
 * 1.0.2: 24/04/2025    : Update to remove macro ETH_UPDATE_PHYS_ADDR_FILTER
 *        13/03/2025    : Update to merging SingleMainline
 *                        + Update source code after Commonize the type Eth_TxBufferTypem, Eth_BufHandlerType,
 *                        Eth_RxFrameType, Eth_RxBufManageType
 *                        + Update function Eth_RxCallEthIf() to remove define LucHWIPType because of redundant
 * 1.0.1: 27/02/2025    : Change name of function Eth_ETND_GetTimeOutValue to Eth_ETND_GetElapsedTimeValue.
 *                        Update function Eth_ETND_GetElapsedTimeValue to fix issue ARDAACJ-695.
 *                        Remove WA() implementation.
 * 1.0.0: 21/10/2024    : Add WA() in function Eth_AXIBMI_Init, Eth_MHD_Init, Eth_ETND_HwGetCurrentTime,
 *                        Eth_ETND_HwGetCurrentTimeTuple, Eth_RxQueueProcess to workaround for HW defect.
 *        28/09/2024    : Add new function Eth_ETND_ResetRxDesc to reset the Rx descriptor.
 *                        Modify function Eth_ETND_HwInit to support enable interrupt.
 *        29/08/2024    : Modify functions Eth_ETND_HwInit, Eth_ETND_HwDisableController, Eth_AXIBMI_Init,
 *                        Eth_ETND_HwTransmit, Eth_ETND_HwTxConfirmation, Eth_TxRxDescConfig, Eth_RxQueueProcess
 *                        to support static memory.
 *                        Modify function RxCallEthIf to add new input argument LulBufIdx.
 *        03/08/2024    : Add function Eth_ETND_HwGetCurrentTimeTuple to get timestamp infor.
 *        16/07/2024    : Update function RxCallEthIf to support R23-11.
 *        25/06/2024    : Support Interrupt ARDAACL-46847.
 *        09/04/2024    : Initial Version.
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                  Include Section                                                   **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_Ram.h"
#if(ETH_DEVICE_NAME == ETH_U5X)
#include "Eth_ETND_Ram.h"
#include "Eth_ETND_LLDriver.h"
#elif(ETH_DEVICE_NAME == ETH_X5X)
#include "Eth_RSW3_TSNES_Ram.h"
#include "Eth_RSW3_TSNES_LLDriver.h"
#endif
#include "EthIf.h"

#if (ETH_CRITICAL_SECTION_PROTECTION == STD_ON)
/* Included for the declaration of the critical section protection functions */
#include "SchM_Eth.h"
#endif
#if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
#include "EthSwt_Eth.h"
#endif

/***********************************************************************************************************************
**                                                Version Information                                                 **
***********************************************************************************************************************/
#if (ETH_MACRO_ETND == STD_ON)
/* AUTOSAR release version information */
#define ETH_ETND_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_ETND_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_ETND_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_ETND_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_ETND_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                                                   Version Check                                                    **
***********************************************************************************************************************/
#if (ETH_ETND_AR_RELEASE_MAJOR_VERSION != ETH_ETND_C_AR_RELEASE_MAJOR_VERSION)
#error "Eth_ETND_LLDriver.c : Mismatch in Release Major Version"
#endif
#if (ETH_ETND_AR_RELEASE_MINOR_VERSION != ETH_ETND_C_AR_RELEASE_MINOR_VERSION)
#error "Eth_ETND_LLDriver.c : Mismatch in Release Minor Version"
#endif
#if (ETH_ETND_AR_RELEASE_REVISION_VERSION != ETH_ETND_C_AR_RELEASE_REVISION_VERSION)
#error "Eth_ETND_LLDriver.c : Mismatch in Release Revision Version"
#endif

#if (ETH_ETND_SW_MAJOR_VERSION != ETH_ETND_C_SW_MAJOR_VERSION)
#error "Eth_ETND_LLDriver.c : Mismatch in Software Major Version"
#endif
#if (ETH_ETND_SW_MINOR_VERSION != ETH_ETND_C_SW_MINOR_VERSION)
#error "Eth_ETND_LLDriver.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (2:0306)    : Cast between a pointer to object and an integral type.                                       */
/* Rule                : CERTCCM INT36, CWE Rule CWE-1158, CWE-398, CWE-569, MISRA C:2012 Rule-11.4                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : Typecasting is done as per the register size, to access hardware registers.                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0310)    : Casting to different object pointer type.                                                    */
/* Rule                : CERTCCM EXP39, EXP11, CWE Rule CWE-188, CWE-468, CWE-1157, CWE-398, CWE-465, CWE-569,        */
/*                       CWE-588, MISRA C:2012 Rule-11.3                                                              */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : For accessing 8-bit and 16-bit PNOT and JPNOT register respectively, the 32-bit pointer is   */
/*                       typecasted.                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0316)    : Cast from a pointer to void to a pointer to object type.                                     */
/* Rule                : CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-11.5                                   */
/*                       REFERENCE - ISO:C90-6.3.4 Cast Operators - Semantics                                         */
/* JV-01 Justification : A cast should not be performed between a pointer to object type and a different pointer to   */
/*                       object type.                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0326)    : Cast between a pointer to void and an integral type.                                         */
/* Rule                : CERTCCM EXP36, INT36, MISRA C:2012 Rule-11.6, CWE-398, CWE-569, CWE-738                      */
/* JV-01 Justification : Using void due to specific requirement of input parameter. So, this can be skipped.          */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (7:0404)    : More than one read access to volatile objects between sequence points.                       */
/* Rule                : CERTCCM EXP30, EXP10, CWE Rule CWE-1157, CWE-758, CWE-682, MISRA C:2012 Rule-1.3, Rule-13.2  */
/*                       REFERENCE - ISO:C90-6.3 Expressions                                                          */
/* JV-01 Justification : This is to get element in array of struct, volatile of counter variable of 'for' loop is     */
/*                       used to ensure no optimization. It is accepted                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0488)    : Performing pointer arithmetic.                                                               */
/* Rule                : CERTCCM EXP08, CWE Rule CWE-188, CWE-398, CWE-569, MISRA C:2012 Rule-18.4                    */
/*                       REFERENCE - ISO:C90-6.3.6 Additive Operators - Constraints                                   */
/* JV-01 Justification : This is to get the ID in the data structure in the code.                                     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:0759)    : An object of union type has been defined.                                                    */
/* Rule                : CWE Rule CWE-843,  MISRA C:2012 Rule-19.2                                                    */
/* JV-01 Justification : Data access of larger data types is used to achieve better throughput.                       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1505)    : The function '%1s' is only referenced in the translation unit where it is defined.           */
/* Rule                : CERTCCM DCL19, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.7                             */
/* JV-01 Justification : This is accepted, due to following coding rule, internal function can be defined in other C  */
/*                       source files                                                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:2982)    : This assignment is redundant. The value of this object is never used before being modified.  */
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-14, CWE-398, CWE-561, CWE-563, CWE-569,  MISRA C:2012     */
/*                       Rule-2.2                                                                                     */
/* JV-01 Justification : The variable needs to be initialized before using it.                                        */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:2985)    : This operation is redundant. The value of the result is always that of the left-hand operand.*/
/* Rule                : CERTCCM MSC12, MSC13, CWE Rule CWE-398, CWE-561, CWE-569,  MISRA C:2012 Rule-2.2             */
/* JV-01 Justification : For readability, setting to registers will used redundant macros and is based on hardware    */
/*                       user's manual                                                                                */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2991)    : The value of this 'if' controlling expression is always 'true'.                              */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2995)    : The result of this logical operation is always 'true'.                                       */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on device configuration, there is case where the 'if' will return 'false'.         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:3305)    : Pointer cast to stricter alignment.                                                          */
/* Rule                : CERTCCM EXP36, EXP39, CWE Rule CWE-188, CWE-1157,  MISRA C:2012 Rule-11.3                    */
/* JV-01 Justification : Pointer alignment is changed by casting, but it's necessary for embedded programming         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3383)    : Cannot identify wraparound guard for unsigned arithmetic expression.                         */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : It can still result in values that are out of range for the intended use, as intuitive       */
/*                       "invariants" may not hold                                                                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:3384)    : Cannot identify wraparound guard for dependent unsigned arithmetic expression.               */
/* Rule                : CERTCCM INT30,                                                                               */
/* JV-01 Justification : In order to effectively guard against overflow and wraparound at all stages, the expression  */
/*                       should be split up into individual dynamic operations, with their own guards where applicable*/
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3416)    : Logical operation performed on expression with persistent side effects.                      */
/* Rule                : CERTCCM EXP45, CWE Rule CWE-1157, CWE-398, CWE-569,                                          */
/*                       REFERENCE - ISO:C90-5,1,2,3 Program Execution                                                */
/* JV-01 Justification : Logical operation accesses volatile object which is a register access. All register          */
/*                       addresses are generated with volatile qualifier. There is no impact on the functionality     */
/*                       due to this conditional check for mode change.                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3432)    : Simple macro argument expression is not parenthesized.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569, MISRA C:2012 Rule-20.7                                            */
/*                       REFERENCE - ISO:C90-6.3.1 Primary Expressions                                                */
/* JV-01 Justification : Compiler keyword (macro) is defined and used followed AUTOSAR standard rule. It is accepted. */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3673)    : The object addressed by the pointer parameter '%1s' is not modified and so the pointer       */
/*                       could be of type 'pointer to const'.                                                         */
/* Rule                : CERTCCM DCL00, DCL13, CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.13                     */
/* JV-01 Justification : Pointer variable is used to modify the value at the address so the pointer cannot be         */
/*                       declared as 'pointer to const' type.                                                         */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3678)    : The object referenced by '%1s' is not modified through it, so '%1s' could be declared with   */
/*                       type '%2s'.                                                                                  */
/* Rule                :  MISRA C:2012 Rule-8.13                                                                      */
/* JV-01 Justification : This is accepted. It just an advise for improve safety by reducing the possibility that the  */
/*                       referenced data is unintentionally modified through an unexpected alias and improves         */
/*                       clarity by indicating that the referenced data is not intended to be modified through this   */
/*                       alias or those depending on it                                                               */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:4342)    : An expression of 'essentially unsigned' type (%1s) is being cast to enum type '%2s'.         */
/* Rule                : CWE Rule CWE-704,  MISRA C:2012 Rule-10.5                                                    */
/* JV-01 Justification : It is assigned to a variable with no conflict in the data.                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:4395)    : A composite expression of 'essentially floating' type (%1s) is being cast to a different     */
/*                       type category, '%2s'.              .                                                         */
/* Rule                : MISRA C:2012 Rule-10.8, CWE Rule CWE-136                                                     */
/* JV-01 Justification : This calculation is handled with care to preserve the accuracy of the result. It is confirmed*/
/*                       that there is no problem with this calculation.                                              */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:1298)    : An integer constant of 'essentially signed' type is being converted to floating type on      */
/*                       assignment.                                                                                  */
/* Rule                : MISRA C:2012 Rule-10.3, CERT-C, 2016 Rule INT02, FLP36, CWE Rule CWE-136, CWE-192            */
/* JV-01 Justification : It is assigned to a variable with no conflict in the data.                                   */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:1800)    : The left-hand operand (essential type: 'unsigned long long') will be implicitly converted to */
/*                       a floating type, 'double', in this arithmetic operation.                                     */
/* Rule                : MISRA C:2012 Rule-10.4, CERT-C, 2016 Rule INT02, FLP36, CWE Rule CWE-136, CWE-192            */
/* JV-01 Justification : It converted the variable to integer as expectation and the converted variable have value no */
/*                       eceed the range of "usigned long long" type.                                                 */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (1:1710)    : Identifiers have the same matching pattern '%1s'.                                            */
/* Rule                : MISRA C:2012 Dir-4.5                                                                         */
/* JV-01 Justification : This is accepted, the identifiers have the same matching pattern, but they are re-defined as */
/*                       local variables in different functions.                                                      */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (3:3387)    : A full expression containing an increment (++) or decrement (--) operator should have no     */
/*                       potential side effects other than that caused by the increment or decrement operator.        */
/* Rule                : MISRA C:2012 Rule-13.3                                                                       */
/* JV-01 Justification : After reviewing coding, it is concluded that this implementation is okay as it is since      */
/*                       the memory used to access this volatile variable is user RAM, not a specific HW              */
/*                       register, so there is no worry about potential side effects in this case.                    */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2992)    : The value of this 'if' controlling expression is always 'false'.                             */
/* Rule                :  MISRA C:2012 Rule-14.3                                                                      */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'true'.     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (6:2996)    : The result of this logical operation is always 'false'.                                      */
/* Rule                : CWE Rule CWE-561,  MISRA C:2012 Rule-2.2                                                     */
/* JV-01 Justification : Depending on the configuration of user, there is case where the 'if' will return 'true'.     */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                                    Global Data                                                     **
***********************************************************************************************************************/

/***********************************************************************************************************************
**                                                Function Definitions                                                **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TxRamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_AXIBMI_Init(CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_MHD_Init(CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RMAC_Init(CONST(uint32, AUTOMATIC) LulCtrlIdx);
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_TxRamInit_DescConfig(
  Eth_ExtDescType * const LulDescChain,
  const uint32 Luldptr);
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RxDescLearning(
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs,
  CONST(uint32, AUTOMATIC) LulEntryNum,
  CONST(uint32, AUTOMATIC) LulChainAddr);

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TasAdminLearning(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulCtrlAddress,
  CONSTP2CONST(Eth_TASEntryType, AUTOMATIC, ETH_APPL_DATA) LpCtrlConfig);
#endif

STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RxCallEthIf(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulQueueIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpFrame,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx);

STATIC FUNC(boolean, ETH_PRIVATE_CODE) Eth_IsRxFrameValid(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulFrameAddr);

#if (ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_ETND_SGMII_SUPPORT == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_WaitNanoSecEtnd(CONST(uint32, AUTOMATIC) LulNanosec);

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_SGMIIInit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(Eth_OptionType, AUTOMATIC) LenBypassMode);
#endif
#endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TxRxDescConfig(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_TsDescConfig(CONST(uint32, AUTOMATIC) LulCtrlIdx);
#endif
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwDisableController
**
** Service ID            : N/A
**
** Description           : Changes the state of an ETND controller as DOWN
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaTxBufferMgrTable
**                         Eth_GaaTxBufferTotal, Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_MHD_ModeSetting, Eth_ETND_ReleaseTxBuffer
**
** Registers Used        : TCC
**
** Reference ID          : ETH_DUD_ACT_2002
** Reference ID          : ETH_DUD_ACT_2002_GBL001, ETH_DUD_ACT_2002_GBL002
** Reference ID          : ETH_DUD_ACT_2002_GBL003, ETH_DUD_ACT_2002_GBL004
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwDisableController(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA) LpTxDescChain;                                                       /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpRxDescChain;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulCntI;
  uint32 LulCntJ;
  Std_ReturnType LucResult;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  /* Set to CONFIG mode to enable MDIO communication.  */
  LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
  LucResult |= Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_CONFIG_MODE);

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* TAS algorithm stop */
  if (ETH_ENABLE == LpHwUnitConfig->stTASConfig.enTasEnable)
  {
    /* TAS disable */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCC = ETH_ETND_TCC_DISABLE;
  }
  #endif

  /* Reset all Buffer Locks or pending Transmit */
  if (E_OK == LucResult)
  {
    for (LulCntI = (uint32)ETH_ZERO; LulCntI < Eth_GaaTxBufferTotal[LulCtrlIdx]; LulCntI++)
    {
      if (NULL_PTR != Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulCntI].pBufferHdr)
      {
        Eth_ETND_ReleaseTxBuffer(LulCtrlIdx, Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulCntI].pBufferHdr->ulbufIdx);
      } /* else: No action required */
    }

    for (LulCntI = (uint32)ETH_ZERO; LulCntI < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulCntI++)
    {
      /* Reset Tx descriptor */
      LpTxDescChain = (Eth_ExtDescType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulCntI];                    /* PRQA S 0316 # JV-01 */
      for (LulCntJ = (uint32)ETH_ZERO; LulCntJ < Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulCntI]; LulCntJ++)
      {
        /* Set frame empty type */
        LpTxDescChain->stHeader.ulDie     = (uint32)ETH_ZERO;
        LpTxDescChain->stHeader.ulAxie    = (uint32)ETH_ZERO;
        LpTxDescChain->stHeader.ulDse     = (uint32)ETH_ZERO;
        LpTxDescChain->stHeader.ulInfo0   = (uint32)ETH_ZERO;
        LpTxDescChain->stHeader.ulDs      = (uint32)ETH_ZERO;
        LpTxDescChain->ulDptr             = (uint32)ETH_ZERO;
        LpTxDescChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
        LpTxDescChain->ulInfo1[ETH_ONE]   = (uint32)ETH_ZERO;
        LpTxDescChain->stHeader.ulDt      = (uint32)ETH_DESC_FEMPTY;

        /* Next descriptor */
        LpTxDescChain++;
        while ((LpTxDescChain->stHeader.ulDt == ETH_DESC_LEMPTY) || (LpTxDescChain->stHeader.ulDt == ETH_DESC_LINK))
        {
          LpTxDescChain->stHeader.ulDt = (uint32)ETH_DESC_LINK;
          LpTxDescChain = (P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA))LpTxDescChain->ulDptr;                      /* PRQA S 0306, 3432 # JV-01, JV-01 */
        }
      }

      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulCntI] = LpTxDescChain;

      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulCntI] = (uint32)ETH_ZERO;
    }

    for (LulCntI = (uint32)ETH_ZERO; LulCntI < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue; LulCntI++)
    {
      /* Reset Rx descriptor */
      LpRxDescChain = (Eth_ExtDescWithTsType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulCntI];              /* PRQA S 0316 # JV-01 */
      while (LpRxDescChain->stHeader.ulDt != ETH_DESC_FEMPTY)
      {
        LpRxDescChain->stHeader.ulDie     = (uint32)ETH_RX_DESC_DIE_ENABLE;
        LpRxDescChain->stHeader.ulAxie    = (uint32)ETH_ZERO;
        LpRxDescChain->stHeader.ulDse     = (uint32)ETH_ZERO;
        LpRxDescChain->stHeader.ulInfo0   = (uint32)ETH_ZERO;
        LpRxDescChain->stHeader.ulDs      = LpHwUnitConfig->stRxConfig.ulMaxFrameSize;
        LpRxDescChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
        LpRxDescChain->ulInfo1[ETH_ONE]   = (uint32)ETH_ZERO;
        LpRxDescChain->ulTsns             = (uint32)ETH_ZERO;
        LpRxDescChain->ulTss              = (uint32)ETH_ZERO;
        LpRxDescChain->stHeader.ulDt      = (uint32)ETH_DESC_FEMPTY;

        /* Next descriptor */
        LpRxDescChain++;
        while ((LpRxDescChain->stHeader.ulDt == ETH_DESC_LEMPTY) || (LpRxDescChain->stHeader.ulDt == ETH_DESC_LINK))
        {
          LpRxDescChain->stHeader.ulDt = (uint32)ETH_DESC_LINK;
          LpRxDescChain = (P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA))LpRxDescChain->ulDptr;                /* PRQA S 0306, 3432 # JV-01, JV-01 */
        }
      }
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulCntI] = LpRxDescChain;

      #if(ETH_DEVICE_NAME == ETH_U5X)
      /* Reset the Buffer warning level counter */
      Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LulCntI] = ETH_ZERO;
      #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
    }
  }
  else
  {
    Eth_GaaCtrlStat[LulCtrlIdx].enMode = ETH_MODE_ACTIVE;
  }

  return LucResult;
}

#if(ETH_DEVICE_NAME == ETH_U5X)
/***********************************************************************************************************************
** Function Name         : Eth_HwPreCommonInit (ETND)
**
** Service ID            : N/A
**
** Description           : Initialize the common parts of ETND HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs
**
** Function(s) invoked   : None
**
** Registers Used        : GTIVt, TME, GTOVt0, GTOVt1, GTOVt2
**
** Reference ID          : ETH_DUD_ACT_2003
** Reference ID          : ETH_DUD_ACT_2003_GBL001,
** Reference ID          : ETH_DUD_ACT_2003_REG001, ETH_DUD_ACT_2003_REG002, ETH_DUD_ACT_2003_REG003
** Reference ID          : ETH_DUD_ACT_2003_REG004, ETH_DUD_ACT_2003_REG005
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwPreCommonInit(void)
{
  /*-------------------------------------------------------------------------*/
  /* gPTP timer initialization for TSNES                                     */
  /*-------------------------------------------------------------------------*/
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* Assigning the configured timer increment value to the GPTP timer GTIVt (t = 0 to PTPTN-1) */
  Eth_GstETND_Regs.pGPTMA->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGTIVt = (uint32)ETH_GPTP_SET_GTIV(ETH_PERI_CLOCK_HZ);     /* PRQA S 3432 # JV-01 */

  /* GPTP Timer Enable */
  Eth_GstETND_Regs.pGPTMA->ulTME = ETH_GPTP_TIMER_DOMAIN_ENABLE;

  /* Set the nanosecond part of the GPTP timer GTOVt0 (t = 0 to PTPTN-1) */
  Eth_GstETND_Regs.pGPTMA->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGTOVt0 = (uint32)ETH_ZERO;

  /* Set the lower 32 bit of second part of the GPTP timer GTOVt1 (t = 0 to PTPTN-1) */
  Eth_GstETND_Regs.pGPTMA->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGTOVt1 = (uint32)ETH_ZERO;

  /* Set the upper 16 bit of second part of the GPTP timer GTOVt1 (t = 0 to PTPTN-1) */
  Eth_GstETND_Regs.pGPTMA->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGTOVt2 = (uint32)ETH_ZERO;
  #endif

  return E_OK;
}
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

#if(ETH_DEVICE_NAME == ETH_U5X)
/***********************************************************************************************************************
** Function Name         : Eth_HwPostCommonInit (ETND)
**
** Service ID            : N/A
**
** Description           : Initialize the common parts of ETND HwDeInit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2004
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_HwPostCommonInit(void)
{
  return E_OK;
}
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

/***********************************************************************************************************************
** Function Name         : Eth_TxRamInit_DescConfig
**
** Service ID            : N/A
**
** Description           : TxRam Description Configuration
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulDescChain : Original address of the descriptor
**                       : Luldptr: Address of allocated RAM with 2Kb
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2005
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_TxRamInit_DescConfig(Eth_ExtDescType * const LulDescChain, const uint32 Luldptr)
{
  LulDescChain->stHeader.ulDie    = (uint32)ETH_ZERO;
  LulDescChain->stHeader.ulAxie   = (uint32)ETH_ZERO;
  LulDescChain->stHeader.ulDse    = (uint32)ETH_ZERO;
  /* FCS needs to be already included in the tx frame since,
     without it, the frame size exceeds the maximum frame size (16KB).*/
  LulDescChain->stHeader.ulInfo0  = (uint32)ETH_ETND_DESC_FCS_INCLUDED;
  LulDescChain->stHeader.ulDs     = (uint32)ETH_ETND_2KB_FRAME_SIZE;
  LulDescChain->ulDptr            = (uint32)Luldptr;
  LulDescChain->ulInfo1[ETH_ZERO] = (uint32)ETH_ETND_INIT_FRAME_LENGTH;
  LulDescChain->ulInfo1[ETH_ONE]  = (uint32)ETH_ZERO;
}

/***********************************************************************************************************************
** Function Name         : Eth_TxRamInit
**
** Service ID            : N/A
**
** Description           : TxRAM initialization
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaTxRamBuffer, Eth_GaaTxRamDesc, Eth_GaaTxRamInitState
**
** Function(s) invoked   : Eth_MHD_ModeSetting, Eth_TxRamInit_DescConfig
**                         Eth_TxDescLearning, GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : AXIWC, AXIRC, TDPC[0], TFT, TFS[0], TFS[1], TFS[2], TFS[3]
**                         TGC1, TGC2, TMS[0], MCC, TRCR[0], TDISi, SWR, GIS
**
** Reference ID          : ETH_DUD_ACT_2006
** Reference ID          : ETH_DUD_ACT_2006_GBL001, ETH_DUD_ACT_2006_GBL002
** Reference ID          : ETH_DUD_ACT_2006_GBL003, ETH_DUD_ACT_2006_GBL004
** Reference ID          : ETH_DUD_ACT_2006_REG001, ETH_DUD_ACT_2006_REG002
** Reference ID          : ETH_DUD_ACT_2006_REG003, ETH_DUD_ACT_2006_REG004
** Reference ID          : ETH_DUD_ACT_2006_REG005, ETH_DUD_ACT_2006_REG006
** Reference ID          : ETH_DUD_ACT_2006_REG007, ETH_DUD_ACT_2006_REG008
** Reference ID          : ETH_DUD_ACT_2006_REG009, ETH_DUD_ACT_2006_REG010
** Reference ID          : ETH_DUD_ACT_2006_REG011, ETH_DUD_ACT_2006_REG012
** Reference ID          : ETH_DUD_ACT_2006_REG013, ETH_DUD_ACT_2006_REG014
** Reference ID          : ETH_DUD_ACT_2006_REG015, ETH_DUD_ACT_2006_REG016
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TxRamInit(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA) LpDescChain;                                                         /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA) LpDescChainTemp;                                                     /* PRQA S 3432, 3678 # JV-01, JV-01 */
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432, 3678 # JV-01, JV-01 */
  uint32 LulCntI;
  uint32 LulCntJ;
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  LpDescChain = NULL_PTR;
  LpDataPtr = NULL_PTR;                                                                                                 /* PRQA S 2982 # JV-01 */

  LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
  LucResult |= Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_CONFIG_MODE);
  if (E_OK == LucResult)
  {
    /* Configure AXIBMI */
    /* Set AXI Write and Read Outstanding Number */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulAXIWC = ETH_ETND_AXIWC_CONFIG;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulAXIRC = ETH_ETND_AXIRC_CONFIG;
    /* Set Tx Queue priority and Frame type */
    /* The supported Tx Queue is 0-7 */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTDPC[ETH_ZERO] = (uint32)ETH_ZERO;
    /* AXIBMI execute TFTP0-2 with p-frame statements and TFTP3-7 with e-frame statements */
    /* Since each statement operates as an independent core, it operates faster by enabling all statements */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTFT = (uint32)(uint32)ETH_ZERO;

    /* Configure MHD */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTFS[ETH_ZERO]   = ETH_ETND_INIT_TFS0_CONFIG;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTFS[ETH_ONE]    = (uint32)ETH_ZERO;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTFS[ETH_TWO]    = (uint32)ETH_ZERO;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTFS[ETH_THREE]  = (uint32)ETH_ZERO;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTGC1 = ETH_ETND_TGC1_CONFIG;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTGC2 = (uint32)ETH_ZERO;
    /* This register must be configured in other to send a 16KB frame */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTMS[ETH_ZERO] = ETH_ETND_INIT_TMS_CONFIG;

    #if(ETH_DEVICE_NAME == ETH_U5X)
    /* Configure RMAC.MCC register to prevent the frame to come out of RMAC */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMCC &= ~ETH_ETND_MCC_TXE_MASK;
    /* PHY Interface configuration */
    LenEthPHYInterface = Eth_GpEthConfigPtr[LulCtrlIdx].enEthPHYInterface;

    if ((ETH_MII == LenEthPHYInterface) || (ETH_RMII == LenEthPHYInterface))
    {
      LulRegVal = ETH_ETND_MPIC_MII_RMII;
    }
    else
    {
      LulRegVal = ETH_ETND_MPIC_GMII_SGMII;
    }

    LenEthSpeed = Eth_GpEthConfigPtr[LulCtrlIdx].enEthSpeed;
    if (ETH_MAC_LAYER_SPEED_10M == LenEthSpeed)
    {       
      LulRegVal |= ETH_ETND_MPIC_10MB;                                                                                  /* PRQA S 2985 # JV-01 */
    }
    else if (ETH_MAC_LAYER_SPEED_100M == LenEthSpeed)
    {
      LulRegVal |= ETH_ETND_MPIC_100MB;
    }
    else if (ETH_MAC_LAYER_SPEED_2500M == LenEthSpeed)
    {
      LulRegVal |= ETH_ETND_MPIC_2500MB;
    }
    else
    {
      LulRegVal |= ETH_ETND_MPIC_1GB;
    }

    Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMPIC = (uint32)LulRegVal;
    #endif

    /* Allocate memory for 2KB frame size (which will be used 16 times) */
    LpDataPtr = &Eth_GaaTxRamBuffer[ETH_ZERO];

    /* Allocate memory for 17 descriptors used to transmit 16KB frame */
    LpDescChain = &Eth_GaaTxRamDesc[ETH_ZERO];
  } /* else: No action required */

  if ((NULL_PTR != LpDescChain) && (NULL_PTR != LpDataPtr))                                                             /* PRQA S 2995 # JV-01 */
  {
    /* Copy the original address of the descriptor */
    LpDescChainTemp = LpDescChain;

    /* Configure descriptors used for transmission */
    for (LulCntI = (uint32)ETH_ZERO; LulCntI < ETH_ETND_INIT_DESC_LOOP_NUM; LulCntI++)
    {
      /* Set start frame type */
      Eth_TxRamInit_DescConfig(LpDescChain, (uint32)LpDataPtr);                                                         /* PRQA S 0306 # JV-01 */
      LpDescChain->stHeader.ulDt = (uint32)ETH_DESC_FSTART;
      /* Next data descriptor */
      LpDescChain++;

      /* Set middle frame type */
      for (LulCntJ = (uint32)ETH_ZERO; LulCntJ < ETH_ETND_MIDDLE_DESC_NUM; LulCntJ++)
      {
      Eth_TxRamInit_DescConfig(LpDescChain, (uint32)LpDataPtr);                                                         /* PRQA S 0306 # JV-01 */
      LpDescChain->stHeader.ulDt = (uint32)ETH_DESC_FMID;
        /* Next data descriptor */
        LpDescChain++;
      }

      /* Set end frame type */
      Eth_TxRamInit_DescConfig(LpDescChain, (uint32)LpDataPtr);                                                         /* PRQA S 0306 # JV-01 */
      LpDescChain->stHeader.ulDt = (uint32)ETH_DESC_FEND;
      /* Next data descriptor */
      LpDescChain++;
    }
    /* Set EOS frame type */
      LpDescChain->stHeader.ulDie   = (uint32)ETH_TX_DESC_DIE_ENABLE;
      LpDescChain->stHeader.ulAxie  = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulDse   = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulInfo0 = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulDs    = (uint32)ETH_ZERO;
      LpDescChain->ulDptr     = (uint32)LpDescChainTemp;                                                                /* PRQA S 0306 # JV-01 */
      LpDescChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
      LpDescChain->ulInfo1[ETH_ONE]   = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulDt      = (uint32)ETH_DESC_EOS;

    LucResult = Eth_TxDescLearning(&Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI,
                                                                   (uint32)ETH_ZERO, (uint32)LpDescChainTemp);          /* PRQA S 0306 # JV-01 */

    /* Transmission Request */
    if (E_OK == LucResult)
    {
      LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
      LucResult |= Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_OPERATION_MODE);
      if (E_OK == LucResult)
      {
        /* Transmit start request */
        Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTRCR[ETH_ZERO] = ETH_ETND_TRCR0_TRANSMIT_ENABLE;
        LulTickStart = (uint32)ETH_ZERO;
        LulTickElap = (uint32)ETH_ZERO;
        (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
        do
        {
          LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                      /* PRQA S 3383 # JV-01 */
        } while ((ETH_ETND_TDIS_0_MASK !=
                (Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.stTXDI[ETH_ZERO].ulTDISi & ETH_ETND_TDIS_0_MASK)) &&        /* PRQA S 3416 # JV-01 */
                (LulTickElap <= ETH_TIMEOUT_COUNT));
        if (ETH_TIMEOUT_COUNT < LulTickElap)
        {
          LucResult = E_NOT_OK;
        }
        else
        {
          /* Clear the interrupt status bit */
          Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.stTXDI[ETH_ZERO].ulTDISi = ETH_ETND_TDIS_0_MASK;
        }
      } /* else: No action required */
    } /* else: No action required */
  }
  else
  {
    LucResult = E_NOT_OK;
  }

  /* Software Reset */
  if (E_OK == LucResult)
  {
    LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
    if (E_OK == LucResult)
    {
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulSWR = ETH_ETND_SOFTWARE_RESET_ENABLE;

      LulTickStart = (uint32)ETH_ZERO;
      LulTickElap = (uint32)ETH_ZERO;
      (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
      do
      {
        LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                        /* PRQA S 3383 # JV-01 */
      } while ((ETH_ETND_GIS_SWRCF_MASK != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulGIS & ETH_ETND_GIS_SWRCF_MASK)) &&/* PRQA S 3416 # JV-01 */
        (LulTickElap <= ETH_TIMEOUT_COUNT));

      if (ETH_TIMEOUT_COUNT < LulTickElap)
      {
        LucResult = E_NOT_OK;
      }
      else
      {
        /* Clear SoftWare Reset Completion Flag */
        Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulGIS = ETH_ETND_GIS_SWRCF_MASK;

        Eth_GaaTxRamInitState[LulCtrlIdx] = ETH_TRUE;
      }
    } /* else: No action required */
  } /* else: No action required */

  return LucResult;
}

#if defined(ETH_HW_DEINIT)
#if (ETH_DEINIT_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwDeInit
**
** Service ID            : N/A
**
** Description           : Perform SW Reset for the ETND controller
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         ForceReset     : Indicate the reset flow to follow (normal/emergency)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : GIS, SWR
**
** Reference ID          : ETH_DUD_ACT_2007
** Reference ID          : ETH_DUD_ACT_2007_GBL001, ETH_DUD_ACT_2007_GBL002
** Reference ID          : ETH_DUD_ACT_2007_REG001, ETH_DUD_ACT_2007_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwDeInit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(boolean, AUTOMATIC) ForceReset)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  (void)ForceReset;

  LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
  if (E_OK == LucResult)
  {
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulSWR = ETH_ETND_SOFTWARE_RESET_ENABLE;
    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
    } while ((ETH_ETND_GIS_SWRCF_MASK != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulGIS & ETH_ETND_GIS_SWRCF_MASK)) &&  /* PRQA S 3416 # JV-01 */
      (LulTickElap <= ETH_TIMEOUT_COUNT));
    if (ETH_TIMEOUT_COUNT < LulTickElap)
    {
      LucResult = E_NOT_OK;
    }
    else
    {
      /* Clear SoftWare Reset Completion Flag */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulGIS = ETH_ETND_GIS_SWRCF_MASK;

      /* Set controller state as DOWN */
      Eth_GaaCtrlStat[LulCtrlIdx].enMode = ETH_MODE_DOWN;
    }
  } /* else: No action required */

  return LucResult;
}
#endif /* (ETH_DEINIT_API == STD_ON) */
#endif /* defined(ETH_HW_DEINIT) */

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwInit
**
** Service ID            : N/A
**
** Description           : Initialize a ETND HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaCtrlStat
**                         Eth_GaaTxRamInitState, Eth_GpEthConfigPtr, Eth_GaaTSNES_GPTPRegs
**
** Function(s) invoked   : Eth_ETND_RamInit, Eth_TxRamInit, Eth_AXIBMI_Init
**                         Eth_MHD_Init, Eth_RMAC_Init, Eth_SGMIIInit
**
** Registers Used        : NVIC
**
** Reference ID          : ETH_DUD_ACT_2008
** Reference ID          : ETH_DUD_ACT_2008_GBL001, ETH_DUD_ACT_2008_GBL002
** Reference ID          : ETH_DUD_ACT_2008_GBL003, ETH_DUD_ACT_2008_GBL004
** Reference ID          : ETH_DUD_ACT_2008_GBL005
** Reference ID          : ETH_DUD_ACT_2008_REG001, ETH_DUD_ACT_2008_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwInit(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  Std_ReturnType LucResult;

  #if(ETH_DEVICE_NAME == ETH_U5X)
  #if (ETH_ETND_SGMII_SUPPORT == STD_ON)
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316 # JV-01 */
  #endif
  #endif

  LucResult = E_OK;

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].ulTsDescTail = (uint32)ETH_ZERO;
  #endif

  /* Initialize Statistics */
  #if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsBroadcastPkts = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOctets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsCrcAlignErrors = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsUndersizePkts = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOversizePkts = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts64Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts65to127Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts128to255Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts256to511Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts512to1023Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts1024to1518Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxUnicastFrames = (uint32)ETH_ZERO;
  #endif
  #if (ETH_GET_TX_STATS_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNumberOfOctets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNUcastPkts = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxUniCastPkts = (uint32)ETH_ZERO;
  #endif
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.DropPktCrc = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.UndersizePkt = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.OversizePkt = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.AlgnmtErr = (uint32)ETH_ZERO;
  #endif

  #if(ETH_DEVICE_NAME == ETH_U5X)
  #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
  Eth_GaaCtrlStat[LucCtrlIdx].stMeasurementData.ulDropInsuffTxBuffCnt = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LucCtrlIdx].stMeasurementData.ulWarnFullRxBuffCnt = (uint32)ETH_ZERO;
  #endif /* #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON) */
  #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

  Eth_ETND_RamInit(LulCtrlIdx);

  if (ETH_TRUE != Eth_GaaTxRamInitState[LulCtrlIdx])
  {
    LucResult = Eth_TxRamInit(LulCtrlIdx);
  } /* else: No action required */

  if (E_OK == LucResult)
  {
    /*-------------------------------------------------------------------------*/
    /* Initialization for TSNES                                                */
    /*-------------------------------------------------------------------------*/
    LucResult = Eth_AXIBMI_Init(LulCtrlIdx);
    if (E_OK == LucResult)
    {
      Eth_MHD_Init(LulCtrlIdx);
      Eth_RMAC_Init(LulCtrlIdx);

      #if(ETH_DEVICE_NAME == ETH_X5X)
      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTIVCt =
                                                      ETH_GPTP_PTPTIVC_BIT0_TO_BIT26(ETH_PERI_CLOCK_HZ_TSNES) |         /* PRQA S 3469 # JV-01 */
                                                        ETH_GPTP_PTPTIVC_BIT27_TO_BIT31(ETH_PERI_CLOCK_HZ_TSNES);       /* PRQA S 3469 # JV-01 */
      Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->ulPTPTMEC = ETH_GPTP_TIMER_DOMAIN_ENABLE << ETH_GPTP_TIMER_DOMAIN;
      #endif
      #endif /* #if(ETH_DEVICE_NAME == ETH_X5X) */

      #if(ETH_DEVICE_NAME == ETH_U5X)
      #if (ETH_ETND_SGMII_SUPPORT == STD_ON)
      if (ETH_SGMII == Eth_GpEthConfigPtr[LulCtrlIdx].enEthPHYInterface)                                                /* PRQA S 3416 # JV-01 */
      {
        LucResult = Eth_SGMIIInit(LulCtrlIdx, LpHwUnitConfig->enBypassMode);
      } /* else: No action required */
      #endif
      #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
    } /* else: No action required */
  } /* else: No action required */

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_AXIBMI_Init
**
** Service ID            : NA
**
** Description           : Initialization process for AXIBMI
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GstETND_Regs, Eth_GpEthConfigPtr
**
** Function(s) invoked   : GetCounterValue, Eth_ETND_GetElapsedTimeValue, Eth_MHD_ModeSetting
**                         Eth_Util_RamSetCircularAddr, Eth_TsDescConfig, Eth_TxRxDescConfig
**
** Registers Used        : RR, AXIWC, AXIRC, TDPC, TFT, EIE0, TMS
**                         TSDIE, TDIEi, RDIEi
**
** Reference ID          : ETH_DUD_ACT_2009
** Reference ID          : ETH_DUD_ACT_2009_GBL001, ETH_DUD_ACT_2009_GBL002, ETH_DUD_ACT_2009_GBL003
** Reference ID          : ETH_DUD_ACT_2009_REG001, ETH_DUD_ACT_2009_REG002, ETH_DUD_ACT_2009_REG003
** Reference ID          : ETH_DUD_ACT_2009_REG004, ETH_DUD_ACT_2009_REG005, ETH_DUD_ACT_2009_REG006
** Reference ID          : ETH_DUD_ACT_2009_REG007, ETH_DUD_ACT_2009_REG008, ETH_DUD_ACT_2009_REG009
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_AXIBMI_Init(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  TickType LulTickStart;
  TickType LulTickElap;
  uint32 LulQPriorityVal;
  uint32 LulFrameTypeVal;
  uint32 LulCnt;
  Std_ReturnType LucResult;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Configure AXIBMI */
  LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
  LucResult |= Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_CONFIG_MODE);
  if (E_OK == LucResult)
  {
    /* Clear RAM Reset Register Bits */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulRR = ETH_ETND_RATRR_RESET | ETH_ETND_TATRR_RESET;

    /* RAM Reset Waiting */
    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
    } while (((ETH_ETND_RATRR_RESET | ETH_ETND_TATRR_RESET) !=
                  Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulRR) && (LulTickElap <= ETH_TIMEOUT_COUNT));              /* PRQA S 3416 # JV-01 */

    if (ETH_TIMEOUT_COUNT < LulTickElap)
    {
      LucResult = E_NOT_OK;
    } /* else: No action required */
  } /* else: No action required */

  if (E_OK == LucResult)
  {
    /* Set AXI Write and Read Outstanding Number */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulAXIWC = ETH_ETND_AXIWC_CONFIG;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulAXIRC = ETH_ETND_AXIRC_CONFIG;

    /* Set Tx Queue priority and Frame type */
    LulQPriorityVal = (uint32)ETH_ZERO;
    LulFrameTypeVal = (uint32)ETH_ZERO;
    for (LulCnt = (uint32)ETH_ZERO; LulCnt < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulCnt++)
    {
      LulQPriorityVal |= LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].ulQueueId << ((uint32)ETH_FOUR * LulCnt); /* PRQA S 3383 # JV-01 */
      LulFrameTypeVal |= (uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].enFrameType << LulCnt;
    }

    /* The supported Tx Queue is 0-7 */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTDPC[ETH_ZERO] = LulQPriorityVal;
    /* AXIBMI execute TFTP0-2 with p-frame statements and TFTP3-7 with e-frame statements */
    /* Since each statement operates as an independent core, it operates faster by enabling all statements */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTFT = LulFrameTypeVal;

    /* Tx/Rx descriptor chain setting */
    LucResult = Eth_TxRxDescConfig(LulCtrlIdx);

    #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
    /* TS descriptor chain setting */
    Eth_TsDescConfig(LulCtrlIdx);

    /* TS Descriptor Data Interrupt */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTSDIE = ETH_ETND_TSDIE_CONFIG;
    #endif

    /* Set AXIBMI Error Interrupt */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulEIE0 = ETH_ETND_EIE0_CONFIG;

    /* TX Descriptor Data Interrupt */
    if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enTxInterruptMode)                                                 /* PRQA S 3416 # JV-01 */
    {
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.stTXDI[ETH_ZERO].ulTDIEi = LpHwUnitConfig->stQueueConfig.ulTxIntConfig;
    } /* else: No action required */

    if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enRxInterruptMode)                                                 /* PRQA S 3416 # JV-01 */
    {
      /* RX Descriptor Data Interrupt */
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.stRXDI[ETH_ZERO].ulRDIEi = LpHwUnitConfig->stQueueConfig.ulRxIntConfig;

      /* RX Descriptor Full Error Interrupt */
      #if(ETH_DEVICE_NAME == ETH_X5X)
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.stRXDFEI[ETH_ZERO].ulRFEIEi =
                                                                        LpHwUnitConfig->stQueueConfig.ulRxIntConfig;
      #endif
    } /* else: No action required */
  } /* else: No action required */

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_MHD_Init
**
** Service ID            : NA
**
** Description           : Initialization process of MHD, TAS, CBS Function
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : TCIE, TIE2, RIE
**                         TMS, TFS, TGC1, TGC2
**                         TCR1, TCR2, TCR3, TCR4, RGC
**                         RDFCR, RCFCR, TPTPC, TTML
**                         TTJ, CACC, CAIV, CAUL, CCS
**
** Reference ID          : ETH_DUD_ACT_2010
** Reference ID          : ETH_DUD_ACT_2010_GBL001, ETH_DUD_ACT_2010_GBL002
** Reference ID          : ETH_DUD_ACT_2010_REG001, ETH_DUD_ACT_2010_REG002, ETH_DUD_ACT_2010_REG003
** Reference ID          : ETH_DUD_ACT_2010_REG004, ETH_DUD_ACT_2010_REG005, ETH_DUD_ACT_2010_REG006
** Reference ID          : ETH_DUD_ACT_2010_REG007, ETH_DUD_ACT_2010_REG008, ETH_DUD_ACT_2010_REG009
** Reference ID          : ETH_DUD_ACT_2010_REG010, ETH_DUD_ACT_2010_REG011, ETH_DUD_ACT_2010_REG012
** Reference ID          : ETH_DUD_ACT_2010_REG013, ETH_DUD_ACT_2010_REG014, ETH_DUD_ACT_2010_REG015
** Reference ID          : ETH_DUD_ACT_2010_REG016, ETH_DUD_ACT_2010_REG017, ETH_DUD_ACT_2010_REG018
** Reference ID          : ETH_DUD_ACT_2010_REG019, ETH_DUD_ACT_2010_REG020, ETH_DUD_ACT_2010_REG021
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_MHD_Init(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulCnt;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Configure MHD */
  /* Interrupt settings */
  /* TAS CBS Interrupt Enable register config */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCIE = ETH_ETND_TCIE_CONFIG;

  /* Transmission Interrupt Enable register config */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTIE2 = ETH_ETND_TIE2_CONFIG;

  /* Reception Interrupt Enable register config */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRIE  = ETH_ETND_RIE_CONFIG;

  for (LulCnt = (uint32)ETH_ZERO; LulCnt < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulCnt++)
  {
    /* This frame size does not include FCS size */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTMS[LulCnt] =
      LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].ulMaxFrameSize;
  }

  /* Tx General Setting */
  for (LulCnt = (uint32)ETH_ZERO; LulCnt < ETH_ETND_MAX_TFS; LulCnt++)
  {
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTFS[LulCnt] = ETH_ETND_TFS_CONFIG;
  }
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTGC1 = ETH_ETND_TGC1_CONFIG;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTGC2 = ((uint32)LpHwUnitConfig->enTxFragment << (uint32)ETH_SIXTEEN) |      /* PRQA S 0404 # JV-01 */
                                                   Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTFT;

  /* Tx data fifo warning level */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCR1 = ETH_ETND_TCR1_CONFIG;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCR2 = ETH_ETND_TCR2_CONFIG;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCR3 = ETH_ETND_TCR3_CONFIG;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCR4 = ETH_ETND_TCR4_CONFIG;

  /* Rx General Setting */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRGC  = ETH_ETND_RGC_CONFIG;

  /* Rx data fifo warning level */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRDFCR = ETH_ETND_RDFCR_CONFIG;
  /* Rx Ctrl fifo warning level */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulRCFCR = ETH_ETND_RCFCR_CONFIG;

  /* TAS configuration */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTPTPC = ETH_GPTP_TIMER_DOMAIN;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTTML = LpHwUnitConfig->stTASConfig.ulTxMiniLatency;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTTJ = LpHwUnitConfig->stTASConfig.ulTxJitter;

  /* CBS configuration */
  for (LulCnt = (uint32)ETH_ZERO; LulCnt < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulCnt++)
  {
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulCACC |=
                                (uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.enCE << LulCnt;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulCAIV[LulCnt] =
      LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.ulCIV;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulCAUL[LulCnt] =
      LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.ulCUL;
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulCCS |=
                                (uint32)LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCnt].stCBSConfig.enCE << LulCnt;
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_RMAC_Init
**
** Service ID            : NA
**
** Description           : Initialization process of RMAC System
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GpEthConfigPtr, Eth_GstETND_Regs, Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : MRMAC0, MRMAC1, MLBC, MTFFC, MTPFC, MTATC, MRGC
**                         MRFSCE, MRFSCP, MTRC, MRSCE, MRSCP, MRAFC, MPIC
**
** Reference ID          : ETH_DUD_ACT_2011
** Reference ID          : ETH_DUD_ACT_2011_GBL001, ETH_DUD_ACT_2011_GBL002
** Reference ID          : ETH_DUD_ACT_2011_GBL003, ETH_DUD_ACT_2011_GBL004
** Reference ID          : ETH_DUD_ACT_2011_REG001, ETH_DUD_ACT_2011_REG002
** Reference ID          : ETH_DUD_ACT_2011_REG003, ETH_DUD_ACT_2011_REG004
** Reference ID          : ETH_DUD_ACT_2011_REG005, ETH_DUD_ACT_2011_REG006
** Reference ID          : ETH_DUD_ACT_2011_REG007, ETH_DUD_ACT_2011_REG008
** Reference ID          : ETH_DUD_ACT_2011_REG009, ETH_DUD_ACT_2011_REG010
** Reference ID          : ETH_DUD_ACT_2011_REG011, ETH_DUD_ACT_2011_REG012
** Reference ID          : ETH_DUD_ACT_2011_REG013, ETH_DUD_ACT_2011_REG014
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RMAC_Init(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulRegVal;
  Eth_MediaInterfaceType LenEthPHYInterface;
  Eth_MacLayerSpeedType LenEthSpeed;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  /* RMAC System configuration */
  /* Set MAC address */
  /* When MAC address is 01-23-45-67-89-AB, set 0x0123 */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRMAC0 =
    Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 >> (uint32)ETH_SIXTEEN;
  /* When MAC address is 01-23-45-67-89-AB, set 0x456789AB */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRMAC1 =
    (Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 << (uint32)ETH_SIXTEEN) | Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulL16;
  /* Config MAC Loopback mode */
  if (ETH_ENABLE == Eth_GpEthConfigPtr[LulCtrlIdx].enInternalLoopBackMode)                                              /* PRQA S 3416 # JV-01 */
  {
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMLBC = ETH_ETND_MLBC_CONFIG;
  } /* else: No action required */

  /* Set Tx function */
  #if(ETH_DEVICE_NAME == ETH_U5X)
  /* Set the IPG/IFG value */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMTFFC = LpHwUnitConfig->ulInterPacketGap;

  /* Set the pauseframe configuration value */
  if (ETH_ENABLE == LpHwUnitConfig->stMACConfig.enPauseFrame)
  {
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMTPFC =
      (uint32)(((uint32)LpHwUnitConfig->stMACConfig.enPauseTimeZero << (uint32)ETH_TWENTLY_FOUR) |
      (LpHwUnitConfig->stMACConfig.ulRetransmissionTime << (uint32)ETH_SIXTEEN) |
        LpHwUnitConfig->stMACConfig.ulPauseTime);
  } /* else: No action required */
  /* Do not use automatic timestamp */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMTATC[ETH_GPTP_TIMER_DOMAIN] = ETH_ETND_MTATC_CONFIG;

  /* Set Rx function */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRGC =
    (uint32)(((uint32)LpHwUnitConfig->stMACConfig.enPauseTimeZero << (uint32)ETH_TWO) |
    ((uint32)LpHwUnitConfig->stMACConfig.enPauseFrame << (uint32)ETH_ONE));
  #else
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMTFFC = (uint32)ETH_ZERO;
  #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRFSCE = LpHwUnitConfig->stRxConfig.ulMaxFrameSize;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRFSCP = LpHwUnitConfig->stRxConfig.ulMaxFrameSize;
  /* Timestamp capture settings for Rx descriptor */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMTRC = ETH_ETND_MTRC_CONFIG;

  /* Set Address Filtering function */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRSCE =
    (LpHwUnitConfig->stRxConfig.ulBcastThreshold << (uint32)ETH_SIXTEEN) | LpHwUnitConfig->stRxConfig.ulMcastThreshold;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRSCP =
    (LpHwUnitConfig->stRxConfig.ulBcastThreshold << (uint32)ETH_SIXTEEN) | LpHwUnitConfig->stRxConfig.ulMcastThreshold;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMRAFC =
    ETH_ETND_MRAFC_CONFIG | (uint32)(((uint32)LpHwUnitConfig->stRxConfig.enBcastStormFilter << (uint32)ETH_TWENTLY) |
                            ((uint32)LpHwUnitConfig->stRxConfig.enMcastStormFilter << (uint32)ETH_NINETEEN) |
                            ((uint32)LpHwUnitConfig->stRxConfig.enBcastStormFilter << (uint32)ETH_FOUR) |
                            ((uint32)LpHwUnitConfig->stRxConfig.enMcastStormFilter << (uint32)ETH_THREE));

  /* PSFP configuration */

  /* PTP Filtering function is not supported */

  /* PHY Interface configuration */
  LenEthPHYInterface = Eth_GpEthConfigPtr[LulCtrlIdx].enEthPHYInterface;
  if ((ETH_MII == LenEthPHYInterface) || (ETH_RMII == LenEthPHYInterface))
  {
    LulRegVal = ETH_ETND_MPIC_MII_RMII;
  }
  else
  {
    LulRegVal = ETH_ETND_MPIC_GMII_SGMII;
  }

  LenEthSpeed = Eth_GpEthConfigPtr[LulCtrlIdx].enEthSpeed;
  if (ETH_MAC_LAYER_SPEED_10M == LenEthSpeed)
  {
    LulRegVal |= ETH_ETND_MPIC_10MB;                                                                                    /* PRQA S 2985 # JV-01 */
  }
  else if (ETH_MAC_LAYER_SPEED_100M == LenEthSpeed)
  {
    LulRegVal |= ETH_ETND_MPIC_100MB;
  }
  else if (ETH_MAC_LAYER_SPEED_2500M == LenEthSpeed)
  {
    LulRegVal |= ETH_ETND_MPIC_2500MB;
  }
  else
  {
    LulRegVal |= ETH_ETND_MPIC_1GB;
  }

  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMPIC = (uint32)LulRegVal;                                        /* PRQA S 0404 # JV-01 */
  #if(ETH_DEVICE_NAME == ETH_U5X)
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC.ulMPIC |=
          (uint32)(((uint32)LpHwUnitConfig->stPHYConfig.enPSMCaptureTime << (uint32)ETH_TWENTLY_EIGHT) |
          ((uint32)LpHwUnitConfig->stPHYConfig.enPSMHoldTime << (uint32)ETH_TWENTLY_FOUR) |
          (LpHwUnitConfig->stPHYConfig.ulPSMClockSelection   << (uint32)ETH_SIXTEEN));
  #endif
}

/***********************************************************************************************************************
** Function Name         : Eth_MHD_ModeSetting
**
** Service ID            : NA
**
** Description           : Set the mode of MHD
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                         LulMode : MHD Mode
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs
**
** Function(s) invoked   : GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : OCR, OSR
**
** Reference ID          : ETH_DUD_ACT_2012
** Reference ID          : ETH_DUD_ACT_2012_GBL001,
** Reference ID          : ETH_DUD_ACT_2012_REG001,ETH_DUD_ACT_2012_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_MHD_ModeSetting(                                                             /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulMode)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  /* Switch to CONFIG mode (OSR.OPS bit) */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulOCR = LulMode;

  /* Wait while CONFIG mode is achieved */
  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
  } while ((Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulOSR != ((uint32)ETH_ONE << LulMode)) &&                           /* PRQA S 3416 # JV-01 */
           (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}


/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwEnableController
**
** Service ID            : N/A
**
** Description           : Changes the state of an ETND controller as ACTIVE
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**                         E_NOT_OK : Failure
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GpCtrlConfigPtr, Eth_GaaCtrlStat, Eth_GaaTSNES_GPTPRegs
**
** Function(s) invoked   : Eth_TasAdminLearning, Eth_MHD_ModeSetting
**                         GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : MRMAC0, MRMAC1, MRAFC
**                         TAEN, TASFE, TACST0
**                         TACST1, TACST2, TCC, MLVC
**
** Reference ID          : ETH_DUD_ACT_2013
** Reference ID          : ETH_DUD_ACT_2013_GBL001, ETH_DUD_ACT_2013_GBL002, ETH_DUD_ACT_2013_GBL003
** Reference ID          : ETH_DUD_ACT_2013_GBL004
** Reference ID          : ETH_DUD_ACT_2013_REG001, ETH_DUD_ACT_2013_REG002, ETH_DUD_ACT_2013_REG003
** Reference ID          : ETH_DUD_ACT_2013_REG004, ETH_DUD_ACT_2013_REG005, ETH_DUD_ACT_2013_REG006
** Reference ID          : ETH_DUD_ACT_2013_REG007, ETH_DUD_ACT_2013_REG008, ETH_DUD_ACT_2013_REG009
** Reference ID          : ETH_DUD_ACT_2013_REG010, ETH_DUD_ACT_2013_REG011, ETH_DUD_ACT_2013_REG012
** Reference ID          : ETH_DUD_ACT_2013_REG013
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwEnableController(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  CONSTP2VAR(volatile Eth_ETND_RMACRegType, AUTOMATIC, REGSPACE) LpRmacRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC;
  Std_ReturnType LucResult;

  #if (ETH_DEVICE_NAME == ETH_U5X)
  #if (ETH_PREEMPTION_SUPPORT == STD_ON)
  TickType LulTickStart;
  TickType LulTickElap;
  #endif
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  CONSTP2CONST(volatile Eth_ETND_GPTMARegType, AUTOMATIC, REGSPACE) LpGptmaRegs = Eth_GstETND_Regs.pGPTMA;
  #endif
  #if ((ETH_GLOBAL_TIME_SUPPORT == STD_ON) || (ETH_PREEMPTION_SUPPORT == STD_ON))
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  #endif
  #endif

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  uint32 LulQIdx;                                                                                                       /* PRQA S 1710 # JV-01 */
  uint32 LulCfgIdx;
  uint32 LulRegIdx;
  uint32 LulTASCfgAddr;
  float64 LdbStartupTime = 0;                                                                                           /* PRQA S 1298 # JV-01 */
  float64 LdbGCTt0Val = 0;                                                                                              /* PRQA S 1298 # JV-01 */
  float64 LdbGCTt1Val = 0;                                                                                              /* PRQA S 1298 # JV-01 */
  float64 LdbGCTt2Val = 0;                                                                                              /* PRQA S 1298 # JV-01 */
  #if (ETH_DEVICE_NAME == ETH_X5X)
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  #endif
  #endif

  /* Set MAC address */
  /* When MAC address is 01-23-45-67-89-AB, set 0x0123 */
  LpRmacRegs->ulMRMAC0 = Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 >> (uint32)ETH_SIXTEEN;
  /* When MAC address is 01-23-45-67-89-AB, set 0x456789AB */
  LpRmacRegs->ulMRMAC1 =
    (Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulH32 << (uint32)ETH_SIXTEEN) | Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr.ulL16;

  #if (ETH_DEVICE_NAME == ETH_U5X)
  if (ETH_TRUE == Eth_GaaCtrlStat[LulCtrlIdx].blPromiscuous)
  {
    /* Promiscuous receive mode */
    LpRmacRegs->ulMRAFC |= ETH_ETND_PROMISCUOUS_MODE;
  }
  else
  {
    /* Normal receive mode */
    LpRmacRegs->ulMRAFC &= ~ETH_ETND_PROMISCUOUS_MODE;
  }
  #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  LucResult = E_OK;
  /* TAS algorithm start */
  if (ETH_ENABLE == LpHwUnitConfig->stTASConfig.enTasEnable)
  {
    LulTASCfgAddr = (uint32)ETH_ZERO;

    #if (ETH_DEVICE_NAME == ETH_U5X)
    /* For U5x device */
    for (LulQIdx = ETH_ZERO; LulQIdx < ETH_TAS_QUEUE_NUM; LulQIdx++)
    {
      /* Entry number setting */
      LulRegIdx = LulQIdx / ETH_ETND_TAEN_POSITION;
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTAEN[LulRegIdx] |=
        LpHwUnitConfig->stTASConfig.aaNumberOfTasTable[LulQIdx] <<
        ((LulQIdx % ETH_ETND_TAEN_POSITION) * ETH_ETND_TAEN_OFFSET);                                                    /* PRQA S 3384 # JV-01 */

      for (LulCfgIdx = 0; LulCfgIdx < LpHwUnitConfig->stTASConfig.aaNumberOfTasTable[LulQIdx]; LulCfgIdx++)
      {
        /* TAS admin control list table learning */
        LucResult = Eth_TasAdminLearning(LulCtrlIdx, LulTASCfgAddr,
                                         LpHwUnitConfig->stTASConfig.aaTasAdminTable[LulQIdx] + LulCfgIdx);             /* PRQA S 0488 # JV-01 */
        if (E_NOT_OK == LucResult)
        {
          /* Failed learning */
          break;
        } /* else: No action required */

        LulTASCfgAddr++;                                                                                                /* PRQA S 3383 # JV-01 */
      }

      if (E_NOT_OK == LucResult)
      {
        /* Failed learning */
        break;
      } /* else: No action required */
    }
    #elif (ETH_DEVICE_NAME == ETH_X5X)
    /* For X5H device */
    for (LulQIdx = ETH_ZERO; LulQIdx < ETH_TAS_QUEUE_NUM; LulQIdx++)
    {
      /* Entry number setting */
      LulRegIdx = LulQIdx / ETH_ETND_TAEN_POSITION;
      Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTAEN[LulRegIdx] |=
        (uint32)((uint32)LpHwUnitConfig->stTASConfig.aaEntryNumber[LulQIdx] <<
          ((LulQIdx % ETH_ETND_TAEN_POSITION) * ETH_ETND_TAEN_OFFSET));                                                 /* PRQA S 3384 # JV-01 */
    }
    for (LulCfgIdx = 0; LulCfgIdx < (uint32)LpHwUnitConfig->stTASConfig.ulNumberOfTasTable; LulCfgIdx++)
    {
      /* TAS admin control list table learning */
      LucResult = Eth_TasAdminLearning(LulCtrlIdx, LulTASCfgAddr,
                                        LpHwUnitConfig->stTASConfig.pTasTable + LulCfgIdx);                             /* PRQA S 0488 # JV-01 */
      if (E_OK == LucResult)
      {
        LulTASCfgAddr = LulTASCfgAddr + 1UL;                                                                            /* PRQA S 3383 # JV-01 */
      }
      else
      {
        break;
      }
    }
    #endif /* #if(ETH_DEVICE_NAME) */

    /* TAS startup time calculation */
    /* GCTt0: The nanosecond part of the gPTP captured timer value
     * GCTt1: The lower 32 bits of second part of the gPTP captured timer value
     * GCTt2: The upper 16 bits of second part of the gPTP captured timer value
     *
     * (1) ulGCTt1*10^9: Convert "the lower 32 bits of second" to nanosecond
     * (2) ulGCTt2*10^9*2^32 : Convert "the upper 16 bits of second" to nanosecond, then left-shift 32 bit
     * (1) + (2) : 48bit second of gPTP (converted to nanosecond)
     * ulGCTt0 + <48bit second of gPTP>(nanosecond) + <1second>(10^9 nanosecond)
     *
     * Note:
     *      4294967296 = 2^32
     *      *10^9 to convert from second to nanosecond
     *      *2^32 to left-shift 32 bits
     *      /2^32 to right-shift 32 bits
     *
     * Example:
     * GCTt0: 0x30 nanosecond
     * GCTt1: 0xF
     * GCTt2: 0x1
     * -> total second part of gPTP timer = GCTt1 + GCTt2 = 0xF + (0x1<<32) = 0x1000F
     * -> convert to nanosecond = 0x1000F*10^9
     * -> total time of gPTP timer in nanosecond = ulGCTt0 + 0x1000F*10^9 = 0x30 + 0x1000F*10^9
     */
    #if (ETH_DEVICE_NAME == ETH_U5X)
    LdbGCTt0Val = (float64)LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt0;
    LdbGCTt1Val = ((float64)LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt1 * (float64)1000000000.0);
    LdbGCTt2Val = ((float64)LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt2 * (float64)1000000000.0 * \
                    (float64)4294967296.0);
    #elif (ETH_DEVICE_NAME == ETH_X5X)
    LdbGCTt0Val = (float64)Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM0t;
    LdbGCTt1Val = ((float64)Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM1t * \
                    (float64)1000000000.0);
    LdbGCTt2Val = ((float64)Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM2t * \
                    (float64)1000000000.0 * (float64)4294967296.0);
    #endif
    /* Caculate the starup time
     * Starup time = Current gPTP time + 1 second
     * Plus 1 second to make sure the TAS start time is valid. The period between enable (write TCC to 1) and cycle
     * start time (TACST) is not exceed 1 second.
     */
    LdbStartupTime = LdbGCTt0Val + LdbGCTt1Val + LdbGCTt2Val + (float64)1000000000.0;

    /* Skip first entry setting */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTASFE = (uint32)ETH_ZERO;
    /* Cycle start time setting */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACST0 = ETH_CALC_TAS_TACST0(LdbStartupTime);                             /* PRQA S 3432, 3469, 4395, 1800 # JV-01, JV-01, JV-01, JV-01 */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACST1 = ETH_CALC_TAS_TACST1(LdbStartupTime);                             /* PRQA S 3432, 3469, 4395, 1800 # JV-01, JV-01, JV-01, JV-01 */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACST2 = ETH_CALC_TAS_TACST2(LdbStartupTime);                             /* PRQA S 3432, 4395, 1800 # JV-01, JV-01, JV-01 */
    /* TAS enable */
    Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTCC = ETH_ETND_TCC_ENABLE;
  } /* else: No action required */

  if (E_OK == LucResult)                                                                                                /* PRQA S 2991, 2995 # JV-01, JV-01 */
  {
  #endif
    /* Set EAMC mode to DISABLE */
    LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_DISABLE_MODE);
    if (E_OK == LucResult)
    {
      /* Set EAMC mode to OPERATION */
      LucResult = Eth_MHD_ModeSetting(LulCtrlIdx, ETH_ETND_MHD_OPERATION_MODE);

      #if (ETH_DEVICE_NAME == ETH_U5X)
      #if (ETH_PREEMPTION_SUPPORT == STD_ON)
      if (E_OK == LucResult)
      {
        /* Link Verification */
        if (ETH_ENABLE == LpHwUnitConfig->enPreemption)
        {
          /* Set Preemption auto response and Link Verification Timer */
          LpRmacRegs->ulMLVC = ETH_ETND_MLVC_PASE_MASK | LpHwUnitConfig->stMACConfig.ulLVTimer;
          /* Request Link Verification (HW will clear this bit after completing link verification) */
          LpRmacRegs->ulMLVC |= ETH_ETND_MLVC_PLV_MASK;
          /* Wait until completing Link Verification */
          LulTickStart = (uint32)ETH_ZERO;
          LulTickElap = (uint32)ETH_ZERO;
          (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
          do
          {
            LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                      /* PRQA S 3383 # JV-01 */
          } while (((uint32)ETH_ZERO != (LpRmacRegs->ulMLVC & ETH_ETND_MLVC_PLV_MASK)) &&
            (LulTickElap <= ETH_TIMEOUT_COUNT));

          if (ETH_TIMEOUT_COUNT < LulTickElap)
          {
            LucResult = E_NOT_OK;
          } /* else: No action required */
        } /* else: No action required */
      }
      #endif /* #if (ETH_PREEMPTION_SUPPORT == STD_ON) */
      #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
    }
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  } /* else: No action required */
  #endif

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwTransmit
**
** Service ID            : N/A
**
** Description           : Initiates a transmission on an ETND controller.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulBufIdx      : index of a tx buffer
**                         LulLenByte     : byte length of a payload
**                         LblConfirmation: Whether TxConfirmation is required when a transmission finished
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK : Success
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaTxBufferMgrTable, Eth_GaaCtrlStat, Eth_GstETND_Regs
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : TRCR
**
** Reference ID          : ETH_DUD_ACT_2014
** Reference ID          : ETH_DUD_ACT_2014_GBL001, ETH_DUD_ACT_2014_GBL002, ETH_DUD_ACT_2014_GBL003
** Reference ID          : ETH_DUD_ACT_2014_REG001
** Reference ID          : ETH_DUD_ACT_2014_CRT001, ETH_DUD_ACT_2014_CRT002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwTransmit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulBufIdx,
  CONST(uint32, AUTOMATIC) LulLenByte, CONST(boolean, AUTOMATIC) LblConfirmation)
{
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                          /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                  /* PRQA S 3432 # JV-01 */
  Eth_TxCtrlInfo0WordType  LunTxCtrlInfo0;                                                                              /* PRQA S 0759 # JV-01 */
  Eth_TxCtrlInfo1WordType  LunTxCtrlInfo1;                                                                              /* PRQA S 0759 # JV-01 */

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Get Tx buffer handler */
  LpBufHandlerPtr = Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Set Tx request length */
  LpBufHandlerPtr->ulTxLength = (uint32)ETH_HEADER_SIZE + LulLenByte;                                                   /* PRQA S 3383 # JV-01 */

  /* Set Tx confirmation flag */
  LpBufHandlerPtr->blTxConfirm = LblConfirmation;

  /* Get next free descriptor */
  LpDataDesc = (Eth_ExtDescType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LpBufHandlerPtr->ucTxQueueIdx];     /* PRQA S 0316 # JV-01 */

  LunTxCtrlInfo0.ulWord = (uint32)ETH_ZERO;
  LunTxCtrlInfo1.ulWord = (uint32)ETH_ZERO;
  /* Justify typecast to smaller datatype */
  LunTxCtrlInfo0.stTxCtrl.ulTsun = (uint8)(LpBufHandlerPtr->ulbufIdx);
  if (ETH_TRUE == LpBufHandlerPtr->blbenableTS)
  {
    LunTxCtrlInfo0.stTxCtrl.ulTxc = (uint32)ETH_TX_DESC_TCX_ENABLE;
    LunTxCtrlInfo0.stTxCtrl.ulTn = (uint32)ETH_TX_DESC_TN_DOMAIN;
  } /* else: No action required */

  LunTxCtrlInfo1.stTxCtrl.ulTfl = LpBufHandlerPtr->ulTxLength;

  /* Build the descriptor */
  LpDataDesc->stHeader.ulDie = (uint32)ETH_TX_DESC_DIE_ENABLE;
  LpDataDesc->stHeader.ulInfo0 = LunTxCtrlInfo0.ulWord;
  LpDataDesc->stHeader.ulDs = LpBufHandlerPtr->ulTxLength;
  LpDataDesc->ulDptr = LpBufHandlerPtr->ulbufAddr;
  LpDataDesc->ulInfo1[ETH_ZERO] = LunTxCtrlInfo1.ulWord;
  LpDataDesc->ulInfo1[ETH_ONE] = (uint32)ETH_ZERO;
  /* DT field is an exclusive control with HW, so it must be set at the end. */
  LpDataDesc->stHeader.ulDt = (uint32)ETH_DESC_FSINGLE;

  /* Set next descriptor */
  LpDataDesc++;
  while ((LpDataDesc->stHeader.ulDt == ETH_DESC_LEMPTY) || (LpDataDesc->stHeader.ulDt == ETH_DESC_LINK))
  {
    LpDataDesc->stHeader.ulDt = (uint32)ETH_DESC_LINK;
    LpDataDesc = (P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA)) LpDataDesc->ulDptr;                                 /* PRQA S 0306, 3432 # JV-01, JV-01 */
  }

  Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LpBufHandlerPtr->ucTxQueueIdx] = LpDataDesc;

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Increase the number of buffer of current Tx queue */
  Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LpBufHandlerPtr->ucTxQueueIdx]++;                                     /* PRQA S 3383 # JV-01 */

  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Transmit start request 0-7 */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI.ulTRCR[ETH_ZERO] |= (uint32)((uint32)ETH_ONE << \
                                                                              ((uint32)LpBufHandlerPtr->ucTxQueueIdx));

  return E_OK;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwTxConfirmation (ETND)
**
** Service ID            : N/A
**
** Description           : Performs transmission processing, notifies the upper layer
**                         of transmission completion and releases the Tx buffer.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaCtrlStat
**                         Eth_GaaTxBufferMgrTable,Eth_GaaTxBufferNodes, Eth_GstBroadcastAddr
**
** Function(s) invoked   : EthIf_TxConfirmation, EthSwt_EthTxFinishedIndication,
**                         ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION,
**                         Eth_ReleaseTxBuffer
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2015
** Reference ID          : ETH_DUD_ACT_2015_GBL001, ETH_DUD_ACT_2015_GBL002, ETH_DUD_ACT_2015_GBL003
** Reference ID          : ETH_DUD_ACT_2015_GBL004, ETH_DUD_ACT_2015_GBL005,
** Reference ID          : ETH_DUD_ACT_2015_REG001
** Reference ID          : ETH_DUD_ACT_2015_CRT001, ETH_DUD_ACT_2015_CRT002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwTxConfirmation(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  uint32 LulQIdx;                                                                                                       /* PRQA S 1710 # JV-01 */
  uint32 LulCnt;
  uint32 LulTxCnt;
  uint32 LulBufIdx;

  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                          /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpBufHandlerPtr;                                                /* PRQA S 3432 # JV-01 */
  #if (ETH_GET_TX_STATS_API == STD_ON)
  Eth_MacAddressType LstMacAddr;
  #endif

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Check the status of the tx descriptor */
  for (LulQIdx = (uint32)ETH_ZERO; LulQIdx < (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue; LulQIdx++)
  {
    /* Get on-transmit count */
    LulTxCnt = Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulQIdx];
    if ((uint32)ETH_ZERO == LulTxCnt)
    {
      /* Skip because the transmit is not completed */
      continue;
    } /* else: No action required */

    LpDataDesc = (Eth_ExtDescType *) Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulQIdx];                        /* PRQA S 0316 # JV-01 */
    /* Transmit not completed yet */
    if (ETH_DESC_FEMPTY == LpDataDesc->stHeader.ulDt)
    {
     for (LulCnt = (uint32)ETH_ZERO; LulCnt < LulTxCnt; LulCnt++)
     {
      /* Get Tx buffer handler */
      LulBufIdx = (LpDataDesc->stHeader.ulInfo0 & ETH_TX_DESCR_TSUN_MASK) >> (uint32)ETH_FOUR;
      LpBufHandlerPtr = Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

      #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
      if ((ETH_TRUE == LpBufHandlerPtr->blbenableTS) && (ETH_INVALID == LpBufHandlerPtr->enTimeQual))
      {
        /* Transmit not completed yet */
        break;
      } /* else: No action required */
      #endif

      #if (ETH_GET_TX_STATS_API == STD_ON)
      Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNumberOfOctets += LpBufHandlerPtr->ulTxLength;                             /* PRQA S 3383 # JV-01 */
      ETH_PACK_ADDRESS_FROM_8(((uint8 *)LpBufHandlerPtr->ulbufAddr), LstMacAddr);                                       /* PRQA S 0306, 3469 # JV-01, JV-01 */
      if (((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstBroadcastAddr)) ||                                    /* PRQA S 3469 # JV-01 */
          ((uint32)ETH_ZERO != ETH_CHECK_MULTICAST(LstMacAddr)))                                                        /* PRQA S 3469 # JV-01 */
      {
        Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNUcastPkts++;                                                            /* PRQA S 3383 # JV-01 */
      }
      else
      {
        Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxUniCastPkts++;                                                           /* PRQA S 3383 # JV-01 */
      }
      #endif

      /* Check whether the transmission confirmation was enabled */
      if (ETH_TRUE == LpBufHandlerPtr->blTxConfirm)
      {
        if (ETH_TRUE == Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].blIsTxHandleId)
        {
          /* SWS_Eth_00321 */
          /* Call the callback function */
          /* Since the maximum value of controller index is always less than 255, casting to uint8 does no problem. */
          EthIf_TxConfirmation((uint8)LulCtrlIdx,
                              (Eth_BufIdxType)Eth_GaaTxBufferNodes[LulCtrlIdx][LulBufIdx].ucTxHandleId, E_OK);
        }
        else
        {
          /* Call the callback function */
          /* Since the maximum value of controller index is always less than 255, casting to uint8 does no problem. */
          EthIf_TxConfirmation((uint8)LulCtrlIdx, (Eth_BufIdxType)LpBufHandlerPtr->ulbufIdx, E_OK);
        }
      } /* else: No action required */

      #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
      /* Indication for a finished transmit process for a specific Ethernet frame. */
      /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
      (void)EthSwt_EthTxFinishedIndication((uint8)LulCtrlIdx, (Eth_BufIdxType)LpBufHandlerPtr->ulbufIdx);
      #endif

      ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Release the tx buffer resource */
      Eth_ETND_ReleaseTxBuffer(LulCtrlIdx, LulBufIdx);

      /* Clear tx descriptor */
      LpDataDesc->stHeader.ulDie    = (uint32)ETH_ZERO;
      LpDataDesc->stHeader.ulAxie   = (uint32)ETH_ZERO;
      LpDataDesc->stHeader.ulDse    = (uint32)ETH_ZERO;
      LpDataDesc->stHeader.ulInfo0  = (uint32)ETH_ZERO;
      LpDataDesc->stHeader.ulDs     = (uint32)ETH_ZERO;
      LpDataDesc->ulDptr            = (uint32)ETH_ZERO;
      LpDataDesc->ulInfo1[ETH_ZERO] = (uint32)ETH_ZERO;
      LpDataDesc->ulInfo1[ETH_ONE]  = (uint32)ETH_ZERO;

      /* Decrease the number of on-transmission buffer of current Tx queue */
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaBufTxCnt[LulQIdx]--;                                                       /* PRQA S 3383 # JV-01 */

      ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

      /* Update start descriptor */
      LpDataDesc++;
      while ((ETH_DESC_LEMPTY == LpDataDesc->stHeader.ulDt) || (ETH_DESC_LINK == LpDataDesc->stHeader.ulDt))
      {
        LpDataDesc->stHeader.ulDt = (uint32)ETH_DESC_LINK;
        LpDataDesc = (P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA))LpDataDesc->ulDptr;                              /* PRQA S 0306, 3432 # JV-01, JV-01 */
      }
      Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulQIdx] = LpDataDesc;
     }
    }/* else: No action required */
  }
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwReceive
**
** Service ID            : N/A
**
** Description           : Performs reception processing in polling mode.
**                         When polling mode:
**                           Receive one frame and indicate it EthIf
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulQueueIdx     : Index of a Queue
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : When polling mode:
**                           ETH_NOT_RECEIVED : there was no received frame
**                           ETH_RECEIVED     : there was one received frame
**                           ETH_RECEIVED_MORE_DATA_AVAILABLE:
**                                 there were more than one received frames
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : Eth_RxQueueProcess
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2016
***********************************************************************************************************************/
FUNC(Eth_RxStatusType, ETH_PRIVATE_CODE) Eth_ETND_HwReceive(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx)
{
  Eth_ExtRxStatusType LenRetValue;
  uint32 LulLenRetValueAsInt;
  /* Receive the specified queue */
  do
  {
    LenRetValue = Eth_RxQueueProcess(LulCtrlIdx, LulQueueIdx);
  } while (ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE == LenRetValue);

  /* Cast Eth_ExtRxStatusType to Integer  */
  LulLenRetValueAsInt = (uint32)LenRetValue;

  /* Cast Integer to Eth_RxStatusType and return value */
  return (Eth_RxStatusType)LulLenRetValueAsInt;                                                                         /* PRQA S 4342 # JV-01 */
}

#if (ETH_CTRL_ENABLE_RX_POLLING == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwCheckFifoIndex
**
** Service ID            : N/A
**
** Description           : Check the validity of the Queue index specified
**                         in the Eth_Receive.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulQueueIdx     : the Queue index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2017
** Reference ID          : ETH_DUD_ACT_2017_GBL001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwCheckFifoIndex(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  Std_ReturnType LucReturnValue;

  LucReturnValue = E_OK;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */

  /* Validity check for the Queue index */
  if ((uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue <= LulQueueIdx)
  {
    LucReturnValue = E_NOT_OK;
  } /* else: No action required */

  return LucReturnValue;
}
#endif /* (ETH_CTRL_ENABLE_RX_POLLING == STD_ON) */

#if (ETH_CTRL_ENABLE_MII == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwReadMii (ETND)
**
** Service ID            : N/A
**
** Description           : Read data from the PHY management interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LucTrcvIdx     : Index of the transceiver on the MII
**                         LucRegIdx      : Index of the transceiver register on the MII
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LusRetData (Read data from PHY)
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs
**
** Function(s) invoked   : GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : MPSM, MMIS1
**
** Reference ID          : ETH_DUD_ACT_2018
** Reference ID          : ETH_DUD_ACT_2018_GBL001
** Reference ID          : ETH_DUD_ACT_2018_REG001, ETH_DUD_ACT_2018_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwReadMii(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx, CONST(uint8, AUTOMATIC) LucRegIdx,
  CONSTP2VAR(uint16, AUTOMATIC, ETH_APPL_DATA) LpRegValPtr)                                                             /* PRQA S 3432, 3673 # JV-01, JV-01 */
{
  #if (ETH_DEVICE_NAME == ETH_X5X)
  (void)LulCtrlIdx;
  (void)LucTrcvIdx;
  (void)LucRegIdx;
  (void)LpRegValPtr;
  /* X5H doesn't support MII access */
  Std_ReturnType LucResult = E_NOT_OK;

  #elif (ETH_DEVICE_NAME == ETH_U5X)
  CONSTP2VAR(volatile Eth_ETND_RMACRegType, AUTOMATIC, REGSPACE) LpRmacRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC;
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  /* Write PRA, PDA to the MPSM register and set read access direction */
  LpRmacRegs->ulMPSM = (uint32)(((uint32)LucTrcvIdx << (uint32)ETH_THREE) | ((uint32)LucRegIdx << (uint32)ETH_EIGHT));

  /* Enable PHY register access bit */
  LpRmacRegs->ulMPSM |= ETH_ETND_MPSM_READ_OPERATION;

  /* Wait until MPSM.PSME returns to 0 */
  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
  } while (((LpRmacRegs->ulMPSM & ETH_ETND_PHY_CONFIG_REGISTER_MASK) !=
                                                              (uint32)ETH_ZERO) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    *LpRegValPtr = (uint16)ETH_ZERO;
    LucResult = E_NOT_OK;
  }
  else
  {
    /* Get read data as return value */
    *LpRegValPtr = (uint16)(LpRmacRegs->ulMPSM >> ETH_SIXTEEN);
    LucResult = E_OK;
  }

  /* Clear interrupt (MMIS1.PRACS = 1) */
  LpRmacRegs->ulMMIS1 |= ETH_ETND_PHY_CONFIG_REGISTER_MASK;
  #endif

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwWriteMii (ETND)
**
** Service ID            : N/A
**
** Description           : Write data to the PHY management interface
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LucTrcvIdx     : Index of the transceiver on the MII
**                         LucRegIdx      : Index of the transceiver register on the MII
**                         LusRegVal      : Value to be written into the indexed
**                                          register
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LucResult (E_OK / E_NOT_OK)
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs
**
** Function(s) invoked   : None
**
** Registers Used        : MPSM, MMIS1
**
** Reference ID          : ETH_DUD_ACT_2019
** Reference ID          : ETH_DUD_ACT_2019_GBL001
** Reference ID          : ETH_DUD_ACT_2019_REG001, ETH_DUD_ACT_2019_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwWriteMii(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint8, AUTOMATIC) LucTrcvIdx,
  CONST(uint8, AUTOMATIC) LucRegIdx, CONST(uint16, AUTOMATIC) LusRegVal)
{
  #if (ETH_DEVICE_NAME == ETH_X5X)
  (void)LulCtrlIdx;
  (void)LucTrcvIdx;
  (void)LucRegIdx;
  (void)LusRegVal;
  /* X5H doesn't support MII access */
  Std_ReturnType LucResult = E_NOT_OK;

  #elif (ETH_DEVICE_NAME == ETH_U5X)
  CONSTP2VAR(volatile Eth_ETND_RMACRegType, AUTOMATIC, REGSPACE) LpRmacRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.stRMAC;
  Std_ReturnType LucResult;
  TickType LulTickStart;
  TickType LulTickElap;

  /* Write PRA, PDA to the MPSM register and and set write access direction */
  LpRmacRegs->ulMPSM = (uint32)(((uint32)LusRegVal << (uint32)ETH_SIXTEEN) | ((uint32)LucTrcvIdx << (uint32)ETH_THREE) |
                       ((uint32)LucRegIdx << (uint32)ETH_EIGHT) | ETH_ETND_MPSM_WRITE_DATA_SET);

  /* Enable PHY register access bit */
  LpRmacRegs->ulMPSM |= ETH_ETND_MPSM_WRITE_OPERATION;

  /* Wait until MPSM.PSME returns to 0 */
  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
  } while (((LpRmacRegs->ulMPSM & ETH_ETND_PHY_CONFIG_REGISTER_MASK) != (uint32)ETH_ZERO)
                                                                                 && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  /* Clear interrupt (MMIS1.PWACS = 1) */
  LpRmacRegs->ulMMIS1 |= ETH_ETND_MMIS1_PWACS_MASK;
  #endif

  return LucResult;
}
#endif /* (ETH_CTRL_ENABLE_MII == STD_ON) */

#if (ETH_GET_COUNTER_VALUES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_GetCounterValues
**
** Service ID            : N/A
**
** Description           : Get drop frame counts for each error factor
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx: Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpCounterPtr: Drop frame counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : RBOEC
**
** Reference ID          : ETH_DUD_ACT_2020
** Reference ID          : ETH_DUD_ACT_2020_GBL001, ETH_DUD_ACT_2020_GBL002
** Reference ID          : ETH_DUD_ACT_2020_REG001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_CounterType, AUTOMATIC, ETH_APPL_DATA) LpCounterPtr)                                                   /* PRQA S 3432 # JV-01 */
{
  CONSTP2CONST(volatile Eth_ETND_RMACSRegType, AUTOMATIC, REGSPACE) LpRmacsRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys;

  /* Statistics Available */
  LpCounterPtr->DropPktBufOverrun = LpRmacsRegs->ulRBOEC;

  /* Critical section protection for these global variables is not necessary in this function
     since these variables are only updated in Eth_HwMainFunction,
     and the ETH module only uses a single thread according to AUTOSAR */
  LpCounterPtr->DropPktCrc   = Eth_GaaCtrlStat[LulCtrlIdx].stCounter.DropPktCrc;
  LpCounterPtr->UndersizePkt = Eth_GaaCtrlStat[LulCtrlIdx].stCounter.UndersizePkt;
  LpCounterPtr->OversizePkt  = Eth_GaaCtrlStat[LulCtrlIdx].stCounter.OversizePkt;
  LpCounterPtr->AlgnmtErr    = Eth_GaaCtrlStat[LulCtrlIdx].stCounter.AlgnmtErr;

  LpCounterPtr->SqeTestErr   = ETH_NOT_AVAILABLE;
  LpCounterPtr->DiscInbdPkt  = ETH_NOT_AVAILABLE;
  LpCounterPtr->ErrInbdPkt   = ETH_NOT_AVAILABLE;
  LpCounterPtr->DiscOtbdPkt  = ETH_NOT_AVAILABLE;
  LpCounterPtr->ErrOtbdPkt   = ETH_NOT_AVAILABLE;
  LpCounterPtr->SnglCollPkt  = ETH_NOT_AVAILABLE;
  LpCounterPtr->MultCollPkt  = ETH_NOT_AVAILABLE;
  LpCounterPtr->DfrdPkt      = ETH_NOT_AVAILABLE;
  LpCounterPtr->LatCollPkt   = ETH_NOT_AVAILABLE;
  LpCounterPtr->HwDepCtr0    = ETH_NOT_AVAILABLE;
  LpCounterPtr->HwDepCtr1    = ETH_NOT_AVAILABLE;
  LpCounterPtr->HwDepCtr2    = ETH_NOT_AVAILABLE;
  LpCounterPtr->HwDepCtr3    = ETH_NOT_AVAILABLE;

  /* Clear these global variables according to the Read Clear spec of the Statistic counter registers */
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.DropPktCrc   = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.UndersizePkt = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.OversizePkt  = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.AlgnmtErr    = (uint32)ETH_ZERO;
}
#endif /* (ETH_GET_COUNTER_VALUES_API == STD_ON) */

#if (ETH_GET_RX_STATS_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetRxStats (ETND)
**
** Service ID            : N/A
**
** Description           : Get Rx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpRxStats: Rx statistics counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GstETND_Regs
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : RBFC, RMFC
**
** Reference ID          : ETH_DUD_ACT_2021
** Reference ID          : ETH_DUD_ACT_2021_GBL001, ETH_DUD_ACT_2021_GBL002
** Reference ID          : ETH_DUD_ACT_2021_REG001, ETH_DUD_ACT_2021_REG002
** Reference ID          : ETH_DUD_ACT_2021_CRT001, ETH_DUD_ACT_2021_CRT002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetRxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(Eth_RxStatsType, AUTOMATIC, ETH_APPL_DATA) LpRxStats)                 /* PRQA S 3432 # JV-01 */
{
  CONSTP2CONST(volatile Eth_ETND_RMACSRegType, AUTOMATIC, REGSPACE) LpRmacsRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys;

  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
  /* Rx Octet Counter */
  LpRxStats->RxStatsOctets = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOctets;

  /* Rx Packet Counter */
  LpRxStats->RxStatsPkts   = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts;

  /* Rx 64 Octets */
  LpRxStats->RxStatsPkts64Octets  = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts64Octets;

  /* Rx 65-127 Octets */
  LpRxStats->RxStatsPkts65to127Octets    = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts65to127Octets;

  /* Rx 128-255 Octets */
  LpRxStats->RxStatsPkts128to255Octets   = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts128to255Octets;

  /* Rx 256-511 Octets */
  LpRxStats->RxStatsPkts256to511Octets   = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts256to511Octets;

  /* Rx 512-1023 Octets */
  LpRxStats->RxStatsPkts512to1023Octets  = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts512to1023Octets;

  /* Rx 1024-1518 Octets */
  LpRxStats->RxStatsPkts1024to1518Octets = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts1024to1518Octets;

  /* Rx unicast frames */
  LpRxStats->RxUnicastFrames       = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxUnicastFrames;

  /* Crc + Alignment Error Counter */
  LpRxStats->RxStatsCrcAlignErrors = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsCrcAlignErrors;

  /* Too Short Frames Counter */
  LpRxStats->RxStatsUndersizePkts  = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsUndersizePkts;

  /* Too Long Frames Counter  */
  LpRxStats->RxStatsOversizePkts   = Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOversizePkts;

  /* Clear these global variables according to the Read Clear spec of the Statistic counter registers */
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOctets               = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts                 = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts64Octets         = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts65to127Octets    = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts128to255Octets   = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts256to511Octets   = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts512to1023Octets  = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts1024to1518Octets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxUnicastFrames             = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsCrcAlignErrors       = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsUndersizePkts        = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOversizePkts         = (uint32)ETH_ZERO;
  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Rx Drop Events */
  LpRxStats->RxStatsDropEvents = ETH_NOT_AVAILABLE;

  /* Rx Stats Fragments */
  LpRxStats->RxStatsFragments  = ETH_NOT_AVAILABLE;

  /* Rx Stats Jabbers */
  LpRxStats->RxStatsJabbers    = ETH_NOT_AVAILABLE;

  /* Rx Stats Collisions */
  LpRxStats->RxStatsCollisions = ETH_NOT_AVAILABLE;

  /* Rx Broadcast Counter */
  LpRxStats->RxStatsBroadcastPkts = LpRmacsRegs->ulRBFC;

  /* Multicast Frame Counter */
  LpRxStats->RxStatsMulticastPkts = LpRmacsRegs->ulRMFC;
}
#endif /* (ETH_GET_RX_STATS_API == STD_ON) */

#if (ETH_GET_TX_STATS_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetTxStats
**
** Service ID            : N/A
**
** Description           : Get Tx statistics information
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTxStats: Tx statistics counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2022
** Reference ID          : ETH_DUD_ACT_2022_GBL001
** Reference ID          : ETH_DUD_ACT_2022_CRT001,ETH_DUD_ACT_2022_CRT002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetTxStats(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2VAR(Eth_TxStatsType, AUTOMATIC, ETH_APPL_DATA) LpTxStats)                 /* PRQA S 3432 # JV-01 */
{
  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
  /* Tx Octet Counter */
  LpTxStats->TxNumberOfOctets = Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNumberOfOctets;

  /* Tx Not Unicast Packet Counter */
  LpTxStats->TxNUcastPkts = Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNUcastPkts;

  /* Tx Unicast Packet Counter */
  LpTxStats->TxUniCastPkts = Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxUniCastPkts;

  /* Clear these global variables according to the Read Clear spec of the Statistic counter registers */
  Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNumberOfOctets = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxNUcastPkts     = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].stTxStat.TxUniCastPkts    = (uint32)ETH_ZERO;
  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);
}
#endif /* (ETH_GET_TX_STATS_API == STD_ON) */

#if (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetTxErrorCounterValues
**
** Service ID            : N/A
**
** Description           : Get error statuses
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTxErrorCounterValues: Tx error counter information
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2023
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwGetTxErrorCounterValues(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_TxErrorCounterValuesType, AUTOMATIC, ETH_APPL_DATA) LpTxErrorCounterValues)                            /* PRQA S 3432 # JV-01 */
{
  #if(ETH_DEVICE_NAME == ETH_X5X)
  LpTxErrorCounterValues->TxDroppedErrorPkts = Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys.ulTEFC;
  #else
  /* Dummy use to avoid QAC warning about unused parameter */
  (void)LulCtrlIdx;

  LpTxErrorCounterValues->TxDroppedErrorPkts = ETH_NOT_AVAILABLE;
  #endif
  /* This HW is cannot get Tx error statistics */
  LpTxErrorCounterValues->TxDroppedNoErrorPkts = ETH_NOT_AVAILABLE;
  LpTxErrorCounterValues->TxDeferredTrans      = ETH_NOT_AVAILABLE;
  LpTxErrorCounterValues->TxSingleCollision    = ETH_NOT_AVAILABLE;
  LpTxErrorCounterValues->TxLateCollision      = ETH_NOT_AVAILABLE;
  LpTxErrorCounterValues->TxExcessiveCollison  = ETH_NOT_AVAILABLE;
}
#endif /* (ETH_GET_TX_ERROR_COUNTER_VALUES_API == STD_ON) */

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwMainFunction
**
** Service ID            : N/A
**
** Description           : Check receive errors and report DEM if exist
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaETNE_ETHARegs, Eth_GpDemEventRxFramesLost, Eth_GpDemEventCRC,
**                         Eth_GpDemEventUnderSizeFrame, Eth_GpDemEventOverSizeFrame,
**                         Eth_GpDemEventAlignment, Eth_GstETND_Regs, Eth_GaaCtrlStat
**
** Function(s) invoked   : Eth_DemConfigCheck
**
** Registers Used        : RPEFC, RFMEFC, RUEFC, ROEFC, RNEFC
**
** Reference ID          : ETH_DUD_ACT_2024
** Reference ID          : ETH_DUD_ACT_2024_GBL001, ETH_DUD_ACT_2024_GBL002, ETH_DUD_ACT_2024_GBL003
** Reference ID          : ETH_DUD_ACT_2024_GBL004, ETH_DUD_ACT_2024_GBL005, ETH_DUD_ACT_2024_GBL006
** Reference ID          : ETH_DUD_ACT_2024_GBL007
** Reference ID          : ETH_DUD_ACT_2024_REG001,ETH_DUD_ACT_2024_REG002, ETH_DUD_ACT_2024_REG003
** Reference ID          : ETH_DUD_ACT_2024_REG004,ETH_DUD_ACT_2024_REG005
** Reference ID          : ETH_DUD_ACT_2024_ERR001, ETH_DUD_ACT_2024_ERR002, ETH_DUD_ACT_2024_ERR003
** Reference ID          : ETH_DUD_ACT_2024_ERR004, ETH_DUD_ACT_2024_ERR005
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_HwMainFunction(CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  /* Report Extended DEM (if any) */
  uint32 LulAutoClearCounter;
  P2CONST(volatile Eth_ETND_RMACSRegType, AUTOMATIC, REGSPACE) LpRmacsRegs;                                             /* PRQA S 3432 # JV-01 */

  LpRmacsRegs = &Eth_GstETND_Regs.pES[LulCtrlIdx]->stRMACSys;
  /* Read RPEFC - Rx Frame Lost Counter */
  if ((uint32)ETH_ZERO < LpRmacsRegs->ulRPEFC)
  {
    /* Call DEM */
    Eth_DemConfigCheck(Eth_GpDemEventRxFramesLost[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
  } /* else: No action required */
  /* Read RFMEFC - FCS/mCRC Error Counter */
  LulAutoClearCounter = LpRmacsRegs->ulRFMEFC;
  #if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsCrcAlignErrors += LulAutoClearCounter;                                    /* PRQA S 3383 # JV-01 */
  #endif
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.DropPktCrc += LulAutoClearCounter;                                              /* PRQA S 3383 # JV-01 */
  #endif
  if ((uint32)ETH_ZERO < LulAutoClearCounter)
  {
    /* Call DEM */
    Eth_DemConfigCheck(Eth_GpDemEventCRC[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
  } /* else: No action required */
  /* Read RUEFC - Too Short Frame Counter */
  LulAutoClearCounter = LpRmacsRegs->ulRUEFC;
  #if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsUndersizePkts += LulAutoClearCounter;                                     /* PRQA S 3383 # JV-01 */
  #endif
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.UndersizePkt += LulAutoClearCounter;                                            /* PRQA S 3383 # JV-01 */
  #endif
  if ((uint32)ETH_ZERO < LulAutoClearCounter)
  {
    /* Call DEM */
    Eth_DemConfigCheck(Eth_GpDemEventUnderSizeFrame[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
  } /* else: No action required */
  /* Read ROEFC - Too Long Frames Counter */
  LulAutoClearCounter = LpRmacsRegs->ulROEFC;
  #if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOversizePkts += LulAutoClearCounter;                                      /* PRQA S 3383 # JV-01 */
  #endif
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.OversizePkt += LulAutoClearCounter;                                             /* PRQA S 3383 # JV-01 */
  #endif
  if ((uint32)ETH_ZERO < LulAutoClearCounter)
  {
    /* Call DEM */
    Eth_DemConfigCheck(Eth_GpDemEventOverSizeFrame[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
  } /* else: No action required */
  /* Read RNEFC - Frame Alignment Error Counter */
  LulAutoClearCounter = LpRmacsRegs->ulRNEFC;
  #if (ETH_GET_RX_STATS_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsCrcAlignErrors += LulAutoClearCounter;                                    /* PRQA S 3383 # JV-01 */
  #endif
  #if (ETH_GET_COUNTER_VALUES_API == STD_ON)
  Eth_GaaCtrlStat[LulCtrlIdx].stCounter.AlgnmtErr += LulAutoClearCounter;                                               /* PRQA S 3383 # JV-01 */
  #endif
  if ((uint32)ETH_ZERO < LulAutoClearCounter)
  {
    /* Call DEM */
    Eth_DemConfigCheck(Eth_GpDemEventAlignment[LulCtrlIdx], DEM_EVENT_STATUS_PREFAILED);
  } /* else: No action required */
}

#if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetCurrentTime
**
** Service ID            : NA
**
** Description           : Return TimeStamp from the HW register
**                         previously started.
**                       : It returns adjusted gPTP timer value (TCSS = 01)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the HW TimeStamp returned
**                       : LpTimeStampPtr : Current TimeStamp value
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaTSNES_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : TME, GCTt0, GCTt1, GCTt2
**
** Reference ID          : ETH_DUD_ACT_2025
** Reference ID          : ETH_DUD_ACT_2025_GBL001, ETH_DUD_ACT_2025_GBL002
** Reference ID          : ETH_DUD_ACT_2025_REG001, ETH_DUD_ACT_2025_REG002
** Reference ID          : ETH_DUD_ACT_2025_REG003, ETH_DUD_ACT_2025_REG004
** Reference ID          : ETH_DUD_ACT_2025_REG005, ETH_DUD_ACT_2025_REG006
** Reference ID          : ETH_DUD_ACT_2025_REG007, ETH_DUD_ACT_2025_REG008
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwGetCurrentTime(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                            /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr)                                               /* PRQA S 3432 # JV-01 */
{
  #if(ETH_DEVICE_NAME == ETH_U5X)
  CONSTP2CONST(volatile Eth_ETND_GPTMARegType, AUTOMATIC, REGSPACE) LpGptmaRegs = Eth_GstETND_Regs.pGPTMA;
  /* Dummy use to avoid QAC warning about unused parameter */
  (void)LulCtrlIdx;
  #endif
  Std_ReturnType LucReturnValue;

  /* R-Switch should use only one gPTP timer domain */

  /* gPTP timer status check */
  #if(ETH_DEVICE_NAME == ETH_U5X)
  if ((uint32)ETH_ZERO != (LpGptmaRegs->ulTME & ETH_GPTP_TIMER_DOMAIN_MASK))
  #elif(ETH_DEVICE_NAME == ETH_X5X)
  if ((uint32)ETH_ZERO != (Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->ulPTPTMEC & ETH_GPTP_TIMER_DOMAIN_MASK))
  #endif
  {
    *LpTimeQualPtr = ETH_VALID;
    LucReturnValue = E_OK;
  }
  else
  {
    *LpTimeQualPtr = ETH_INVALID;
    LucReturnValue = E_NOT_OK;
  }

  #if(ETH_DEVICE_NAME == ETH_U5X)
  /* Get the nanosecond part of the GPTP timer */
  LpTimeStampPtr->nanoseconds = LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt0;
  /* Get the lower 32 bit of second part of the GPTP timer */
  LpTimeStampPtr->seconds = LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt1;
  /* Get the upper 16 bit of second part of the GPTP timer */
  LpTimeStampPtr->secondsHi = (uint16)LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt2;
  #elif(ETH_DEVICE_NAME == ETH_X5X)
  /* Get the nanosecond part of the GPTP timer */
  LpTimeStampPtr->nanoseconds = Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM0t;
  /* Get the lower 32 bit of second part of the GPTP timer */
  LpTimeStampPtr->seconds = Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM1t;
  /* Get the upper 16 bit of second part of the GPTP timer */
  LpTimeStampPtr->secondsHi = (uint16)Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM2t;
  #endif

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetCurrentTimeTuple
**
** Service ID            : NA
**
** Description           : Return TimeStamp from the HW register
**                         previously started.
**                       : It returns adjusted gPTP timer value (TCSS = 01)
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the HW TimeStamp returned
**                       : LpTimeStampPtr : Current TimeStamp value
**
** Return parameter      : LucReturnValue E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaTSNES_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : TME, GCTt0, GCTt1, GCTt2
**
** Reference ID          : ETH_DUD_ACT_2026
** Reference ID          : ETH_DUD_ACT_2026_GBL001, ETH_DUD_ACT_2026_GBL002
** Reference ID          : ETH_DUD_ACT_2026_REG001, ETH_DUD_ACT_2026_REG002
** Reference ID          : ETH_DUD_ACT_2026_REG003, ETH_DUD_ACT_2026_REG004
** Reference ID          : ETH_DUD_ACT_2026_REG005, ETH_DUD_ACT_2026_REG006
** Reference ID          : ETH_DUD_ACT_2026_REG007, ETH_DUD_ACT_2026_REG008
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwGetCurrentTimeTuple(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA) LpCurrentTimeTuplePtr)                                                 /* PRQA S 3432 # JV-01 */
{
  #if(ETH_DEVICE_NAME == ETH_U5X)
  CONSTP2CONST(volatile Eth_ETND_GPTMARegType, AUTOMATIC, REGSPACE) LpGptmaRegs = Eth_GstETND_Regs.pGPTMA;

  /* Dummy use to avoid QAC warning about unused parameter */
  (void)LulCtrlIdx;
  #endif
  Std_ReturnType LucReturnValue;

  /* gPTP timer status check */
  #if(ETH_DEVICE_NAME == ETH_U5X)
  if ((uint32)ETH_ZERO != (LpGptmaRegs->ulTME & ETH_GPTP_TIMER_DOMAIN_MASK))
  #elif(ETH_DEVICE_NAME == ETH_X5X)
  if ((uint32)ETH_ZERO != (Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->ulPTPTMEC & ETH_GPTP_TIMER_DOMAIN_MASK))
  #endif
  {
    LpCurrentTimeTuplePtr->timeQuality = ETH_VALID;
    LucReturnValue = E_OK;
  }
  else
  {
    LpCurrentTimeTuplePtr->timeQuality = ETH_INVALID;
    LucReturnValue = E_NOT_OK;
  }

  /* Get the nanosecond part of the GPTP timer */
  #if(ETH_DEVICE_NAME == ETH_U5X)
  LpCurrentTimeTuplePtr->timestampClockValue.nanoseconds = LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt0;
  /* Get the lower 32 bit of second part of the GPTP timer */
  LpCurrentTimeTuplePtr->timestampClockValue.seconds = LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt1;
  /* Get the upper 16 bit of second part of the GPTP timer */
  LpCurrentTimeTuplePtr->timestampClockValue.secondsHi = (uint16)LpGptmaRegs->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGCTt2;
  #elif(ETH_DEVICE_NAME == ETH_X5X)
  /* Get the nanosecond part of the GPTP timer */
  LpCurrentTimeTuplePtr->timestampClockValue.nanoseconds = Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM0t;
  /* Get the lower 32 bit of second part of the GPTP timer */
  LpCurrentTimeTuplePtr->timestampClockValue.seconds = Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM1t;
  /* Get the upper 16 bit of second part of the GPTP timer */
  LpCurrentTimeTuplePtr->timestampClockValue.secondsHi = (uint16)Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPGPTPTM2t;
  #endif

  /* Since there is no xtimestamp support */
  LpCurrentTimeTuplePtr->disciplinedClockValue.nanoseconds = LpCurrentTimeTuplePtr->timestampClockValue.nanoseconds;
  LpCurrentTimeTuplePtr->disciplinedClockValue.seconds     = LpCurrentTimeTuplePtr->timestampClockValue.seconds;
  LpCurrentTimeTuplePtr->disciplinedClockValue.secondsHi   = LpCurrentTimeTuplePtr->timestampClockValue.secondsHi;

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetEgressTimeStamp
**
** Service ID            : NA
**
** Description           : Read TimeStamp from a message just transmitted
**                         if tag match with Buf idx
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                       : LulBufIdx      : Index of the message buffer
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the Read TS
**                       : LpTimeStampPtr : Value passed above
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GaaTxBufferMgrTable
**
** Function(s) invoked   : ETH_ENTER_CRITICAL_SECTION, ETH_EXIT_CRITICAL_SECTION
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2027
** Reference ID          : ETH_DUD_ACT_2027_GBL001
** Reference ID          : ETH_DUD_ACT_2027_CRT001, ETH_DUD_ACT_2027_CRT002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwGetEgressTimeStamp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx,
  CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                            /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr)                                               /* PRQA S 3432 # JV-01 */
{
  P2CONST(Eth_BufHandlerType, AUTOMATIC, ETH_APPL_DATA) LpTxBufferNode;                                                 /* PRQA S 3432 # JV-01 */

  /* Critical section is required to protect updating of enTimeQual from DataIsr0 interrupt
  during getting egress time stamp in buffer. */
  ETH_ENTER_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

  /* Get Tx buffer handler from the Tx buffer manager table */
  LpTxBufferNode = (Eth_BufHandlerType *)Eth_GaaTxBufferMgrTable[LulCtrlIdx][LulBufIdx].pBufferHdr;

  *LpTimeQualPtr = LpTxBufferNode->enTimeQual;

  *LpTimeStampPtr = LpTxBufferNode->stTimeStamp;
  ETH_EXIT_CRITICAL_SECTION(ETH_RAM_DATA_PROTECTION);

   return (E_OK);
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwGetIngressTimeStamp
**
** Service ID            : NA
**
** Description           : Read TimeStamp from a message received and
**                         store in Autosar Format
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LpDataPtr      : Pointer to the message buffer,
**                                          where Application expects ingress time stamping
**
** InOut Parameters      : None
**
** Output Parameters     : LpTimeQualPtr  : Quality of the Time Stamp
**                       : LpTimeStampPtr : TS read from the Rx Descriptor.
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variables Used : Eth_GaaRxFrame
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2028
** Reference ID          : ETH_DUD_ACT_2028_GBL001
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwGetIngressTimeStamp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpDataPtr,
  CONSTP2VAR(Eth_TimeStampQualType, AUTOMATIC, ETH_APPL_DATA) LpTimeQualPtr,                                            /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeStampPtr)                                               /* PRQA S 3432 # JV-01 */
{
  P2VAR(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpCompPtr;                                                              /* PRQA S 3432, 3678 # JV-01, JV-01 */
  Std_ReturnType LucReturnValue;

  /* Read TimeStamp from the rxframe.Timestamp */
  LpCompPtr = (Eth_DataType *)(Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr + (uint32)ETH_ETHERTYPE_SIZE);                  /* PRQA S 0306, 3383 # JV-01, JV-01 */
  if (LpCompPtr == LpDataPtr)
  {
    LpTimeStampPtr->nanoseconds = Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds;
    LpTimeStampPtr->seconds = Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds;
    LpTimeStampPtr->secondsHi = (uint16)ETH_ZERO;
    /* TimeStamp is valid  */
    *LpTimeQualPtr = ETH_VALID;
    LucReturnValue = E_OK;
  }
  else
  {
    LpTimeStampPtr->nanoseconds = (uint32)ETH_ZERO;
    LpTimeStampPtr->seconds = (uint32)ETH_ZERO;
    LpTimeStampPtr->secondsHi = (uint16)ETH_ZERO;
    /* TimeStamp is invalid  */
    *LpTimeQualPtr = ETH_INVALID;
    LucReturnValue = E_NOT_OK;
  }

  return LucReturnValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwSetIncrementTimeForGptp
**
** Service ID            : NA
**
** Description           : Set a value to GTI and issue a load request
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LulIncVal      : New increment value for the gPTP timer
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - GTIVt update success
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaTSNES_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : GTIVt
**
** Reference ID          : ETH_DUD_ACT_2029
** Reference ID          : ETH_DUD_ACT_2029_GBL001, ETH_DUD_ACT_2029_GBL002
** Reference ID          : ETH_DUD_ACT_2029_REG001, ETH_DUD_ACT_2029_REG002
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwSetIncrementTimeForGptp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulIncVal)
{
  /* R-Switch should use only one gPTP timer domain */
  #if(ETH_DEVICE_NAME == ETH_U5X)
  Eth_GstETND_Regs.pGPTMA->stGptpCfg[ETH_GPTP_TIMER_DOMAIN].ulGTIVt = LulIncVal;

  /* Dummy use to avoid QAC warning about unused parameter */
  (void)LulCtrlIdx;
  #elif(ETH_DEVICE_NAME == ETH_X5X)
  Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTIVCt= LulIncVal;
  #endif

  return E_OK;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_HwSetOffsetTimeForGptp
**
** Service ID            : NA
**
** Description           : Adjust gPTP with an given delta
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                       : LpTimeOffsetPtr: Delta TimeStamp
**
** InOut Parameters      : None
**
** Output Parameters     : E_OK - gPTP Request is completed w/o timeout
**                       : E_NOT_OK - gPTP Request not completed due to timeout
**
** Return parameter      : LucReturnValue - E_OK / E_NOT_OK
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit.
**
** Global Variable(s)    : Eth_GstETND_Regs, Eth_GaaTSNES_GPTPRegs
**
** Function(s) invoked   : None
**
** Registers Used        : GTOVt0, GTOVt1, GTOVt2
**
** Reference ID          : ETH_DUD_ACT_2030
** Reference ID          : ETH_DUD_ACT_2030_GBL001, ETH_DUD_ACT_2030_GBL002
** Reference ID          : ETH_DUD_ACT_2030_REG001, ETH_DUD_ACT_2030_REG002, ETH_DUD_ACT_2030_REG003
** Reference ID          : ETH_DUD_ACT_2030_REG004, ETH_DUD_ACT_2030_REG005, ETH_DUD_ACT_2030_REG006
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_ETND_HwSetOffsetTimeForGptp(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONSTP2CONST(Eth_TimeStampType, AUTOMATIC, ETH_APPL_DATA) LpTimeOffsetPtr)
{
  #if(ETH_DEVICE_NAME == ETH_U5X)
  CONSTP2VAR(volatile Eth_ETND_GPTPCFGRegType, AUTOMATIC, REGSPACE) LpGptpRegs =
    &Eth_GstETND_Regs.pGPTMA->stGptpCfg[ETH_GPTP_TIMER_DOMAIN];

  /* Dummy use to avoid QAC warning about unused parameter */
  (void)LulCtrlIdx;

  /* R-Switch should use only one gPTP timer domain */
  /* Set the upper 16 bit of second part of the GPTP timer GTOVt1 (t = 0 to PTPTN-1) */
  LpGptpRegs->ulGTOVt2 = (uint32)LpTimeOffsetPtr->secondsHi;

  /* Set the lower 32 bit of second part of the GPTP timer GTOVt1 (t = 0 to PTPTN-1) */
  LpGptpRegs->ulGTOVt1 = LpTimeOffsetPtr->seconds;

  /* Set the nanosecond part of the GPTP timer GTOVt0 (t = 0 to PTPTN-1) */
  if (LpTimeOffsetPtr->nanoseconds > ETH_GPTP_OFFSET_NANOSEC_MAXVALUE)
  {
    /* The upper limit is 0x3B9AC9FF */
    LpGptpRegs->ulGTOVt0 = ETH_GPTP_OFFSET_NANOSEC_MAXVALUE;
  }
  else
  {
    LpGptpRegs->ulGTOVt0 = LpTimeOffsetPtr->nanoseconds;
  }
  #elif(ETH_DEVICE_NAME == ETH_X5X)
  Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTOVC2t = (uint32)(uint32)LpTimeOffsetPtr->secondsHi;
  Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTOVC1t = LpTimeOffsetPtr->seconds;
  if (LpTimeOffsetPtr->nanoseconds > ETH_GPTP_OFFSET_NANOSEC_MAXVALUE)
  {
    /* The upper limit is 0x3B9AC9FF */
    Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTOVC0t = ETH_GPTP_OFFSET_NANOSEC_MAXVALUE;
  }
  else
  {
    Eth_GaaTSNES_GPTPRegs[LulCtrlIdx]->PTP[ETH_GPTP_TIMER_DOMAIN].ulPTPTOVC0t = LpTimeOffsetPtr->nanoseconds;
  }
  #endif
  return E_OK;
}

/***********************************************************************************************************************
** Function Name         : Eth_TsDescConfig
**
** Service ID            : NA
**
** Description           : Create timestamp descriptor chain & learning descriptor.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : None
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpETNE_MFWDRegs, Eth_GaaDescTsChain, Eth_GaaDescTsChainTable
**                         Eth_GaaTsDescTotal
**
** Function(s) invoked   : None
**
** Registers Used        : TSSs, TSAs
**
** Reference ID          : ETH_DUD_ACT_2031
** Reference ID          : ETH_DUD_ACT_2031_GBL001, ETH_DUD_ACT_2031_GBL002, ETH_DUD_ACT_2031_GBL003
** Reference ID          : ETH_DUD_ACT_2031_REG001, ETH_DUD_ACT_2031_REG002
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_TsDescConfig(CONST(uint32, AUTOMATIC) LulCtrlIdx)                               /* PRQA S 1505 # JV-01 */
{
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpDescTsChain;                                                 /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs =
    &Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI;
  uint32 LulCnt;

  /* TS descriptor chain setting */
  for (LulCnt = (uint32)ETH_ZERO; LulCnt < Eth_GaaTsDescTotal[LulCtrlIdx]; LulCnt++)
  {
    LpDescTsChain = &Eth_GaaDescTsChainTable[LulCtrlIdx][LulCnt];

    /* Set frame empty type */
    LpDescTsChain->stHeader.ulDie = (uint32)ETH_TS_DESC_DIE_ENABLE;
    LpDescTsChain->stHeader.ulAxie = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulDse = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulInfo0 = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulDs = (uint32)ETH_ZERO;
    LpDescTsChain->ulDptr = (uint32)ETH_ZERO;
    LpDescTsChain->ulInfo1[ETH_ZERO] = (uint32)ETH_ZERO;
    LpDescTsChain->ulInfo1[ETH_ONE] = (uint32)ETH_ZERO;
    LpDescTsChain->ulTsns = (uint32)ETH_ZERO;
    LpDescTsChain->ulTss = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulDt = (uint32)ETH_DESC_FEMPTY_ND;
  }
  /* Set link type for cyclic descriptor */
  LpDescTsChain = &Eth_GaaDescTsChainTable[LulCtrlIdx][LulCnt];
  LpDescTsChain->stHeader.ulDie   = (uint32)ETH_ZERO;
  LpDescTsChain->stHeader.ulAxie  = (uint32)ETH_ZERO;
  LpDescTsChain->stHeader.ulDse   = (uint32)ETH_ZERO;
  LpDescTsChain->stHeader.ulInfo0 = (uint32)ETH_ZERO;
  LpDescTsChain->stHeader.ulDs    = (uint32)ETH_ZERO;
  LpDescTsChain->ulDptr = (uint32)&Eth_GaaDescTsChainTable[LulCtrlIdx][ETH_ZERO];                                       /* PRQA S 0306 # JV-01 */
  LpDescTsChain->ulInfo1[ETH_ZERO] = (uint32)ETH_ZERO;
  LpDescTsChain->ulInfo1[ETH_ONE] = (uint32)ETH_ZERO;
  LpDescTsChain->ulTsns = (uint32)ETH_ZERO;
  LpDescTsChain->ulTss = (uint32)ETH_ZERO;
  LpDescTsChain->stHeader.ulDt = (uint32)ETH_DESC_LINK;

  /* Learning Ts descriptor table */
  LpAxiRegs->stTSD[ETH_ZERO].ulTSSs = ETH_ETND_TSS_CONFIG;
  LpAxiRegs->stTSD[ETH_ZERO].ulTSAs = LpDescTsChain->ulDptr;
}

/***********************************************************************************************************************
** Function Name         : Eth_TasAdminLearning
**
** Service ID            : NA
**
** Description           : Learning TAS admin control list table
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                       : LulCtrlAddress : TAS admin control address.
**                       : LpCtrlConfig : TAS admin control information.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - Succeeded in learning TAS admin control.
**                         E_NOT_OK - Failed in learning TAS admin control.
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETND_Regs
**
** Function(s) invoked   : GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : TACLL0, TACLL1, TACLL2
**
** Reference ID          : ETH_DUD_ACT_2032
** Reference ID          : ETH_DUD_ACT_2032_GBL001
** Reference ID          : ETH_DUD_ACT_2032_REG001, ETH_DUD_ACT_2032_REG002, ETH_DUD_ACT_2032_REG003
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TasAdminLearning(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulCtrlAddress,
  CONSTP2CONST(Eth_TASEntryType, AUTOMATIC, ETH_APPL_DATA) LpCtrlConfig)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  /* Tx Descriptor Address Table learning */
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACLL0 =
    (uint32)(((uint32)LpCtrlConfig->enGateState << (uint32)ETH_TWENTLY_EIGHT) | LpCtrlConfig->ulTimeInterval);
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACLL1 = LulCtrlAddress;
  Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACLL2 = ETH_ETND_TACLL2_LEARNING;

  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
  } while (((uint32)ETH_ZERO != (Eth_GstETND_Regs.pES[LulCtrlIdx]->stMHD.ulTACLL2 & ETH_ETND_TACLL2_LEARNING)) &&       /* PRQA S 3416 # JV-01 */
           (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}
#endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_ETND_SGMII_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_SGMIIInit (ETND)
**
** Service ID            : N/A
**
** Description           : Initialize SGMII for ETND/ETNE HWUnit
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**                       : LenBypassMode : Bypass mode
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GstETNE_Regs, Eth_GstETND_Regs
**
** Function(s) invoked   : None
**
** Registers Used        : ulETNDzSGSRST, ulETNDzSGSDS, ulETNDzSGCLKSEL, ulETNDzSGRCIE, ulETNDzSGINTM
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_SGMIIInit(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(Eth_OptionType, AUTOMATIC) LenBypassMode)
{
  uint8 LucRegVal;
  Std_ReturnType LucResult;
  TickType LulTickStart;
  TickType LulTickElap;

  CONSTP2VAR(volatile Eth_ETND_SGMIIRegType, AUTOMATIC, REGSPACE) LpSgmiiRegs = Eth_GstETND_Regs.pSGMII;
  (void)LulCtrlIdx;

  LucResult = E_OK;

  /* Execute SW-Reset on SGMII interface */
  LpSgmiiRegs->ulETNDzSGSRST = ETH_ETND_SGSRST_SRST;
  LpSgmiiRegs->ulETNDzSGSRST = (uint32)ETH_ZERO;

  /* Wait 4us */
  Eth_WaitNanoSecEtnd(ETH_ETND_WAIT_FOR_SGMII);

  /* Wait until the power supply for the SGMII SerDes is turned on */
  /* (ETNB1SGSDS.PWS[1:0] == 11B) */
  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
    LucRegVal = (uint8)LpSgmiiRegs->stPWRCTL.ulETNDzSGSDS & ETH_ETND_SGSDS_PWS_ON;
  } while ((LucRegVal != ETH_ETND_SGSDS_PWS_ON) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    /* Timeout */
    LucResult = E_NOT_OK;
  } /* else: No action required */


  /* Select the reference clock */
  /* Set the reference clock, enable the clock input and wait until it is stable, if applicable */
  /* This setting is allowed only when MOSC is 20 MHz. */
  LpSgmiiRegs->stPWRCTL.ulETNDzSGCLKSEL = ETH_ETND_SGCLKSEL_SEL;

  /* Wait until the reference clock which is supplied by the external
    oscillator or the internal MainOSC becomes stable */

  /* Enable the reference clock input */
  LpSgmiiRegs->stPWRCTL.ulETNDzSGRCIE = ETH_ETND_SGRCIE_RCIE;

  /* Wait until the SerDes startup is completed */
  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
    LucRegVal = (uint8)LpSgmiiRegs->stPWRCTL.ulETNDzSGSDS & ETH_ETND_SGSDS_SUC;
  } while ((LucRegVal != ETH_ETND_SGSDS_SUC) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if (ETH_TIMEOUT_COUNT < LulTickElap)
  {
    /* Timeout */
    LucResult = E_NOT_OK;
  } /* else: No action required */

  if (ETH_ENABLE == LenBypassMode)
  {
    /* Manual set the operation mode */
    switch (Eth_GpEthConfigPtr[LulCtrlIdx].enEthSpeed)
    {
    case ETH_MAC_LAYER_SPEED_10M:
      /* Set operation mode to 10base */
      LpSgmiiRegs->ulETNDzSGOPMC = ETH_ETND_SGOPMC_10M;
      break;
    case ETH_MAC_LAYER_SPEED_100M:
      /* Set operation mode to 100base */
      LpSgmiiRegs->ulETNDzSGOPMC = ETH_ETND_SGOPMC_100M;
      break;
    default:
      /* Set operation mode to 1000base */
      LpSgmiiRegs->ulETNDzSGOPMC = ETH_ETND_SGOPMC_1G;
      break;
    }
  } /* else: No action required */

  /* Enable Ready Interrupt */
  LpSgmiiRegs->ulETNDzSGINTM = (uint32)ETH_ETND_SGINTM_ENABLE;

  return LucResult;
}
#endif /* #if (ETH_ETND_SGMII_SUPPORT == STD_ON) */
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

#if(ETH_DEVICE_NAME == ETH_U5X)
#if (ETH_ETND_SGMII_SUPPORT == STD_ON)
/***********************************************************************************************************************
** Function Name         : Eth_WaitNanoSecEtnd
**
** Service ID            : NA
**
** Description           : Wait for the specified nanosecond.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulNanosec     : Waiting time (nano sec)
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2034
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_WaitNanoSecEtnd(CONST(uint32, AUTOMATIC) LulNanosec)
{
  CONST(uint32, AUTOMATIC) LulCycle = ETH_NS2HZ(LulNanosec) + (uint32)ETH_ONE;                                          /* PRQA S 3383, 3384, 3469 # JV-01, JV-01, JV-01 */
  volatile uint32 LulCount;

  for (LulCount = (uint32)ETH_ZERO; LulCount < LulCycle; LulCount++)                                                    /* PRQA S 3416, 3387 # JV-01, JV-01 */
  {
    /* No action required */
  }
}
#endif /* #if (ETH_ETND_SGMII_SUPPORT == STD_ON) */
#endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */

/***********************************************************************************************************************
** Function Name         : Eth_TxDescLearning
**
** Service ID            : NA
**
** Description           : Learning tx descriptor chain table
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LpAxiRegs : AXIBMI registers.
**                       : LulEntryNum : Table entry number.
**                       : LulChainAddr : Tx descriptor chain address.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - Succeeded in learning Tx descriptor.
**                         E_NOT_OK - Failed in learning Tx descriptor.
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : TATLS0, TATLS1, TATLR
**
** Reference ID          : ETH_DUD_ACT_2035
** Reference ID          : ETH_DUD_ACT_2035_REG001, ETH_DUD_ACT_2035_REG002, ETH_DUD_ACT_2035_REG003
***********************************************************************************************************************/
FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TxDescLearning(                                                              /* PRQA S 1505 # JV-01 */
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs,
  CONST(uint32, AUTOMATIC) LulEntryNum,
  CONST(uint32, AUTOMATIC) LulChainAddr)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  /* Tx Descriptor Address Table learning */
  LpAxiRegs->ulTATLS0 = ETH_ETND_TATLS0_CONFIG | (LulEntryNum << (uint32)ETH_TWENTLY_FOUR);
  LpAxiRegs->ulTATLS1 = LulChainAddr;
  LpAxiRegs->ulTATLR = ETH_ETND_TATLR_LEARNING;

  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
  } while (((uint32)ETH_ZERO != (LpAxiRegs->ulTATLR & ETH_ETND_TATLR_LEARNING)) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if ((ETH_TIMEOUT_COUNT < LulTickElap) || ((uint32)ETH_ZERO != (LpAxiRegs->ulTATLR & ETH_ETND_TATLR_FAILED)))
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RxDescLearning
**
** Service ID            : NA
**
** Description           : Learning rx descriptor chain table
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LpAxiRegs : AXIBMI registers.
**                       : LulEntryNum : Table entry number.
**                       : LulChainAddr : Rx descriptor chain address.
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - Succeeded in learning Rx descriptor.
**                         E_NOT_OK - Failed in learning Rx descriptor.
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : GetCounterValue, Eth_ETND_GetElapsedTimeValue
**
** Registers Used        : RATLS0, RATLS1, RATLR
**
** Reference ID          : ETH_DUD_ACT_2036
** Reference ID          : ETH_DUD_ACT_2036_REG001, ETH_DUD_ACT_2036_REG002, ETH_DUD_ACT_2036_REG003
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_RxDescLearning(
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs,
  CONST(uint32, AUTOMATIC) LulEntryNum,
  CONST(uint32, AUTOMATIC) LulChainAddr)
{
  TickType LulTickStart;
  TickType LulTickElap;
  Std_ReturnType LucResult;

  /* Rx Descriptor Address Table learning */
  LpAxiRegs->ulRATLS0 = ETH_ETND_RATLS0_CONFIG | (LulEntryNum << (uint32)ETH_TWENTLY_FOUR);
  LpAxiRegs->ulRATLS1 = LulChainAddr;
  LpAxiRegs->ulRATLR = ETH_ETND_RATLR_LEARNING;

  LulTickStart = (uint32)ETH_ZERO;
  LulTickElap = (uint32)ETH_ZERO;
  (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
  do
  {
    LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                            /* PRQA S 3383 # JV-01 */
  } while (((uint32)ETH_ZERO != (LpAxiRegs->ulRATLR & ETH_ETND_RATLR_LEARNING)) && (LulTickElap <= ETH_TIMEOUT_COUNT));

  if ((ETH_TIMEOUT_COUNT < LulTickElap) || ((uint32)ETH_ZERO != (LpAxiRegs->ulRATLR & ETH_ETND_RATLR_FAILED)))
  {
    LucResult = E_NOT_OK;
  }
  else
  {
    LucResult = E_OK;
  }

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_TxRxDescConfig
**
** Service ID            : NA
**
** Description           : Create descriptor chain & learning descriptor.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx : Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : E_OK - Success in learning Tx/Rx descriptor.
**                         E_NOT_OK - Faile in learning Tx/Rx descriptor.
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GaaCtrlStat,
**                         Eth_GstETND_Regs, Eth_GpETNE_MFWDRegs
**
** Function(s) invoked   : Eth_TxDescLearning, Eth_RxDescLearning.
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2037
** Reference ID          : ETH_DUD_ACT_2037_GBL001, ETH_DUD_ACT_2037_GBL002, ETH_DUD_ACT_2037_GBL003
** Reference ID          : ETH_DUD_ACT_2037_GBL004, ETH_DUD_ACT_2037_GBL005, ETH_DUD_ACT_2037_GBL006
** Reference ID          : ETH_DUD_ACT_2037_REG001
***********************************************************************************************************************/
STATIC FUNC(Std_ReturnType, ETH_PRIVATE_CODE) Eth_TxRxDescConfig(CONST(uint32, AUTOMATIC) LulCtrlIdx)                   /* PRQA S 1505 # JV-01 */
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescType, AUTOMATIC, ETH_APPL_DATA) LpDescChain;                                                         /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpDescTsChain;                                                 /* PRQA S 3432 # JV-01 */
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpRxBuffer;                                                                    /* PRQA S 3432 # JV-01 */
  uint32 LulTxQueueMax;
  uint32 LulRxQueueMax;
  uint32 LulRxBufferIndex;
  uint32 LulCntI;
  uint32 LulCntJ;
  uint32 LulCntK;
  uint32 LusBufIdxTmp;
  Std_ReturnType LucResult;

  LucResult = E_OK;
  LulCntK = (uint32)ETH_ZERO;
  LusBufIdxTmp = (uint32)ETH_ZERO;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  LulTxQueueMax = (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfTxQueue;
  LulRxQueueMax = (uint32)LpHwUnitConfig->stQueueConfig.ucNumberOfRxQueue;

  /* Create Tx descriptor */
  for (LulCntI = (uint32)ETH_ZERO; (LulCntI < LulTxQueueMax) && (E_OK == LucResult); LulCntI++)                         /* PRQA S 2995 # JV-01 */
  {
    LpDescChain = &Eth_GaaTxDescTableEtnd[LulCtrlIdx][LulCntK];

    /* Move to the correct index with the next queue */
    LulCntK += LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCntI].ulQueueBufs + ETH_CYCLIC_DESC_NUM;                 /* PRQA S 3383, 3384 # JV-01, JV-01 */

    if (NULL_PTR == LpDescChain)
    {
      LucResult = E_NOT_OK;
      break;
    } /* else: No action required */

    /* Store the head Tx descriptor address */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaNextTxDesc[LulCntI] = LpDescChain;
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulCntI] = LpDescChain;

    /* Set descriptor chain */
    for (LulCntJ = (uint32)ETH_ZERO; LulCntJ < LpHwUnitConfig->stQueueConfig.pTxQueueConfig[LulCntI].ulQueueBufs;
                                                                                                              LulCntJ++)
    {
      /* Set frame empty type */
      LpDescChain->stHeader.ulDie     = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulAxie    = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulDse     = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulInfo0   = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulDs      = (uint32)ETH_ZERO;
      LpDescChain->ulDptr             = (uint32)ETH_ZERO;
      LpDescChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
      LpDescChain->ulInfo1[ETH_ONE]   = (uint32)ETH_ZERO;
      LpDescChain->stHeader.ulDt      = (uint32)ETH_DESC_FEMPTY;

      /* Next data descriptor */
      LpDescChain++;
    }
    /* Set link type for cyclic descriptor */
    LpDescChain->stHeader.ulDie     = (uint32)ETH_ZERO;
    LpDescChain->stHeader.ulAxie    = (uint32)ETH_ZERO;
    LpDescChain->stHeader.ulDse     = (uint32)ETH_ZERO;
    LpDescChain->stHeader.ulInfo0   = (uint32)ETH_ZERO;
    LpDescChain->stHeader.ulDs      = (uint32)ETH_ZERO;
    LpDescChain->ulDptr             = (uint32)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulCntI];               /* PRQA S 0306, 0326 # JV-01, JV-01 */
    LpDescChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
    LpDescChain->ulInfo1[ETH_ONE]   = (uint32)ETH_ZERO;
    LpDescChain->stHeader.ulDt      = (uint32)ETH_DESC_LINK;
  }

  /* Create Rx descriptor */
  LulCntK = (uint32)ETH_ZERO;
  LulRxBufferIndex = (uint32)ETH_ZERO;
  for (LulCntI = (uint32)ETH_ZERO; (LulCntI < LulRxQueueMax) && (E_OK == LucResult); LulCntI++)
  {
    LpDescTsChain = &Eth_GaaRxDescTableEtnd[LulCtrlIdx][LulCntK];

    /* Move to the correct index with the next queue */
    LulCntK += LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCntI].ulQueueBufs + ETH_CYCLIC_DESC_NUM;                 /* PRQA S 3383, 3384 # JV-01, JV-01 */

    if (NULL_PTR == LpDescTsChain)
    {
      LucResult = E_NOT_OK;
      break;
    } /* else: No action required */

    /* Store the head Rx descriptor address */
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulCntI] = LpDescTsChain;

    /* Set Rx descriptor chain */
    for (LulCntJ = (uint32)ETH_ZERO; LulCntJ < LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCntI].ulQueueBufs; LulCntJ++)
    {
      LpRxBuffer = (uint8 *)Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulCntJ].ulbufAddr;                         /* PRQA S 0306, 3383 # JV-01, JV-01 */

      if (NULL_PTR == LpRxBuffer)
      {
        /* Access to the invalid index of array */
        LucResult = E_NOT_OK;
        break;
      } /* else: No action required */

      /* Add receive buffer index */
      *(P2VAR(Eth_BufIdxType, AUTOMATIC, ETH_APPL_DATA))LpRxBuffer = LulRxBufferIndex;                                  /* PRQA S 0310, 3305, 3432 # JV-01, JV-01, JV-01 */
      LulRxBufferIndex++;                                                                                               /* PRQA S 3383 # JV-01 */

      /* Set frame empty type */
      LpDescTsChain->stHeader.ulDie     = (uint32)ETH_RX_DESC_DIE_ENABLE;
      LpDescTsChain->stHeader.ulAxie    = (uint32)ETH_ZERO;
      LpDescTsChain->stHeader.ulDse     = (uint32)ETH_ZERO;
      LpDescTsChain->stHeader.ulInfo0   = (uint32)ETH_ZERO;
      LpDescTsChain->stHeader.ulDs      = LpHwUnitConfig->stRxConfig.ulMaxFrameSize;
      LpDescTsChain->ulDptr             = (uint32)LpRxBuffer;                                                           /* PRQA S 0306 # JV-01 */
      LpDescTsChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
      LpDescTsChain->ulInfo1[ETH_ONE]   = (uint32)ETH_ZERO;
      LpDescTsChain->ulTsns             = (uint32)ETH_ZERO;
      LpDescTsChain->ulTss              = (uint32)ETH_ZERO;
      LpDescTsChain->stHeader.ulDt      = (uint32)ETH_DESC_FEMPTY;

      /* Hold the Rx descriptor address according to with Rx buffer for future manage */
      Eth_GaaRxBufferNodes[LulCtrlIdx][LusBufIdxTmp + LulCntJ].ulRxDescAddr = (uint32)LpDescTsChain;                    /* PRQA S 0306, 3383 # JV-01, JV-01 */

      /* Next data descriptor */
      LpDescTsChain++;
    }
    /* Set link type for cyclic descriptor */
    LpDescTsChain->stHeader.ulDie     = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulAxie    = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulDse     = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulInfo0   = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulDs      = (uint32)ETH_ZERO;
    LpDescTsChain->ulDptr             = (uint32)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulCntI];             /* PRQA S 0306, 0326 # JV-01, JV-01 */
    LpDescTsChain->ulInfo1[ETH_ZERO]  = (uint32)ETH_ZERO;
    LpDescTsChain->ulInfo1[ETH_ONE] = (uint32)ETH_ZERO;
    LpDescTsChain->ulTsns           = (uint32)ETH_ZERO;
    LpDescTsChain->ulTss            = (uint32)ETH_ZERO;
    LpDescTsChain->stHeader.ulDt    = (uint32)ETH_DESC_LINK;

    /* Caculate the buffer index for the next queue */
    LusBufIdxTmp += LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulCntI].ulQueueBufs;                                  /* PRQA S 3383 # JV-01 */
  }

  if (E_OK == LucResult)
  {
    /* Learning Tx descriptor table */
    for (LulCntI = (uint32)ETH_ZERO; LulCntI < LulTxQueueMax; LulCntI++)
    {
      LucResult |= Eth_TxDescLearning(&Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI,
                                      LulCntI,
                                      (uint32)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadTxDesc[LulCntI]);              /* PRQA S 0306, 0326 # JV-01, JV-01 */
    }

    /* Learning Rx descriptor table */
    for (LulCntI = (uint32)ETH_ZERO; LulCntI < LulRxQueueMax; LulCntI++)
    {
      LucResult |= Eth_RxDescLearning(&Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI,
                                      LulCntI,
                                      (uint32)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulCntI]);              /* PRQA S 0306, 0326 # JV-01, JV-01 */
    }
  } /* else: No action required */

  return LucResult;
}

/***********************************************************************************************************************
** Function Name         : Eth_RxQueueProcess
**
** Service ID            : NA
**
** Description           : Process Receive Queue.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Instance number
**                       : LulQueueIdx - Rx queue index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : When polling mode:
**                           ETH_EXT_NOT_RECEIVED : there was no received frame
**                           ETH_EXT_RECEIVED     : there was one received frame
**                           ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE:
**                                 there were more than one received frames
**                           ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE:
**                                 there was no received, but there are still receive frames.
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr, Eth_GstETND_Regs, Eth_GaaCtrlStat, Eth_GaaRxBufferDataTable
**                         Eth_CtrlRxMaxFrameLengthMapping, Eth_GaaRxBufferNodes, Eth_GaaRxFrame
**
** Function(s) invoked   : Eth_IsRxFrameValid
**                         Eth_RxCallEthIf, EthSwt_EthRxProcessFrame, EthSwt_EthRxFinishedIndication
**                         GetCounterValue, Eth_ETND_GetElapsedTimeValue, Eth_RxDescLearning
**
** Registers Used        : RFEISi, RATS, RATSR0, RATSR1, RATSR2
**
** Reference ID          : ETH_DUD_ACT_2038
** Reference ID          : ETH_DUD_ACT_2038_GBL001, ETH_DUD_ACT_2038_GBL002, ETH_DUD_ACT_2038_GBL003
** Reference ID          : ETH_DUD_ACT_2038_GBL004, ETH_DUD_ACT_2038_GBL005, ETH_DUD_ACT_2038_GBL006
** Reference ID          : ETH_DUD_ACT_2038_GBL007
** Reference ID          : ETH_DUD_ACT_2038_REG001, ETH_DUD_ACT_2038_REG002, ETH_DUD_ACT_2038_REG003
** Reference ID          : ETH_DUD_ACT_2038_REG004, ETH_DUD_ACT_2038_REG005
***********************************************************************************************************************/
FUNC(Eth_ExtRxStatusType, ETH_PRIVATE_CODE) Eth_RxQueueProcess(                                                         /* PRQA S 1505 # JV-01 */
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulQueueIdx)
{
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */
  CONSTP2VAR(volatile Eth_ETND_AXIBMIRegType, AUTOMATIC, REGSPACE) LpAxiRegs =
  &Eth_GstETND_Regs.pES[LulCtrlIdx]->stAXIBMI;
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                    /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpTempDesc;                                                    /* PRQA S 3432 # JV-01 */
  P2VAR(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode;                                                  /* PRQA S 3432 # JV-01 */
  uint32 LulRxQueueOffset;
  boolean LblRxFrameValid;

  TickType LulTickStart;
  TickType LulTickElap;
  uint32 LulIntStat;
  Eth_ExtRxStatusType LenRetValue;
  Eth_BufIdxType LulBufIdx;

  #if (ETH_DEVICE_NAME == ETH_U5X)
  Eth_RxBufWarnLvlUserCalloutPtrType LpRxBufWarnLvlUserCallout;
  #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

  #if (ETH_GET_RX_STATS_API == STD_ON)
  uint32 LulLengthWithFCS;
  #endif

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA) LpDataPtr;                                                                     /* PRQA S 3432 # JV-01 */
  boolean LblIsMgmtFrameOnlyPtr;
  uint16 LusLength;
  Std_ReturnType LucReturnValue;
  #endif

  LenRetValue = ETH_EXT_NOT_RECEIVED;

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  LulRxQueueOffset = (uint32)LpHwUnitConfig->stQueueConfig.ucOffsetOfRxQueue;

  /* Get descriptor for read */
  LpDataDesc = (Eth_ExtDescWithTsType *)Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulQueueIdx];                 /* PRQA S 0316 # JV-01 */
  LpTempDesc = LpDataDesc;

  if (ETH_DESC_FSINGLE == LpDataDesc->stHeader.ulDt)
  {
    /* Set descriptor to be read next */
    LpTempDesc++;
    while ((LpTempDesc->stHeader.ulDt == ETH_DESC_LINK) || (LpTempDesc->stHeader.ulDt == ETH_DESC_LEMPTY))
    {
      LpTempDesc->stHeader.ulDt = (uint32)ETH_DESC_LINK;
      LpTempDesc = (P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA))LpTempDesc->ulDptr;                          /* PRQA S 0306, 3432 # JV-01, JV-01 */
    }
    Eth_GaaCtrlStat[LulCtrlIdx].stHwStat.aaHeadRxDesc[LulQueueIdx] = LpTempDesc;

    /* Get Buffer index infor base on buffer address */
    LulBufIdx = (Eth_BufIdxType)((uint8*)(LpDataDesc->ulDptr)                                                           /* PRQA S 0306 # JV-01 */
                  - Eth_GaaRxBufferDataTable[LulCtrlIdx]) / Eth_CtrlRxMaxFrameLengthMapping[LulCtrlIdx];                /* PRQA S 0488 # JV-01 */
    /* Get the Rx Buffer Node infor */
    LpRxBufferNode = &Eth_GaaRxBufferNodes[LulCtrlIdx][LulBufIdx];

    /* Verify the status of buffer and descriptor mapping */
    if ((LpRxBufferNode->blLockedFlag == ETH_FALSE) && (LpRxBufferNode->ulRxDescAddr == (uint32)LpDataDesc))            /* PRQA S 0306 # JV-01 */
    {
      /* Check whether received frame is valid or not */
      LblRxFrameValid = Eth_IsRxFrameValid(LulCtrlIdx, LpDataDesc->ulDptr);

      if  ((ETH_TRUE == LblRxFrameValid)
        && (ETH_ETND_INFO0_SEI_MASK != (ETH_ETND_INFO0_SEI_MASK & LpDataDesc->stHeader.ulInfo0)))
      {
        /* Lock Rx buffer */
        LpRxBufferNode->blLockedFlag = ETH_TRUE;

        /* Set Rx descriptor info */
        Eth_GaaRxFrame[LulCtrlIdx].ulFrameAddr   = LpDataDesc->ulDptr;
        Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = LpDataDesc->ulDptr + ETH_SRC_DST_ADDRESS_SIZE;                       /* PRQA S 3383 # JV-01 */
        Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = LpDataDesc->stHeader.ulDs;
        #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
        Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.nanoseconds = LpDataDesc->ulTsns;
        Eth_GaaRxFrame[LulCtrlIdx].stTimeStamp.seconds  = LpDataDesc->ulTss;
        Eth_GaaRxFrame[LulCtrlIdx].enTimeQual  = ETH_VALID;
        #endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */
   
        #if (ETH_DEVICE_NAME == ETH_U5X)
        /* Increase the Buffer warning level counter */
        Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LulQueueIdx] = 
                      Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LulQueueIdx] + ETH_ONE;                                    /* PRQA S 3383 # JV-01 */

        #if (ETH_GET_AND_RESET_MEASUREMENTDATA_API == STD_ON)
        /* Increase the Measurement counter for Buffer warning level */
        Eth_GaaCtrlStat[LulCtrlIdx].stMeasurementData.ulWarnFullRxBuffCnt++;
        #endif

        if (LpHwUnitConfig->stQueueConfig.pRxQueueConfig[LulQueueIdx].ulQueueBufs < 
                                          Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LulQueueIdx])
        {
          /* All Rx buffers are occupied: */
          LpRxBufWarnLvlUserCallout = ETH_GET_USER_RXBUFF_WARNING_CALLOUT;
          if (NULL_PTR != LpRxBufWarnLvlUserCallout)                                                                    /* PRQA S 2991, 2992, 2995, 2996 # JV-01, JV-01, JV-01, JV-01 */
          {
            /* Call to the user Rx buffer warning call out function */
            LpRxBufWarnLvlUserCallout(LulCtrlIdx, LulQueueIdx);
          }/* else No action required */
        }/* else No action required */
        #endif /* #if (ETH_DEVICE_NAME == ETH_U5X) */

        if (ETH_DESC_FSINGLE == LpTempDesc->stHeader.ulDt)
        {
          /* More frames are available */
          LenRetValue = ETH_EXT_RECEIVED_MORE_DATA_AVAILABLE;
        }
        else
        {
          /* Frame valid - Update status */
          LenRetValue = ETH_EXT_RECEIVED;
        }

        #if (ETH_GET_RX_STATS_API == STD_ON)
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts++;                                                             /* PRQA S 3383 # JV-01 */
        LulLengthWithFCS = Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength + ETH_FCS_LENGTH;                                   /* PRQA S 3383 # JV-01 */
        Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsOctets += LulLengthWithFCS;                                         /* PRQA S 3383 # JV-01 */
        if (LulLengthWithFCS <= (uint32)ETH_LENGTH_64B)
        {
          /* Since the receive data size that does not include padding data is set in the receive descriptor,
            frames of 64 or less are collected by the statistical counter. */
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts64Octets++;                                                   /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_127B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts65to127Octets++;                                              /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_255B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts128to255Octets++;                                             /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_511B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts256to511Octets++;                                             /* PRQA S 3383 # JV-01 */
        }
        else if (LulLengthWithFCS <= (uint32)ETH_LENGTH_1023B)
        {
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts512to1023Octets++;                                            /* PRQA S 3383 # JV-01 */
        }
        else
        {
          /* When VLAN tag is supported, the maximum data size is 1522. */
          /* The maximum frame size that HW can receive is set to 1522. */
          Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxStatsPkts1024to1518Octets++;                                           /* PRQA S 3383 # JV-01 */
        }
        #endif

        #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
        LpDataPtr = (P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr;                   /* PRQA S 0306, 3432 # JV-01, JV-01 */
        /* Since the maximum value of buffer size is 1518, casting to uint16 does no problem. */
        LusLength = (uint16)(Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength - ETH_HEADER_SIZE);                               /* PRQA S 3383 # JV-01 */
        LblIsMgmtFrameOnlyPtr = ETH_FALSE;
        /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
        LucReturnValue = EthSwt_EthRxProcessFrame((uint8)LulCtrlIdx, LulBufIdx, &LpDataPtr,
                                                  &LusLength, &LblIsMgmtFrameOnlyPtr);
        if (E_OK == LucReturnValue)
        {
          Eth_GaaRxFrame[LulCtrlIdx].ulEthTypeAddr = (uint32)LpDataPtr;                                                 /* PRQA S 0306 # JV-01 */
          Eth_GaaRxFrame[LulCtrlIdx].ulFrameLength = (uint32)(LusLength + ETH_HEADER_SIZE);                             /* PRQA S 3383 # JV-01 */

          if (ETH_FALSE == LblIsMgmtFrameOnlyPtr)
          {
            /* Call EthIf if the Frame Received is valid */
            Eth_RxCallEthIf(LulCtrlIdx, LulQueueIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
          }
          else
          {
            /* Must not be the Rx processed */
            /* Since the maximum value of controller index is 1, casting to uint8 does no problem. */
            (void)EthSwt_EthRxFinishedIndication((uint8)LulCtrlIdx, LulBufIdx);
          }
        }
        else
        {
          /* Normal operation if E_NOT_OK */
          Eth_RxCallEthIf(LulCtrlIdx, LulQueueIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
        }
        #else
        /* Call EthIf if the Frame Received is valid */
        Eth_RxCallEthIf(LulCtrlIdx, LulQueueIdx, &Eth_GaaRxFrame[LulCtrlIdx], LulBufIdx);
        #endif
      }
      else
      {
        /* Frame Invalid - E.g. Multicast to be discarded */
        /* No Call of EthIf */
        if (ETH_DESC_FSINGLE == LpTempDesc->stHeader.ulDt)
        {
          /* Not received, but more frames are available */
          LenRetValue = ETH_EXT_NOT_RECEIVED_MORE_DATA_AVAILABLE;
        } /* else: No action required */

        /* Reset Rx descriptor */
        LpDataDesc->stHeader.ulDie   = (uint32)ETH_RX_DESC_DIE_ENABLE;
        LpDataDesc->stHeader.ulAxie  = (uint32)ETH_ZERO;
        LpDataDesc->stHeader.ulDse   = (uint32)ETH_ZERO;
        LpDataDesc->stHeader.ulInfo0 = (uint32)ETH_ZERO;
        LpDataDesc->stHeader.ulDs    = LpHwUnitConfig->stRxConfig.ulMaxFrameSize;
        LpDataDesc->ulInfo1[ETH_ZERO] = (uint32)ETH_ZERO;
        LpDataDesc->ulInfo1[ETH_ONE]  = (uint32)ETH_ZERO;
        LpDataDesc->ulTsns           = (uint32)ETH_ZERO;
        LpDataDesc->ulTss            = (uint32)ETH_ZERO;
        /* Do not move this process due to descriptor exclusive control */
        LpDataDesc->stHeader.ulDt    = (uint32)ETH_DESC_FEMPTY;
      }
    } /* else - The Rx buffer is locked */
  } /* else: No action required */

  /* Get rx descriptor full interrupt status */
  LulIntStat = ETH_GET_RX_FULL_INT_STAT(LulQueueIdx, LpAxiRegs->stRXDFEI[ETH_ZERO].ulRFEISi, LulRxQueueOffset);         /* PRQA S 3469 # JV-01 */
  if ((uint32)ETH_ZERO != LulIntStat)
  {
    /* Searching rx descriptor chain table */
    LpAxiRegs->ulRATS = LulQueueIdx + LulRxQueueOffset;                                                                 /* PRQA S 3383 # JV-01 */
    LpAxiRegs->ulRATSR2 = ETH_ETND_RATSR2_SEARCHING;

    /* Rx Descriptor Address Table searching waiting */
    LulTickStart = (uint32)ETH_ZERO;
    LulTickElap = (uint32)ETH_ZERO;
    (void)GetCounterValue(ETH_OS_COUNTER_ID, &LulTickStart);
    do
    {
      LulTickElap = LulTickElap + Eth_ETND_GetElapsedTimeValue(&LulTickStart);                                          /* PRQA S 3383 # JV-01 */
    } while (((uint32)ETH_ZERO != LpAxiRegs->ulRATSR2) && (LulTickElap <= ETH_TIMEOUT_COUNT));

    if (ETH_TIMEOUT_COUNT >= LulTickElap)
    {
      /* Clear rx descriptor full interrupt status */
      LpAxiRegs->stRXDFEI[LulCtrlIdx].ulRFEISi = LulIntStat;
      if ((uint32)ETH_ZERO == (LpAxiRegs->ulRATSR0 & ETH_ETND_RATLS0_CHAIN_ENTRY_INVALID))
      {
        /* Re-learning rx descriptor chain table */
        (void)Eth_RxDescLearning(LpAxiRegs, LpAxiRegs->ulRATS, (uint32)LpAxiRegs->ulRATSR1);                            /* PRQA S 0404 # JV-01 */
      } /* else: No action required */
    } /* else: No action required */
  } /* else: No action required */
  return LenRetValue;
}

/***********************************************************************************************************************
** Function Name         : Eth_IsRxFrameValid
**
** Service ID            : NA
**
** Description           : Compare Mac Address Frame just received with
**                         Broadcast and Controller Mac Address.
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx   - Controller / Channel Index
**                         LulFrameAddr - Pointer to the Frame Address just received
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LblPass
**                         True : Frame DA is Broadcast or
**                         matches with the Source Address of this Controller
**                         False : Otherwise
**
** Preconditions         : None
**
** Global Variables Used : Eth_GaaCtrlStat, Eth_GstBroadcastAddr, Eth_GaaAddressFilters,
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2039
** Reference ID          : ETH_DUD_ACT_2039_GBL001, ETH_DUD_ACT_2039_GBL002, ETH_DUD_ACT_2039_GBL003
***********************************************************************************************************************/
STATIC FUNC(boolean, ETH_PRIVATE_CODE) Eth_IsRxFrameValid(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulFrameAddr)
{
  Eth_MacAddressType LstDstAddress;
  boolean LblPass;
  uint32 LulFilterIdx;
  uint32 LulRemainBits;

  LblPass = ETH_FALSE;
  ETH_PACK_ADDRESS_FROM_8(((P2VAR(uint8, AUTOMATIC, ETH_APPL_DATA))LulFrameAddr), LstDstAddress);                       /* PRQA S 0306, 3432, 3469 # JV-01, JV-01, JV-01 */

  /* Check whether promiscuous mode, broadcast, own unicast, multicast address is not registed */
  if ((ETH_TRUE == Eth_GaaCtrlStat[LulCtrlIdx].blPromiscuous) ||
      ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstDstAddress, Eth_GstBroadcastAddr)) ||                                     /* PRQA S 3469 # JV-01 */
      ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstDstAddress, Eth_GaaCtrlStat[LulCtrlIdx].stMacAddr)))                      /* PRQA S 3469 # JV-01 */
  {
    LblPass = ETH_TRUE;
  }
  else
  {
    /* Otherwise, do the filter operation */

    /* To skip empty filters efficiently, copy active bits to the local var */
    LulRemainBits = Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits;
    LulFilterIdx = (uint32)ETH_ZERO;
    /* Loop until any filter hits or pass all active filters */
    while ((uint32)ETH_ZERO != LulRemainBits)
    {
      if (((uint32)ETH_ZERO != (LulRemainBits & ((uint32)ETH_ONE << LulFilterIdx))) &&
          ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstDstAddress, Eth_GaaAddressFilters[LulCtrlIdx][LulFilterIdx])))        /* PRQA S 3469 # JV-01 */
      {
        LblPass = ETH_TRUE;
        break;
      } /* else: No action required */

      /* Clear the compared filter bit */
      LulRemainBits &= ~((uint32)ETH_ONE << LulFilterIdx);
      LulFilterIdx++;                                                                                                   /* PRQA S 3383 # JV-01 */
    }
  }

  return LblPass;
}

/***********************************************************************************************************************
** Function Name         : Eth_RxCallEthIf
**
** Service ID            : NA
**
** Description           : Wrapper for the Callback to the Eth Interface
**                         for each frame received
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non-Reentrant
**
** Input Parameters      : LulCtrlIdx - Controller / Channel Index
**                       : LpFrame - Address of the Received Frame in URAM
**                       : LulBufIdx - Buffer index
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : NA
**
** Global Variables Used : Eth_GstBroadcastAddr, Eth_GaaCtrlStat, Eth_GaaTimeTuple
**
** Function(s) invoked   : EthIf_RxIndication, EthSwt_EthRxFinishedIndication,
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2040
** Reference ID          : ETH_DUD_ACT_2040_GBL001, ETH_DUD_ACT_2040_GBL002, ETH_DUD_ACT_2040_GBL003
***********************************************************************************************************************/
STATIC FUNC(void, ETH_PRIVATE_CODE) Eth_RxCallEthIf(
  CONST(uint32, AUTOMATIC) LulCtrlIdx,
  CONST(uint32, AUTOMATIC) LulQueueIdx,
  CONSTP2CONST(Eth_RxFrameType, AUTOMATIC, ETH_APPL_DATA) LpFrame,
  CONST(Eth_BufIdxType, AUTOMATIC) LulBufIdx)
{
  boolean LblBroadcast;
  P2CONST(Eth_DataType, AUTOMATIC, ETH_APPL_DATA) LpFrameType;                                                          /* PRQA S 3432 # JV-01 */
  Eth_FrameType LddFrameType;
  Eth_MacAddressType LstMacAddr;
  P2CONST(Eth_EtherFrameType, AUTOMATIC, ETH_APPL_DATA) LstEtherFrame;                                                  /* PRQA S 3432 # JV-01 */
  P2VAR(TimeTupleType, AUTOMATIC, ETH_APPL_DATA)LpTimeTuplePtr;                                                         /* PRQA S 3432 # JV-01 */

  LpTimeTuplePtr = &Eth_GaaTimeTuple[LulCtrlIdx][LulQueueIdx];

  LstEtherFrame = (P2CONST(Eth_EtherFrameType, AUTOMATIC, ETH_APPL_DATA)) LpFrame->ulFrameAddr;                         /* PRQA S 0306, 3432 # JV-01, JV-01 */
  ETH_PACK_ADDRESS_FROM_8(LstEtherFrame->ucDstAddr, LstMacAddr);                                                        /* PRQA S 3469 # JV-01 */

  if ((uint32)ETH_ZERO == ETH_COMPARE_MAC(LstMacAddr, Eth_GstBroadcastAddr))                                            /* PRQA S 3469 # JV-01 */
  {
    LblBroadcast = ETH_TRUE;
  }
  else
  {
    LblBroadcast = ETH_FALSE;
    #if (ETH_GET_RX_STATS_API == STD_ON)
    if ((uint32)ETH_ZERO == ETH_CHECK_MULTICAST(LstMacAddr))                                                            /* PRQA S 3469 # JV-01 */
    {
      /* Unicast frame */
      Eth_GaaCtrlStat[LulCtrlIdx].stRxStat.RxUnicastFrames++;                                                           /* PRQA S 3383 # JV-01 */
    } /* else: No action required */
    #endif
  }

  LpFrameType = (const Eth_DataType *)LpFrame->ulEthTypeAddr;                                                           /* PRQA S 0306 # JV-01 */
  LddFrameType = (Eth_FrameType)((uint32)LpFrameType[ETH_ZERO] << ETH_BYTE_BITS);
  LddFrameType |= (Eth_FrameType)LpFrameType[ETH_ONE];

  /* SWS_Eth_00327 */
  #if (ETH_GLOBAL_TIME_SUPPORT == STD_ON)
  /* SWS_Eth_00323 */
  /* Get the ingress timestamp from current RxFrame */
  LpTimeTuplePtr->timestampClockValue.nanoseconds   = (uint32)LpFrame->stTimeStamp.nanoseconds;
  LpTimeTuplePtr->timestampClockValue.seconds       = (uint32)LpFrame->stTimeStamp.seconds;
  LpTimeTuplePtr->timestampClockValue.secondsHi     = (uint16)ETH_ZERO;
  /* Since there is no xtimestamp support */
  LpTimeTuplePtr->disciplinedClockValue.nanoseconds = LpTimeTuplePtr->timestampClockValue.nanoseconds;
  LpTimeTuplePtr->disciplinedClockValue.seconds     = LpTimeTuplePtr->timestampClockValue.seconds;
  LpTimeTuplePtr->disciplinedClockValue.secondsHi   = LpTimeTuplePtr->timestampClockValue.secondsHi;
  LpTimeTuplePtr->timeQuality                       = ETH_VALID;
  /* SWS_Eth_00324 */
  #else
  /* Set the timestamp as invalid */
  LpTimeTuplePtr->timestampClockValue.nanoseconds   = (uint32)ETH_ZERO;
  LpTimeTuplePtr->timestampClockValue.seconds       = (uint32)ETH_ZERO;
  LpTimeTuplePtr->timestampClockValue.secondsHi     = (uint16)ETH_ZERO;
  /* Since there is no xtimestamp support */
  LpTimeTuplePtr->disciplinedClockValue.nanoseconds = LpTimeTuplePtr->timestampClockValue.nanoseconds;
  LpTimeTuplePtr->disciplinedClockValue.seconds     = LpTimeTuplePtr->timestampClockValue.seconds;
  LpTimeTuplePtr->disciplinedClockValue.secondsHi   = LpTimeTuplePtr->timestampClockValue.secondsHi;
  LpTimeTuplePtr->timeQuality                       = ETH_INVALID;
  #endif /* (ETH_GLOBAL_TIME_SUPPORT == STD_ON) */

  /* Since the maximum value of Controller Index is 1, casting to uint8 does no problem. */
  EthIf_RxIndication((uint8)LulCtrlIdx, LddFrameType, LblBroadcast, LstEtherFrame->ucSrcAddr,
    LpFrameType + ETH_ETHERTYPE_SIZE, (uint16)(LpFrame->ulFrameLength - ETH_HEADER_SIZE),                               /* PRQA S 0488, 3383 # JV-01, JV-01 */
    LpTimeTuplePtr, LulBufIdx);

  #if (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON)
  (void)EthSwt_EthRxFinishedIndication((uint8)LulCtrlIdx, LulBufIdx);
  #endif /* (ETH_ETHSWITCH_MANAGEMENT_SUPPORT == STD_ON) */
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_GetElapsedTimeValue
**
** Service ID            : NA
**
** Description           : This returns the elapsed timeout value of  Os timer
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Reentrant
**
** Input Parameters      : LusTimeOutCount
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : LulTimeOutCount_Elapsed - TickType
**
** Preconditions         : None
**
** Global Variable(s)    : None
**
** Function(s) invoked   : GetCounterValue
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2041
***********************************************************************************************************************/
FUNC(TickType, ETH_PRIVATE_CODE) Eth_ETND_GetElapsedTimeValue(                                                          /* PRQA S 1505 # JV-01 */
  P2VAR(TickType, AUTOMATIC, ETH_APPL_DATA) LusTimeOutCount)                                                            /* PRQA S 3432 # JV-01 */
{
  TickType LulTimeOutCount_Curr;
  TickType LulTimeOutCount_Elapsed;
  TickType LusTimeOutCount_Init;

  LusTimeOutCount_Init = *LusTimeOutCount;

  LulTimeOutCount_Curr = (uint32)ETH_ZERO;

  /* Get the current tick value from OS Counter */
  (void)GetCounterValue((CounterType)ETH_OS_COUNTER_ID, &LulTimeOutCount_Curr);

  /* Check whether current time out exceeds inital time out value */
  if (LulTimeOutCount_Curr >= LusTimeOutCount_Init)
  {
    /* Get elapsed time out count */
    LulTimeOutCount_Elapsed = LulTimeOutCount_Curr - LusTimeOutCount_Init;
  }
  else
  {
    /* Get elapsed time out count */
    LulTimeOutCount_Elapsed = ((uint32)ETH_OS_COUNTER_MAX_VALUE - LusTimeOutCount_Init) + LulTimeOutCount_Curr;         /* PRQA S 3383 # JV-01 */
  }

  *LusTimeOutCount = LulTimeOutCount_Curr;

  return LulTimeOutCount_Elapsed;
}

/***********************************************************************************************************************
** Function Name         : Eth_ETND_ResetRxDesc
**
** Service ID            : NA
**
** Description           : Reset the RX descriptor
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant for the same Ctrl ,
**                         Re-entrant for different
**
** Input Parameters      : LulCtrlIdx     : Index of a controller
**                         LpRxBufferNode : Pointer to Rx buffer node
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : Component Requires previous controller
**                         initialization using Eth_ControllerInit..
**
** Global Variable(s)    : Eth_GpCtrlConfigPtr
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_2042
** Reference ID          : ETH_DUD_ACT_2042_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ETND_ResetRxDesc(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_RxBufManageType, AUTOMATIC, ETH_APPL_DATA) LpRxBufferNode)
{
  P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA) LpDataDesc;                                                    /* PRQA S 3432 # JV-01 */
  P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA) LpHwUnitConfig;                                                 /* PRQA S 3432 # JV-01 */

  LpHwUnitConfig =
    (P2CONST(Eth_ETNDConfigType, AUTOMATIC, ETH_APPL_DATA))Eth_GpCtrlConfigPtr[LulCtrlIdx].pHwUnitConfig;               /* PRQA S 0316, 3432 # JV-01, JV-01 */
  /* Get the Rx Descriptor */
  LpDataDesc = (P2VAR(Eth_ExtDescWithTsType, AUTOMATIC, ETH_APPL_DATA)) (LpRxBufferNode->ulRxDescAddr);                 /* PRQA S 0306, 3432 # JV-01, JV-01 */

  /* Reset Rx descriptor */
  LpDataDesc->stHeader.ulDie   = (uint32)ETH_RX_DESC_DIE_ENABLE;
  LpDataDesc->stHeader.ulAxie  = (uint32)ETH_ZERO;
  LpDataDesc->stHeader.ulDse   = (uint32)ETH_ZERO;
  LpDataDesc->stHeader.ulInfo0 = (uint32)ETH_ZERO;
  LpDataDesc->stHeader.ulDs    = LpHwUnitConfig->stRxConfig.ulMaxFrameSize;
  LpDataDesc->ulInfo1[ETH_ZERO] = (uint32)ETH_ZERO;
  LpDataDesc->ulInfo1[ETH_ONE]  = (uint32)ETH_ZERO;
  LpDataDesc->ulTsns           = (uint32)ETH_ZERO;
  LpDataDesc->ulTss            = (uint32)ETH_ZERO;
  /* Do not move this process due to descriptor exclusive control */
  LpDataDesc->stHeader.ulDt    = (uint32)ETH_DESC_FEMPTY;

  #if(ETH_DEVICE_NAME == ETH_U5X)
  /* Decrease the Buffer warning level counter */
  Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LpRxBufferNode->ucRxQueueIdx] = 
                Eth_GaaRxBufferWarnLvlStat[LulCtrlIdx][LpRxBufferNode->ucRxQueueIdx] - ETH_ONE;                         /* PRQA S 3383 # JV-01 */
  #endif /* #if(ETH_DEVICE_NAME == ETH_U5X) */
}

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */
#endif /* (ETH_MACRO_ETND == STD_ON) */
/***********************************************************************************************************************
**                                                    End of File                                                     **
***********************************************************************************************************************/

