/*====================================================================================================================*/
/* Project      = RCar Gen5 AUTOSAR MCAL Platform                                                                     */
/* Module       = Eth_Filter.c                                                                                        */
/*====================================================================================================================*/
/*                                  COPYRIGHT                                                                         */
/*====================================================================================================================*/
/* Copyright(c) 2024-2025 Renesas Electronics Corporation. All rights reserved.                                       */
/*====================================================================================================================*/
/* Purpose:                                                                                                           */
/* This file contains software filter functions implementation of Eth Driver Component.                               */
/*====================================================================================================================*/
/*                                                                                                                    */
/* Unless otherwise agreed upon in writing between your company and Renesas Electronics Corporation the following     */
/* shall apply!                                                                                                       */
/*                                                                                                                    */
/* Warranty Disclaimer                                                                                                */
/*                                                                                                                    */
/* There is no warranty of any kind whatsoever granted by Renesas. Any warranty is expressly disclaimed and excluded  */
/* by Renesas, either expressed or implied, including but not limited to those for non-infringement of intellectual   */
/* property, merchantability and/or fitness for the particular purpose.                                               */
/*                                                                                                                    */
/* Renesas shall not have any obligation to maintain, service or provide bug fixes for the supplied Product(s)        */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/* Each User is solely responsible for determining the appropriateness of using the Product(s) and assumes all risks  */
/* associated with its exercise of rights under this Agreement, including, but not limited to the risks and costs     */
/* of program errors, compliance with applicable laws, damage to or loss of data, programs or equipment,              */
/* and unavailability or interruption of operations.                                                                  */
/*                                                                                                                    */
/* Limitation of Liability                                                                                            */
/*                                                                                                                    */
/* In no event shall Renesas be liable to the User for any incidental, consequential, indirect, or punitive damage    */
/* (including but not limited to lost profits) regardless of whether such liability is based on breach of contract,   */
/* tort, strict liability, breach of warranties, failure of essential purpose or otherwise and even if advised of the */
/* possibility of such damages. Renesas shall not be liable for any services or products provided by third party      */
/* vendors, developers or consultants identified or referred to the User by Renesas in connection with the Product(s) */
/* and/or the Application.                                                                                            */
/*                                                                                                                    */
/*====================================================================================================================*/
/* Environment:                                                                                                       */
/*              Devices:   U5x/X5H                                                                                    */
/*====================================================================================================================*/

/***********************************************************************************************************************
**                                          Revision Control History                                                  **
***********************************************************************************************************************/
/*
 * 1.0.2: 16/09/2025    : Update to support TSN-ES
 * 1.0.1: 24/04/2025    : Update to remove macro ETH_UPDATE_PHYS_ADDR_FILTER
 * 1.0.0: 09/04/2024    : Initial Version
 */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                                       Include Section                                                              **
***********************************************************************************************************************/
#include "Eth.h"
#include "Eth_Ram.h"
#if (ETH_MACRO_RSW3 == STD_ON)
#include "Eth_RSW3_Ram.h"
#endif  /* #if (ETH_MACRO_RSW3 == STD_ON) */
#if (ETH_MACRO_ETND == STD_ON)
#if(ETH_DEVICE_NAME == ETH_U5X)
#include "Eth_ETND_Ram.h"
#elif(ETH_DEVICE_NAME == ETH_X5X)
#include "Eth_RSW3_TSNES_Ram.h"
#endif  /* #if(ETH_DEVICE_NAME) */
#endif /* #if (ETH_MACRO_ETND == STD_ON) */
#if (ETH_MACRO_ETNF == STD_ON)
#include "Eth_ETNF_Ram.h"
#endif /* #if (ETH_MACRO_ETNF == STD_ON) */
#include "Eth_Filter.h"

/***********************************************************************************************************************
**                      Version Information                                                                           **
***********************************************************************************************************************/
/* AUTOSAR release version information */
#define ETH_FILTER_C_AR_RELEASE_MAJOR_VERSION ETH_AR_RELEASE_MAJOR_VERSION_VALUE
#define ETH_FILTER_C_AR_RELEASE_MINOR_VERSION ETH_AR_RELEASE_MINOR_VERSION_VALUE
#define ETH_FILTER_C_AR_RELEASE_REVISION_VERSION ETH_AR_RELEASE_REVISION_VERSION_VALUE

/* File version information */
#define ETH_FILTER_C_SW_MAJOR_VERSION    ETH_SW_MAJOR_VERSION_VALUE
#define ETH_FILTER_C_SW_MINOR_VERSION    ETH_SW_MINOR_VERSION_VALUE

/***********************************************************************************************************************
**                      Version Check                                                                                 **
***********************************************************************************************************************/
#if (ETH_FILTER_AR_RELEASE_MAJOR_VERSION != ETH_FILTER_C_AR_RELEASE_MAJOR_VERSION)
  #error "Eth_Filter.c : Mismatch in Release Major Version"
#endif
#if (ETH_FILTER_AR_RELEASE_MINOR_VERSION != ETH_FILTER_C_AR_RELEASE_MINOR_VERSION)
  #error "Eth_Filter.c : Mismatch in Release Minor Version"
#endif
#if (ETH_FILTER_AR_RELEASE_REVISION_VERSION != ETH_FILTER_C_AR_RELEASE_REVISION_VERSION)
  #error "Eth_Filter.c : Mismatch in Release Revision Version"
#endif

#if (ETH_FILTER_SW_MAJOR_VERSION != ETH_FILTER_C_SW_MAJOR_VERSION)
  #error "Eth_Filter.c : Mismatch in Software Major Version"
#endif
#if (ETH_FILTER_SW_MINOR_VERSION != ETH_FILTER_C_SW_MINOR_VERSION)
  #error "Eth_Filter.c : Mismatch in Software Minor Version"
#endif

/***********************************************************************************************************************
**                                               Coding Rule Violations                                               **
***********************************************************************************************************************/
/* Message (1:1533)    : The object '%1s' is only referenced by function '%2s'.                                       */
/* Rule                : CWE Rule CWE-398, CWE-569,  MISRA C:2012 Rule-8.9                                            */
/* JV-01 Justification : This is accepted, due to the object is defined in separated source C file to followed        */
/*                       coding rule                                                                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (2:3469)    : This usage of a function-like macro looks like it could be replaced by an equivalent         */
/*                       function call.                                                                               */
/* Rule                :  MISRA C:2012 Dir-4.9                                                                        */
/* JV-01 Justification : This message indicates that a candidate macro may be suitable for replacement by a           */
/*                       function, based on an actual call-site and the arguments passed to it there. (Other uses of  */
/*                       the macro may not necessarily be suitable for replacement.)                                  */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/
/* Message (4:5087)    : Use of #include directive after code fragment.                                               */
/* Rule                :  MISRA C:2012 Rule-20.1                                                                      */
/* JV-01 Justification : This is done as per Memory Requirement, (MEMMAP003 - Specification of Memory Mapping).       */
/*       Verification  : However, part of the code is verified manually and it is not having any impact.              */
/**********************************************************************************************************************/

/***********************************************************************************************************************
**                      Global Data                                                                                   **
***********************************************************************************************************************/
#define ETH_START_SEC_CONST_32
#include "Eth_MemMap.h"

/* Const values of broadcast and null address to be compared */
CONST(Eth_MacAddressType, ETH_CONST) Eth_GstBroadcastAddr =
{
  0xFFFFFFFFUL, 0x0000FFFFU
};
CONST(Eth_MacAddressType, ETH_CONST) Eth_GstNullAddr =                                                                  /* PRQA S 1533 # JV-01 */
{
  0x00000000UL, 0x00000000U
};
#define ETH_STOP_SEC_CONST_32
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */


/***********************************************************************************************************************
**                                         Function Definitions                                                       **
***********************************************************************************************************************/
#define ETH_START_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
** Function Name         : Eth_GetFilterIndex
**
** Service ID            : N/A
**
** Description           : Get the index of the specified MAC address if exists
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx: Index of a controller
**                         LpMacAddr:  Pointer to a MAC address to be searched
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaAddressFilters
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_201
** Reference ID          : ETH_DUD_ACT_201_GBL001, ETH_DUD_ACT_201_GBL002
***********************************************************************************************************************/
FUNC(uint32, ETH_PRIVATE_CODE) Eth_GetFilterIndex(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_MacAddressType, AUTOMATIC, AUTOMATIC) LpMacAddr)
{
  uint32 LulFilterIdx;
  uint32 LulFoundIdx;

  LulFoundIdx = ETH_INVALID_FILTER_INDEX;
  /* Check the specified address is already registered */
  for (LulFilterIdx = (uint32)ETH_ZERO; (ETH_INVALID_FILTER_INDEX == LulFoundIdx) &&
    (LulFilterIdx < ETH_MAX_FILTERS); LulFilterIdx++)
  {
    if (((uint32)ETH_ZERO != (Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits & (1UL << LulFilterIdx))) &&
      ((uint32)ETH_ZERO == ETH_COMPARE_MAC(*LpMacAddr, Eth_GaaAddressFilters[LulCtrlIdx][LulFilterIdx])))               /* PRQA S 3469 # JV-01 */
    {
      LulFoundIdx = LulFilterIdx;
    }
    else
    {
      /* No action required */
    }
  }

  return LulFoundIdx;
}

/***********************************************************************************************************************
** Function Name         : Eth_ClearAllAddressFilters
**
** Service ID            : N/A
**
** Description           : Remove all filters from the filter list and turn off promiscuous mode
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx: Index of a controller
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_202
** Reference ID          : ETH_DUD_ACT_202_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_ClearAllAddressFilters(
  CONST(uint32, AUTOMATIC) LulCtrlIdx)
{
  Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits = (uint32)ETH_ZERO;
  Eth_GaaCtrlStat[LulCtrlIdx].blPromiscuous = ETH_FALSE;
}

/***********************************************************************************************************************
** Function Name         : Eth_RemoveAddressFilter
**
** Service ID            : N/A
**
** Description           : Remove a filter from the filter list
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx  : Index of a controller
**                         LulFilterIdx: Index of an address in the filter list
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : None
**
** Global Variable(s)    : Eth_GaaCtrlStat
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_203
** Reference ID          : ETH_DUD_ACT_203_GBL001
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_RemoveAddressFilter(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONST(uint32, AUTOMATIC) LulFilterIdx)
{
  /* Clear an active bit */
  Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits &= ~(1UL << LulFilterIdx);
}

/***********************************************************************************************************************
** Function Name         : Eth_AddAddressFilter
**
** Service ID            : N/A
**
** Description           : Add a address filter to the filter list
**
** Sync/Async            : Synchronous
**
** Reentrancy            : Non Reentrant
**
** Input Parameters      : LulCtrlIdx: Index of a controller
**                         LpMacAddr : Pointer to a MAC address to be added
**
** InOut Parameters      : None
**
** Output Parameters     : None
**
** Return parameter      : None
**
** Preconditions         : At least there is an empty entry in the FilterArray
**
** Global Variable(s)    : Eth_GaaCtrlStat, Eth_GaaAddressFilters
**
** Function(s) invoked   : None
**
** Registers Used        : None
**
** Reference ID          : ETH_DUD_ACT_204
** Reference ID          : ETH_DUD_ACT_204_GBL001, ETH_DUD_ACT_204_GBL002
***********************************************************************************************************************/
FUNC(void, ETH_PRIVATE_CODE) Eth_AddAddressFilter(
  CONST(uint32, AUTOMATIC) LulCtrlIdx, CONSTP2CONST(Eth_MacAddressType, AUTOMATIC, AUTOMATIC) LpMacAddr)
{
  uint32 LulFilterIdx;
  boolean LblRegistered;

  LblRegistered = ETH_FALSE;
  for (LulFilterIdx = (uint32)ETH_ZERO; (ETH_FALSE == LblRegistered) && (LulFilterIdx < ETH_MAX_FILTERS);
                                                                                                        LulFilterIdx++)
  {
    if ((uint32)ETH_ZERO == (Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits & (1UL << (LulFilterIdx))))
    {
      Eth_GaaAddressFilters[LulCtrlIdx][LulFilterIdx] = *LpMacAddr;
      Eth_GaaCtrlStat[LulCtrlIdx].ulActiveFilterBits |= (1UL << LulFilterIdx);
      LblRegistered = ETH_TRUE;
    }
    else
    {
      /* No action required */
    }
  }
}

#define ETH_STOP_SEC_PRIVATE_CODE
#include "Eth_MemMap.h"                                                                                                 /* PRQA S 5087 # JV-01 */

/***********************************************************************************************************************
**                                            End of File                                                             **
***********************************************************************************************************************/
