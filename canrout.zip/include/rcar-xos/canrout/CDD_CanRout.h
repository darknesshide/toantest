/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.25.0
* Description  : This file contains the process to access registers used in the Initialization function.
***********************************************************************************************************************/
#ifndef CDD_CANROUT_H
#define CDD_CANROUT_H

/* Include standard Autosar Type */
#include "Std_Types.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define CANROUT_CHECK_CODE          (0x12345678U)   /* Integrity Check Code */
#define CANROUT_RSCFD_CH_NUM        (8U)            /* Number of channels in RS-CANFD */
#define CANROUT_CANXL_CH_NUM        (2U)            /* Number of channels in CAN XL */
#define CANROUT_RSCFD_IFLBL_NUM     (2U)            /* Number of Information Label of RS-CANFD */
#define CANROUT_RSCFD_UNIT_NUM      (2U)            /* Number of Units in RS-CANFD */
#define CANROUT_CANIP_UNIT_NUM      (3U)            /* Number of Units in CAN IP */
#define CANROUT_PAYLOAD_MAX_SIZE    (8U)
#define MAX_SWENTRY_PER_UNIT_NUM    (425U)
#define CANROUT_STAT_SUCCESS        (1U)            /* Indicate success-type */
#define CANROUT_STAT_ERROR          (0U)            /* Indicate error-type */
/* CANXL Statistics type */
#define CANROUT_STAT_XL_RX_ERROR    (2U)            /* CANXL RX Error counter type */
#define CANROUT_STAT_XL_RX_SUCCESS  (3U)            /* CANXL RX Success counter type */
#define CANROUT_STAT_XL_TX_ERROR    (4U)            /* CANXL TX Error counter type */
#define CANROUT_STAT_XL_TX_SUCCESS  (5U)            /* CANXL TX Success counter type */

#define CANROUT_CANXL_UNIT          (2U)            /* CAN XL Unit number */


#define CANROUT_VENDOR_ID           CANROUT_VENDOR_ID_VALUE
#define CANROUT_MODULE_ID           CANROUT_MODULE_ID_VALUE
#define CANROUT_INSTANCE_ID         CANROUT_INSTANCE_ID_VALUE

/***********************************************************************************************************************
**                                                    Service IDs                                                     **
***********************************************************************************************************************/
/* Service ID for R_CanRout_Init */
#define R_CANROUT_INIT_SID                   (uint8)0x00U

/* Service ID for R_CanRout_SwRout */
#define R_CANROUT_SWROUT_SID                 (uint8)0x01U

/* Service ID for R_CanRout_UpdateSwTbl */
#define R_CANROUT_UPDATE_SWTBL_SID           (uint8)0x02U

/* Service ID for R_CanRout_SendEnable */
#define R_CANROUT_SEND_ENABLE_SID            (uint8)0x03U

/* Service ID for R_CanRout_SendDisable */
#define R_CANROUT_SEND_DISABLE_SID           (uint8)0x04U

/* Service ID for R_CanRout_GetSendStatus */
#define R_CANROUT_GET_SEND_STATUS_SID        (uint8)0x05U

/* Service ID for R_CanRout_UpdateHwTbl */
#define R_CANROUT_UPDATE_HWTBL_SID           (uint8)0x06U

/* Service ID for R_CanRout_GetCount */
#define R_CANROUT_GET_COUNT_SID              (uint8)0x08U

/* Service ID for R_CanRout_ClearCount */
#define R_CANROUT_CLEAR_COUNT_SID            (uint8)0x09U

/* Service ID for R_CanRout_SwRout */
#define R_CANROUT_XLSWROUT_SID               (uint8)0x0AU

/* Service ID for R_CanRout_MainFunction */
#define R_CANROUT_MAINFUNCTION_SID           (uint8)0x0BU

/*******************************************************************************
**                      DET Error Codes                                       **
*******************************************************************************/
/* DET code to report parameter error (argument is NULL pointer) */
#define CANROUT_E_PARAM_POINTER         (uint8)0x02U /* 2U*/

/* DET code to report process error (API executed in uninitialized state) */
#define CANROUT_E_UNINIT                (uint8)0x03U /* 3U*/

/* DET code to report already initialized */
#define CANROUT_E_ALREADY_INITIALIZED   (uint8)0x04U /* 4U*/

/* DET code to report RS-CANFD register setting error */
#define CANROUT_E_REG                   (uint8)0x05U /* 5U*/

/* DET code to report discrepancy error (Miss match with SW routing table value) */
#define CANROUT_E_MATCH                 (uint8)0x06U /* 6U*/

/* DET code to report configuration errors (overall)*/
#define CANROUT_E_CFG                   (uint8)0x07U /* 7U*/

/* DET code to report configuration error (AFL entry) */
#define CANROUT_E_CFG_HWTBL             (uint8)0x08U /* 8U*/

/* DET code to report configuration error (SW routing table entry incorrect value) */
#define CANROUT_E_CFG_SWTBL             (uint8)0x09U /* 9U*/

/* DET code to report transmission error */
#define CANROUT_E_TRANS                 (uint8)0x0AU /* 10U*/

/* DET code to report parameter is invalid value */
#define CANROUT_E_INV_PARAM             (uint8)0x0BU /* 11U*/

/* DET code to report configuration parameter error */
#define CANROUT_E_CONFIG_PARAM          (uint8)0x0CU /* 12U*/

/*******************************************************************************
Typedef definitions
*******************************************************************************/
/* CAN XL Frame struct */
typedef struct
{
    uint16 usPriorityId;
    uint16 usVcid;
    uint8 ucSduType;
    uint32 ulAcceptanceField;
    uint8 ucSec;
} R_CanRout_CanXLParamType;

/* CAN HW Routing Table Entry */
typedef struct
{
    uint32 ulSrcCanId;                                  /* Source CAN ID (29 bit) */
    uint32 ulSrcCanIdMask;                              /* Source CAN ID Mask (29 bit) */
    uint8  ucSrcCanIde;                                 /* Source CAN IDE (1 bit) */
    uint8  ucSrcCanIdeMask;                             /* Source CAN IDE Mask (1 bit) */
    uint8  ucSrcCanRtr;                                 /* Source CAN RTR (1 bit) */
    uint8  ucSrcCanRtrMask;                             /* Source CAN RTR Mask (1 bit) */
    uint16 usPtrInfo;                                   /* Pointer information (16 bit) */
    uint8  aaInfoLabel[CANROUT_RSCFD_IFLBL_NUM];        /* Information Label bit 0/1 */
    uint8  ucLoopbackCfg;                               /* Entry Loopback Configuration (1 bit) */
    uint8  ucDlc;                                       /* DLC value for automatic DLC filtering (4 bit) */
    uint8  ucSelRoutDest;                               /* Select Routing destination 0/1/2 (3 bit) */
    uint8  ucRmbValid;                                  /* RX Message Buffer Valid (1 bit) */
    uint8  ucRmbDest;                                   /* RX Message Buffer Direction Pointer (7 bit) */
    uint32 ulFifoDest;                                  /* FIFO Direction Pointer (32 bit) */
} R_CanRout_HwTblEntryType;

/* CAN SW Routing Table Entry */
typedef struct
{
    uint32 ulSrcCanId;                                  /* Source CAN ID (29 bit) */
    uint32 ulSrcCanIdMask;                              /* Source CAN ID Mask (29 bit) */
    uint8  ucSrcCanIde;                                 /* Source CAN IDE (1 bit) */
    uint8  ucSrcCanIdeMask;                             /* Source CAN IDE Mask (1 bit) */
    uint8  ucSrcCanCh;                                  /* Source CAN Channel Number (8 bit) */
    uint8  aaPayload[CANROUT_PAYLOAD_MAX_SIZE];         /* Payload (64bit) */
    uint8  aaPayloadMask[CANROUT_PAYLOAD_MAX_SIZE];     /* Payload Mask (64bit) */
    uint8  ucDestCanCh[CANROUT_CANIP_UNIT_NUM];         /* Destination CAN IP channel[unit number] (8 bit) */
    uint8  ucAddInfo;                                   /* Generic additional Information (8 bit) */
    uint8  ucConvFlag;                                  /* CAN ID conversion flag (1 bit) */
    uint32 ulConvCanId;                                 /* CAN ID after conversion (32 bit) */
    uint8  ucXLFlag;                                    /* CANXL Param conversion Flag */
    R_CanRout_CanXLParamType stXLParams;                /* CANXL Param Config */
} R_CanRout_SwTblEntryType;

/* CAN HW Routing Table */
typedef struct
{
    uint32 aaEntryNumPerCh[CANROUT_RSCFD_CH_NUM];       /* AFL entry number for each channel */
    const  R_CanRout_HwTblEntryType *pHwTblEntry;       /* AFL entries (RS-CANFD) */
    uint8 *pHwTblEntryMapping;                          /* Channel number ID for each AFL entry pHwTblEntryMapping*/
} R_CanRout_HwTblType;

/* CAN SW Routing Table */
typedef struct
{
    uint32 aaEntryNum;                                  /* SW entry number */
    const  R_CanRout_SwTblEntryType *pSwTblEntry;       /* SW Entries for RS-CANFD */
} R_CanRout_SwTblType;

/* CAN Routing Initialization Configuration */
typedef struct
{
    uint8 ucUnitSetFlag[CANROUT_CANIP_UNIT_NUM];                /* Setting flag whether initialize or not. */
    const R_CanRout_HwTblType *pHwTbl[CANROUT_RSCFD_UNIT_NUM];  /* CAN HW Routing Table Configuration */
    const R_CanRout_SwTblType *pSwTbl[CANROUT_CANIP_UNIT_NUM];  /* CAN SW Routing Table Configuration */
    uint32 ulIntegrityCheck;                                    /* Integrity check code */
} R_CanRout_CfgType;

typedef struct
{
    uint32 ulCanId;
    uint32 ulCanDlc;
    uint8  *pCanData;
} R_CanRout_CanFrameType;

/* CAN XL Frame information */
typedef struct
{
    uint32 ulCanDlc;
    uint8  *pCanData;
    R_CanRout_CanXLParamType *pXLParams;
} R_CanRout_CanXLFrameType;

/* CanRout Pre-compile configuration Header File */
#include "CDD_CanRout_Cfg.h"

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define CANROUT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanRout_MemMap.h" 
extern VAR(R_CanRout_HwTblType, CANROUT_VAR_NO_INIT) *CanRout_GpHwTblEntry; 
#define CANROUT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanRout_MemMap.h" 
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANROUT_START_SEC_PUBLIC_CODE
#include "CanRout_MemMap.h"

extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_Init(const R_CanRout_CfgType *pConfig);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_SwRout(const R_CanRout_CanFrameType *pCanFrame, 
    const uint8 ucSrcUnit, const uint8 ucSrcCh, uint32 *pMultiSendResult);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_XLSwRout(const R_CanRout_CanXLFrameType *pCanFrame,
    const uint8 ucSrcUnit, const uint8 ucSrcCh, uint32 *pMultiSendResult);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_UpdateSwTbl(const uint8 ucSrcUnit, const R_CanRout_SwTblType *pSwTblType);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_SendEnable(const uint8 ucUnit, const uint8 ucCh);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_SendDisable(const uint8 ucUnit, const uint8 ucCh);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_GetSendStatus(uint32 *pStatus);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_UpdateHwTbl(const uint8 ucUnit, const uint32 ulEntryIdx,
    const R_CanRout_HwTblEntryType *pHwtblEntryConfig);
extern FUNC(void, CANROUT_PUBLIC_CODE) R_CanRout_MainFunction(void);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_GetCount(const uint8 ucUnit, const uint8 ucCh, const uint8 ucCounterType,
                                                                                                        uint32 *pCount);
extern FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_ClearCount(const uint8 ucUnit, const uint8 ucCh, const uint8 ucCounterType);

#define CANROUT_STOP_SEC_PUBLIC_CODE
#include "CanRout_MemMap.h"

#endif /* CDD_CANROUT_H */
