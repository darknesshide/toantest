/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file provides the interface of "CDD_CanRout_tblsetting.c".
***********************************************************************************************************************/

#ifndef CDD_CANROUT_TBLSETTING_H
#define CDD_CANROUT_TBLSETTING_H

#include "rcar-xos/canrout/CDD_CanRout.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Maximum number of rules per channel */
#define MAX_RULE_PER_CH_NUM     (384U)
/* Maximum number of rules per unit */
#define MAX_RULE_PER_UNIT_NUM (1536U)
/* Maximum number of rules per page */
#define MAX_RULE_PER_PAGE_NUM   (16U)
/* Mask for AFLPN bit */
#define AFLPN_BIT_MASK          (0xFFFFFF80U)
/* Register bit set */
#define REG_BIT_SET             (1U)
/* For CanRout_UpdateHwTbl register access setting macro definitions */
#define AFL_IGNORE_ENABLE       (0x0000c401U)
#define AFL_IGNORE_DISABLE      (0x0000c400U)
#define AFL_DATAACCESS_ENABLE   (0x00000100U)
#define AFL_DATAACCESS_DISABLE  (0x00000000U)

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

extern FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_SetHwTbl(const uint8 ucUnit, const R_CanRout_HwTblType *pHwtblConfig);
extern FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_UpdateHwTbl(const uint8 ucUnit, const uint32 ulEntryIdx, 
                                  const R_CanRout_HwTblEntryType *pHwtblEntryConfig);

#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
#endif /* CDD_CANROUT_TBLSETTING_H */
