/***********************************************************************************************************************
* Copyright [2023-2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.26.0
* Description  : This file provides the interface of "CDD_CanRout_stat.c".
***********************************************************************************************************************/

#ifndef CDD_CANROUT_STAT_H
#define CDD_CANROUT_STAT_H

#include "rcar-xos/canrout/CDD_CanRout.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* Maximum counter value (12-bit) */
#define CANXL_STAT_COUNTER_MAX          (0x0FFFUL)      /* 4095 - Bit 11:0 */

/* Reserved bits mask */
#define CANXL_STAT_RESERVED_MASK        (0xF000F000UL)  /* Bit 31-28 and 15-12 */

/* CANXL STATS_INT_STS bit masks */
#define CANXL_STATS_INT_RX_SUCC_WRAP        (0x00000001U)  /* bit 0 */
#define CANXL_STATS_INT_RX_UNSUCC_WRAP      (0x00000002U)  /* bit 1 */
#define CANXL_STATS_INT_TX_SUCC_WRAP        (0x00000004U)  /* bit 2 */
#define CANXL_STATS_INT_TX_UNSUCC_WRAP      (0x00000008U)  /* bit 3 */

/* CANXL wrap add value (4096 = max 12-bit + 1) */
#define CANXL_STAT_WRAP_ADD_VALUE           (0x00001000U)  /* 4096 */

/*******************************************************************************
Typedef definitions
*******************************************************************************/
#define COUNT_THRESHOLD         (0x80000000U)

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

extern FUNC(void, CANROUT_PRIVATE_CODE) CanRout_StatCount(void);
extern FUNC(void, CANROUT_PRIVATE_CODE) CanRout_StatCount_XL(void);
extern FUNC(void, CANROUT_PRIVATE_CODE) CanRout_GetCount(const uint8 ucUnit, const uint8 ucCh, const uint8 ucCounterType, uint32 *pCount);
extern FUNC(void, CANROUT_PRIVATE_CODE) CanRout_ClearCount(const uint8 ucUnit, const uint8 ucCh, const uint8 ucCounterType);

#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
#endif /* CDD_CANROUT_STAT_H */
