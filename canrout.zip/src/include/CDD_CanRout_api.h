/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file provides the interface of "CDD_CanRout_api.c".
***********************************************************************************************************************/

#ifndef CDD_CANROUT_API_H
#define CDD_CANROUT_API_H

#include "rcar-xos/canrout/CDD_CanRout.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define CANROUT_STS_UNINIT      (0U)
#define CANROUT_STS_INIT        (1U)

#define RSCFD_GL_OPERATION_MODE (0U)
#define RSCFD_GL_RESET_MODE     (1U)
#define RSCFD_GL_HALT_MODE      (2U)
#define RSCFD_GL_SLEEP_MODE     (4U)

/* Check RS_CANFD Channel mode */
#define RSCFD_CH_STATUS         (7U)

/*******************************************************************************
Typedef definitions
*******************************************************************************/
typedef enum {
    GL_OPERATION_MODE = 0U,
    GL_RESET_MODE,
    GL_HALT_MODE,
    GL_SLEEP_MODE
} CanRout_GblModeType;

typedef enum {
    CH_RESET_MODE = 1U,
    CH_HALT_MODE = 2U,
    CH_SLEEP_MODE = 4U
} CanRout_ChannelModeType;

/*******************************************************************************
Exported global variables
*******************************************************************************/
#define CANROUT_START_SEC_VAR_INIT_8
#include "CanRout_MemMap.h" 

extern VAR(uint8, CANROUT_VAR_INIT) CanRout_GucInitStatus;

#define CANROUT_STOP_SEC_VAR_INIT_8
#include "CanRout_MemMap.h" 
/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_CANROUT_API_H */

