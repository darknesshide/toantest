/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.6.0
* Description  : This file provides the common configuration.
***********************************************************************************************************************/

#ifndef CDD_CANROUT_COMMON_H
#define CDD_CANROUT_COMMON_H

#include "rcar-xos/canrout/CDD_CanRout.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

#define NUM0                      0U

/* CanRouting Common Configuration */
#define CANROUT_FLAG_CLR          0U
#define CANROUT_FLAG_SET          1U
#define CANROUT_SWINITFLAG_SET    2U
#define CANROUT_MAX_1BIT_VAL      0x01U
#define CANROUT_MAX_2BIT_VAL      0x03U
#define CANROUT_MAX_3BIT_VAL      0x07U
#define CANROUT_MAX_4BIT_VAL      0x0FU
#define CANROUT_MAX_7BIT_VAL      0x07FU
#define CANROUT_MAX_8BIT_VAL      0x0FFU
#define CANROUT_MAX_16BIT_VAL     0xFFFFU
#define CANROUT_MAX_18BIT_VAL     0x3FFFFU
#define CANROUT_MAX_29BIT_VAL     0x1FFFFFFFU
/* New range for CANFD */
#define CANROUT_FD_MAX_29BIT_VAL  0x5FFFFFFFU
#define CANROUT_MAX_31BIT_VAL     0x7FFFFFFFU
#define CANROUT_MAX_32BIT_VAL     0xFFFFFFFFU

/* CAN ID range*/
#define CANID_BASE_MAX            0x000007FFU
#define CANID_EXTEND_MIN          0x80000000U
#define CANID_EXTEND_MAX          0x9FFFFFFFU
/* CANFD ID range*/
#define CANFD_ID_BASE_MIN            0x40000000U
#define CANFD_ID_BASE_MAX            0x400007FFU
#define CANFD_ID_EXTEND_MIN          0xC0000000U
#define CANFD_ID_EXTEND_MAX          0xDFFFFFFFU

#define CANROUT_DLC_0             0U
#define CANROUT_DLC_8             8U
#define CANROUT_DLC_12            12U
#define CANROUT_DLC_16            16U
#define CANROUT_DLC_20            20U
#define CANROUT_DLC_24            24U
#define CANROUT_DLC_32            32U
#define CANROUT_DLC_48            48U
#define CANROUT_DLC_2048            2048U
#define CANROUT_DLC_64            64U
#define CANROUT_MASK_9BIT_VAL     0x1FFU
#define CANROUT_BIT_32            32U
#define CANROUT_DESTFIFO_NUM_MAX  8U

/* Array index */
#define IDX_0                   (0U)
#define IDX_1                   (1U)
#define IDX_2                   (2U)
#define IDX_3                   (3U)
#define IDX_4                   (4U)
#define IDX_5                   (5U)
#define IDX_6                   (6U)
#define IDX_7                   (7U)

/* Bit shift */
#define SHIFT_1BIT              (1U)
#define SHIFT_2BIT              (2U)
#define SHIFT_4BIT              (4U)
#define SHIFT_7BIT              (7U)
#define SHIFT_8BIT              (8U)
#define SHIFT_15BIT             (15U)
#define SHIFT_16BIT             (16U)
#define SHIFT_24BIT             (24U)
#define SHIFT_28BIT             (28U)
#define SHIFT_29BIT             (29U)
#define SHIFT_30BIT             (30U)
#define SHIFT_31BIT             (31U)
/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_CANROUT_COMMON_H */
