/***********************************************************************************************************************
* Copyright [2023-2025] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.25.0
* Description  : This file defines the I/O Registers of RS-CANFD.
***********************************************************************************************************************/

#ifndef CDD_CANROUT_IODEFINE_H
#define CDD_CANROUT_IODEFINE_H

#include "rcar-xos/canrout/CDD_CanRout.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/
/* RS-CANFD unit 0 */
#define RSCANFD_UNIT_0 (0U)
/* RS-CANFD unit 1 */
#define RSCANFD_UNIT_1 (1U)

#ifdef X5H_RFS_PLATFORM_USED
/* RSCAN0 Base Address */
#define RSCAN0_BASE (0xC1400000UL)
/* RSCAN1 Base Address */
#define RSCAN1_BASE (0xC1500000UL)
#else
/* RSCAN0 Base Address */
#define RSCAN0_BASE (0xC1420000UL)
/* RSCAN1 Base Address */
#define RSCAN1_BASE (0xC1520000UL)
#endif

/* CANXL0 Base Address */
#define CANXL0_BASE (0xC1200000UL)
/* CANXL1 Base Address */
#define CANXL1_BASE (0xC1240000UL)

/* RSCAN Global Status Register Address (CFDGSTS) */
#define RSCAN_GSTS(unit) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x008CUL))
/* RSCAN Global Acceptance Filter List Entry Control Register Address (FDGAFLECTR) */
#define RSCAN_AFLEC(unit) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x0098UL))
/* RSCAN Global Acceptance Filter List Configuration Register w Address (CFDGAFLCFGw) */
#define RSCAN_AFLC(unit) (*(volatile struct RSCFD_AFLCRegType *)(GaaRSCANRegs[unit] + 0x009CUL))
/* RSCAN Acceptance Filter List-Related Registers (AFL Entries) Address */
#define RSCAN_AFLE(unit) (*(volatile struct RSCFD_AFLERegType *)(GaaRSCANRegs[unit] + 0x1800UL))
/* RSCAN Global AFL Ignore Entry Register Address (CFDGAFLIGNENT) */
#define RSCAN_GAFLIGNENT(unit) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x1324UL))
/* RSCAN Global AFL Ignore Control Register Address (CFDGAFLIGNCTR) */
#define RSCAN_GAFLIGNCTR(unit) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x1328UL))
/* RSCAN Global Channel CAN-FD Status Register Address (CFDCnFDSTS) */
#define RSCAN_CFDCNFDSTS(unit, ch) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x140CUL + ((ch) * 0x0020UL)))
/* RSCAN Global Channel CAN-FD Control Register Address (CFDCnFDCTR) */
#define RSCAN_CFDCNFDCTR(unit, ch) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x1408UL + ((ch) * 0x0020UL)))
/* RSCAN Channel Status Registers (CFDCnSTS) */
#define RSCAN_CFDCNSTS(unit, ch) (*(volatile uint32 *)(GaaRSCANRegs[unit] + 0x0008UL + ((ch) * 0x0010UL)))

/* Number of CFDGAFLIDs */
#define CFDGAFLIDS_NUM (16U)
/* Number of CFDGAFLCFGs */
#define CFDGAFLCFG_NUM (4U)

/*******************************************************************************
Typedef definitions
*******************************************************************************/
struct RSCFD_AFLCRegType {                       /* AFL Configuration        */
    uint32 CFDGAFLCFG[CFDGAFLCFG_NUM];           /* CFDGAFLCFG[1...4]h       */
}; /* RSCFD_AFLCRegType */

typedef struct {                                 /*                          */
    uint32 CFDGAFLIDr;                           /* CFDGAFLIDr               */
    uint32 CFDGAFLMr;                            /* CFDGAFLMr                */
    uint32 CFDGAFLP0r;                           /* CFDGAFLP0r               */
    uint32 CFDGAFLP1r;                           /* CFDGAFLP1r               */
} CFDGAFLXXX;

struct RSCFD_AFLERegType {                       /* AFL Entries              */
    CFDGAFLXXX CFDGAFL[CFDGAFLIDS_NUM];          /* CFDGAFLID[1...10]h       */
                                                 /* CFDGAFLM[1...10]h        */
                                                 /* CFDGAFLP0[1...10]h       */
                                                 /* CFDGAFLP1[1...10]h       */
}; /* RSCFD_AFLERegType */

/* ========================================================================== */
/*                      CANXL STATISTICS REGISTERS                            */
/* ========================================================================== */

/* CANXL RX Statistics Register (RX_STATISTICS) */
#define CANXL_RX_STATISTICS(ch) \
    (*(volatile uint32 *)(GaaCANXLRegs[ch] + 0x0404UL))

/* CANXL TX Statistics Register (TX_STATISTICS) */
#define CANXL_TX_STATISTICS(ch) \
    (*(volatile uint32 *)(GaaCANXLRegs[ch] + 0x0104UL))

/* CANXL STATS_INT_STS register */
#define CANXL_STATS_INT_STS(ch)  \
    (*(volatile uint32*)(GaaCANXLRegs[ch] + 0x0710UL))

/*******************************************************************************
Exported global variables
*******************************************************************************/
static volatile uint32 GaaRSCANRegs[CANROUT_RSCFD_UNIT_NUM] =
{
    RSCAN0_BASE,
    RSCAN1_BASE
};

static volatile uint32 GaaCANXLRegs[CANROUT_CANXL_CH_NUM] =
{
    CANXL0_BASE,
    CANXL1_BASE
};

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/

#endif /* CDD_CANROUT_IODEFINE_H */
