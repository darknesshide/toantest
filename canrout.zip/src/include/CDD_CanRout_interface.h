/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains sample function.
***********************************************************************************************************************/
#ifndef CDD_CANROUT_INTERFACE_H
#define CDD_CANROUT_INTERFACE_H

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "rcar-xos/canrout/CDD_CanRout.h"

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables
*******************************************************************************/

/*******************************************************************************
Exported global functions (to be accessed by other files)
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_TransmitUserDef(const R_CanRout_CanFrameType *pCanFrame, const uint8 ucUnit,
                               const uint8 ucCh, const uint8 ucAddInfo);
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_XLTransmitUserDef(const R_CanRout_CanXLFrameType *pCanFrame, const uint8 ucUnit,
                               const uint8 ucCh, const uint8 ucAddInfo);
FUNC(void, CANROUT_PRIVATE_CODE) CanRout_NotifyStatUserDef(const uint8 ucUnit, const uint8 ucCh,
                               const uint8 ucConterType, const uint32 ulCounterValue);

#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
#endif /* CDD_CANROUT_INTERFACE_H */
