/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains the process of Software Routing functions.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanRout_swrout.h"
#include "CDD_CanRout_common.h"
#include "CDD_CanRout_interface.h"
#include "CDD_CanRout_iodefine.h"

/* Included for the declaration of Det_ReportError() */
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANROUT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanRout_MemMap.h" 
/* SW Routing Table */
static VAR(R_CanRout_SwTblEntryType, CANROUT_VAR_NO_INIT) CanRout_GstSwRoutTbl[CANROUT_CANIP_UNIT_NUM][MAX_SWENTRY_PER_UNIT_NUM];
/* Transmit CAN Frame */
static VAR(R_CanRout_CanFrameType, CANROUT_VAR_NO_INIT) CanRout_GstCanFrame;
static VAR(R_CanRout_CanXLFrameType, CANROUT_VAR_NO_INIT) CanRout_GstCanXLFrame;
#define CANROUT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanRout_MemMap.h" 

/* Each Units Entry Number for SW Routing Table  */
#define CANROUT_START_SEC_VAR_NO_INIT_32
#include "CanRout_MemMap.h" 
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GulSwRoutTblEntryNum[CANROUT_CANIP_UNIT_NUM];
#define CANROUT_STOP_SEC_VAR_NO_INIT_32
#include "CanRout_MemMap.h" 

#define CANROUT_START_SEC_VAR_NO_INIT_8
#include "CanRout_MemMap.h" 
STATIC VAR(uint8, CANROUT_VAR_NO_INIT) CanRout_GaaCanData[CANROUT_DLC_2048];
#define CANROUT_STOP_SEC_VAR_NO_INIT_8
#include "CanRout_MemMap.h" 

#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) SearchCanRoutTbl(const uint8 ucSrcUnit, const uint32 ulCanDlc, const uint8 *pCanData,
    R_CanRout_SwTblEntryType *pSwTblEntry
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    );

STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CreateAndSendCan(const R_CanRout_SwTblEntryType *pSearchResult, uint32 *pMultiSendResult
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        , const uint8 ucSID
    #endif
   );

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_010]:[Gen5GW_CanRout_UD_03_001]
* Function Name: CanRout_SetSwTbl
* Description  : Set SW Routing Table.
* Arguments    : ucUnit -
*                    RS-CANFD unit number
*                pSwtblConfig -
*                    SW Routing configuration
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_SetSwTbl(const uint8 ucSrcUnit, const R_CanRout_SwTblType *pSwtblConfig
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    )
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint8  LucChIdx;

    LucRetVal = E_OK;

    if ((pSwtblConfig->aaEntryNum <= (uint32)MAX_SWENTRY_PER_UNIT_NUM) &&
        (NULL_PTR != pSwtblConfig->pSwTblEntry))
    {
        /* Checks whether values of each rule are under the MAX value. */
        for (LulEntryIdx= IDX_0; LulEntryIdx < pSwtblConfig->aaEntryNum; LulEntryIdx++)
        {
            /* If ucSrcCanIde is 0 */
            if (((((uint32)CANROUT_FLAG_CLR == (uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanIde) &&
                ((pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId        <= (uint32)CANID_BASE_MAX) ||
                    /* New CANFD range */
                    (((uint32)CANFD_ID_BASE_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId) &&
                    (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId        <= (uint32)CANFD_ID_BASE_MAX))) &&
                ((pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask    <= (uint32)CANID_BASE_MAX) ||
                    /* New CANFD range */
                    (((uint32)CANFD_ID_BASE_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask) &&
                    (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask        <= (uint32)CANFD_ID_BASE_MAX)))) ||
                /* If ucSrcCanIde is 1 */
                (((uint32)CANROUT_FLAG_SET == (uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanIde) &&
                ((pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId        <= (uint32)CANROUT_MAX_29BIT_VAL) ||
                    /* New CANFD range */
                    (((uint32)CANFD_ID_BASE_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId) &&
                    (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId        <= (uint32)CANROUT_FD_MAX_29BIT_VAL))) &&
                ((pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask    <= (uint32)CANROUT_MAX_29BIT_VAL) ||
                    /* New CANFD range */
                    (((uint32)CANFD_ID_BASE_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask) &&
                    (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask <= (uint32)CANROUT_FD_MAX_29BIT_VAL))))) &&
                ((uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanIdeMask    <= (uint32)CANROUT_MAX_1BIT_VAL) &&
                ((uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanCh         <  (uint32)CANROUT_RSCFD_CH_NUM) &&
                ((uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucConvFlag         <= (uint32)CANROUT_MAX_1BIT_VAL) &&
                ((uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucDestCanCh[IDX_2] <= (uint32)CANROUT_MAX_2BIT_VAL) &&
                ((uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucXLFlag           <= (uint32)CANROUT_MAX_2BIT_VAL) &&
                ((pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId       <= (uint32)CANID_BASE_MAX) ||
                 (((uint32)CANFD_ID_BASE_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId) &&
                 (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId       <= (uint32)CANFD_ID_BASE_MAX)) ||
                 (((uint32)CANID_EXTEND_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId) &&
                 (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId       <= (uint32)CANID_EXTEND_MAX)) ||
                 (((uint32)CANFD_ID_EXTEND_MIN <= pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId) &&
                 (pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId       <= (uint32)CANFD_ID_EXTEND_MAX))))
            {
                if (ucSrcUnit < CANROUT_RSCFD_UNIT_NUM)
                {
                    /* Do nothing (Checks value of next entry.) */
                }
                else
                {
                    if ((uint32)pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanCh < (uint32)CANROUT_CANXL_CH_NUM)
                    {
                        /* Do nothing (Checks value of next entry.) */
                    }
                    else
                    {
                        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                        /* Report to DET */
                        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_CFG_SWTBL);
                        #endif
                        LucRetVal = E_NOT_OK;
                    }
                }
            }
            else
            {
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_CFG_SWTBL);
                #endif
                LucRetVal = E_NOT_OK;
            }
            if (E_OK == LucRetVal)
            {
                /* Do nothing */
            }
            else
            {
                break;
            }
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_CONFIG_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        CanRout_GulSwRoutTblEntryNum[ucSrcUnit] =  pSwtblConfig->aaEntryNum;
        
        /* Initialized MultiSendresult */
        
        /* Copy input SW Routing Table to Global SW Routing variables. */
        for (LulEntryIdx = IDX_0; LulEntryIdx < CanRout_GulSwRoutTblEntryNum[ucSrcUnit]; LulEntryIdx++)
        {
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucSrcCanIde =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanIde;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ulSrcCanId =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanId;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ulSrcCanIdMask =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ulSrcCanIdMask;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ulConvCanId =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ulConvCanId;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucSrcCanIdeMask =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanIdeMask;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucSrcCanCh =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucSrcCanCh;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucDestCanCh[IDX_0] =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucDestCanCh[IDX_0];
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucDestCanCh[IDX_1] =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucDestCanCh[IDX_1];
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucDestCanCh[IDX_2] =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucDestCanCh[IDX_2];
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucAddInfo =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucAddInfo;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucConvFlag =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucConvFlag;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].ucXLFlag =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].ucXLFlag;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].stXLParams.usPriorityId =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].stXLParams.usPriorityId;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].stXLParams.usVcid =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].stXLParams.usVcid;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].stXLParams.ucSduType =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].stXLParams.ucSduType;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].stXLParams.ulAcceptanceField =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].stXLParams.ulAcceptanceField;
            CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].stXLParams.ucSec =
                pSwtblConfig->pSwTblEntry[LulEntryIdx].stXLParams.ucSec;
            
            for (LucChIdx = IDX_0; (uint32)LucChIdx < (uint32)CANROUT_PAYLOAD_MAX_SIZE; LucChIdx++)
            {
                CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].aaPayload[LucChIdx] =
                    pSwtblConfig->pSwTblEntry[LulEntryIdx].aaPayload[LucChIdx];
                CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx].aaPayloadMask[LucChIdx] =
                    pSwtblConfig->pSwTblEntry[LulEntryIdx].aaPayloadMask[LucChIdx];
            }
        }
    }
    else
    {
        /* Do nothing. */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_003]:[Gen5GW_CanRout_UD_03_003]
* Function Name: CanRout_SwRout
* Description  : SW Can Routing Function.
* Arguments    : pCanFrame -
*                    received CAN ID, DLC, payload data
*                ucSrcUnit - 
*                    CAN-IP unit number
*                ucSrcCh -
*                    RS-CANFD channel number
*                pMultiSendResult -
*                    Multicast send result
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_SwRout(const R_CanRout_CanFrameType *pCanFrame,
                      const uint8 ucSrcUnit, const uint8 ucSrcCh, uint32 *pMultiSendResult
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
)
{
    Std_ReturnType LucRetVal;
    uint8  LucCanIde;
    uint32 LulCanId;
    R_CanRout_SwTblEntryType LstSearchResult;
    uint32 LulPayloadIndex;
    
    R_CanRout_CanXLParamType LstXLParams;
    CanRout_GstCanXLFrame.pXLParams = &LstXLParams;

    CanRout_GstCanFrame.pCanData = &CanRout_GaaCanData[IDX_0];
    CanRout_GstCanXLFrame.pCanData = &CanRout_GaaCanData[IDX_0];
    LucRetVal = E_OK;

    /* Unit and channel range check */
    if ((((uint32)ucSrcUnit < (uint32)CANROUT_RSCFD_UNIT_NUM) && ((uint32)ucSrcCh < (uint32)CANROUT_RSCFD_CH_NUM)) ||
        (((uint32)CANROUT_CANXL_UNIT == (uint32)ucSrcUnit) && ((uint32)ucSrcCh < (uint32)CANROUT_CANXL_CH_NUM)))
    {
        /* Do nothing */
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucCanIde = (uint8)(pCanFrame->ulCanId >> SHIFT_31BIT);
        /* Check CAN ID */
        LulCanId  = (uint32)(pCanFrame->ulCanId & (uint32)CANROUT_MAX_31BIT_VAL);
        LucRetVal = CanRout_UtilCanIdCheck(LulCanId, LucCanIde
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
            #endif
            );

        /* Check CAN DLC */
        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = CanRout_UtilCanDlcCheck(pCanFrame->ulCanDlc
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                , ucSID
                #endif
                );
        }
        else
        {
            /* Do nothing. */
        }
    }
    else
    {
        /* Do nothing. */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LstSearchResult.ulSrcCanId          = LulCanId;
        LstSearchResult.ulSrcCanIdMask      = NUM0;
        LstSearchResult.ucSrcCanIde         = LucCanIde;
        LstSearchResult.ucSrcCanIdeMask     = NUM0;
        LstSearchResult.ucSrcCanCh          = ucSrcCh;
        LstSearchResult.ucDestCanCh[IDX_0]  = NUM0;
        LstSearchResult.ucDestCanCh[IDX_1]  = NUM0;
        LstSearchResult.ucDestCanCh[IDX_2]  = NUM0;
        LstSearchResult.ucAddInfo           = NUM0;
        LstSearchResult.ucConvFlag          = NUM0;
        LstSearchResult.ulConvCanId         = NUM0;
        LstSearchResult.ucXLFlag            = NUM0;
        LstSearchResult.stXLParams.usPriorityId      = NUM0;
        LstSearchResult.stXLParams.usVcid            = NUM0;
        LstSearchResult.stXLParams.ucSduType         = NUM0;
        LstSearchResult.stXLParams.ulAcceptanceField = NUM0;
        LstSearchResult.stXLParams.ucSec             = NUM0;

        LucRetVal = SearchCanRoutTbl(ucSrcUnit, pCanFrame->ulCanDlc, pCanFrame->pCanData, &LstSearchResult
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
            #endif
            );
    }
    else
    {
        /* Do nothing. */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if ((uint32)CANROUT_FLAG_SET == (uint32)LstSearchResult.ucConvFlag)
        {
            /* Convert CAN ID */
            LulCanId = LstSearchResult.ulConvCanId;
        }
        else
        {
            LulCanId = LulCanId | ((uint32)LucCanIde << SHIFT_31BIT);
        }

        /* Create CAN/CANFD frame */
        CanRout_GstCanFrame.ulCanDlc = pCanFrame->ulCanDlc;
        CanRout_GstCanFrame.ulCanId  = LulCanId;

        /* Create CANXL frame */
        CanRout_GstCanXLFrame.ulCanDlc = pCanFrame->ulCanDlc;

        /* Update CANXL Parameter or not depending on the value of CANXL Flag Bit 1. */
        if ((uint32)CANROUT_FLAG_SET == (((uint32)LstSearchResult.ucXLFlag >> SHIFT_1BIT) & (uint32)CANROUT_FLAG_SET))
        {
            CanRout_GstCanXLFrame.pXLParams->usPriorityId       = LstSearchResult.stXLParams.usPriorityId;
            CanRout_GstCanXLFrame.pXLParams->usVcid             = LstSearchResult.stXLParams.usVcid;
            CanRout_GstCanXLFrame.pXLParams->ucSduType          = LstSearchResult.stXLParams.ucSduType;
            CanRout_GstCanXLFrame.pXLParams->ulAcceptanceField  = LstSearchResult.stXLParams.ulAcceptanceField;
            CanRout_GstCanXLFrame.pXLParams->ucSec              = LstSearchResult.stXLParams.ucSec;
        }
        else
        {
            CanRout_GstCanXLFrame.pXLParams->usPriorityId       = NUM0;
            CanRout_GstCanXLFrame.pXLParams->usVcid             = NUM0;
            CanRout_GstCanXLFrame.pXLParams->ucSduType          = NUM0;
            CanRout_GstCanXLFrame.pXLParams->ulAcceptanceField  = NUM0;
            CanRout_GstCanXLFrame.pXLParams->ucSec              = NUM0;
        }

        for (LulPayloadIndex = IDX_0; LulPayloadIndex < CanRout_GstCanFrame.ulCanDlc; LulPayloadIndex++)
        {
            CanRout_GaaCanData[LulPayloadIndex] = pCanFrame->pCanData[LulPayloadIndex];
        }
    }
    else
    {
        /* Do nothing. */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CreateAndSendCan(&LstSearchResult, pMultiSendResult
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
        #endif
        );
    }
    else
    {
        /* Do nothing. */
    }

    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_019]:[Gen5GW_CanRout_UD_03_017]
* Function Name: CanRout_XLSwRout
* Description  : SW Can Routing Function.
* Arguments    : pCanFrame -
*                    received CAN ID, DLC, payload data, CANXL Parameter
*                ucSrcUnit - 
*                    CAN IP unit number
*                ucSrcCh -
*                    CAN IP channel number
*                pMultiSendResult -
*                    Multicast send result
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_XLSwRout(const R_CanRout_CanXLFrameType *pCanFrame,
                      const uint8 ucSrcUnit, const uint8 ucSrcCh, uint32 *pMultiSendResult
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
)
{
    Std_ReturnType LucRetVal;
    uint8  LucCanIde;
    uint32 LulCanId;
    R_CanRout_SwTblEntryType LstSearchResult;
    uint32 LulPayloadIndex;

    R_CanRout_CanXLParamType LstXLParams;
    CanRout_GstCanXLFrame.pXLParams = &LstXLParams;

    CanRout_GstCanFrame.pCanData = &CanRout_GaaCanData[IDX_0];
    CanRout_GstCanXLFrame.pCanData = &CanRout_GaaCanData[IDX_0];
    LucRetVal = E_OK;

    /* Unit and channel range check */
    if (((uint32)CANROUT_CANXL_UNIT == ucSrcUnit) && ((uint32)ucSrcCh < (uint32)CANROUT_CANXL_CH_NUM))
    {
        /* Do nothing */
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LucCanIde = NUM0;
        /* Check CAN ID */
        LulCanId  = (uint32)pCanFrame->pXLParams->usPriorityId;
        LucRetVal = CanRout_UtilCanIdCheck(LulCanId, LucCanIde
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
            #endif
            );

        /* Check CAN DLC */
        if ((pCanFrame->ulCanDlc <= (uint32)CANROUT_DLC_2048) && (pCanFrame->ulCanDlc > NUM0))
        {
            /* Do nothing. */
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing. */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LstSearchResult.ulSrcCanId          = LulCanId;
        LstSearchResult.ulSrcCanIdMask      = NUM0;
        LstSearchResult.ucSrcCanIde         = LucCanIde;
        LstSearchResult.ucSrcCanIdeMask     = NUM0;
        LstSearchResult.ucSrcCanCh          = ucSrcCh;
        LstSearchResult.ucDestCanCh[IDX_0]  = NUM0;
        LstSearchResult.ucDestCanCh[IDX_1]  = NUM0;
        LstSearchResult.ucDestCanCh[IDX_2]  = NUM0;
        LstSearchResult.ucAddInfo           = NUM0;
        LstSearchResult.ucConvFlag          = NUM0;
        LstSearchResult.ulConvCanId         = NUM0;
        LstSearchResult.ucXLFlag            = NUM0;
        LstSearchResult.stXLParams.usPriorityId      = NUM0;
        LstSearchResult.stXLParams.usVcid            = NUM0;
        LstSearchResult.stXLParams.ucSduType         = NUM0;
        LstSearchResult.stXLParams.ulAcceptanceField = NUM0;
        LstSearchResult.stXLParams.ucSec             = NUM0;

        LucRetVal = SearchCanRoutTbl(ucSrcUnit, pCanFrame->ulCanDlc, pCanFrame->pCanData, &LstSearchResult
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
            #endif
            );
    }
    else
    {
        /* Do nothing. */
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if ((uint32)CANROUT_FLAG_SET == (uint32)LstSearchResult.ucConvFlag)
        {
            /* Convert CAN ID */
            LulCanId = LstSearchResult.ulConvCanId;
        }
        else
        {
            LulCanId = LulCanId | ((uint32)LucCanIde << SHIFT_31BIT);
        }

        /* Create CAN/CANFD frame */
        CanRout_GstCanFrame.ulCanDlc = pCanFrame->ulCanDlc;
        CanRout_GstCanFrame.ulCanId  = LulCanId;

        /* Create CANXL frame */
        CanRout_GstCanXLFrame.ulCanDlc = pCanFrame->ulCanDlc;

        /* Update CANXL Parameter or not depending on the value of CANXL Flag Bit 1. */
        if ((uint32)CANROUT_FLAG_SET == (((uint32)LstSearchResult.ucXLFlag >> SHIFT_1BIT) & (uint32)CANROUT_FLAG_SET))
        {
            CanRout_GstCanXLFrame.pXLParams->usPriorityId       = LstSearchResult.stXLParams.usPriorityId;
            CanRout_GstCanXLFrame.pXLParams->usVcid             = LstSearchResult.stXLParams.usVcid;
            CanRout_GstCanXLFrame.pXLParams->ucSduType          = LstSearchResult.stXLParams.ucSduType;
            CanRout_GstCanXLFrame.pXLParams->ulAcceptanceField  = LstSearchResult.stXLParams.ulAcceptanceField;
            CanRout_GstCanXLFrame.pXLParams->ucSec              = LstSearchResult.stXLParams.ucSec;
        }
        else
        {
            CanRout_GstCanXLFrame.pXLParams->usPriorityId       = pCanFrame->pXLParams->usPriorityId;
            CanRout_GstCanXLFrame.pXLParams->usVcid             = pCanFrame->pXLParams->usVcid;
            CanRout_GstCanXLFrame.pXLParams->ucSduType          = pCanFrame->pXLParams->ucSduType;
            CanRout_GstCanXLFrame.pXLParams->ulAcceptanceField  = pCanFrame->pXLParams->ulAcceptanceField;
            CanRout_GstCanXLFrame.pXLParams->ucSec              = pCanFrame->pXLParams->ucSec;
        }

        for (LulPayloadIndex = IDX_0; LulPayloadIndex < CanRout_GstCanFrame.ulCanDlc; LulPayloadIndex++)
        {
            CanRout_GaaCanData[LulPayloadIndex] = pCanFrame->pCanData[LulPayloadIndex];
        }
    }
    else
    {
        /* Do nothing. */
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        LucRetVal = CreateAndSendCan(&LstSearchResult, pMultiSendResult
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , ucSID
        #endif
        );
    }
    else
    {
        /* Do nothing. */
    }

    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_020]:[Gen5GW_CanRout_UD_03_018]
* Function Name: CreateAndSendCan
* Description  : SW Can Routing Function.
* Arguments    : pSearchResult -
*                    SW Routing Table Search result
*                pMultiSendResult -
*                    Multicast send result
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CreateAndSendCan(const R_CanRout_SwTblEntryType *pSearchResult, uint32 *pMultiSendResult
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        , const uint8 ucSID
    #endif
)
{
    Std_ReturnType LucRetVal;
    uint32 LulTransmitRetVal;
    uint8 LucDestUnit;
    uint8 LucDestCh;
    uint8 LucTransmitErrorFlag;

    LucRetVal = E_OK;
    LucTransmitErrorFlag = NUM0;

    for (LucDestUnit = NUM0; (uint32)LucDestUnit < (uint32)CANROUT_CANIP_UNIT_NUM; LucDestUnit++)
    {
        for (LucDestCh = NUM0; (uint32)LucDestCh < (uint32)CANROUT_RSCFD_CH_NUM; LucDestCh++)
        {
            LulTransmitRetVal = E_OK;
            /* CANXL frame received */
            if (((uint32)CANROUT_FLAG_SET ==
                ((uint32)((uint32)pSearchResult->ucDestCanCh[LucDestUnit] >> (uint32)LucDestCh) &
                (uint32)CANROUT_FLAG_SET)) &&
                ((uint32)CANROUT_FLAG_SET ==
                (uint32)((CanRout_GulSendEnableFlag >>
                ((uint32)LucDestCh + ((uint32)LucDestUnit * (uint32)CANROUT_RSCFD_CH_NUM))) &
                (uint32)CANROUT_FLAG_SET)))
            {
                /* Decide whether to use CAN or CANXL depending on the value of CANXL Flag Bit 0. */
                if ((CANROUT_CANXL_UNIT == LucDestUnit) &&
                    ((uint32)CANROUT_FLAG_SET == ((uint32)pSearchResult->ucXLFlag & (uint32)CANROUT_FLAG_SET)))
                {
                    LulTransmitRetVal = CanRout_XLTransmitUserDef(&CanRout_GstCanXLFrame, LucDestUnit, LucDestCh,
                    pSearchResult->ucAddInfo);
                }
                else
                {
                    LulTransmitRetVal = CanRout_TransmitUserDef(&CanRout_GstCanFrame, LucDestUnit, LucDestCh,
                    pSearchResult->ucAddInfo);
                }
            }
            else
            {
                /* Do nothing. */
            }
            
            if ((uint8)E_OK == LulTransmitRetVal)
            {
                /* Do nothing. */
            }
            else
            {
                *pMultiSendResult = (uint32)(*pMultiSendResult |
                    ((uint32)CANROUT_FLAG_SET <<
                    (uint32)((uint32)LucDestCh + ((uint32)LucDestUnit * (uint32)CANROUT_RSCFD_CH_NUM))));
                LucTransmitErrorFlag++;
            }
        }
    }
    
    if ((uint32)NUM0 == (uint32)LucTransmitErrorFlag)
    {
        /* Do nothing. */
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_TRANS);
        #endif
        LucRetVal = E_NOT_OK;
    }
    
    return LucRetVal;
}


/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_006]:[Gen5GW_CanRout_UD_03_006]
* Function Name: SearchCanRoutTbl
* Description  : SW Can Routing Function.
* Arguments    : ucSrcUnit -
*                    RS-CANFD unit number
*                ulCanDlc -
*                    received CAN DLC
*                *pCanData -
*                    received CAN payload data
*                *pSwTblEntry -
*                    in-out argument:[in]SrcCh, ulCanId, ucCanIde [out]result SW Routing
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) SearchCanRoutTbl(const uint8 ucSrcUnit, const uint32 ulCanDlc, const uint8 *pCanData,
    R_CanRout_SwTblEntryType *pSwTblEntry
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    )
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdx;
    uint32 LulCanIdMasked;
    uint32 LulTblCanIdMasked;
    uint8  LucCanIdeMasked;
    uint8  LucTblCanIdeMasked;
    uint8  LaaPayloadMasked[CANROUT_PAYLOAD_MAX_SIZE];
    uint8  LaaTblPayloadMasked[CANROUT_PAYLOAD_MAX_SIZE];
    uint8  LucPayloadIdx;
    uint32 LulPayloadLen;
    R_CanRout_SwTblEntryType *LpSwRoutTbl;

    LucRetVal = E_NOT_OK;


    /* Initialize local payload array */
    for (LucPayloadIdx = IDX_0; (uint32)LucPayloadIdx < (uint32)CANROUT_PAYLOAD_MAX_SIZE; LucPayloadIdx++)
    {
        LaaPayloadMasked[LucPayloadIdx] = NUM0;
        LaaTblPayloadMasked[LucPayloadIdx] = NUM0;
    }

    if ((uint32)NUM0 != (uint32)CanRout_GulSwRoutTblEntryNum[ucSrcUnit])
    {
        if (ulCanDlc > (uint32)CANROUT_PAYLOAD_MAX_SIZE)
        {
            LulPayloadLen = CANROUT_PAYLOAD_MAX_SIZE;
        }
        else
        {
            LulPayloadLen = ulCanDlc;
        }

        for (LulEntryIdx = IDX_0; LulEntryIdx < CanRout_GulSwRoutTblEntryNum[ucSrcUnit]; LulEntryIdx++)
        {
            LpSwRoutTbl        = &CanRout_GstSwRoutTbl[ucSrcUnit][LulEntryIdx];
            LulCanIdMasked     = pSwTblEntry->ulSrcCanId & LpSwRoutTbl->ulSrcCanIdMask;
            LucCanIdeMasked    = pSwTblEntry->ucSrcCanIde & LpSwRoutTbl->ucSrcCanIdeMask;
            LulTblCanIdMasked  = LpSwRoutTbl->ulSrcCanId & LpSwRoutTbl->ulSrcCanIdMask;
            LucTblCanIdeMasked = LpSwRoutTbl->ucSrcCanIde & LpSwRoutTbl->ucSrcCanIdeMask;

            for (LucPayloadIdx = IDX_0; (uint32)LucPayloadIdx < (uint32)LulPayloadLen; LucPayloadIdx++)
            {
                LaaPayloadMasked[LucPayloadIdx] =
                    pCanData[LucPayloadIdx] & LpSwRoutTbl->aaPayloadMask[LucPayloadIdx];
                LaaTblPayloadMasked[LucPayloadIdx] =
                    LpSwRoutTbl->aaPayload[LucPayloadIdx] & LpSwRoutTbl->aaPayloadMask[LucPayloadIdx];
            }

            if (((uint32)LpSwRoutTbl->ucSrcCanCh == (uint32)pSwTblEntry->ucSrcCanCh) &&
                (LulTblCanIdMasked  == LulCanIdMasked) &&
                ((uint32)LucTblCanIdeMasked == (uint32)LucCanIdeMasked) &&
                ((uint32)LaaTblPayloadMasked[IDX_0] == (uint32)LaaPayloadMasked[IDX_0]) &&
                ((uint32)LaaTblPayloadMasked[IDX_1] == (uint32)LaaPayloadMasked[IDX_1]) &&
                ((uint32)LaaTblPayloadMasked[IDX_2] == (uint32)LaaPayloadMasked[IDX_2]) &&
                ((uint32)LaaTblPayloadMasked[IDX_3] == (uint32)LaaPayloadMasked[IDX_3]) &&
                ((uint32)LaaTblPayloadMasked[IDX_4] == (uint32)LaaPayloadMasked[IDX_4]) &&
                ((uint32)LaaTblPayloadMasked[IDX_5] == (uint32)LaaPayloadMasked[IDX_5]) &&
                ((uint32)LaaTblPayloadMasked[IDX_6] == (uint32)LaaPayloadMasked[IDX_6]) &&
                ((uint32)LaaTblPayloadMasked[IDX_7] == (uint32)LaaPayloadMasked[IDX_7]))
            {
                pSwTblEntry->ucDestCanCh[IDX_0] = LpSwRoutTbl->ucDestCanCh[IDX_0];
                pSwTblEntry->ucDestCanCh[IDX_1] = LpSwRoutTbl->ucDestCanCh[IDX_1];
                pSwTblEntry->ucDestCanCh[IDX_2] = LpSwRoutTbl->ucDestCanCh[IDX_2];
                pSwTblEntry->ucAddInfo          = LpSwRoutTbl->ucAddInfo;
                pSwTblEntry->ucConvFlag         = LpSwRoutTbl->ucConvFlag;
                pSwTblEntry->ulConvCanId        = LpSwRoutTbl->ulConvCanId;
                pSwTblEntry->ucXLFlag           = LpSwRoutTbl->ucXLFlag;
                pSwTblEntry->stXLParams.usPriorityId      = LpSwRoutTbl->stXLParams.usPriorityId;
                pSwTblEntry->stXLParams.usVcid            = LpSwRoutTbl->stXLParams.usVcid;
                pSwTblEntry->stXLParams.ucSduType         = LpSwRoutTbl->stXLParams.ucSduType;
                pSwTblEntry->stXLParams.ulAcceptanceField = LpSwRoutTbl->stXLParams.ulAcceptanceField;
                pSwTblEntry->stXLParams.ucSec             = LpSwRoutTbl->stXLParams.ucSec;
                LucRetVal = E_OK;
                break;
            }
            else
            {
                /* Do nothing */
            }
        }
    }
    else
    {
        /* Skip Searching SW Routing Table */
    }
    if(E_OK != LucRetVal)
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_MATCH);
        #endif
    }
    else
    {
        /* Do nothing */
    }
    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_005]:[Gen5GW_CanRout_UD_03_005]
* Function Name: CanRout_UpdateSwTbl
* Description  : SW Can Routing Function.
* Arguments    : ucSrcUnit -
*                    RS-CANFD unit number
*                pSwTblType -
*                    SW Routing new setting parameter.
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_UpdateSwTbl(const uint8 ucSrcUnit, const R_CanRout_SwTblType *pSwTblType)
{
    Std_ReturnType LucRetVal;

    if ((uint32)ucSrcUnit < (uint32)CANROUT_CANIP_UNIT_NUM)
    {
        LucRetVal = CanRout_SetSwTbl(ucSrcUnit, pSwTblType
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , R_CANROUT_UPDATE_SWTBL_SID
            #endif
            );
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_SWTBL_SID,
                                                                                            CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}
#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
