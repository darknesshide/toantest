/***********************************************************************************************************************
* Copyright [2023-2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.26.0
* Description  : This file contains the process of Statistical functions.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanRout_stat.h"
#include "CDD_CanRout_common.h"
#include "CDD_CanRout_iodefine.h"
#include "CDD_CanRout_interface.h"

/* Included for the declaration of Det_ReportError() */
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANROUT_START_SEC_VAR_NO_INIT_32
#include "CanRout_MemMap.h" 
/* CANFD Statistical */
/* Send/Receive Successful Count */
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GaaSuccessCount[CANROUT_RSCFD_UNIT_NUM][CANROUT_RSCFD_CH_NUM];
/* Send/Receive Error Count */
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GaaErrorCount[CANROUT_RSCFD_UNIT_NUM][CANROUT_RSCFD_CH_NUM];

/* CANFD Statistics */
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GaaRxSuccessCount_Xl[CANROUT_CANXL_CH_NUM];
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GaaRxErrorCount_Xl[CANROUT_CANXL_CH_NUM];
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GaaTxSuccessCount_Xl[CANROUT_CANXL_CH_NUM];
STATIC VAR(uint32, CANROUT_VAR_NO_INIT) CanRout_GaaTxErrorCount_Xl[CANROUT_CANXL_CH_NUM];

#define CANROUT_STOP_SEC_VAR_NO_INIT_32
#include "CanRout_MemMap.h" 

#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_011]:[Gen5GW_CanRout_UD_03_011]
* Function Name: CanRout_StatCount
* Description  : Statistical information processing function.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, CANROUT_PRIVATE_CODE) CanRout_StatCount(void)
{
    uint8 LucUnitIdx;
    uint8 LucChIdx;
    uint32 LulRegSetVal;

    for (LucUnitIdx= IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_RSCFD_UNIT_NUM; LucUnitIdx++)
    {
        for (LucChIdx = IDX_0; (uint32)LucChIdx < (uint32)CANROUT_RSCFD_CH_NUM; LucChIdx++)
        {
            /* Read statistical successful count from CFDCNFDSTS Register */
            CanRout_GaaSuccessCount[LucUnitIdx][LucChIdx] += ((uint32)CANROUT_MAX_8BIT_VAL &
                (RSCAN_CFDCNFDSTS(LucUnitIdx, LucChIdx) >> (uint32)SHIFT_24BIT));
            /* Read statistical error count from CFDCNFDSTS Register */
            CanRout_GaaErrorCount[LucUnitIdx][LucChIdx] += ((uint32)CANROUT_MAX_8BIT_VAL &
                (RSCAN_CFDCNFDSTS(LucUnitIdx, LucChIdx) >> (uint32)SHIFT_16BIT));
            
            /* Clear statistical counters(both successful and error counter) */
            LulRegSetVal = (RSCAN_CFDCNFDCTR(LucUnitIdx, LucChIdx) | (uint32)CANROUT_MAX_2BIT_VAL);
            RSCAN_CFDCNFDCTR(LucUnitIdx, LucChIdx) = LulRegSetVal;
            
            /* Clear statistical count Global variables */
            if (CanRout_GaaSuccessCount[LucUnitIdx][LucChIdx] >= (uint32)COUNT_THRESHOLD)
            {
                CanRout_NotifyStatUserDef(LucUnitIdx, LucChIdx, (uint8)CANROUT_STAT_SUCCESS,
                    CanRout_GaaSuccessCount[LucUnitIdx][LucChIdx]);
                CanRout_ClearCount(LucUnitIdx, LucChIdx, (uint8)CANROUT_STAT_SUCCESS);
            }
            else
            {
                /* Do nothing. */
            }
            
            if (CanRout_GaaErrorCount[LucUnitIdx][LucChIdx] >= (uint32)COUNT_THRESHOLD)
            {
                CanRout_NotifyStatUserDef(LucUnitIdx, LucChIdx, (uint8)CANROUT_STAT_ERROR,
                    CanRout_GaaErrorCount[LucUnitIdx][LucChIdx]);
                CanRout_ClearCount(LucUnitIdx, LucChIdx, (uint8)CANROUT_STAT_ERROR);
            }
            else
            {
                /* Do nothing. */
            }
        }
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_021]:[Gen5GW_CanRout_UD_03_021]
* Function Name: CanRout_StatCount_XL
* Description  : Statistical information processing function for CANXL.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
FUNC(void, CANROUT_PRIVATE_CODE) CanRout_StatCount_XL(void)
{
    uint8 LucChIdx;
    uint32 LulRegSetVal;
    uint32 LulRxStats;
    uint32 LulTxStats;
    uint32 LulStatIntSts;
    uint16 LusRxSuccessCount;
    uint16 LusRxErrorCount;
    uint16 LusTxSuccessCount;
    uint16 LusTxErrorCount;

    for (LucChIdx = IDX_0; (uint32)LucChIdx < (uint32)CANROUT_CANXL_CH_NUM; LucChIdx++)
    {
        /* Check and handle wrap interrupts to prevent data loss */
        LulStatIntSts = CANXL_STATS_INT_STS(LucChIdx);
        if (LulStatIntSts != 0U)
        {
            /* RX Success counter wrapped (bit 0) */
            if ((LulStatIntSts & CANXL_STATS_INT_RX_SUCC_WRAP) != 0U)
            {
                /* Add 4096 (max 12-bit value + 1) to account for wrap */
                CanRout_GaaRxSuccessCount_Xl[LucChIdx] += CANXL_STAT_WRAP_ADD_VALUE;
            }
            else
            {
                /* Do nothing. */
            }
            
            /* RX Unsuccessful counter wrapped (bit 1) */
            if ((LulStatIntSts & CANXL_STATS_INT_RX_UNSUCC_WRAP) != 0U)
            {
                /* Add 4096 to account for wrap */
                CanRout_GaaRxErrorCount_Xl[LucChIdx] += CANXL_STAT_WRAP_ADD_VALUE;
            }
            else
            {
                /* Do nothing. */
            }
            
            /* TX Success counter wrapped (bit 2) */
            if ((LulStatIntSts & CANXL_STATS_INT_TX_SUCC_WRAP) != 0U)
            {
                /* Add 4096 to account for wrap */
                CanRout_GaaTxSuccessCount_Xl[LucChIdx] += CANXL_STAT_WRAP_ADD_VALUE;
            }
            else
            {
                /* Do nothing. */
            }
            
            /* TX Unsuccessful counter wrapped (bit 3) */
            if ((LulStatIntSts & CANXL_STATS_INT_TX_UNSUCC_WRAP) != 0U)
            {
                /* Add 4096 to account for wrap */
                CanRout_GaaTxErrorCount_Xl[LucChIdx] += CANXL_STAT_WRAP_ADD_VALUE;
            }
            else
            {
                /* Do nothing. */
            }
            
            /* Clear interrupt status by writing 1 to the bits */
            CANXL_STATS_INT_STS(LucChIdx) = LulStatIntSts;
        }
        else
        {
            /* No wrap interrupt, do nothing. */
        }

        /* Read RX Statistics (Offset 0x404) */
        LulRxStats = CANXL_RX_STATISTICS(LucChIdx);
        LusRxSuccessCount = (uint16)(LulRxStats & CANXL_STAT_COUNTER_MAX);
        LusRxErrorCount = (uint16)((LulRxStats >> SHIFT_16BIT) & CANXL_STAT_COUNTER_MAX);

        /* Read TX Statistics (Offset 0x104) */
        LulTxStats = CANXL_TX_STATISTICS(LucChIdx);
        LusTxSuccessCount = (uint16)(LulTxStats & CANXL_STAT_COUNTER_MAX);
        LusTxErrorCount = (uint16)((LulTxStats >> SHIFT_16BIT) & CANXL_STAT_COUNTER_MAX);

        /* Collect counters */
        CanRout_GaaRxSuccessCount_Xl[LucChIdx] += (uint32)LusRxSuccessCount;
        CanRout_GaaRxErrorCount_Xl[LucChIdx] += (uint32)LusRxErrorCount;
        CanRout_GaaTxSuccessCount_Xl[LucChIdx] += (uint32)LusTxSuccessCount;
        CanRout_GaaTxErrorCount_Xl[LucChIdx] += (uint32)LusTxErrorCount;

        /* Clear hardware counters */
        /* Clear RX counters - preserve reserved bits */
        LulRegSetVal = LulRxStats & CANXL_STAT_RESERVED_MASK;
        CANXL_RX_STATISTICS(LucChIdx) = LulRegSetVal;

        /* Clear TX counters - preserve reserved bits */
        LulRegSetVal = LulTxStats & CANXL_STAT_RESERVED_MASK;
        CANXL_TX_STATISTICS(LucChIdx) = LulRegSetVal;

        /* Check thresholds and notify - RX Success */
        if (CanRout_GaaRxSuccessCount_Xl[LucChIdx] >= (uint32)COUNT_THRESHOLD)
        {
            CanRout_NotifyStatUserDef(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_RX_SUCCESS,
                CanRout_GaaRxSuccessCount_Xl[LucChIdx]);
            CanRout_ClearCount(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_RX_SUCCESS);
        }
        else
        {
            /* Do nothing. */
        }
        
        /* RX Error */
        if (CanRout_GaaRxErrorCount_Xl[LucChIdx] >= (uint32)COUNT_THRESHOLD)
        {
            CanRout_NotifyStatUserDef(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_RX_ERROR,
                CanRout_GaaRxErrorCount_Xl[LucChIdx]);
            CanRout_ClearCount(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_RX_ERROR);
        }
        else
        {
            /* Do nothing. */
        }
        
        /* TX Success */
        if (CanRout_GaaTxSuccessCount_Xl[LucChIdx] >= (uint32)COUNT_THRESHOLD)
        {
            CanRout_NotifyStatUserDef(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_TX_SUCCESS,
                CanRout_GaaTxSuccessCount_Xl[LucChIdx]);
            CanRout_ClearCount(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_TX_SUCCESS);
        }
        else
        {
            /* Do nothing. */
        }
        
        /* TX Error */
        if (CanRout_GaaTxErrorCount_Xl[LucChIdx] >= (uint32)COUNT_THRESHOLD)
        {
            CanRout_NotifyStatUserDef(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_TX_ERROR,
                CanRout_GaaTxErrorCount_Xl[LucChIdx]);
            CanRout_ClearCount(CANROUT_CANXL_UNIT, LucChIdx, 
                (uint8)CANROUT_STAT_XL_TX_ERROR);
        }
        else
        {
            /* Do nothing. */
        }
    }

}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_013]:[Gen5GW_CanRout_UD_03_013]
* Function Name: CanRout_GetCount
* Description  : Get Statistical counter information.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                ucCh -
*                    RS-CANFD channel number
*                ucCounterType -
*                    Counter type(Success or Error)
*                pCount -
*                    Counter value
* Return Value : N/A
*******************************************************************************/
FUNC(void, CANROUT_PRIVATE_CODE) CanRout_GetCount(const uint8 ucUnit, const uint8 ucCh,
                      const uint8 ucCounterType, uint32 *pCount)
{
    /* Check if CANXL unit */
    if ((uint32)CANROUT_CANXL_UNIT == (uint32)ucUnit)
    {
        /* CANXL Statistics */
        switch (ucCounterType)
        {
            case CANROUT_STAT_XL_RX_SUCCESS:
                *pCount = CanRout_GaaRxSuccessCount_Xl[ucCh];
                break;
            case CANROUT_STAT_XL_RX_ERROR:
                    *pCount = CanRout_GaaRxErrorCount_Xl[ucCh];
                    break;
            case CANROUT_STAT_XL_TX_SUCCESS:
                *pCount = CanRout_GaaTxSuccessCount_Xl[ucCh];
                break;   
            case CANROUT_STAT_XL_TX_ERROR:
                *pCount = CanRout_GaaTxErrorCount_Xl[ucCh];
                break;
            default:
                break;
        }
    }
    else
    {
        /* CANFD Statistical */
        if ((uint32)CANROUT_STAT_SUCCESS == (uint32)ucCounterType)
        {
            *pCount = CanRout_GaaSuccessCount[ucUnit][ucCh];
        }
        else if ((uint32)CANROUT_STAT_ERROR == (uint32)ucCounterType)
        {
            *pCount = CanRout_GaaErrorCount[ucUnit][ucCh];
        }
    } 
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_015]:[Gen5GW_CanRout_UD_03_015]
* Function Name: CanRout_ClearCount
* Description  : Clear Statistical counter information.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                ucCh -
*                    RS-CANFD channel number
*                ucCounterType -
*                    Counter type(Success or Error)
* Return Value : N/A
*******************************************************************************/
FUNC(void, CANROUT_PRIVATE_CODE) CanRout_ClearCount(const uint8 ucUnit, const uint8 ucCh, const uint8 ucCounterType)
{
    /* Check if CANXL unit */
    if ((uint32)CANROUT_CANXL_UNIT == (uint32)ucUnit)
    {
        /* CANXL Statistics */
        switch (ucCounterType)
        {
            case CANROUT_STAT_XL_RX_SUCCESS:
                CanRout_GaaRxSuccessCount_Xl[ucCh] = NUM0;
                break;
            case CANROUT_STAT_XL_RX_ERROR:
                CanRout_GaaRxErrorCount_Xl[ucCh] = NUM0;
                break;
            case CANROUT_STAT_XL_TX_SUCCESS:
                CanRout_GaaTxSuccessCount_Xl[ucCh] = NUM0;
                break;
            case CANROUT_STAT_XL_TX_ERROR:
                CanRout_GaaTxErrorCount_Xl[ucCh] = NUM0;
                break;
            default:
                break;
        }
    }
    else
    {
        if ((uint32)CANROUT_STAT_SUCCESS == (uint32)ucCounterType)
        {
            CanRout_GaaSuccessCount[ucUnit][ucCh] = NUM0;
        }
        else if ((uint32)CANROUT_STAT_ERROR == (uint32)ucCounterType)
        {
            CanRout_GaaErrorCount[ucUnit][ucCh] = NUM0;
        }
    }
}
#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
