/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains the process of Table Setting functions.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanRout_tblsetting.h"
#include "CDD_CanRout_common.h"
#include "CDD_CanRout_iodefine.h"

/* Included for the declaration of Det_ReportError() */
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

STATIC FUNC(void, CANROUT_PRIVATE_CODE) SetAflEntryAll(const uint8 ucUnit, const uint32 ulEntryNum, const R_CanRout_HwTblType *pHwtblConfig);
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CheckHwTbl(const R_CanRout_HwTblEntryType *pHwtblEntryConfig
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    );

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_001]:[Gen5GW_CanRout_UD_02_001]
* Function Name: CanRout_SetHwTbl
* Description  : Checks ALF configuration and sets them to AFL entries of RS-CANFD.
* Arguments    : ucUnit -
*                    RS-CANFD unit number
*                pHwtblConfig -
*                    ALF configuration
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_SetHwTbl(const uint8 ucUnit, const R_CanRout_HwTblType *pHwtblConfig)
{
    Std_ReturnType LucRetVal;
    uint32 LulChIdx;
    uint32 LulEntryIdx;
    uint32 LulRuleNum;

    LucRetVal = E_OK;
    LulRuleNum = NUM0;
    
    if ((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM)
    {
        if (NULL_PTR == pHwtblConfig->pHwTblEntry)
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_CFG_HWTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        /* Checks whether rule number per channel is under the MAX value. */
        for (LulChIdx = IDX_0; LulChIdx < (uint32)CANROUT_RSCFD_CH_NUM; LulChIdx++)
        {
            if (pHwtblConfig->aaEntryNumPerCh[LulChIdx] <= (uint32)MAX_RULE_PER_CH_NUM)
            {
                LulRuleNum += pHwtblConfig->aaEntryNumPerCh[LulChIdx];
            }
            else
            {
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_CFG_HWTBL);
                #endif
                LucRetVal = E_NOT_OK;
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    /* Checks whether rule number per unit is under the MAX value. */
    if ((uint8)E_OK == LucRetVal)
    {
        if (LulRuleNum <= (uint32)MAX_RULE_PER_UNIT_NUM)
        {
            /* Do nothing */
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_CFG_HWTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    /* Checks whether values of each rule are under the MAX value. */
    if ((uint8)E_OK == LucRetVal)
    {
        for (LulEntryIdx = IDX_0; LulEntryIdx < LulRuleNum; LulEntryIdx++)
        {
            LucRetVal = CheckHwTbl(&pHwtblConfig->pHwTblEntry[LulEntryIdx]
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                , R_CANROUT_INIT_SID
                #endif
                );
            if ((uint8)E_OK == LucRetVal)
            {
                /* Do nothing (Checks value of next entry.) */
            }
            else
            {
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    /* Sets AFL entries of RS-CANFD */
    if ((uint8)E_OK == LucRetVal)
    {
        SetAflEntryAll(ucUnit, LulRuleNum, pHwtblConfig);
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_002]:[Gen5GW_CanRout_UD_02_002]
* Function Name: SetAflEntryAll
* Description  : Sets AFL entries of RS-CANFD.
* Arguments    : ucUnit -
*                    RS-CANFD unit number
*                ulEntryNum -
*                    Number of AFL entries
*                pHwtblConfig -
*                    ALF configuration
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(void, CANROUT_PRIVATE_CODE) SetAflEntryAll(const uint8 ucUnit, const uint32 ulEntryNum,
                           const R_CanRout_HwTblType *pHwtblConfig)
{
    uint32 LulEntryIdx;
    uint32 LulEntryIdxInPage;
    uint32 LulPage;
    uint32 LulRegSetVal;

    LulEntryIdxInPage = NUM0;
    LulPage = NUM0;

    /* Sets AFLDAE bit to enable write access to the AFL. */
    LulRegSetVal = RSCAN_AFLEC(ucUnit);
    RSCAN_AFLEC(ucUnit) = LulRegSetVal | ((uint32)REG_BIT_SET << SHIFT_8BIT);
    /* Sets the number of entries for each channel. (RSCFDnCFDGAFLCFGv) */
    LulRegSetVal = ((pHwtblConfig->aaEntryNumPerCh[IDX_0] << SHIFT_16BIT) |
                    (pHwtblConfig->aaEntryNumPerCh[IDX_1]));
    RSCAN_AFLC(ucUnit).CFDGAFLCFG[IDX_0] = LulRegSetVal;
    LulRegSetVal = ((pHwtblConfig->aaEntryNumPerCh[IDX_2] << SHIFT_16BIT) |
                    (pHwtblConfig->aaEntryNumPerCh[IDX_3]));
    RSCAN_AFLC(ucUnit).CFDGAFLCFG[IDX_1] = LulRegSetVal;
    LulRegSetVal = ((pHwtblConfig->aaEntryNumPerCh[IDX_4] << SHIFT_16BIT) |
                    (pHwtblConfig->aaEntryNumPerCh[IDX_5]));
    RSCAN_AFLC(ucUnit).CFDGAFLCFG[IDX_2] = LulRegSetVal;
    LulRegSetVal = ((pHwtblConfig->aaEntryNumPerCh[IDX_6] << SHIFT_16BIT) |
                    (pHwtblConfig->aaEntryNumPerCh[IDX_7]));
    RSCAN_AFLC(ucUnit).CFDGAFLCFG[IDX_3] = LulRegSetVal;
    /* Selects first page number to access. (Sets AFLPN bit.) */
    LulRegSetVal = RSCAN_AFLEC(ucUnit);
    LulRegSetVal = (uint32)(LulRegSetVal & (uint32)AFLPN_BIT_MASK);
    RSCAN_AFLEC(ucUnit) = LulRegSetVal;

    for (LulEntryIdx = IDX_0; LulEntryIdx < ulEntryNum; LulEntryIdx++)
    {
        /* Sets AFL entries. (RSCFDnCFDGAFLIDj) */
        LulRegSetVal = (((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucSrcCanIde) << SHIFT_31BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucSrcCanRtr) << SHIFT_30BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucLoopbackCfg) << SHIFT_29BIT) |
                         pHwtblConfig->pHwTblEntry[LulEntryIdx].ulSrcCanId);
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLIDr = LulRegSetVal;
        /* Sets AFL entries. (RSCFDnCFDGAFLMj) */
        LulRegSetVal = (((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucSrcCanIdeMask) << SHIFT_31BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucSrcCanRtrMask) << SHIFT_30BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].aaInfoLabel[IDX_1]) << SHIFT_29BIT) |
                         pHwtblConfig->pHwTblEntry[LulEntryIdx].ulSrcCanIdMask);
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLMr = LulRegSetVal;
        /* Sets AFL entries. (RSCFDnCFDGAFLP0j) */
        LulRegSetVal = (((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].usPtrInfo) << SHIFT_16BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucRmbValid) << SHIFT_15BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucRmbDest) << SHIFT_8BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].aaInfoLabel[IDX_0]) << SHIFT_7BIT) |
                        ((uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucSelRoutDest) << SHIFT_4BIT) |
                         (uint32)(pHwtblConfig->pHwTblEntry[LulEntryIdx].ucDlc));
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLP0r = LulRegSetVal;
        /* Sets AFL entries. (RSCFDnCFDGAFLP1j) */
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLP1r
                       = pHwtblConfig->pHwTblEntry[LulEntryIdx].ulFifoDest;

        LulEntryIdxInPage++;
        if (LulEntryIdxInPage < (uint32)MAX_RULE_PER_PAGE_NUM)
        {
            /* Do nothing (Continues setting ALF entries in this page.) */
        }
        else
        {
            LulEntryIdxInPage = NUM0;
            LulPage++;
            /* Updates page number to access. (Updates AFLPN bit.) */
            LulRegSetVal = (uint32)RSCAN_AFLEC(ucUnit);
            LulRegSetVal = (LulRegSetVal & (uint32)AFLPN_BIT_MASK);
            RSCAN_AFLEC(ucUnit) = (LulRegSetVal | LulPage);
        }
   }
   /* Clears AFLDAE bit to disable write access to the AFL. */
   LulRegSetVal = RSCAN_AFLEC(ucUnit);
   RSCAN_AFLEC(ucUnit) = LulRegSetVal & ~((uint32)REG_BIT_SET << SHIFT_8BIT);
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_02_005]:[Gen5GW_CanRout_UD_02_005]
* Function Name: CheckHwTbl
* Description  : Checks ALF configuration.
* Arguments    : pHwtblEntryConfig - 
*                    One ALF entry configuration
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CheckHwTbl(const R_CanRout_HwTblEntryType *pHwtblEntryConfig
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    )
{
    Std_ReturnType LucRetVal;
    uint32 LulBitIdx;
    uint32 LulFifoDestCount;
    
    LucRetVal = E_OK;
    LulFifoDestCount = NUM0;
    
    if ((NULL_PTR != pHwtblEntryConfig) &&
        (pHwtblEntryConfig->ulSrcCanId <= (uint32)CANROUT_MAX_29BIT_VAL) &&
        (pHwtblEntryConfig->ulSrcCanIdMask <= (uint32)CANROUT_MAX_29BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucSrcCanIde) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucSrcCanIdeMask) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucSrcCanRtr) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucSrcCanRtrMask) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->aaInfoLabel[IDX_0]) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->aaInfoLabel[IDX_1]) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucLoopbackCfg) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucDlc) <= (uint32)CANROUT_MAX_4BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucSelRoutDest) <= (uint32)CANROUT_MAX_3BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucRmbValid) <= (uint32)CANROUT_MAX_1BIT_VAL) &&
        ((uint32)(pHwtblEntryConfig->ucRmbDest) <= (uint32)CANROUT_MAX_7BIT_VAL)
        )
    {
        /* RXMB Configuration Check */
        for (LulBitIdx = IDX_0; LulBitIdx < (uint32)CANROUT_BIT_32; LulBitIdx++)
        {
            LulFifoDestCount += (pHwtblEntryConfig->ulFifoDest >> LulBitIdx) & (uint32)CANROUT_MAX_1BIT_VAL;
        }
        if ((LulFifoDestCount < (uint32)CANROUT_DESTFIFO_NUM_MAX) || 
        ((LulFifoDestCount == (uint32)CANROUT_DESTFIFO_NUM_MAX) && 
        ((uint32)CANROUT_FLAG_CLR == (uint32)pHwtblEntryConfig->ucRmbValid)))
        {
            /* Do nothing. */
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_CFG_HWTBL);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_CFG_HWTBL);
        #endif
        LucRetVal = E_NOT_OK;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_02_004]:[Gen5GW_CanRout_UD_02_004]
* Function Name: CanRout_UpdateHwTbl
* Description  : Update AFL entries of RS-CANFD.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                ulEntryIdx -
*                    Update Index Number of AFL entries
*                pHwtblEntryConfig - 
*                    ALF configuration of one entry
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_UpdateHwTbl(const uint8 ucUnit, const uint32 ulEntryIdx,
    const R_CanRout_HwTblEntryType *pHwtblEntryConfig)
{
    Std_ReturnType LucRetVal;
    uint32 LulEntryIdxInPage;
    uint32 LulPage;
    uint32 LulTotalEntryNum;
    uint32 LulEntryIdxInCh;
    uint32 LulUpdateChIdx;
    uint32 LulRegVal;
    uint32 LaaEachChEntryNum[CANROUT_RSCFD_CH_NUM];
    uint32 LulChIdx;
    uint32 LulRegIdx;
    
    LulChIdx = NUM0;
    LulTotalEntryNum = IDX_0;
    LulUpdateChIdx = CANROUT_MAX_32BIT_VAL;
    LulEntryIdxInCh = IDX_0;
    
    /* Check ulEntry whether not less than register setting entry number or not */
    if (ulEntryIdx <= (uint32)MAX_RULE_PER_UNIT_NUM)
    {
        LucRetVal = CheckHwTbl(pHwtblEntryConfig
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , R_CANROUT_UPDATE_HWTBL_SID
            #endif
            );
    }
    else
    {
        /* Invalid Entry Index number */
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_HWTBL_SID,
                                                                                            CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Get each channel entry number and update channel number */
        for (LulRegIdx = IDX_0; LulRegIdx < (uint32)CFDGAFLCFG_NUM; LulRegIdx++)
        {
            LulRegVal = RSCAN_AFLC(ucUnit).CFDGAFLCFG[LulRegIdx];
            LaaEachChEntryNum[LulChIdx] = ((LulRegVal >> (uint32)SHIFT_16BIT) & (uint32)CANROUT_MASK_9BIT_VAL);
            LaaEachChEntryNum[LulChIdx + IDX_1] = (LulRegVal & (uint32)CANROUT_MASK_9BIT_VAL);
            LulChIdx += (uint32)IDX_2;
        }
        
        /* Calculate entry index and channel number */
        for (LulChIdx = IDX_0; LulChIdx < (uint32)CANROUT_RSCFD_CH_NUM; LulChIdx++)
        {
            LulTotalEntryNum += LaaEachChEntryNum[LulChIdx];
            if (ulEntryIdx < LulTotalEntryNum)
            {
                LulUpdateChIdx = LulChIdx;
                LulEntryIdxInCh = ulEntryIdx - (LulTotalEntryNum - LaaEachChEntryNum[LulChIdx]);
                break;
            }
            else
            {
                /* Do nothing. */
            }
        }
        if ((uint32)CANROUT_MAX_32BIT_VAL != LulUpdateChIdx)
        {
            /* Do nothing. */
        }
        else
        {
            /* Update channel index was not found. */
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_HWTBL_SID,
                                                                                            CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing. */
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        /* Set entry number and a channel number */
        RSCAN_GAFLIGNENT(ucUnit) = ((LulUpdateChIdx << SHIFT_16BIT) | LulEntryIdxInCh);
        
        /* Set the value (key code & enable bit) */
        RSCAN_GAFLIGNCTR(ucUnit) = AFL_IGNORE_ENABLE;
        
        /* Get Page index and Entry index in page */
        LulEntryIdxInPage = ulEntryIdx % (uint32)MAX_RULE_PER_PAGE_NUM;
        LulPage = ulEntryIdx / (uint32)MAX_RULE_PER_PAGE_NUM;
        
        /* Sets AFLDAE bit to enable write access to the AFL. */
        LulRegVal = RSCAN_AFLEC(ucUnit);
        RSCAN_AFLEC(ucUnit) = (uint32)(LulRegVal | (uint32)AFL_DATAACCESS_ENABLE);
        
        /* Set entry page. (Sets AFLPN bit.) */
        LulRegVal = RSCAN_AFLEC(ucUnit);
        LulRegVal = (uint32)(LulRegVal & (uint32)AFLPN_BIT_MASK);
        RSCAN_AFLEC(ucUnit) = (LulRegVal | LulPage);
        
        /* Sets AFL entries. (RSCFDnCFDGAFLIDj) */
        LulRegVal = (((uint32)(pHwtblEntryConfig->ucSrcCanIde) << SHIFT_31BIT) |
                        ((uint32)(pHwtblEntryConfig->ucSrcCanRtr) << SHIFT_30BIT) |
                        ((uint32)(pHwtblEntryConfig->ucLoopbackCfg) << SHIFT_29BIT) |
                         pHwtblEntryConfig->ulSrcCanId);
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLIDr = LulRegVal;
        /* Sets AFL entries. (RSCFDnCFDGAFLMj) */
        LulRegVal = (((uint32)(pHwtblEntryConfig->ucSrcCanIdeMask) << SHIFT_31BIT) |
                        ((uint32)(pHwtblEntryConfig->ucSrcCanRtrMask) << SHIFT_30BIT) |
                        ((uint32)(pHwtblEntryConfig->aaInfoLabel[IDX_1]) << SHIFT_29BIT) |
                         pHwtblEntryConfig->ulSrcCanIdMask);
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLMr = LulRegVal;
        /* Sets AFL entries. (RSCFDnCFDGAFLP0j) */
        LulRegVal = (((uint32)(pHwtblEntryConfig->usPtrInfo) << SHIFT_16BIT) |
                        ((uint32)(pHwtblEntryConfig->ucRmbValid) << SHIFT_15BIT) |
                        ((uint32)(pHwtblEntryConfig->ucRmbDest) << SHIFT_8BIT) |
                        ((uint32)(pHwtblEntryConfig->aaInfoLabel[IDX_0]) << SHIFT_7BIT) |
                        ((uint32)(pHwtblEntryConfig->ucSelRoutDest) << SHIFT_4BIT) |
                         (uint32)(pHwtblEntryConfig->ucDlc));
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLP0r = LulRegVal;
        /* Sets AFL entries. (RSCFDnCFDGAFLP1j) */
        RSCAN_AFLE(ucUnit).CFDGAFL[LulEntryIdxInPage].CFDGAFLP1r
                     = pHwtblEntryConfig->ulFifoDest;
        
        /* Clears AFLDAE bit to disable write access to the AFL. */
        LulRegVal = RSCAN_AFLEC(ucUnit);
        RSCAN_AFLEC(ucUnit) = (LulRegVal & ~(AFL_DATAACCESS_ENABLE));
        
        /* Disable to access Hw Table entry register settings. */
        RSCAN_GAFLIGNCTR(ucUnit) = AFL_IGNORE_DISABLE;
    }
    else
    {
        /* Do nothing. */
    }
    
    return LucRetVal;
}
#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
