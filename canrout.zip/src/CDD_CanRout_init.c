/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains the process of Initialization functions.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanRout_init.h"
#include "CDD_CanRout_tblsetting.h"
#include "CDD_CanRout_common.h"
#include "CDD_CanRout_swrout.h"
#include "CDD_CanRout_iodefine.h"

/* Included for the declaration of Det_ReportError() */
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/


/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_02_001]:[Gen5GW_CanRout_UD_01_002]
* Function Name: CanRout_Init
* Description  : Initializes CAN routing table setting.
* Arguments    : pConfig -
*                    CAN Routing Configuration
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_Init(const R_CanRout_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;
    uint8 LucUnitIdx;

    LucRetVal = E_OK;

    if ((uint32)CANROUT_CHECK_CODE == pConfig->ulIntegrityCheck)
    {
        for (LucUnitIdx = IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_RSCFD_UNIT_NUM; LucUnitIdx++)
        {
            if ((NULL_PTR != pConfig->pHwTbl[LucUnitIdx]))
            {
                /* Do nothing. */
            }
            else
            {
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID,
                                                                                            CANROUT_E_CONFIG_PARAM);
                #endif
                LucRetVal = E_NOT_OK;
                break;
            }
        }
        if ((uint8)E_OK == LucRetVal)
        {
            for (LucUnitIdx = IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_CANIP_UNIT_NUM; LucUnitIdx++)
            {
                if (NULL_PTR != pConfig->pSwTbl[LucUnitIdx])
                {
                    /* Do nothing. */
                }
                else
                {
                    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                    /* Report to DET */
                    (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID,
                                                                                            CANROUT_E_CONFIG_PARAM);
                    #endif
                    LucRetVal = E_NOT_OK;
                    break;
                }
            }
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_CFG);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        for (LucUnitIdx = IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_RSCFD_UNIT_NUM; LucUnitIdx++)
        {
            if ((uint32)CANROUT_FLAG_SET == ((uint32)pConfig->ucUnitSetFlag[LucUnitIdx] & (uint32)CANROUT_FLAG_SET))
            {
                /* Sets AFL entries. */
                LucRetVal = CanRout_SetHwTbl(LucUnitIdx, pConfig->pHwTbl[LucUnitIdx]);
                if ((uint8)E_OK == LucRetVal)
                {
                    /* Do nothing */
                }
                else
                {
                    break;
                }
            }
            else
            {
                /* Skip initialization. */
            }
        }
        if ((uint8)E_OK == LucRetVal)
        {
            for (LucUnitIdx = IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_CANIP_UNIT_NUM; LucUnitIdx++)
            {
                if ((uint32)CANROUT_SWINITFLAG_SET == ((uint32)pConfig->ucUnitSetFlag[LucUnitIdx] & 
                                                                                        (uint32)CANROUT_SWINITFLAG_SET))
                {
                    /* Sets SW Routing Table. */
                    LucRetVal = CanRout_SetSwTbl(LucUnitIdx, pConfig->pSwTbl[LucUnitIdx]
                        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                        , R_CANROUT_INIT_SID
                        #endif
                        );
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Do nothing */
                    }
                    else
                    {
                        break;
                    }
                }
                else
                {
                    /* Skip initialization. */
                }
            }
        }
        else
        {
             /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}
#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
