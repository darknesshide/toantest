/***********************************************************************************************************************
* Copyright [2023-2024] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.22.0
* Description  : This file contains the process of Utility functions for Can Rout.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include "CDD_CanRout_util.h"
#include "CDD_CanRout_common.h"

/* Included for the declaration of Det_ReportError() */
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/

/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_05_001]:[Gen5GW_CanRout_UD_05_001]
* Function Name: CanRout_UtilCanIdCheck
* Description  : Check CAN ID range.
* Arguments    : ulCanId -
*                    received CAN ID
*                ucCanIde -
*                    received CAN IDE
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_UtilCanIdCheck(const uint32 ulCanId, const uint8 ucCanIde
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    )
{
    Std_ReturnType LucRetVal;

    LucRetVal = E_OK;

    if ((uint32)CANROUT_FLAG_CLR == (uint32)ucCanIde)
    {
        if ((ulCanId <= (uint32)CANID_BASE_MAX) || 
            /* New CANFD range */
            (((uint32)CANFD_ID_BASE_MIN <= ulCanId) && (ulCanId <= (uint32)CANFD_ID_BASE_MAX)))
        {
            /* return E_OK*/
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else if ((uint32)CANROUT_FLAG_SET == (uint32)ucCanIde)
    {
        if ((ulCanId <= (uint32)CANROUT_MAX_29BIT_VAL) ||
            /* New CANFD range */
            (((uint32)CANFD_ID_BASE_MIN <= ulCanId) && (ulCanId <= (uint32)CANROUT_FD_MAX_29BIT_VAL)))
        {
           /* return E_OK*/
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_05_002]:[Gen5GW_CanRout_UD_05_002]
* Function Name: CanRout_UtilCanDlcCheck
* Description  : Check CAN DLC range.
* Arguments    : ulCanDlc -
*                    received CAN DLC
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CanRout_UtilCanDlcCheck(const uint32 ulCanDlc
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    )
{
    Std_ReturnType LucRetVal;

    if ((ulCanDlc <= (uint32)CANROUT_DLC_8) ||
        ((uint32)CANROUT_DLC_12 == ulCanDlc) ||
        ((uint32)CANROUT_DLC_16 == ulCanDlc) ||
        ((uint32)CANROUT_DLC_20 == ulCanDlc) ||
        ((uint32)CANROUT_DLC_24 == ulCanDlc) ||
        ((uint32)CANROUT_DLC_32 == ulCanDlc) ||
        ((uint32)CANROUT_DLC_48 == ulCanDlc) ||
        ((uint32)CANROUT_DLC_64 == ulCanDlc))
    {
        LucRetVal = E_OK;
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}
#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
