/***********************************************************************************************************************
* Copyright [2023-2026] Renesas Electronics Corporation and/or its licensors. All Rights Reserved.
*
* The contents of this file (the "contents") are proprietary and confidential to Renesas Electronics Corporation
* and/or its licensors ("Renesas") and subject to statutory and contractual protections.
*
* Unless otherwise expressly agreed in writing between Renesas and you: 1) you may not use, copy, modify, distribute,
* display, or perform the contents; 2) you may not use any name or mark of Renesas for advertising or publicity
* purposes or in connection with your use of the contents; 3) RENESAS MAKES NO WARRANTY OR REPRESENTATIONS ABOUT THE
* SUITABILITY OF THE CONTENTS FOR ANY PURPOSE; THE CONTENTS ARE PROVIDED "AS IS" WITHOUT ANY EXPRESS OR IMPLIED
* WARRANTY, INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
* NON-INFRINGEMENT; AND 4) RENESAS SHALL NOT BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, OR CONSEQUENTIAL DAMAGES,
* INCLUDING DAMAGES RESULTING FROM LOSS OF USE, DATA, OR PROJECTS, WHETHER IN AN ACTION OF CONTRACT OR TORT, ARISING
* OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THE CONTENTS. Third-party contents included in this file may
* be subject to different terms.
***********************************************************************************************************************/
/***********************************************************************************************************************
* Version      : 0.26.0
* Description  : This file contains the process to access registers used in the Initialization function.
***********************************************************************************************************************/

/*******************************************************************************
Includes   <System Includes> , "Project Includes"
*******************************************************************************/

#include "CDD_CanRout_api.h"
#include "CDD_CanRout_init.h"
#include "CDD_CanRout_iodefine.h"
#include "CDD_CanRout_common.h"
#include "CDD_CanRout_swrout.h"
#include "CDD_CanRout_tblsetting.h"
#include "CDD_CanRout_stat.h"

/* including DEM header file */
#include "Dem.h"

/* Included for the declaration of Det_ReportError() */
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
#include "Det.h"
#endif

/*******************************************************************************
Macro definitions
*******************************************************************************/

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables (to be accessed by other files)
*******************************************************************************/
#define CANROUT_START_SEC_VAR_INIT_8
#include "CanRout_MemMap.h"    
VAR(uint8, CANROUT_VAR_INIT) CanRout_GucInitStatus = CANROUT_STS_UNINIT;
#define CANROUT_STOP_SEC_VAR_INIT_8
#include "CanRout_MemMap.h" 

#define CANROUT_START_SEC_VAR_INIT_32
#include "CanRout_MemMap.h" 
VAR(uint32, CANROUT_VAR_INIT) CanRout_GulSendEnableFlag = NUM0;
#define CANROUT_STOP_SEC_VAR_INIT_32
#include "CanRout_MemMap.h" 

#define CANROUT_START_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanRout_MemMap.h" 
VAR(R_CanRout_HwTblType, CANROUT_VAR_NO_INIT) *CanRout_GpHwTblEntry; 
#define CANROUT_STOP_SEC_VAR_NO_INIT_UNSPECIFIED
#include "CanRout_MemMap.h" 
/*******************************************************************************
Private global variables and functions
*******************************************************************************/
#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) GetGblMode(const uint8 ucUnit, CanRout_GblModeType *pGblMode 
    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
    #endif
    );
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CheckGblMode(const uint8 ucUnit, CanRout_GblModeType enGblMode);
STATIC FUNC(void, CANROUT_PRIVATE_CODE) GetChannelMode(const uint8 ucUnit, const uint8 ucCh, CanRout_ChannelModeType *pChannelMode);
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CheckChannelMode(const uint8 ucUnit);

#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

#define CANROUT_START_SEC_PUBLIC_CODE
#include "CanRout_MemMap.h"
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_01_001]:[Gen5GW_CanRout_UD_01_001]
* Function Name: R_CanRout_Init
* Description  : Initializes CAN Routing (routing table setting).
* Arguments    : pConfig -
*                    CAN Routing Configuration
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_Init(const R_CanRout_CfgType *pConfig)
{
    Std_ReturnType LucRetVal;
    uint8 LucUnitIdx;
    uint8 LucChIdx;

    LucRetVal = E_OK;

    if ((uint32)CANROUT_STS_UNINIT == (uint32)CanRout_GucInitStatus)
    {
        if (NULL_PTR != pConfig)
        {
            /* Continues the process. */
            CanRout_GpHwTblEntry = (R_CanRout_HwTblType *) pConfig[NUM0].pHwTbl[NUM0];
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, 
                                                                                        CANROUT_E_ALREADY_INITIALIZED);
            #endif
            /* R_CanRout_Init has already been executed. */
            LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        for (LucUnitIdx = IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_RSCFD_UNIT_NUM; LucUnitIdx++)
        {
            if ((uint32)CANROUT_FLAG_SET == ((uint32)pConfig->ucUnitSetFlag[LucUnitIdx] & (uint32)CANROUT_FLAG_SET))
            {
                /* Gets Global mode of RS-CANFD. */
                LucRetVal = CheckGblMode(LucUnitIdx, GL_RESET_MODE);
                if ((uint8)E_OK == LucRetVal)
                {
                    /* Checks Channel mode of RS-CANFD. */
                    LucRetVal = CheckChannelMode(LucUnitIdx);
                    if ((uint8)E_OK == LucRetVal)
                    {
                        /* Do nothing */
                    }
                    else
                    {
                        /* Exit Loop */
                        break;
                    }
                }
                else
                {
                    /* Exit Loop */
                    break;
                }
            }
            else
            {
                /* Skip getting Global mode of RS-CANFD. */
            }
        }

        if ((uint8)E_OK == LucRetVal)
        {
            LucRetVal = CanRout_Init(pConfig);
        }
        else
        {
            /* Do nothing */
        }

        if ((uint8)E_OK == LucRetVal)
        {
            CanRout_GucInitStatus = CANROUT_STS_INIT;
            CanRout_GulSendEnableFlag = CANROUT_MAX_18BIT_VAL;

            /* Initialize statistical global variables. */
            for (LucUnitIdx = IDX_0; (uint32)LucUnitIdx < (uint32)CANROUT_RSCFD_UNIT_NUM; LucUnitIdx++)
            {
                for (LucChIdx = IDX_0; (uint32)LucChIdx < (uint32)CANROUT_RSCFD_CH_NUM; LucChIdx++)
                {
                    CanRout_ClearCount(LucUnitIdx, LucChIdx, CANROUT_STAT_SUCCESS);
                    CanRout_ClearCount(LucUnitIdx, LucChIdx, CANROUT_STAT_ERROR);
                }
            }
        }
        else
        {
            /* Do nothing */
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}
#define CANROUT_STOP_SEC_PUBLIC_CODE
#include "CanRout_MemMap.h"

#define CANROUT_START_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_01_002]:[Gen5GW_CanRout_UD_01_003]
* Function Name: GetGblMode
* Description  : Gets Global Mode of RS-CANFD.
* Arguments    : ucUnit -
*                    RS-CANFD unit number
*                pGblMode -
*                    Global Mode of RS-CANFD
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) GetGblMode(const uint8 ucUnit, CanRout_GblModeType *pGblMode
#if (CANROUT_DEV_ERROR_DETECT == STD_ON)
    , const uint8 ucSID
#endif
)
{
    Std_ReturnType LucRetVal;
    uint32 LulRegVal;
    uint32 LulSleepFlag;

    LucRetVal = E_OK;

    if((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM)
    {
        /* Gets Global Mode of RS-CANFD */
        LulRegVal = RSCAN_GSTS(ucUnit);
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, ucSID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        LulSleepFlag = LulRegVal >> SHIFT_2BIT;
        if ((uint32)CANROUT_FLAG_SET == LulSleepFlag)
        {
            *pGblMode = GL_SLEEP_MODE;
        }
        else
        {
            switch (LulRegVal)
            {
            case RSCFD_GL_OPERATION_MODE:
                *pGblMode = GL_OPERATION_MODE;
                break;
            case RSCFD_GL_RESET_MODE:
                *pGblMode = GL_RESET_MODE;
                break;
            case RSCFD_GL_HALT_MODE:
                *pGblMode = GL_HALT_MODE;
                break;
            default:
                /* Report to DEM */
                #if defined(CANROUT_E_HARDWARE_ERROR)
                (void)Dem_SetEventStatus(CANROUT_E_HARDWARE_ERROR, DEM_EVENT_STATUS_FAILED);
                #endif
                LucRetVal = E_NOT_OK;
                break;
            }
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_01_003]:[Gen5GW_CanRout_UD_02_006]
* Function Name: GetChannelMode
* Description  : Gets Channel Mode of RS-CANFD.
* Arguments    : ucUnit -
*                    RS-CANFD unit number
*                pChannelMode -
*                    Channel Mode of RS-CANFD
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(void, CANROUT_PRIVATE_CODE) GetChannelMode(const uint8 ucUnit, const uint8 ucCh, CanRout_ChannelModeType *pChannelMode)
{
    uint32 LulRegVal;

    /* Gets Channel Mode of RS-CANFD */
    LulRegVal = RSCAN_CFDCNSTS(ucUnit, ucCh);
   *pChannelMode = (CanRout_ChannelModeType)(LulRegVal & (uint32) RSCFD_CH_STATUS);

}
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_01_004]:[Gen5GW_CanRout_UD_01_004]
* Function Name: CheckGblMode
* Description  : Check Global Mode of RS-CANFD.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                enGblMode -
*                    Global Mode of RS-CANFD
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CheckGblMode(const uint8 ucUnit, CanRout_GblModeType enGblMode)
{
    Std_ReturnType LucRetVal;
    CanRout_GblModeType LenGblMode;
    
    /* GL_SLEEP_MODE is MAX value in CanRout_GblModeType enum. */
    if (enGblMode <= GL_SLEEP_MODE)
    {
        LenGblMode = GL_OPERATION_MODE;
        LucRetVal  = GetGblMode(ucUnit, &LenGblMode
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            , R_CANROUT_INIT_SID
            #endif
            );
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_INV_PARAM);
        #endif
        LucRetVal = E_NOT_OK;
    }

    if ((uint8)E_OK == LucRetVal)
    {
        if (enGblMode == LenGblMode)
        {
            /* Do nothing */
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_REG);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        /* Do nothing */
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_01_005]:[Gen5GW_CanRout_UD_01_005]
* Function Name: CheckGblMode
* Description  : Check Channel Mode of RS-CANFD.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                enChannelMode -
*                    Channel Mode of RS-CANFD
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
STATIC FUNC(Std_ReturnType, CANROUT_PRIVATE_CODE) CheckChannelMode(const uint8 ucUnit)
{
    Std_ReturnType LucRetVal;
    CanRout_ChannelModeType LenChannelMode;
    uint8 LucChIdx;

    LucRetVal = E_OK;
    
    /* Gets Channel Mode of RS-CANFD */
    for (LucChIdx = IDX_0; (uint32)LucChIdx < (uint32)CANROUT_RSCFD_CH_NUM; LucChIdx++)
    {
        GetChannelMode(ucUnit, LucChIdx, &LenChannelMode);

        /* Report DET error if channel mode is not reset mode or halt mode */
        if (CH_SLEEP_MODE == (LenChannelMode & CH_SLEEP_MODE))
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_INIT_SID, CANROUT_E_REG);
            #endif
            LucRetVal = E_NOT_OK;
            /* Exit Loop */
            break;
        }
        else
        {
            /* Do nothing */
        }
    }

    return LucRetVal;
}
#define CANROUT_STOP_SEC_PRIVATE_CODE
#include "CanRout_MemMap.h"

#define CANROUT_START_SEC_PUBLIC_CODE
#include "CanRout_MemMap.h"
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_012]:[Gen5GW_CanRout_UD_03_002]
* Function Name: R_CanRout_SwRout
* Description  : SW Can Routing Function.
* Arguments    : pCanFrame -
*                    received CAN ID, DLC, payload data
*                ucSrcUnit - 
*                    CAN-IP unit number
*                ucSrcCh -
*                    RS-CANFD channel number
*                pMultiSendResult -
*                    Multicast send result
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_SwRout(const R_CanRout_CanFrameType *pCanFrame, 
                        const uint8 ucSrcUnit, const uint8 ucSrcCh, uint32 *pMultiSendResult)
{
    Std_ReturnType LucRetVal;

    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if ((NULL_PTR != pCanFrame) && (NULL_PTR != pCanFrame->pCanData) && (NULL_PTR != pMultiSendResult))
        { 
            /* Initialize MuitiSendResult */
            *pMultiSendResult = NUM0;
            LucRetVal = CanRout_SwRout(pCanFrame, ucSrcUnit, ucSrcCh, pMultiSendResult
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                , R_CANROUT_SWROUT_SID
                #endif
                );
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_SWROUT_SID, 
                                                                                            CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_SWROUT_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_018]:[Gen5GW_CanRout_UD_03_016]
* Function Name: R_CanRout_XLSwRout
* Description  : SW Can Routing Function.
* Arguments    : pCanFrame -
*                    received CAN ID, DLC, payload data
*                ucSrcUnit - 
*                    CAN-IP unit number
*                ucSrcCh -
*                    CANXL IP channel number
*                pMultiSendResult -
*                    Multicast send result
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_XLSwRout(const R_CanRout_CanXLFrameType *pCanFrame,
                        const uint8 ucSrcUnit, const uint8 ucSrcCh, uint32 *pMultiSendResult)
{
    Std_ReturnType LucRetVal;

    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if ((NULL_PTR != pCanFrame) && (NULL_PTR != pCanFrame->pCanData) && (NULL_PTR != pMultiSendResult))
        {
            /* Initialize MuitiSendResult */
            *pMultiSendResult = NUM0;
            LucRetVal = CanRout_XLSwRout(pCanFrame, ucSrcUnit, ucSrcCh, pMultiSendResult
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                , R_CANROUT_XLSWROUT_SID
                #endif
                );
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_XLSWROUT_SID,
                                                                                            CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_XLSWROUT_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_004]:[Gen5GW_CanRout_UD_03_004]
* Function Name: R_CanRout_UpdateSwTbl
* Description  : SW Can Routing Function.
* Arguments    : ucSrcUnit -
*                    CAN-IP unit number
*                pSwTblType -
*                    SW Routing new setting parameter
* Return Value : E_OK -
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_UpdateSwTbl(const uint8 ucSrcUnit, const R_CanRout_SwTblType *pSwTblType)
{
    Std_ReturnType LucRetVal;

    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if (NULL_PTR != pSwTblType)
        {
            LucRetVal = CanRout_UpdateSwTbl(ucSrcUnit, pSwTblType);
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_SWTBL_SID,
                                                                                            CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_SWTBL_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}
/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_007]:[Gen5GW_CanRout_UD_03_007]
* Function Name: R_CanRout_SendEnable
* Description  : Gets Global Mode of CAN-IP.
* Arguments    : ucUnit - 
*                    CAN-IP unit number
*                ucCh -
*                    CAN-IP channel number
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_SendEnable(const uint8 ucUnit, const uint8 ucCh)
{
    Std_ReturnType LucRetVal;
    
    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if ((((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM) && ((uint32)ucCh < (uint32)CANROUT_RSCFD_CH_NUM)) ||
            ((ucUnit == CANROUT_CANXL_UNIT) && (ucCh < (uint32)CANROUT_CANXL_CH_NUM)))
        {
            CanRout_GulSendEnableFlag = (uint32)(CanRout_GulSendEnableFlag
            | ((uint32)CANROUT_FLAG_SET << (uint32)(((uint32)ucUnit * (uint32)CANROUT_RSCFD_CH_NUM) + (uint32)ucCh)));
            LucRetVal = E_OK;   
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_SEND_ENABLE_SID,
                                                                                                CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_SEND_ENABLE_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_008]:[Gen5GW_CanRout_UD_03_008]
* Function Name: R_CanRout_SendDisable
* Description  : Gets Global Mode of CAN-IP.
* Arguments    : ucUnit - 
*                    CAN-IP unit number
*                ucCh -
*                    CAN-IP channel number
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_SendDisable(const uint8 ucUnit, const uint8 ucCh)
{
    Std_ReturnType LucRetVal;
    
    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if ((((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM) && ((uint32)ucCh < (uint32)CANROUT_RSCFD_CH_NUM)) ||
            ((ucUnit == CANROUT_CANXL_UNIT) && (ucCh < (uint32)CANROUT_CANXL_CH_NUM)))
        {
            CanRout_GulSendEnableFlag = (uint32)(CanRout_GulSendEnableFlag
                & (~((uint32)CANROUT_FLAG_SET <<
                ((uint32)((uint32)ucUnit * (uint32)CANROUT_RSCFD_CH_NUM) + (uint32)ucCh))));
            LucRetVal = E_OK;
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_SEND_DISABLE_SID,
                                                                                                CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_SEND_DISABLE_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_009]:[Gen5GW_CanRout_UD_03_009]
* Function Name: R_CanRout_GetSendStatus
* Description  : Gets Global Mode of CAN-IP.
* Arguments    : pStatus - 
*                    Send status
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_GetSendStatus(uint32 *pStatus)
{
    Std_ReturnType LucRetVal;
    
    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if (pStatus != NULL_PTR)
        {
            *pStatus = CanRout_GulSendEnableFlag;
            LucRetVal = E_OK;
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_GET_SEND_STATUS_SID,
                                                                                            CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_GET_SEND_STATUS_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_02_003]:[Gen5GW_CanRout_UD_02_003]
* Function Name: R_CanRout_UpdateHwTbl
* Description  : Checks ALF configuration and Update AFL entries of RS-CANFD.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                ulEntryIdx -
*                    Update Index Number of AFL entries
*                pHwtblEntryConfig - 
*                    ALF configuration of one entry
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_UpdateHwTbl(const uint8 ucUnit, const uint32 ulEntryIdx,
    const R_CanRout_HwTblEntryType *pHwtblEntryConfig)
{
    Std_ReturnType LucRetVal;
    CanRout_GblModeType LenGblMode;
    CanRout_ChannelModeType LenChannelMode;
    uint8 LucCh;

    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if ((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM)
        {
            if (NULL_PTR != pHwtblEntryConfig)
            {
                LucRetVal = GetGblMode(ucUnit, &LenGblMode
                    #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                    , R_CANROUT_UPDATE_HWTBL_SID
                    #endif
                    );
            }
            else
            {
                #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
                /* Report to DET */
                (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_HWTBL_SID,
                                                                                                CANROUT_E_PARAM_POINTER);
                #endif
                LucRetVal = E_NOT_OK;
            }
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_HWTBL_SID,
                                                                                            CANROUT_E_INV_PARAM);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_HWTBL_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }
    
    if ((uint8)E_OK == LucRetVal)
    {
        LucCh = CanRout_GpHwTblEntry[ucUnit].pHwTblEntryMapping[ulEntryIdx];
        GetChannelMode(ucUnit, LucCh, &LenChannelMode);
        if ((GL_SLEEP_MODE == LenGblMode) || (CH_SLEEP_MODE == (LenChannelMode & CH_SLEEP_MODE)))
        {
            /* RS-CANFD is Sleep Mode. */
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_UPDATE_HWTBL_SID, CANROUT_E_REG);
            #endif
            LucRetVal = E_NOT_OK;
        }
        else
        {
            /* Update AFL entries of RS-CANFD */
            LucRetVal = CanRout_UpdateHwTbl(ucUnit, ulEntryIdx, pHwtblEntryConfig);
        }
    }
    else
    {
        /* Do nothing */
    }
    
    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_016]:[Gen5GW_CanRout_UD_03_010]
* Function Name: R_CanRout_MainFunction
* Description  : Main function for statistical function.
* Arguments    : N/A
* Return Value : N/A
*******************************************************************************/
void R_CanRout_MainFunction(void)
{
    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        /* CANFD Statistical */
        CanRout_StatCount();
        /* CANXL Statistical */
        CanRout_StatCount_XL();
    }
    else
    {
        /* Do nothing. */
    }
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_017]:[Gen5GW_CanRout_UD_03_012]
* Function Name: R_CanRout_GetCount
* Description  : Get Statistical counter information.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                ucCh -
*                    RS-CANFD channel number
*                ucCounterType -
*                    Counter type(Success or Error)
*                pCount -
*                    Counter value
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_GetCount(const uint8 ucUnit, const uint8 ucCh,
                          const uint8 ucCounterType, uint32 *pCount)
{
    Std_ReturnType LucRetVal;
    
    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if (((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM) &&
            ((uint32)ucCh < (uint32)CANROUT_RSCFD_CH_NUM) &&
            ((uint32)ucCounterType <= (uint32)CANROUT_STAT_SUCCESS) &&
            (NULL_PTR != pCount))
        {
            CanRout_GetCount(ucUnit, ucCh, ucCounterType, pCount);
            LucRetVal = E_OK;
        }
        else if (((ucUnit == CANROUT_CANXL_UNIT) && 
                (ucCh < (uint32)CANROUT_CANXL_CH_NUM)) && 
            ((uint32)ucCounterType >= (uint32)CANROUT_STAT_XL_RX_ERROR) && 
            ((uint32)ucCounterType <= (uint32)CANROUT_STAT_XL_TX_SUCCESS) && 
            (NULL_PTR != pCount))
        {
            CanRout_GetCount(ucUnit, ucCh, ucCounterType, pCount);
            LucRetVal = E_OK;
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_GET_COUNT_SID,
                                                                                            CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_GET_COUNT_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

/*******************************************************************************
* Function ID  : [Gen5GW_CanRout_CD_03_014]:[Gen5GW_CanRout_UD_03_014]
* Function Name: R_CanRout_ClearCount
* Description  : Clear Statistical counter information.
* Arguments    : ucUnit - 
*                    RS-CANFD unit number
*                ucCh -
*                    RS-CANFD channel number
*                ucCounterType -
*                    Counter type(Success or Error)
* Return Value : E_OK - 
*                    Successful completion
*                E_NOT_OK -
*                    Unsuccessful completion
*******************************************************************************/
FUNC(Std_ReturnType, CANROUT_PUBLIC_CODE) R_CanRout_ClearCount(const uint8 ucUnit, const uint8 ucCh, const uint8 ucCounterType)
{
    Std_ReturnType LucRetVal;
    
    if ((uint32)CANROUT_STS_INIT == (uint32)CanRout_GucInitStatus)
    {
        if (((uint32)ucUnit < (uint32)CANROUT_RSCFD_UNIT_NUM) &&
            ((uint32)ucCh < (uint32)CANROUT_RSCFD_CH_NUM) &&
            ((uint32)ucCounterType <= (uint32)CANROUT_STAT_SUCCESS))
        {
            CanRout_ClearCount(ucUnit, ucCh, ucCounterType);
            LucRetVal = E_OK;
        }
        else if (((ucUnit == CANROUT_CANXL_UNIT) && 
                (ucCh < (uint32)CANROUT_CANXL_CH_NUM)) && 
            ((uint32)ucCounterType >= (uint32)CANROUT_STAT_XL_RX_ERROR) && 
            ((uint32)ucCounterType <= (uint32)CANROUT_STAT_XL_TX_SUCCESS))
        {
            CanRout_ClearCount(ucUnit, ucCh, ucCounterType);
            LucRetVal = E_OK;
        }
        else
        {
            #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
            /* Report to DET */
            (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_CLEAR_COUNT_SID,
                                                                                            CANROUT_E_PARAM_POINTER);
            #endif
            LucRetVal = E_NOT_OK;
        }
    }
    else
    {
        #if (CANROUT_DEV_ERROR_DETECT == STD_ON)
        /* Report to DET */
        (void)Det_ReportError(CANROUT_MODULE_ID, CANROUT_INSTANCE_ID, R_CANROUT_CLEAR_COUNT_SID, CANROUT_E_UNINIT);
        #endif
        LucRetVal = E_NOT_OK;
    }

    return LucRetVal;
}

#define CANROUT_STOP_SEC_PUBLIC_CODE
#include "CanRout_MemMap.h"

