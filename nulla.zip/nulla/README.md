# NetworkUniversalLowLatencyAccelerator

This is a simulation environment for a CPU based network accelerator.

It bases on RISC-V core (Hazard3) used for Raspberry PI MCU.
This core allows a single port bus design as well as a dual ported one.
The dual ported variant is similar to the architecture we are using in
our RH850 products. The speed is similar to the G4MH used in U2A.

There are three RAMs (all 128 kByte for simplification) connected
to the CPU:

- Code RAM (typically our Flash)
- Data RAM (for local variables and the configuration tables)
- Buffer RAM (intended to emulate a 2-port RAM. One side is for read, one
side for write). This is used for the data transfer to the peripherals.

In a first check, the system is simulated in about 1.5 MHz in realtime.
This allows even to simulate later longer CAN and Ethernet data sequences.

The code is "flashed" before simulation starts.

For simple feedback from software there SFR defines triggering a print
to stdout.

For CAN/Ethernet communication the environment has a python interface.
This allows time triggered interaction with the C-Code for example for stimulus
generation as well as event triggered interaction for example for checking.


## A Getting started

### 1. Clone this project

~~~bash
git clone ssh://git@gitlab.eur.eng.renesas.com:2222/automotive-network-section-ans/mcu-and-realtime/nulla.git
~~~

Our gitlab server need a key based authentification. See https://gitlab.eur.eng.renesas.com/groups/automotive-network-section-ans/-/wikis/Create-a-key-to-access-the-git-lab-server-in-ubuntu for details.

### 2. Required software

- verilator
- gcc for riscv
- gtkwave (or any other waveform viewer)
- python3 development environment

#### 2.1 Verilator

From Ubuntu-24.04 there is a suitable verilator version available. Use `sudo apt install verilator`.

In earlier versions like Ubuntu-22.04 there is a version 4.038 inside the repository which can be installed.
It is proven but some linting comments needs to be adapted. To minimise the risk of
incompatibilities inside the CPU core, the version 5.018 is the preferred one. This is
the latest version supporting for GCC-11. As the internal indexes has changed, between
these verilator 4.x and 5.x , the differences are adjusted by `VERILATOR4` defines
inside the testbench C code.

~~~bash
sudo apt install git help2man flex bison python3-dev
git clone https://github.com/verilator/verilator
cd verilator
git checkout v5.018
autoconf
./configure
make -j 4
sudo make install
~~~
Note select the `-j 4` according to the CPUs on your machine, do not overload :-)

#### 2.2 Cross compiler

For gcc see https://github.com/Wren6991/Hazard3.
Recommended installation is `/opt/riscv` and added to search path as `PATH=$PATH:/opt/riscv/gcc14-no-zcmp/bin`.
There is a pre-compiled version available you can copy and install on amd64 (about 1.3 GByte).

~~~bash
scp p620.adwin.renesas.com:/opt/riscv/gcc14-no-zcmp.tar.bz .
sudo mkdir /opt/riscv
sudo tar xjf gcc14-no-zcmp.tar.bz -C /opt/riscv
rm gcc14-no-zcmp.tar.bz

echo PATH=$PATH:/opt/riscv/gcc14-no-zcmp/bin >> ~/.bashrc
~~~

#### 2.3 Gtkwave

You can use the version priovided by package manager.

~~~bash
sudo apt install gtkwave
~~~

#### 2.4 Python3 development environment

You can use the version priovided by package manager.

~~~bash
 sudo apt install python3-dev
~~~

### 3. Simulate the hello world.

The Makefiles allows to simulate either from the simulation folder `./sim` or
from the source code folder for example from `./apps/hello`.

Using the simulation folder is recommended when expanding or debugging the
RTL or simulation environment itself. This Makefile has
full support to control about build conditions, waveform generation and debug options.

Using the application folder is recommended when working and running the application.

~~~bash
cd ./apps/hello
make run
~~~

Note: Adding `NOSILENT=1` helps to understand problems during make execution.


### 4. Hello World with python interface

There is an example as `./apps/pyhello` showing interaction between
C an PY code.


### 5. Overview of example C and PY codes

All example code is in `./apps`.

| Application | Description |
|---       |--- |
| hello    | Hello World for C-Code side |
| pyworld  | Hello World for C and Python side |
| ifhello  | Hello World using the CAN/Eth interface traffic generator and checker |
| datacopy | Performance check data copy and duplication |
| lookup   | Performance check table lookup in BIN and LINEAR manner |
| testsfr  | Check RA specific SFR access and function |


Additionally there are some libraries provided

| Library | Description |
|---       |--- |
| moduleComif  | Python module provides CAN/Eth interface traffic generator and checked |
| moduleEvents | Python module for event based simulation. Used by moduleComif |
| moduleVdc    | Python module to output VCD waveform files |
| stdlib       | Startup and standard library functions for C-Code |
| ra_adrmap.h  | Header file for standard library and RA hardware |
| mmap-nostdlib.ld | Default linker file |



## B Python interface

The python interface provides a tick based event execution. A python script has to
do all things required at the current tick time and provide a *single*
time when the next tick shall be generated. Typically the python script
have its own dynamic event handler managing a bunch of future events.

The different python call-back functions are called only in sequential manner, no need to
lock. For the C code and simulation side the python code execution is in *zero time*.

**Attention**: The simulation can be aborted by `Ctrl-C` inside the
simulation code and inside the python code. But python's signal handler
pauses during calls into C extensions, if the code hangs in such a section
press `Ctrl-C` twice.
When installing an own Python-side signal handler, this
function becomes disabled.

The python script have to provide these functions called by simulation:


### 1. Call back functions

#### 1.1 main()

~~~python
def main(now):
    ...
    return nextTick
~~~
**Mandatory function**

Called from simulator at simulation time `now`=0 before
the simulation and C code execution starts (DPE stays in reset).

Intended to provide the python side initialisation code. This is called

The return value `nextTick` defines the time when the first tick
shall be generated.
- `> 0` time of next tick
- `-1` in case of error (ends the simulation)


#### 1.2 tick()

~~~python
def tick(now):
    ...
    return nextTick
~~~
**Mandatory function**

Called from simulator at simulation time `now` in ns.

The return value `nextTick` defines the time when the next tick
shall be generated.
- `> now` time of next tick in ns
- `0` for last `tick()` execution but simulation continues
- `-1` in case of error (ends the simulation)

It is possible to reschedule and restart the tick generation
by a feedback event.


#### 1.3 feedback()

~~~python
def feedback(now, signalName, index, value):
    ...
    return nextTick
~~~
**Optional function**

Called to provide information of hardware signals (like interrupts) or SFR
register changes (like write by C code) to python. `now` provides the
current simulation time in ns.

If using python controlled wave file generation, the feedback function allows
to mirror hardware states into this file, too.

`signalName` and `index` define the scope of event. The mapping is defined in `tb_top.cpp`.\
`value` is the new value of the signal.

The return value `nextTick` defines the time when the next tick
shall be generated.
- `> now` time of next tick in ns (overwrites the return value of last `tick()`)
- `0` no tick operation (next event is unchanged)
- `-1` in case of error (ends the simulation)


#### 1.4 cleanup()
~~~python
def cleanup(now):
    ...
    return result
~~~
**Optional function**

Called before the simulation ends. Intended for python side cleanup.
The return is used as result of test execution. The return value of C-Code has higher priority.


### 2. Environment maintained by simulation

A set of *normal* python variables is maintained by simulator:

| Variable | Description |
|--- |--- |
| `sys.argv` | Parameters provided by simulator command line |
| `argv[0]` | Name of this python script. |
| `os.getcwd()` | The current working dir is set to the folder of the python script. |


Specific variables:

| Variable | Description |
|--- |--- |
| `ra.TICKFACTOR` | Provides the relation between simulation clock and the ns time. It can be used to predict rounding effects. For example in case of 100 MHz simulation clock the `TICKFACTOR` is 10. |
| `ra.CODERAM` | Provide Code RAM outline as list `[base, size]`. The size is given in bytes. <br> This RAM contains the C-Code (.text) and the constant data (.rodata). The addresses are maintained by the linker and not predictable. |
| `ra.DATARAM` | Provide Data RAM outline as list `[base, size]`. The size is given in bytes. <br> This RAM contains the data of C-Code (.bss) and the stack (.stack). |
| `ra.BUFRAMIN` | Provide Input Buffer RAM outline as list `[base, size]`. The size is given in bytes. <br> This is intended to emulate the IO-Buffers of the peripheral IPs. The C-Code accesses this RAM using absolute addresses. |
| `ra.BUFRAMOUT` | Provide Output Buffer RAM outline as list `[base, size]`. The size is given in bytes. <br> This is intended to emulate the IO-Buffers of the peripheral IPs. The C-Code accesses this RAM using absolute addresses. |
| `ra.SRAM` | Provide external System RAM outline as list `[base, size]`. The size is given in bytes. <br> This RAM is intended to emulate the Ethernet, CAN-XL, and software (MCAL) data structures maintained by external world. The C-Code accesses this RAM using absolute addresses. |

The intention is to use a part of DATARAM for TUBE configuration. This fits to the
harvard architecture of PE; access to data RAM is faster, as it is possible to
access code and data RAMs in parallel.

See [address map](docu/hw-addressmap.md) for the full address map of TUBE.


### 3. API to simulation

#### 3.1 ra.now()

~~~python
def ra.now():
~~~

Returns the current simulation time in ns.


#### 3.2 ra.clock()

~~~python
def ra.clock():
~~~

Returns the current simulation clock cycle number.


#### 3.3 ra.write()

~~~python
def ra.write(addr, size, pList):
~~~

Returns the next address to be written. Raises an error
in case of failure.

`addr` Address as per memory layout. Only access to the RAM
modules is possible by this function.
This address needs to be 32-bit, independent from the the given size.
In case of 8 bit write, remaining bytes are written as 0x00.

`size` Data size in bits, either 8 or 32.

`pList` is a list of data values.

Example storing 2 words (8 bytes) into Buffer RAM:\
`ra.write(ra.BUFRAM[0]+0x200, 32, [0x12345678, 0xaabbccdd])`


#### 3.4 ra.read()

~~~python
def ra.read(addr, size. length):
~~~

Returns a list of read values.

`addr` Address as per memory layout. Only access to the RAM
modules is possible by this function.
This address needs to be 32-bit, independent from the the given size.

`size` Data size in bits, either 8 or 32.

`length` Number of values to be read.

Example reading 12 bytes in byte or long granularity\
`ra.read(ra.DATARAM[0]+0x200, 8, 12)`\
`ra.read(ra.DATARAM[0]+0x200, 32, 3)`


#### 3.5 ra.markIngressValid()

~~~python
def ra.markIngressValid(bufferNumber):
~~~
**SFR emulation function**

Returns *True* when given buffer could be marked as valid and it was empty before.

This function informs the C-Code that there is new data available in
ingress buffer. This allows to model **Rx-Message handler** providing data to the software.
There is no pre-defined mapping between these valid SFR and the buffer outline.


#### 3.6 ra.markEgressFree()

~~~python
def ra.markEgressFree(bufferNumber):
~~~
**SFR emulation function**

Returns *True* when given buffer could be marked as free and was used before.

This function is used inform the C-Code that the data provided in egress buffer is handled.
This allows to model **Tx-Message handler** consuming the data provided by software before.
There is no pre-defined mapping between these valid SFR and the buffer outline.


#### 3.7 ra.markInFifoAvailable()

~~~python
def ra.markInFifoAvailable(extFifoNumber):
~~~
**SFR emulation function**

Returns 0 when the FIFO was full, the number of pending entries in case of success.

In case of Ethernet targets having the FIFO in SRAM, the return value is always 1,
because the model cannot check the status of software controlled FIFO in SRAM.

This function is used inform the C-Code that the data provided in ComIP's Rx-FIFO.
This allows to model ComIP's **Rx-Message handler**.


#### 3.8 ra.verboseRead

~~~python
ra.verboseRead = True
~~~
**Environment configuration**

When set to *True* `ra.read()` provides verbose messages during execution.
By default this function is disabled (*False*).

#### 3.9 ra.verboseWrite

~~~python
ra.verboseWrite = True
~~~
**Environment configuration**

When set to *True* `ra.write()` provides verbose messages during execution.
By default this function is disabled (*False*).


## C Python communication simulation

For the communication simulation there is an event based simulation module.
See [canif module](docu/cansim.md) for details.


## D Hardware and SFR layout

The Network Universal Low Latency Accelerator consists on three components,
the hardware model including DPE and offloader to allow a quite accurate
performance judgement, the CRAM containing the code executed by DPE, and
a peripheral emulation is realised inside the integrated Python environment.

The initial load of CRAM content is done by the simulation environment
before the initialise the Python environment and release reset from DPE.

Runtime configuration like routing tables can be either part of the
"C-Code" binary, for example by tables in header files and place in
Data RAM per linker file, or by the Python environment. For simplification
it is recommended to use the Python environment, as both sides need
to know configuration.

![Block diagram of Nulla](docu/nulla-top.svg "Block diagram of Nulla")

The read arrows allow the Python side to access the Buffer and Data
RAMs as well as the SFRs in zero-time.

### 1. Simulator control

For interaction of C-Code with the simulator a small SFR is defined. It
allows to print on the console and to terminate the simulation.

The names are defined in `ra_adrmap.h`. The SFR is part of `tb.v` for
the IO_ part and `ra.v` for CPU_ part.

| Address | Name | Mode | Description |
|--- |--- |--- |--- |
| FFF0_F000 | IO_PRINT_CHAR | WO | Print a single character `%c` |
| FFF0_F004 | IO_PRINT_U8X | WO | Print an 8-bit hex number `%02x` |
| FFF0_F008 | IO_PRINT_U16X | WO | Print a 16-bit hex number `%04x` |
| FFF0_F00C | IO_PRINT_U32X | WO | Print a 32-bit hex number `%08x` |
| FFF0_F010 | IO_PRINT_U32D | WO | Print a 32-bit decimal number `%d` |
| FFF0_F014 | IO_PRINT_U32D3 | WO | Print a 32-bit decimal number `%3d` |
| FFF0_F018 | IO_PRINT_U32D5 | WO | Print a 32-bit decimal number `%5d` |
| FFF0_F01C | IO_PRINT_U32D7 | WO | Print a 32-bit decimal number `%7d` |
| FFF0_F020 | IO_PRINT_STR | WO | Print a 0 terminated string `%s` |
| FFF0_F024 | IO_PRINT_F | WO | Call all full printf() (*) |
| FFF0_F040 | IO_EXIT | WO | Terminate the simulation |
| FFF0_F080 | CPU_STALLCNT | RO | Provide the number of CPU stalls |

Legend:\
WO - Write only\
RO - Read only

(*) The `printf()` interaction needs a stack alignment between host and dut side
to interpret the arguments on the stack frame in correct way. Intention is to
use this function only by the aligned wrapper function `dbg_printf()` form the
standard library.


### 2. Integrated peripherals

See [./docu](./docu) folder
