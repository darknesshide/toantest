#ifndef __RA_ADRMAP_H__
#define __RA_ADRMAP_H__

#ifndef _FROM_S_
#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#endif

//Stuff for C and AS
#define HARTS              2

//common definition of RAM layout between environment and c compiler
#include "ra_base_addr.h"


#define CRAM_BASE          CODERAM_BASE8             // 00_0000 ~ 04_0000  CRAM local (up to 256k)
#define CRAM_BASE_PE(i)   (CODERAM_PE_BASE8*((i)+1)) // 04_0000 ~ 20_0000  CRAM other PE (up to 7)
#define DRAM_BASE          DATARAM_BASE8             // 20_0000 ~ 30_0000  1M
#define KRAM_BASE          0x00300000                // 30_0000 ~ 40_0000
#define BRAM_IN_BASE       BUFRAMIN_BASE8            // 40_0000 ~ 50_0000  1M
#define BRAM_OUT_BASE      BUFRAMOUT_BASE8           // 50_0000 ~ 60_0000  1M
#define PERI_BASE          PERIPHERAL_BASE8          // FF_0000


#define CRAM_SIZE          (CODERAM_SIZE32*4)        //2_0000 = 128k
#define DRAM_SIZE          (DATARAM_SIZE32*4)        //2_0000 = 128k
#define KRAM_SIZE          0x00010000                //1_0000 = 64k
#define BRAM_SIZE          (BUFRAMIN_SIZE32*4)       //2_0000 = 128k
//                         BUFRAMOUT_SIZE32


#define BIGENDIAN_OFFSET   0x00080000          //8_0000 = 512k, bit 19 (inside BRAM)


#define MACSEC_BASE     (PERI_BASE + 0x00000)
#define EXT_BASE        (PERI_BASE + 0x0b000)
#define LUP_BASE        (PERI_BASE + 0x0c000)
#define DCM_BASE        (PERI_BASE + 0x0d000)
#define BUF_BASE        (PERI_BASE + 0x0e000)
#define IO_BASE         (PERI_BASE + 0x0f000)

#define IO_PRINT_CHAR   (IO_BASE + 0x00)  // one char
#define IO_PRINT_U8X    (IO_BASE + 0x04)  // 8-bit Hex
#define IO_PRINT_U16X   (IO_BASE + 0x08)  // 16-bit Hex
#define IO_PRINT_U32X   (IO_BASE + 0x0C)  // 32-bit Hex
#define IO_PRINT_U32D   (IO_BASE + 0x10)  // decimal
#define IO_PRINT_U32D3  (IO_BASE + 0x14)  // 3 digit decimal
#define IO_PRINT_U32D5  (IO_BASE + 0x18)  // 5 digit decimal
#define IO_PRINT_U32D7  (IO_BASE + 0x1C)  // 7 digit decimal

#define IO_PRINT_STR    (IO_BASE + 0x20)  // string 0 terminated
#define IO_PRINT_F      (IO_BASE + 0x24)  // full printf

#define IO_EXIT         (IO_BASE + 0x40)  // end the simulation
#define IO_PERF_S       (IO_BASE + 0x44)  // update perf variable in python
#define IO_PERF_C       (IO_BASE + 0x48)  // update perf variable in python
#define IO_ERROR        (IO_BASE + 0x4c)  // increment error counter in python

#define CPU_STALL_CNT   (IO_BASE + 0x80)


//Only for C

#ifndef _FROM_S_
#define PRINT_CHAR     (*((volatile uint32_t*) IO_PRINT_CHAR))
#define PRINT_U8X      (*((volatile uint32_t*) IO_PRINT_U8X))
#define PRINT_U16X     (*((volatile uint32_t*) IO_PRINT_U16X))
#define PRINT_U32X     (*((volatile uint32_t*) IO_PRINT_U32X))
#define PRINT_U32D     (*((volatile uint32_t*) IO_PRINT_U32D))
#define PRINT_U32D3    (*((volatile uint32_t*) IO_PRINT_U32D3))
#define PRINT_U32D5    (*((volatile uint32_t*) IO_PRINT_U32D5))
#define PRINT_U32D7    (*((volatile uint32_t*) IO_PRINT_U32D7))

#define PRINT_STR      (*((volatile uint32_t*) IO_PRINT_STR))
#define PRINT_F        (*((volatile uint32_t*) IO_PRINT_F))

#define IO_EXIT_VAR    (*((volatile uint32_t*) IO_EXIT))
#define IO_PERF_SET    (*((volatile uint32_t*) IO_PERF_S))
#define IO_PERF_CLR    (*((volatile uint32_t*) IO_PERF_C))
#define IO_INC_ERROR   (*((volatile uint32_t*) IO_ERROR))

#define cpu_stall_cnt  (*((volatile uint32_t*) CPU_STALL_CNT))

//--- BUFFER MANAGER ----------------------------------------------------------
struct s_buf_info {
	uint16_t  max;
	uint16_t  cnt;
};

#define buf_in_valid    (*((volatile uint32_t*) (BUF_BASE+0x00)))
#define buf_in_dec      (*((volatile uint32_t*) (BUF_BASE+0x10)))
#define buf_in_info     ( ((volatile uint32_t*) (BUF_BASE+0x200))) //128/0x80
#define buf_in          ( ((volatile struct s_buf_info*) (BUF_BASE+0x200))) //128/0x80

#define buf_out_full    (*((volatile uint32_t*) (BUF_BASE+0x20)))
#define buf_out_inc     (*((volatile uint32_t*) (BUF_BASE+0x30)))
#define buf_out_targets (*((volatile uint32_t*) (BUF_BASE+0x40)))
#define buf_out_store   (*((volatile uint32_t*) (BUF_BASE+0x44)))
#define buf_out_busy    (*((volatile uint32_t*) (BUF_BASE+0x48)))
#define buf_out_info    ( ((volatile uint32_t*) (BUF_BASE+0x400))) //128/0x80
#define buf_out         ( ((volatile struct s_buf_info*) (BUF_BASE+0x400))) //128/0x80

#define buf_config      (*((volatile uint32_t*) (BUF_BASE+0xFC)))

//--- DCM ---------------------------------------------------------------------
#define dcm_rta         ( ((const void* volatile*) (DCM_BASE+0x00)))
#define dcm_rsa         (*((const void* volatile*) (DCM_BASE+0x80)))
#define dcm_len         (*((volatile uint32_t*)    (DCM_BASE+0x84)))
#define dcm_stat        (*((volatile uint32_t*)    (DCM_BASE+0x88)))
#define dcm_stat_to     (*((volatile uint8_t*)     (DCM_BASE+0x88+3)))
#define dcm_perf        (*((volatile uint32_t*)    (DCM_BASE+0x8C)))
#define dcm_config      (*((volatile uint32_t*)    (DCM_BASE+0x90)))

//--- EXTSYS ------------------------------------------------------------------
#define IDA_FIRST_CFD   0      //HW offset mapping of nda/proc (fixed 0 HW)
#define IDA_FIRST_XL    16     //HW offset mapping of nda/proc (HW parameter INPUT_DIRECT_FIFO_CNT)
#define IDA_FIRST_ETH   16     //HW offset mapping of nda/proc (HW parameter INPUT_DIRECT_FIFO_CNT+XL-CNT)
#define IDA_LAST        (26-1) //HW parameter INPUT_DIRECT_FIFO_CNT + INPUT_EVENT_FIFO_CNT -1
//dependent parameters
#define IDA_LAST_CFD    (IDA_FIRST_XL-1)
#define IDA_LAST_XL     (IDA_FIRST_ETH-1)
#define IDA_LAST_ETH    IDA_LAST
//SFR
#define ida_idx         (*((volatile int32_t*)     (EXT_BASE+0x00)))
#define ida_da          (*((volatile uint32_t*)    (EXT_BASE+0x08)))
#define ida_nda         (*((volatile uint32_t*)    (EXT_BASE+0x10)))
#define ida_proc        (*((volatile uint32_t*)    (EXT_BASE+0x14)))


//--- IPC ---------------------------------------------------------------------
enum e_pe_index {PE_SELF=-1, PE0, PE1, PE2, PE3, PE4, PE5, PE6, PE7};
#define IPC_CHANNELS 4

#define IPC_PUT(pe, ch) (*(volatile uint32_t *)( 0x7FF00 + (pe)*0x40000 + (ch)*0x10 ))
#define IPC_GET(pe, ch) (*(volatile uint32_t *)( 0x7FF04 + (pe)*0x40000 + (ch)*0x10 ))
#define IPC_VAL(pe, ch) (*(volatile uint32_t *)( 0x7FF08 + (pe)*0x40000 + (ch)*0x10 ))
#define IPC_MAX(pe, ch) (*(volatile uint32_t *)( 0x7FF0C + (pe)*0x40000 + (ch)*0x10 ))

inline void ipc_request(int pe, int channel)
{
	IPC_PUT(pe, channel) = 0; //written value is don't care (0 result in compact code)
}
inline uint32_t ipc_pending(int channel)
{
	return IPC_GET(PE_SELF, channel);
}
inline void ipc_wait(int channel)
{
	while (!IPC_GET(PE_SELF, channel));
}

//--- MACsec ------------------------------------------------------------------
#define ms_din          ( ((volatile uint32_t*) (MACSEC_BASE+0x00)))
#define ms_dout         ( ((volatile uint32_t*) (MACSEC_BASE+0x20)))
#define ms_tag          ( ((volatile uint32_t*) (MACSEC_BASE+0x30)))
#define ms_stat         (*((volatile uint32_t*) (MACSEC_BASE+0x40)))
#define ms_stat_busy    (*((volatile uint8_t*)  (MACSEC_BASE+0x41)))
#define ms_stat_ok      (*((volatile uint8_t*)  (MACSEC_BASE+0x42)))
#define ms_info         (*((volatile uint32_t*) (MACSEC_BASE+0x44)))
#define ms_conf         (*((volatile uint32_t*) (MACSEC_BASE+0x48)))
#define ms_reset        (*((volatile uint32_t*) (MACSEC_BASE+0x4c)))

//--- LOOKUP HANDLER ----------------------------------------------------------
enum e_lupFormat {LUP_ID11=0, LUP_8, LUP_16, LUP_32, LUP_ID29=4, LUP_48, LUP_64};
//replaced by defines because enums are always signed and we need to place in [31:29]
//enum e_lupProt   {LUP_ONLY_CC=2, LUP_ONLY_FD=4, LUP_BOTH_CCFD=6, LUP_BOTH_CC=3, LUP_BOTH_FD=5};
#define LUP_ONLY_CC   2U
#define LUP_ONLY_FD   4U
#define LUP_BOTH_CCFD 6U
#define LUP_BOTH_CC   3U
#define LUP_BOTH_FD   5U

#define LUP_MAX_SORTED = 4096  /* entries 0 to 4097 */
#define LUP_MAX_LINEAR = 256   /* entries 0 to 255 */

struct s_lupCtrl {
	unsigned sortedEntries :16;
	unsigned linearEntries :8;
	unsigned reserved1     :4;
	unsigned format        :4;
};
struct s_lupTable {
	struct s_lupCtrl ctrl;
	uint32_t         entries[1]; //size don't care. Structure only for casting
};

#define lup_value       ( ((volatile uint32_t*)    (LUP_BASE+0x00)))
#define lup_table       (*((const void* volatile*) (LUP_BASE+0x08)))
#define lup_status      (*((volatile uint32_t*)    (LUP_BASE+0x0c)))
#define lup_found       (*((volatile int16_t*)     (LUP_BASE+0x0c)))


//-----------------------------------------------------------------------------
//Included in init code

extern uint32_t __stack_top;

#define cpuCycleRead(var) asm volatile ("rdcycle %0" : "=r" (var) )
inline uint32_t cpuCycle(void) { register uint32_t tmp; cpuCycleRead(tmp); return tmp; }

//uint32_t csr_rdcycle32();   //returns the lower 32-bits of CDR mcycle counter
uint64_t csr_rdcycle64();   //returns consistently the full CDR mcycle counter

#define cpuHartIdRead(var) asm volatile ("csrr %0, mhartid" : "=r" (var) )
inline uint32_t cpuHartId(void) { register uint32_t tmp; cpuHartIdRead(tmp); return tmp; }

void exit(int code);


//from byteswap.h
#define bswap_16(x) \
	((__uint16_t) ((((x) >> 8) & 0xff) | (((x) & 0xff) << 8)))
#define bswap_32(x) \
	((((x) & 0xff000000u) >> 24) | (((x) & 0x00ff0000u) >> 8) \
	|(((x) & 0x0000ff00u) << 8) | (((x) & 0x000000ffu) << 24))

#define nop() asm volatile ("nop" )

//From stdlib
void *memcpy(void *dest, const void *src, size_t n);
unsigned int strlen(const char *s);

void dbg_putsn(const char *s, int n);
void dbg_printf(const char *fmt, ...);
void dbg_dump(uint32_t addr, int as8, int lines);
inline void dbg_dump_ptr(volatile const void *addr, int as8, int lines) { dbg_dump((uint32_t)addr, as8, lines); }

//Some aliases for the print functions
inline void dbg_putc(char c)        { PRINT_CHAR = c; }
inline void dbg_puts(const char *s) { PRINT_STR = (uint32_t)s; }

inline void dbg_putp(const void *p) { PRINT_U32X = (uint32_t)p; }
inline void dbg_putspc(void)        { PRINT_CHAR = ' '; }
inline void dbg_putnl(void)         { PRINT_CHAR = 10; }

//For the direct ram access
struct s_lit2bigEndian {
	uint32_t lit[BIGENDIAN_OFFSET / 4];
	uint32_t big[BIGENDIAN_OFFSET / 4];
};

#define bram_in8   ((uint8_t* )BRAM_IN_BASE)
#define bram_in32  ((uint32_t*)BRAM_IN_BASE)
#define bram_out8  ((uint8_t* )BRAM_OUT_BASE)
#define bram_out32 ((uint32_t*)BRAM_OUT_BASE)

#define bram_in8_big   ((uint8_t* )(BRAM_IN_BASE+BIGENDIAN_OFFSET))
#define bram_in32_big  ((uint32_t*)(BRAM_IN_BASE+BIGENDIAN_OFFSET))
#define bram_out8_big  ((uint8_t* )(BRAM_OUT_BASE+BIGENDIAN_OFFSET))
#define bram_out32_big ((uint32_t*)(BRAM_OUT_BASE+BIGENDIAN_OFFSET))

#define kram8      ((uint8_t*) KRAM_BASE)
#define kram32     ((uint32_t*)KRAM_BASE)

#define dram8      ((uint8_t*) DRAM_BASE)
#define dram32     ((uint32_t*)DRAM_BASE)
#define dram8_big  ((uint8_t*) DRAM_BASE+BIGENDIAN_OFFSET)
#define dram32_big ((uint32_t*)DRAM_BASE+BIGENDIAN_OFFSET)

#define cram8      ((uint8_t*) CRAM_BASE)
#define cram32     ((uint32_t*)CRAM_BASE)

#define cram8_pe(i)  ((uint8_t*) CRAM_BASE_PE(i))
#define cram32_pe(i) ((uint32_t*)CRAM_BASE_PE(i))

#endif
#endif
