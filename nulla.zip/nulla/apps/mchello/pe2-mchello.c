#include <stdint.h>

#include "ra_adrmap.h"


static volatile uint32_t * const a = dram32  + (0x4000/4);
static int error;

static uint32_t ipc_var __attribute__ ((section (".ipcdata")));


int main(void)
{
	//for (unsigned i = 0; i<cpuHartId()*10; i++);

	dbg_puts("C: Hello World from hart ");
	PRINT_U32D = cpuHartId();
	PRINT_CHAR = 0x0a;

	for (unsigned i = 0; i<100; i++);

	error = 0;
	dbg_printf("C: &a=%p        a=%p\n", &a, a);
	dbg_printf("C: &ipc_var=%p  ipc_var=%p\n", &ipc_var, ipc_var);

	error += 2 != cpuHartId();

	error += ipc_var != 0xdeadbeef;

	dbg_printf("C: Wait for stage 5\n");
	while (a[0] != 5);


	//Check the CRAM access (local/extern)
	volatile uint32_t *p = cram32 + 0x3000;
	p[1] = 0x12340000 + cpuHartId();
	for (unsigned i = 0; i<50; i++);

	dbg_printf("C: base of CRAM: local=%x  pe0=%x  pe1=%x  pe2=%x\n", cram32, cram32_pe(0), cram32_pe(1), cram32_pe(2));
	dbg_printf("C: local[0,1]=%x,%x  pe0[0,1]=%x,%x  pe1[0,1]=%x,%x  pe2[0,1]=%x,%x\n",
		p[0], p[1], p[0x10000], p[0x10001], p[0x20000], p[0x20001], p[0x30000], p[0x30001]);

	error += p[0] != 0xffffffff;
	error += p[1] != 0x12340000+2;

	error += p[0x10000] != 0xffffffff;
	error += p[0x10001] != 0x12340000+0;

	error += p[0x20000] != 0xffffffff;
	error += p[0x20001] != 0x12340000+1;

	error += p[0x30000] != 0xffffffff;
	error += p[0x30001] != 0x12340000+2;

	dbg_printf("B: error = %d\n", error);


	for (int i=1; i<800; i++) {
		IPC_VAL(PE0, 2);
	}
	return error;
}
