#include <stdint.h>

#include "ra_adrmap.h"


static volatile uint32_t * const a = dram32  + (0x4000/4);
static int error;

static uint32_t ipc_var __attribute__ ((section (".ipcdata")));


int main(void)
{
	//for (unsigned i = 0; i<cpuHartId()*10; i++);

	dbg_puts("B: Hello World from hart ");
	PRINT_U32D = cpuHartId();
	PRINT_CHAR = 0x0a;

	for (unsigned i = 0; i<100; i++);

	error = 0;
	dbg_printf("B: &a=%p        a=%p\n", &a, a);
	dbg_printf("B: &ipc_var=%p  ipc_var=%p\n", &ipc_var, ipc_var);

	error += 1 != cpuHartId();

	error += ipc_var != 0xdeadbeef;

	for (unsigned i = 0; i<10; i++);
	dbg_printf("B: Trigger stage 1  (ipc_var=%x)\n", ipc_var);
	a[0] = 1;

	while (a[0] != 2);
	dbg_printf("B: Reached stage 2  (ipc_var=%x)\n", ipc_var);
	error += ipc_var != 0x2222;
	for(int i=1; i<100; i++)
		a[i+0x100] = a[i];
	a[0] = 3;
	ipc_var = 0x3333;

	while (a[0] != 4);
	dbg_printf("B: Reached stage 4  (ipc_var=%x)\n", ipc_var);
	a[0] = 5;


	//Check the CRAM access (local/extern)
	volatile uint32_t *p = cram32 + 0x3000;
	p[1] = 0x12340000 + cpuHartId();
	for (unsigned i = 0; i<50; i++);

	dbg_printf("B: base of CRAM: local=%x  pe0=%x  pe1=%x  pe2=%x\n", cram32, cram32_pe(0), cram32_pe(1), cram32_pe(2));
	dbg_printf("B: local[0,1]=%x,%x  pe0[0,1]=%x,%x  pe1[0,1]=%x,%x  pe2[0,1]=%x,%x\n",
		p[0], p[1], p[0x10000], p[0x10001], p[0x20000], p[0x20001], p[0x30000], p[0x30001]);

	error += p[0] != 0xffffffff;
	error += p[1] != 0x12340000+1;

	error += p[0x10000] != 0xffffffff;
	error += p[0x10001] != 0x12340000+0;

	error += p[0x20000] != 0xffffffff;
	error += p[0x20001] != 0x12340000+1;

	error += p[0x30000] != 0xffffffff;
	error += p[0x30001] != 0x12340000+2;

	dbg_printf("B: error = %d\n", error);


	for (int i=1; i<800; i++) {
		IPC_VAL(PE0, 2);
	}
	return error;
}
