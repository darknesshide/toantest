#include <stdint.h>

#include "ra_adrmap.h"


static volatile uint32_t * const a = dram32  + (0x4000/4);
static int error;

static uint32_t ipc_var __attribute__ ((section (".ipcdata")));


int main(void)
{
	//for (unsigned i = 0; i<cpuHartId()*10; i++);

	dbg_puts("A: Hello World from hart ");
	PRINT_U32D = cpuHartId();
	PRINT_CHAR = 0x0a;

	for (unsigned i = 0; i<50; i++);


	error = 0;
	dbg_printf("A: &a=%p        a=%p\n", &a, a);
	dbg_printf("A: &ipc_var=%p  ipc_var=%p\n", &ipc_var, ipc_var);

	error += 0 != cpuHartId();

	error += ipc_var != 0xdeadbeef;

	dbg_printf("A: Wait for 1\n");
	while (a[0] != 1);
	dbg_printf("A: Reached stage 1  (ipc_var=%x)\n", ipc_var);
	for(unsigned i=1; i<100; i++)
		a[i] = 0x12340000+i;
	a[0] = 2;
	ipc_var = 0x2222;

	while (a[0] != 3);
	dbg_printf("A: Reached stage 3  (ipc_var=%x)\n", ipc_var);
	error += ipc_var != 0x3333;
	for(unsigned i=1; i<100; i++)
		if (a[i+0x100] != 0x12340000+i)
			error++;
	a[0] = 4;

	dbg_printf("A: Wait for stage 5\n");
	while (a[0] != 5);


	//Check the CRAM access (local/extern)
	volatile uint32_t *p = cram32 + 0x3000;
	p[1] = 0x12340000 + cpuHartId();
	for (unsigned i = 0; i<50; i++);

	dbg_printf("A: base of CRAM: local=%x  pe0=%x  pe1=%x  pe2=%x\n", cram32, cram32_pe(0), cram32_pe(1), cram32_pe(2));
	dbg_printf("A: local[0,1]=%x,%x  pe0[0,1]=%x,%x  pe1[0,1]=%x,%x  pe2[0,1]=%x,%x\n",
		p[0], p[1], p[0x10000], p[0x10001], p[0x20000], p[0x20001], p[0x30000], p[0x30001]);

	error += p[0] != 0xffffffff;
	error += p[1] != 0x12340000+0;

	error += p[0x10000] != 0xffffffff;
	error += p[0x10001] != 0x12340000+0;

	error += p[0x20000] != 0xffffffff;
	error += p[0x20001] != 0x12340000+1;

	error += p[0x30000] != 0xffffffff;
	error += p[0x30001] != 0x12340000+2;

	dbg_printf("A: error = %d\n", error);


	dbg_printf("A: Check IPC\nA:  BASE         ");
	for (int p=-1; p<HARTS; p++)
		dbg_printf(" %06x", &IPC_PUT(p, 0));
	dbg_putnl();

	for (int i=0; i<IPC_CHANNELS; i++) {
		dbg_printf("A:   IPC_PUT(%d)  ", i);
		for (int p=-1; p<HARTS; p++) {
			dbg_printf("   %04x", IPC_PUT(p, i));
			error += IPC_PUT(p, i) != 0;
		}
		dbg_printf("\nA:   IPC_GET(%d)  ", i);
		for (int p=-1; p<HARTS; p++) {
			dbg_printf("   %04x", IPC_GET(p, i));
			error += IPC_GET(p, i) != 0;
		}
		dbg_printf("\nA:   IPC_VAL(%d)  ", i);
		for (int p=-1; p<HARTS; p++) {
			dbg_printf("   %04x", IPC_VAL(p, i));
			error += IPC_VAL(p, i) != 0;
		}
		dbg_printf("\nA:   IPC_MAX(%d)  ", i);
		for (int p=-1; p<HARTS; p++) {
			dbg_printf("   %04x", IPC_MAX(p, i));
			error += IPC_MAX(p, i) != 0x40;
		}
		dbg_putnl();
	}
	dbg_printf("A: error = %d\n", error);

	dbg_printf("A: Put 1,2,3,4 entries in each local IPC\n");
	IPC_PUT(PE_SELF, 0) = 0;
	IPC_PUT(PE_SELF, 1) = 0;
	IPC_PUT(PE_SELF, 1) = 0;
	IPC_PUT(PE_SELF, 2) = 0;
	IPC_PUT(PE_SELF, 2) = 0;
	IPC_PUT(PE_SELF, 2) = 0;
	IPC_PUT(PE_SELF, 3) = 0;
	IPC_PUT(PE_SELF, 3) = 0;
	IPC_PUT(PE_SELF, 3) = 0;
	IPC_PUT(PE_SELF, 3) = 0;
	for (int p=-1; p<HARTS; p++) {
		dbg_printf("A:    IPC_VAL(%2d, ...) =", p);
		for (unsigned i=0; i<IPC_CHANNELS; i++) {
			dbg_printf(" %04x", IPC_VAL(p, i));
			error += IPC_VAL(p, i) != ((p>=PE1)?0:i+1);
		}
		dbg_putnl();
	}

	dbg_printf("A: Get from #2\n");
	int val;
	dbg_printf("A:    IPC_GET(%2d, %d) = %04x\n", PE_SELF, 2, val=IPC_GET(PE_SELF, 2));
	error += val != 3;
	dbg_printf("A:    IPC_GET(%2d, %d) = %04x\n", PE_SELF, 2, val=IPC_GET(PE_SELF, 2));
	error += val != 2;
	dbg_printf("A:    IPC_GET(%2d, %d) = %04x\n", PE_SELF, 2, val=IPC_GET(PE_SELF, 2));
	error += val != 1;
	dbg_printf("A:    IPC_GET(%2d, %d) = %04x\n", PE_SELF, 2, val=IPC_GET(PE_SELF, 2));
	error += val != 0;
	dbg_printf("A:    IPC_GET(%2d, %d) = %04x\n", PE_SELF, 2, val=IPC_GET(PE_SELF, 2));
	error += val != 0;


	dbg_printf("A: error = %d\n", error);
	return error;
}
