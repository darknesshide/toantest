#ifndef __RA_BASE_ADDR_H__
#define __RA_BASE_ADDR_H__

#define CODERAM_BASE8     0x000000    // position in memory map
#define DATARAM_BASE8     0x200000    // position in memory map
#define BUFRAMIN_BASE8    0x400000    // position in memory map
#define BUFRAMOUT_BASE8   0x500000    // position in memory map
#define PERIPHERAL_BASE8  0xFF0000    // position in memory map

#define CANRXFIFO0_BASE8  0xFF806000  // position in memory map (same int and extern)
#define CANRXFIFO1_BASE8  0xFF826000  // position in memory map (same int and extern)
#define SRAM_BASE8        0xFE000000  // position in memory map (same int and extern)


#define CODERAM_PE_BASE8  0x040000    // 1st position in memory map and factor


#define CODERAM_SIZE32    (0x20000/4)  // 0x04000 =  16kBytes
#define DATARAM_SIZE32    (0x20000/4)  // 0x08000 =  32kBytes
#define BUFRAMIN_SIZE32   (0x20000/4)  // 0x10000 =  64kBytes
#define BUFRAMOUT_SIZE32  (0x20000/4)  // 0x20000 = 128kBytes

#define CANRXFIFO_SIZE32  (1024/4)     // 0x400 = 1kBytes
#define SRAM_SIZE32       (0x20000/4)  // 0x20000 = 128kBytes

#define KEYRAM_SIZE32      0x4000      // 4000 (16klong) =  64kBytes

#endif
