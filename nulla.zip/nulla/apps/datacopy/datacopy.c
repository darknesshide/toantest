#include <stdint.h>

#include "ra_adrmap.h"


#define CNTMAX 2048
#define TARGETS 8
uint32_t source[CNTMAX/4];
uint32_t dest[TARGETS][CNTMAX/4];

const uint16_t checkCNT[] = {
				4, 8, 12, 16, 32, 64, 128, 256, 512, 1024, 2000 };


int main(void)
{
	dbg_puts("Copy check for 1 to 8 targets (in clock cycles)\n");
	for (int i=0; i<CNTMAX/4; i++)
		source[i] = i*0x20000 + i*0x100 + 0x100 + i;
	dbg_printf("&source=%06x  dest=%06x\n", source, dest);

	int count;
	uint32_t value;
	uint32_t *src, *d0, *d1, *d2, *d3, *d4, *d5, *d6, *d7;
	uint32_t t[TARGETS+4];

	dbg_puts("           memcpy    /---------------- by loop -----------------------\\  memcpy   /-- HW --\\\n");
	dbg_puts("  bytes       1      1      2      3      4      5      6      7      8      8      1      8\n");
	dbg_puts("         ------------------------------------------------------------------------------------\n");
	for (unsigned cntIdx=0; cntIdx<sizeof(checkCNT)/sizeof(checkCNT[0]); cntIdx++) {
		count = checkCNT[cntIdx] / 4;

	//1 copy
		t[1] = cpuCycle();
		src = source;
		d0 = dest[0];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
#else
			value = *src++;
			*d0++ = value;
#endif
		}
		t[1] = cpuCycle() - t[1];

	//2 copy
		t[2] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
#endif
		}
		t[2] = cpuCycle() - t[2];

	//3 copy
		t[3] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		d2 = dest[2];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
			d2[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
			*d2++ = value;
#endif
		}
		t[3] = cpuCycle() - t[3];

	//4 copy
		t[4] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		d2 = dest[2];
		d3 = dest[3];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
			d2[i] = value;
			d3[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
			*d2++ = value;
			*d3++ = value;
#endif
		}
		t[4] = cpuCycle() - t[4];

	//5 copy
		t[5] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		d2 = dest[2];
		d3 = dest[3];
		d4 = dest[4];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
			d2[i] = value;
			d3[i] = value;
			d4[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
			*d2++ = value;
			*d3++ = value;
			*d4++ = value;
#endif
		}
		t[5] = cpuCycle() - t[5];

	//6 copy
		t[6] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		d2 = dest[2];
		d3 = dest[3];
		d4 = dest[4];
		d5 = dest[5];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
			d2[i] = value;
			d3[i] = value;
			d4[i] = value;
			d5[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
			*d2++ = value;
			*d3++ = value;
			*d4++ = value;
			*d5++ = value;
#endif
		}
		t[6] = cpuCycle() - t[6];

	//7 copy
		t[7] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		d2 = dest[2];
		d3 = dest[3];
		d4 = dest[4];
		d5 = dest[5];
		d6 = dest[6];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
			d2[i] = value;
			d3[i] = value;
			d4[i] = value;
			d5[i] = value;
			d6[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
			*d2++ = value;
			*d3++ = value;
			*d4++ = value;
			*d5++ = value;
			*d6++ = value;
#endif
		}
		t[7] = cpuCycle() - t[7];

	//8 copy
		t[8] = cpuCycle();
		src = source;
		d0 = dest[0];
		d1 = dest[1];
		d2 = dest[2];
		d3 = dest[3];
		d4 = dest[4];
		d5 = dest[5];
		d6 = dest[6];
		d7 = dest[7];
		for (int i=0; i < count; i++) {
#ifdef INDEXED
			value = src[i];
			d0[i] = value;
			d1[i] = value;
			d2[i] = value;
			d3[i] = value;
			d4[i] = value;
			d5[i] = value;
			d6[i] = value;
			d7[i] = value;
#else
			value = *src++;
			*d0++ = value;
			*d1++ = value;
			*d2++ = value;
			*d3++ = value;
			*d4++ = value;
			*d5++ = value;
			*d6++ = value;
			*d7++ = value;
#endif
		}
		t[8] = cpuCycle() - t[8];

	//using 1* memcpy
		t[0] = cpuCycle();
		memcpy(dest[0], source, count*4);
		t[0] = cpuCycle() - t[0];

	//using 8* memcpy
		t[9] = cpuCycle();
		for (int i=0; i < 8; i++)
			memcpy(dest[i], source, count*4);
		t[9] = cpuCycle() - t[9];


	//using 1* HWcpy
		t[10] = cpuCycle();
		dcm_rta[0] = &bram_out8[0xa000];
		dcm_rsa = bram_in32;
		dcm_len = count*4;
		while (dcm_stat_to);
		t[10] = cpuCycle() - t[10];

	//using 8* HWcpy
		t[11] = cpuCycle();
		dcm_rta[0] = &bram_out8[0xa000];
		dcm_rta[1] = &bram_out8[0xb000];
		dcm_rta[2] = &bram_out8[0xc000];
		dcm_rta[3] = &bram_out8[0xd000];
		dcm_rta[4] = &bram_out8[0xe000];
		dcm_rta[5] = &bram_out8[0xf000];
		dcm_rta[6] = &bram_out8[0x10000];
		dcm_rta[7] = &bram_out8[0x11000];
		dcm_rsa = bram_in32;
		dcm_len = count*4;
		while (dcm_stat_to);
		t[11] = cpuCycle() - t[11];

	//print summary
		dbg_printf("%6d: ", count*4);
		for (int i=0; i < TARGETS+4; i++) {
			dbg_printf(" %6d", t[i]);
		}
		dbg_putnl();
	}

/*
	print_puts("src ");
	print_putx((uint32_t)src); print_puts(": ");
	for (int i=0; i < 4; i++) {
		print_putx(src[i]); print_putc(32);
	}
	print_putc(10);

	for (int t=0; t<TARGETS; t++) {
		print_putc('d'); print_putd1(t); print_puts("  ");
		print_putx((uint32_t)dest[t]); print_puts(": ");
		for (int i=0; i < 4; i++) {
			print_putx(dest[t][i]); print_putc(32);
		}
		print_putc(10);
	}
*/
	return 0;
}
