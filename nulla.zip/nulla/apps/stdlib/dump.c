#include "ra_adrmap.h"

#define WITH_COLOUR


void dbg_dump(uint32_t addr, int as8, int lines)
{
	if (!(as8&1))
		addr = addr&0xfffffffc;
	uint8_t *p = (uint8_t*)addr;

	for (int l=0; l<lines; l++) {
		dbg_putp(p);
		if (as8&2) {
			dbg_putc('/');
			PRINT_U32X = (uint32_t)p/4;
		}
		dbg_putspc();
		if (as8&1)
			for (int i=0; i<16; i++) {
				dbg_putspc();
				if (i && (i&3) == 0)
					dbg_putspc();
				PRINT_U8X = p[i];
			}
		else
			for (int i=0; i<4; i++) {
				dbg_putspc();
				#ifdef WITH_COLOUR
					if (!((uint32_t*)p)[i])
						dbg_puts("\033[30;1m");
				#endif
				PRINT_U32X = ((uint32_t*)p)[i];
				#ifdef WITH_COLOUR
					dbg_puts("\033[m");
				#endif
			}
		p += 16;
		dbg_putnl();
	}
}
