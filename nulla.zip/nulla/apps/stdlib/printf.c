#include "ra_adrmap.h"

void dbg_printf(const char *fmt, ...)
{
	//Do not add other function calls without align stack with testbench code
	//default stackframe size is 2 words, when adding the dump it becomes 6 words
	PRINT_F = (uint32_t)&fmt;
}
