#include "ra_adrmap.h"

void __assert_func(const char *file, int line, const char *func, const char *failedexpr)
{
	dbg_printf("%s:%d: %s: Assertion '%s' failed.\n", file, line, func, failedexpr);
	exit(1);
}
