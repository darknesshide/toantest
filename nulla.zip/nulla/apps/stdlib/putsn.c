#include "ra_adrmap.h"

void dbg_putsn(const char *s, int n)
{
	while (*s) {
		PRINT_CHAR = *(s++);
		n--;
	}
	while (n-->0)
		PRINT_CHAR = ' ';
}
