#ifndef __MCU_ADRMAP_H__
#define __MCU_ADRMAP_H__

//Register set of RSCANFD is as per U2C
#define RSCFD_BASE8 0xff800000

#define RSCFD_REG(ch, a)  ( ((volatile uint32_t*)(RSCFD_BASE8+0x20000*((ch)>7)))[(a)/4] )

#define CFDIPV(ch)        RSCFD_REG(ch, 0x0080)
#define CFDRFSTS(ch)      RSCFD_REG(ch, 0x00e0+((ch)&7)*4)
#define CFDRFID(ch, i)    RSCFD_REG(ch, 0x6000+((ch)&7)*0x80+(i)*4)
#define CFDRFPCTR(ch)     RSCFD_REG(ch, 0x0100+((ch)&7)*4)


//Register set of ETNF, similar to U2C, expanded to cover up to 8 channels
#define ETNF_BASE8 0xff1d0000

#define ETNF_REG(ch, a)   ( ((volatile uint32_t*)(ETNF_BASE8+0x1000*(ch)))[(a)/4] )

#define ETNFVRR(ch)       ETNF_REG(ch, 0x31C)


//Register set of ETND, similar to U2C
#define ETND_BASE8 0xff940000

#define ETND_REG(ch, a)   ( ((volatile uint32_t*)(ETND_BASE8+0x10000*(ch)))[(a)/4] )

#define ETNDRGC(ch)       ETND_REG(ch, 0x10D0)

//CPU's System RAM, compared to U2C only 128 kByte
#define sram8             ( (volatile uint8_t*) SRAM_BASE8 )
#define sram32            ( (volatile uint32_t*)SRAM_BASE8 )


// Some general helper functions for ComIP access

static inline void cfd_RxFIFO_release(int fifo) { CFDRFPCTR(fifo) = 0xff; }


#endif
