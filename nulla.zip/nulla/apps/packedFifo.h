#ifndef __PACKEDFIFO_H__
#define __PACKEDFIFO_H__

#include <stdint.h>
#include <assert.h>

//#define FIFO_VERBOSE

struct s_packedFifo {
	void *base;
	void *put;
	void *get;
	void *top;
};

#define PACKED_FIFO_INVALID -1 //important is an invalid value from Meta[0] coding (0 or -1 are nice value)



//get==put is always empty
//  only fifo-size - 4 bytes is useable for storage to prevent double meaning of ==
//Fifo wraps if
//  not sufficient space after put and
//  sufficient space after base


//-----------------------------------------------------------------------------
//Initialise the FIFO
inline static void packedFIFO_init(volatile struct s_packedFifo *fifo, void *buffer, int size8)
{
	assert((size8&3) == 0);
	fifo->base = buffer;
	fifo->put = buffer;
	fifo->get = buffer;
	fifo->top = (char*)buffer + size8;
}


//-----------------------------------------------------------------------------
//Adjust put pointer to allow adding size data bytes into FIFO (handles wrap)
//Return NULL if add fails (FIFO full)
//Return ptr where to add data (same as fifo->put)
inline static void *packedFifo_nextPut(volatile struct s_packedFifo *fifo, int size8)
{
	long gap, space;
	char *put = (char*)fifo->put;   //only my side changes this, no need to read every time from RAM (volatile)

	//Calculate free space after put
	//Either (get-put) if get is behind  B....p.....g.....T  --> space > 0
	//Or     (top-put) if get is before  B..g..........p..T  --> space < 0
	space = (char*)fifo->get - put - 4;
	if (space < 0)
		gap = (char*)fifo->top - put -4;  //-4 ensure that there is never a word written at top (even <= 4 bytes)
	else
		gap = space;
	#ifdef FIFO_VERBOSE
		dbg_printf("packedFifoPut(%06x, %03x/%d)  put=%06x  get=%06x  top=%06x  gap=%d  space=%d\n",
		fifo, size8, size8, put, fifo->get, fifo->top, gap, space);
	#endif
	assert (size8 <= (char*)fifo->top - (char*)fifo->base -4);

	//In case there is gap is too small, check if we can wrap around
	//This is only an option if get is before put (space < 0)
	if (gap < size8) {
		if (space < 0)
			space = (char*)fifo->get - (char*)fifo->base - 4;
		//printf("  Top reached  gap=%ld  space=%ld\n", gap, space);
		if (space < size8) {
			#ifdef FIFO_VERBOSE
				dbg_printf("  Full!\n");
			#endif
			return NULL;
		}
		((uint32_t*)put)[0] = PACKED_FIFO_INVALID;
		put = fifo->put = fifo->base;
	}

	return put;
}


//-----------------------------------------------------------------------------
//Simply increments the put pointer (4 byte aligned), no check needed
inline static void packedFifo_incPut(volatile struct s_packedFifo *fifo, int size8)
{
	fifo->put = (char*)fifo->put + ((size8+3) & ~3);
	assert (fifo->get != fifo->put);
}


//-----------------------------------------------------------------------------
//Get next frame from FIFO
//Return NULL if empty
inline static void *packedFifo_nextGet(volatile struct s_packedFifo *fifo)
{
	char *get = (char*)fifo->get;   //only my side changes this, no need to read every time from RAM (volatile)

	#ifdef FIFO_VERBOSE
		dbg_printf("packedFifoGet(%06x)  put=%06x  get=%06x  base=%06x\n",
		fifo, fifo->put, get,fifo->base);
	#endif

	if (get == fifo->put) {
		#ifdef FIFO_VERBOSE
			dbg_printf("  Empty\n");
		#endif
		return NULL;
	}

	if (((int32_t*)get)[0] == PACKED_FIFO_INVALID) {
		#ifdef FIFO_VERBOSE
			dbg_printf("  Top reached\n");
		#endif
		get = fifo->get = fifo->base;
	}

	return get;
}


//-----------------------------------------------------------------------------
//Simply increments the put pointer (4 byte aligned), no check needed
inline static void packedFifo_incGet(volatile struct s_packedFifo *fifo, int size8)
{
	fifo->get = (char*)fifo->get + ((size8+3) & ~3);
	assert (fifo->get < fifo->top);
}

#endif
