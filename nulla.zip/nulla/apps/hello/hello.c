#include <stdint.h>

#include "ra_adrmap.h"


volatile int a;


int main(void)
{
	dbg_puts("Hello World from hart ");
	PRINT_U32D = cpuHartId();
	PRINT_CHAR = 0x0a;

	volatile char *p;

//Check Address
	dbg_puts(".bss DRAM stack-top : ");
	PRINT_U32X = (uint32_t)&a;           PRINT_CHAR = ' ';
	PRINT_U32X = DRAM_BASE;              PRINT_CHAR = ' ';
	PRINT_U32X = (uint32_t)&__stack_top; PRINT_CHAR = ' ';

	PRINT_CHAR = 0x0a;

//Check Endian.
	dbg_puts("Expect abcd 64636261\n   Get ");
	a = 0x64636261;
	p = (char*)&a;
	PRINT_CHAR = p[0];  //little endian
	PRINT_CHAR = p[1];
	PRINT_CHAR = p[2];
	PRINT_CHAR = p[3];
	PRINT_CHAR = ' ';
	PRINT_U32X = a;
	PRINT_CHAR = 0x0a;

	dbg_puts("Expect 1234 34333231\n   Get ");
	p[0] = 0x31;
	p[1] = 0x32;
	p[2] = 0x33;
	p[3] = 0x34;
	PRINT_CHAR = p[0];  //little endian
	PRINT_CHAR = p[1];
	PRINT_CHAR = p[2];
	PRINT_CHAR = p[3];
	PRINT_CHAR = ' ';
	PRINT_U32X = a;
	PRINT_CHAR = 0x0a;

//Check data access (trigger data alignment fault)
#if 0
	uint32_t *u;
	u = (uint32_t*)0x330;
	for (int i=0; i<4; i++) {
		dbg_printf("ptr=%p\n", u);
		dbg_printf("    *ptr=%x\n", *u);

		u = (uint32_t*)( ((uint32_t)u) +1 );
	}
#endif

	return 0;
}
