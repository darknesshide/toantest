#include <stdint.h>

#include "ra_adrmap.h"


#define CNTMAX 2000
uint32_t lookupTable[CNTMAX];

//const uint16_t checkCNT[] = {5, 10, 25, 50, 100, 250, 500, 750, 1000, 1500, 2000};

//for BIN1 the jump is at 2^n (between 16 and 17)
//for BIN2 the jump is at 2^n -2 (between 14 and 15)
const uint16_t checkCNT[] = {
				1, 2, 3, 4, 5, 6, 7, 8, 9,
				14, 15, 16, 17,
				30, 31, 32, 33,
				62, 63, 64, 65,
				126, 127, 128, 129,
				254, 255, 256, 257,
				510, 511, 512, 513,
				1022, 1023, 1024, 1025,
				2000
};


inline void print_putx(uint32_t c)
{
	PRINT_U32X = c;
}
inline void print_putd(uint32_t c)
{
	PRINT_U32D5 = c;
}

int lookupLIN(uint32_t *tab, uint32_t value, int max)
{
#if 1
	for (int pos=0; pos<max; pos++) {
		if (tab[pos] == value)
			return pos;
	}
#else
	for (int pos=0; pos<max; pos++) {
		//moving pointer could faster than index in case of no compiler optimisation
		if (*(tab++) == value)
			return pos;
	}
#endif
	return -1;
}
/*
int lookupBIN1(uint32_t *tab, uint32_t value, int max)
{
	//This binary search uses a different formula to get the middle number
	// (gap+1)/2 instead of (hig-low)/2, as this result due to the not
	// binary table size in up to 2 steps with '1'. out variable handles this
	uint32_t v;
	int pos = (max+1) / 2;
	int gap = pos;
	int out = 3;

	gap = (gap+1) / 2;
	while (out) {
		// print_putc(32);
		// print_putd(pos);
		// print_putc(10);

		v = tab[pos];
		if (value == v)
			return pos;
		else if (value < v) {
			pos -= gap;
			if (pos < 0)
				pos = 0;
		}
		else {
			pos += gap;
			if (pos > max)
				pos = max;
		}
		if (gap == 1)
			out -= 1;
		gap = (gap+1) / 2;
	}
	return -1;
}*/

int lookupBIN2(uint32_t *tab, uint32_t value, int min, int max)
{
	uint32_t v;
	int pos;
	while (min <= max) {
		pos = min + ((max-min) / 2);
		// print_putc(32);
		// print_putd(min);
		// print_putc(32);
		// print_putd(pos);
		// print_putc(32);
		// print_putd(max);

		// print_putc(32);
		// print_putd(value);
		// print_putc(32);
		// print_putd(tab[pos]);
		// print_putc(10);

		v = tab[pos];
		if (value == v)
			return pos;
		else if (value < v) {
			max = pos -1;
		}
		else {
			min = pos +1;
		}
	}
	return -1;
}

int main(void)
{
	dbg_printf("lookupTable at %p of size:%08x\n",
		&lookupTable, sizeof(lookupTable));

	for (int i=0; i<CNTMAX; i++)
		lookupTable[i] = i*0x100 + 0x100 + i;
	// for (int i=0; i<CNT; i++) {
	//	 print_putd(i);
	//	 print_putc(32);
	//	 print_putx(lookupTable[i]);
	//	 print_putc(10);
	// }

	uint32_t t1, tmax, tavg, ctotal, ttotal, tmaxtotal;
	uint32_t value;
	int res, count;
	ctotal = 0;
	ttotal = 0;
	tmaxtotal = 0;
	dbg_puts("Each existing and a not existing element is used for each size.\n"
		"What TableSize Average Maximum\n");
	for (unsigned cntIdx=0; cntIdx<sizeof(checkCNT)/sizeof(checkCNT[0]); cntIdx++) {
		count = checkCNT[cntIdx];
		//count = 10;
		// print_puts("Check ");
		// print_putd(cntIdx);
		// print_putc(32);
		// print_putd(count);
		// print_putc(10);

		tmax = 0;
		tavg = 0;
		for (int i=0; i<count+1; i++) {
			value = (i==count) ? 0x1234 : lookupTable[i];

			t1 = cpuCycle();
#ifdef LINEAR
			res = lookupLIN(lookupTable, value, count);
#else
			//res = lookupBIN1(lookupTable, value, count);
			res = lookupBIN2(lookupTable, value, 0, count);
#endif
			t1 = cpuCycle() - t1;

			if (t1 > tmax)
				tmax = t1;
			tavg += t1;
			ttotal += t1;
			ctotal ++;

			// print_puts("	Result ");
			// print_putx(value);
			// print_putc(32);
			// print_putd(res);
			// print_putc(32);
			// print_putd(t1);
			// print_putc(10);
			if (! (res == i || (res == -1 && i == count))) {
				dbg_puts("ERROR in lookup\n");
				return -1;
			}
		}
		tavg = tavg/(count+1);
#ifdef LINEAR
		dbg_puts("LIN   ");
#else
		dbg_puts("BIN   ");
#endif
		dbg_printf(" %7d %7d %7d\n", count, tavg, tmax);
		if (tmax > tmaxtotal)
			tmaxtotal = tmax;

		//No need to check the out of range search variants
		if (tmax > 5000)
			break;
	}

	ttotal = ttotal/ctotal;
	dbg_printf("\n    Lookups Average Maximum\ntotal %d %d %d\n",
		ctotal, ttotal, tmaxtotal);

	return 0;
}
