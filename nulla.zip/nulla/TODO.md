== Ingress

== Processing

== Egress


== RTL

=== External connection

* Mirror of system side SFR to IDA_EN0, IDA_EN1, IDA_EN2 and the masking of related probe signals.


== Environment

* System side modelling of IDA_EN0, IDA_EN1, IDA_EN2 and configuration based on
  +JSON:comIfUtilisation/cfdIngressEnable+ and +
  +JSON:comIfUtilisation/ethIngressEnable+.

* How to code Remote Frames with Extended identifier?

