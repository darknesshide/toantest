
== Ingress Path

```
Ingress            Channel  Mapping             Select ingress config
  CFD0~15   (IDA)  0~15     \
  XL0~7     (IDA)  -         | cfg.ingressMap   |
  ETH0~9    (IDA)  16~25     +----------------->| cfg.ingress[map]
  CPU0~57   (???)  26~83     |                  |
  vPORT0~31 (s/w)  84~115    /
Total:             116
```

== Egress

```
Egress             Channel
  CFD0~15   (???)  0~31
  XL0~7     (???)  -
  ETH0~9    (???)  32~65
  CPU0~47   (???)  66~113
Sum:               114
  SG0~31    (s/w)  190~221   #SG/ST are overlapping as addressed by either CAN or ETH path
  ST0~31    (s/w)  190~221
Sum :              64
Total:             178
```

vPorts are addressed directly from Stream Termination unit. No egress number needed

CFD:  2    TxFIFO, TxQueue
XL:   2    TxFIFO, TxQueue
T1S:  4    4 TxFIFO
ETH:  1    TxFIFO

For the 10 Ethernet (8 T1S + 2 ETH) --> 34 resources
