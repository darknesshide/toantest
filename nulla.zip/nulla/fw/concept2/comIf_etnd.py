import ra;
import random

import sys
sys.path.append(sys.path[-1]+"../../apps")
from moduleComif import *

ETD_CHANNELS = 7
RX_CHAIN_ENTRY = 4
FEMPTY  =  4
FSINGLE =  8
LEMPTY  = 12
LINK    = 14
DTYPE   = (0,0,0,0,'FEMPTY',0,0,0,'FSINGLE',0,0,0,'LEMPTY',0,'LINK')

rxFifoCnt = 0
seqNumberCounter = {}


#------------------------------------------------------------------------------
def assemble_acf_brief(srcBus, id, frameType, size, options={}):
	print("  PY      assemble_acf_brief(%d, %d/%x, %s %d, %s)"%(srcBus, id, id, TYPE_STR[frameType], size, options))
	len32 = 2+(size+3)//4
	pad = (4-(size&3))&3
	mtv	= options.get("MTV", 0)
	rtr	= options.get("RTR", 0)
	eff	= frameType == CCe or frameType == FDe
	brs	= options.get("BRS", 0)
	fdf	= frameType == FDb or frameType == FDe
	esi = options.get("ESI", 0)

	ret = [0xAA] * (len32*4)
	ret[0] = 0x04          #CAN_BRIEF
	ret[1] = len32         #len32
	ret[2] = (pad<<6) + (mtv<<5) + (rtr<<4) + (eff<<3) + (brs<<2) + (fdf<<1) + (esi<<0)
	ret[4:8] = splitInt32(id)
	ret[8:8+size] = [random.randint(0, 0xff) for _ in range(size)]

	tag = "" #frameTagString(None, frameType, id)
	#print("  PY        tag=%s  len32=%d  size=%d"%(tag, len32, size))
	#comIf_printDump(ret)

	return ret, tag, len32, ret[8:8+size]
#def


#------------------------------------------------------------------------------
#creates the ETND receive payload provided to TUBE by RX-Descriptor chain
# Returns a Fifo-Entry-Object
def assemble_rxObject(da=None, size=0, et=None, vid=None, pcp=None, sid=None, acf=None, payload=None, bus=31, ts=0):
	if (payload == None):
		payload = [random.randint(0, 0xff) for y in range(size)]
	assert len(payload) == size, f"etd_RxFifo object assembling fails. Provided payload (len={len(payload)}) != requested size {size}."

	if (da != None):
		da = [int(x, 16) for x in da.split(':')]
		payload[0:6] = da

	etPos = 12
	if (vid != None):
		assert pcp != None
		assert vid >= 0 and vid <=0xfff
		assert pcp >= 0 and pcp < 16
		vid = vid + (pcp<<12)
		payload[12:16] = [0x81,0x00] + list(vid.to_bytes(2, "big"))
		etPos += 4

	if (et != None):
		assert et >= 0 and et <= 0xffff
		payload[etPos:(etPos+2)] =  list(et.to_bytes(2, "big"))

	if (sid != None):
		global seqNumberCounter
		# Insert optional 1722 stream ID
		if not sid in seqNumberCounter:
			seqNumberCounter[sid] = random.randint(0, 0xff)
		# Add some IEEE 1722 specific fields (simplified)
		payload[etPos+2] = 0x77  #subtype
		payload[etPos+5] = seqNumberCounter[sid]  #sequence num
		seqNumberCounter[sid] = (seqNumberCounter[sid] +1)&0xff
		payload[etPos+6:etPos+6+8] = list(sid.to_bytes(8, "big"))
		if acf != None:
			print("  PY      Add %d ACFs to frame"%(len(acf)))
			#print(acf)
			payload[etPos+2] = 0x82  #NTCF container
			pos = etPos+2 + 12
			length = 0
			for this in acf:
				#print(this)
				d, tag, len32, canPayload = assemble_acf_brief(bus, *this)
				payload[pos:pos+len(d)] = d
				length += len32*4
				pos += len32*4
			payload[etPos+4] = length & 0xff
			payload[etPos+3] = (length>>8) &0x07
			#print(pos, length, hex(length), length+etpos+12)
			if (length+etPos+12 > size):
				print("  PY      %sWARNING%s: Requested ACF (%d bytes) exceeds the configured frame length of %d bytes"%(YELLOW, NORM, length+etpos+12, size))
				payload = payload[0:size+2]
		#if ACF
	#if sid

	assert (ts >= 0 and ts <= 0xffffffffffffffff), f"etd_RxFifo object assembling fails. ts={ts} is out of range."

	# print("  PY  INFO: Length of payload is %d, Requested size was %d"%(len(payload),size))
	#comIf_printDump(payload, prefix="Gen Payload |")
	return [payload, ts]
#def


#------------------------------------------------------------------------------
#Simulation model of ETND Rx-Descriptor Chain handing
#
def add_to_RxFifo(busIdx, fifoIdx, obj):

	global rxFifoBuf, rxFifoAccessWindowFree, rxFifoCnt
	global next_descrAddr
	#print("ra.tick: Publish to ETH to fifo %s "%(fifoIdx))
	#FULL --> discard
	# if (len(rxFifoBuf[fifoIdx]) > config['etd_RxFifoDepth'][fifoIdx]):
	# 	print("  PY  WARNING: etd_RxFifo FULL with %d entries. Frame dropped."%(len(rxFifoBuf[fifoIdx])))
	# 	return False
	# print(hex(next_descrAddr))
	descriptor = ra.read(next_descrAddr[fifoIdx],32,4)
	dscrType =(descriptor[0]>>28)
	# print(dscrType)
	dataPtr = descriptor[1]
	# print(hex(dataPtr))
	if (dscrType == LINK):
		print("  PY  INFO: Descriptor with DT = %s"%(DTYPE[dscrType]))
		ra.write(next_descrAddr[fifoIdx], 32, [(LEMPTY<<28)])
		next_descrAddr[fifoIdx] == dataPtr
		descriptor = ra.read(next_descrAddr,32,4)
		dscrType =(descriptor[0]>>28)
		dataPtr = descriptor[1]
	if ((dscrType == FSINGLE) or (dscrType == LEMPTY)):
		print("  PY  WARNING: etd_RxFifo FULL with DT = %s"%(DTYPE[dscrType]))
		return False

	assert (dscrType == FEMPTY), "  PY  ERROR: Not used descriptor type: %s"%(DTYPE[dscrType])

	ra.write(dataPtr,  8, obj[0])
	print("  PY  INFO: Writing Descriptor: DT=FSINGLE, DS=%d, DPTR=0x%8x, TSNS=%d, TSS=%d"%(len(obj[0]),dataPtr,(obj[1] & 0xFFFFFFFFF),obj[1] >> 32))
	ra.write(next_descrAddr[fifoIdx], 32, [(FSINGLE<<28)+len(obj[0]), dataPtr, obj[1] & 0xFFFFFFFFF, obj[1] >> 32])
	next_descrAddr[fifoIdx] += 4*4
	# print(hex(next_descrAddr))
	# Trigger TUBE
	assert ra.markInFifoAvailable(busIdx), f"etd_RxFifo {fifoIdx} sanity check fails. Access window is full."

	return True
#def


#------------------------------------------------------------------------------
#Basic initialisation
def init(_config=None):
	global rxFifoBuf, rxFifoAccessWindowFree
	global config, rxFifoCnt
	global next_descrAddr

	#take over the configuration
	if _config != None:
		config = _config
	#assemble a default configuration
	else:
		config = {
			'etd_Channels'  : ETD_CHANNELS, # ETD_CHANNELS = 7
			'etd_Ch0_Offs'  : 16,
			'etd_DscrBase'  : 0xfe010000,
			'etd_Cfg'       : [
				{
					# per TUBE spec ETD entries are always 2048 bytes
					'EntrySize' : 2048, # max data payload
					'Entries'   : RX_CHAIN_ENTRY,
				},
			]
		}

	#setup the internal data structures
	rxFifoBuf = [[] for i in range(config['etd_Channels'])]
	rxFifoAccessWindowFree = [True for i in range(config['etd_Channels'])]
	rxFifoCnt = 0

	#init the Rx-FIFOs of ETND
	print("Init %d Rx chains for ETND"%config['etd_Channels'])
	# Descriptor Pointer to the Descriptor Base address
	descr_Ptr = config['etd_DscrBase']
	# Data Pointer - Data Payload starts after all RX Descriptor chains
	data_Ptr = config['etd_DscrBase']+config['etd_Channels']*(config['etd_Cfg'][0]['Entries']+1)*4*4
	next_descrAddr = []
	descr_Chain = []
	for j in range(config['etd_Channels']):
		next_descrAddr += [descr_Ptr]
		for i in range(config['etd_Cfg'][0]['Entries']):
			# Fill Descriptor Chain by setting every descriptor to (FEMPTY,DS=0),DataPointer,0,0)
			descr_Chain+=[(FEMPTY<<28)+config['etd_Cfg'][0]['EntrySize'],data_Ptr,0,0]
			data_Ptr+=config['etd_Cfg'][0]['EntrySize']
		# Fill last desriptor to link to first: (LINK,DS=0),0,0,descr_Chain[j])
		descr_Chain+=[(LINK<<28),descr_Ptr,0,0]
		descr_Ptr+=(config['etd_Cfg'][0]['Entries']+1)*4*4
	comIf_printDump(descr_Chain, width=8, itemsPerLine=4, heading=None, addrMul=4)
	print("next_descrAddr",["%x"%i for i in next_descrAddr])

	if not ra.write(config['etd_DscrBase'], 32, descr_Chain):
		return True

	return False
#def
