//#define NDEBUG        //define disables all assertion code

//Some debug and measurement configurations
#define VERBOSE_GENERAL
#ifdef VERBOSE_GENERAL
	#define VERBOSE_CFD
	//#define VERBOSE_ETH
#endif


//-------------------------------------------------------------------
#include <assert.h>
#include "ra_adrmap.h"
#include "mcu_addrmap.h"

#include "racfg.h"
#include "packedFifo.h"
#include "shared_data.h"
#include "etnd.h"

//Configuration **************************************************
#define RA_CONFIG_ADDR      0x6000   //Address inside dram

const struct s_raConfig *raConfig;


//Statistics **************************************************
#ifdef VERBOSE_GENERAL
	static const char *dbg_COUNTER_INGRESS_STR[] = { THE_INGRESS_COUNTERS(GENERATE_STRING) };
#endif


//-------------------------------------------------------------------
// RSCANFD
// DLC conversion helper
static const uint8_t DLC2LEN[16] = {0,1,2,3,4,5,6,7, 8,12,16,20,24,32,48,64};


//-------------------------------------------------------------------
// ETND
// Pointer to the RX Descriptor Chains
static struct s_descr_basic *etnd_rx_desc[INGRESS_ETH_CNT];
// Descriptor Type translation
// static const char *descriptor_types[16] = {
//     "DT0",
//     "FEMPTY_IS",
//     "FEMPTY_IC",
//     "FEMPTY_ND",
//     "FEMPTY",
//     "FEMPTY_Start",
//     "FEMPTY_MID",
//     "FEMPTY_END",
//     "FSINGLE",
//     "FSTART",
//     "FMID",
//     "FEND",
//     "LEMPTY",
//     "EEMPTY",
//     "LINK",
//     "EOS"
// };


//-------------------------------------------------------------------
static void cfd_read_rxfifo(unsigned idx)
{
	assert(idx < INGRESS_CFD_CNT);

	int ide   =  CFDRFID(idx,0) >> 31;
	int rtr   = (CFDRFID(idx,0) >> 30) & 0x1;
	int id_be =  CFDRFID(idx,0)        & 0x1FFFFFFF;
	int len   = DLC2LEN[CFDRFID(idx,1)>>28];
	int ts    =  CFDRFID(idx,1)        & 0xFFFF;
	int fdf   = (CFDRFID(idx,2) >>  2) & 0x1;
	int brs   = (CFDRFID(idx,2) >>  1) & 0x1;
	int esi   =  CFDRFID(idx,2)        & 0x1;
	int prot  = /*(rtr) ? 4 :*/((ide) ? 1 : 0);

	//print the Fifo entry
	#ifdef VERBOSE_CFD
		dbg_printf("\033[32mRxFifo%-2d %08x %08x %08x  id=%d len=%d\033[m\n      \\-", idx,
			CFDRFID(idx,0), CFDRFID(idx,1), CFDRFID(idx,2),
			CFDRFID(idx,0)&0x3ffffff, DLC2LEN[CFDRFID(idx,1)>>28]
		);
		if (len <= 20) {
			for (int i=0; i<(len+3)/4; i++)
				dbg_printf(" %08x", CFDRFID(idx,i+3));
			dbg_puts("\n");
		}
		else
			dbg_printf(" %08x %08x %08x ... %08x %08x\n", CFDRFID(idx,3), CFDRFID(idx,4),
				CFDRFID(idx,5), CFDRFID(idx,3+len/4-2), CFDRFID(idx,3+len/4-1));

		dbg_printf("    ide   = %d\n", ide);
		dbg_printf("    rtr   = %d\n", rtr);
		dbg_printf("    id_be = 0x%08x %d\n", id_be, id_be);
		dbg_printf("    len   = 0x%04x\n", len);
		dbg_printf("    ts    = 0x%08x %d\n", ts, ts);
		dbg_printf("    fdf   = %d\n", fdf);
		dbg_printf("    brs   = %d\n", brs);
		dbg_printf("    esi   = %d\n", esi);
		dbg_printf("    prot  = %d\n", prot);
	#endif

	//TODO: Discard and count remote frames

	//copy to output buffer to allow score boarding in python
	uint32_t *srcBuf = (uint32_t*)&CFDRFID(idx,3);
	uint32_t *tgBuf = packedFifo_nextPut(&ingressFIFO, len+28);
	#ifdef VERBOSE_CFD
		dbg_printf("    Copy %06x <= %x  size=%d (%03x total)\n", tgBuf, srcBuf, len, (len+28+3)/4*4);
	#else
	#ifdef VERBOSE_GENERAL
		dbg_printf("\033[32m  CFD#%d Read %d bytes from %x to %06x\033[m\n", idx, len, srcBuf, tgBuf);
	#endif
	#endif
	assert(tgBuf);  //Full (returns NULL) is not handled yet. TODO: Add a fetch delay if FIFO is full (polling? or better back trigger from Processing stage)

	//Assemble TUBE meta and CAN header
	tgBuf[0] = (idx << 24) + (prot << 16) + len;        // M0
	tgBuf[1] = 0;                                       // M1
	tgBuf[2] = ts;                                      // M2
	tgBuf[3] = 0;                                       // M3
	tgBuf[4] = (fdf << 31) + ((!fdf) << 30) + id_be;    // H0
	tgBuf[5] = (rtr << 19) + (brs << 18) + (esi << 17); // H1
	tgBuf[6] = 0;                                       // H2
	// dbg_printf("    %08x tgBuf[0] M0 (IPN, PROT, LEN)            %08x\n", &tgBuf[0], tgBuf[0]);
	// dbg_printf("    %08x tgBuf[1] M1 (PDUID)                     %08x\n", &tgBuf[1], tgBuf[1]);
	// dbg_printf("    %08x tgBuf[2] M2 (TS[31:0])                  %08x\n", &tgBuf[2], tgBuf[2]);
	// dbg_printf("    %08x tgBuf[3] M3 (TS[63:32])                 %08x\n", &tgBuf[3], tgBuf[3]);
	// dbg_printf("    %08x tgBuf[4] H0 (FD, CC, CANID)             %08x\n", &tgBuf[4], tgBuf[4]);
	// dbg_printf("    %08x tgBuf[5] H1 (RTR, BRS, ESI, VCID, SDT)  %08x\n", &tgBuf[5], tgBuf[5]);
	// dbg_printf("    %08x tgBuf[6] H2 (AF)                        %08x\n", &tgBuf[6], tgBuf[6]);

	memcpy((void*)&tgBuf[7], srcBuf, (len+3)/4*4);
	#ifdef VERBOSE_CFD
		dbg_printf("\033[32mCFD frame fetched into ingress FIFO:\033[m\n");
		dbg_dump_ptr(tgBuf, 0, (len+28+15)/16);
	#endif

	countersIngress[idx][IN_TOTAL] += 1;

	// Trigger Processing Stage PE
	packedFifo_incPut(&ingressFIFO, len+28);
	ipc_request(PROCESSING_STAGE, IPC_INGRESS_FIFO);

	// release the FIFO in CFD IP
	cfd_RxFIFO_release(idx);
}


//-------------------------------------------------------------------
static void etnd_read_rxfifo(unsigned channel)
{
	assert(channel < INGRESS_ETH_CNT);

	int saved_ds;
	int saved_dt;
	int saved_tsns;
	int saved_tss;

	dbg_printf("Working on Descriptor Chain of Channel %d\n", channel);

	//mark the channel as 'under processing'
	ida_proc = (1 << (channel));

	//Check if there is a link
	saved_dt = etnd_rx_desc[channel]->dt;
	//dbg_printf("Descriptor Type %s\n", descriptor_types[saved_dt]);
	if (saved_dt == LEMPTY) {
		etnd_rx_desc[channel]->dt = LINK;
		etnd_rx_desc[channel] = (struct s_descr_basic *) (etnd_rx_desc[channel]->dptr);
		saved_dt = etnd_rx_desc[channel]->dt;
	}
	dbg_dump_ptr(etnd_rx_desc[channel], 0, 1);
	saved_ds = etnd_rx_desc[channel]->ds;
	saved_tsns = etnd_rx_desc[channel]->tsns;
	saved_tss = etnd_rx_desc[channel]->tss;

	//Process the available frame
	if (saved_dt == FSINGLE) {
		uint32_t *srcBuf = (uint32_t*)etnd_rx_desc[channel]->dptr;
		uint32_t *tgBuf = packedFifo_nextPut(&ingressFIFO, saved_ds + 2 + 16);
		dbg_printf("\033[32m    Copy %x <= %x  size=%d/%x\033[m\n", tgBuf, srcBuf, etnd_rx_desc[channel]->ds, etnd_rx_desc[channel]->ds);
		assert(tgBuf);  //Full (returns NULL) is not handled yet. TODO: Add a fetch delay if FIFO is full (polling? or better back trigger from Processing stage)

		//Assemble TUBE meta and CAN header
		tgBuf[0] = ((channel+IDA_FIRST_ETH) << 24) + (3 << 16) + saved_ds;  // M0
		tgBuf[1] = 0;                                       // M1
		tgBuf[2] = saved_tsns;                              // M2
		tgBuf[3] = saved_tss;                               // M3

		//Copy data (manual copy requires due to 16 byte re-alignment)
		uint16_t gap_tmp = 0;
		int i;
		for (i = 0; i < (etnd_rx_desc[channel]->ds + 3) / 4; i++) {
			// dbg_printf("    SourceBuffer %03d, value is 0x%08x\n", i, srcBuf[i]);
			uint32_t read_tmp = srcBuf[i];
			// dbg_printf("    gap_tmp = 0x%04x, read_tmp = 0x%08x, store value is 0x%08x\n", gap_tmp, read_tmp, (read_tmp << 16) + gap_tmp);
			tgBuf[4+i] = (read_tmp << 16) + gap_tmp;
			gap_tmp = read_tmp >> 16;
		}
		tgBuf[4+i] = gap_tmp;

		dbg_dump_ptr(tgBuf, 0, ((etnd_rx_desc[channel]->ds + 16) + 15) / 16);
		etnd_rx_desc[channel]->ds = FRAME_SIZE;
		etnd_rx_desc[channel]->dt = FEMPTY;
		etnd_rx_desc[channel]++;

		countersIngress[channel+IDA_FIRST_ETH][IN_TOTAL] += 1;

		// Trigger Processing Stage PE
		packedFifo_incPut(&ingressFIFO, saved_ds+2+16);
		ipc_request(PROCESSING_STAGE, IPC_INGRESS_FIFO);
	}
	//Check if chain is empty
	else if ((saved_dt == LINK) || (saved_dt == FEMPTY)) {
		//Acknowledge that processing this chain has be completed
		//The clear of NDA is prevented by HW in case there are new data added after write of IDA_PROC
		ida_nda = (1 << (channel));
		dbg_printf("Descriptor Chain of Channel %d is empty!\n", channel);
	}
	else {
		dbg_printf("Coding ERROR   Descriptor Type %d is not expected");
		exit (-1);
	}

}

//-------------------------------------------------------------------
int main(void)
{
	#ifdef VERBOSE_GENERAL
		dbg_printf("Ingress Stage main() on PE %d\n", cpuHartId());
		dbg_checkPythonStarted();
		#if 0
			dbg_printf("CFD %3d ~ %3d  = %3d\n"
					"XL  %3d ~ %3d       = %3d   (first in PY %d)\n"
					"ETH %3d ~ %3d       = %3d   (first in PY %d)\n"
					"INGRESS_MAX         = %3d   (PY %d)\n"
					"VPORT_MAX           = %3d   (PY %d)\n"
					"EGRESS_MAX          = %3d   (PY %d)\n"
					"EGRESS_FIRST_STREAM = %3d   (PY %d)\n",
				IDA_FIRST_CFD, IDA_LAST_CFD, INGRESS_CFD_CNT,
				IDA_FIRST_XL, IDA_LAST_XL, INGRESS_XL_CNT, bram_in32[0x10],
				IDA_FIRST_ETH, IDA_LAST_ETH, INGRESS_ETH_CNT, bram_in32[0x11],
				INGRESS_MAX, bram_in32[0x12],
				VPORT_MAX, bram_in32[0x13],
				EGRESS_MAX, bram_in32[0x14],
				EGRESS_FIRST_STREAM, bram_in32[0x15]
			);
		#endif
		//Python simulator places its configuration in input buffer RAM to allow sanity check
		assert(bram_in32[0x10] == IDA_FIRST_XL);
		assert(bram_in32[0x11] == IDA_FIRST_ETH);
		assert(bram_in32[0x12] == INGRESS_MAX);
		assert(bram_in32[0x13] == VPORT_MAX);
		assert(bram_in32[0x14] == EGRESS_MAX);
		assert(bram_in32[0x15] == EGRESS_FIRST_STREAM);
		assert(bram_in32[0x16] == INGRESS_FIRST_VPORT);
	#endif

	//wait PE1 has finished config
	while (!IPC_GET(PE_SELF, IPC_CONFIG_DONE));


//Some accesses checks on CFD address space
	// dbg_printf("CFD0.IPV (%x)=%08x\nCFD1.IPV (%x)=%08x\n", &CFDIPV(0), CFDIPV(0), &CFDIPV(1), CFDIPV(1));
	// for (int i=0; i<2; i++)
	// 	if (CFDIPV(i) != 0x142) {
	// 		dbg_printf("FATAL: No RSCANFD%d found at %p. Read IPV as %08x\n", i, &CFDIPV(i), CFDIPV(i));
	// 		return 1;
	// 	}
	// return 99;

//Initialisation
	raConfig = (struct s_raConfig*)&dram32[RA_CONFIG_ADDR/4];

	dbg_printf("Init ingressFIFO @%06x to data=%06x  size=%x/%d\n", &ingressFIFO, raConfig->ingressFIFO.baseAddr, raConfig->ingressFIFO.size8, raConfig->ingressFIFO.size8);
	packedFIFO_init(&ingressFIFO, raConfig->ingressFIFO.baseAddr, raConfig->ingressFIFO.size8);

	memset((void*)countersIngress, 0, sizeof(countersIngress));


// init Software
	// set pointer to RX Descriptor chains
	for (int ch = 0; ch < INGRESS_ETH_CNT; ch++) {
		etnd_rx_desc[ch] = (struct s_descr_basic *) (ETND_DESCR_BASE + ch * RX_CHAIN_SIZE * 4*4);
		//dbg_printf("Descriptor Base Address Channel %d is 0x%08x\n", ch, etnd_rx_desc[ch]);
		//dbg_dump_ptr(etnd_rx_desc[ch], 0, RX_CHAIN_SIZE);
	}

//Main processing loop
	while (1) {
		int32_t idx;
		int to;
		dbg_printf("Wait for frame in Rx-FIFO  (idx=%d)\n", ida_idx);
		to = 50000;
		while ((idx=ida_idx) == -1 && to) to--;
		if (!to) break;

		dbg_printf("ext_in: idx=%d  da=%08x nda=%08x  proc=%08x  @%d\n", idx, ida_da, ida_nda, ida_proc, cpuCycle());
		#ifdef VERBOSE_GENERAL
			int t1 = cpuCycle();
		#endif
		if (idx <= IDA_LAST_CFD)
			cfd_read_rxfifo(idx);
		else {
			assert(idx >= IDA_FIRST_ETH); //Will fail when XL is added
			etnd_read_rxfifo(idx - IDA_FIRST_ETH);
		}

		#ifdef VERBOSE_GENERAL
			t1 = cpuCycle() - t1;
			dbg_printf("         Ingress process time %d\n", t1);
		#endif
	}
	return 0;

	#ifdef VERBOSE_GENERAL
		//Print the collected counters
		dbg_puts("+----- Status summary of C-Code side ------------------------------\n");
		dbg_puts("| Ingr FFI CFG |");
		for (int j=0; j<LAST_COUNTER_INGRESS; j++)
			dbg_printf(" %10s", dbg_COUNTER_INGRESS_STR[j]);
		dbg_puts(" |\n+------------------------------------------------------------------\n");
		int eth=IDA_FIRST_ETH;
		for (int j=0; j<INGRESS_MAX; j++) {
			int m = raConfig->ingressMap[j];
			if (m == 255) continue;
			if (j>=eth) {
				dbg_puts("+------------------------------------------------------------------\n");
				eth = 10000;
			}
			dbg_printf("| %4d   %d  %2d |", j, raConfig->ingress[m].ingressPartition, m);
			for (int i=0; i<LAST_COUNTER_INGRESS; i++)
				dbg_printf(" %10d", countersIngress[j][i]);
			dbg_printf(" |\n");
		}


			// int sum = 0;
			// for (int i=0; i<raConfig->maxIngress; i++)
			// 	sum += countersIngress[i][j];
			// dbg_printf("| %-25s %4d", dbg_COUNTER_INGRESS_STR[j], sum);
			// for (int i=0; i<raConfig->maxIngress; i++)
			// dbg_putnl();
	#endif

	return 0;
}
