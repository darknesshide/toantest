#ifndef __SHARED_DATA_H__
#define __SHARED_DATA_H__
//-------------------------------------------------------------------
//Shared data must be included in all PEs in same manner.
//Include this file only once per PE code, because the definition is
//not 'extern'. All defined data are declared in the C file.
//
//Variables accessed by different PEs shall be declared volatile to
//ensure data is written at the current place in C-Code and not moved
//by compiler optimisation.
//-------------------------------------------------------------------

#include <stdint.h>

//Give PEs and IPC channels names
#define INGRESS_STAGE    PE0
#define PROCESSING_STAGE PE1

#define IPC_CONFIG_DONE   0  //shared IPC unit. Only used during boot time between all PEs
#define IPC_INGRESS_FIFO  0


//-------------------------------------------------------------------
//Ingress FIFO control stucture (init by source)
volatile struct s_packedFifo ingressFIFO __attribute__ ((section (".ipcdata")));

volatile struct s_packedFifo vPortFIFO[VPORT_MAX] __attribute__ ((section (".ipcdata")));
volatile uint32_t vPortPending __attribute__ ((section (".ipcdata")));
#if VPORT_MAX > 32
#error "More than 32 vPorts cannot be handled by current uint32_t variable"
#endif

volatile uint32_t countersIngress[INGRESS_MAX][LAST_COUNTER_INGRESS] __attribute__ ((section (".ipcdata")));
volatile uint32_t countersEgress[EGRESS_MAX][LAST_COUNTER_EGRESS] __attribute__ ((section (".ipcdata")));

#endif
