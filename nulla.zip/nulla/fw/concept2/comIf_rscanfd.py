import ra;
import random


CFD_CHANNELS = 16

LEN2DLC = [0,1,2,3,4,5,6,7, 8,12,16,20, 24,32,48,64]
TYPE_STR = ["CCb", "FDb", "CCe", "FDe"]

rxFifoCnt = 0


#------------------------------------------------------------------------------
def scoreboard_frameTag(srcBus, id, fdf, ide, rtr=0, brs=0, esi=0):
	if srcBus == None:
		tag = ""
	else:
		tag = str(srcBus) + ">"
	assert int(fdf) in [0,1] and int(ide) in [0,1], f"Out of range parameter fdf={fdf} ide={ide}"
	tag += TYPE_STR[fdf + ide*2] + "." + str(id) \
	    + (".R" if (rtr) else "") + (".B" if (brs) else "") \
	    + (".E" if (esi) else "")
	#print(tag)
	return tag
#def


#------------------------------------------------------------------------------
#creates the RSCANFD receive data provided to TUBE by Rx-FIFO
# ide   base/extended format   optional, if not given IDs<2k generate base format
# data  8-bit array            optional, if not given filled with size-times random data
# Returns a Fifo-Entry-Object
def assemble_rxObject(id, size, fdf, ide=None, data=None, rtr=0, ts=0, ptr=0, ifl=0, brs=0, esi=0, srcBus=None):
	if (ide == None):
		ide = 0 if id < 2048 else 1
	if (data == None):
		data = 	[random.randint(0, 0xff) for y in range(size)]
	assert (type(ts) == int and ts >= 0 and ts <= 0xffff), f"cfd_RxFifo object assembling fails. ts={ts} is no integer or out of range."
	assert len(data) == size, f"cfd_RxFifo object assembling fails. Provided data (len={len(data)}) != requested size {size}."
	assert (size in LEN2DLC), f"cfd_RxFifo object assembling fails. Size {size} out of range."
	assert (fdf or size <= 8), f"cfd_RxFifo object assembling fails. Size {size} not valid for CC."
	#RIFD  +0 -- IDE, RTR, -, ID[29]
	#RIPTR +4 -- DLC[4], -[12], TS[16]
	#STS   +8 -- PTR[16], -[6], IFL[2], -[5], FDF, BRS, ESI
	h0 = (ide<<31) + (rtr<<30) + id
	h1 = (LEN2DLC.index(size)<<28) + ts
	h2 = (ptr<<16) + (ifl<<8) + (fdf<<2) + (brs<<1) + esi
	#print("head=%s" %([hex(i) for i in [h0, h1, h2]]))
	#print("data=%s" %([hex(i) for i in data]))
	return {0:[h0, h1, h2], 1:data, "tag":scoreboard_frameTag(srcBus, id, fdf, ide, rtr, brs, esi)}
#def


#------------------------------------------------------------------------------
#Copy the first entry of simulation side Rx-FIFO into SRF for the TUBE's software processing
def publish_rxFifo(fifoIdx):
	global rxFifoBuf, rxFifoAccessWindowFree
	#print("ra.tick: Publish to CAN to fifo %s (%d further entries pending)"%(fifoIdx, len(rxFifoBuf[fifoIdx])-1))
	obj = rxFifoBuf[fifoIdx].pop()
	ra.write(ra.CANRXFIFORAM[fifoIdx], 32, obj[0])
	ra.write(ra.CANRXFIFORAM[fifoIdx]+12, 8, obj[1])
	# set data available signal to trigger TUBE ingress stage
	assert ra.markInFifoAvailable(fifoIdx), f"cfd_RxFifo {fifoIdx} sanity check fails. Access window is full."
	rxFifoAccessWindowFree[fifoIdx] = False
#def


#------------------------------------------------------------------------------
#Simulation model of RSCANFD's Rx-FIFO
#
def add_to_RxFifo(fifoIdx, obj):
	global rxFifoBuf, rxFifoAccessWindowFree, rxFifoCnt
	#FULL --> discard
	if (len(rxFifoBuf[fifoIdx]) > config['cfd_RxFifoDepth'][fifoIdx]):
		print("  PY  WARNING: cfd_RxFifo FULL with %d entries. Frame dropped."%(len(rxFifoBuf[fifoIdx])))
		return False

	#queue it in Python software FIFO
	#print("         Queue to %s"%(fifoIdx))
	rxFifoBuf[fifoIdx].append(obj)
	rxFifoCnt += 1

	#if access window is free, publish this frame directly
	if rxFifoAccessWindowFree[fifoIdx]:
		publish_rxFifo(fifoIdx)
	return True
#def

#------------------------------------------------------------------------------
#Simulation model of RSCANFD's Rx-FIFO release register
#
def release_RxFifo_entry(fifoIdx):
	global rxFifoBuf, rxFifoAccessWindowFree
	rxFifoAccessWindowFree[fifoIdx] = True
	if rxFifoBuf[fifoIdx]:
		publish_rxFifo(fifoIdx)
#def


#------------------------------------------------------------------------------
#Basic initialisation
def init(_config=None):
	global rxFifoBuf, rxFifoAccessWindowFree
	global config, rxFifoCnt

	#take over the configuration
	if _config != None:
		config = _config
	#assemble a default configuration
	else:
		config = {
			#per TUBE spec CFD entries are always 64 bytes, only DLC check is needed
			'cfd_RxFifoDepth' : [64]*CFD_CHANNELS,   #entries per FIFO
		}

	#setup the internal data structures
	rxFifoBuf = [[] for i in range(CFD_CHANNELS)]
	rxFifoAccessWindowFree = [True for i in range(CFD_CHANNELS)]
	rxFifoCnt = 0

	#init the Rx-FIFOs of RSCANFD with some random data
	# for i in range(CFD_CHANNELS):
	# 	d = [0xd0d00d0d+0x01010000*i+0x0010*j for j in range(19)]
	# 	if not ra.write(ra.CANRXFIFORAM[i], 32, d):
	# 		return True
	return False
#def
