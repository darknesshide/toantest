"""
Test scenarios for Ethernet frame processing with different configurations.
Updated to use actual MAC addresses from config.json VlanDaTableCfg entries.
"""
import sys
# print(sys.argv)
# exit(1)

# Import required constants and types
from moduleComif import *


# Check testcase name is provided by the make command
if len(sys.argv) != 2:
	print(f"\n{RED}Missing parameter TC, use: {YELLOW}make run TC=<name>{NORM}\n")
	exit(5)

testcase = sys.argv[1]
print(f"{YELLOW}  PY  Chosen testcase: %s {NORM}"%testcase, end="\n")

# Initialize test stimulus definitions
rxStimulusDef = [None] * 32

expectedFramesNotTransmitted = []

# ============================================================================
# TEST SCENARIO SELECTION
# Set one of these to True to activate the corresponding test scenario
# ============================================================================
if testcase == 'can1' or testcase == "default":
	print(f"  PY  Tests triggering CAN frames of CC and FD for basic and extended foramt")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	frames = 1

	expectedFramesNotTransmitted = [["0>Id11.231.CC>4", 1]
	                               ,["0>Id11.232.FD>4", 1]
	                               ]

	rxStimulusDef[0] = [
	    [0x000003b4, CCb,  3, [1.0, 0.3], frames],
	    [0x0000072c, CCb,  0, [1.0, 0.3], frames, {"RTR":1}],
	    [0x000235de, CCe,  7, [1.0, 0.3], frames],
	    [0x08745a3f, CCe,  1, [1.0, 0.3], frames, {"RTR":1}],
	    [0x00000123, FDb,  8, [1.0, 0.3], frames, {         "BRS":1}],
	    [0x0dcef067, FDe, 12, [1.0, 0.3], frames, {"RTR":1, "BRS":0, "ESI":1 }],
	    [0x0000002c, FDb, 24, [1.0, 0.3], frames, {"RTR":0, "BRS":0, "ESI":1 }],
	    [0x11223344, FDe, 64, [1.0, 0.3], frames, {"RTR":1, "BRS":1, "ESI":0 }],
	  ]

	rxStimulusDef[1] = [
	    # [0x000003b4, CCb,  3, [1.0, 0.3], frames],
	    [0x0000072c, CCb,  0, [2.0, 0.3], frames, {"RTR":1}],
	  ]

	rxStimulusDef[7] = [
	    # [0x000003b4, CCb,  3, [1.0, 0.3], frames],
	    [0x000235de, CCe,  7, [1.4, 0.3], frames],
	  ]

	rxStimulusDef[8] = [
	    # [0x000003b4, CCb,  3, [1.0, 0.3], frames],
	    [0x00000123, FDb,  8, [4.0, 0.3], frames, {         "BRS":1}],
	  ]

	rxStimulusDef[9] = [
	    # [0x000003b4, CCb,  3, [1.0, 0.3], frames],
	    [0x0000002c, FDb, 24, [5.0, 0.3], frames, {"RTR":0, "BRS":0, "ESI":1 }],
	  ]

	rxStimulusDef[10] = [
	    # [0x000003b4, CCb,  3, [1.0, 0.3], frames],
	    [0x11223344, FDe, 64, [6.0, 0.3], frames, {"RTR":1, "BRS":1, "ESI":0 }],
	  ]

# ============================================================================
elif testcase == 'mix1':
	configJsonFile = 'config.json'  #json file loaded for this testcase

	# some frames with different sizes, all send back to back
	rxStimulusDef[0] = [
	    # [0x000007cc, CCb,    5, 1.0, 1],
	    # [0x1eeff901, FDe,   64, 1.5, 1],
	    # [0x000005de, XL,  2048, 1.0, 1, {0x12345678, 100, 200}],
	    # [0x00000100, CCb,    3, 1.0, 1],
	]

	rxStimulusDef[6] = [
	    # [0x00000123, CCb,    7, 1.0, 1],
	    # [0x1eeff901, FDe,   64, 1.5, 1],
	    # [0x000005de, XL,  2048, 1.0, 1, {0x12345678, 100, 200}],
	    # [0x00000100, CCb,    0, 1.0, 4],
	]

	rxStimulusDef[16] = [
		# A simple ETH frame as reference
		["16:26:1a:2b:3c:4d", T1S,  67,  0.5, 1, {"ET":0x4004, "VID":0x753, "PCP":0x9}],     #per ET
		["16:26:22:33:44:02", T1S, 150,  2.5, 1, {"ET":0x4367}],     #per ET
	]
	rxStimulusDef[17] = [
	# 	# A simple ETH frame as reference
		["17:27:1a:2b:3c:4d", T1S,  99,  1.5, 1, {"ET":0xed23, "VID":0x753, "PCP":0x9}],     #per ET
	# 	# ["17:27:22:33:44:02", T1S, 404,  2.2 1, {"ET":0x1234}],     #per ET
	]
	rxStimulusDef[18] = [
	# 	# A simple ETH frame as reference
		["18:28:1a:2b:3c:4d", T1S,  267,  1.0, 1, {"ET":0xed23, "VID":0x753, "PCP":0x9}],     #per ET
	# 	# ["18:28:22:33:44:02", T1S, 734,  2.0, 1, {"ET":0x1234}],     #per ET
	]

# ============================================================================
elif testcase == 'classify':
	configJsonFile = 'config.json'  #json file loaded for this testcase

	# some frames with different sizes, all send back to back
	rxStimulusDef[0] = [
		[100, CCb,    8, 1.0, 1],
		# [101, CCb,    7, 1.4, 1, {"BRS":1}],
		# [102, CCb,    6, 1.8, 1],
		# [103, CCb,    5, 2.2, 1],
		# [104, FDb,    4, 2.6, 1],
		# [105, FDb,   12, 3.4, 1],
		# [106, FDb,   48, 3.8, 1],
		# [107, FDb,   64, 4.2, 1],

		# [1000, CCe,    6, 1.8, 1],

		# [200, FDb,   48, 2, 1],   #-->SG0 (send immediately)
		# [201, FDb,   0, 2, 1],

		# [210, FDb,  64, [3, -1], 2],   #-->SG1 (collect up to 1100 bytes, 50 frames, 50 ms)
		# [211, FDb,  64, [3, -1], 2],
		# [212, FDb,  64, [3, -1], 2],
		# [213, FDb,  64, [3, -1], 2],
		# [214, FDb,  64, [3, -1], 2],
		# [215, FDb,  64, [3, -1], 2],
		# [216, FDb,  64, [3, -1], 2],
		# [217, FDb,  24, 3, 1],
		# [218, FDb,   8, 7, 1],   #4 for 1996, 8 for ==1100, 12=1104

		# [210, FDb,  64,  8, 1],   #-->SG1 (collect up to 1100 bytes, 50 frames, 50 ms)
		# [211, FDb,  64,  8, 1],
		# [212, FDb,  64,  8, 1],
		# [218, FDb,  12,  8, 1],
		# [219, FDb,  5,  8, 1],   #trigger flush
	]

	rxStimulusDef[16] = [
		# A simple ETH frame as reference
		# ["00:11:22:33:44:02", T1S, 60,  1.5, 1, {"ET":0x0800}],
		# ["00:11:22:33:44:03", T1S, 61,  2.0, 1, {"ET":0x0800, "VID":0x123, "PCP":7}],
		# ["00:11:22:33:44:02", T1S, 63,  2.0, 1, {"SID":"0x91E0F000_FE700002"}],   #only add
		#["1a:2b:3c:4d:5e:6f", T1S, 67,  1.5, 1, {"ET":0x4004, "VID":0x753, "PCP":0x9}],     #per ET

		#SID matches but no content --> exceptional
		["00:11:22:33:44:02", T1S, 62,  2.0, 1, {"SID":"0x01234567_fedcba98"}],

		#Singe ACF in stream (with padding)
		["e0:e1:e2:e3:e4:e5", T1S, 100, 2.5, 1, {"SID":0x01234567_fedcba98, "VID":7, "ACF":[
				[213, CCb, 7],
			], "hasException":False}],
	]

# ============================================================================
elif testcase == 'perf1': # Not running need to adapt on current port setting
	sys.exit(-1)
	configJsonFile = 'config.json'  #json file loaded for this testcase

	E_MAX = 1.6576 # time of longest T1S frame on bus
	RA_MAX = 0.006625 # Routing time for 2048 + 8 * 4 bytes
	rxStimulusDef[ 0] = [
		["11:22:33:44:55:66",  T1S, 2048, [1.8000,                       -1],  1, {}],
		# [0x542,                XL,  176, [1.8000 + E_MAX,                -1],  5, {}]
	]
	# rxStimulusDef[ 1] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  1 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  168, [1.8000 +  1 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 2] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  2 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  160, [1.8000 +  2 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 3] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  3 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  152, [1.8000 +  3 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 4] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  4 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  144, [1.8000 +  4 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 5] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  5 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  136, [1.8000 +  5 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 6] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  6 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  127, [1.8000 +  6 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 7] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  7 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  119, [1.8000 +  7 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 8] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  8 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                XL,  111, [1.8000 +  8 * RA_MAX + E_MAX,  -1],  5, {}]
	# ]
	# rxStimulusDef[ 9] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 +  9 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,  104, [1.8000 +  9 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[10] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 10 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   98, [1.8000 + 10 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[11] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 11 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   92, [1.8000 + 11 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[12] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 12 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   86, [1.8000 + 12 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[13] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 13 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   80, [1.8000 + 13 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[14] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 14 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   74, [1.8000 + 14 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[15] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 15 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   67, [1.8000 + 15 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[16] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 16 * RA_MAX,         -1],  1, {}],
	# 	["11:22:33:44:55:66",  T1S,   61, [1.8000 + 16 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[17] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 17 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                 XL,   36, [1.8000 + 17 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[18] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 18 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                 XL,   27, [1.8000 + 18 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[19] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 19 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                 XL,   19, [1.8000 + 19 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[20] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000 + 20 * RA_MAX,         -1],  1, {}],
	# 	[0x542,                FDb,   15, [1.8000 + 20 * RA_MAX + E_MAX, -1],  5, {}]
	# ]
	# rxStimulusDef[21] = [
	# 	["11:22:33:44:55:66",  T1S, 2048, [1.8000,                       -1],  1, {}],
	# 	[0x542,                 XL,  176, [1.8000 + 1.6576,              -1],  1, {}],
	#     [0x542,                FDb,    0, [1.8000 + 1.6576 + 0.1456,     -1], 20, {}]
	# ]

# ============================================================================
else:
	print(f"\n{RED}PY  testcase = %s is not defined!{NORM}"%testcase, end="\n\n")
	exit(5)
