
= Overview of configuration in JSON file for TUBE


== Ingress configuration below `ingress`

This section contains a list of *N* ingress interfaces (CAN, ETH, CPU). And controls

* Mapping to pysical interface
* FFI partition relation
* Classification table based on interface protocol
* Forwarding actions

Categories of fields:

* `Mandatory` Defines a required parameter.
* `Alternate x` Defines group `x` in which exactly one parameter is required.
* `Default v` Defines an optional parameter. If not provides the value `v` is used.
* `Conditional` Defines a parameter which is mandatory based on another parameter.

Generic values used in definitions:

* `name` A string to identify an interface (CAN, Ethernet, CPU, vPorts) and Stream units.
* `number` A decimal number or a string containing an hex number (e.g. "0x7b") or a formula.
* `**ABC**` A label to a sub-container explained in a dedicated chapter of this document.

== Top-level container

```json
{
  "ingressFifo": {                     //Mandatory  | Common ingress FIFO definition
    "relatesToRam": "ramName",         //Mandatory  | Defines the TUBE-RAM where to place this FIFO
    "size": number                     //Mandatory  | Defines the size of the FIFO
  },

  "vPortFifo": {                       //Mandatory  | vPort buffers used by ETH->CAN termination
    "relatesToRam": "ramName",         //Mandatory  | Defines the TUBE-RAM where to place this FIFO
    "vPortNumber": number,             //Mandatory  | How many vPorts can be used (0~32)
    "defaultSize": number,             //Mandatory  | Size of the vPort buffers
    "index": number,                   //Optional   | Defines for vPort index the buffer size (can be placed multiple times)
    ...
  },

  "ingress": [**INGRESS**],            //Mandatory  | The classification and forwarding rule definition
  "egress": [**EGRESS**],              //Mandatory  | The egress FIFO definition
  "streamTerminate": [**STREAMTERM**], //Default [] | The stream termination definition
  "streamGenerate": [**STREAMGEN**],   //Default [] | The stream generation definition

//Environment configurations. Not in real product
  "hwAddressesForConfigGenerator": {   //Mandatory  | Defines TUBE's HW Addresses for configuration and buffer mapping (in "data")
    "raConfigBaseAddr":    "0x206000", //Mandatory  | Address of the TUBE configuration structure (matches with #define in C-Code)
    "bufferInBaseAddr":    "0x400000", //Mandatory  | HW Address of TUBE input side data RAM
    "bufferOutBaseAddr":   "0x500000", //Mandatory  | HW Address of TUBE output side data RAM
  },

  "busConfigurationForStimulusGeneration": {  //Mandatory | Defines the interface bus speed configuration in kBit/s
    "canBitrateArbitration": number,
    "canBitrateData": number,
    "xlBitrateArbitration": number,
    "xlBitrateData": number,
    "ethPortSpeed": number
  }
}
```

The `ramName` is either

* `bufferIn` for elements placed in input buffer RAM (bufferInBaseAddr)
* `bufferOut` for elements placed in output buffer RAM (bufferOutBaseAddr)
* `globalData` for elements placed in global data RAM (after the raConfig structure)


=== **INGRESS** container definition

```json
{
  ...
  "ingress": [
    {
      "name": "name",                           //Mandatory      | Ingress name in form of "CFD0~16, ETH0~9, XL0~7, CPU0~127, vPort0~31"
      "ffiPartition": number,                   //Default 4      | 0~3 for normal, 4 for privileged FFI partition
      "1722BusId": number,                      //Default idx    | Defines the bus_id used by stream generation for ACF. idx represents the ingress port number like in IPN field

      //Only defined for CAN, CPU/CAN, and vPort interfaces
      "RxPduDefault": {**CAN-ACTION**},         //Default {}     | Defines action used if no found classification entry
      "RxPduDisabled": {**CAN-ACTION**},        //Default {}     | Defines action used if found classification entry is disabled
      "RxPduCfg": [                             //Default []     | List of rules with search values and actions used if entry matches
        {
          //This block is only defined for CC and FD frames
          "CanIfRxPduCanId11": number,          //Alternate A    | Defines Id for CAN frames with base identifier
          "CanIfRxPduCanId29": number,          //Alternate A    | Defines Id for CAN frames with extended identifier
          "CanIfRxPduCanIdRangeUpperCanId": number, //Optional   | Allows definition of a CAN Id range (no range if not present)
          "CanIfRxPduCanIdMask": number,        //Optional       | Allows definition of a binary mask CAN Id (no masking if not present)
          "CanIfRxPduCanIdType": "scope",       //Default "CCFD" | Defines the scope of CAN Id in form of "CC, FD, CCFD"

          //This block is only defined for XL frames
          "CanIfXLPriorityId": number,          //Mandatory      | 11-bit
          "CanIfXLSduType": number,             //Mandatory      | 8-bit
          "CanIfXLVcid": number,                //Mandatory      | 8-bit
          "CanIfXLAcceptanceField": number,     //Mandatory      | 32-bit

          //This block is only defined for I-PDU (could come from vPort or CPU)
          "IPduId": number,                     //Mandatory      | 16-bit

          //From here the fields relates to **CAN-ACTION**
          "FrameSizeCheck": "mode",             //Default none   | Check mode can be "none <= == >="
          "FrameSize": number,                  //Conditional    | Defines the frame size to be used for frame size check
          "Targets": "names",                   //Default ""     | String with all targets e.g. "CFD0, CPU73, SG5, SG12"
          "TxConfirmationOn": "names",          //Default ""     | String with targets require a confirmation e.g. "CFD2, XL6"
          "flushOnTarget": "names",             //Default ""     | Flush Stream Generation target e.g. "SG2"

          "CanIfTxPduCfg": [                    //Default []     | List of CAN modification rules, not listed name in "Targets" are unchanged
            {
              "target": "name",                 //Optional       | Selects a name in "Targets" list where this modification applies (optional if there is only 1 target)
              "allowTruncation": boolean,       //Default false  | Controls if frames are discarded (false) or forwarded (true) in case of truncation
              //This block is only defined for CC and FD
              "CanIfTxPduCanId11": number,      //Alternate A    | Defines the new CAN Id in base format
              "CanIfTxPduCanId29": number,      //Alternate A    | Defines the new CAN Id in extended format
              "CanIfTxPduCanIdType": "format",  //Mandatory      | Defines the CAN frame format as "CC, FD"
              //This block is only defined for XL
              "CanIfXLPriorityId": number,      //Mandatory      | 11-bit
              "CanIfXLSduType": number,         //Mandatory      | 8-bit
              "CanIfXLVcid": number,            //Mandatory      | 8-bit
              "CanIfXLAcceptanceField": number, //Mandatory      | 32-bit
            },
            ...
          ],
        },
        ...
      ],

TODO: Fixed classification fields for streams

      //Only defined for ETH and CPU/ETH interfaces
      "DefaultVlanId": number,                  //Default 0xfff  | Defines VID used for lookup of untagged frame
      "AcceptanceDefault": {**ETH-ACTION**},    //Default {}     | Defines action used if no found classification entry
      "AcceptanceCfg": [                        //Default []     | List of rules with search values and actions used if entry matches
        {
          "destMacAddr": "address",             //Mandatory      | Defines the MAC-DA as hex-string e.g. "e0:e1:e2:e3:e4:e5"
          "vlanId": number,                     //Optional       | Defines the VID (0 to 0xfff). Missing means untagged and `DefaultVlanId` applies.

          //From here the fields relates to **ETH-ACTION**
          "FrameSizeCheck": "mode",             //Default all    | Check mode can be "none <= == >="
          "FrameSize": number,                  //Conditional    | Defines the frame size to be used for frame size check
          "Targets": "names",                   //Default ""     | String with all targets e.g. "ETH3, ETH4, ETH5, CPU7"
          "TxConfirmationOn": "names",          //Default ""     | String with targets require a confirmation e.g. "ETH3, ETH4"
          "streamIdentification": [             //Default []     | List of streams (streamId must be unique per interface)
            {
              "streamId": "identifier",         //Mandatory      | "64BitHexSid" for 1722 stream,  "SrcIP:port DstIP:port" for IPDU stream

              "streamUnit": "name",             //Default ""     | Defines the stream termination offload target e.g. "ST7"
              "actsFor": "name",                //Default ""     | Defines a name in "Target" which is not used for stream frames e.g. "CPU7"
            },
            ...
          ],
        },
        ...
      ],
    },

//Other ingress interface definitions
    ...
  ],
  ...
}
```

In case `RxPduCfg` or `AcceptanceCfg` is empty, always the default rule is used.

As `Targets` all physical ports (CAN, ETH, XL, CPU) and the stream Termination units "STREAM0~31" are valid.

Truncation happens in case of protocol conversion during CAN/CAN forwarding. In case of FD->CC or XL->CC if length is > 8.
In case of XL->FD if length is > 64.

Padding with 0x00 happens in case of XL->FD protocol conversion if the length cannot be represented by a DLC value.

During CAN/CAN forwarding the length is the received CAN frame is primary used for the conversion.
If an truncation is required and the `FrameSizeCheck` is ">", the provided `FrameSize` is used to decide if a truncation is necessary.
Autosar defines "CanIfRxPduDataLengthCheck" as minimum frame size which is valid for processing.

=== **EGRESS** container definition

=== **STREAMTERM** container definition

```json
{
  ...
  "streamTerminate": [
    {
      "name": "name",                   //Mandatory   | Name of this stream generation instance (e.g. ST0~31, as used in ETH target definition)
      "exceptionTarget": "name",        //Default ""  | Name of one ETH or CPU/ETH port used to send the ETH frame in case of decoding error
      "containerTarget": "name",        //Default ""  | Name of CPU/ACF port to send IPDUs or unknown ACF container types (e.g. to handle LIN)
      "busIdTranslation": [             //Mandatory   | Links between bus_id in ACF to vPorts (in case of IPDU streams "number" is always 0)
        { "number": "name" },           //Mandatory   | Defines for interface *name* the bus_id number (e.g. "0": "vPort3)
        ...
      ],
    },
    ...
  ],
  ...
}
```

I no `exceptionTarget` is given, there is no exceptional forwarding in case of frame decoding errors.

If no `acfTarget` is given, the frame is forwarded to the exceptionTarget in case of unknown ACF format. All known
ACF containers are extracted independent from the failure position.

=== **STREAMGEN** container definition

This container controls the stream generation.

```json
{
  ...
  "streamGenerate": [
    {
      "name": "name",                 //Mandatory   | Name of this stream generation instance (e.g. SG0~31, as used in CAN target definition)
      "relatesToRam": "ramName",      //Mandatory  | Defines the TUBE-RAM where to place this buffer
      "bufferSize": number,           //Mandatory   | Size of the assembling buffer
      "streamFormat": "format",       //Mandatory   | Defines the format for container generation as ACF or IPDU
      "maxFrameSize": number,         //Default 1   | Tx is triggered if this number of bytes (1~2000) is assembled
      "maxContainers": number,        //Default 250 | Tx is triggered if this number of containers (1~250) is assembled
      "txTimeout": number,            //Default 0   | Tx is triggered after txTimeout (0~50.0) [in ms] after first container is assembled
      "Targets": "names",             //Mandatory   | Defines the forwarding targets of of the generated Ethernet frame e.g "ETH3, CPU7"
      "templateData" : [              //Mandatory   | Defines the stream header as list of 32, 16, and 8 bit data strings
        { "data32": "values" },       //Optional    | List of Hex numbers. ' ', ',' or ':' separated.  '_' inside numbers are ignored
        { "data16": "values" },       //Optional    | List of Hex numbers. ' ', ',' or ':' separated.  '_' inside numbers are ignored
        { "data8":  "values" },       //Optional    | List of Hex numbers. ' ', ',' or ':' separated.  '_' inside numbers are ignored
        ...
      ],
      "patchDataLengthPos": number,   //Mandatory   | Offset of byte (4-byte aligned) in templateData where length value to be patched in
    },
    ...
  ],
}
```

The maxFrameSize does not define the size of the assembling buffer. This needs to be maxFrameSize + maxContainter -1
maxFrameSize includes the size of header template and all headers inside the container (e.g. ACF header)

If a container would exceed the buffer size, the pending frame is transmitted and a new frame is assembled. Containers
not fitting into the buffer at all are discarded.

txTimeout is decreased to the timing grid of TUBE.

A template data example for NTSCF frame with VLAN:

```json
"templateData" : [
    { "data32": "0000_0000 0000_0000 0000_0000 0000_0000"}    //prepares space for TUBE internal meta data
    { "data16": "0"}                                          //prepares space for TUBE internal Ethernet alignment gap
    { "data8":  "00:00:0e:1e:2e:3e 4e  5e:06:16:26:36"},
    { "data16": "22f0"},
    { "data8":  "82 80 00 41  88 99 aa bb cc dd ee ff"}
],
```
