#Add the search path to the python modules
import sys
sys.path.append(sys.path[-1]+"../../apps")

#Import connection to the ra simulation environment
import ra;
#Import RSCANFD model
import comIf_rscanfd as cfd;
#Import ETND model
import comIf_etnd as etnd;

#Import the communication interface simulation environment
from moduleComif import *

#read RA configuration from config file
from readCfg import raConfig
import readCfg as readCfg

#some general libraries
import random

#Import test_scenarios
from test_scenarios import *


#add this lines to send Ethernet frames to observe with wireshark
#from moduleMACsec import Scapy
#scapy = Scapy(True)


#------------------------------------------------------------------------------
# Global variables
scoreboard = []
scoreboard_errors = 0

ingressBufferPage = [0] * 32
ingressBufferFillLevel = [0] * 32

egressBufferPage  = [0] * 32

protocol_translate = [None] * (T1S + 1)
protocol_translate[CCb] = 0 # CAN Base Frame Format
protocol_translate[FDb] = 0 # CAN Base Frame Format
protocol_translate[CCe] = 1 # CAN Extended Frame Format
protocol_translate[FDe] = 1 # CAN Extended Frame Format
protocol_translate[XL ] = 2 # CAN XL Frame Format
protocol_translate[T1S] = 3 # Ethernet Frame Format

protocol_rule = ["Id11", "Id11", "Id29", "Id29"]
format_rule = ["XL", "CC", "FD", "ET"]

LEN2DLC = [0,1,2,3,4,5,6,7, 8,12,16,20, 24,32,48,64]

seqNumberCounter = {}


#------------------------------------------------------------------------------
# def frameTagString(srcBus, frameType, id):
# 	if (srcBus != None):
# 		return f"{srcBus}>{protocol_rule[frameType]}.{id}.{TYPE_STR[frameType][0:2]}"
# 	else:
# 		return f"{protocol_rule[frameType]}.{id}.{TYPE_STR[frameType][0:2]}"
#def


#------------------------------------------------------------------------------
def addToScoreboard(bus, frameTag, frameInfo, payload, ts=0, fifoHeaderSize=0, targets=[], vPortIdx=None):
	#print(f"addToScoreboard({bus}, {frameTag}, {frameInfo}, {payload}, {ts}, {fifoHeaderSize}, {targets})")
	#print(comCfg.rules[bus])
	if frameTag in comCfg.rules[bus]:
		allTargets = targets + comCfg.rules[bus][frameTag]
	else:
		allTargets = targets
	#print("  PY         addToScoreboard(bus=%d) Tag:"%bus, frameTag, "Bus:", bus, "Targets:", len(allTargets), "vPort:", vPortIdx) #, "-", allTargets)
	#print(comCfg.rules[bus])

	toAdd = []
	for tg in allTargets:
		#print(tg)
		#if (tg[1]):
		#	print(tg[1])
		if len(payload) >= tg["minLength"]:  #too short frames are always discarded
			#print(tg[0])
			#print(comCfg.egressBuffer[tg["target"]])
			ff = ( f"{bus}>{tg['TxModify']}" if tg['TxModify'] else frameTag) + frameInfo
			if (len(payload) > comCfg.egressBuffer[tg["target"]]["fifoEntrySize"]-fifoHeaderSize):
				p = payload[0:comCfg.egressBuffer[tg["target"]]["fifoEntrySize"]-fifoHeaderSize]
				ff += "!T"
			else:
				p = payload
			#print("bus", bus, " tg", tg["target"], " mapFifoToStream", comCfg.mapFifoToStream)
			#re-mapping of CAN->ETH generation
			# if tg["target"] in comCfg.mapFifoToStream:
			# 	#print(comCfg.streams[comCfg.mapFifoToStream[tg["target"]]])
			# 	ff += ".S"
			#re-mapping of ETH->CAN termination
			if vPortIdx != None:
				ff = f"{vPortIdx}>{ff[ff.find('>')+1:]}"
			ff = f'{ts/1000000:1.2f}|{ff}>{tg["target"]}'
			#ff = f"{ff}>{tg["target"]}"
			print(f"  PY           Register frame '{ff}' with len={len(p)}")
			toAdd.append(ff.encode()+" ".encode()+bytes(p))
			#scoreboard.append(ff.encode()+" ".encode()+bytes(p))
	#for
	return toAdd
#def


#******************************************************************************
#***** Ingress side model *****************************************************
#******************************************************************************
def ingressStoreInBuffer(now, bus, idx, PN, ts):
	global ingressBufferPage, counters_error, counters
	if comIf.VERBOSE&8 or 0:
		print(f"{CYAN}{now/MSTONS:8.3f} > ingressStoreInBuffer({bus}, {idx}, {PN}, {ts/MSTONS:1.3f}){NORM} callback")

	frame = rxStimulusDef[bus][idx]
	#print(bus, idx, frame)
	print (f"  PY  {L_GREEN}{now/MSTONS:8.3f} ingressStoreInBuffer: bus={bus} TYPE={TYPE_STR[frame[RX_DEF_TYPE]]} ID={frame[RX_DEF_ID]} SIZE={frame[RX_DEF_SIZE]} {frame[RX_DEF_ENH]['comment']}{NORM} ts={ts}\n", end="")

	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	#- - - - - Assemble the message
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	frameType = frame[RX_DEF_TYPE]
	size = frame[RX_DEF_SIZE]
	if frameType == T1S:  # Ethernet frame processing
		#print(frame)
		da = frame[RX_DEF_DA]
		enh = frame[RX_DEF_ENH]
		fifoObject = etnd.assemble_rxObject(da=da, size=size, et=enh["ET"], vid=enh["VID"], pcp=enh["PCP"], sid=enh["SID"], acf=enh.get("ACF", None), ts=(int(ts)//1000//10))
		etnd.add_to_RxFifo(bus, bus-readCfg.DEFINE_INGRESS_FIRST_ETH, fifoObject)

	else:  # Standard check for CAN frames
		id = frame[RX_DEF_ID]
		fdf = 1 if frame[RX_DEF_TYPE] in (1, 3) else 0
		ide = protocol_translate[frame[RX_DEF_TYPE]]
		rtr = frame[RX_DEF_ENH]["RTR"] if "RTR" in frame[RX_DEF_ENH] else 0
		brs = frame[RX_DEF_ENH]["BRS"] if "BRS" in frame[RX_DEF_ENH] else 0
		esi = frame[RX_DEF_ENH]["ESI"] if "ESI" in frame[RX_DEF_ENH] else 0

		assert (frameType < XL)  # in the first step we will handle only CC and FD frames
		assert (size in LEN2DLC), f"{size} is no valid CAN length. Use {LEN2DLC}"

		# buffer = comCfg.ingressBuffer[bus]
		# if (size > buffer['fifoEntrySize']):
		# 	print("%s  PY  ERROR: No stimulus for oversized frame on bus %d size=%d fifoSize %d at %1.3f%s"%(RED,
		# 		bus, size, buffer['fifoEntrySize'], now/MSTONS, NORM))
		# 	return

		fifoObject = cfd.assemble_rxObject(id=id, size=size, fdf=fdf, ide=ide, data=None, rtr=rtr, ts=(int(ts)//1000//10)&0xffff, ptr=0, ifl=0, brs=brs, esi=esi, srcBus=bus)
		if not cfd.add_to_RxFifo(bus, fifoObject):
			print("%s  PY  WARNING: No stimulus generated as input buffer overflow (level=%d max=%d) on bus %d at %1.3f%s"%(RED,
				ingressBufferFillLevel[bus], comCfg.ingressBuffer[bus]["fifoEntries"], bus, now/MSTONS, NORM))
			counters['rxOverflow'][bus] += 1
			counters_error += 1
			vcdWriter.change(vcd_error, now, counters_error)
			return

		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		#- - - - - Bring it to the DUT and Scoreboard
		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		global scoreboard
		targets = []
		#in first firmware all frames provided back by egress FIFO 0 independent of format
		fifoHeaderSize = 16+12
		frameInfo = ""
		#print("scorebording: targets=%s  frameTag=%s  frameInfo=%s"%(targets, fifoObject["tag"], frameInfo))
		scoreboard += addToScoreboard(bus, fifoObject["tag"], frameInfo, fifoObject[1], ts, fifoHeaderSize, targets)

"""
	# Initialize meta with 0 and payload with random bytes
	payload = [random.randint(0, 0xff) for _ in range(size)]
	#payload = [0xFF for _ in range(size)]

	# Process payload based on protocol type
	listOfACF = []
	skipFromScoreboard = {}
	if frameType == T1S:  # Ethernet frame processing
		frame_indicator = 3  #ET
		fifoHeaderSize = 4 * 4

		## macDA = [int(x, 16) for x in id.split(':')]
		## etherType = frame[RX_DEF_ENH]["ET"]

		#patch the random payload
		payload += payload[0:2]  #create a 2byte gap and bring first two bytes to the end
		payload[0:2] = [0,0]      #ET gap

		# payload[2:8] = macDA

		# # Set etherType and optional VLAN tag
		## if frame[RX_DEF_ENH]["VID"] != None:
		# 	vid = frame[RX_DEF_ENH]["VID"] + (frame[RX_DEF_ENH]["PCP"] << 12)
		# 	payload[14:18] = [0x81, 0x00, vid>>8, vid&0xff]
		# 	etpos = 18
		# else:
		# 	vid = 0   #default VLAN of this port
		# 	etpos = 14
		# payload[etpos:etpos+2] = [etherType>>8, etherType&0xff]

		frameTag = f"{bus}>{id}-{vid}"  #will be expanded on demand

		# Insert optional 1722 stream ID
		if frame[RX_DEF_ENH]["SID"] != None:
			if not frame[RX_DEF_ENH]["SID"] in seqNumberCounter:
				seqNumberCounter[frame[RX_DEF_ENH]["SID"]] = random.randint(0, 0xff)
			# Add some IEEE 1722 specific fields (simplified)
			payload[etpos+2] = 0x77  #subtype
			#payload[etpos+3:etpos+5] = #length and format
			payload[etpos+5] = seqNumberCounter[frame[RX_DEF_ENH]["SID"]]  #sequence num
			seqNumberCounter[frame[RX_DEF_ENH]["SID"]] = (seqNumberCounter[frame[RX_DEF_ENH]["SID"]] +1)&0xff
			sid = 0
			for i in range(7,-1,-1):
				payload[etpos+6+7-i] = (frame[RX_DEF_ENH]["SID"] >> (8*i)) & 0xFF
				sid = (sid<<8) + ((frame[RX_DEF_ENH]["SID"] >> (8*i)) & 0xFF)
			frameInfo = f"-S{sid:016x}"
			if "ACF" in frame[RX_DEF_ENH]:
				print("  PY      Add ACFs to frame")
				payload[etpos+2] = 0x82  #NTCF container
				pos = etpos+2 + 12
				length = 0
				for acf in frame[RX_DEF_ENH]["ACF"]:
					#print(acf)
					d, tag, len32, canPayload = assemble_acf_brief(bus, *acf)
					payload[pos:pos+len(d)] = d
					length += len32*4
					pos += len32*4
					listOfACF.append([tag, ".S", canPayload, ts])
				payload[etpos+4] = length & 0xff
				payload[etpos+3] = (length>>8) &0x07
				if frame[RX_DEF_ENH].get("hasException", False):
					t = f"ST-{sid:016x}"
					if t in comCfg.rules[bus]:
						#print(comCfg.rules[bus][t])
						#print(comCfg.streamsTerm)
						skipFromScoreboard = [comCfg.rules[bus][t][0]]   #TODO what happens if we have more targets
						skipFromScoreboard[0]['target'] = comCfg.streamsTerm[skipFromScoreboard[0]['streamTerm']]['targetExceptionPort']
				#print(pos, length, hex(length), length+etpos+12)
				if (length+etpos+12 > size):
					print("  PY      %sWARNING%s: Requested ACF (%d bytes) exceeds the configured frame length of %d bytes"%(YELLOW, NORM, length+etpos+12, size))
					payload = payload[0:size+2]
					listOfACF = []
				#print("listOfACF", listOfACF)
				#print("skipFromScoreboard", skipFromScoreboard)
			#if ACF
		else:
			sid = None
			frameInfo = f"-E{etherType:04x}"
		#comIf_printDump(meta, width=8, prefix="  PY           Gen Meta    |")
		#comIf_printDump(payload, prefix="  PY           Gen Payload |")

	else:  # Standard check for CAN frames
		if frameType in (CCb, CCe):
			frame_indicator = 1
		elif frameType in (FDb, FDe):
			frame_indicator = 2
		else:  #XL
			frame_indicator = 0
		fifoHeaderSize = 7 * 4

		rtr = frame[RX_DEF_ENH].get("RTR", 0)
		brs = frame[RX_DEF_ENH].get("BRS", 0)
		esi = frame[RX_DEF_ENH].get("ESI", 0)
		#print(f"{Colors.GREEN}  PY  Frame bits: RTR = %d, BRS = %d, ESI = %d{Colors.RESET}" %(rtr, brs, esi))

		#generate the header
		header = [0] * 3
		header[0] = (frame_indicator << 30) + id
		header[1] = (rtr << 19) + (brs << 18) + (esi << 17)
		header[2] = 0
		meta = meta + header

		frameTag = frameTagString(bus, frameType, id)
		frameInfo = ""
		#comIf_printDump(meta, "CAN  Meta + Header", width=8, prefix="  PY  ")
		#comIf_printDump(payload, "Generated CAN frame", prefix="  PY  ")

	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	#- - - - - Bring it to the DUT and Scoreboard
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	#if FIFO is full, discard the frame
	if (ingressBufferFillLevel[bus] >= comCfg.ingressBuffer[bus]["fifoEntries"]):
		print("%s  PY  WARNING: No stimulus generated as input buffer overflow (level=%d max=%d) on bus %d at %1.3f%s"%(RED,
			ingressBufferFillLevel[bus], comCfg.ingressBuffer[bus]["fifoEntries"], bus, now/MSTONS, NORM))
		counters['rxOverflow'][bus] += 1
		counters_error += 1
		vcdWriter.change(vcd_error, now, counters_error)

	#bring to simulation
	else:
		global scoreboard

		addr = buffer['fifoBaseAddr'] + buffer['fifoEntrySize'] * ingressBufferPage[bus]
		ingressBufferPage[bus] = (ingressBufferPage[bus]+1) % buffer["fifoEntries"]

		#print("  PY  meta     ra.write address: %04x"%addr)
		addr = ra.write(addr, 32, meta)
		#print("  PY  payload  ra.write address: %04x"%addr)
		addr = ra.write(addr, 8, payload)
		ra.markIngressValid(bus)

		#Check forwarding config to remember the frame for automatic checking
		#print("\n  PY    Check if required for scoreboard  type:", frameType, " tag:", frameTag, " info:", frameInfo)
		#print(comCfg.rules[bus])
		#print(comCfg.rules[bus].keys())
		#print(comCfg.egressBuffer)
		targets = []
		if frameTag+"#ET" in comCfg.rules[bus]:
			tag = f'ET{comCfg.rules[bus][frameTag+"#ET"]}-{etherType:04x}'
			#print(">>ET", comCfg.rules[bus][frameTag+"#ET"], tag)
			if tag in comCfg.rules[bus]:
				#print(">>>", comCfg.rules[bus][tag])
				targets += comCfg.rules[bus][tag]
		if (frameTag+"#ST" in comCfg.rules[bus]) and sid != None:
			tag = f"ST-{sid:016x}"
			#print(">>ST", comCfg.rules[bus][frameTag+"#ST"], tag)
			if tag in comCfg.rules[bus]:
				#print(">>>ST>>>", skipFromScoreboard, bus, comCfg.rules[bus][tag])
				for t in comCfg.rules[bus][tag]:
					if not "streamTerm" in t or t['streamTerm'] == None:
						targets.append(t)
				if (skipFromScoreboard):
					targets += skipFromScoreboard
				for t in comCfg.rules[bus][tag]:
					if t["streamTerm"] != None:
						#print(comCfg.streamsTerm)
						idx = comCfg.streamsTerm[t["streamTerm"]]["vPortIndex"]
						print("  PY      Target stream Termination %d -> %d of %d ACF containers"%(t["streamTerm"],idx, len(listOfACF)))
						#print(listOfACF)
						for a in listOfACF:
							a[0] = f"{idx}>{a[0]}"
							#print("--",*a)
							scoreboard += addToScoreboard(idx, *a, vPortIdx=t["streamTerm"]+0x60)
				#for
		#if
		#print("targets", targets)
		scoreboard += addToScoreboard(bus, frameTag, frameInfo, payload, ts, fifoHeaderSize, targets)
"""
#def ingressStoreInBuffer


#******************************************************************************
#***** Egress side model ******************************************************
#******************************************************************************
def egressReadOutBuffer(now, bus):
	global egressBufferPage
	if comIf.VERBOSE&0x80 or 1:
		print(f"{BLUE}  PY  {now/MSTONS:8.3f} < egressReadOutBuffer({bus}){NORM}  page={egressBufferPage[bus]}")

	#get frame from simulation side
	buffer = comCfg.egressBuffer[bus]
	addr = buffer['fifoBaseAddr'] + buffer['fifoEntrySize'] * egressBufferPage[bus]
	egressBufferPage[bus] = (egressBufferPage[bus]+1) % buffer["fifoEntries"]

	# analyse meta and header
	header = ra.read(addr, 32, 7)
	print("  PY      bufferAddr=%06x"%(addr))
	comIf_printDump(header, width=8, prefix="  PY      Header |")
	print("  PY      header[0] = %08x"%header[0])
	prot = (header[0] & 0x000f0000) >> 16
	size = header[0] & 0x00000fff
	trunc = (header[0] & 0x00008000) >> 15
	pnr = header[0] >> 24
	tsl = header[2]
	tsh = header[3] & 0xffffff
	ts = tsl + (tsh<<32)
	#print("ts=%1.3f  %d  %08x"%(ts/1000000, tsl, tsl))

	assert prot>=0 and prot<=4, f"Protocol in output FIFO prot={prot} is out of range"
	# T1S
	if prot == 3:
		frameType = T1S
		id = header[1] & 0x1fffffff
		addr += 16
		payload = ra.read(addr, 8, size+2)
	# A CAN variant
	elif prot in [0,1,2]:
		type_fd = (header[4] & 0x80000000) >> 31
		type_cc = (header[4] & 0x40000000) >> 30
		assert (type_fd + type_cc) == 1, f"Unexpected frame type FD={type_fd} CC={type_cc}"
		id = header[4] & 0x1fffffff
		addr += 7*4
		payload = ra.read(addr, 8, size)
		rtr =  (header[5]>>19) & 1
		brs =  (header[5]>>18) & 1
		esi =  (header[5]>>17) & 1

		if prot == 0:
			if type_fd == 0:
				frameType = CCb
			else:
				frameType = FDb
			assert id < (1<<11), f"Too big id {id}/{id:x} for base identifier"
		elif prot == 1:
			if type_fd == 0:
				frameType = CCe
			else:
				frameType = FDe
		else: #if prot == 2:
			frameType = XL
	else:
		assert False, f"Unexpected protocol prot={prot}"
	#if prot
	srcDev = header[0] >> 24
	PN = header[3] >> 24
	assert size <= comCfg.egressBuffer[bus]['fifoEntrySize'], f"Oversized CAN Frame in egress buffer ({bus}) of {size}. fifoEntrySize={comCfg.egressBuffer[bus]['fifoEntrySize']}  addr={addr:08x}"
	if comIf.VERBOSE&0x180:
		print(f"{L_BLUE}  PY  {now/MSTONS:8.3f} egressReadOutBuffer: bus={bus} srcBus={srcDev} addr={addr:08x} id={id}/{id:x} frameType={TYPE_STR[frameType]} size={size}/{size:x}{NORM}")
	#comIf_printDump(payload, "Read payload", prefix="  PY  payload |")

	#Now analyse in format specific manner
	#and check if this frame is expected on this interface
	checkVariants = [""]
	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	if frameType == T1S:
		# Extract MAC addresses and EtherType
		dst_mac = ":".join(["%02x"%i for i in payload[2:8]])
		etherType = (payload[14] << 8) | payload[15]
		frameTag = f"{pnr}>{dst_mac}"
		if etherType == 0x8100:
			vlan_id = (payload[16] << 8) | payload[17]
			etherType = (payload[18] << 8) | payload[19]
			frameTag += f"-{vlan_id}"
		else:
			vlan_id = None
			frameTag += f"-{0}"   #TODO: default VLAN ID expected
		checkVariants.insert(0, f"-E{etherType:04x}")

		print(f"{L_BLUE}  PY  {now/MSTONS:8.3f}   Checking Eth @{addr:04x}  bus={bus} size={size} dst={dst_mac} ET={etherType:04x}{' vlan='+str(vlan_id) if vlan_id != None else ''} TS={tsh:x}_{tsl:08x}{NORM}")
		#comIf_printDump(header[0:4],  width=8, prefix="  PY             check header  |")
		#comIf_printDump(payload, prefix="  PY             check payload |")
		if etherType == 0x22f0:
			pos = 0x10 if vlan_id==None else 0x14
			subtype = payload[pos+0]
			length = ((payload[pos+1]&7)<<8) + payload[pos+2]
			seq = payload[pos+3]

			streamId = "".join(["%02x"%i for i in payload[pos+4:pos+12]])
			frameTag += f"-S{streamId}"
			print(f"  PY             1722 subtype={subtype:02x} streamId={streamId[0:8]}_{streamId[8:]}  length={length:04x}/{length}  seq={seq:02x}/{seq}")
			if (subtype == 0x82) and pnr >= 0x60:   #full ethernet frames from a vPort (streamGen) are unpacked, exceptional once have the physical source port number
				processed = 0
				pos += 12
				#print(processed, length)
				while (processed < length):
					#comIf_printDump(payload[pos:], prefix="  PY             payload |")
					assert payload[pos] == 0x04, f"CAN_BRIEF==04 expected, got {payload[pos]:02x}"
					len32 = payload[pos+1]
					pad = payload[pos+2]>>6
					fdf = "FD" if (payload[pos+2]>>1) & 1 else "CC"
					busid = payload[pos+3]&0x1f
					id = int("".join(["%02x"%i for i in payload[pos+4:pos+8]]), 16)
					data = payload[pos+8:pos+len32*4-pad]
					#print("  PY               %sACF-Decode:"%(BLUE), NORM, "busid:", busid, "len32:", len32, pad, id, len(data)) #, data)
					f = f"{busid}>Id11.{id}.{fdf}.S>{bus}"
					print(f"  PY               Check ACF {f}  len={len(data):x}/{len(data)}")
					check_received_frame(f, data, noTsCheck=True)

					pos += len32*4
					processed += len32*4
					#print(processed, len32)
				#all is checked, we can clean the frameTag
				frameTag = None
				#while over sub ACFs
				#print(processed, length)
				assert (processed == length), "Incorrect length in NTCFS / ACF"

			#generate a copy/paste string for format analysis by scapy
			if 'scapy' in globals():
				ff = str(bytearray(payload[2:]))
				#print(f"ff = {ff}")
				scapy.command(f"ff = {ff}")
				#scapy.command("print(bytes.hex(bytes(ff)))")
				scapy.command("sendp(ff, iface='lo')")

		else: #only ET
			frameTag += f"-E{etherType:04x}"


	else: #CAN
		#print(frameType, protocol_translate[frameType], protocol_rule[protocol_translate[frameType]], protocol_rule[frameType])
		if comIf.VERBOSE&0x80:
			print(f"{RED}  PY  {now/MSTONS:8.3f}   egressReadOutBuffer payload={payload}{NORM}  ts={ts}")
		ide = prot == 1
		frameTag = cfd.scoreboard_frameTag(pnr, id, type_fd, ide, rtr, brs, esi)
		#print(rtr, frameTag)
	#if frameType

	if (frameTag != None):
		if (trunc):
			frameTag += "!T"
		frameTag = f"{ts/100:1.2f}|" + frameTag + ">" + str(bus)
		print(f"  PY           {L_BLUE}Check{NORM} reception of {frameTag}  len={len(payload)}  ts={ts}")
		check_received_frame(frameTag, payload)

	#and show in the bus simulation
	return comIf_txWrite(now+2*ra.TICKFACTOR, bus, 0, frameType, size, vcdFrameName(srcDev,PN))
#def egressReadOutBuffer


def check_received_frame(name, payload, noTsCheck=False):
	expected = name.encode()+" ".encode()+bytes(payload)
	if expected in scoreboard:
		#print("\033[96m✅ Frame matched a sent frame!\033[0m")
		scoreboard.remove(expected)  # Remove the matched frame from the list
	else:
		if (noTsCheck):
			for s in scoreboard:
				n = str(s).find('|')
				if (expected == s[n-1:]):
					#print("expected frame found", name);
					scoreboard.remove(s)
					return
		#if

		print(f"❌ Frame '{name}' with {len(payload)} bytes is not in sent list!")
		global scoreboard_errors
		scoreboard_errors += 1
		# print("The frame")
		# for i, x in enumerate(payload):
		# 	print(f" {x:02x}", end="")
		# 	if (i%16==15) or i==len(payload)-1: print();
		# for j, xx in enumerate(scoreboard):
		# 	p = str(xx).find(' ')
		# 	tag = str(xx)[2:p]
		# 	print("Scoreboard", j, tag, len(xx)-p+1)
		# 	for i, x in enumerate(xx[p-1:]):
		# 		print(f" {x:02x}", end="")
		# 		if (i%16==15) or i==len(xx)-p: print();
#def


#------------------------------------------------------------------------------
def EgressCB(now, bus, idx, ts):
	if comIf.VERBOSE&0x280 or 0:
		print(f"{BLUE}  PY  {now/MSTONS:8.3f} < EgressCB({bus}, {idx}, {ts/MSTONS:1.3f}){NORM}")
	ra.markEgressFree(bus)
#def


#******************************************************************************
#***** Interaction with simulation ********************************************
#******************************************************************************

#------------------------------------------------------------------------------
def feedback(now, signal, index, value):
	#print(f"  PY  \033[35;2mfeedback({now}ns == {now/MSTONS}ms, {signal}, {index}, {value})\033[m")
	if (signal == "inValidCnt"):
		vcdWriter.change(vcd_ingressBuffer[index], now, value)
		ingressBufferFillLevel[index] = value
	elif (signal == "outValidCnt"):
		vcdWriter.change(vcd_egressBuffer[index], now, value)
	elif (signal == "outCntInc"):
		return egressReadOutBuffer(now, index)
	elif (signal == "perf"):
		vcdWriter.change(vcd_performance, now, value)
	elif (signal == "extIngressProcessed"):
		cfd.release_RxFifo_entry(index)
	return 0;
#feedback


#------------------------------------------------------------------------------
def tick(now):
	#print(f"  PY  \033[35mtick({now}ns == {now/MSTONS}ms)\033[m")
	assert events.pending() > 0, f"No events pending when call tick({now})"

	#get the next event round to simulation tick time
	tEvent, f, a = events.getNext()
	assert tEvent == now, \
		f"Call of tick({now}ns) doesn't match to event time {tEvent}ns  delta={now-tEvent}"

	#execute the event function
	f(tEvent, *a)

	#And step forward to next event
	if (events.pending() == 0):
		print(f"{CYAN}  PY  {now/MSTONS:8.3f} > Last Rx stimulus reached{NORM}")
		return 0
	else:
		t = int(events.getNextTime())
		if (t == now):
			#this covers multiple event at the same time tick
			return tick(now)
		else:
			return t
#tick


#------------------------------------------------------------------------------
def main(now):
	# print("PY main:  argv =", sys.argv)

	# print("PY main:              [base,         size]   base       size")
	# print("PY main:  CODERAM   = %20s - 0x%08x 0x%06x"%(ra.CODERAM, ra.CODERAM[0], ra.CODERAM[1]))
	# print("PY main:  DATARAM   = %20s - 0x%08x 0x%06x"%(ra.DATARAM, ra.DATARAM[0], ra.DATARAM[1]))
	# print("PY main:  BUFRAMIN  = %20s - 0x%08x 0x%06x" %(ra.BUFRAMIN, ra.BUFRAMIN[0], ra.BUFRAMIN[1]))
	# print("PY main:  BUFRAMOUT = %20s - 0x%08x 0x%06x" %(ra.BUFRAMOUT, ra.BUFRAMOUT[0], ra.BUFRAMOUT[1]))

	# # Meta and Header data for ACF frame
	# # Frame with VLAN, 2 byte aligned 	 #  DA                       DA                       SA                       SA,EType
	# ra.write(ra.DATARAM[0] + 0x10000, 8, [	0x00, 0x00, 0x0e, 0x1e,  0x2e, 0x3e, 0x4e, 0x5e,  0x06, 0x16, 0x26, 0x36,  0x46, 0x56, 0x81, 0x00,
	# 									 #  VLANID,Etype             Stype,sv,version,r,data_len,seq_num[7:0]
	# 										0x00, 0x10, 0x22, 0xf0,  0x82, 0x00, 0x00, 0x01,
	# 									 #	stream_id[31:0]          stream_id[63:32]
	# 										0x12, 0x34, 0x56, 0x78,  0x9a, 0xbc, 0xde, 0xf0,
	# 									])

	print("  PY  ------------ PY-INIT-Start ---------------")
	global events, vcdWriter
	global comCfg
	#Place a magic number at first buffer word. The C program checks
	#this to ensure that C and PY code runs in simulation.
	if not ra.write(ra.BUFRAMIN[0]+0, 32, [0x71829304, 0xabbadead]):
		return -1

	#Configuration from json as defined for testcase
	#VERBOSE: 0=silent, 1=base, 2=tables, 4=ingress, 8=ingress-entries
	#         0x10=streamGen, 0x20=streamTerm
	comCfg = raConfig(configJsonFile, VERBOSE=1 | 1 | 1)
	#sys.exit(0)

	#bring the sanity check values to the C-Code side
	ra.write(ra.BUFRAMIN[0]+0x40, 32, comCfg.sanityValues)

	#setup the bus simulator
	events, vcdWriter = comIf_setup("tmp/dump.vcd", comCfg, rxStimulusDef,
						tickFactor=ra.TICKFACTOR,
						rxCB=ingressStoreInBuffer, txCB=EgressCB) #, verbose=0x188)
	assert events.pending() > 0, "No events generated for CAN input stimulus"

	#register signals for VCD
	global vcd_ingressBuffer, vcd_egressBuffer, vcd_performance, vcd_error
	vcd_ingressBuffer = [None] * comCfg.maxIngress
	vcd_egressBuffer = [None] * comCfg.maxEgress

	for i in range(comCfg.maxIngress):
		vcd_ingressBuffer[i] = vcdWriter.register_var('dut', 'bufIn(%d)'%(i), 'integer', size=4)
		vcdWriter.change(vcd_ingressBuffer[i], 0, 0)

	for i in range(comCfg.maxEgress):
		vcd_egressBuffer[i] = vcdWriter.register_var('dut', 'bufOut(%d)'%(i), 'integer', size=4)
		vcdWriter.change(vcd_egressBuffer[i], 0, 0)

	vcd_performance = vcdWriter.register_var('dut', 'perf', 'reg', size=32)
	vcdWriter.change(vcd_performance, 0, 0)
	vcd_error = vcdWriter.register_var('dut', 'error', 'integer', size=32)
	vcdWriter.change(vcd_error, 0, 0)

	#register additional counters
	global counters_error
	counters_error = 0
	counters['rxOverflow'] = [0] * comCfg.maxIngress
	counters['txErrChkSum'] = [0] * comCfg.maxEgress
	counters['txErrPN'] = [0] * comCfg.maxEgress

	#and start the processing on DUT
	t = events.getNextTime()
	assert (t > now), "First frame is not in the future"

	#Python side CFD RxFifo buffer, verilog has only the current entry
	if cfd.init():
		return -1
	if etnd.init():
		return -1

	print("  PY  ------------ PY-INIT-DONE ---------------")
	return int(t);
#main


#------------------------------------------------------------------------------
def cleanup(now):
	global scoreboard
	ret = scoreboard_errors

	comIf_flushWriter(now)
	print(f"  PY  {now/MSTONS:8.3f} ms - Done.")

	if 'scapy' in globals():
		scapy.command("quit")
		scapy.join()

	#comIf_printCounters()

	if len(scoreboard) != 0:
		i = 0;
		for s,c in expectedFramesNotTransmitted:
			#print("Expected not transmit:", s, c, len(s))
			expected = s.encode()
			sendX = []
			for pending in scoreboard:
				#for expected discard frames the timestamps are ignored
				p = str(pending).find('|')
				if (expected == pending[p-1:len(expected)+p-1]):
					#print("expected frame lost found", s);
					expectedFramesNotTransmitted[i][1] -= 1
				else:
					sendX.append(pending)
			scoreboard = sendX
			i += 1

		for s,c in expectedFramesNotTransmitted:
			if (c != 0):
				print(f"❌ Frame '{s}' expected to be discarded {c} times but not found in pending transmit list")
				ret += 1

		for pending in scoreboard:
			n = str(pending).find(' ')
			#print(n, len(pending), pending)
			print(f"❌ Frame '{str(pending)[2:n]}' with {len(pending)-n} bytes has not been transmitted")
			ret += 1
	#if
	return ret

	# #check content of ingress buffers
	# for b in comCfg.ingressBuffer:
	# 	print(b)
	# 	for i in range(b["fifoEntries"]):
	# 		a = b["fifoBaseAddr"]+i*b["fifoEntrySize"]
	# 		print("  I #%d %04x = %08x"%(i, a, ra.read(a, 32, 1)[0]))

	# #check content of egress buffers
	# for b in comCfg.egressBuffer:
	# 	print(b)
	# 	for i in range(b["fifoEntries"]):
	# 		a = b["fifoBaseAddr"]+i*b["fifoEntrySize"]
	# 		print("  E #%d %04x = %08x"%(i, a, ra.read(a, 32, 1)[0]))

	# print("\nPY main:  DATARAM ACFHEAD content:")
	# dram_acfhead = ra.read(ra.DATARAM[0] + 0x10000, 32, 16)
	# print("PY main:    Buffer by word")
	# print("PY main:    Address    word / byte address")
	# for i in range(16):
	# 	if i%4 == 0:
	# 		print("PY main:    %08x   %04x / %04x   %08x" % (ra.DATARAM[0] + 0x10000 + i, i, i*4, dram_acfhead[i]), end="")
	# 	elif i%4 == 3:
	# 		print(" %08x"%dram_acfhead[i], end="\n")
	# 	else:
	# 		print(" %08x"%dram_acfhead[i], end="")

	# print("\nPY main:  BUFRAMIN FIFO content:")
	# bramin = ra.read(ra.BUFRAMIN[0], 32, 32)
	# print("PY main:    Buffer by word")
	# print("PY main:    Address    word / byte address")
	# for i in range(32):
	# 	if i%4 == 0:
	# 		print("PY main:    %08x   %04x / %04x   %08x" % (ra.BUFRAMIN[0] + i, i, i*4, bramin[i]), end="")
	# 	elif i%4 == 3:
	# 		print(" %08x"%bramin[i], end="\n")
	# 	else:
	# 		print(" %08x"%bramin[i], end="")

	# print("\nPY main:  DATARAM ETH_OUT content:")
	# dram_eth = ra.read(ra.DATARAM[0] + 0x18000, 32, 32)
	# print("PY main:    Buffer by word")
	# print("PY main:    Address    word / byte address")
	# for i in range(32):
	# 	if i%4 == 0:
	# 		print("PY main:    %08x   %04x / %04x   %08x" % (ra.DATARAM[0] + 0x18000 + i, i, i*4, dram_eth[i]), end="")
	# 	elif i%4 == 3:
	# 		print(" %08x"%dram_eth[i], end="\n")
	# 	else:
	# 		print(" %08x"%dram_eth[i], end="")
#cleanup
