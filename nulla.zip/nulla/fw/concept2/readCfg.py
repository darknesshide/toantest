import json
import ra
#import struct
import sys
import re

from moduleComif import normMAC
from comIf_rscanfd import scoreboard_frameTag as cfd_scoreboard_frameTag

DEFINE_VPORT_MAX = 32

DEFINE_INGRESS_CFD_CNT   = 16
DEFINE_INGRESS_XL_CNT    = 0
DEFINE_INGRESS_ETH_CNT   = 10
DEFINE_INGRESS_CPU_CNT   = 58
DEFINE_INGRESS_VPORT_CNT = 32

DEFINE_INGRESS_FIRST_CFD   =  0                             #Physical map IDA 0~15
DEFINE_INGRESS_FIRST_XL    = 16 + DEFINE_INGRESS_FIRST_CFD  #Physical map IDA ???
DEFINE_INGRESS_FIRST_ETH   =  0 + DEFINE_INGRESS_FIRST_XL   #Physical map IDA 16~25
DEFINE_INGRESS_FIRST_CPU   = 10 + DEFINE_INGRESS_FIRST_ETH  #Physical map CPU-In-Handler
DEFINE_INGRESS_FIRST_VPORT = 58 + DEFINE_INGRESS_FIRST_CPU  #Physical map vPOrt-In-Handler
DEFINE_INGRESS_MAX =         32 + DEFINE_INGRESS_FIRST_VPORT
#SUM                        116


DEFINE_EGRESS_MAX = 32


DEFINE_EGRESS_FIRST_STREAM  = 190   #artificial target number above the physical range (same for CAN/ETH even if different function)


SIZEOF_s_raConfig = 7*4   #without SIZEOF_s_fifoConfig and SIZEOF_s_vPortConfig

SIZEOF_s_fifoConfig = 2*4

SIZEOF_s_vPortConfig = (1+(DEFINE_VPORT_MAX//2)+1) * 4

SIZEOF_s_egressConfig = 2*4

SIZEOF_s_streamGen =  5 * 4    #template not included
SIZEOF_s_streamTerm = 6 * 4 + 32

SIZEOF_s_ingressConfig = (2+3+1)*4



canIdTypeValue  = {'CC':1, 'FD':2, 'CCFD':3}
#canIfTxPduCanIdType  = {'CBFF':2, 'CEFF':3, 'FBFF':4, 'FEFF':5, 'XL':6}

RED = "\033[31m"
L_RED = "\033[91m"
GREEN = "\033[32m"
L_GREEN = "\033[92m"
BLUE = "\033[34m"
L_BLUE = "\033[94m"
MAGENTA = "\033[35m"
L_MAGENTA = "\033[95m"
CYAN = "\033[36m"
L_CYAN = "\033[96m"
YELLOW = "\033[33m"
L_YELLOW = "\033[93m"
WHITE = "\033[37;1m"

NORM = "\033[m"

#--------------------------------------------------------------------------
def toInt(val):
	if (type(val) == bool):
		val = 1 if val else 0
	elif (type(val) != int):
		val = eval(val)
	return val


#--------------------------------------------------------------------------
def bswap_32(val):
	return  ((val & 0xff000000) >> 24) | ((val & 0x00ff0000) >> 8) | \
	        ((val & 0x0000ff00) <<  8) | ((val & 0x000000ff) << 24)

#--------------------------------------------------------------------------
def bswap_64(val):
	return (bswap_32(val & 0xffffffff) << 32) | bswap_32((val>>32) & 0xffffffff)

#--------------------------------------------------------------------------
def mergeBytes(val):
	if len(val) == 1:
		return (val[0]<<0)
	elif len(val) == 2:
		return (val[1]<<8) + (val[0]<<0)
	elif len(val) == 3:
		return (val[2]<<16) + (val[1]<<8) + (val[0]<<0)
	elif len(val) == 4:
		return (val[3]<<24) + (val[2]<<16) + (val[1]<<8) + (val[0]<<0)
	else:
		assert False, f"len(val)={len(val)}"

#--------------------------------------------------------------------------
def normalise_templateData(this):
	data = []
	for d in this["templateData"]:
		if "data8" in d:
			l = re.split(":| +|,", d["data8"])
			#print(l)
			n = [int(s,16) for s in filter(len,l)]
			#print(len(n), "--", n, "--", [s[2:] for s in list(map(hex, n))])
			data += n
		elif "data16" in d:
			l = re.split(":| +|,", d["data16"])
			#print(l)
			n = [int(s,16) for s in filter(len,l)]
			#print(len(n), "--", n)
			b = sum([[s>>8, s&0xff] for s in n], [])
			#print(len(b), "--", b, "--", [s[2:] for s in list(map(hex, b))])
			data += b
		elif "data32" in d:
			l = re.split(":| +|,", d["data32"])
			#print(l)
			n = [int(s,16) for s in filter(len,l)]
			#print(len(n), "--", n)
			b = sum([[(s>>24)&0xff, (s>>16)&0xff, (s>>8)&0xff, s&0xff] for s in n], [])
			#print(len(b), "--", b, "--", [s[2:] for s in list(map(hex, b))])
			data += b
		else:
			assert False, "Expect data8, data16, data32 in templateData to define a template"
	#for
	#print(len(data), "--", data)
	assert len(data)%4==0, f"Template data shall have multiple of 4 bytes. Got {len(data)} bytes"
	this['templateData'] = data


#--------------------------------------------------------------------------
class raConfig:
	raConfigBaseAddr = 0
	#rxPduCfgBaseAddr = 0
	bufferInBaseAddr = None
	bufferOutBaseAddr = None
	#virtualBufferAddr = None

	canBitrateArbitration = 500
	canBitrateData = 1000
	xlBitrateArbitration = 500
	xlBitrateData = 2000
	ethPortSpeed = 2500

	#collect the next free address of RAM segments
	ramMap = {}
	ingressNameMap = {}
	egressNameMap = {}

	#the configuration collection
	maxIngress = 0
	maxEgress = 0
	egressBuffer = []

	rules = []

	jsonIssue = 0
	VerboseWarning = True #False

	# streamsGen = []
	# streamGenHandles = 0
	# streamsTerm = []
	# streamTermHandles = 0
	# mapFifoToStream = {}

	#for C-side sanity check
	sanityValues = [DEFINE_INGRESS_FIRST_XL, DEFINE_INGRESS_FIRST_ETH, DEFINE_INGRESS_MAX, DEFINE_VPORT_MAX,
	                DEFINE_EGRESS_MAX, DEFINE_EGRESS_FIRST_STREAM, DEFINE_INGRESS_FIRST_VPORT
	]



	#--------------------------------------------------------------------------
	def init_raConfig_base(self, cfgThis, raConfigAddr):
		cfdIngressEnable = 0
		ethIngressEnable = 0
		for ingress in cfgThis["ingress"]:
			comIf, channel, _ = self.ingressNameMap[ingress['name']]
			#print(comIf, channel)
			if (comIf == "CFD"):
				cfdIngressEnable += 1<<channel
			if (comIf == "ETH"):
				ethIngressEnable += 1<<channel

		self.maxStreamGen = 0
		if "streamGenerate" in cfgThis:
			sg_size = 4*len(cfgThis["streamGenerate"])
			for idx, sg in enumerate(cfgThis["streamGenerate"]):
				assert "name" in sg, f"No 'name' in streamGenerate definition #{idx} found."
				s = "".join([c for c in sg['name'] if not c.isdigit()])
				i = toInt("".join([c for c in sg['name'] if c.isdigit()]))
				assert s in ["SG"], f"streamGenerate name shall indicate the interface type 'SG'. Got '{s}'"
				assert not sg['name'] in self.egressNameMap, f"Multiple definition of {sg['name']}"
				self.egressNameMap[sg['name']] = [s, i, i+DEFINE_EGRESS_FIRST_STREAM]

				normalise_templateData(sg)

				self.maxStreamGen += 1
				#print("%d/%x + %d/%x + %d/%x = %d/%x"%(sg_size, sg_size, SIZEOF_s_streamGen,SIZEOF_s_streamGen, len(sg["templateData"]), len(sg["templateData"]), 0, 0))
				sg_size += SIZEOF_s_streamGen + len(sg["templateData"])
		else:
			sg_size = 0
		#print("%d/%x"%(sg_size,sg_size))

		self.maxStreamTerm = 0
		if "streamTerminate" in cfgThis:
			st_size = 0
			for idx, st in enumerate(cfgThis["streamTerminate"]):
				assert "name" in st, f"No 'name' in streamTerminate definition #{idx} found."
				s = "".join([c for c in st['name'] if not c.isdigit()])
				i = toInt("".join([c for c in st['name'] if c.isdigit()]))
				assert s in ["ST"], f"streamTerminate name shall indicate the interface type 'ST'. Got '{s}'"
				assert not st['name'] in self.egressNameMap, f"Multiple definition of {st['name']}"
				self.egressNameMap[st['name']] = [s, i, i+DEFINE_EGRESS_FIRST_STREAM]

				self.maxStreamTerm += 1
				# #print("%d/%x + %d/%x + %d/%x = %d/%x"%(sg_size, sg_size, SIZEOF_s_streamGen,SIZEOF_s_streamGen, len(sg["templateData"]), len(sg["templateData"]), 0, 0))
				st_size += SIZEOF_s_streamTerm
		else:
			st_size = 0
		#print("%d/%x"%(sg_size,sg_size))

		#the linked tables depend on the sizes of the fields before
		#always in common area
		ptr_egress = raConfigAddr + SIZEOF_s_raConfig \
			+ SIZEOF_s_fifoConfig \
			+ SIZEOF_s_vPortConfig \
			+ DEFINE_INGRESS_MAX \
			+ (DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH)*2
		#always in common area
		ptr_streamGen = ptr_egress + self.maxEgress * SIZEOF_s_egressConfig
		ptr_streamTerm = ptr_streamGen + sg_size
		#in FFI split area
		ptr_ingress = ptr_streamTerm + st_size

		#assemble the structure
		d = [0] * 7
		d[0] = self.maxIngress+(self.maxEgress<<8)+(self.maxStreamGen<<16)
		d[1] = cfdIngressEnable
		d[2] = ethIngressEnable
		d[3] = ptr_ingress
		d[4] = ptr_egress
		d[5] = ptr_streamGen
		d[6] = ptr_streamTerm


		#provide result
		if self._VERBOSE>0:
			print("%sraConfig ------------- %06x:%s %08x %08x %08x %s%08x %s%08x%s  #maxIngress=%d (%d total) maxEgress=%d"%(
				L_BLUE, raConfigAddr, NORM, d[0], d[1], d[2], L_CYAN, d[3], YELLOW, d[4], NORM,
		 		self.maxIngress, DEFINE_INGRESS_MAX, self.maxEgress))
			print("                       %06x: %s%08x %08x%s                             #maxStreamGen=%d maxStreamTerm=%d"%(
				raConfigAddr+5*4, L_MAGENTA, d[5], d[6], NORM,
		 		self.maxStreamGen, self.maxStreamTerm))
		#sys.exit()
		return d, raConfigAddr + SIZEOF_s_raConfig, ptr_ingress, ptr_egress, ptr_streamGen, ptr_streamTerm
	#def


	#--------------------------------------------------------------------------
	def init_streamGenerate(self, streamGenerate, raConfigAddr):
		#print("raConfigAddr", hex(raConfigAddr))
		d = []
		ptr = [0] * len(streamGenerate)
		addr = raConfigAddr + len(streamGenerate)*4
		boAddr = self.ramMap["bufferOut"]
		for idx, sg in enumerate(streamGenerate):
			ptr[idx] = addr
			#print(sg)
			assert "relatesToRam" in sg
			assert sg["relatesToRam"] in self.ramMap, f"Cannot find '{sg['relatesToRam']}' list of usable RAMs {list(self.ramMap.keys())}"
			assert "bufferSize" in sg
			bufferAddr = self.ramMap[sg["relatesToRam"]]
			bufferSize = toInt(sg["bufferSize"])
			assert bufferSize%4==0
			self.ramMap[sg["relatesToRam"]] += bufferSize

			assert "patchDataLengthPos" in sg
			assert sg["patchDataLengthPos"] < len(sg["templateData"])-4
			assert sg["patchDataLengthPos"]%4 == 0
			maxFrameSize = sg.get("maxFrameSize", 1)
			assert maxFrameSize >= 1 and maxFrameSize <= 2000, f"Only frame sizes in range 1..2000 are allowed. Got {maxFrameSize}."
			to =  int(sg.get("txTimeout", 0) * 1000)
			assert to >= 0 and to <= 50000, f"Only timeouts in range 0..500000us are allowed. Got {to}."
			if (to%200 != 0):
				if self.VerboseWarning:
					print("%sWARNING: Stream Generation timeout granularity is 200 us. Number %1.1fms is rounded to %1.1fms.%s"%(L_YELLOW, to/1000, (to+199)//200*200/1000, NORM))
				to = (to+199)//200*200
				self.jsonIssue += 1
			maxContainers = sg.get("maxContainers", 250)
			assert maxContainers >= 0 and maxContainers <= 250, f"maxContainers shall be in range 1..250. Got {maxContainers}."

			assert "Targets" in sg
			assert type(sg["Targets"]) == str, f"Expect a string listing all targets. Got '{sg['Targets']}' of {type(sg['Targets'])}."
			tg = [x for x in re.split(" +|,", sg["Targets"]) if x]
			assert len(tg) <= 8
			comment = ""
			tgVal = [0xff] * 8
			i = 0
			for t in tg:
				if not t in self.egressNameMap:
					if self.VerboseWarning:
						print("%sWARNING: Target '%s' has no definition. Removed from target list%s"%(L_YELLOW, t, NORM))
					self.jsonIssue += 1
					continue
				assert self.egressNameMap[t][0] in ["ETH", "CPU"], f"Stream generation can only send to CPU and ETH targets. Got {t}."
				comment += ","+t
				tgVal[i] = self.egressNameMap[t][2]
				i += 1
			#tNames.sort()
			#print(tgVal)

			d0= len(d)
			d.append(((sg["patchDataLengthPos"]//4)<<8) + len(sg["templateData"]))
			d.append((maxContainers<<24) + (to//200<<16) + maxFrameSize)
			d.append(mergeBytes(tgVal[0:4]))    # .targets
			d.append(mergeBytes(tgVal[4:8]))
			d.append(bufferAddr)

			##add the template data (byte array) in M0 the meta data offset is preset in 2-complement
			m0 = mergeBytes(sg["templateData"][0:4])
			assert m0 & 0xff00ffff == 0, f"Unexpected bits set in M0 of template. Got {hex(m0)}."
			m0 +=  (idx + DEFINE_EGRESS_FIRST_STREAM) << 24  #meta.ipn
			m0 -= 16+2    #size of the meta data
			sg["templateData"][0:4] = [(m0>>0)&0xff, (m0>>8)&0xff, (m0>>16)&0xff, (m0>>24)&0xff]
			for i in range(0, len(sg["templateData"]), 4):
				d.append(mergeBytes(sg["templateData"][i:i+4]))
				#print("template", i, hex(mergeBytes(sg["templateData"][i:i+4])),
				#	[hex(sg["templateData"][j]) for j in range(i,i+4)] )

			if self._VERBOSE&0x10:
				print("%sstreamGen[%02d]    %06x:%s %08x %08x %08x %08x  #template=%d/%x patch=%d  maxSize=%d maxContainer=%d to=%1.1fms(%d/%x) -> %s"%(
					MAGENTA, idx, addr, NORM,
					d[d0+0], d[d0+1], d[d0+2], d[d0+3],
					len(sg["templateData"]), len(sg["templateData"]), sg["patchDataLengthPos"]*4, maxFrameSize, maxContainers, to/1000, to//200, to//200,
					comment.strip(",")
				))
				print("                 %06x: %08x                             #buffer=%06x size=%d/%x"%(
					addr+16, d[d0+4], bufferAddr, bufferSize, bufferSize))
				for i in range(0, len(sg["templateData"]), 16):
					print("   template +%03x %06x: "%(i, addr+SIZEOF_s_streamGen+i), end="")
					for j in range(0, 16):
						if i+j < len(sg["templateData"]):
							print(" %02x"%(sg["templateData"][i+j]), end="")
					print()

			addr += SIZEOF_s_streamGen + len(sg["templateData"])
			#print("next", hex(addr), hex(SIZEOF_s_streamGen + len(sg["templateData"])))
		#for
		if self._VERBOSE&0x10:
			print("%sstreamGen        %06x:%s"%(L_MAGENTA, raConfigAddr, MAGENTA), end="")
			for i, p in enumerate(ptr):
				print(" %08x"%(p), end="")
			print(NORM)

		if self._VERBOSE>0:
			print("streamGen      at %06x..%06x with %05x/%d bytes (%d streams)"%(raConfigAddr, addr, len(d)*4, len(d)*4, len(streamGenerate)))
			print("streamBuffer   at %06x..%06x with %05x/%d bytes"%(boAddr, self.ramMap["bufferOut"], self.ramMap["bufferOut"]-boAddr, self.ramMap["bufferOut"]-boAddr))

		d = ptr + d
		assert len(d)*4 == addr-raConfigAddr
		return d, addr
	#def


	#--------------------------------------------------------------------------
	def init_streamTerminate(self, streamTerminate, raConfigAddr):
		#print("raConfigAddr", hex(raConfigAddr))
		d = []
		addr = raConfigAddr
		for idx, st in enumerate(streamTerminate):

			exceptionTarget = st.get("exceptionTarget", "")
			if not exceptionTarget in self.egressNameMap:
				if self.VerboseWarning:
					print("%sWARNING: Target '%s' has no definition. Removed from target list%s"%(L_YELLOW, exceptionTarget, NORM))
				self.jsonIssue += 1
				exceptionTarget = ["", -1, 255]
			else:
				assert self.egressNameMap[exceptionTarget][0] in ["ETH", "CPU"], f"Exceptional target of stream termination should be CPU or ETH target. Got {exceptionTarget}."
				exceptionTarget = self.egressNameMap[exceptionTarget]

			containerTarget = st.get("containerTarget", "")
			if not containerTarget in self.egressNameMap:
				if self.VerboseWarning:
					print("%sWARNING: Target '%s' has no definition. Removed from target list%s"%(L_YELLOW, containerTarget, NORM))
				self.jsonIssue += 1
				containerTarget = ["", -1, 255]
			else:
				assert self.egressNameMap[containerTarget][0] in ["CPU"], f"ACF container target of stream termination should be CPU target. Got {containerTarget}."
				containerTarget = self.egressNameMap[containerTarget]

			assert "busIdTranslation" in st, "busIdTranslation is a mandatory field."
			busIdTranslation = [255] * 32
			for bt in st["busIdTranslation"]:
				#print(bt)
				bus_id = toInt(bt)
				assert bus_id >= 0 and bus_id < 32, f"Bus Id in 'busIdTranslation' shall be an integer in range 0..31. Got {bt}"
				to = st["busIdTranslation"][bt]
				if to == "": continue
				if not to in self.egressNameMap:
					if self.VerboseWarning:
						print("%sWARNING: Target '%s' has no definition. Removed from busIdTranslation list%s"%(L_YELLOW, to, NORM))
					self.jsonIssue += 1
				else:
					assert self.egressNameMap[to][0] in ["vPort"], f"busIdTranslation can only target vPorts. Got {to}."
					busIdTranslation[bus_id] = self.egressNameMap[to][1]
			#for
			#print("exceptionTarget", exceptionTarget, " containerTarget", containerTarget, " busIdTranslation", busIdTranslation)

			d.append(0);   #s_ethAction.confirmationReq
			d.append(0xffffff00 + exceptionTarget[2])
			d.append(0xffffffff)
			d.append(0);   #s_ethAction.confirmationReq
			d.append(0xffffff00 + containerTarget[2])
			d.append(0xffffffff)
			for i in range(0, len(busIdTranslation), 4):
				d.append(mergeBytes(busIdTranslation[i:i+4]))
				#print(busIdTranslation[i:i+4])
			#print(d)

			if self._VERBOSE&0x20:
				print("%sstreamTerm[%02d]   %06x:%s %08x %08x %08x           #except=%d"%(
					L_MAGENTA, idx, addr, NORM,
					d[0], d[1], d[2],
					exceptionTarget[2]
				))
				print("                 %06x: %08x %08x %08x           #container=%d"%(
					addr+12, d[3], d[4], d[5], containerTarget[2]))
				for i in range(0, 8, 4):
					print("                 %06x: %08x %08x %08x %08x  #%d~%d"%(
						addr+6*4+i*4, d[i+6], d[i+7], d[i+8], d[i+9],
						i*16, i*16+15
					))
			addr += SIZEOF_s_streamTerm
		#for

		if self._VERBOSE>0:
			print("streamTerm     at %06x..%06x with %05x/%d bytes (%d streams)"%(raConfigAddr, addr, len(d)*4, len(d)*4, len(streamTerminate)))

		assert len(d)*4 == addr-raConfigAddr
		return d, addr
	#def


	#--------------------------------------------------------------------------
	def init_ingressFifo(self, cfgThis, raConfigAddr):
		assert "relatesToRam" in cfgThis
		assert cfgThis["relatesToRam"] in self.ramMap, f"Cannot find '{cfgThis['relatesToRam']}' list of usable RAMs {list(self.ramMap.keys())}"
		assert "size" in cfgThis

		#assemble the structure
		d = [0] * 2
		d[0] = self.ramMap[cfgThis["relatesToRam"]]
		d[1] = size = toInt(cfgThis["size"])

		if self._VERBOSE&2: print("%s ingressFIFO           %06x:%s %08x %08x                    #base=%06x size=%04x/%d"%(
			L_BLUE, raConfigAddr, NORM, d[0], d[1],
			d[0], d[1], d[1]))

		#update internal variables
		self.ramMap[cfgThis["relatesToRam"]] += size

		#provide result
		if self._VERBOSE>0:
			print("ingressFifo    at %06x..%06x with %05x/%d bytes"%(d[0], d[0]+size, size, size))
		assert d[1] % 4 == 0, f"ingressFifo size={size} needs multiple of 4 bytes"
		assert SIZEOF_s_fifoConfig == len(d)*4, f"SIZEOF_s_fifoConfig={SIZEOF_s_fifoConfig} != {len(d)}"
		return d, raConfigAddr+SIZEOF_s_fifoConfig
	#def


	#--------------------------------------------------------------------------
	def init_vPortFifo(self, cfgThis, raConfigAddr):
		assert "relatesToRam" in cfgThis
		assert cfgThis["relatesToRam"] in self.ramMap, f"Cannot find '{cfgThis['relatesToRam']}' list of usable RAMs {list(self.ramMap.keys())}"
		assert "vPortNumber" in cfgThis
		assert "defaultSize" in cfgThis

		#assemble the structure
		vPortNumber = toInt(cfgThis["vPortNumber"])
		assert DEFINE_VPORT_MAX % 2 == 0
		assert vPortNumber <= DEFINE_VPORT_MAX, f"vPortNumber={vPortNumber} <= {DEFINE_VPORT_MAX}"
		sizes = [toInt(cfgThis["defaultSize"])] * vPortNumber
		sizes += [0] * (DEFINE_VPORT_MAX-vPortNumber)
		size = 0
		for i in range(DEFINE_VPORT_MAX):
			if str(i) in cfgThis:
				sizes[i] = toInt(cfgThis[str(i)])
			size += sizes[i]
			assert sizes[i] % 4 == 0, f"vPortFifo[{i}] size={sizes[i]} needs multiple of 4 bytes"

		d = [0] * (2+DEFINE_VPORT_MAX//2)
		d[0] = self.ramMap[cfgThis["relatesToRam"]]
		d[1] = toInt(cfgThis["vPortNumber"])
		for i in range(0, DEFINE_VPORT_MAX, 2):
			d[i//2+2] = sizes[i] + (sizes[i+1]<<16)

		if self._VERBOSE&2:
			print("%s vPortFIFOs            %06x:%s %08x %08x                    #base=%06x number=%d"%(
				L_BLUE, raConfigAddr, NORM, d[0], d[1],
				d[0], d[1]))
			a = raConfigAddr + 8
			for i in range(0, DEFINE_VPORT_MAX//2, 4):
				print("%s                       %06x:%s %08x %08x %08x %08x  #sizes %d~%d: %d, %d, %d, %d, %d, %d, %d, %d"%(
					L_BLUE, a, NORM, d[i+2], d[i+3], d[i+4], d[i+5],
					i,i+7, d[i+2]&0xffff, d[i+2]>>16, d[i+3]&0xffff, d[i+3]>>16, d[i+4]&0xffff, d[i+4]>>16, d[i+5]&0xffff, d[i+5]>>16))
				a += 4*4
		#VERBOSE

		#update internal variables
		self.ramMap[cfgThis["relatesToRam"]] += size

		#provide result
		if self._VERBOSE>0:
			print("vPortFifos     at %06x..%06x with %05x/%d bytes (%d vPorts are in use)"%(d[0], d[0]+size, size, size, vPortNumber))
		assert SIZEOF_s_vPortConfig == len(d)*4, f"SIZEOF_s_vPortConfig={SIZEOF_s_vPortConfig} != {len(d)}"
		return d, raConfigAddr+SIZEOF_s_vPortConfig
	#def


	#--------------------------------------------------------------------------
	def init_ingressMap(self, cfgThis, raConfigAddr):
		assert DEFINE_INGRESS_MAX%4 == 0, "Number of theoretical ingresses needs multiple of 4"

		#analyse the definition to judge sizes
		self.ingressFFI = []
		self.ingressBusId = {}
		self.ingressOrder = []
		nr2Idx = {}
		self.maxIngressSpread = 0
		for nr, ingress in enumerate(cfgThis):
			comIf, channel, idx = self.ingressNameMap[ingress['name']]
			ffi = toInt(ingress.get("ffiPartition",4))
			assert ffi in [0,1,2,3,4], f"Unexpected ffiPartition={ffi} in {ingress['name']} definition"
			bus_id = toInt(ingress.get("1722BusId", idx))
			#print(nr, "->", comIf, channel, idx, "ffi:", ffi, "bus_id", bus_id)
			nr2Idx[nr] = idx
			self.ingressBusId[nr] = bus_id
			if (idx > self.maxIngressSpread):
				self.maxIngressSpread = idx
			#all defined ingress vPorts are also valid egress for stream termination
			if comIf == "vPort":
				self.egressNameMap[ingress['name']] = ["vPort", channel, channel]  #vPorts from egress side have an own number space

			if comIf in ["CFD", "vPort"]:
				assert comIf != "CFD" or channel < DEFINE_INGRESS_FIRST_ETH, f"channel={channel}"
				assert comIf != "vPort" or channel < DEFINE_INGRESS_MAX-DEFINE_INGRESS_FIRST_VPORT, f"channel={channel}"
				assert not "AcceptanceDefault" in ingress
				assert not "AcceptanceCfg" in ingress
				assert not "1722StreamDefault" in ingress
				assert not "1722StreamCfg" in ingress
				if not "RxPduDefault" in ingress:
					ingress["RxPduDefault"] = {}
				if not "RxPduCfg" in ingress:
					ingress["RxPduCfg"] = []
			elif comIf in ["ETH"]:
				assert comIf == "ETH", f"Ingress {ingress['name']} defines RxPduDefault"
				assert channel < DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH, f"channel={channel}"
				assert not "RxPduDefault" in ingress
				if not "AcceptanceDefault" in ingress:
					ingress["AcceptanceDefault"] = {}
				if not "AcceptanceCfg" in ingress:
					ingress["AcceptanceCfg"] = []
				if not "1722StreamDefault" in ingress:
					ingress["1722StreamDefault"] = {}
				if not "1722StreamCfg" in ingress:
					ingress["1722StreamCfg"] = []
			else:
				assert False, f"Ingress {ingress['name']} has no rule definition."

			self.ingressFFI.append(ffi)   #4 means privileged
		#for
		#print("  ingressFFI       ", self.ingressFFI, len(self.ingressFFI  ))
		#print("  nr2Idx           ", nr2Idx, len(nr2Idx  ))

		#order the pointer as per FFI partition
		for p in [0,1,2,3,4]:
			for i, v in enumerate(self.ingressFFI):
				if (p == v):
					self.ingressOrder.append(i)
		#print("  ingressOrder     ", self.ingressOrder, len(self.ingressOrder))

		# ingressFFIbase = [tableAddr, 0, 0, 0, 0, addr]
		# if 1 in self.ingressFFI:
		# 	ingressFFIbase[1] = d[self.ingressFFI.index(1)] if 1 in self.ingressFFI else ingressFFIbase[0]
		# if 2 in self.ingressFFI:
		# 	ingressFFIbase[2] = d[self.ingressFFI.index(2)] if 2 in self.ingressFFI else ingressFFIbase[1]
		# if 3 in self.ingressFFI:
		# 	ingressFFIbase[3] = d[self.ingressFFI.index(3)] if 3 in self.ingressFFI else ingressFFIbase[2]
		# if 3 in self.ingressFFI:
		# 	ingressFFIbase[4] = d[self.ingressFFI.index(4)] if 4 in self.ingressFFI else ingressFFIbase[3]
		# print("ingressFFIbase", ingressFFIbase)

		#provide result
		order =[0xff] * DEFINE_INGRESS_MAX
		for i, v in enumerate(self.ingressOrder):
			order[nr2Idx[v]] = i
		#print("  order            ", order, len(order))
		self.idx2Channel = [None] * len(nr2Idx)
		for i in range(DEFINE_INGRESS_MAX):
			if order[i]!= 255:
				#print(i, order[i])
				self.idx2Channel[order[i]] = i
		#print("  idx2Channel     ", self.idx2Channel, len(self.idx2Channel))


		d = []
		for i in range(0, DEFINE_INGRESS_MAX, 4):
			d.append(mergeBytes(order[i:i+4]))

		if self._VERBOSE&(2+4+8):
			print("%s ingressMap            %06x:%s"%(L_BLUE, raConfigAddr, NORM), end="")
			for i in range(DEFINE_INGRESS_MAX//4):
				print(" %08x"%(d[i]), end="")
				if (i >= self.maxIngressSpread//4):
					print(" ...", end="")
					break
			print()
		if self._VERBOSE:
			print("ingressMap    ", end="")
			last = 255
			gap = 0
			for i in range(DEFINE_INGRESS_MAX):
				if last==255 and order[i]!= 255:
					print("  %d:%d"%(i, order[i]), end="")
					gap = 1
				elif order[i] != 255:
					print(" %d"%(order[i]), end="")
					if (gap == 3):
						print(" ", end="")
						gap = 0
					else:
						gap += 1
				last = order[i]
			print()


		# if self._VERBOSE:
		# 	for i in range(5):
		# 		size = ingressFFIbase[i+1]- ingressFFIbase[i]
		# 		cnt = len([x for x,val in enumerate(self.ingressFFI) if val==i])
		# 		print("ingress FFI%d   at %06x..%06x with %04x/%d bytes (%s ports using this FFI)"%(
		# 			i, ingressFFIbase[i], ingressFFIbase[i+1], size, size, cnt))
		#sys.exit()
		return d, raConfigAddr + DEFINE_INGRESS_MAX
	#def


	#--------------------------------------------------------------------------
	def init_defaultVlan(self, cfgThis, raConfigAddr):
		assert (DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH)%2 == 0, "Number of theoretical ethernet ports needs multiple of 2"

		vl = [0xfff] * (DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH)
		for idx, ingress in enumerate(cfgThis):
			comIf, channel, _ = self.ingressNameMap[ingress['name']]
			if comIf != "ETH":
				continue
			defaultVlanId = ingress.get("DefaultVlanId", 0xfff)
			#print(idx, "->", comIf, channel, "vid", defaultVlanId)
			assert defaultVlanId >= 0 and defaultVlanId <= 0xffff
			ingress["DefaultVlanId"] = defaultVlanId
			vl[channel] = defaultVlanId
		#for
		d = []
		for i in range(0, len(vl), 2):
			d.append(vl[i] + (vl[i+1]<<16))
		if self._VERBOSE&2:
			print("%s defaultVlanIds        %06x:%s"%(L_BLUE, raConfigAddr, NORM), end="")
			for i in range((DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH)//2):
				print(" %08x"%(d[i]), end="")
				if (i >= len(self.ingressOrder)//4):
					print(" ...", end="")
					break
			print("  #%d ports"%(DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH))
		return d, raConfigAddr + (DEFINE_INGRESS_FIRST_VPORT-DEFINE_INGRESS_FIRST_ETH)*2
	#def


	#--------------------------------------------------------------------------
	def extractFrameSizeCheck(self, entry):  #for CAN and ETH
		sizeCheck = entry.get("FrameSizeCheck", "none")
		if sizeCheck == "none":
			return 0, ""
		else:
			modes = [">=", "==", "<="]
			assert sizeCheck in modes
			assert "FrameSize" in entry
			sizeValue = entry["FrameSize"]
			assert sizeValue >= 0 and sizeValue <= 2048
			return sizeValue + (modes.index(sizeCheck) << 16), sizeCheck+str(sizeValue)+" "
	#def


	#--------------------------------------------------------------------------
	def getModificationTargets(self, entry, currentTargets):
		#No target, no modification
		if len(currentTargets) == 0:
			return []
		assert isinstance(entry, list), "List of CanIfTxPduCfg configurations expected"
		if len(entry) == 1 and len(currentTargets) == 1 and not "name" in entry[0]:
			entry[0]["name"] = currentTargets[0]

		#Check that all modification rules have a related target and defined unique
		used = []
		for i, modification in enumerate(entry):
			#print(i, modification)
			assert "name" in modification, f"'name' required in CanIfTxPduCfg entry {i} if multiple targets are defined. Got {modification}"
			if not modification['name'] in currentTargets:
				if self.VerboseWarning:
					print(f"{L_YELLOW}WARNING: Target '{modification['name']}' in CanIfTxPduCfg is not a rule target. Modification skipped{NORM}")
				self.jsonIssue += 1
				continue
			assert not modification['name'] in used, f"Modification target '{modification['name']}' defined twice."
			used.append(modification['name'])

		#and extract in ordered way
		ret = []
		remain = []
		for name in currentTargets:
			modification = next(filter(lambda x: x['name'] == name, entry), False)
			#print(name, "---", modification)
			if modification:
				ret.append(name)
			else:
				remain.append(name)

		#print("ret", ret)
		#print("remain", remain)
		return ret + remain
	#def


	#--------------------------------------------------------------------------
	def extractTargets(self, entry, validate=None):
		t = entry.get("Targets", "")
		assert type(t) == str, f"Expect a string listing all targets. Got '{t}' of {type(t)}."
		tg = [x for x in re.split(" +|,", t) if x]
		assert len(tg) <= 8
		tNames = []
		for t in tg:
			if not t in self.egressNameMap:
				if self.VerboseWarning:
					print("%sWARNING: Target '%s' has no definition. Removed from target list%s"%(L_YELLOW, t, NORM))
				self.jsonIssue += 1
				continue
			tNames.append([self.egressNameMap[t][2], t])
		tNames.sort()
		tg = self.getModificationTargets(entry.get("CanIfTxPduCfg", []), [t[1] for t in tNames])
		#print("tg", tg)

		targets = [0xff] * 8
		i = 0
		comment = ""
		used = []
		for t in tg:
			if not t in self.egressNameMap:
				if self.VerboseWarning:
					print("%sWARNING: Target '%s' has no definition. Removed from target list%s"%(L_YELLOW, t, NORM))
				self.jsonIssue += 1
				continue
			targets[i] = self.egressNameMap[t][2]
			assert not validate or self.egressNameMap[t][0] in validate, f"Interface '{self.egressNameMap[t][0]}' is no valid target. Expected {validate}."
			assert not t in used, f"Interface {t} defined multiple."
			used += [t]
			comment += ","+t
			i += 1

		#confirmation
		t = entry.get("TxConfirmationOn", "")
		assert type(t) == str, f"Expect a string listing all targets. Got '{t}' of {type(t)}."
		txc = [x for x in re.split(" +|,", t) if x]
		assert len(txc) <= 8
		confirmation = 0
		used = []
		i = 0
		for t in txc:
			if not t in tg:
				if self.VerboseWarning:
					print("%sWARNING: Target '%s' in TxConfirmation is no rule target. Removed from list%s"%(L_YELLOW, t, NORM))
				self.jsonIssue += 1
				continue
			#print(t, self.egressNameMap[t])
			assert self.egressNameMap[t][0] in ["CFD", "ETH"], f"Only physical interfaces can generate a TxConfirmation. Not '{t}'"
			confirmation += (1 << targets.index( self.egressNameMap[t][2]))
			comment = comment.replace(t,"!"+t)
			assert not t in used, f"Interface {t} defined multiple."
			used += [t]

		#flush
		t = entry.get("flushOnTarget", "")
		#if t: print(t,"--",targets)
		assert type(t) == str, f"Expect a string listing all targets. Got '{t}' of {type(t)}."
		fot = [x for x in re.split(" +|,", t) if x]
		assert len(fot) <= 8
		flush = 0
		flushTargets = []
		for t in fot:
			if not t in tg:
				if self.VerboseWarning:
					print("%sWARNING: Target '%s' in flushOnTarget is no rule target. Removed from list%s"%(L_YELLOW, t, NORM))
				self.jsonIssue += 1
				continue
			assert self.egressNameMap[t][0] == "SG", f"Only stream generation targets can flush. Not '{t}'"
			flushTargets.append(self.egressNameMap[t][2])
			comment = comment.replace(t,t+"^")
		if flushTargets:
			i = 0
			for t in tNames:
				#print(i, t[0], flush)
				if t[0] in flushTargets:
					flush += (1 << i)
				if (t[0] >= DEFINE_EGRESS_FIRST_STREAM):
					i += 1
			#print("flush:", flush)

		return tg, targets, confirmation, flush, comment
	#def



	#--------------------------------------------------------------------------
	def assembleCanModification(self, entry, currentTargets, tgComment):
		#print("assembleCanModification() entry:", entry)
		assert isinstance(entry, list), "List of CanIfTxPduCfg configurations expected"
		d = []
		comment = []

		#process the modification rules in order of the target vector
		for name in currentTargets:
			modification = next(filter(lambda x: x['name'] == name, entry), False)
			if not modification:
				continue

			assert toInt(modification.get('CanIfTxPduCanId11',0)) < (1<<11), "11-bit CanId out of range"
			assert toInt(modification.get('CanIfTxPduCanId29',0)) < (1<<29), "29-bit CanId out of range"
			assert toInt(modification.get('CanIfXLPriorityId',0)) < (1<<11), "11-bit CanPriorityId out of range"
			assert ("CanIfTxPduCanId11" in modification) + ("CanIfTxPduCanId29" in modification) + ("CanIfXLPriorityId" in modification) == 1, "No or multiple IDs are specified"
			assert "CanIfXLPriorityId" in modification or modification["CanIfTxPduCanIdType"] == "FD" or modification["CanIfTxPduCanIdType"] == "CC", "CanIfTxPduCanIdType should be CC or FD"
			#TODO: Assertions for XL

			#fill s_canIfTxPduCfg
			if ("CanIfTxPduCanId11" in modification):
				id = toInt(modification["CanIfTxPduCanId11"])
				d.append(id + (0<<29))  #PROTOCOL_bff
				if (modification["CanIfTxPduCanIdType"] == "CC"):
					d[-1] |= (1<<31)
					comment += ["CCb."+str(id)]   #BRS, RTR, ESI cannot be set by modification rule
				else:
					comment += ["FDb."+str(id)]  #BRS, RTR, ESI cannot be set by modification rule
			elif ("CanIfTxPduCanId29" in modification):
				id = toInt(modification["CanIfTxPduCanId29"])
				d.append(id + (1<<29))  #PROTOCOL_eff
				if (modification["CanIfTxPduCanIdType"] == "CC"):
					d[-1] |= (1<<31)
					comment += ["CCe."+str(id)]   #BRS, RTR, ESI cannot be set by modification rule
				else:
					comment += ["FDe."+str(id)]  #BRS, RTR, ESI cannot be set by modification rule
			#fill s_canXLIfTxPduCfg
			else: #if ("CanIfXLPriorityId" in modification):
				assert 'CanIfXLSduType' in modification, "CanIfXLSduType is missing"
				assert 'CanIfXLVcid' in modification, "CanIfXLVcid is missing"
				assert 'CanIfXLAcceptanceField' in modification, "CanIfXLAcceptanceField is missing"
				assert toInt(modification['CanIfXLSduType']) < 256, "8-bit CanIfXLSduType out of range"
				assert toInt(modification['CanIfXLVcid']) < 256, "8-bit CanIfXLVcid out of range"
				assert toInt(modification['CanIfXLAcceptanceField']) < (1<<32), "8-bit CanIfXLAcceptanceField out of range"
				id = toInt(modification["CanIfXLPriorityId"])
				sdu = toInt(modification['CanIfXLSduType'])
				vc = toInt(modification['CanIfXLVcid'])
				af = toInt(modification['CanIfXLAcceptanceField'])
				d.append((2<<29) + (id<<16) + (vc<<8) + (sdu<<0))  #PROTOCOL_xlff
				d.append(af)
				comment += [f"XL.{id}/{sdu:02x}/{vc:02x}/{af:x}"]

			#print("tgComment", tgComment)
			tgComment = tgComment.replace(name,name+"("+comment[-1]+")")
		#for
		#print("comment", comment)
		#print("d", list(map(hex, d)))
		return d, comment, tgComment
	#def


	#--------------------------------------------------------------------------
	def assembleCanAction(self, entry):
		#print("assembleCanAction() entry:", entry)
		d = [None] * 2

		#size check
		d[0], chkComment = self.extractFrameSizeCheck(entry)

		#targets and confirmation
		tg, targets, confirmation, flush, tgComment = self.extractTargets(entry)
		#print("tg", tg, "targets", targets, "confirmation", confirmation, "flush", flush)
		d[0] += (confirmation << 24)

		d[1] = (mergeBytes(targets[0:3]) << 8) + flush
		if (targets[2] != 255):   #shorten action if less than 3 targets
			d.append(mergeBytes(targets[3:7]))
			if (targets[6] != 255):   #shorten action if less than 3 targets
				d.append(mergeBytes(targets[7:8]))


		if ("CanIfTxPduCfg" in entry):
			#if modification is requested all 8 targets have to be specified
			if len(d) == 2:
				d += [0xffffffff]
			if len(d) == 3:
				d += [0xff]

			mod, modComment, tgComment = self.assembleCanModification(entry["CanIfTxPduCfg"], tg, tgComment)
			d[0] += (len(modComment) << 20)
			d += mod
			#print("d", list(map(hex, d)))
			#print("tgComment", tgComment)
			#sys.exit()

		printValue = " ".join(["%08x"%(i) for i in d])
		return chkComment+(tgComment.strip(",")), d, printValue
	#def


	#--------------------------------------------------------------------------
	def assembleCanIngressTable(self, this, channel, nr, idx, tableAddr, tableDataAddr, ruleNr):
		canIdTypeLookup = {"Id11":'CanIfRxPduCanId11', "XL":'CanIfXLPriorityId', "Id29":'CanIfRxPduCanId29'}
		lupEntrySizes =   {"Id11":4, "XL":4, "Id29":8}
		lupFormats =      {"Id11":0, "XL":3, "Id29":4}  #LUP_ID11, LUP_32, LUP_ID29

		#search entries
		d = []
		searchData = []
		actionPtr = []
		actionData = []
		matches = {}
		localRuleNr = -1
		for type in ["Id11", "Id29", "XL"]:
			matches[type] = [c for c in this.get('RxPduCfg',[]) if toInt(c.get(canIdTypeLookup[type],-1)) >= 0]
			if type != "XL":
				matches[type] = sorted(matches[type], key=lambda m: toInt(m[canIdTypeLookup[type]]))
			else: #XL
				# matches = sorted(matches, key=lambda m:
				# 	(m['search'].get('CanIfXLPriorityId',0) << 0) +
				# 	(m['search'].get('CanIfXLSduType',0) << 16) +
				# 	(m['search'].get('CanIfXLVcid',0) << 24) +
				# 	(m['search'].get('CanIfXLAcceptanceField', 0) << 32)
				# )
				None
		#for

		#Assemble the structure
		cnt11 = len(matches["Id11"])
		cnt29 = len(matches["Id29"])
		cntXL = len(matches["XL"])
		assert cntXL == 0 or channel >= DEFINE_INGRESS_FIRST_XL, "Unexpected XL definition for CFD port"
		offs11 = 0
		offs29 = offs11 + cnt11 +1
		offsXL = 0 if channel < DEFINE_INGRESS_FIRST_XL else (offs29 + cnt29 +1)

		d.append(offs11 + (offs29<<16))
		d.append(offsXL + (self.ingressFFI[idx]<<16) + (self.ingressBusId[idx]<<24))

		d.append(tableDataAddr)
		d.append(d[-1] + 4 + cnt11 * lupEntrySizes["Id11"])
		d.append(d[-1] + 4 + cnt29 * lupEntrySizes["Id29"])
		d.append(d[-1] + 4 + cntXL * lupEntrySizes["XL"] + 4)  #action pointer has a 4 byte offset because default ist at [-1]
		actionAddr = d[-1] - 4
		actionDataAddr = actionAddr + 4 * (1+cnt11+1+cnt29+1+cntXL)
		if (channel < DEFINE_INGRESS_FIRST_XL):
			d[4] = 0    #no pointer to XL lookup
			actionAddr -= 4   #no action pointer for XL
			d[5] -= 4
			actionDataAddr -= 8  #no need of a default action
		if self._VERBOSE&(2+4+8):
			oo = "-" if channel < DEFINE_INGRESS_FIRST_XL else offsXL
			ee = "-" if channel < DEFINE_INGRESS_FIRST_XL else cntXL
			print("%singress[%02d] ch=(%02d)    %06x:%s %08x %08x                    #%soffs=%d/%d/%s %sffi=%d%s bus_id=%d"%(
				L_CYAN, nr, channel, tableAddr, NORM, d[0], d[1],
				L_BLUE, offs11, offs29, oo, RED, self.ingressFFI[idx], NORM, self.ingressBusId[idx] ))
			print("%s                       %06x:%s %08x %08x %08x %s%08x%s  #entries=%d/%d/%s"%(
				L_CYAN, tableAddr+8, CYAN, d[2], d[3], d[4], L_GREEN, d[5], NORM,
				cnt11, cnt29, ee ))
		assert len(d)*4 == SIZEOF_s_ingressConfig
		tableAddr += SIZEOF_s_ingressConfig

		for type in ["Id11", "Id29", "XL"]:
			if (channel < DEFINE_INGRESS_FIRST_XL and type == "XL"):
				continue
			format = lupFormats[type]
			sortedCnt = 0
			linearCnt = 0

			#check utilisation of search table
			for entry in matches[type]:
				assert toInt(entry.get('CanIfRxPduCanId11',0)) < (1<<11), "11-bit CanId out of range"
				assert toInt(entry.get('CanIfRxPduCanId29',0)) < (1<<29), "29-bit CanId out of range"
				assert toInt(entry.get('CanIfXLPriorityId',0)) < (1<<11), "11-bit CanPriorityId out of range"
				assert (('CanIfRxPduCanId11' in entry) + ('CanIfRxPduCanId29' in entry) + ('CanIfXLPriorityId' in entry)) == 1, "Only one CanId format expected"

				if 'CanIfRxPduCanIdMask' in entry:
					assert not 'CanIfXLPriorityId' in entry, "No mask is possible on XL PriorityId"
					linearCnt += 1
					assert False
				else:
					sortedCnt += 1

			#default action TODO: Currently the same for all sub-tables
			commentAction, a, printAction = self.assembleCanAction(this["RxPduDefault"])

			#Assemble search table header
			searchData.append(sortedCnt + (linearCnt<<16) + (format<<28))
			if self._VERBOSE&(4+8): print("   %sRxPduCfg(%02d)%-7s %06x:%s %08x          %s%06x: %s%06x: %s%-26s %s%3d%s #format=%d sorted=%d linear=%d >> %s"%(
				CYAN, channel, '['+type+']', tableDataAddr, NORM, searchData[-1],
				L_GREEN if localRuleNr==0 else "", actionAddr, GREEN, actionDataAddr, NORM, printAction,
				BLUE, localRuleNr, NORM,
				format, sortedCnt, linearCnt, commentAction ))
			actionPtr.append(actionDataAddr)
			actionData.extend(a)
			actionDataAddr += len(a) * 4
			tableDataAddr += 4   #header has always 4 bytes
			actionAddr += 4      #pointer has always 4 bytes
			localRuleNr += 1  #of default rule

			#Assemble the table entries
			i = 0
			lastKey = -1
			for entry in matches[type]:
				#assemble the Action
				#print(entry)
				commentAction, a, printAction = self.assembleCanAction(entry)

				#assemble the lookup
				id = toInt(entry.get('CanIfRxPduCanId29',0)) + toInt(entry.get('CanIfRxPduCanId11',0)) + toInt(entry.get('CanIfXLPriorityId',0))
				upper_range = toInt(entry.get('CanIfRxPduCanIdRangeUpperCanId',id))
				id_type = entry.get('CanIfRxPduCanIdType', "CCFD")
				assert upper_range >= id, f"Upper range {upper_range} 0x{upper_range:x} value smaller than CanId {id} 0x{id:x}"
				val1 = id
				if type == "Id11":
					val1 |= (upper_range << 11)
					val1 |= (canIdTypeValue[id_type]*2+0 << 22)
					searchData.append(val1)
					if self._VERBOSE&8: print("           entry%-6s %06x: %08x %-8s %s%06x: %s%06x: %s%-26s %s%3d%s #id=%x..%x (%d..%d) type=%s >> %s"%(
						'['+str(i)+']',tableDataAddr, searchData[-1], "-",
						L_GREEN if localRuleNr==0 else "", actionAddr, GREEN, actionDataAddr, NORM, printAction,
						BLUE, localRuleNr, NORM,
						id, upper_range, id, upper_range, id_type, commentAction ))
					key = upper_range
				elif (type == "Id29"):
					val1 |= (canIdTypeValue[id_type]*2+0 << 29)
					val2 = upper_range
					searchData += [val1, val2]
					if self._VERBOSE&8: print("           entry%-6s %06x: %08x %08x %s%06x: %s%06x: %s%-26s %s%3d%s #id=%x/%d..%x/%d type=%s >> %s"%(
						'['+str(i)+']',tableDataAddr, searchData[-2], searchData[-1],
						L_GREEN, actionAddr, GREEN, actionDataAddr, NORM, printAction,
						BLUE, localRuleNr, NORM,
						id, upper_range, id, upper_range, id_type, commentAction ))
					key = upper_range
				else: #XL
					assert False
					# val1 = id
					# val1 |= (search['CanIfXLSduType'] << 16) + (search['CanIfXLVcid'] << 24)
					# val2 = search['CanIfXLAcceptanceField']
					# val3, val4, val5, val6, _, _ = self._assembleCanAction(channel, i, action, this['fifoEntrySize'])
					# if self._VERBOSE>1: print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x %08x %08x  #id=%d af=%d sd=%d vc=%d"%(
					# 	'['+str(i)+']', self._rxPduCfgAddr, val1, val2,
					# 	'['+str(i)+']', actionAddr, val3, val4, val5, val6, id, val2, search['CanIfXLSduType'], search['CanIfXLVcid']))
					# ra.write(self._rxPduCfgAddr, 32, [val1, val2])
					# ra.write(actionAddr, 32, [val3, val4, val5, val6])
					# self._rxPduCfgAddr += SIZEOF_s_canXlEntry
					# lastKey = (val2<<32)+(val1)

				assert key > lastKey, f"Internal: not valid sorted table {key} >= {lastKey}"
				lastKey = key
				i += 1
				localRuleNr += 1

				actionPtr.append(actionDataAddr)
				actionData.extend(a)
				actionDataAddr += len(a) * 4
				tableDataAddr += lupEntrySizes[type]
				actionAddr += 4      #pointer has always 4 bytes
			#for entry
		#for sub-table

		# print(list(map(hex, actionPtr)))
		# print(list(map(hex, actionData)))
		# sys.exit()
		allData = searchData + actionPtr + actionData
		# print(list(map(hex, searchData)))
		return d, allData, tableAddr, actionDataAddr, ruleNr+localRuleNr+1
	#def


	#--------------------------------------------------------------------------
	def getTargetNumber(self, name, defaultNumber=None):
		if not name in self.egressNameMap and defaultNumber != None:
			return defaultNumber
		assert name in self.egressNameMap, f"Target name '{name} has no definition."
		return self.egressNameMap[name]
	#def


	#--------------------------------------------------------------------------
	def assembleEthAction(self, entry, type):
		#print("assembleEthAction() entry:", entry)
		if (type=="MACVL"):
			d = [None] * 2

			d[0], chkComment = self.extractFrameSizeCheck(entry)

			#targets and confirmation
			tg, targets, confirmation, _, tgComment = self.extractTargets(entry, ["CPU", "ETH"])
			tgComment = tgComment.strip(",")
			d[0] += confirmation

			d[1] = mergeBytes(targets[0:4])
			if (targets[3] != 255):   #shorten action if less than 4 targets
				d.append(mergeBytes(targets[4:8]))

			if "streamIdentification" in entry:
				d[0] += 1<<20;  #struct s_ethAction.searchStream
				tgComment += " +Stream"
			printValue = " ".join(["%08x"%(i) for i in d])

		else:
			name = entry.get("streamUnit", "")
			if name == "":
				v0 = 255
			elif not name in self.egressNameMap:
				if self.VerboseWarning:
					print(f"{L_YELLOW}WARNING: Target '{name} has no definition. Removed as streamUnit{NORM}")
				self.jsonIssue += 1
				v0 = 255
			else:
				assert self.egressNameMap[name][0] in ["ST", "ETH", "CPU"], f"Stream termination target must accept Ethernet frames. Got '{name}'."
				v0 = self.egressNameMap[name][2]-DEFINE_EGRESS_FIRST_STREAM

			name = entry.get("actsFor", "")
			if name == "":
				v1 = ["", -1, 255]
			elif not name in self.egressNameMap:
				if self.VerboseWarning:
					print(f"{L_YELLOW}WARNING: Target '{name} is not in target list. Removed as actsFor{NORM}")
				self.jsonIssue += 1
				v1 = ["", -1, 255]
			else:
				v1 = self.egressNameMap[name]
			#print(v0, v1)
			d = [(v1[2]<<8) + v0]

			tgComment = "+"+entry["streamUnit"] if (v0 != 255) else ""
			tgComment += " -"+entry["actsFor"] if (v1[2] != 255) else ""
			chkComment = ""
			printValue = "0000%04x"%(d[0])

		tgComment = tgComment.strip()
		return chkComment+tgComment, d, printValue
	#def


	#--------------------------------------------------------------------------
	def	extractStreamTable(self, acceptance):
		streams1722 = []
		for entry in acceptance:
			if "streamIdentification" in entry:
				#print(entry["streamIdentification"])
				for e in entry["streamIdentification"]:
					sid = int(e['streamId'], 16)
					e['streamId-Number'] = int.from_bytes(sid.to_bytes(8, byteorder='little'), byteorder='big', signed=False)
					e['streamId'] = "%08x_%08x"%(sid>>32, sid&0xffffffff)  #unify the ID string form printout
				streams1722.extend(entry["streamIdentification"])
		#for
		# Sort 1722 stream IDs
		streams1722 = sorted(streams1722, key=lambda e: e['streamId-Number'])  #the sorting uses the network format of the number, not the sid itself
		return streams1722
	#def


	#--------------------------------------------------------------------------
	def assembleEthIngressTable(self, this, channel, nr, idx, tableAddr, tableDataAddr, ruleNr):
		lupFormats = {"MACVL":6, "1722":6}  #LUP_64, LUP_64
		assert 'AcceptanceDefault' in this, "Missing required 'AcceptanceDefault' in Ethernet interface configuration"
		assert 'AcceptanceCfg' in this, "Missing required 'AcceptanceCfg' in Ethernet interface configuration"
		assert ('1722StreamDefault' in this) + ('1722StreamCfg' in this) in [0,2], "For stream table definition 1722StreamDefault and 1722StreamCfg are required"

		d = []
		searchData = []
		actionPtr = []
		actionData = []
		matches = {}
		localRuleNr = -1

		defaultVlanId = this["DefaultVlanId"]

		# convert MAC Address into a big-endian number as per Ethernet format
		# print(this["AcceptanceCfg"])
		for entry in this["AcceptanceCfg"]:
			assert 'destMacAddr' in entry
			entry['destMacAddr'], entry['destMacAddr-Number'] = normMAC(entry['destMacAddr'])
		# Sort entries by destMacAddr and vlanId
		matches["MACVL"] = sorted(this["AcceptanceCfg"], key=lambda e: (
			int(e.get('vlanId', defaultVlanId)),
			e['destMacAddr-Number']
		))

		# Extract and sort 1722 stream IDs
		matches["1722"] = self.extractStreamTable(this["AcceptanceCfg"])

		cntMV = len(matches["MACVL"])
		cntST = len(matches["1722"])
		offsMV = 0
		offsST = offsMV + cntMV +1

		d.append(offsMV + (offsST<<16))
		d.append(0 + (self.ingressFFI[idx]<<16))
		d.append(tableDataAddr)
		d.append(d[-1] + 4 + cntMV * 8)
		d.append(0)  #unused
		d.append(d[-2] + 4 + cntST * 8 + 4)
		actionAddr = d[-1] - 4
		actionDataAddr = actionAddr + 4 * (1+cntMV+1+cntST)

		if self._VERBOSE&(2+4+8):
			print("%singress[%02d] ch=(%02d)    %06x:%s %08x %08x                    #%soffs=%d/%d/- %sffi=%d%s"%(
				L_CYAN, nr, channel, tableAddr, NORM, d[0], d[1],
				L_BLUE, offsMV, offsST, RED, self.ingressFFI[idx], NORM ))
			print("%s                       %06x:%s%s %08x %08x%s %08x %s%08x%s  #entries=%d/%d/-"%(
				L_CYAN, tableAddr+8, NORM,CYAN, d[2], d[3], NORM, d[4], L_GREEN, d[5], NORM,
				cntMV, cntST ))
		assert len(d)*4 == SIZEOF_s_ingressConfig
		tableAddr += SIZEOF_s_ingressConfig

		for type in ["MACVL", "1722"]:
			format = lupFormats[type]
			sortedCnt = len(matches[type])

			#default action TODO: Currently the same for all sub-tables
			defaultEntry = this["AcceptanceDefault" if type=="MACVL" else '1722StreamDefault']
			commentAction, a, printAction = self.assembleEthAction(defaultEntry, type)

			#Assemble search table header
			searchData.append(sortedCnt + (format<<28))
			if self._VERBOSE&(4+8): print("%s   Table(%02d)%-10s %06x:%s %08x          %s%06x: %s%06x: %s%-26s %s%3d%s #format=%d sorted=%d >> %s"%(
				CYAN, channel, '['+type+']', tableDataAddr, NORM, searchData[-1],
				L_GREEN if localRuleNr==0 else "", actionAddr, GREEN, actionDataAddr, NORM, printAction,
				BLUE, localRuleNr, NORM,
				format, sortedCnt, commentAction ))
			actionPtr.append(actionDataAddr)
			actionData.extend(a)
			actionDataAddr += len(a) * 4 #(4 if type == "MACVL" else 1)

			tableDataAddr += 4   #header has always 4 bytes
			actionAddr += 4      #pointer has always 4 bytes
			localRuleNr += 1  #of default rule

			#Assemble the table entries
			i = 0
			lastKey = -1
			for entry in matches[type]:
				commentAction, a, printAction = self.assembleEthAction(entry, type)

				if type == "MACVL":
					macvl = entry['destMacAddr-Number']
					vid = toInt(entry.get('vlanId', defaultVlanId))
					val1 = macvl & 0xffffffff
					val2 = ((macvl>>32) & 0xffffffff) + (vid << 16)
					searchData += [val1, val2]
					if self._VERBOSE&8: print("           entry%-6s %06x: %08x %08x %s%06x: %s%06x: %s%-26s %s%3d%s #MAC=%s VID=%d >> %s"%(
						'['+str(i)+']', tableDataAddr, searchData[-2], searchData[-1],
						L_GREEN if localRuleNr==0 else "", actionAddr, GREEN, actionDataAddr, NORM, printAction,
						BLUE, localRuleNr, NORM,
						entry['destMacAddr'], vid, commentAction ))
					key = macvl + (vid<<48)
				elif (type == "1722"):
					id = entry['streamId-Number']
					val1 = id & 0xffffffff
					val2 = ((id>>32) & 0xffffffff)
					searchData += [val1, val2]
					if self._VERBOSE&8: print("           entry%-6s %06x: %08x %08x %s%06x: %s%06x: %s%-26s %s%3d%s #SID=%s >> %s"%(
						'['+str(i)+']', tableDataAddr, searchData[-2], searchData[-1],
						L_GREEN if localRuleNr==0 else "", actionAddr, GREEN, actionDataAddr, NORM, printAction,
						BLUE, localRuleNr, NORM,
						entry['streamId'], commentAction ))
					key = id
				else:
					assert False

				assert key > lastKey, f"Internal: not valid sorted table {key} >= {lastKey}"
				lastKey = key
				i += 1
				localRuleNr += 1

				actionPtr.append(actionDataAddr)
				actionData.extend(a)
				actionDataAddr += len(a) * 4 #(4 if type == "MACVL" else 1)
				tableDataAddr += 8
				actionAddr += 4      #pointer has always 4 bytes
			#for entry
		#for sub-table

		allData = searchData + actionPtr + actionData
		return d, allData, tableAddr, actionDataAddr, ruleNr+localRuleNr+1
	#def


	#--------------------------------------------------------------------------
	def init_ingress(self, cfgThis, tableAddr):
		assert len(self.ingressOrder) <= len(cfgThis)

		tAddr = tableAddr
		dataTopAddr = tableDataAddr = tableAddr + len(self.ingressOrder) * SIZEOF_s_ingressConfig
		ruleNr = 0
		nr = 0
		dd = []
		ss = []
		for idx in self.ingressOrder:
			ingress = cfgThis[idx]
			channel = self.idx2Channel[nr]
			# For CAN interfaces, call _assembleCanIngressTable for all three ID types
			if "RxPduDefault" in ingress:
				d, s, tAddr, tableDataAddr, ruleNr = self.assembleCanIngressTable(ingress, channel, nr, idx, tAddr, tableDataAddr, ruleNr)
			else: #Ethernet
				d, s, tAddr, tableDataAddr, ruleNr = self.assembleEthIngressTable(ingress, channel, nr, idx, tAddr, tableDataAddr, ruleNr)
			dd += d
			ss += s
			nr += 1
		#for

		#provide result
		if self._VERBOSE>0:
			print("ingressConfig  at %06x..%06x with %05x/%d bytes (%d ingress ports are in use)"%(tableAddr, tAddr-4, tAddr-tableAddr, tAddr-tableAddr, len(self.ingressOrder) ))
			print("ingressTables  at %06x..%06x with %05x/%d bytes"%(dataTopAddr, tableDataAddr-4, tableDataAddr-dataTopAddr, tableDataAddr-dataTopAddr ))
		assert tAddr == dataTopAddr
		assert tableDataAddr == dataTopAddr + len(ss) * 4, f"dataTopAddr={dataTopAddr:x} tableDataAddr={tableDataAddr:x} len(ss)={len(ss):x} -- tableDataAddr-dataTopAddr={tableDataAddr-dataTopAddr:x}"
		#sys.exit()
		return dd+ss, tableDataAddr
	#def


	#--------------------------------------------------------------------------
	def init_egress(self, cfgThis, tableAddr):
		comment = ""  #was used for show stream gen/term linking
		egressBaseAddr = tableAddr

		#assemble the structures
		d = []
		relatesToRam = "bufferOut"
		total = 0
		for idx, egress in enumerate(cfgThis):
			assert "fifoEntrySize" in egress
			assert "fifoEntries" in egress
			size = egress['fifoEntrySize']
			assert size % 4 == 0, f"fifoEntrySize[{idx}] size={size} needs multiple of 4 bytes"
			base = self.ramMap[relatesToRam]
			val2 = size + (egress['fifoEntries']<<16)
			d += [base, val2]

			if self._VERBOSE&2: print(" %segressCfg[%02d]         %06x:%s %08x %08x         #FIFO{base=%06x entries=%d size=%d}%s"%(
				YELLOW, idx, tableAddr, NORM, base, val2,
				base, egress['fifoEntries'], size, comment))

			#bring egressBuffer specification to the python side
			self.egressBuffer.append({'fifoBaseAddr':base, 'fifoEntrySize':size, 'fifoEntries':egress['fifoEntries']} )

			self.ramMap[relatesToRam] += size * egress['fifoEntries']
			total += size * egress['fifoEntries']
			tableAddr += SIZEOF_s_egressConfig

		#provide result
		if self._VERBOSE>0:
			print("egressFifos    at %06x..%06x with %05x/%d bytes (%d Fifos are in use)"%(d[0], d[0]+total, total, total, len(cfgThis)))
			print("egressConfig   at %06x..%06x with %05x/%d bytes"%(egressBaseAddr, tableAddr-4, tableAddr-egressBaseAddr, tableAddr-egressBaseAddr))
		#assert SIZEOF_s_vPortConfig == len(d)*4, f"SIZEOF_s_vPortConfig={SIZEOF_s_vPortConfig} != {len(d)}"
		return d, tableAddr
	#def


	#--------------------------------------------------------------------------
	def __init__(self, fileName, VERBOSE=1):
		self._VERBOSE = VERBOSE
		# Open and read the JSON file
		print("Read RA configuration from", fileName)
		with open(fileName, 'r') as file:
			cfg = json.load(file)

	#Extract the environment specific configurations
		assert "hwAddressesForConfigGenerator" in cfg
		cfgHW = cfg["hwAddressesForConfigGenerator"]
		self.raConfigBaseAddr = raConfigAddr = int(cfgHW["raConfigBaseAddr"], 16)
		#self.rxPduCfgBaseAddr = self._rxPduCfgAddr = int(cfgHW["rxPduCfgBaseAddr"], 16)
		self.bufferInBaseAddr = self.ramMap["bufferIn"] = int(cfgHW["bufferInBaseAddr"], 16)
		self.bufferOutBaseAddr = self.ramMap["bufferOut"] = int(cfgHW["bufferOutBaseAddr"], 16)
		#self.virtualBufferAddr = self._virtualBufferAddr = int(cfgHW["virtualBufferAddr"], 16)
		assert self.raConfigBaseAddr>= ra.DATARAM[0] and self.raConfigBaseAddr <= sum(ra.DATARAM), f"raConfigBaseAddr={self.raConfigBaseAddr:x} RAM={ra.DATARAM[0]:x}..{sum(ra.DATARAM):x}"
		#assert self.rxPduCfgBaseAddr>= ra.DATARAM[0] and self.rxPduCfgBaseAddr <= sum(ra.DATARAM), f"configBaseAddr={self.rxPduCfgBaseAddr:x} RAM={ra.DATARAM[0]:x}..{sum(ra.DATARAM):x}"
		assert self.bufferInBaseAddr>= ra.BUFRAMIN[0] and self.bufferInBaseAddr <= sum(ra.BUFRAMIN), f"bufferInBaseAddr={self.bufferInBaseAddr:x} RAM={ra.BUFRAMIN[0]:x}..{sum(ra.BUFRAMIN):x}"
		assert self.bufferOutBaseAddr>= ra.BUFRAMOUT[0] and self.bufferOutBaseAddr <= sum(ra.BUFRAMOUT), f"bufferOutBaseAddr={self.bufferOutBaseAddr:x} RAM={ra.BUFRAMOUT[0]:x}..{sum(ra.BUFRAMOUT):x}"
		#assert self.virtualBufferAddr>= ra.DATARAM[0] and self.virtualBufferAddr <= sum(ra.DATARAM)

		assert "busConfigurationForStimulusGeneration" in cfg
		cfgBus = cfg["busConfigurationForStimulusGeneration"]
		self.canBitrateArbitration = int(cfgBus["canBitrateArbitration"])
		self.canBitrateData = int(cfgBus["canBitrateData"])
		self.xlBitrateArbitration = int(cfgBus["xlBitrateArbitration"])
		self.xlBitrateData = int(cfgBus["xlBitrateData"])
		self.ethPortSpeed = int(cfgBus["ethPortSpeed"])

	#Collect toplevel configuration
		assert "ingress" in cfg
		self.maxIngress = len(cfg['ingress'])
		assert self.maxIngress <= DEFINE_INGRESS_MAX, f"More than {DEFINE_INGRESS_MAX} ingress channels ({self.maxIngress}) defined."

		assert "egress" in cfg
		self.maxEgress = len(cfg['egress'])

		self.rules = []
		for idx, ingress in enumerate(cfg['ingress']):
			self.rules.append("")
			assert "name" in ingress, f"No 'name' in ingress definition #{idx} found."
			s = "".join([c for c in ingress['name'] if not c.isdigit()])
			i = toInt("".join([c for c in ingress['name'] if c.isdigit()]))
			assert s in ["CFD", "ETH", "vPort"], f"Ingress name shall indicate the interface type 'CFD, ETH, vPort'. Got '{s}'"
			if s == "CFD":
				channel = i
			elif s == "ETH":
				channel = i + DEFINE_INGRESS_FIRST_ETH
			else:
				assert s=="vPort"
				channel = i + DEFINE_INGRESS_FIRST_VPORT
			#print("Ingress %d '%s' --> %s %d %d"%(idx, ingress['name'], s, i, channel))
			assert not ingress['name'] in self.ingressNameMap, f"Multiple definition of {ingress['name']}"
			self.ingressNameMap[ingress['name']] = [s, i, channel]
		#for
		#sys.exit(0)


		#temporary generate generic egress names
		for i in range(14):
			if (i+0>=self.maxEgress): break
			self.egressNameMap["CFD"+str(i)+"f"] = ["CFD", i, i]
			#self.egressNameMap["CFD"+str(i)+"q"] = ["CFD", i, i*2+1]
		for i in range(2):
			if (i+14>=self.maxEgress): break
			self.egressNameMap["ETH"+str(i)+".0"] = ["ETH", i, i+14]
		for i in range(10):
			if (i+14+2>=self.maxEgress): break
			self.egressNameMap["CPU"+str(i)] = ["CPU", i, i+14+2]
		#for m in self.egressNameMap: print("Egress", m, self.egressNameMap[m])


		#all fields in raConfig structure
		cfgData_base, next, ptr_ingress, ptr_egress, ptr_streamGen, ptr_streamTerm = self.init_raConfig_base(cfg, raConfigAddr)
		raConfigAddr = ra.write(raConfigAddr, 32, cfgData_base)
		assert raConfigAddr == next, "%x != %x"%(raConfigAddr, next)

		assert "ingressFifo" in cfg
		cfgData_ingressFifo, next = self.init_ingressFifo(cfg["ingressFifo"], raConfigAddr)
		raConfigAddr = ra.write(raConfigAddr, 32, cfgData_ingressFifo)
		assert raConfigAddr == next, "%x != %x"%(raConfigAddr, next)

		assert "vPortFifo" in cfg
		cfgData_vPortFifo, next = self.init_vPortFifo(cfg["vPortFifo"], raConfigAddr)
		raConfigAddr = ra.write(raConfigAddr, 32, cfgData_vPortFifo)
		assert raConfigAddr == next, "%x != %x"%(raConfigAddr, next)

		cfgData_ingressMap, next = self.init_ingressMap(cfg["ingress"], raConfigAddr)
		raConfigAddr = ra.write(raConfigAddr, 32, cfgData_ingressMap)
		assert raConfigAddr == next, "%x != %x"%(raConfigAddr, next)

		cfgData_defaultVlan, next = self.init_defaultVlan(cfg["ingress"], raConfigAddr)
		raConfigAddr = ra.write(raConfigAddr, 32, cfgData_defaultVlan)
		assert raConfigAddr == next, "%x != %x"%(raConfigAddr, next)

		#egress structure (linked form raConfig)
		assert raConfigAddr == ptr_egress, "%x != %x"%(raConfigAddr, ptr_egress)
		cfgData_egress, next = self.init_egress(cfg["egress"], ptr_egress)
		ptr_egress = ra.write(ptr_egress, 32, cfgData_egress)
		assert ptr_egress == next, "%x != %x"%(ptr_egress, next)

		#streamGen structure (linked form raConfig)
		assert ptr_egress == ptr_streamGen, "%x != %x"%(ptr_egress, ptr_streamGen)
		cfgData_streamGen, next = self.init_streamGenerate(cfg["streamGenerate"], ptr_streamGen)
		ptr_streamGen = ra.write(ptr_streamGen, 32, cfgData_streamGen)
		assert ptr_streamGen == next, "%x != %x"%(ptr_streamGen, next)

		#streamTerm structure (linked form raConfig)
		assert ptr_streamGen == ptr_streamTerm, "%x != %x"%(ptr_streamGen, ptr_streamTerm)
		cfgData_streamTerm, next = self.init_streamTerminate(cfg["streamTerminate"], ptr_streamTerm)
		ptr_streamTerm = ra.write(ptr_streamTerm, 32, cfgData_streamTerm)
		assert ptr_streamTerm == next, "%x != %x"%(ptr_streamTerm, next)


		#ingress structure (FFI sorted and linked form raConfig)
		assert ptr_streamTerm == ptr_ingress, "%x != %x"%(ptr_streamTerm, ptr_ingress)
		cfgData_ingress, next = self.init_ingress(cfg["ingress"], ptr_ingress)
		ptr_ingress = ra.write(ptr_ingress, 32, cfgData_ingress)
		assert ptr_ingress == next, "%x != %x"%(ptr_ingress, next)


	##### Summarise and check
		if self._VERBOSE>0:
			print("BaseConfig     at %06x..%06x with %04x/%d bytes"%(self.raConfigBaseAddr, raConfigAddr-4, raConfigAddr-self.raConfigBaseAddr, raConfigAddr-self.raConfigBaseAddr))
			print("%sTotal Config   at %06x..%06x with %04x/%d bytes in Data RAM%s"%(WHITE, self.raConfigBaseAddr, ptr_ingress-4, ptr_ingress-self.raConfigBaseAddr, ptr_ingress-self.raConfigBaseAddr, NORM))
			#print("Rx tables      at %06x with %04x/%d bytes in Data RAM"%(self.rxPduCfgBaseAddr, self._rxPduCfgAddr-self.rxPduCfgBaseAddr, self._rxPduCfgAddr-self.rxPduCfgBaseAddr))
			print("Buffer In RAM  at %06x uses %04x/%d bytes"%(self.bufferInBaseAddr, self.ramMap['bufferIn']-self.bufferInBaseAddr, self.ramMap['bufferIn']-self.bufferInBaseAddr))
			print("Buffer Out RAM at %06x uses %04x/%d bytes"%(self.bufferOutBaseAddr, self.ramMap['bufferOut']-self.bufferOutBaseAddr, self.ramMap['bufferOut']-self.bufferOutBaseAddr))
			#print("Virtual InBuf at %06x with %04x/%d bytes in Data RAM"%(self.virtualBufferAddr, self._virtualBufferAddr-self.virtualBufferAddr, self._virtualBufferAddr-self.virtualBufferAddr))
			#print("Stream Gen    at %06x with %04x/%d bytes in Data RAM"%(streamGenAddr_print, streamTermAddr_print-streamGenAddr_print, streamTermAddr_print-streamGenAddr_print))
			#print("Stream Term   at %06x with %04x/%d bytes in Data RAM"%(streamTermAddr_print, self._ingressAddr-streamTermAddr_print, self._ingressAddr-streamTermAddr_print))
		#assert raConfigBaseAddr <= self.rxPduCfgBaseAddr
		#assert self._rxPduCfgAddr <= self.virtualBufferAddr
		#assert self.maxIngress == len(self.ingressBuffer)
		#assert self.maxEgress == len(self.egressBuffer)
		# print(self.rules)

		#sys.exit(1)


	#Ingress related config (includes the rule tables)

		# i = 0
		# total_ingress_memory = 0
		# total_ingress_subTable = 0
		# total_egress_memory = 0
		# for ingress in cfg['ingress']:
		# 	if 'RxPduDefault' in ingress:  #a CAN definition
		# 		total_ingress_memory += SIZEOF_s_ingressConfig + 3 * SIZEOF_s_RxPduCfg
		# 		#Multicast action tables are handled by sub-table
		# 		for RxPduCfg in ingress.get("RxPduCfg", []):
		# 			if "CanIfTxPduCfg" in RxPduCfg["action"] and len(RxPduCfg["action"]["CanIfTxPduCfg"]) > 1:
		# 				for m in RxPduCfg["action"]["CanIfTxPduCfg"]:
		# 					if len(m):
		# 						total_ingress_subTable += SIZEOF_s_canIfTxPduCfg # * len(RxPduCfg["action"]["CanIfTxPduCfg"])
		# 	else: # an Ethernet definition
		# 		total_ingress_memory += SIZEOF_s_ingressConfig + 3 * SIZEOF_s_RxPduCfg  # Change here from 4 to 3 to get working scenario as in past
		# 		#self._totalEthControllers += 1  # Increment for each Ethernet interface

		# #for 'ingress'
		# total_egress_memory = 0
		# total_streamGen_memory = 0
		# maxStreamGen = 0
		# maxStreamTerm = 0
		# for idx, egress in enumerate(cfg['egress']):
		# 	total_egress_memory += SIZEOF_s_egressConfig
		# 	if "streamGenerate" in egress:
		# 		maxStreamGen += 1
		# 		normalise_templateData(egress['streamGenerate'])
		# 		total_streamGen_memory += 4 + SIZEOF_s_1722streamGen + len(egress['streamGenerate']["templateData"])
		# 	if "streamTerminate" in egress:
		# 		maxStreamTerm += 1
		# 		self.streamsTerm.append({"outFifoIdx":idx,
		# 			"targetExceptionPort":egress["streamTerminate"]["targetExceptionPort"],
		# 			"vPortIndex":egress["streamTerminate"]["vPortIndex"]
		# 		})


		# val1 = self._ingressAddr + SIZEOF_s_raConfig + total_ingress_subTable
		# val2 = val1 + total_ingress_memory
		# val3 = val2 + total_egress_memory
		# val4 = val3 + total_streamGen_memory
		# val5 = self.maxIngress + (self.maxEgress<<8) + (maxStreamGen<<16)  + (maxStreamTerm<<24)

		# if self._VERBOSE>0: print("%sbaseConfig ----------- %06x : %s%08x %s%08x %s%08x %08x %s%08x%s  #ingressBuffers=%d  egressBuffers=%d streamGen=%d streamTerm=%d"%(
		# 	BLUE+"\033[1m", self._ingressAddr, MAGENTA, val1, YELLOW, val2, GREEN, val3, val4, BLUE, val5, NORM,
		# 	len(cfg['ingress']), len(cfg['egress']), maxStreamGen, maxStreamTerm))
		# self._ingressAddr = ra.write(self._ingressAddr, 32, [val1, val2, val3, val4, val5])

		# #space for the ingress sub-table
		# self._ingressSubTableAddr = {'base':self._ingressAddr, 'next':self._ingressAddr, 'CanIfTxPduCfg-comment':[], 'CanIfTxPduCfg':[]}
		# self._ingressAddr += total_ingress_subTable

		# #- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		# #for ingress config
		# i = 0
		# for ingress in cfg['ingress']:
		# 	self.rules.append({})
		# 	if 'RxPduDefault' in ingress:  #a CAN definition
		# 		# For CAN interfaces, call _assembleCanIngressTable for all three ID types
		# 		self._assembleCanIngressTable(ingress, i, "Id11", True)
		# 		self._assembleCanIngressTable(ingress, i, "XL",   False)
		# 		self._assembleCanIngressTable(ingress, i, "Id29", False)
		# 	else:
		# 		# For Ethernet interfaces, call only _assembleEthIngressTable
		# 		self._assembleEthIngressTable(ingress, i, True)
		# 	i += 1
		# #for

		# a = self._ingressSubTableAddr['base']
		# for i in range(len(self._ingressSubTableAddr['CanIfTxPduCfg'])*4//SIZEOF_s_canIfTxPduCfg):
		# 	if self._VERBOSE > 0:
		# 		print(" %sCanTxPduCfg%-10s %06x :" % (
		# 			GREEN, "["+self._ingressSubTableAddr['CanIfTxPduCfg-comment'][i]+"]", a), end="")
		# 		for v in self._ingressSubTableAddr['CanIfTxPduCfg'][i]:
		# 			if (v):
		# 				print(" %08x"%v, end="")
		# 		print("%s"%NORM)
		# 	d = [x for x in self._ingressSubTableAddr['CanIfTxPduCfg'][i] if x is not None]
		# 	ra.write(a, 32, d)
		# 	a +=  4 * len(d)

		# #- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		# #for egress config
		# i = 0
		# for egress in cfg['egress']:
		# 	self._assembleEgressTable(egress, i)
		# 	i += 1

		# ##### Stream Generation structure
		# streamGenAddr_print = self._ingressAddr
		# #print(self.streamsGen)
		# a = self._ingressAddr + 4 * len(self.streamsGen)
		# sub = []
		# for s in self.streamsGen:
		# 	sub.append(a)
		# 	a += len(s['template'])*4 + SIZEOF_s_1722streamGen
		# if self._VERBOSE > 0:
		# 	print(" %sstreamGenCfg          %06x :%s%s%s" % (
		# 		GREEN, self._ingressAddr, CYAN, "".join([f" {i:08x}" for i in sub]), NORM))
		# self._ingressAddr = ra.write(self._ingressAddr, 32, sub)

		# #print(self.streamsGen)
		# for i, s in enumerate(self.streamsGen):
		# 	#print(s)
		# 	#fill s_1722streamGen
		# 	val1 = len(s['template'])*4 + (s['patchDataLengthWord']<<16)
		# 	val2 = s["maxFrameSize"] + (s["txTimeout"]<<16)
		# 	val3, val4 = self._assembleEthAction(s["action"])
		# 	if self._VERBOSE > 0:
		# 		print("   %sstreamGen%-7s    %06x : %08x %08x |> %08x %08x%s  #maxSize=%d timeout=%1.3fms" % (
		# 				CYAN, f"[{i}]", self._ingressAddr, val1, val2, val3, val4, NORM,
		# 				s["maxFrameSize"], s["txTimeout"]/1000), end='')
		# 		j = 4
		# 		a = self._ingressAddr + SIZEOF_s_1722streamGen
		# 		for v in s['template']:
		# 			if j==4:
		# 				print("\n                       %06x :"%(a), end='')
		# 				j = 0
		# 			print(" %08x"%v, end="")
		# 			a += 4
		# 			j += 1
		# 		#for
		# 		print()

		# 	self._ingressAddr = ra.write(self._ingressAddr, 32, [val1, val2, val3, val4]+s['template'])

		# ##### Stream Termination structure
		# streamTermAddr_print = self._ingressAddr
		# #print(self.streamsTerm)
		# a = self._ingressAddr + 4 * len(self.streamsTerm)
		# sub = []
		# for s in self.streamsTerm:
		# 	sub.append(a)
		# 	a += SIZEOF_s_1722streamTerm
		# if self._VERBOSE > 0:
		# 	print(" %sstreamTermCfg         %06x :%s%s%s" % (
		# 		GREEN, self._ingressAddr, CYAN, "".join([f" {i:08x}" for i in sub]), NORM))
		# self._ingressAddr = ra.write(self._ingressAddr, 32, sub)

		# for i, s in enumerate(self.streamsTerm):
		# 	#fill s_1722streamTerm
		# 	val1 = s["vPortIndex"] + ((s["targetExceptionPort"]&0xff)<<8)
		# 	if self._VERBOSE > 0:
		# 		print("   %sstreamTerm%-7s   %06x : %08x%s                    #vPortIndex=%d targetExceptionPort=%d" % (
		# 				CYAN, f"[{i}]", self._ingressAddr, val1, NORM,
		# 				s["vPortIndex"], s["targetExceptionPort"]&0xff))
		# 	self._ingressAddr = ra.write(self._ingressAddr, 32, [val1])

	#__init__


	# #--------------------------------------------------------------------------
	# def _assembleCanAction(self, idx, rule, action, fifoEntrySize):
	# 	comment = ""
	# 	val3 = toInt(action.get('CanIfRxPduId', 0))
	# 	if (action['CanIfRxPduDataLengthCheck']):
	# 		val2 = toInt(action['CanIfRxPduDataLength'])
	# 		assert val2 >= 0 and val2 <=64, "CanIfRxPduDataLength is out of range 0..64"
	# 		if (val2 > fifoEntrySize):
	# 			print("\033[33;1mWarning: CanIfRxPduDataLength=%d (min size) is above configured fifoEntrySize=%d  (CanIfRxPduId=%d)\033[m"%(val2, fifoEntrySize, val3))
	# 		comment += " min="+str(val2)
	# 	else:
	# 		val2 = 0x0
	# 	minLength = val2

	# 	val4 = toInt(action['TargetVector'])

	# 	i = 0x10000
	# 	if ("CanIfTxPduCfg" in action):
	# 		assert isinstance(action["CanIfTxPduCfg"], list), "List of CanIfTxPduCfg configurations expected"
	# 		val5 = []
	# 		for modification in action["CanIfTxPduCfg"]:
	# 			#print(modification, type(modification))
	# 			if len(modification) == 0:
	# 				comment += " -"
	# 			else:
	# 				assert toInt(modification.get('CanIfTxPduCanId11',0)) < (1<<11), "11-bit CanId out of range"
	# 				assert toInt(modification.get('CanIfTxPduCanId29',0)) < (1<<29), "29-bit CanId out of range"
	# 				assert toInt(modification.get('CanIfXLPriorityId',0)) < (1<<11), "11-bit CanPriorityId out of range"
	# 				assert "CanIfTxPduCanId11" in modification or "CanIfTxPduCanId29" in modification or "CanIfXLPriorityId" in modification, "No Id specified"
	# 				assert modification["CanIfTxPduCanIdType"] == "FD" or modification["CanIfTxPduCanIdType"] == "CC", "CanIfTxPduCanIdType should be CC or FD"

	# 				#fills s_canIfTxPduCfg
	# 				comment += " ->"
	# 				if ("CanIfTxPduCanId11" in modification):
	# 					val5.append(toInt(modification["CanIfTxPduCanId11"]) + (0<<29))  #PROTOCOL_bff
	# 					if (modification["CanIfTxPduCanIdType"] == "FD"):
	# 						val5[-1] |= (1<<31)
	# 						modification["frameIdentifier"] = "Id11."+str(modification["CanIfTxPduCanId11"])+".FD"
	# 					else:
	# 						modification["frameIdentifier"] = "Id11."+str(modification["CanIfTxPduCanId11"])+".CC"
	# 					comment += modification["frameIdentifier"]
	# 				elif ("CanIfTxPduCanId29" in modification):
	# 					val5.append(toInt(modification["CanIfTxPduCanId29"]) + (1<<29))  #PROTOCOL_eff
	# 					if (modification["CanIfTxPduCanIdType"] == "FD"):
	# 						val5[-1] |= (1<<31)
	# 						modification["frameIdentifier"] = "Id29."+str(modification["CanIfTxPduCanId29"])+".FD"
	# 					else:
	# 						modification["frameIdentifier"] = "Id29."+str(modification["CanIfTxPduCanId29"])+".CC"
	# 					comment += modification["frameIdentifier"]
	# 				elif ("CanIfXLPriorityId" in modification):
	# 					val5.append(toInt(modification["CanIfXLPriorityId"]) + (2<<29))  #PROTOCOL_xlff
	# 				#else:
	# 				#	val5.append(None)

	# 				#mark in modifyOnTarget
	# 				val2 |= i
	# 			i <<= 1
	# 		#for
	# 		if len(action["CanIfTxPduCfg"]) > 1:
	# 			self._ingressSubTableAddr['CanIfTxPduCfg'].append(val5)
	# 			self._ingressSubTableAddr['CanIfTxPduCfg-comment'].append("C%d#%d"%(idx,rule))
	# 			val5 = self._ingressSubTableAddr['next']
	# 			self._ingressSubTableAddr['next'] += SIZEOF_s_canIfTxPduCfg * len(action["CanIfTxPduCfg"])
	# 		else:
	# 			val5 = val5[0]
	# 	else:
	# 		val5 = 0

	# 	if ("flushOnTarget" in action):
	# 		flush = action["flushOnTarget"]
	# 		#print("FLUSH %x  target=%x"%(flush, val4))
	# 		i = 0x1000000
	# 		for j in range(32):
	# 			if (1<<j) & val4:
	# 				if (1<<j) & flush:
	# 					val2 |= i
	# 					comment += f" Flush #{j}"
	# 				i <<= 1
	# 		#print("%x"%val2)

	# 	return val2, val3, val4, val5, minLength, comment
	# #_assembleCanAction


	# #--------------------------------------------------------------------------
	# def _assembleEthAction(self, action):
	# 	val1 = toInt(action["FrameOwner"])
	# 	val2 = toInt(action["TargetVector"])
	# 	return val1, val2


	# #--------------------------------------------------------------------------
	# def _assembleEthIngressTable(self, this, idx, withHeader):
	# 	assert 'EthTypeTableCfg' in this, "Missing required 'EthTypeTableCfg' in Ethernet interface configuration"

	# 	# Add assertions for the new default routes
	# 	assert 'EthTypeTableDefault' in this, "Missing required 'EthTypeTableDefault' in Ethernet interface configuration"
	# 	assert 'VlanDaTableDefault' in this, "Missing required 'VlanDaTableDefault' in Ethernet interface configuration"
	# 	assert 'Ieee1722TableDefault' in this, "Missing required 'Ieee1722TableDefault' in Ethernet interface configuration"

	# 	table_keys = ['EthTypeTableCfg', 'VlanDaTableCfg', 'Ieee1722TableCfg']
	# 	default_keys = ['EthTypeTableDefault', 'VlanDaTableDefault', 'Ieee1722TableDefault']
	# 	lookup_formats = {
	# 		'EthTypeTableCfg': 2,  # LUP_16
	# 		'VlanDaTableCfg': 6,   # LUP_48
	# 		'Ieee1722TableCfg': 6  # LUP_64
	# 	}

	# 	if withHeader:
	# 		assert this['fifoEntrySize'] >= 24, f"ETH Ingress FIFOs needs at least 24 bytes (meta+4*payload) got{this['fifoEntrySize']}"
	# 		assert this['fifoEntrySize']%4 == 0, f"Ingress FIFO size shall multiple of 4  got {this['fifoEntrySize']}"
	# 		val1 = self._bufferInAddr
	# 		val2 = this['fifoEntrySize'] | (this['fifoEntries'] << 16)
	# 		if self._VERBOSE > 0:
	# 			print(" %singressCfg[%02d]        %06x : %08x %08x%s (+3 ptr)  #FIFO{base=%04x entries=%d size=%d}" % (
	# 				MAGENTA, idx, self._ingressAddr, val1, val2, NORM,
	# 				val1, this['fifoEntries'], this['fifoEntrySize']))
	# 		ra.write(self._ingressAddr, 32, [val1, val2])
	# 		self.ingressBuffer.append({
	# 			'fifoBaseAddr': self._bufferInAddr,
	# 			'fifoEntrySize': this['fifoEntrySize'],
	# 			'fifoEntries': this['fifoEntries']
	# 		})
	# 		self._ingressAddr += SIZEOF_s_ingressConfig
	# 		self._bufferInAddr += ((this['fifoEntrySize'] + 127) // 128) * 128 * this['fifoEntries']

	# 	for table_idx, table_key in enumerate(table_keys):
	# 		default_key = default_keys[table_idx]
	# 		entries = this.get(table_key, [])
	# 		DefaultVlanId = this['DefaultVlanId']
	# 		if entries:
	# 			# Sort entries by etherType for EthTypeTableCfg
	# 			if table_key == 'EthTypeTableCfg':
	# 				for i, entry in enumerate(entries):
	# 					entries[i] = sorted(entry, key=lambda e: int(e['search']['etherType'], 16))
	# 				assert len(entries) == 1, f"Currently only an ET Table with 1 table is supported. Got {len(entries)}"
	# 				entries = entries[0]
	# 			elif table_key == 'VlanDaTableCfg':
	# 				# convert MAC Address into a bit-endian number as per Ethernet format
	# 				for entry in entries:
	# 					entry['search']['destMacAddr'], entry['search']['destMacAddr-Number'] = normMAC(entry['search']['destMacAddr'])
	# 				# Sort entries by destMacAddr and vlanId
	# 				entries = sorted(entries, key=lambda e: (
	# 					int(e['search'].get('vlanId', DefaultVlanId)),
	# 					e['search']['destMacAddr-Number']
	# 				))
	# 			elif table_key == 'Ieee1722TableCfg':
	# 				# convert MAC Address into a bit-endian number as per Ethernet format
	# 				for entry in entries:
	# 					sid = int(entry['search']['streamId'],16)
	# 					entry['search']['streamId-Number'] = int.from_bytes(sid.to_bytes(8, byteorder='little'), byteorder='big', signed=False)
	# 				entries = sorted(entries, key=lambda e: e['search']['streamId-Number'])
	# 			val1 = self._rxPduCfgAddr
	# 			# Calculate actionAddr based on key size
	# 			if table_key == 'EthTypeTableCfg':
	# 				key_size = 4
	# 			else:
	# 				key_size = 8
	# 			actionAddr = val1 + SIZEOF_s_lookupCtrl + SIZEOF_s_EthAction + len(entries) * key_size

	# 			# Validate each entry in EthTypeTableCfg has search and action fields
	# 			for entry in entries:
	# 				assert 'search' in entry, f"Missing 'search' field in {table_key} entry: {entry}"
	# 				assert 'action' in entry, f"Missing 'action' field in {table_key} entry: {entry}"
	# 				if table_key == 'EthTypeTableCfg':
	# 					assert 'etherType' in entry['search'], f"Missing 'etherType' in search field: {entry['search']}"
	# 				elif table_key == 'VlanDaTableCfg':
	# 					assert 'destMacAddr' in entry['search'], f"Missing 'destMacAddr' in search field: {entry['search']}"
	# 				elif table_key == 'Ieee1722TableCfg':
	# 					assert 'streamId' in entry['search'], f"Missing 'streamId' in search field: {entry['search']}"
	# 				assert 'FrameOwner' in entry['action'], f"Missing 'FrameOwner' in action field: {entry['action']}"
	# 				assert 'TargetVector' in entry['action'], f"Missing 'TargetVector' in action field: {entry['action']}"
	# 			val2 = actionAddr
	# 			if self._VERBOSE > 0:
	# 				print("   %s%-19s %06x : %08x %08x%s           #entries=%d search->%06x action->%06x" % (
	# 					CYAN, table_key+"["+str(idx)+"]", self._ingressAddr, val1, val2, NORM, len(entries), val1, val2))
	# 			ra.write(self._ingressAddr, 32, [val1, val2])
	# 			self._ingressAddr += SIZEOF_s_RxEthPduCfg

	# 			# write lookup control and print
	# 			lupFormat = lookup_formats[table_key]
	# 			val3 = len(entries) | (0 << 16) | (lupFormat << 28)
	# 			if self._VERBOSE > 1:
	# 				print("           config      %06x : %08x -    action[-1] %06x : %08x %08x  #bin=%d lin=%d" % (
	# 					self._rxPduCfgAddr, val3,
	# 					actionAddr - SIZEOF_s_EthAction,
	# 					toInt(this[default_key]['FrameOwner']),
	# 					toInt(this[default_key]['TargetVector']),
	# 					len(entries), 0))
	# 			ra.write(self._rxPduCfgAddr, 32, [val3])
	# 			self._rxPduCfgAddr += 4

	# 			# write default action using the specific table default
	# 			val1, val2 = self._assembleEthAction(this[default_key])
	# 			ra.write(actionAddr - SIZEOF_s_EthAction, 32, [val1, val2])

	# 			# write entries with proper bit widths
	# 			for i, entry in enumerate(entries):
	# 				if table_key == 'VlanDaTableCfg':
	# 					# 64-bit MAC+VLAN combination for LUP_64
	# 					vlan = int(entry['search'].get('vlanId', DefaultVlanId))
	# 					assert vlan <= 0xfff
	# 					key = entry['search']['destMacAddr-Number'] + (vlan << 48)
	# 					key_low = key & 0xFFFFFFFF
	# 					key_high = (key >> 32) & 0xFFFFFFFF
	# 					search1722 = entry['action'].get('search1722', False)
	# 					searchET = entry['action'].get('searchET', False)
	# 					if (type(searchET)==bool and searchET == False):
	# 						searchET =  0
	# 					elif (type(searchET)==bool and searchET==True):
	# 						searchET = 1
	# 					else:
	# 						searchET += 1
	# 					assert (searchET < 256)

	# 					val3, val4 = self._assembleEthAction(entry['action'])
	# 					val3 = val4 | (searchET<<16) | (search1722<<24)

	# 					#print("VLDA: Key=0x%016x vlan=%d ET=%s 1722=%d  action=%x" % (key, vlan, searchET, search1722, actionAddr))
	# 					if self._VERBOSE > 1:
	# 						print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x  #mac=%s vlan=%d - 1722=%s ET=%s" % (
	# 							'['+str(i)+']', self._rxPduCfgAddr, key_low, key_high,
	# 							'['+str(i)+']', actionAddr,
	# 							val3, val4,
	# 							entry['search']['destMacAddr'], vlan, "check" if search1722 else "no", "no" if searchET==0 else searchET-1))
	# 					ra.write(self._rxPduCfgAddr, 32, [key_low, key_high])
	# 					self._rxPduCfgAddr += 8

	# 					#place in rule table for Python
	# 					tag = ":".join([f"{int(x, 16):02x}" for x in entry['search']['destMacAddr'].split(':')])
	# 					tag = f"{idx}>{tag}-{vlan}"
	# 					tg = []
	# 					for i, c in enumerate(format(toInt(entry['action']['TargetVector']), "b")[::-1]):
	# 						if (c=="1"):
	# 							tg.append({"target":i, "TxModify":None, "minLength":0}) #, "subTag":""})
	# 					#print(idx, ":", searchET, tag, tg)
	# 					self.rules[-1][tag] = tg
	# 					if (searchET != 0):
	# 						self.rules[-1][tag+"#ET"] = searchET-1
	# 						#print(idx, ":", searchET, tag+"#ET")
	# 					if (search1722 != 0):
	# 						self.rules[-1][tag+"#ST"] = True
	# 						#print(idx, ":", tag+"#ST")

	# 				elif table_key == 'EthTypeTableCfg':
	# 					# 16-bit EtherType
	# 					key = int(entry['search']['etherType'], 16)
	# 					assert key < 0x10000, f"EtherType {key:x} out of range"
	# 					val3, val4 = self._assembleEthAction(entry['action'])

	# 					if self._VERBOSE > 1:
	# 						print("           entry%-6s %06x : %08x -        %6s %06x : %08x %08x  #etherType=0x%04x" % (
	# 							'['+str(i)+']', self._rxPduCfgAddr, key,
	# 							'['+str(i)+']', actionAddr,
	# 							val3, val4,
	# 							key))
	# 					ra.write(self._rxPduCfgAddr, 32, [(key>>8)+((key<<8)&0xff00)])
	# 					self._rxPduCfgAddr += 4

	# 					#place in rule table for Python
	# 					tag = f"ET0-{key:04x}"  #currently on list supported here
	# 					tg = []
	# 					for i, c in enumerate(format(toInt(entry['action']['TargetVector']), "b")[::-1]):
	# 						if (c=="1"):
	# 							tg.append({"target":i, "TxModify":None, "minLength":0}) #, "subTag":f"-E{key:04x}"})
	# 					#print(idx, ":", tag, tg)
	# 					self.rules[-1][tag] = tg

	# 				elif table_key == 'Ieee1722TableCfg':
	# 					# 64-bit stream ID only (no subtype)
	# 					stream_id = entry['search']['streamId-Number']
	# 					val1 = stream_id & 0xFFFFFFFF
	# 					val2 = (stream_id >> 32) & 0xFFFFFFFF
	# 					val3, val4 = self._assembleEthAction(entry['action'])

	# 					#place in rule table for Python
	# 					tag = f"ST-{bswap_64(stream_id):016x}"
	# 					tg = []
	# 					comment = ""
	# 					for i, c in enumerate(format(toInt(entry['action']['TargetVector']), "b")[::-1]):
	# 						if (c=="1"):
	# 							if any(d['outFifoIdx'] == i for d in self.streamsTerm):
	# 								pos = sum(idx if d['outFifoIdx']==i else 0 for idx,d in enumerate(self.streamsTerm))
	# 								comment = f"  --> streamTerm#{pos}"
	# 							else:
	# 								pos = None
	# 							tg.append({"target":i, "TxModify":None, "minLength":0, "streamTerm":pos}) #, "subTag":f"-S{stream_id:016x}"})
	# 					#for
	# 					#print(idx, ":", tag, tg)
	# 					self.rules[-1][tag] = tg

	# 					if self._VERBOSE > 1:
	# 						current_action_offset = sum(SIZEOF_s_EthAction for _ in range(i))
	# 						print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x  #streamId=%s%s" % (
	# 							'['+str(i)+']', self._rxPduCfgAddr, val1, val2,
	# 							'['+str(i)+']', actionAddr + current_action_offset,
	# 							val3, val4,
	# 							entry['search']['streamId'], comment))
	# 					ra.write(self._rxPduCfgAddr, 32, [val1, val2])
	# 					self._rxPduCfgAddr += 8
	# 				#if

	# 				#write the action table entry
	# 				ra.write(actionAddr, 32, [val3, val4])
	# 				actionAddr += SIZEOF_s_EthAction
	# 			#for all entries
	# 			self._rxPduCfgAddr = actionAddr
	# 		else:
	# 			# NULL table
	# 			if self._VERBOSE > 0:
	# 				print("   %s%s[%02d]     %06x : %08x %08x%s           #NULL" % (
	# 					CYAN, table_key, idx, self._ingressAddr, 0, 0, NORM))
	# 			ra.write(self._ingressAddr, 32, [0, 0])
	# 			self._ingressAddr += SIZEOF_s_RxEthPduCfg
	# #_assembleEthIngressTable


	# #--------------------------------------------------------------------------
	# def _assembleCanIngressTable(self, this, idx, type, withHeader):
	# 	#The header information of this ingress port
	# 	#Fills struct s_ingressConfig
	# 	if withHeader:
	# 		assert this['fifoEntrySize'] >= 32, f"CAN Ingress FIFOs needs at least 32 bytes (meta+4*payload) got{this['fifoEntrySize']}"
	# 		assert this['fifoEntrySize']%4 == 0, f"Ingress FIFO size shall multiple of 4  got {this['fifoEntrySize']}"
	# 		val1 = self._virtualBufferAddr if this.get('fifoIsVirtual', False) else self._bufferInAddr
	# 		val2 = this['fifoEntrySize']
	# 		val2 |= this['fifoEntries']<<16
	# 		if self._VERBOSE>0: print(" %singressCfg[%02d]        %06x : %08x %08x%s (+3 ptr)  #FIFO{base=%04x entries=%d size=%d}"%(
	# 				MAGENTA, idx, self._ingressAddr, val1, val2, NORM,
	# 				val1, this['fifoEntries'], this['fifoEntrySize']))
	# 		ra.write(self._ingressAddr, 32, [val1, val2])
	# 		self.ingressBuffer.append({'fifoBaseAddr':val1, 'fifoEntrySize':this['fifoEntrySize'], 'fifoEntries':this['fifoEntries']} )
	# 		self._ingressAddr += SIZEOF_s_ingressConfig
	# 		if this.get('fifoIsVirtual', False):
	# 			self._virtualBufferAddr += ((this['fifoEntrySize']+127)//128)*128 * this['fifoEntries']
	# 		else:
	# 			self._bufferInAddr += ((this['fifoEntrySize']+127)//128)*128 * this['fifoEntries']


	# 	# Original CAN processing code...
	# 	matches = [c for c in this.get('RxPduCfg',[]) if toInt(c['search'].get(canIdTypeLookup[type],-1)) >= 0]
	# 	#print("  PY  ingress #%d  entriesSize=%d  type=%s  entries=%d"%(idx, this['fifoEntrySize'], type, len(matches)))

	# 	#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	# 	#The table information of one format (Id11, XL, Id29)
	# 	#Fills struct s_RxPduCfg (3 times for CAN)
	# 	#struct s_RxPduCfg {
	# 	#	struct s_lookupTable *search;  //contains size and table itself
	# 	#	struct s_canAction *actions;   //default action is at [-1]
	# 	#};
	# 	actionAddr = self._rxPduCfgAddr + SIZEOF_s_lookupCtrl + SIZEOF_s_canAction #space for default action
	# 	if (type == "XL"):
	# 		actionAddr += SIZEOF_s_canXlEntry * len(matches)
	# 		lupFormat = 3 #LUP_32 for AF
	# 	elif (type=="Id11"):
	# 		actionAddr += SIZEOF_s_canFdEntry * len(matches)
	# 		lupFormat = 0 #LUP_ID11
	# 	else:
	# 		actionAddr += SIZEOF_s_canFdEntry * len(matches)
	# 		lupFormat = 4 #LUP_ID29

	# 	val1 = self._rxPduCfgAddr
	# 	val2 = actionAddr

	# 	if self._VERBOSE>0: print("   %sRxPduCfg[%02d]%-7s %06x : %08x %08x%s           #entries=%d search->%06x action->%06x"%(
	# 			CYAN, idx, '['+type+']', self._ingressAddr, val1, val2, NORM,
	# 			len(matches), self._rxPduCfgAddr, actionAddr))
	# 	ra.write(self._ingressAddr, 32, [val1, val2])
	# 	self._ingressAddr += SIZEOF_s_RxPduCfg

	# 	val1 = len(matches)  #sorted entries
	# 	val1 |= (0 << 16)    #linear entries
	# 	val1 |= (lupFormat << 28)    #format (enum e_lupFormat {LUP_ID11=0, LUP_8, LUP_16, LUP_32, LUP_ID29=4, LUP_48, LUP_64};
	# 	val4, val5, val6, val7, _, _ = self._assembleCanAction(idx, -1, this['RxPduDefault'], this['fifoEntrySize'])

	# 	if self._VERBOSE>1: print("           config      %06x : %08x -    action[-1] %06x : %08x %08x %08x %08x  #bin=%d lin=%d"%(
	# 		self._rxPduCfgAddr, val1,
	# 		actionAddr-SIZEOF_s_canAction, val4, val5, val6, val7,
	# 		len(matches), 0))
	# 	ra.write(self._rxPduCfgAddr, 32, [val1])
	# 	ra.write(actionAddr-SIZEOF_s_canAction, 32, [val4, val5, val6, val7])
	# 	self._rxPduCfgAddr += 4

	# 	if (type == "XL"):
	# 		matches = sorted(matches, key=lambda m:
	# 			(m['search'].get('CanIfXLPriorityId',0) << 0) +
	# 			(m['search'].get('CanIfXLSduType',0) << 16) +
	# 			(m['search'].get('CanIfXLVcid',0) << 24) +
	# 			(m['search'].get('CanIfXLAcceptanceField', 0) << 32)
	# 		)
	# 	else:
	# 		matches = sorted(matches, key=lambda m: toInt(m['search'].get('CanIfRxPduCanId11',0)))


	# 	#The table itself (in either FD or XL format)
	# 	#Fills struct s_canFdEntry
	# 	#Fills struct s_canXlEntry
	# 	#lastKey and i are only for assertion and printing
	# 	lastKey = 0
	# 	i = 0
	# 	for rxPduCfg in matches:
	# 		search = rxPduCfg['search']
	# 		action = rxPduCfg['action']

	# 		assert toInt(search.get('CanIfRxPduCanId11',0)) < (1<<11), "11-bit CanId out of range"
	# 		assert toInt(search.get('CanIfXLPriorityId',0)) < (1<<11), "11-bit CanPriorityId out of range"
	# 		assert toInt(search.get('CanIfRxPduCanId29',0)) < (1<<29), "29-bit CanId out of range"
	# 		assert action.get('TargetVector', -1) != -1, "Number as TargetVector expected"

	# 		# ToDo Check for overlapping

	# 		id = toInt(search.get('CanIfRxPduCanId29',0)) + toInt(search.get('CanIfRxPduCanId11',0)) + toInt(search.get('CanIfXLPriorityId',0))
	# 		upper_range = toInt(search.get('CanIfRxPduCanIdRangeUpperCanId',id))
	# 		assert upper_range >= id, f"Upper range {upper_range} 0x{upper_range:x} value smaller than CanId {id} 0x{id:x}"

	# 		#place in data RAM for C
	# 		if (type == "XL"):
	# 			val1 = id
	# 			val1 |= (search['CanIfXLSduType'] << 16) + (search['CanIfXLVcid'] << 24)
	# 			val2 = search['CanIfXLAcceptanceField']
	# 			val3, val4, val5, val6, _, _ = self._assembleCanAction(idx, i, action, this['fifoEntrySize'])
	# 			if self._VERBOSE>1: print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x %08x %08x  #id=%d af=%d sd=%d vc=%d"%(
	# 				'['+str(i)+']', self._rxPduCfgAddr, val1, val2,
	# 				'['+str(i)+']', actionAddr, val3, val4, val5, val6, id, val2, search['CanIfXLSduType'], search['CanIfXLVcid']))
	# 			ra.write(self._rxPduCfgAddr, 32, [val1, val2])
	# 			ra.write(actionAddr, 32, [val3, val4, val5, val6])
	# 			self._rxPduCfgAddr += SIZEOF_s_canXlEntry

	# 			assert (val2<<32)+(val1) > lastKey
	# 			lastKey = (val2<<32)+(val1)
	# 		else:
	# 			val1 = id
	# 			if (type == "Id11"):
	# 				assert upper_range < (1<<11), "11-bit CanId upper range out of range"
	# 				val1 |= (upper_range << 11)
	# 				val1 |= (canIdTypeValue[search['CanIfRxPduCanIdType']]*2+0 << 22)
	# 			else:
	# 				assert upper_range < (1<<29), "29-bit CanId upper range out of range"
	# 				#TODO 29-bit Id table entry assembling not yet implemented
	# 				val1 |= (canIdTypeValue[search['CanIfRxPduCanIdType']] << 30)
	# 			val3, val4, val5, val6, minLength, comment = self._assembleCanAction(idx, i, action, this['fifoEntrySize'])
	# 			if self._VERBOSE>1: print("           entry%-6s %06x : %08x -        %6s %06x : %08x %08x %08x %08x  #id=%d%s%s"%(
	# 				'['+str(i)+']', self._rxPduCfgAddr, val1,
	# 				'['+str(i)+']', actionAddr, val3, val4, val5, val6, id,
	# 				"" if (id==upper_range) else f"..{upper_range}",
	# 				comment))
	# 			ra.write(self._rxPduCfgAddr, 32, [val1])
	# 			ra.write(actionAddr, 32, [val3, val4, val5, val6])
	# 			self._rxPduCfgAddr += SIZEOF_s_canFdEntry

	# 			assert id > lastKey, f"if=%d/%x lastId=%d"%(id, id, lastKey)
	# 			lastKey = id

	# 			#place in rule table for Python
	# 			tg = []
	# 			ii = 0
	# 			for tgi, c in enumerate(format(toInt(action['TargetVector']), "b")[::-1]):
	# 				if (c=="1"):
	# 					f = None
	# 					if 'CanIfTxPduCfg' in action and ii < len(action['CanIfTxPduCfg']) and action['CanIfTxPduCfg'][ii]:
	# 						#print(action['CanIfTxPduCfg'])
	# 						f = action['CanIfTxPduCfg'][ii]['frameIdentifier']
	# 					tg.append({"target":tgi, "TxModify":f, "minLength":minLength}) #, "subTag":""})
	# 					ii += 1
	# 			for id in range(id, upper_range+1):
	# 				rtr = 0
	# 				brs = 0
	# 				esi = 0
	# 				fdf = search['CanIfRxPduCanIdType'] == "FD"
	# 				ide = (type=="Id29")
	# 				if (search['CanIfRxPduCanIdType'] == "CCFD"):
	# 					self.rules[-1][cfd_scoreboard_frameTag(idx, id, not fdf, ide, rtr, brs, esi)] = tg
	# 					#print("Register rule:", cfd_scoreboard_frameTag(idx, id, not fdf, ide, rtr, brs, esi))
	# 				self.rules[-1][cfd_scoreboard_frameTag(idx, id, fdf, ide, rtr, brs, esi)] = tg
	# 				#print("Register rule:", cfd_scoreboard_frameTag(idx, id, fdf, ide, rtr, brs, esi))
	# 			#for
	# 		#if type
	# 		actionAddr += SIZEOF_s_canAction
	# 		i += 1
	# 	#the action table is the later part and defines the end address of this container
	# 	self._rxPduCfgAddr = actionAddr
	# 	#sys.exit()
	# #_assembleCanIngressTable


	# #--------------------------------------------------------------------------
	# def _assembleEgressTable(self, this, idx):
	# 	val1 = self._bufferOutAddr
	# 	val2 = this['fifoEntrySize']
	# 	val2 |= this['fifoEntries']<<16

	# 	if "streamGenerate" in this:
	# 		data = this["streamGenerate"]["templateData"]
	# 		template = []
	# 		#Meta in little endian
	# 		for i in range(0,4*4,4):
	# 			template.append((data[i+0]<<24)+(data[i+1]<<16)+(data[i+2]<<8)+(data[i+3]<<0))
	# 		#Data in big
	# 		for i in range(4*4,len(data),4):
	# 			template.append((data[i+0]<<0)+(data[i+1]<<8)+(data[i+2]<<16)+(data[i+3]<<24))

	# 		gen = this["streamGenerate"]
	# 		self.streamsGen.append({"template":template, "outFifoIdx":idx,
	# 			"maxFrameSize":gen["maxFrameSize"], "txTimeout":gen["txTimeout"],
	# 			"patchDataLengthWord":gen["patchDataLengthWord"], "action":gen["action"],
	# 		})
	# 		self.mapFifoToStream[idx]= len(self.streamsGen)-1

	# 		#link this stream in the egress config
	# 		val2 |= self.streamGenHandles<<24
	# 		comment = " --> streamGen#"+str(self.streamGenHandles)
	# 		self.streamGenHandles += 1

	# 	elif "streamTerminate" in this:
	# 		#print(this["streamTerminate"])
	# 		# term = this["streamTerminate"]
	# 		# self.streamsTerm.append({"outFifoIdx":idx,
	# 		# 	"targetExceptionPort":term["targetExceptionPort"], "vPortIndex":term["vPortIndex"]
	# 		# })

	# 		#link this stream in the egress config
	# 		val2 |= self.streamTermHandles<<24
	# 		comment = " --> streamTerm#"+str(self.streamTermHandles)
	# 		self.streamTermHandles += 1

	# 	else:
	# 		val2 |= 255<<24
	# 		comment = ""
	# 	#if stream

	# 	if self._VERBOSE>0: print(" %segressCfg[%02d]         %06x : %08x %08x%s           #FIFO{base=%06x entries=%d size=%d}%s"%(
	# 			YELLOW, idx, self._ingressAddr, val1, val2, NORM,
	# 			self._bufferOutAddr, this['fifoEntries'], this['fifoEntrySize'], comment))
	# 	self.egressBuffer.append({'fifoBaseAddr':self._bufferOutAddr, 'fifoEntrySize':this['fifoEntrySize'], 'fifoEntries':this['fifoEntries']} )
	# 	ra.write(self._ingressAddr, 32, [val1, val2])
	# 	self._ingressAddr += SIZEOF_s_egressConfig
	# 	self._bufferOutAddr += ((this['fifoEntrySize']+127)//128)*128 * this['fifoEntries']
	# #_assembleEgressTable
#class

#some test code
# class ra:
# 	def write(adr, values):
# 		return 0
# raCfg = raConfig('config.json', 2)
