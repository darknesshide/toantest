#include "ra_adrmap.h"
#include "racfg.h"


//static const char dbg_protocolVersionStr[][5] = PROTOCOL_STR;

/*
//-----------------------------------------------------------------------------
//Perform a sanity check of the ingress frame.
//This is not required for a final version when assuming CAN/ETH
//generator IP is working correctly
int dbg_sanity_check_IngressFrame(uint32_t idx)
{
	unsigned addr;
	const union u_fifoEntry *inBuf;
	struct s_ingressConfig *ingress = &raConfig->ingress[idx];

	addr =ingress->fifoBaseAddr + ingress->fifoEntrySize * ingressFifoEntryNumber[idx];
	inBuf = (union u_fifoEntry *)addr;

	//dbg_dump_ptr(inBuf, 0, 4);
	//dbg_print_IngressFrame(idx, ingressFifoEntryNumber[idx]);

	if (inBuf->meta.prot > PROTOCOL_t1s) {
		dbg_printf("\033[93mSANITY: %d Unexpected meta.prot=%d > %d\033[m\n", idx, inBuf->meta.prot, PROTOCOL_t1s);
		return 0;
	}

	if (inBuf->meta.len > ingress->fifoEntrySize) {
		dbg_printf("\033[93mSANITY: %d Oversized ingress data meta.len=%d > %d\033[m\n", idx, inBuf->meta.len, ingress->fifoEntrySize);
		return 0;
	}

	return 1;  //All fine
}
*/


void dbg_checkPythonStarted()
{
	//Check if the python main() was executed by checking a magic number
	if (bram_in32[0] != 0x71829304) {
		dbg_printf("ERROR: No magic number from python.main() found at 0. Got %08x\n", bram_in32[0]);
		exit(-1);
	}
	if (bram_in32[1] != 0xabbadead) {
		dbg_printf("ERROR: No magic number from python.main() found at 1. Got %08x", bram_in32[1]);
		exit(-1);
	}
}


void dbg_printConfiguration(int VERBOSE)
{
	//dbg_printf("%x %x %x  %x  %x\n", &raConfig->maxIngress, &raConfig->cfdIngressEnable, &raConfig->ethIngressEnable,&raConfig->egress, &raConfig->ingressFIFO);
	if (VERBOSE) {
		dbg_printf("Base config:  raConfig=%06x  ingressCfg=%06x (%d inputs) egressCfg=%06x (%d outputs)\n",
		 	raConfig, raConfig->ingress, raConfig->maxIngress, raConfig->egress, raConfig->maxEgress);
		dbg_printf("  ingressFifo:     base=%06x  size=%d\n", raConfig->ingressFIFO.baseAddr, raConfig->ingressFIFO.size8);
		dbg_printf("  vPortFifos:      base=%06x  number=%d  sizes=[", raConfig->vPorts.baseAddr, raConfig->vPorts.number);
		for (int i=0; i<raConfig->vPorts.number && i<100; i++) dbg_printf(" %d", raConfig->vPorts.size8[i]);
		dbg_puts(" ]\n");
		dbg_printf("  egressFifos:     base=%06x  top=%06x\n", raConfig->egress[0].fifoBaseAddr, raConfig->egress[raConfig->maxEgress-1].fifoBaseAddr+raConfig->egress[raConfig->maxEgress-1].fifoEntrySize);
		dbg_printf("  ingressMap:      [");
		int last = 255;
		for (int i=0; i<INGRESS_MAX; i++) {
			if (raConfig->ingressMap[i] != 255) {
				if (last == 255)
					dbg_printf(" %d:%d", i, raConfig->ingressMap[i]);
				else
					dbg_printf(" %d", raConfig->ingressMap[i]);
			}
			last = raConfig->ingressMap[i];
		}
		dbg_puts(" ]\n");
		dbg_printf("  defaultVlans:    [");
		for (int i=0; i<INGRESS_ETH_CNT; i++) dbg_printf(" %d", raConfig->defaultVlan[i]);
		dbg_puts(" ]\n");
		dbg_printf("  FFI Partitions:  [");
		for (int i=0; i<raConfig->maxIngress && i<100; i++) dbg_printf(" %d", raConfig->ingress[i].ingressPartition);
		dbg_puts(" ]\n");
		dbg_printf("  streamGen:       base=%06x  number=%d\n", raConfig->streamGenCfg, raConfig->maxStreamGen);
		//exit(9);
	}
	if (VERBOSE & 2 && 1) {
		for (int i=0; i<raConfig->maxEgress; i++) {
			struct s_egressConfig *egress = &raConfig->egress[i];
			dbg_printf("  egressFifo[%02d]:  base=%06x  entries=%-3d size=%-4d --> to %06x\n",
				i, egress->fifoBaseAddr, egress->fifoEntries, egress->fifoEntrySize,
				egress->fifoBaseAddr + (egress->fifoEntries * egress->fifoEntrySize)
			);
		}
	}
	if (VERBOSE & (4+8+16)) {
		// dbg_printf("%x  %x %x %x %x\n", raConfig->ingress, &raConfig->ingress[0], raConfig->ingress[0], &raConfig->ingress[1], raConfig->ingress[1]);
		dbg_printf("ingress[0]@206194  action@206388  action[0]=20639c\n");
		dbg_printf("@%x  [0]@%x action@%x action=%x action[1]=%x\n", raConfig->ingress, &raConfig->ingress[0], &raConfig->ingress[0].action, raConfig->ingress[0].action, raConfig->ingress[0].action[0]);
		//exit(0);
		for (int i=0; i<raConfig->maxIngress; i++) {
			struct s_ingressConfig *ingress = &raConfig->ingress[i];
			int ch=255;
			for (int j=0; j<raConfig->maxIngress; j++)
				if (raConfig->ingressMap[j] == i) {
					ch = j;
					break;
				}
			dbg_printf("  ingressCfg[%02d]:  channel=\033[94m%d\033[m  offs=%d/%d/%d  ffi=%d  search=%06x/%06x/%06x action=\033[92m%06x\033[m\n", i, ch
				, ingress->tableOffset[0], ingress->tableOffset[1], ingress->tableOffset[2]
				, ingress->ingressPartition
				, ingress->search[0], ingress->search[1], ingress->search[2]
				, ingress->action
			);
			if (VERBOSE &8) {
				for (int j=0; j<3; j++) {
					struct s_lupTable *search = ingress->search[j];
					union u_action **action = &ingress->action[ingress->tableOffset[j]];
					if (search == NULL) continue;
					dbg_printf("    search[%02d][%d]  %06x  sorted=%d linear=%d fmt=%d\n",
						i, j, search,
						search->ctrl.sortedEntries, search->ctrl.linearEntries, search->ctrl.format
					);
					if (VERBOSE &16 && 1) {
						int max = search->ctrl.sortedEntries + search->ctrl.linearEntries+1;
						for (int e=0; e<max; e++) {
							uint8_t *tg;
							if (i < IDA_LAST_CFD) {
								dbg_printf("      \033[32maction[%03d]@%06x:\033[m sizeCheck=%d,%d TxConf=%02x flush=%02x modify=%d targets=[", e, *action
									, (*action)->can.SizeCheckMode, (*action)->can.SizeCheckValue
									, (*action)->can.confirmationReq, (*action)->can.flushOnTarget, (*action)->can.modifyOnTarget
								);
								tg = (*action)->can.targets;
							}
							else {
								dbg_printf("      \033[32maction[%03d]@%06x:\033[m sizeCheck=%d,%d TxConf=%02x searchStream=%d targets=[", e, *action
									, (*action)->eth.SizeCheckMode, (*action)->eth.SizeCheckValue
									, (*action)->eth.confirmationReq, (*action)->eth.searchStream
								);
								tg = (*action)->eth.targets;
							}

							for (int t=0; t<8; t++) {
								if (tg[t] == 255)
									break;
								dbg_printf(" %d", tg[t]);
							}
							dbg_printf(" ]\n");
							action++;
						}
					}
				}
			}
			//exit(0);
		}
	}
	//exit(1);


	// struct s_lupTable *search[MAX_SEARCH_TABLES];  // Points to the unified lookup table
	// union {
	// 	struct s_canAction **can;                 // Points to the specific CAN/ETH lookup tables
	// 	struct s_ethAction **eth;                 // Points to the specific CAN/ETH lookup tables
	// } action;
		// dbg_printf("%x %x   %x %x %x\n", raConfig->search, raConfig->search[0], &raConfig->search[0][0], &raConfig->search[0][1], &raConfig->search[0][2]);
		// dbg_printf("%x  %x  %x  %x\n", &raConfig->search[1][0], &raConfig->search[1][1], &raConfig->search[1][2], &raConfig->search[2][0]);
		// dbg_printf("last=%x\n", &raConfig->last);
	// if (raConfig->maxIngress > INGRESS_MAX) {
	// 	dbg_printf("\033[31mToo many ingress ports (%d) in configuration. C-Code supports INGRESS_MAX=%d.\033[m\n", raConfig->maxIngress, INGRESS_MAX);
	// 	exit(1);
	// }
	// if (raConfig->maxEgress > EGRESS_MAX) {
	// 	dbg_printf("\033[31mToo many egress ports (%d) in configuration. C-Code supports EGRESS_MAX=%d.\033[m\n", raConfig->maxEgress, EGRESS_MAX);
	// 	exit(1);
	// }


	// if (VERBOSE&1) {
	// 	dbg_puts("Buffer configuration\n");
	// 	for (int i=0; i<raConfig->maxIngress; i++) {
	// 		struct s_ingressConfig *ingress = &raConfig->ingress[i];
	// 		dbg_printf("  ingress #%-2d  base=%06x  entries=%-3d size=%-4d  --> to %06x\n",
	// 			i, ingress->fifoBaseAddr, ingress->fifoEntries, ingress->fifoEntrySize,
	// 			ingress->fifoBaseAddr + (ingress->fifoEntries * ingress->fifoEntrySize)
	// 		);
	// 	}
	// }

	// if (VERBOSE&2 || VERBOSE&4) {
	// 	dbg_puts("Ingress Tables\n");
	// 	for (int i=0; i<raConfig->maxIngress; i++) {
	// 		struct s_ingressConfig *ingress = &raConfig->ingress[i];
	// 		for (int j=0; j<3; j++) {
	// 			struct s_lookupTable *search = ingress->table.rxPduCfg[j].search;
	// 			dbg_printf("  rxPduCfg[%02d][%d]  search->%06x  action->%06x    #search{bin=%d lin=%d fmt=%d}\n",
	// 				i, j, ingress->table.rxPduCfg[j].search, ingress->table.rxPduCfg[j].action,
	// 				search->ctrl.sortedEntries, search->ctrl.linearEntries, search->ctrl.format
	// 			);
	// 			if (VERBOSE&4) {
	// 				struct s_canAction *action = ingress->table.rxPduCfg[j].action;
	// 				dbg_printf("     cfg  %06x : %08x               default --> tg=%x m1=%d\n",
	// 					ingress->table.rxPduCfg[j].search, ingress->table.rxPduCfg[j].search->ctrl,
	// 					action[-1].TargetVector, action[-1].CanIfRxPduId);
	// 				for (int e=0; e<search->ctrl.sortedEntries; e++) {
	// 						dbg_printf("     %3d  %06x : %08x    #fmt=%d  id=%d..%d  --> tg=%x m1=%d\n",
	// 						e, &search->entries[e], search->entries[e],
	// 						(search->entries[e]>>22)&0x7, search->entries[e]&0x7ff, (search->entries[e]>>11)&0x7ff,
	// 						action[e].TargetVector, action[e].CanIfRxPduId
	// 					);
	// 				}
	// 			}
	// 		}
	// 	}
	// }

	// if (VERBOSE&0x10) {
	// 	dbg_puts("Stream Generation Tables\n");
	// 	//struct s_1722streamGen (*streamGenCfgList)[] = raConfig->streamGenCfg;
	// 	for (int i=0; i<raConfig->maxStreamGen; i++) {
	// 		struct s_1722streamGen *streamGenCfg = raConfig->streamGenCfg[i];
	// 		dbg_printf("  streamGen[%d] %06x -> template=%d size=%d timeOut=%d\n",
	// 				i, streamGenCfg, streamGenCfg->templateLength, streamGenCfg->maxFrameSize, streamGenCfg->txTimeout
	// 		);
	// 	}
	// }

	// if (VERBOSE&0x20) {
	// 	dbg_puts("Stream Termination Tables\n");
	// 	//struct s_1722streamGen (*streamGenCfgList)[] = raConfig->streamGenCfg;
	// 	for (int i=0; i<raConfig->dbg_maxStreamTerm; i++) {
	// 		struct s_1722streamTerm *streamGenTerm = raConfig->streamTermCfg[i];
	// 		dbg_printf("  streamTerm[%d] %06x -> vPortIndex=%d exceptionPortIndex=%d\n",
	// 				i, streamGenTerm, streamGenTerm->vPortIndex, streamGenTerm->exceptionPortIndex
	// 		);
	// 	}
	// }

	// if (VERBOSE&2) {
	// 	for (int i=0; i<raConfig->maxIngress; i++) {
	// 		struct s_ingressConfig *ingress = &raConfig->ingress[i];
	// 		for (int j=0; j<3; j++) {
	// 			union u_canEntry *entries = ingress->rxPduCfg[j].entries;
	// 			struct s_canAction *actions = ingress->rxPduCfg[j].actions;
	// 			dbg_printf("rxPduCfg Table ---  #%d  type=%s  e-> %p  s-> %p\n",
	// 				i, dbg_tableFormatStr[j], entries, actions);
	// 			dbg_puts("                              default  ");
	// 			dbg_printAction(&ingress->rxPduCfg[j].defaultAction);
	// 			dbg_putnl();

	// 			for (int t=0; t<ingress->rxPduCfg[j].tableEntries; t++) {
	// 				dbg_printf("%5d [", t);
	// 				if (j==0)
	// 					dbg_printf("%5d %s             ",
	// 						entries->fd[t].CanIfRxPduCanId&((1<<11)-1),
	// 						dbg_acceptanceStr[entries->fd[t].CanIfRxPduCanId>>14]);
	// 				else if (j==1)
	// 					dbg_printf("%5d %08x %3d %3d ", entries->xl[t].CanIfXLPriorityId,
	// 						entries->xl[t].CanIfXLAcceptanceField, entries->xl[t].CanIfXLSduType,
	// 						entries->xl[t].CanIfXLVcid);
	// 				else
	// 					dbg_printf("%5d %s", entries->fd[t].CanIfRxPduCanId&((1<<29)-1),
	// 						dbg_acceptanceStr[entries->fd[t].CanIfRxPduCanId>>30]);
	// 				dbg_putp(&actions[t]);
	// 				dbg_putspc();
	// 				dbg_printAction(&actions[t]);
	// 				dbg_puts(" ]\n");
	// 			}
	// 		}
	// 	}
	// }
}

/*
void dbg_print_IngressFrame(int bus, int entry)
{
	unsigned addr, meta;
	struct s_ingressConfig *ingress = &raConfig->ingress[bus];
	union u_fifoEntry *buf;

	addr = ingress->fifoBaseAddr + ingress->fifoEntrySize * entry;
	buf = (union u_fifoEntry *)addr;

	dbg_printf("dbg_print_IngressFrame : Ingress %c %d [%08x] Prot=%s Len=%d",
		bus + 'A',
		entry,
		addr,
		dbg_protocolVersionStr[buf->meta.prot],
		buf->meta.len);

	switch (buf->meta.prot) {
	case PROTOCOL_bff:
	case PROTOCOL_eff:
	case PROTOCOL_xlff:
	case PROTOCOL_ccr:
		// CAN Frame Info
		dbg_printf(" - ID=0x%08x  DLC=%d\n", buf->can.id, buf->can.len);
		meta = 7;
		break;

	case PROTOCOL_t1s:
		// Ethernet Frame Info
		dbg_printf("\n");
		meta = 4;
		break;

	default:
		dbg_puts(" !! Unknown protocol\n");
		return;
	}

	dbg_puts("  Meta data:");
	for (unsigned i = 0; i < meta; i++) {
		dbg_putspc();
		PRINT_U32X = buf->data32[i];
	}
	dbg_puts("\n  Payload:");
	#define MAXDATA 30
	for (unsigned i = 0; i < buf->meta.len && i < MAXDATA; i++) {
		dbg_putspc();
		PRINT_U8X = buf->data8[meta*4+i];
	}
	if (buf->meta.len > MAXDATA)
		dbg_puts(" ...");
	dbg_putnl();
	// dbg_dump_ptr(buf, 0, 4);
}
*/
