

#define ETND_RX_DESCR_OFFSET 0x10000

#define ETND_DESCR_BASE (SRAM_BASE8 + ETND_RX_DESCR_OFFSET) // position of the RX Descriptor Chain in memory

// #define ETND_CHANNELS        7 // coming from racfg.h INGRESS_ETH_CNT
#define RX_CHAIN_ENTRY       4
#define RX_CHAIN_SIZE        (RX_CHAIN_ENTRY + 1)
#define FRAME_SIZE        2048
#define FEMPTY               4
#define FSINGLE              8
#define LEMPTY              12
#define LINK                14


// structure for Basic Descriptor format with Timestamp
struct s_descr_basic {
    unsigned ds    : 12;  // 12-bit DS
    unsigned rsv0  : 16;  // INFO0, DSE, AXIE, DIE not used, all set as 0
    unsigned dt    : 4;   // 4-bit DT
    uint32_t dptr;        // pointer to a RAM address
    uint32_t tsns;        // Timestamps nanosecond
    uint32_t tss;         // Timestamps second
};

// structure for Extended Descriptor format with Timestamp
struct s_descr_extd {
    unsigned ds    : 12;  // 12-bit DS
    unsigned rsv0  : 16;  // INFO0, DSE, AXIE, DIE not used, all set as 0
    unsigned dt    : 4;   // 4-bit DT
    uint32_t dptr;        // pointer to a RAM address
    uint32_t tsl;         // First part of INFO1: TFL is used (set equal to DS), all other set to 0
    uint32_t rsv1;        // Second part of INFO1: not used, all set as 0
    uint32_t tsns;        // Timestamps nanosecond
    uint32_t tss;         // Timestamps second
};
