#ifndef __RACFG_H__
#define __RACFG_H__

#include <stdint.h>
#include "ra_adrmap.h"

#include "packedFifo.h"


//Maximum numbers for internal data structures,
//real numbers are coming dynamically from json via raConfig. This number defines only the size of the mapping vector
#define INGRESS_MAX         116

//Split the IDA input range between XL and ETH
#define INGRESS_CFD_CNT     (IDA_LAST_CFD-IDA_FIRST_CFD+1)
#define INGRESS_XL_CNT      (IDA_LAST_XL-IDA_FIRST_XL+1)
#define INGRESS_ETH_CNT     (IDA_LAST_ETH-IDA_FIRST_ETH+1)

//Magic numbers to be aligned with configuration
#define INGRESS_FIRST_VPORT 84   //vPorts
#define EGRESS_FIRST_STREAM 190  //artificial target number above the physical range

#define STREAM_GEN_MAX      8
#define STREAM_TERM_MAX     10

#define VPORT_MAX           32


#define EGRESS_MAX          32



//-----------------------------------------------------------------------------
//Sanity checks
#if INGRESS_MAX%4 != 0
#error "INGRESS_MAX needs multiple of 4"
#endif
#if (INGRESS_ETH_CNT)%2 != 0
#error "Number of Ethernet ports needs multiple of 2"
#endif
#if (INGRESS_FIRST_VPORT+VPORT_MAX) != INGRESS_MAX
#error "Inconsistent ingress port configuration"
#endif
#if EGRESS_FIRST_STREAM < INGRESS_MAX
#error "Inconsistent ingress port configuration"
#endif

//=============================================================================
//===== Statistic counters (per port)
//=============================================================================
#define GENERATE_ENUM(ENUM) ENUM,
#define GENERATE_STRING(STRING) #STRING,

#define THE_INGRESS_COUNTERS(C) \
	C(IN_TOTAL) C(IN_FAULTY) C(IN_LEN_ERR)
#define THE_EGRESS_COUNTERS(C) \
	C(CNT_TX_BYTES) C(CNT_TX_TOTAL) C(CNT_TX_BUSY) C(CNT_TX_TRUNC) \
	C(CNT_TX_MODIFY)

enum e_rxCounters { THE_INGRESS_COUNTERS(GENERATE_ENUM) LAST_COUNTER_INGRESS };
enum e_txCounters { THE_EGRESS_COUNTERS(GENERATE_ENUM) LAST_COUNTER_EGRESS };
// placed in shared RAM: countersIngress[INGRESS_MAX][LAST_COUNTER_INGRESS];
// placed in shared RAM: countersEgress[EGRESS_MAX][LAST_COUNTER_EGRESS];


//=============================================================================
//===== CAN format configurations in FIFO buffers
//=============================================================================

// #define CAN_VER_C20s  0
// #define CAN_VER_CFDs  1
// #define CAN_VER_C20x  2
// #define CAN_VER_CFDx  3
// #define CAN_VER_CXL   4

// #define CAN_VERSION_STR {"CCb", "FDb", "CCe", "FDe", "XL "}

// #define PROTOCOL_STR {"bff", "eff", "xlff", "t1s", "ccr"}
#define PROTOCOL_bff  0 // CC and FD frame with standard identifier
#define PROTOCOL_eff  1 // CC and FD frame with extended identifier
// #define PROTOCOL_xlff 2 // XL frame
#define PROTOCOL_eth  3 // Ethernet/T1S frame
// #define PROTOCOL_ccr  4 // CC remote frame


//=============================================================================
//====== Defines for CAN to Eth and ETH to CAN configuration
//=============================================================================

//MAX_SEARCH_TABLES is maximum of both enums
enum e_canTableFormat {ID11, ID29, XL, MAX_SEARCH_TABLES};
enum e_ethTableFormat {MAC_VLAN, STREAM1722};


struct s_fifoEntryMeta {
	//common meta header M0~M3
	unsigned len   : 12; //M0
	unsigned rsv1  :  3;
	unsigned ti    :  1;
	unsigned prot  :  4;
	unsigned rsv2  :  4;
	unsigned ipn   :  8;
	//unsigned tsrq  :  1;
	unsigned rule1 : 16; //M1
	unsigned rule2 : 16;
	unsigned ts_l  : 32; //M2
	unsigned ts_h  : 32; //M3
};

struct s_fifoEntryCan {
	//common meta header M0~M3
	struct s_fifoEntryMeta meta;

	//CAN specific header H0~H2, M4~M6
	unsigned id    : 29;
	unsigned rsv1  :  1;
	unsigned cc    :  1;
	unsigned fd    :  1;

	unsigned sdt   :  8;
	unsigned vcid  :  8;
	unsigned sec   :  1;
	unsigned esi   :  1;
	unsigned brs   :  1;
	unsigned rtr   :  1;
	unsigned rsv2  : 12;

	unsigned af    : 32;

	//CAN payload data (at 32-bit offset 7)
	uint8_t data[64]; //this struct is used for casting only, the real size is controlled outside
};
#define FIFO_CAN_HEADER_SIZE8 (16+12)  //12 bytes for CAN header

struct s_fifoEntryEth {
	//common meta header M0~M3
	struct s_fifoEntryMeta meta;

	//Ethernet payload data (at 32-bit offset 4)
	uint8_t data[64]; //this struct is used for casting only, the real size is controlled outside
};
#define FIFO_ETH_HEADER_SIZE8 (16+2)  //2 bytes for payload alignment


union u_fifoEntry {
	struct s_fifoEntryMeta meta;
	struct s_fifoEntryCan  can;
	struct s_fifoEntryEth  eth;
	uint8_t                data8[1];  //this struct is used for casting only, the real size is controlled outside
	uint32_t               data32[1]; //this struct is used for casting only, the real size is controlled outside
};


//=============================================================================
//====== Structures for ingress and table configuration
//=============================================================================
enum e_sizeCheckMode {NONE, SE, EQ, GE};

union u_canIfTxPduCfg {
	uint32_t    val32[2];
	//the field 'protocol' must at the same position in both structures
	struct s_canIfTxPduCfg {
		unsigned canId      : 29;
		unsigned protocol   :  2;  //as per PROTOCOL 0~2 (0=bff, 1=eff, 2=xlff)
		unsigned protocolFD :  1;  //on protocol = 0,1   (same bit as in meta)
	} can;
	struct s_canXLIfTxPduCfg {
		unsigned sduType    :  8;  //CanIfXLSduType
		unsigned vcid       :  8;  //CanIfXLVcid
		unsigned canId      : 11;  //CanIfXLPriorityId
		unsigned reserved   :  2;  //to keep protocol and protocolFD at the same position
		unsigned protocol   :  2;  //as per PROTOCOL 0~2 (0=bff, 1=eff, 2=xlff)
		unsigned protocolFD :  1;  //on protocol = 0,1   (same bit as in meta)
		unsigned acceptance : 32;  //CanIfXLAcceptanceField
	} xl;
};

struct s_canAction {
	unsigned                SizeCheckValue  :16; //:12  min size of PDU
	unsigned                SizeCheckMode   :4;  //:2  "none <= == >="
	unsigned                modifyOnTarget  :4;  //number of modification rules
	unsigned             	confirmationReq :8;  //each bit enables this on one target

	unsigned             	flushOnTarget   :8;  //each bit triggers flush on a stream target
	uint8_t                 targets[8];          //0xff means no target
	uint8_t                 reserved[3];
	union u_canIfTxPduCfg   modifyRules[];       //this array cannot used indexed, because the structure size of CAN and XL differs
};

struct s_ethAction {
	unsigned                SizeCheckValue  :16;  //min size of PDU
	unsigned                SizeCheckMode   :4;   //"none <= == >="
	unsigned                searchStream    :1;
	unsigned                reserved        :3;
	unsigned             	confirmationReq :8;  //each bit enables this on one target

	uint8_t                 targets[8];          //0xff means no target (targets 4~7 are skipped if 255 used before)
};

struct s_streamAction {
	uint8_t                 streamUnit;          //additional stream target (0~31, own number range), 0xff means no target
	uint8_t                 subTarget;           //replaced (CPU) target, 0xff means no replacement (common target number range)
	uint16_t                reserved;
};

union u_action {
	struct s_canAction    can;
	struct s_ethAction    eth;
	struct s_streamAction stream;
};

struct s_ingressConfig {
	uint16_t tableOffset[MAX_SEARCH_TABLES];       //MAX_SEARCH_TABLES is fixed to 3 in current firmware
	uint8_t  ingressPartition;                     //FFI Partition relation of each search table group (one per ingress)
	uint8_t  gen1722_bus_id;                       //Number used in 1722 stream generation to fill the bus_id field
	struct s_lupTable *search[MAX_SEARCH_TABLES];  //Points to the unified lookup table
	union u_action    **action;                    //Points to the specific CAN/ETH lookup tables
};


//=============================================================================
//====== Structures for stream handling
//=============================================================================
struct s_streamGen {
	uint8_t		       templateLength8;
	uint8_t		       patchDataLengthPos32;
	uint16_t           reserved;

	uint16_t           maxFrameSize;
	uint8_t            txTimeout;          //in 200µs (0=immediately, 200µs - 50 ms)
	uint8_t            maxContainers;

	uint8_t            targets[8];         //0xff means no target
	union u_fifoEntry  *buffer;

	uint32_t           template[];
};

struct s_streamTerm {
	struct s_ethAction exceptionTarget;
	struct s_ethAction containerTarget;

	uint8_t            busId2vPort[32];   //allows lookup of 5-bit bus_id used in v1 containers
};


//=============================================================================
//=============================================================================
struct s_egressConfig {
	uint32_t fifoBaseAddr;
	uint16_t fifoEntrySize;
	uint8_t  fifoEntries;
	int8_t   streamHandle;  //-1 for no stream (in case of ETH->s_1722streamTerm, CAN->s_1722streamGen
};


//=============================================================================
//====== Structures for the buffer configuration
//=============================================================================
struct s_fifoConfig {
	void     *baseAddr;
	uint32_t size8;
};

struct s_vPortConfig {
	void     *baseAddr;             //base address of first buffer
	uint8_t  number;
	uint8_t  reserved[3];
	uint16_t size8[VPORT_MAX];
};


//=============================================================================
//====== Main configuration structure
//=============================================================================

struct s_raConfig {
	uint8_t  maxIngress;
	uint8_t  maxEgress;
	uint8_t  maxStreamGen;         //required for sequence number extraction in init code
	uint8_t  reserved1;
	//uint8_t  dbg_maxStreamTerm;  //only for printout

	uint32_t cfdIngressEnable;     //each bit defines an utilised CDF channel
	uint16_t ethIngressEnable;     //each bit defines an utilised ETH channel (RSW, ES, T1S)
	uint16_t reserved2;

	struct s_ingressConfig *ingress;  //pointer to a list of ingress structures
	struct s_egressConfig  *egress;   //pointer to a list of egress structures
	struct s_streamGen     **streamGenCfg;   //defined inside a list of pointers, structures have no unique size
	struct s_streamTerm    *streamTermCfg;   //pointer to array as structures have known size

	struct s_fifoConfig    ingressFIFO;
	struct s_vPortConfig   vPorts;
	uint8_t                ingressMap[INGRESS_MAX];
	uint16_t               defaultVlan[INGRESS_ETH_CNT];

	// struct s_1722streamTerm **streamTermCfg; //defined inside a list of pointers to allow 8bit index in CAN action
};


//=============================================================================
//====== Global symbols
//=============================================================================
//This is our global configuration variable
extern const struct s_raConfig *raConfig;

//from shared_data.h
extern volatile uint32_t vPortPending;

//some helpers for debug from canhw_dbg.c
//extern uint8_t ingressFifoEntryNumber[];
void dbg_checkPythonStarted();
void dbg_printConfiguration(int VERBOSE);
void dbg_print_IngressFrame(int idx, int page);
int  dbg_sanity_check_IngressFrame(uint32_t idx);

//Stream handling in conv_stream.c
void stream_init(volatile struct s_packedFifo *vPortFIFO);
int stream_generate(const union u_fifoEntry *inBuf, const int stream, const struct s_streamGen *streamGenCfg, const int flushOnTarget, const unsigned gen1722_bus_id);
int stream_terminate(const union u_fifoEntry *inBuf,  const int stream, volatile struct s_packedFifo *vPortFIFO);


//-----------------------------------------------------------------------------
#ifdef USE_LOOKUP_HW
inline static void lookup32_start(const struct s_lupTable *tab, uint32_t value)
{
	lup_value[0] = value;
	lup_table = tab;
}
inline static int lookup32_result(void)
{
	while (lup_status & 0x80000000);
	return lup_found;
}

inline static void lookup64_start(const struct s_lupTable *tab, uint64_t value)
{
	lup_value[0] = value & 0xffffffff;
	lup_value[1] = value >> 32;
	lup_table = tab;
}
inline static int lookup64_result(void)
{
	while (lup_status & 0x80000000);
	return lup_found;
}
#else
int lookup32(const struct s_lupTable *tab, uint32_t value); //the software function
int lookup64(const struct s_lupTable *tab, uint64_t value);
#endif


#ifdef USE_COPY_HW
inline static void bufferCpy(uint32_t *tgBuf, const uint32_t *srcBuf, uint32_t cnt8)
{
	dcm_rta[0] = tgBuf;
	dcm_rsa = srcBuf;
	dcm_len = cnt8+3;
	while (dcm_stat&0x80000000);
}
#else
#include <string.h>
inline static void bufferCpy(uint32_t *tgBuf, const uint32_t *srcBuf, uint32_t cnt8)
{
	//dbg_printf("memcpy(%p, %p, %d)\n", tgBuf, srcBuf, (cnt8+3)&0xfffffffc);
	memcpy(tgBuf, srcBuf, (cnt8+3)&0xfffffffc);
}
#endif

#endif
