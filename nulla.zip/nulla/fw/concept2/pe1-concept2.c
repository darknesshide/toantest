//#define NDEBUG        //define disables all assertion code

#define USE_LOOKUP_HW


//Some debug and measurement configurations
#define VERBOSE_GENERAL
#ifdef VERBOSE_GENERAL
	#define VERBOSE_CLASSIFY
	#define VERBOSE_FORWARD
#endif


//-------------------------------------------------------------------
#include "ra_adrmap.h"
#include "racfg.h"         //Configuration of RA system

#include "../../apps/packedFifo.h"
#include "shared_data.h"


//Configuration **************************************************
#define RA_CONFIG_ADDR      0x6000   //Address inside dram

const struct s_raConfig *raConfig;


//Internal variables *****************************************
//uint8_t ingressFifoEntryNumber[INGRESS_MAX];  //used in dbg_
static uint8_t egressFifoEntryNumber[EGRESS_MAX];

//a common variable for 'no stream action'
static const struct s_streamAction no_saction = {255, 255, 0};


//-----------------------------------------------------------------------------
//----- CAN processing path
//-----------------------------------------------------------------------------
static void can_processing(const struct s_canAction *action, const union u_fifoEntry *srcBuf, unsigned gen1722_bus_id)
{
	int modifyOnTarget, flushOnTarget;
	const union u_canIfTxPduCfg *modifyRules;

	modifyOnTarget = action->modifyOnTarget;
	modifyRules = action->modifyRules;
	flushOnTarget = action->flushOnTarget;

	//Loop over all targets
	for (int i=0; (i<8) && (action->targets[i] != 255); i++) {
		int tg = action->targets[i];
		dbg_printf("   i=%d  target=%d\n", i, tg);
		//TODO: reactivate full handling
		// if (buf_out_full & mask) {
		// 	countersTx[tg][CNT_TX_BUSY]++;
		//	continue;
		//}

		// ========== ACF handling: egress-type is Ethernet => CAN to Ethernet
		if (tg >= EGRESS_FIRST_STREAM) {
			int stream = tg - EGRESS_FIRST_STREAM;

			dbg_printf("   CAN%d->SG%d: flushOnTarget=%x bus_id=%d\n", srcBuf->meta.ipn, stream, flushOnTarget, gen1722_bus_id);
			int sendBytes = stream_generate(srcBuf, stream, raConfig->streamGenCfg[stream], flushOnTarget&1, gen1722_bus_id);
			//dbg_printf("      stream generator request %d/%x bytes for transmission\n", sendBytes, sendBytes);

			//For ETH targets there is no direct buffer release
			if (sendBytes) {
				uint8_t *stg = raConfig->streamGenCfg[stream]->targets;
				const union u_fifoEntry *streamBuf = raConfig->streamGenCfg[stream]->buffer;
				//dbg_dump_ptr(streamBuf, 0, (sendBytes+15)/16);
				for (int i=0; *stg!= 255 && i<8; i++) {
					//TODO: missing full handling
					struct s_egressConfig *egress = &raConfig->egress[*stg];
					union u_fifoEntry *tgBuf = (union u_fifoEntry*)(egress->fifoBaseAddr + egress->fifoEntrySize * egressFifoEntryNumber[*stg]);
					dbg_printf("   SG%d->ETH%d: %x <= %x, %d (max=%d, targetConfig=%x)\n", stream, *stg, tgBuf, streamBuf, sendBytes, egress->fifoEntrySize, egress);

					//TODO: Do we need a size check / truncation as for normal forwarding?
					bufferCpy(tgBuf->data32, streamBuf->data32, sendBytes);
					//dbg_dump_ptr(tgBuf, 0, (sendBytes+15)/16);

					countersEgress[*stg][CNT_TX_BYTES] += sendBytes-FIFO_ETH_HEADER_SIZE8;
					countersEgress[*stg][CNT_TX_TOTAL]++;
					//And release the target buffer for tranmission
					buf_out_inc |= (1<<*stg);
					egressFifoEntryNumber[*stg] = (egressFifoEntryNumber[*stg]+1) % egress->fifoEntries;
					stg++;
				}
			}
			flushOnTarget >>= 1;
		}
		// ========== CAN handling: egress-type is CAN => CAN to CAN
		else {
			int truncated, payload_length8;
			struct s_egressConfig *egress = &raConfig->egress[tg];
			union u_fifoEntry *tgBuf = (union u_fifoEntry*)(egress->fifoBaseAddr + egress->fifoEntrySize * egressFifoEntryNumber[tg]);
			dbg_printf("  CAN%d->CAN%d: %x <= %x, %d (max=%d, targetConfig=%x)\n", srcBuf->meta.ipn, tg, tgBuf, srcBuf, srcBuf->meta.len+FIFO_CAN_HEADER_SIZE8, egress->fifoEntrySize, egress);

			//truncation in case target buffer is smaller (typically a configuration fault)
			if (srcBuf->meta.len+FIFO_CAN_HEADER_SIZE8 > egress->fifoEntrySize){
				payload_length8 = egress->fifoEntrySize - FIFO_CAN_HEADER_SIZE8;
				truncated = 1;
				countersEgress[tg][CNT_TX_TRUNC]++;
			}
			else {
				payload_length8 = srcBuf->meta.len;
				truncated = 0;
			}
			countersEgress[tg][CNT_TX_BYTES] += payload_length8;
			countersEgress[tg][CNT_TX_TOTAL]++;

			//Copy the data
			bufferCpy(tgBuf->data32, srcBuf->data32, payload_length8+FIFO_CAN_HEADER_SIZE8); //some fields are updated later

			//Reformat the header M0 if this is requested (modification is always mapped to the first targets)
			if (modifyOnTarget) {
				//dbg_printf("   modify %08x %08x modify=%08x (%d %d %x)\n", srcBuf->data32[0], srcBuf->data32[4], modify->val32, modify->field.protocolFD, modify->field.protocol, modify->field.canId);
				countersEgress[tg][CNT_TX_MODIFY]++;

				//tgBuf[0] = (srcBuf->data32[0]&0xfff00000) + (modify->protocol<<16) + (truncated<<15) + payload_length8;
				tgBuf->data32[0] = (srcBuf->data32[0]&0xfff00000) + ((modifyRules->val32[0]>>13)&0x30000) + (truncated<<15) + payload_length8;  //manual extract of protocol is faster on GCC/RV
				tgBuf->data32[4] = (modifyRules->val32[0] & 0x9ffffffff) + ((!modifyRules->can.protocolFD)<<30);

				modifyRules++; //next multicast uses the next rule
				modifyOnTarget--;
			}
			else if (truncated) {
				tgBuf->data32[0] = (srcBuf->data32[0] & 0xffff0000) | (1<<15) | payload_length8;
				//dbg_printf("   truncate to %d\n", payload_length8);
				//TODO: Missing exception handling, not all interfaces can egress truncated frames
			}

			//And release the target buffer for tranmission
			buf_out_inc |= (1 << tg);	//TODO: Copy can speedup by copy all targets in parallel
			egressFifoEntryNumber[tg] = (egressFifoEntryNumber[tg]+1) % egress->fifoEntries;
		}
	}
}


//-----------------------------------------------------------------------------
//----- ETH processing path
//-----------------------------------------------------------------------------
static void eth_processing(const struct s_ethAction *action, const struct s_streamAction *saction, const union u_fifoEntry *srcBuf)
{
	uint16_t payload_length8;
	uint8_t truncated;

	dbg_printf("eth_processing()  tg[0]=%d  tg[1]=%d\n", action->targets[0], action->targets[1]);
	dbg_printf("   stream: %06x:  unit=%d sub=%d\n", saction, saction->streamUnit, saction->subTarget);

	//Loop over all ethernet targets
	for (int i=0; (i<8) && (action->targets[i] != 255); i++) {
		int tg = action->targets[i];
		dbg_printf("   i=%d  target=%d\n", i, tg);

		//Temporary skip all out of range targets because CPU is not yet implemented
		if (tg > raConfig->maxEgress) {
			dbg_printf("   ETH%d->ETH%d: Skipped as target is out of range (TODO)\n", srcBuf->meta.ipn, tg);
			continue;
		}
		//Skip if the target is replaced by stream processing
		if (tg == saction->subTarget) {
			dbg_printf("   ETH%d->ETH%d: Replaced by Stream Offloading\n", srcBuf->meta.ipn, tg);
			continue;
		}
		//Do not store if target buffer is full
		if (buf_out_full & (1 << tg)) {
			countersEgress[tg][CNT_TX_BUSY]++;
			continue;
		}

		struct s_egressConfig *egress = &raConfig->egress[tg];
		union u_fifoEntry *tgBuf = (union u_fifoEntry*)(egress->fifoBaseAddr + egress->fifoEntrySize * egressFifoEntryNumber[tg]);

		if (srcBuf->meta.len + FIFO_ETH_HEADER_SIZE8 > egress->fifoEntrySize) {
			payload_length8 = egress->fifoEntrySize - FIFO_ETH_HEADER_SIZE8;
			truncated = 1;
			countersEgress[tg][CNT_TX_TRUNC]++;
		}
		else {
			payload_length8 = srcBuf->meta.len;
			truncated = 0;
		}
		countersEgress[tg][CNT_TX_BYTES] += payload_length8;
		countersEgress[tg][CNT_TX_TOTAL]++;

		//Copy the data
		dbg_printf("   ETH%d->TG%d: %x <= %x, %d (max=%d, targetConfig=%x) cpLen=%d trunc=%d\n", srcBuf->meta.ipn, tg, tgBuf, srcBuf, srcBuf->meta.len+FIFO_ETH_HEADER_SIZE8, egress->fifoEntrySize, egress, payload_length8, truncated);
		//dbg_dump_ptr(srcBuf, 0, (srcBuf->meta.len+FIFO_ETH_HEADER_SIZE8+15)/16);
		bufferCpy(tgBuf->data32, srcBuf->data32, payload_length8+FIFO_ETH_HEADER_SIZE8);  //some fields are updated later

		// Update the target header (first 16 bytes)
		if (truncated) {
			tgBuf->data32[0] = (srcBuf->data32[0] & 0xffff0000) | (1<<15) | payload_length8;
			assert(payload_length8>20);  //such small frames are never expected
			//dbg_printf("   truncate to %d\n", payload_length8);
			//TODO: Missing exception handling, not all interfaces can egress truncated frames
		}
		//dbg_dump_ptr(tgBuf, 0, (payload_length8+FIFO_ETH_HEADER_SIZE8+15)/16);

		//And release the target buffer for tranmission
		buf_out_inc |= (1 << tg);	//TODO: Copy can speedup by copy all targets in parallel
		egressFifoEntryNumber[tg] = (egressFifoEntryNumber[tg] + 1) % egress->fifoEntries;
	}

	//Stream target for termination
	if (saction->streamUnit != 255) {
		int stream = saction->streamUnit;  //already in stream address number space
		dbg_printf("   ETH%d->ST%d: vPorts <= %x  length=%d\n", srcBuf->meta.ipn, stream, srcBuf, srcBuf->meta.len+FIFO_ETH_HEADER_SIZE8);
		// 	struct s_1722streamTerm *term = raConfig->streamTermCfg[egress->streamHandle];
		// 	//dbg_printf("   ETH/CAN ->%d: streamHandle=%d vPort=%d  %x <= %x, %d (%d)  targetConfig=%x\n", tg, egress->streamHandle, term->vPortIndex, tgBuf, inBuf, inBuf->eth.len+FIFO_ETH_HEADER_SIZE8, egress->fifoEntrySize, egress);

		// 	//For the ACF extraction the target is the vPort ingress FIFO to store the CAN frames.
		// 	//The egressBuffer itself is not used. The egressFifoEntryNumber of the unused streamTarget is
		// 	//used to count the position inside the vPort ingress FIFO
		// 	//TODO
		// 	//Currently there is storage of the complete ethernet frame (decoding on the fly) this
		// 	//not the final solution, because it takes too long processing time.
		// 	int vPort = term->vPortIndex;
		// 	struct s_ingressConfig *vPortIn = &raConfig->ingress[vPort]; //because we need to fill this
		int problem = stream_terminate(srcBuf, stream, vPortFIFO);
		if (problem) {
			#ifdef VERBOSE_FORWARD
				dbg_printf("   Trigger forward to exceptionPortIndex=%d\n", raConfig->streamTermCfg[stream].exceptionTarget.targets[0]);
			#endif
			eth_processing(&raConfig->streamTermCfg[stream].exceptionTarget, &no_saction, srcBuf);
		}
	}
}


//-------------------------------------------------------------------
int main(void)
{
	#ifdef VERBOSE_GENERAL
		dbg_printf("Processing Stage main() on PE %d\n", cpuHartId());
	#endif

	//Initialisation code
	raConfig = (struct s_raConfig*)&dram32[RA_CONFIG_ADDR/4];
	#if defined(VERBOSE_GENERAL) || 0
		//dbg_dump_ptr(raConfig, 32, 8);
		dbg_printConfiguration(0x1);  //1=general, 2=egress, 4/8/10=ingressTables, 100=streamGen, 200=streamTerm
		//return 0;
	#endif
	vPortPending = 0;
	stream_init(vPortFIFO);
	memset(egressFifoEntryNumber, 0, sizeof(egressFifoEntryNumber));


	//TODO: wait for others PEs
	//inform ingress that all config is done
	ipc_request(INGRESS_STAGE, IPC_CONFIG_DONE);


	//No timeout handling added on this PE, because the timeout
	//on ingress stage terminates whole testcase.
	while (1) {
		union u_fifoEntry *srcBuf;
		volatile struct s_packedFifo *srcFIFO;

		//simple arbitration between Ingress Stage (high) and vPort (low)
		srcBuf = NULL;
		if (!IPC_GET(PE_SELF, IPC_INGRESS_FIFO)) {
			for (uint32_t i=0, mask=1; i<VPORT_MAX; i++, mask<<=1) {
				if (vPortPending & mask) {
					dbg_printf("vPort[%d] has pending frames\n", i);
					srcBuf = packedFifo_nextGet(&vPortFIFO[i]);
					dbg_printf("Processing from vPort[%d] at %06x\n", i, srcBuf);
					if (srcBuf) {
						srcFIFO = &vPortFIFO[i];
						break;
					}
					else
						vPortPending &= ~mask;  //clear the request
				}
			}
		}
		if (srcBuf == NULL) {
			//IPC channel 0 is used to get frames from input FIFO
			dbg_printf("Wait for frame in Rx-FIFO...\n");
			while (!IPC_GET(PE_SELF, IPC_INGRESS_FIFO));
			for (volatile int i=0; i<100; i++);  //prevent overlapping prints
			srcBuf = packedFifo_nextGet(&ingressFIFO);
			dbg_printf("Processing from ingressFIFO at %06x\n", srcBuf);
			srcFIFO = &ingressFIFO;
		}

		//Perform the processing
		assert(srcBuf);
		int channel = srcBuf->meta.ipn;
		int idx = raConfig->ingressMap[channel];
		struct s_ingressConfig *ingress = &raConfig->ingress[idx];
		//dbg_dump_ptr(srcBuf, 0, (srcBuf->meta.len+28+15)/16);
		dbg_printf("channel=%d  idx=%d\n", channel, idx);
		dbg_printf("channel=%d  idx=%d  len=%d/%x  ingress@%06x  search[ID11]@%06x (format=%d, sorted=%d lin=%d)\n",
			channel, idx, srcBuf->meta.len, srcBuf->meta.len, ingress, ingress->search[ID11], ingress->search[ID11]->ctrl.format, ingress->search[ID11]->ctrl.sortedEntries, ingress->search[ID11]->ctrl.linearEntries);

		//***********************************************************************************************************
		//***** Later the code below is moved to Ingress Stage (PE0). The rules are provided as part of the meta data
		//***********************************************************************************************************
		int rule1, rule2;
		uint8_t *frame;
		switch (srcBuf->meta.prot) {
		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		case PROTOCOL_bff :
			//Lookup to filter for 11-bit CAN-IDs in 2.0 or FD mode
			lookup32_start(ingress->search[ID11], srcBuf->data32[4]);  //inBuf->id + and FD,CC
			rule1 = 0;    //Id11 starts always with offset 0
			goto COMMON_CAN;

		case PROTOCOL_eff :
			//Lookup to filter for 11-bit CAN-IDs in 2.0 or FD mode
			lookup32_start(ingress->search[ID29], srcBuf->data32[4]);  //inBuf->id + and FD,CC
			rule1 = ingress->tableOffset[ID29];

		COMMON_CAN:
			rule1 += lookup32_result();
			#ifdef VERBOSE_CLASSIFY
				//dbg_printf("action[%d] @%06x\n", rule1, ingress->action[rule1]);
				dbg_printf("\033[35mclassify(%d, %s%c): idx=%d  Id=%d/%x  rule=%d/%x\033[m  Targets=[",
					channel, (srcBuf->can.fd)?"FD":"CC",  (srcBuf->meta.prot==PROTOCOL_bff)?'b':'e',
					idx, srcBuf->can.id, srcBuf->can.id, rule1, rule1 );
				uint8_t *tg = ingress->action[rule1]->can.targets;
				for (int t=0; t<8; t++) {
					if (tg[t] == 255)
						break;
					dbg_printf(" %d", tg[t]);
				}
				dbg_printf(" ]\n");
			#endif
			rule2 = -1;
			break;

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		case PROTOCOL_eth :
			// Extract Ethernet frame data from the input buffer
			frame = srcBuf->eth.data;

			// Extract Ethertype and VLAN
			uint16_t etherType = *(uint16_t*)&frame[2+12]; // EtherType field
			int vid;                   // VLAN ID (extracted later if present)
			int streamIdOffset;

			// Process VLAN tagged frames (IEEE 802.1Q) C-TAG = 0x8100
			if (etherType == bswap_16(0x8100)) {
				vid = ((frame[2+14] << 8) | frame[2+15]) & 0x0FFF;  // Extract VLAN ID (12 bits)
				etherType =  *(uint16_t*)&frame[2+16];           // Get actual EtherType after VLAN tag
				streamIdOffset = 2+18+4;                         // Adjust payload offset for VLAN tag
			}
			else {
				vid = raConfig->defaultVlan[channel-IDA_FIRST_ETH];
				streamIdOffset = 2+18;     // Offset to payload (after standard Ethernet header)
			}
			dbg_printf("ET=%04x  VID=%d/%x\n", bswap_16(etherType), vid, vid);

			//Extract MAC-DA
			//uint64_t value = *(uint32_t*)&frame[0] | ((uint64_t)(*(uint16_t*)&frame[4]) << 32) | ((uint64_t)vid << 48);  //no gap in ETH
			uint64_t value = *(uint16_t*)&frame[2+0] | ((uint64_t)(*(uint32_t*)&frame[2+2]) << 16) | ((uint64_t)vid << 48);  //with gap
			dbg_printf("Acceptance lookup %08x_%08x\n", (uint32_t)value, value>>32);

			lookup64_start(ingress->search[MAC_VLAN], value);
			rule1 = lookup64_result();
			#ifdef VERBOSE_CLASSIFY
				//dbg_printf("action[%d] @%06x\n", rule1, ingress->action[rule1]);
				dbg_printf("\033[35mclassify(%d, ETH): idx=%d  MAC=%02x:%02x:%02x:%02x:%02x:%02x VID=%d/%x  rule=%d/%x\033[m searchStream=%d Targets=[",
					channel, idx,
					frame[2+0], frame[2+1], frame[2+2], frame[2+3], frame[2+4], frame[2+5], vid, vid,
					rule1, rule1, ingress->action[rule1]->eth.searchStream);
				tg = ingress->action[rule1]->eth.targets;
				for (int t=0; t<8; t++) {
					if (tg[t] == 255)
						break;
					dbg_printf(" %d", tg[t]);
				}
				dbg_printf(" ]\n");
			#endif

			// Stream identification
			if (ingress->action[rule1]->eth.searchStream) {
				//1722 L2
				if (etherType == bswap_16(0x22F0)) {
					// Extract 64-bit Stream ID from IEEE 1722 header
					value = *(uint64_t*)&frame[streamIdOffset];
					lookup64_start(ingress->search[STREAM1722], value);
					rule2 = lookup64_result() + ingress->tableOffset[STREAM1722];
					#ifdef VERBOSE_CLASSIFY
						//dbg_printf("action[%d] @%06x\n", rule2, ingress->action[rule2]);
						dbg_printf("\033[35m    SID=%08x_%08x  rule=%d/%x\033[m streamUnit=%d sub=%d\n",
							bswap_32((uint32_t)value), bswap_32((uint32_t)(value>>32)),
							rule2, rule2&0xffff,
							(rule2==-1)?255:ingress->action[rule2]->stream.streamUnit,
							(rule2==-1)?255:ingress->action[rule2]->stream.subTarget);
					#endif
				}
				else
					rule2 = -1 + ingress->tableOffset[STREAM1722];
			}
			else
				rule2 = -1 + ingress->tableOffset[STREAM1722];
			break;

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		default:
			//Not possible in Ingress stage as the protocols comes from the external world and known before starting the search
			dbg_printf("FATAL: Interface version %d not yet supported\n", srcBuf->meta.prot);
			countersIngress[channel][IN_FAULTY]++;
			return 1;
		}

		// DataLengthCheck based on primary rule can happen always. The stream rule is checked during stream generation after multicasting
		// The action structure defined to have data length check common in can and eth
		enum e_sizeCheckMode chkMode = ingress->action[rule1]->can.SizeCheckMode;
		//dbg_printf("    SizeCheckMode=%d SizeCheckValue=%d\n", chkMode, ingress->action[rule1]->can.SizeCheckValue);
		if (chkMode != NONE) {
			int chkVal = ingress->action[rule1]->can.SizeCheckValue;
			if (! ((chkMode == SE && srcBuf->meta.len <= chkVal)
			    || (chkMode == EQ && srcBuf->meta.len == chkVal)
			    || (chkMode == GE && srcBuf->meta.len >= chkVal)
			)) {
				countersIngress[idx][IN_LEN_ERR]++;
				#ifdef VERBOSE_CLASSIFY
					dbg_printf("   DataLengthCheck failed: Received Length=0x%04x CheckMode=%d CheckLength=0x%04x CNT_IN_LEN_ERR=%d\n",
						srcBuf->meta.len, chkMode, ingress->action[rule1]->can.SizeCheckValue ,countersIngress[idx][IN_LEN_ERR]);
				#endif
				//Based on the configuration trunc/discard, classification stage/PE0 will not release the frame to ingress FIFO
				//Due to this the frame never appear in processing stage
				return 1;
			}
		}

		//***********************************************************************************************************
		//***** Later the code above is moved to Ingress Stage (PE0). The rules are provided as part of the meta data
		//***********************************************************************************************************
		int releaseLen;
		switch (srcBuf->meta.prot) {
		case PROTOCOL_bff :
		case PROTOCOL_eff :
			can_processing(&ingress->action[rule1]->can, srcBuf, ingress->gen1722_bus_id);
			releaseLen = srcBuf->meta.len+FIFO_CAN_HEADER_SIZE8;
			break;

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		case PROTOCOL_eth :
			eth_processing(&ingress->action[rule1]->eth, &ingress->action[rule2]->stream, srcBuf);
			releaseLen = srcBuf->meta.len+2+16;
			break;

			//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		default:
			//Ingress stage shall never generate such code.
			//TUBE reset expected
			assert (0);
			break;
		}
		//Increase get pointer to mark frame as processed back to ingress stage
		packedFifo_incGet(srcFIFO, releaseLen);


		// int tg = 4;   //fake lookup target
		// struct s_egressConfig *egress = &raConfig->egress[tg];
		// union u_fifoEntry *tgBuf = (union u_fifoEntry*)(egress->fifoBaseAddr + egress->fifoEntrySize * egressFifoEntryNumber[tg]);

		// //uint32_t *tgBuf = (uint32_t*)BUFRAMOUT_BASE8;
		// dbg_printf("\033[94m    Copy tg=%d  %x <= %x  size=%d (%03x total)\033[m\n", tg, tgBuf, srcBuf, len, (len+28+3) & ~3);
		// memcpy(tgBuf, srcBuf, (len+28+3) & ~3);
		// buf_out_inc |= 0x10;  //send of CAN4 for testing
		// egressFifoEntryNumber[tg] = (egressFifoEntryNumber[tg]+1) % egress->fifoEntries;

	}
	return 0;
}
