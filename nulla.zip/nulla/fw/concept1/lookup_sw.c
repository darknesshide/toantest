#include <stdint.h>
#include "ra_adrmap.h"     //RA Hardware mapping
#include "racfg.h"         //Configuration of RA system


//-----------------------------------------------------------------------------
static int lookupBIN11(const uint32_t *tab, uint32_t value, int min, int max)
{
	uint32_t vLow, vUp, vFormat;
	int pos;
	uint32_t format = (value>>30);
	value &= 0x1fffffff;
	while (min <= max) {
		pos = min + ((max-min) / 2);
		vLow = tab[pos] & 0x7ff;
		vUp  = (tab[pos]>>11) & 0x7ff;
		vFormat = (tab[pos]>>22) & 0x7;   //FD, CC, M
		//dbg_printf("     CHK: %03x==%03x  min=%d max=%d pos=%d\n", value, v, min, max, pos);
		if (value < vLow) {
			max = pos -1;
			//dbg_printf("      max->%d\n", max);
		}
		else if (value > vUp) {
			min = pos +1;
			//dbg_printf("      min->%d\n", min);
		}
		else { // ==
			if (format & (vFormat>>1))
				return pos;
			//M handling missing
			else
				break; //not found
		}
	}
	return -1;
}

//-----------------------------------------------------------------------------
static int lookup_ID11(const struct s_lupTable *tab, uint32_t value)
{
	uint32_t v, m, p;
	int pos, cnt, res;
	const uint32_t *lin;

	pos = tab->ctrl.sortedEntries;

	res = lookupBIN11(tab->entries, value, 0, pos-1);
	if (res != -1)
		return res;

	lin = &tab->entries[tab->ctrl.sortedEntries];
	cnt = tab->ctrl.linearEntries;

	while (cnt) {
		v = *lin&0x7ff;
		m = (*lin>>11)&0x7ff;
		p = (*lin>>23)&3;
		//dbg_printf("%3d %03x %03x\n", pos, v, m);
		if (v & ~m)
			dbg_printf("\033[42mMASK error\033[m\n");
		if (((value&m) == v) && ((value>>30)&p))
			return pos;
		pos++;
		lin++;
		cnt--;
	}
	return -1;
}

//-----------------------------------------------------------------------------
static int lookupBIN16(const struct s_lupTable *tab, uint16_t value) {
	int pos;
	const uint32_t *entries = tab->entries;
	int max = tab->ctrl.sortedEntries - 1;
	int min = 0;
	while (min <= max) {
		pos = min + ((max-min) >> 1);
		uint16_t etherType = entries[pos] & 0xFFFF;
		if (value < etherType)
			max = pos - 1;
		else if (value > etherType)
			min = pos + 1;
		else
			return pos;
	}
	return -1;
}

//-----------------------------------------------------------------------------
static int lookupBIN64(const struct s_lupTable *tab, uint64_t value) {
	const uint32_t *entries = tab->entries;
	int left = 0;
	int right = tab->ctrl.sortedEntries - 1;
	// dbg_printf(" key   %08x_%08x\n",  (uint32_t)(value>>32), (uint32_t)value);
	while (left <= right) {
		int mid = left + ((right - left) >> 1);
		// Extract 64-bit entry key (stored as two consecutive 32-bit values)
		uint64_t entry_key = *(uint64_t*)&entries[mid*2];
		// dbg_printf(" entry %08x_%08x\n",  (uint32_t)(entry_key>>32), (uint32_t)entry_key);
		if (value < entry_key)
			right = mid - 1;
		else if (value > entry_key)
			left = mid + 1;
		else
			return mid;
	}
	// Not found
	return -1;
}

//-----------------------------------------------------------------------------
int lookup32(const struct s_lupTable *tab, uint32_t value)
{
    switch (tab->ctrl.format) {
    case LUP_ID11:
        return lookup_ID11(tab, value);
    case LUP_16:
        return lookupBIN16(tab, value);

	default:
		dbg_printf("Unsupported lookup32 format %d\n", tab->ctrl.format);
		exit(-1);
        return -1;
    }
}

//-----------------------------------------------------------------------------
int lookup64(const struct s_lupTable *tab, uint64_t value)
{
    switch (tab->ctrl.format) {
    case LUP_64:
        return lookupBIN64(tab, value);

    default:
		dbg_printf("Unsupported lookup64 format %d\n", tab->ctrl.format);
		exit(-1);
        return -1;
    }
}

