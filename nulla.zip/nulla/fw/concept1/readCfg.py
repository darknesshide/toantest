import json
import ra
#import struct
import sys
import re

from moduleComif import normMAC

SIZEOF_s_raConfig = 5*4

SIZEOF_s_ingressConfig = 2*4

SIZEOF_s_RxPduCfg = 2*4
SIZEOF_s_lookupCtrl = 4

SIZEOF_s_canIfTxPduCfg = 4

SIZEOF_s_egressConfig = 2*4
SIZEOF_s_canAction = 4*4

SIZEOF_s_canFdEntry = 1*4
SIZEOF_s_canXlEntry = 2*4

SIZEOF_s_EthAction = 2 * 4  # FrameOwner + TargetVector
SIZEOF_s_RxEthPduCfg = 2 * 4  # search + action pointers

SIZEOF_s_1722streamGen = 4 * 4    #template not included
SIZEOF_s_1722streamTerm = 1 * 4


canIdTypeValue  = {'CC':1, 'FD':2, 'CCFD':3}
#canIfTxPduCanIdType  = {'CBFF':2, 'CEFF':3, 'FBFF':4, 'FEFF':5, 'XL':6}
canIdTypeLookup = {"Id11":'CanIfRxPduCanId11', "XL":'CanIfXLPriorityId', "Id29":'CanIfRxPduCanId29'}

GREEN = "\033[32m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
YELLOW = "\033[33;1m"

NORM = "\033[m"

#--------------------------------------------------------------------------
def toInt(val):
	if (type(val) == bool):
		val = 1 if val else 0
	elif (type(val) != int):
		val = int(val, 0)
	return val


#--------------------------------------------------------------------------
def bswap_32(val):
	return  ((val & 0xff000000) >> 24) | ((val & 0x00ff0000) >> 8) | \
	        ((val & 0x0000ff00) <<  8) | ((val & 0x000000ff) << 24)

#--------------------------------------------------------------------------
def bswap_64(val):
	return (bswap_32(val & 0xffffffff) << 32) | bswap_32((val>>32) & 0xffffffff)

#--------------------------------------------------------------------------
def normalise_templateData(this):
	data = []
	for d in this["templateData"]:
		if "data8" in d:
			l = re.split(":|\s+|,", d["data8"])
			#print(l)
			n = [int(s,16) for s in filter(len,l)]
			#print(len(n), "--", n, "--", [s[2:] for s in list(map(hex, n))])
			data += n
		elif "data16" in d:
			l = re.split(":|\s+|,", d["data16"])
			#print(l)
			n = [int(s,16) for s in filter(len,l)]
			#print(len(n), "--", n)
			b = sum([[s>>8, s&0xff] for s in n], [])
			#print(len(b), "--", b, "--", [s[2:] for s in list(map(hex, b))])
			data += b
		elif "data32" in d:
			l = re.split(":|\s+|,", d["data32"])
			#print(l)
			n = [int(s,16) for s in filter(len,l)]
			#print(len(n), "--", n)
			b = sum([[(s>>24)&0xff, (s>>16)&0xff, (s>>8)&0xff, s&0xff] for s in n], [])
			#print(len(b), "--", b, "--", [s[2:] for s in list(map(hex, b))])
			data += b
		else:
			assert False, "Expect data8, data16, data32 in templateData to define a template"
	#for
	#print(len(data), "--", data)
	assert len(data)%4==0, f"Template data shall have multiple of 4 bytes. Got {len(data)} bytes"
	this['templateData'] = data


#--------------------------------------------------------------------------
class raConfig:
	configBaseAddr = 0
	rxPduCfgBaseAddr = 0
	bufferInBaseAddr = None
	bufferOutBaseAddr = None
	virtualBufferAddr = None

	canBitrateArbitration = 500
	canBitrateData = 1000
	xlBitrateArbitration = 500
	xlBitrateData = 2000
	ethPortSpeed = 2500

	maxIngress = 0
	maxEgress = 0
	ingressBuffer = []
	egressBuffer = []
	rules = []
	streamsGen = []
	streamGenHandles = 0
	streamsTerm = []
	streamTermHandles = 0
	mapFifoToStream = {}

	#--------------------------------------------------------------------------
	def __init__(self, fileName, VERBOSE=1):
		self._VERBOSE = VERBOSE
		#self._totalEthControllers = 0  # Add this to track total controllers
		# Open and read the JSON file
		print("Read RA configuration from", fileName)
		with open(fileName, 'r') as file:
			cfg = json.load(file)

		self.configBaseAddr = self._ingressAddr = int(cfg["configBaseAddr"], 16)
		self.rxPduCfgBaseAddr = self._rxPduCfgAddr = int(cfg["rxPduCfgBaseAddr"], 16)
		self.bufferInBaseAddr = self._bufferInAddr = int(cfg["bufferInBaseAddr"], 16)
		self.bufferOutBaseAddr = self._bufferOutAddr = int(cfg["bufferOutBaseAddr"], 16)
		self.virtualBufferAddr = self._virtualBufferAddr = int(cfg["virtualBufferAddr"], 16)
		assert self.configBaseAddr>= ra.DATARAM[0] and self.configBaseAddr <= sum(ra.DATARAM)
		assert self.rxPduCfgBaseAddr>= ra.DATARAM[0] and self.rxPduCfgBaseAddr <= sum(ra.DATARAM)
		assert self.bufferInBaseAddr>= ra.BUFRAMIN[0] and self.bufferInBaseAddr <= sum(ra.BUFRAMIN)
		assert self.bufferOutBaseAddr>= ra.BUFRAMOUT[0] and self.bufferOutBaseAddr <= sum(ra.BUFRAMOUT)
		assert self.virtualBufferAddr>= ra.DATARAM[0] and self.virtualBufferAddr <= sum(ra.DATARAM)

		self.canBitrateArbitration = int(cfg["canBitrateArbitration"])
		self.canBitrateData = int(cfg["canBitrateData"])
		self.xlBitrateArbitration = int(cfg["xlBitrateArbitration"])
		self.xlBitrateData = int(cfg["xlBitrateData"])
		self.ethPortSpeed = int(cfg["ethPortSpeed"])

		self.maxIngress = len(cfg['ingress'])
		self.maxEgress = len(cfg['egress'])

		i = 0
		total_ingress_memory = 0
		total_ingress_subTable = 0
		total_egress_memory = 0
		for ingress in cfg['ingress']:
			if 'RxPduDefault' in ingress:  #a CAN definition
				total_ingress_memory += SIZEOF_s_ingressConfig + 3 * SIZEOF_s_RxPduCfg
				#Multicast action tables are handled by sub-table
				for RxPduCfg in ingress.get("RxPduCfg", []):
					if "CanIfTxPduCfg" in RxPduCfg["action"] and len(RxPduCfg["action"]["CanIfTxPduCfg"]) > 1:
						for m in RxPduCfg["action"]["CanIfTxPduCfg"]:
							if len(m):
								total_ingress_subTable += SIZEOF_s_canIfTxPduCfg # * len(RxPduCfg["action"]["CanIfTxPduCfg"])
			else: # an Ethernet definition
				total_ingress_memory += SIZEOF_s_ingressConfig + 3 * SIZEOF_s_RxPduCfg  # Change here from 4 to 3 to get working scenario as in past
				#self._totalEthControllers += 1  # Increment for each Ethernet interface

		#for 'ingress'
		total_egress_memory = 0
		total_streamGen_memory = 0
		maxStreamGen = 0
		maxStreamTerm = 0
		for idx, egress in enumerate(cfg['egress']):
			total_egress_memory += SIZEOF_s_egressConfig
			if "streamGenerate" in egress:
				maxStreamGen += 1
				normalise_templateData(egress['streamGenerate'])
				total_streamGen_memory += 4 + SIZEOF_s_1722streamGen + len(egress['streamGenerate']["templateData"])
			if "streamTerminate" in egress:
				maxStreamTerm += 1
				self.streamsTerm.append({"outFifoIdx":idx,
					"targetExceptionPort":egress["streamTerminate"]["targetExceptionPort"],
					"vPortIndex":egress["streamTerminate"]["vPortIndex"]
				})


		val1 = self._ingressAddr + SIZEOF_s_raConfig + total_ingress_subTable
		val2 = val1 + total_ingress_memory
		val3 = val2 + total_egress_memory
		val4 = val3 + total_streamGen_memory
		val5 = self.maxIngress + (self.maxEgress<<8) + (maxStreamGen<<16)  + (maxStreamTerm<<24)

		if self._VERBOSE>0: print("%sbaseConfig ----------- %06x : %s%08x %s%08x %s%08x %08x %s%08x%s  #ingressBuffers=%d  egressBuffers=%d streamGen=%d streamTerm=%d"%(
			BLUE+"\033[1m", self._ingressAddr, MAGENTA, val1, YELLOW, val2, GREEN, val3, val4, BLUE, val5, NORM,
			len(cfg['ingress']), len(cfg['egress']), maxStreamGen, maxStreamTerm))
		self._ingressAddr = ra.write(self._ingressAddr, 32, [val1, val2, val3, val4, val5])

		#space for the ingress sub-table
		self._ingressSubTableAddr = {'base':self._ingressAddr, 'next':self._ingressAddr, 'CanIfTxPduCfg-comment':[], 'CanIfTxPduCfg':[]}
		self._ingressAddr += total_ingress_subTable

		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		#for ingress config
		i = 0
		for ingress in cfg['ingress']:
			self.rules.append({})
			if 'RxPduDefault' in ingress:  #a CAN definition
				# For CAN interfaces, call _assembleCanIngressTable for all three ID types
				self._assembleCanIngressTable(ingress, i, "Id11", True)
				self._assembleCanIngressTable(ingress, i, "XL",   False)
				self._assembleCanIngressTable(ingress, i, "Id29", False)
			else:
				# For Ethernet interfaces, call only _assembleEthIngressTable
				self._assembleEthIngressTable(ingress, i, True)
			i += 1
		#for

		a = self._ingressSubTableAddr['base']
		for i in range(len(self._ingressSubTableAddr['CanIfTxPduCfg'])*4//SIZEOF_s_canIfTxPduCfg):
			if self._VERBOSE > 0:
				print(" %sCanTxPduCfg%-10s %06x :" % (
					GREEN, "["+self._ingressSubTableAddr['CanIfTxPduCfg-comment'][i]+"]", a), end="")
				for v in self._ingressSubTableAddr['CanIfTxPduCfg'][i]:
					if (v):
						print(" %08x"%v, end="")
				print("%s"%NORM)
			d = [x for x in self._ingressSubTableAddr['CanIfTxPduCfg'][i] if x is not None]
			ra.write(a, 32, d)
			a +=  4 * len(d)

		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		#for egress config
		i = 0
		for egress in cfg['egress']:
			self._assembleEgressTable(egress, i)
			i += 1

		##### Stream Generation structure
		streamGenAddr_print = self._ingressAddr
		#print(self.streamsGen)
		a = self._ingressAddr + 4 * len(self.streamsGen)
		sub = []
		for s in self.streamsGen:
			sub.append(a)
			a += len(s['template'])*4 + SIZEOF_s_1722streamGen
		if self._VERBOSE > 0:
			print(" %sstreamGenCfg          %06x :%s%s%s" % (
				GREEN, self._ingressAddr, CYAN, "".join([f" {i:08x}" for i in sub]), NORM))
		self._ingressAddr = ra.write(self._ingressAddr, 32, sub)

		#print(self.streamsGen)
		for i, s in enumerate(self.streamsGen):
			#print(s)
			#fill s_1722streamGen
			val1 = len(s['template'])*4 + (s['patchDataLengthWord']<<16)
			val2 = s["maxFrameSize"] + (s["txTimeout"]<<16)
			val3, val4 = self._assembleEthAction(s["action"])
			if self._VERBOSE > 0:
				print("   %sstreamGen%-7s    %06x : %08x %08x |> %08x %08x%s  #maxSize=%d timeout=%1.3fms" % (
						CYAN, f"[{i}]", self._ingressAddr, val1, val2, val3, val4, NORM,
						s["maxFrameSize"], s["txTimeout"]/1000), end='')
				j = 4
				a = self._ingressAddr + SIZEOF_s_1722streamGen
				for v in s['template']:
					if j==4:
						print("\n                       %06x :"%(a), end='')
						j = 0
					print(" %08x"%v, end="")
					a += 4
					j += 1
				#for
				print()

			self._ingressAddr = ra.write(self._ingressAddr, 32, [val1, val2, val3, val4]+s['template'])

		##### Stream Termination structure
		streamTermAddr_print = self._ingressAddr
		#print(self.streamsTerm)
		a = self._ingressAddr + 4 * len(self.streamsTerm)
		sub = []
		for s in self.streamsTerm:
			sub.append(a)
			a += SIZEOF_s_1722streamTerm
		if self._VERBOSE > 0:
			print(" %sstreamTermCfg         %06x :%s%s%s" % (
				GREEN, self._ingressAddr, CYAN, "".join([f" {i:08x}" for i in sub]), NORM))
		self._ingressAddr = ra.write(self._ingressAddr, 32, sub)

		for i, s in enumerate(self.streamsTerm):
			#fill s_1722streamTerm
			val1 = s["vPortIndex"] + ((s["targetExceptionPort"]&0xff)<<8)
			if self._VERBOSE > 0:
				print("   %sstreamTerm%-7s   %06x : %08x%s                    #vPortIndex=%d targetExceptionPort=%d" % (
						CYAN, f"[{i}]", self._ingressAddr, val1, NORM,
						s["vPortIndex"], s["targetExceptionPort"]&0xff))
			self._ingressAddr = ra.write(self._ingressAddr, 32, [val1])


		##### Summarise and check
		if self._VERBOSE>0:
			print("Configuration at %06x with %04x/%d bytes in Data RAM"%(self.configBaseAddr, self._ingressAddr-self.configBaseAddr, self._ingressAddr-self.configBaseAddr))
			print("Rx tables     at %06x with %04x/%d bytes in Data RAM"%(self.rxPduCfgBaseAddr, self._rxPduCfgAddr-self.rxPduCfgBaseAddr, self._rxPduCfgAddr-self.rxPduCfgBaseAddr))
			print("In buffers    at %06x with %04x/%d bytes in Buffer RAM"%(self.bufferInBaseAddr, self._bufferInAddr-self.bufferInBaseAddr, self._bufferInAddr-self.bufferInBaseAddr))
			print("Out buffers   at %06x with %04x/%d bytes in Buffer RAM"%(self.bufferOutBaseAddr, self._bufferOutAddr-self.bufferOutBaseAddr, self._bufferOutAddr-self.bufferOutBaseAddr))
			print("Virtual InBuf at %06x with %04x/%d bytes in Data RAM"%(self.virtualBufferAddr, self._virtualBufferAddr-self.virtualBufferAddr, self._virtualBufferAddr-self.virtualBufferAddr))
			print("Stream Gen    at %06x with %04x/%d bytes in Data RAM"%(streamGenAddr_print, streamTermAddr_print-streamGenAddr_print, streamTermAddr_print-streamGenAddr_print))
			print("Stream Term   at %06x with %04x/%d bytes in Data RAM"%(streamTermAddr_print, self._ingressAddr-streamTermAddr_print, self._ingressAddr-streamTermAddr_print))
		assert self._ingressAddr <= self.rxPduCfgBaseAddr
		assert self._rxPduCfgAddr <= self.virtualBufferAddr
		assert self.maxIngress == len(self.ingressBuffer)
		assert self.maxEgress == len(self.egressBuffer)
		# print(self.rules)
		# sys.exit(1)
	#__init__


	#--------------------------------------------------------------------------
	def _assembleCanAction(self, idx, rule, action, fifoEntrySize):
		comment = ""
		val3 = toInt(action.get('CanIfRxPduId', 0))
		if (action['CanIfRxPduDataLengthCheck']):
			val2 = toInt(action['CanIfRxPduDataLength'])
			assert val2 >= 0 and val2 <=64, "CanIfRxPduDataLength is out of range 0..64"
			if (val2 > fifoEntrySize):
				print("\033[33;1mWarning: CanIfRxPduDataLength=%d (min size) is above configured fifoEntrySize=%d  (CanIfRxPduId=%d)\033[m"%(val2, fifoEntrySize, val3))
			comment += " min="+str(val2)
		else:
			val2 = 0x0
		minLength = val2

		val4 = toInt(action['TargetVector'])

		i = 0x10000
		if ("CanIfTxPduCfg" in action):
			assert isinstance(action["CanIfTxPduCfg"], list), "List of CanIfTxPduCfg configurations expected"
			val5 = []
			for modification in action["CanIfTxPduCfg"]:
				#print(modification, type(modification))
				if len(modification) == 0:
					comment += " -"
				else:
					assert toInt(modification.get('CanIfTxPduCanId11',0)) < (1<<11), "11-bit CanId out of range"
					assert toInt(modification.get('CanIfTxPduCanId29',0)) < (1<<29), "29-bit CanId out of range"
					assert toInt(modification.get('CanIfXLPriorityId',0)) < (1<<11), "11-bit CanPriorityId out of range"
					assert "CanIfTxPduCanId11" in modification or "CanIfTxPduCanId29" in modification or "CanIfXLPriorityId" in modification, "No Id specified"
					assert modification["CanIfTxPduCanIdType"] == "FD" or modification["CanIfTxPduCanIdType"] == "CC", "CanIfTxPduCanIdType should be CC or FD"

					#fills s_canIfTxPduCfg
					comment += " ->"
					if ("CanIfTxPduCanId11" in modification):
						val5.append(toInt(modification["CanIfTxPduCanId11"]) + (0<<29))  #PROTOCOL_bff
						if (modification["CanIfTxPduCanIdType"] == "FD"):
							val5[-1] |= (1<<31)
							modification["frameIdentifier"] = "Id11."+str(modification["CanIfTxPduCanId11"])+".FD"
						else:
							modification["frameIdentifier"] = "Id11."+str(modification["CanIfTxPduCanId11"])+".CC"
						comment += modification["frameIdentifier"]
					elif ("CanIfTxPduCanId29" in modification):
						val5.append(toInt(modification["CanIfTxPduCanId29"]) + (1<<29))  #PROTOCOL_eff
						if (modification["CanIfTxPduCanIdType"] == "FD"):
							val5[-1] |= (1<<31)
							modification["frameIdentifier"] = "Id29."+str(modification["CanIfTxPduCanId29"])+".FD"
						else:
							modification["frameIdentifier"] = "Id29."+str(modification["CanIfTxPduCanId29"])+".CC"
						comment += modification["frameIdentifier"]
					elif ("CanIfXLPriorityId" in modification):
						val5.append(toInt(modification["CanIfXLPriorityId"]) + (2<<29))  #PROTOCOL_xlff
					#else:
					#	val5.append(None)

					#mark in modifyOnTarget
					val2 |= i
				i <<= 1
			#for
			if len(action["CanIfTxPduCfg"]) > 1:
				self._ingressSubTableAddr['CanIfTxPduCfg'].append(val5)
				self._ingressSubTableAddr['CanIfTxPduCfg-comment'].append("C%d#%d"%(idx,rule))
				val5 = self._ingressSubTableAddr['next']
				self._ingressSubTableAddr['next'] += SIZEOF_s_canIfTxPduCfg * len(action["CanIfTxPduCfg"])
			else:
				val5 = val5[0]
		else:
			val5 = 0

		if ("flushOnTarget" in action):
			flush = action["flushOnTarget"]
			#print("FLUSH %x  target=%x"%(flush, val4))
			i = 0x1000000
			for j in range(32):
				if (1<<j) & val4:
					if (1<<j) & flush:
						val2 |= i
						comment += f" Flush #{j}"
					i <<= 1
			#print("%x"%val2)

		return val2, val3, val4, val5, minLength, comment
	#_assembleCanAction


	#--------------------------------------------------------------------------
	def _assembleEthAction(self, action):
		val1 = toInt(action["FrameOwner"])
		val2 = toInt(action["TargetVector"])
		return val1, val2


	#--------------------------------------------------------------------------
	def _assembleEthIngressTable(self, this, idx, withHeader):
		assert 'EthTypeTableCfg' in this, "Missing required 'EthTypeTableCfg' in Ethernet interface configuration"

		# Add assertions for the new default routes
		assert 'EthTypeTableDefault' in this, "Missing required 'EthTypeTableDefault' in Ethernet interface configuration"
		assert 'VlanDaTableDefault' in this, "Missing required 'VlanDaTableDefault' in Ethernet interface configuration"
		assert 'Ieee1722TableDefault' in this, "Missing required 'Ieee1722TableDefault' in Ethernet interface configuration"

		table_keys = ['EthTypeTableCfg', 'VlanDaTableCfg', 'Ieee1722TableCfg']
		default_keys = ['EthTypeTableDefault', 'VlanDaTableDefault', 'Ieee1722TableDefault']
		lookup_formats = {
			'EthTypeTableCfg': 2,  # LUP_16
			'VlanDaTableCfg': 6,   # LUP_48
			'Ieee1722TableCfg': 6  # LUP_64
		}

		if withHeader:
			assert this['fifoEntrySize'] >= 24, f"ETH Ingress FIFOs needs at least 24 bytes (meta+4*payload) got{this['fifoEntrySize']}"
			assert this['fifoEntrySize']%4 == 0, f"Ingress FIFO size shall multiple of 4  got {this['fifoEntrySize']}"
			val1 = self._bufferInAddr
			val2 = this['fifoEntrySize'] | (this['fifoEntries'] << 16)
			if self._VERBOSE > 0:
				print(" %singressCfg[%02d]        %06x : %08x %08x%s (+3 ptr)  #FIFO{base=%04x entries=%d size=%d}" % (
					MAGENTA, idx, self._ingressAddr, val1, val2, NORM,
					val1, this['fifoEntries'], this['fifoEntrySize']))
			ra.write(self._ingressAddr, 32, [val1, val2])
			self.ingressBuffer.append({
				'fifoBaseAddr': self._bufferInAddr,
				'fifoEntrySize': this['fifoEntrySize'],
				'fifoEntries': this['fifoEntries']
			})
			self._ingressAddr += SIZEOF_s_ingressConfig
			self._bufferInAddr += ((this['fifoEntrySize'] + 127) // 128) * 128 * this['fifoEntries']

		for table_idx, table_key in enumerate(table_keys):
			default_key = default_keys[table_idx]
			entries = this.get(table_key, [])
			DefaultVlanId = this['DefaultVlanId']
			if entries:
				# Sort entries by etherType for EthTypeTableCfg
				if table_key == 'EthTypeTableCfg':
					for i, entry in enumerate(entries):
						entries[i] = sorted(entry, key=lambda e: int(e['search']['etherType'], 16))
					assert len(entries) == 1, f"Currently only an ET Table with 1 table is supported. Got {len(entries)}"
					entries = entries[0]
				elif table_key == 'VlanDaTableCfg':
					# convert MAC Address into a bit-endian number as per Ethernet format
					for entry in entries:
						entry['search']['destMacAddr'], entry['search']['destMacAddr-Number'] = normMAC(entry['search']['destMacAddr'])
					# Sort entries by destMacAddr and vlanId
					entries = sorted(entries, key=lambda e: (
						int(e['search'].get('vlanId', DefaultVlanId)),
						e['search']['destMacAddr-Number']
					))
				elif table_key == 'Ieee1722TableCfg':
					# convert MAC Address into a bit-endian number as per Ethernet format
					for entry in entries:
						sid = int(entry['search']['streamId'],16)
						entry['search']['streamId-Number'] = int.from_bytes(sid.to_bytes(8, byteorder='little'), byteorder='big', signed=False)
					entries = sorted(entries, key=lambda e: e['search']['streamId-Number'])
				val1 = self._rxPduCfgAddr
				# Calculate actionAddr based on key size
				if table_key == 'EthTypeTableCfg':
					key_size = 4
				else:
					key_size = 8
				actionAddr = val1 + SIZEOF_s_lookupCtrl + SIZEOF_s_EthAction + len(entries) * key_size

				# Validate each entry in EthTypeTableCfg has search and action fields
				for entry in entries:
					assert 'search' in entry, f"Missing 'search' field in {table_key} entry: {entry}"
					assert 'action' in entry, f"Missing 'action' field in {table_key} entry: {entry}"
					if table_key == 'EthTypeTableCfg':
						assert 'etherType' in entry['search'], f"Missing 'etherType' in search field: {entry['search']}"
					elif table_key == 'VlanDaTableCfg':
						assert 'destMacAddr' in entry['search'], f"Missing 'destMacAddr' in search field: {entry['search']}"
					elif table_key == 'Ieee1722TableCfg':
						assert 'streamId' in entry['search'], f"Missing 'streamId' in search field: {entry['search']}"
					assert 'FrameOwner' in entry['action'], f"Missing 'FrameOwner' in action field: {entry['action']}"
					assert 'TargetVector' in entry['action'], f"Missing 'TargetVector' in action field: {entry['action']}"
				val2 = actionAddr
				if self._VERBOSE > 0:
					print("   %s%-19s %06x : %08x %08x%s           #entries=%d search->%06x action->%06x" % (
						CYAN, table_key+"["+str(idx)+"]", self._ingressAddr, val1, val2, NORM, len(entries), val1, val2))
				ra.write(self._ingressAddr, 32, [val1, val2])
				self._ingressAddr += SIZEOF_s_RxEthPduCfg

				# write lookup control and print
				lupFormat = lookup_formats[table_key]
				val3 = len(entries) | (0 << 16) | (lupFormat << 28)
				if self._VERBOSE > 1:
					print("           config      %06x : %08x -    action[-1] %06x : %08x %08x  #bin=%d lin=%d" % (
						self._rxPduCfgAddr, val3,
						actionAddr - SIZEOF_s_EthAction,
						toInt(this[default_key]['FrameOwner']),
						toInt(this[default_key]['TargetVector']),
						len(entries), 0))
				ra.write(self._rxPduCfgAddr, 32, [val3])
				self._rxPduCfgAddr += 4

				# write default action using the specific table default
				val1, val2 = self._assembleEthAction(this[default_key])
				ra.write(actionAddr - SIZEOF_s_EthAction, 32, [val1, val2])

				# write entries with proper bit widths
				for i, entry in enumerate(entries):
					if table_key == 'VlanDaTableCfg':
						# 64-bit MAC+VLAN combination for LUP_64
						vlan = int(entry['search'].get('vlanId', DefaultVlanId))
						assert vlan <= 0xfff
						key = entry['search']['destMacAddr-Number'] + (vlan << 48)
						key_low = key & 0xFFFFFFFF
						key_high = (key >> 32) & 0xFFFFFFFF
						search1722 = entry['action'].get('search1722', False)
						searchET = entry['action'].get('searchET', False)
						if (type(searchET)==bool and searchET == False):
							searchET =  0
						elif (type(searchET)==bool and searchET==True):
							searchET = 1
						else:
							searchET += 1
						assert (searchET < 256)

						val3, val4 = self._assembleEthAction(entry['action'])
						val3 = val4 | (searchET<<16) | (search1722<<24)

						#print("VLDA: Key=0x%016x vlan=%d ET=%s 1722=%d  action=%x" % (key, vlan, searchET, search1722, actionAddr))
						if self._VERBOSE > 1:
							print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x  #mac=%s vlan=%d - 1722=%s ET=%s" % (
								'['+str(i)+']', self._rxPduCfgAddr, key_low, key_high,
								'['+str(i)+']', actionAddr,
								val3, val4,
								entry['search']['destMacAddr'], vlan, "check" if search1722 else "no", "no" if searchET==0 else searchET-1))
						ra.write(self._rxPduCfgAddr, 32, [key_low, key_high])
						self._rxPduCfgAddr += 8

						#place in rule table for Python
						tag = ":".join([f"{int(x, 16):02x}" for x in entry['search']['destMacAddr'].split(':')])
						tag = f"{idx}>{tag}-{vlan}"
						tg = []
						for i, c in enumerate(format(toInt(entry['action']['TargetVector']), "b")[::-1]):
							if (c=="1"):
								tg.append({"target":i, "TxModify":None, "minLength":0}) #, "subTag":""})
						#print(idx, ":", searchET, tag, tg)
						self.rules[-1][tag] = tg
						if (searchET != 0):
							self.rules[-1][tag+"#ET"] = searchET-1
							#print(idx, ":", searchET, tag+"#ET")
						if (search1722 != 0):
							self.rules[-1][tag+"#ST"] = True
							#print(idx, ":", tag+"#ST")

					elif table_key == 'EthTypeTableCfg':
						# 16-bit EtherType
						key = int(entry['search']['etherType'], 16)
						assert key < 0x10000, f"EtherType {key:x} out of range"
						val3, val4 = self._assembleEthAction(entry['action'])

						if self._VERBOSE > 1:
							print("           entry%-6s %06x : %08x -        %6s %06x : %08x %08x  #etherType=0x%04x" % (
								'['+str(i)+']', self._rxPduCfgAddr, key,
								'['+str(i)+']', actionAddr,
								val3, val4,
								key))
						ra.write(self._rxPduCfgAddr, 32, [(key>>8)+((key<<8)&0xff00)])
						self._rxPduCfgAddr += 4

						#place in rule table for Python
						tag = f"ET0-{key:04x}"  #currently on list supported here
						tg = []
						for i, c in enumerate(format(toInt(entry['action']['TargetVector']), "b")[::-1]):
							if (c=="1"):
								tg.append({"target":i, "TxModify":None, "minLength":0}) #, "subTag":f"-E{key:04x}"})
						#print(idx, ":", tag, tg)
						self.rules[-1][tag] = tg

					elif table_key == 'Ieee1722TableCfg':
						# 64-bit stream ID only (no subtype)
						stream_id = entry['search']['streamId-Number']
						val1 = stream_id & 0xFFFFFFFF
						val2 = (stream_id >> 32) & 0xFFFFFFFF
						val3, val4 = self._assembleEthAction(entry['action'])

						#place in rule table for Python
						tag = f"ST-{bswap_64(stream_id):016x}"
						tg = []
						comment = ""
						for i, c in enumerate(format(toInt(entry['action']['TargetVector']), "b")[::-1]):
							if (c=="1"):
								if any(d['outFifoIdx'] == i for d in self.streamsTerm):
									pos = sum(idx if d['outFifoIdx']==i else 0 for idx,d in enumerate(self.streamsTerm))
									comment = f"  --> streamTerm#{pos}"
								else:
									pos = None
								tg.append({"target":i, "TxModify":None, "minLength":0, "streamTerm":pos}) #, "subTag":f"-S{stream_id:016x}"})
						#for
						#print(idx, ":", tag, tg)
						self.rules[-1][tag] = tg

						if self._VERBOSE > 1:
							current_action_offset = sum(SIZEOF_s_EthAction for _ in range(i))
							print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x  #streamId=%s%s" % (
								'['+str(i)+']', self._rxPduCfgAddr, val1, val2,
								'['+str(i)+']', actionAddr + current_action_offset,
								val3, val4,
								entry['search']['streamId'], comment))
						ra.write(self._rxPduCfgAddr, 32, [val1, val2])
						self._rxPduCfgAddr += 8
					#if

					#write the action table entry
					ra.write(actionAddr, 32, [val3, val4])
					actionAddr += SIZEOF_s_EthAction
				#for all entries
				self._rxPduCfgAddr = actionAddr
			else:
				# NULL table
				if self._VERBOSE > 0:
					print("   %s%s[%02d]     %06x : %08x %08x%s           #NULL" % (
						CYAN, table_key, idx, self._ingressAddr, 0, 0, NORM))
				ra.write(self._ingressAddr, 32, [0, 0])
				self._ingressAddr += SIZEOF_s_RxEthPduCfg
	#_assembleEthIngressTable


	#--------------------------------------------------------------------------
	def _assembleCanIngressTable(self, this, idx, type, withHeader):
		#The header information of this ingress port
		#Fills struct s_ingressConfig
		if withHeader:
			assert this['fifoEntrySize'] >= 32, f"CAN Ingress FIFOs needs at least 32 bytes (meta+4*payload) got{this['fifoEntrySize']}"
			assert this['fifoEntrySize']%4 == 0, f"Ingress FIFO size shall multiple of 4  got {this['fifoEntrySize']}"
			val1 = self._virtualBufferAddr if this.get('fifoIsVirtual', False) else self._bufferInAddr
			val2 = this['fifoEntrySize']
			val2 |= this['fifoEntries']<<16
			if self._VERBOSE>0: print(" %singressCfg[%02d]        %06x : %08x %08x%s (+3 ptr)  #FIFO{base=%04x entries=%d size=%d}"%(
					MAGENTA, idx, self._ingressAddr, val1, val2, NORM,
					val1, this['fifoEntries'], this['fifoEntrySize']))
			ra.write(self._ingressAddr, 32, [val1, val2])
			self.ingressBuffer.append({'fifoBaseAddr':val1, 'fifoEntrySize':this['fifoEntrySize'], 'fifoEntries':this['fifoEntries']} )
			self._ingressAddr += SIZEOF_s_ingressConfig
			if this.get('fifoIsVirtual', False):
				self._virtualBufferAddr += ((this['fifoEntrySize']+127)//128)*128 * this['fifoEntries']
			else:
				self._bufferInAddr += ((this['fifoEntrySize']+127)//128)*128 * this['fifoEntries']


		# Original CAN processing code...
		matches = [c for c in this.get('RxPduCfg',[]) if toInt(c['search'].get(canIdTypeLookup[type],-1)) >= 0]
		#print("  PY  ingress #%d  entriesSize=%d  type=%s  entries=%d"%(idx, this['fifoEntrySize'], type, len(matches)))

		#- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		#The table information of one format (Id11, XL, Id29)
		#Fills struct s_RxPduCfg (3 times for CAN)
		#struct s_RxPduCfg {
		#	struct s_lookupTable *search;  //contains size and table itself
		#	struct s_canAction *actions;   //default action is at [-1]
		#};
		actionAddr = self._rxPduCfgAddr + SIZEOF_s_lookupCtrl + SIZEOF_s_canAction #space for default action
		if (type == "XL"):
			actionAddr += SIZEOF_s_canXlEntry * len(matches)
			lupFormat = 3 #LUP_32 for AF
		elif (type=="Id11"):
			actionAddr += SIZEOF_s_canFdEntry * len(matches)
			lupFormat = 0 #LUP_ID11
		else:
			actionAddr += SIZEOF_s_canFdEntry * len(matches)
			lupFormat = 4 #LUP_ID29

		val1 = self._rxPduCfgAddr
		val2 = actionAddr

		if self._VERBOSE>0: print("   %sRxPduCfg[%02d]%-7s %06x : %08x %08x%s           #entries=%d search->%06x action->%06x"%(
				CYAN, idx, '['+type+']', self._ingressAddr, val1, val2, NORM,
				len(matches), self._rxPduCfgAddr, actionAddr))
		ra.write(self._ingressAddr, 32, [val1, val2])
		self._ingressAddr += SIZEOF_s_RxPduCfg

		val1 = len(matches)  #sorted entries
		val1 |= (0 << 16)    #linear entries
		val1 |= (lupFormat << 28)    #format (enum e_lupFormat {LUP_ID11=0, LUP_8, LUP_16, LUP_32, LUP_ID29=4, LUP_48, LUP_64};
		val4, val5, val6, val7, _, _ = self._assembleCanAction(idx, -1, this['RxPduDefault'], this['fifoEntrySize'])

		if self._VERBOSE>1: print("           config      %06x : %08x -    action[-1] %06x : %08x %08x %08x %08x  #bin=%d lin=%d"%(
			self._rxPduCfgAddr, val1,
			actionAddr-SIZEOF_s_canAction, val4, val5, val6, val7,
			len(matches), 0))
		ra.write(self._rxPduCfgAddr, 32, [val1])
		ra.write(actionAddr-SIZEOF_s_canAction, 32, [val4, val5, val6, val7])
		self._rxPduCfgAddr += 4

		if (type == "XL"):
			matches = sorted(matches, key=lambda m:
				(m['search'].get('CanIfXLPriorityId',0) << 0) +
				(m['search'].get('CanIfXLSduType',0) << 16) +
				(m['search'].get('CanIfXLVcid',0) << 24) +
				(m['search'].get('CanIfXLAcceptanceField', 0) << 32)
			)
		else:
			matches = sorted(matches, key=lambda m: toInt(m['search'].get('CanIfRxPduCanId11',0)))


		#The table itself (in either FD or XL format)
		#Fills struct s_canFdEntry
		#Fills struct s_canXlEntry
		#lastKey and i are only for assertion and printing
		lastKey = 0
		i = 0
		for rxPduCfg in matches:
			search = rxPduCfg['search']
			action = rxPduCfg['action']

			assert toInt(search.get('CanIfRxPduCanId11',0)) < (1<<11), "11-bit CanId out of range"
			assert toInt(search.get('CanIfXLPriorityId',0)) < (1<<11), "11-bit CanPriorityId out of range"
			assert toInt(search.get('CanIfRxPduCanId29',0)) < (1<<29), "29-bit CanId out of range"
			assert action.get('TargetVector', -1) != -1, "Number as TargetVector expected"

			# ToDo Check for overlapping

			id = toInt(search.get('CanIfRxPduCanId29',0)) + toInt(search.get('CanIfRxPduCanId11',0)) + toInt(search.get('CanIfXLPriorityId',0))
			upper_range = toInt(search.get('CanIfRxPduCanIdRangeUpperCanId',id))
			assert upper_range >= id, f"Upper range {upper_range} 0x{upper_range:x} value smaller than CanId {id} 0x{id:x}"

			#place in data RAM for C
			if (type == "XL"):
				val1 = id
				val1 |= (search['CanIfXLSduType'] << 16) + (search['CanIfXLVcid'] << 24)
				val2 = search['CanIfXLAcceptanceField']
				val3, val4, val5, val6, _, _ = self._assembleCanAction(idx, i, action, this['fifoEntrySize'])
				if self._VERBOSE>1: print("           entry%-6s %06x : %08x %08x %6s %06x : %08x %08x %08x %08x  #id=%d af=%d sd=%d vc=%d"%(
					'['+str(i)+']', self._rxPduCfgAddr, val1, val2,
					'['+str(i)+']', actionAddr, val3, val4, val5, val6, id, val2, search['CanIfXLSduType'], search['CanIfXLVcid']))
				ra.write(self._rxPduCfgAddr, 32, [val1, val2])
				ra.write(actionAddr, 32, [val3, val4, val5, val6])
				self._rxPduCfgAddr += SIZEOF_s_canXlEntry

				assert (val2<<32)+(val1) > lastKey
				lastKey = (val2<<32)+(val1)
			else:
				val1 = id
				if (type == "Id11"):
					assert upper_range < (1<<11), "11-bit CanId upper range out of range"
					val1 |= (upper_range << 11)
					val1 |= (canIdTypeValue[search['CanIfRxPduCanIdType']]*2+0 << 22)
				else:
					assert upper_range < (1<<29), "29-bit CanId upper range out of range"
					#TODO 29-bit Id table entry assembling not yet implemented
					val1 |= (canIdTypeValue[search['CanIfRxPduCanIdType']] << 30)
				val3, val4, val5, val6, minLength, comment = self._assembleCanAction(idx, i, action, this['fifoEntrySize'])
				if self._VERBOSE>1: print("           entry%-6s %06x : %08x -        %6s %06x : %08x %08x %08x %08x  #id=%d%s%s"%(
					'['+str(i)+']', self._rxPduCfgAddr, val1,
					'['+str(i)+']', actionAddr, val3, val4, val5, val6, id,
					"" if (id==upper_range) else f"..{upper_range}",
					comment))
				ra.write(self._rxPduCfgAddr, 32, [val1])
				ra.write(actionAddr, 32, [val3, val4, val5, val6])
				self._rxPduCfgAddr += SIZEOF_s_canFdEntry

				assert id > lastKey, f"if=%d/%x lastId=%d"%(id, id, lastKey)
				lastKey = id

				#place in rule table for Python
				tg = []
				ii = 0
				for tgi, c in enumerate(format(toInt(action['TargetVector']), "b")[::-1]):
					if (c=="1"):
						f = None
						if 'CanIfTxPduCfg' in action and ii < len(action['CanIfTxPduCfg']) and action['CanIfTxPduCfg'][ii]:
							#print(action['CanIfTxPduCfg'])
							f = action['CanIfTxPduCfg'][ii]['frameIdentifier']
						tg.append({"target":tgi, "TxModify":f, "minLength":minLength}) #, "subTag":""})
						ii += 1
				for id in range(id, upper_range+1):
					if (search['CanIfRxPduCanIdType'] == "CCFD"):
						self.rules[-1][str(idx)+">"+type+"."+str(id)+".FD"] = tg
						self.rules[-1][str(idx)+">"+type+"."+str(id)+".CC"] = tg
					else:
						self.rules[-1][str(idx)+">"+type+"."+str(id)+"."+search['CanIfRxPduCanIdType']] = tg
				#for
			#if type
			actionAddr += SIZEOF_s_canAction
			i += 1
		#the action table is the later part and defines the end address of this container
		self._rxPduCfgAddr = actionAddr
		#sys.exit()
	#_assembleCanIngressTable


	#--------------------------------------------------------------------------
	def _assembleEgressTable(self, this, idx):
		val1 = self._bufferOutAddr
		val2 = this['fifoEntrySize']
		val2 |= this['fifoEntries']<<16

		if "streamGenerate" in this:
			data = this["streamGenerate"]["templateData"]
			template = []
			#Meta in little endian
			for i in range(0,4*4,4):
				template.append((data[i+0]<<24)+(data[i+1]<<16)+(data[i+2]<<8)+(data[i+3]<<0))
			#Data in big
			for i in range(4*4,len(data),4):
				template.append((data[i+0]<<0)+(data[i+1]<<8)+(data[i+2]<<16)+(data[i+3]<<24))

			gen = this["streamGenerate"]
			self.streamsGen.append({"template":template, "outFifoIdx":idx,
				"maxFrameSize":gen["maxFrameSize"], "txTimeout":gen["txTimeout"],
				"patchDataLengthWord":gen["patchDataLengthWord"], "action":gen["action"],
			})
			self.mapFifoToStream[idx]= len(self.streamsGen)-1

			#link this stream in the egress config
			val2 |= self.streamGenHandles<<24
			comment = " --> streamGen#"+str(self.streamGenHandles)
			self.streamGenHandles += 1

		elif "streamTerminate" in this:
			#print(this["streamTerminate"])
			# term = this["streamTerminate"]
			# self.streamsTerm.append({"outFifoIdx":idx,
			# 	"targetExceptionPort":term["targetExceptionPort"], "vPortIndex":term["vPortIndex"]
			# })

			#link this stream in the egress config
			val2 |= self.streamTermHandles<<24
			comment = " --> streamTerm#"+str(self.streamTermHandles)
			self.streamTermHandles += 1

		else:
			val2 |= 255<<24
			comment = ""
		#if stream

		if self._VERBOSE>0: print(" %segressCfg[%02d]         %06x : %08x %08x%s           #FIFO{base=%06x entries=%d size=%d}%s"%(
				YELLOW, idx, self._ingressAddr, val1, val2, NORM,
				self._bufferOutAddr, this['fifoEntries'], this['fifoEntrySize'], comment))
		self.egressBuffer.append({'fifoBaseAddr':self._bufferOutAddr, 'fifoEntrySize':this['fifoEntrySize'], 'fifoEntries':this['fifoEntries']} )
		ra.write(self._ingressAddr, 32, [val1, val2])
		self._ingressAddr += SIZEOF_s_egressConfig
		self._bufferOutAddr += ((this['fifoEntrySize']+127)//128)*128 * this['fifoEntries']
	#_assembleEgressTable
#class

#some test code
# class ra:
# 	def write(adr, values):
# 		return 0
# raCfg = raConfig('config.json', 2)
