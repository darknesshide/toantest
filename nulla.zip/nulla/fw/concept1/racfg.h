#ifndef __RACFG_H__
#define __RACFG_H__

#include <stdint.h>

//Maximum numbers for internal data structures,
//real numbers are coming from json via raConfig
#define INGRESS_MAX        16
#define EGRESS_MAX         32
#define INGRESS_STREAM_MAX  8  /*coded inside INGRESS_MAX*/
#define EGRESS_STREAM_MAX   8  /*coded inside EGRESS_MAX*/

#define PN_VPORT_OFFSET  0x60 /*32 streams mapped to input port number 96~127*/

//=============================================================================
//===== Statistic counters
//=============================================================================
#define GENERATE_ENUM(ENUM) ENUM,
#define GENERATE_STRING(STRING) #STRING,

#define THE_RX_COUNTERS(C) \
	C(CNT_RX_BYTES) C(CNT_RX_TOTAL) C(CNT_RX_FAULTY) C(CNT_RX_DATALERR) \
	C(CNT_RX_FRAME_TOO_LARGE)
#define THE_TX_COUNTERS(C) \
	C(CNT_TX_BYTES) C(CNT_TX_TOTAL) C(CNT_TX_BUSY) C(CNT_TX_TRUNC) \
	C(CNT_TX_MODIFY)

enum e_rxCounters { THE_RX_COUNTERS(GENERATE_ENUM) LAST_COUNTER_RX };
enum e_txCounters { THE_TX_COUNTERS(GENERATE_ENUM) LAST_COUNTER_TX };
extern uint32_t countersRx[INGRESS_MAX][LAST_COUNTER_RX];
extern uint32_t countersTx[EGRESS_MAX][LAST_COUNTER_TX];


//=============================================================================
//===== CAN format configurations in FIFO buffers
//=============================================================================

// #define CAN_VER_C20s  0
// #define CAN_VER_CFDs  1
// #define CAN_VER_C20x  2
// #define CAN_VER_CFDx  3
// #define CAN_VER_CXL   4

#define CAN_VERSION_STR {"CCb", "FDb", "CCe", "FDe", "XL "}

#define PROTOCOL_STR {"bff", "eff", "xlff", "t1s", "ccr"}
#define PROTOCOL_bff  0 // CC and FD frame w/ standard identifier
#define PROTOCOL_eff  1 // CC and FD frame w/ extended identifier
#define PROTOCOL_xlff 2 // XL frame
#define PROTOCOL_t1s  3 // T1S frame
#define PROTOCOL_ccr  4 // CC remote frame


//=============================================================================
//====== Defines for the EthIf configuration
//=============================================================================
#define MAX_FRAME_OWNERS 			20  // Maximum number of frame type to owner mappings---
#define MAX_DEFAULT_ETH_CTRL 		16  //Default value : Will be updated from json config during run time
#define DEFAULT_VLAN_ID             1


//=============================================================================
//====== Defines for CAN to Eth and ETH to CAN configuration
//=============================================================================
// #define ACF_CAN_BRIEF 0x02

enum e_canTableFormat {Id11, XL, Id29, max_canTableFormat};
enum e_ethTableFormat {
    EthType,     // For EtherType matching (16-bit)
    VlanDa,      // For VLAN + Destination MAC address matching (48-bit)
    Ieee1722,    // For IEEE 1722 stream ID matching (64-bit)
    max_ethTableFormat
};

struct s_fifoEntryMeta {
	//common meta header M0~M3
	unsigned len   : 12; //M0
	unsigned rsv1  :  3;
	unsigned ti    :  1;
	unsigned prot  :  4;
	unsigned rsv2  :  4;
	unsigned ipn   :  8;
	//unsigned tsrq  :  1;
	unsigned pduid : 32; //M1
	unsigned ts_l  : 32; //M2
	unsigned ts_h  : 32; //M3
};

struct s_fifoCanEntry {
	//common meta header M0~M3
	unsigned len   : 12;  //0
	unsigned rsv1  :  3;  //12
	unsigned ti    :  1;  //15
	unsigned prot  :  4;  //16
	unsigned rsv2  :  4;
	unsigned ipn   :  8;  //24
	//unsigned tsrq  :  1;  //31

	unsigned pduid : 32;

	unsigned ts_l  : 32;
	unsigned ts_h  : 32;

	//CAN specific header H0~H2, M4~M7
	unsigned id    : 29;
	unsigned rsv3  :  1;
	unsigned cc    :  1;
	unsigned fd    :  1;

	unsigned sdt   :  8;
	unsigned vcid  :  8;
	unsigned sec   :  1;
	unsigned esi   :  1;
	unsigned brs   :  1;
	unsigned rtr   :  1;
	unsigned rsv4  : 12;

	unsigned af    : 32;
	//data
	uint8_t data[4]; //this struct is used for casting only, the real size is controlled outside
};
#define FIFO_CAN_HEADER_SIZE8 (sizeof(struct s_fifoCanEntry)-4)  //without the data field

struct s_fifoEthEntry {
	//common meta header M0~M3
	unsigned len   : 12;
	unsigned rsv1  :  3;
	unsigned ti    :  1;
	unsigned prot  :  4;
	unsigned rsv2  :  4;
	unsigned ipn   :  8;  //0~31 physical, 64~67 cpu partition, 96~127 vPort
	//unsigned tsrq  :  1;

	unsigned pduid : 32;
	unsigned ts_l  : 32;
	unsigned ts_h  : 32;
	//data
	uint8_t data[64]; //this struct is used for casting only, the real size is controlled outside
};
#define FIFO_ETH_HEADER_SIZE8 (sizeof(struct s_fifoEthEntry)-4)  //without the data field


union u_fifoEntry {
	struct s_fifoEntryMeta meta;
	struct s_fifoCanEntry  can;
	struct s_fifoEthEntry  eth;
	uint8_t                data8[1];  //this struct is used for casting only, the real size is controlled outside
	uint32_t               data32[1]; //this struct is used for casting only, the real size is controlled outside
};


//helper structure for endian conversion
struct s_acfBuf {
	uint32_t lit[BIGENDIAN_OFFSET / 4];
	uint32_t big[BIGENDIAN_OFFSET / 4];
};


//=============================================================================
//====== Structures for CAN ingress classification and rules
//=============================================================================
// struct s_canFdEntry11 {
// 	uint32_t CanIfRxPduCanId;
// };

// struct s_canFdEntry29 {
// 	uint32_t CanIfRxPduCanId;
// };

// struct s_canXlEntry {
// 	uint16_t CanIfXLPriorityId;  //11 bit needed
// 	uint8_t  CanIfXLSduType;
// 	uint8_t  CanIfXLVcid;
// 	uint32_t CanIfXLAcceptanceField;
// };

// union u_canEntry {
// 	//This entries tables can be accessed as array and have same
// 	//index as the action table. Based in the initial index in
// 	//s_ingressConfig the c-code knows which container type to be
// 	//addressed.
// 	struct s_canFdEntry11 *id11;
// 	struct s_canFdEntry29 *id29;
// 	struct s_canXlEntry *xl;
// };

union u_canIfTxPduCfg {
	uint32_t    val32;
	struct s_canIfTxPduCfg {
		unsigned canId      : 29;
		unsigned protocol   :  2;  //as per PROTOCOL 0~2
		unsigned protocolFD :  1;  //on protocol = 0,1   (same bit as in meta)
	} field;
};

struct s_canAction {
	uint16_t                CanIfRxPduDataLength;  //min size of PDU
	uint8_t             	modifyOnTarget;        //on CAN target: one bit for each target (0x03 means target 1 and 2),
	uint8_t             	flushOnTarget;         //on Stream target: means flush in case of stream target
	uint32_t                CanIfRxPduId;
	uint32_t                TargetVector;          //bit vector defining 32 targets buffers
	union {
		union u_canIfTxPduCfg  single;
		union u_canIfTxPduCfg *multi;
	} CanIfTxPduCfg;
};

//For fixed search table layout the lookup entries and actions are split
struct s_RxPduCfg {
	struct s_lupTable *search;  //contains size and table itself
	struct s_canAction   *action;  //default action is at [-1]
};


//=============================================================================
//====== Structures for ETH ingress classification and rules
//=============================================================================

/* Structure for Ethernet frame actions */
struct s_ethAction {
    uint16_t FrameOwner;       // Frame owner ID
	uint8_t  searchET;         //Number of ET table (255 for none)
	uint8_t  search1722;       //Boolean
    uint32_t TargetVector;     // Target vector for routing
};

struct s_ethRxPduCfg {
	struct s_lupTable *search;  // Points to the unified lookup table
	struct s_ethAction   *ethaction;  // Default action is at [-1]
};


//=============================================================================
//====== Structures for 1722 stream handling
//=============================================================================
struct s_1722streamGen {
	uint16_t		   templateLength;
	uint16_t		   patchDataLengthWord;
	//uint8_t	       reserved2;
	uint16_t           maxFrameSize;
	uint16_t           txTimeout;       //in µs (0=immediately, 1µs - 60 ms)
	struct s_ethAction action;          //allows direct forwarding
	uint32_t           template[];
};

struct s_1722streamTerm {
	uint8_t	       vPortIndex;
	uint8_t		   exceptionPortIndex;
	uint16_t	   reserved1;
};


//=============================================================================
//====== Structures for the buffer configuration
//=============================================================================
union u_table {
	struct s_RxPduCfg rxPduCfg[max_canTableFormat];
	struct s_ethRxPduCfg rxEthPduCfg[max_ethTableFormat];
};

struct s_ingressConfig {
	uint32_t fifoBaseAddr;
	uint16_t fifoEntrySize;  //This is intended to realise the name EthIfCtrlMtu check
	uint8_t  fifoEntries;
	uint8_t  reserved1;
	//union u_classification table;--make changes in the c code it should work table.search or table.action no need to modify json as well
	union u_table table;
};


struct s_egressConfig {
	uint32_t fifoBaseAddr;
	uint16_t fifoEntrySize;
	uint8_t  fifoEntries;
	int8_t   streamHandle;  //-1 for no stream (in case of ETH->s_1722streamTerm, CAN->s_1722streamGen
};


//=============================================================================
//====== Main configuration structure
//=============================================================================

struct s_raConfig {
	struct s_ingressConfig  *ingress;
	struct s_egressConfig   *egress;
	struct s_1722streamGen  **streamGenCfg;  //defined inside a list of pointers to allow 8bit index in CAN action
	struct s_1722streamTerm **streamTermCfg; //defined inside a list of pointers to allow 8bit index in CAN action
	uint8_t  maxIngress;
	uint8_t  maxEgress;
	uint8_t  maxStreamGen;       //required for sequence number extraction in init code
	uint8_t  dbg_maxStreamTerm;  //only for printout
};


//This is our global configuration variable
extern const struct s_raConfig *raConfig;

//from ACF stream generation
extern uint16_t streamSize[EGRESS_STREAM_MAX];
extern uint8_t  streamGenSequence[EGRESS_STREAM_MAX];
extern int16_t  streamTermSequence[INGRESS_STREAM_MAX];
extern uint8_t  vPortPending[INGRESS_STREAM_MAX];

//some helpers for debug from canhw_dbg.c
extern uint8_t ingressFifoEntryNumber[];

void dbg_checkPythonStarted();
void dbg_printConfiguration(int VERBOSE);
void dbg_print_IngressFrame(int idx, int page);
int  dbg_sanity_check_IngressFrame(uint32_t idx);

//Stream handling in conv_acf.c
int can_eth(const union u_fifoEntry *inBuf, union u_fifoEntry *tgBuf, const int stream, const struct s_1722streamGen *streamGenCfg, const int flushOnTarget);
int eth_can(const union u_fifoEntry *inBuf, const struct s_ingressConfig *vPortIn, const int stream, const int vPortIndex, uint8_t *egressFifoEntryNumber);

//Call backs from conv_acf.c
void rx_indication(int idx, const union u_fifoEntry *inBuf);


//-----------------------------------------------------------------------------
#ifdef USE_COPY_HW
inline static void bufferCpy(uint32_t *tgBuf, const uint32_t *srcBuf, uint32_t cnt8)
{
	dcm_rta[0] = tgBuf;
	dcm_rsa = srcBuf;
	dcm_len = cnt8+3;
	while (dcm_stat&0x80000000);
}
#else
#include <string.h>
inline static void bufferCpy(uint32_t *tgBuf, const uint32_t *srcBuf, uint32_t cnt8)
{
	//dbg_printf("memcpy(%p, %p, %d)\n", tgBuf, srcBuf, (cnt8+3)&0xfffffffc);
	memcpy(tgBuf, srcBuf, (cnt8+3)&0xfffffffc);
}
#endif

#endif
