"""
Test scenarios for Ethernet frame processing with different configurations.
Updated to use actual MAC addresses from config.json VlanDaTableCfg entries.
"""
import sys
# print(sys.argv)
# exit(1)

# Import required constants and types
from moduleComif import *


# Check testcase name is provided by the make command
if len(sys.argv) != 2:
	print(f"\n{RED}Missing parameter TC, use: {YELLOW}make run TC=<name>{NORM}\n")
	exit(5)

testcase = sys.argv[1]
print(f"{YELLOW}  PY  Chosen testcase: %s {NORM}"%testcase, end="\n")

# Initialize test stimulus definitions
rxStimulusDef = [None] * 32

expectedFramesNotTransmitted = []

# ============================================================================
# TEST SCENARIO SELECTION
# Set one of these to True to activate the corresponding test scenario
# ============================================================================
if testcase == 'can1' or testcase == "default":
	print(f"  PY  Tests triggering all basic CAN/CAN cases")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	frames = 1

	expectedFramesNotTransmitted = [["0>Id11.231.CC>4", 1]
	                               ,["0>Id11.232.FD>4", 1]
	                               ]

	rxStimulusDef[0] = ([
		#1:1 forwarding to 8~16
		[100, FDb, 64, [1.0, 0.3], frames],
		[101, FDb, 32, [1.0, 0.3], frames],
		[102, FDb, 24, [1.0, 0.3], frames],
		[103, FDb, 16, [1.0, 0.3], frames],
		[104, FDb, 10, [1.0, 0.3], frames],
		[105, CCb,  3, [1.0, 0.3], frames],
		[106, CCb,  1, [1.0, 0.3], frames],
		[107, CCb,  0, [1.0, 0.3], frames],

		#1:N forwarding to 8~16
		[120, FDb, 64, [1.5, 0.3], frames],
		[121, FDb, 64, [1.5, 0.3], frames],
		[122, FDb, 64, [1.5, 0.3], frames],
		[123, FDb, 64, [1.5, 0.3], frames],
		[124, FDb, 64, [1.5, 0.3], frames],
		[125, CCb, 64, [1.5, 0.3], frames],
		[126, CCb, 64, [1.5, 0.3], frames],
		[127, CCb, 64, [1.5, 0.3], frames],
#
		#1:1 with Id replacement
		[130, CCb, 0, [2.5, 0.3], frames],  #No action
		[131, CCb, 1, [2.5, 0.3], frames],
		[131, FDb, 1, [2.5, 0.3], frames],  #->CC,11
		[132, CCb, 2, [2.5, 0.3], frames],  #->FD,11
		[132, FDb, 2, [2.5, 0.3], frames],
		[133, CCb, 3, [2.5, 0.3], frames],  #->CC,29
		[133, FDb, 3, [2.5, 0.3], frames],  #->CC,29
		[134, CCb, 4, [2.5, 0.3], frames],  #->FD,29
		[134, FDb, 4, [2.5, 0.3], frames],  #->FD,29
		#1:N with Id replacement
		[135, CCb, 5, [2.5, 0.3], frames],  #->Id29.20035.FD ->Id11.235.CC
		[135, FDb, 5, [2.5, 0.3], frames],  #->Id29.20035.FD ->Id11.235.CC
		[136, CCb, 6, [2.5, 0.3], frames],  #->Id29.20036.FD ->Id11.236.FD ->Id11.236.CC ->Id29.20036.CC
		[136, FDb, 6, [2.5, 0.3], frames],  #->Id29.20036.FD ->Id11.236.FD ->Id11.236.CC ->Id29.20036.CC
		[137, CCb, 7, [2.5, 0.3], frames],
		#An unknown id goes to default rule (discarded)
		[138, CCb, 7, [2.5, 0.3], frames],

		#Length check and truncation
		[140, FDb, 20, [3.5, 0.3], frames], #min 20  (ok)
		[140, FDb, 19, [3.5, 0.3], frames], #min 20  (discard)
		[141, CCb, 2,  [3.5, 0.3], frames],  #min 1  (ok)
		[141, CCb, 1,  [3.5, 0.3], frames],  #min 1  (ok)
		[141, CCb, 0,  [3.5, 0.3], frames],  #min 1  (discard)
		[142, FDb, 64, [3.5, 0.3], frames],
		[142, FDb, 63, [3.5, 0.3], frames],
		#trunc
		[143, FDb, 60, [3.5, 0.3], frames], #truncated after 88 (60 bytes)
		[143, FDb, 61, [3.5, 0.3], frames],
		[144, FDb, 64, [3.5, 0.3], frames], #truncated after 88 (60 bytes)
		[144, FDb, 65, [3.5, 0.3], frames], #truncated to 64 bytes based on target (92 bytes), TUBE has no check on CAN DLC
		[145, FDb, 65, [3.5, 0.3], frames], #not truncated. Storage to CAN-IP will discard such oversized frames
	  ])

# ============================================================================
elif testcase == 'can2':
	print(f"  PY  Tests triggering basic CAN/ETH cases")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	frames = 1

	rxStimulusDef[0] = ([
		#1:1 forwarding into stream
		[100, FDb, 64, [1.0, 0.3], frames],  #can/can
		#[200, FDb, 64, [1.5, 0.3], frames],  #can->stream0
		#[209, FDb, 32, [2.0, 0.3], frames],  #can->stream0

		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1
		[210, FDb, 64, [2.5, 0.3], frames],  #can->stream1 (send)

		[200, FDb, 4, [4.0, 0.3], frames],  #can->stream0 (send)
		[201, FDb, 5, [4.0, 0.3], frames],  #can->stream0 (send)
		[202, FDb, 6, [4.0, 0.3], frames],  #can->stream0 (send)
		[203, FDb, 7, [4.0, 0.3], frames],  #can->stream0 (send)
		[204, FDb, 8, [4.0, 0.3], frames],  #can->stream0 (send)

		# [201, FDb, 32, [1.0, 0.3], frames],
		# [102, FDb, 24, [1.0, 0.3], frames],
	  ])
	rxStimulusDef[1] = ([
		#1:1 forwarding into stream
		[100, FDb, 64, [1.0, 0.3], frames],  #can/can
		[209, FDb, 32, [2.0, 0.3], frames],  #can->stream0
	])

# ============================================================================
elif testcase == 'honda6':
	print(f"  PY  Tests for the Honda 6 CAN interface with parallel input")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	frames = 2
	gap64 = 0.2
	gap1 = 0.1

	rxStimulusDef[0] = ([
		[210, FDb, 64, [1, gap64], frames],  #can->stream1
		[210, FDb,  1, [1.5, gap1], frames],  #can->stream1
		[200, FDb,  1, [2, gap1], frames],  #can->stream1
	  ])
	rxStimulusDef[1] = ([
		[211, FDb, 64, [1, gap64], frames],  #can->stream1
		[211, FDb,  1, [1.5, gap1], frames],  #can->stream1
		[200, FDb,  1, [2, gap1], frames],  #can->stream1
	  ])
	rxStimulusDef[2] = ([
		[212, FDb, 64, [1, gap64], frames],  #can->stream1
		[212, FDb,  1, [1.5, gap1], frames],  #can->stream1
		[200, FDb,  1, [2, gap1], frames],  #can->stream1
	  ])
	rxStimulusDef[3] = ([
		[213, FDb, 64, [1, gap64], frames],  #can->stream1
		[213, FDb,  1, [1.5, gap1], frames],  #can->stream1
		[200, FDb,  1, [2, gap1], frames],  #can->stream1
	  ])
	rxStimulusDef[4] = ([
		[214, FDb, 64, [1, gap64], frames],  #can->stream1
		[214, FDb,  1, [1.5, gap1], frames],  #can->stream1
		[200, FDb,  1, [2, gap1], frames],  #can->stream1
	  ])
	rxStimulusDef[7] = ([
		[219, FDb, 64, [1, gap64], frames],  #can->stream1 (219 on 5 flushes)
		[219, FDb,  1, [1.5, gap1], frames],  #can->stream1
		[200, FDb,  1, [2, gap1], frames],  #can->stream1
	  ])

# ============================================================================
elif testcase == 'can3':
	print(f"{CYAN}CAN SCENARIO: Some FD frames with different number of data bytes and with one target{NORM}")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	rxStimulusDef[2] = ([
	    [0x3b4, FDb, 64, [ 5.0, -1], 1, {"RTR":0, "BRS":1, "ESI":0 }],  # ID=948  target is FIFO 5
	  ])

# ============================================================================
elif testcase == 'eth1':
	print(f"{CYAN}CAN SCENARIO: Basic Ethernet forwarding cases{NORM}")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	rxStimulusDef[0] = ([
		#[210, FDb, 64, 1, 1],  #can->stream1
	  ])

	rxStimulusDef[8] = ([
		["aa:bb:cc:dd:ee:Ff", T1S,  60,  1.0, 1, {"ET":0x0800}],              #per MACVL
		["00:11:22:33:44:02", T1S, 128,  1.5, 1, {"ET":0x0801, "VID":4}],     #discarded by ET
		["00:11:22:33:44:02", T1S, 228,  1.5, 1, {"ET":0x4004, "VID":4}],     #per ET
		["e0:e1:e2:e3:e4:e5", T1S, 158,  2,   1, {"ET":0x04002, "VID":7}],    #per ET
		["e0:e1:e2:e3:e4:e5", T1S, 0x20, 2.5, 1, {"SID":0x0123_4567_89ab_cdef, "VID":7}], #per SID
		["01:88:99:88:77:88", T1S, 500,  3,   1, {"ET":0xABCD}], #per MACVL
	])

	rxStimulusDef[3] = ([
		# ["02:03:04:05:06:07", T1S, 100, 2.5, 1, {"ET":0x0802, "VID":151, "PCP":3}],
		# ["12:13:14:15:16:17", T1S, 500, 3.5, 1, {"SID":0x0123_4567_89ab_cdef}],
	])

# ============================================================================
elif testcase == 'eth2':
	print(f"{CYAN}CAN SCENARIO: Triggers Ethernet to CAN{NORM}")
	configJsonFile = 'config.json'  #json file loaded for this testcase

	rxStimulusDef[0] = ([
		#A simple CAN frame as reference
		[100, FDb, 64, 1, 1],
	  ])

	rxStimulusDef[8] = ([
		#A simple ETH frame as reference
		["00:11:22:33:44:02", T1S, 64,  1.5, 1, {"ET":0x4004, "VID":4}],     #per ET

		#Singe ACF in stream (with padding)
		["e0:e1:e2:e3:e4:e5", T1S, 100, 2, 1, {"SID":0x11112222_33334444, "VID":7, "ACF":[
				[213, CCb, 7],
			], "hasException":False}],
		#Single ACF but send also to other ETH
		["10:11:12:13:14:A0", T1S, 100, 3, 1, {"SID":0x11112222_33334444, "VID":99, "ACF":[
				[214, CCb, 7],
			]}],
		#Multiple ACF in stream (exact fit)
		["e0:e1:e2:e3:e4:e5", T1S, 134, 4, 1, {"SID":0x11112222_33334444, "VID":7, "ACF":[
				[215, CCb, 1],
				[216, FDb, 12, {"RTR":0, "BRS":1, "ESI":0}],
				[217, FDb, 64, {"RTR":0, "BRS":0, "ESI":1}],
			]}],
		#Multiple ACF in stream (oversized)
		["e0:e1:e2:e3:e4:e5", T1S, 133, 5, 1, {"SID":0x11112222_33334444, "VID":7, "ACF":[
				[100, CCb, 1],
				[101, FDb, 10, {"RTR":0, "BRS":1, "ESI":1}],
				[102, FDb, 64],
			], "hasException":True}],
		#Multiple ACF in stream (oversized) and send to other ETH
		["10:11:12:13:14:A0", T1S, 99, 6, 1, {"SID":0x11112222_33334444, "VID":99, "ACF":[
				[100, CCb, 1],
				[101, FDb, 10, {"RTR":0, "BRS":1, "ESI":1}],
				[102, FDb, 64],
			], "hasException":True}],
	])

	rxStimulusDef[3] = ([
		# ["02:03:04:05:06:07", T1S, 100, 2.5, 1, {"ET":0x0802, "VID":151, "PCP":3}],
		# ["12:13:14:15:16:17", T1S, 500, 3.5, 1, {"SID":0x0123_4567_89ab_cdef}],
	])

# ============================================================================
else:
	print(f"\n{RED}PY  testcase = %s is not defined!{NORM}"%testcase, end="\n\n")
	exit(5)
