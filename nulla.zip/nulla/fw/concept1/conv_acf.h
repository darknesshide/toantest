#ifndef __RACANETH_ACF_H__
#define __RACANETH_ACF_H__

#include <stdint.h>

#include "ra_adrmap.h"
#include "racfg.h"         //Configuration of RA system

#define ACF_CAN_BRIEF    0x02
#define ACF_CAN_XL_BRIEF 0x12
#define NTSCF_SUBTYPE    0x82

// #define BYTE0
// #define BYTE2
// #define FORLOOP
// #define MEMCPY
// #define D_MEASURE

// struct s_acf_can_brief {
// 	unsigned can_bus_id       :  5;
// 	unsigned rsv1             :  3;
// 	unsigned esi              :  1;
// 	unsigned fdf              :  1;
// 	unsigned brs              :  1;
// 	unsigned eff              :  1;
// 	unsigned rtr              :  1;
// 	unsigned mtv              :  1;
// 	unsigned pad              :  2;
// 	unsigned acf_msg_length   :  9; // number of words (acf_msg_payload (incl. pad bytes) + 2 header
// 	unsigned acf_msg_type     :  7; // 0x02 for ACF_CAN_BRIEF

// 	unsigned can_identifier   : 29;
// 	unsigned rsv2             :  3;
// 	// data
// 	uint8_t  can_msg_payload[64];   //this struct is used for casting only, the real size is controlled outside
// };
// struct s_acf_can_brief_lit {
// 	unsigned acf_msg_length_8   :  1; // number of words (acf_msg_payload (incl. pad bytes) + 2 header
// 	unsigned acf_msg_type       :  7; // 0x02 for ACF_CAN_BRIEF
// 	unsigned acf_msg_length_7_0 :  8; // number of words (acf_msg_payload (incl. pad bytes) + 2 header
// 	unsigned esi                :  1;
// 	unsigned fdf                :  1;
// 	unsigned brs                :  1;
// 	unsigned eff                :  1;
// 	unsigned rtr                :  1;
// 	unsigned mtv                :  1;
// 	unsigned pad                :  2;
// 	unsigned can_bus_id         :  5;
// 	unsigned rsv1               :  3;
// 	unsigned can_id_28_24       :  5;
// 	unsigned rsv2               :  3;
// 	unsigned can_id_23_16       :  8;
// 	unsigned can_id_15_8        :  8;
// 	unsigned can_id_7_0         :  8;
// 	// data
// 	uint8_t  can_msg_payload[64];   //this struct is used for casting only, the real size is controlled outside
// };
// struct s_acf_can_brief_noalign {
// 	unsigned acf_msg_length   :  9; // number of words (acf_msg_payload (incl. pad bytes) + 2 header
// 	unsigned acf_msg_type     :  7; // 0x02 for ACF_CAN_BRIEF
// 	unsigned rsv0a            : 16;

// 	unsigned can_identifier_h : 13;
// 	unsigned rsv0b            :  3;
// 	unsigned can_bus_id       :  5;
// 	unsigned rsv1             :  3;
// 	unsigned esi              :  1;
// 	unsigned fdf              :  1;
// 	unsigned brs              :  1;
// 	unsigned eff              :  1;
// 	unsigned rtr              :  1;
// 	unsigned mtv              :  1;
// 	unsigned pad              :  2;

// 	unsigned can_msg_payload0 : 16;
// 	unsigned can_identifier_l : 16;
// 	// data
// 	uint8_t  can_msg_payload[64];   //this struct is used for casting only, the real size is controlled outside
// };
// struct s_acf_can_brief_noalign_lit {
// 	unsigned rsv0               : 16;
// 	unsigned acf_msg_length_8   :  1; // number of words (acf_msg_payload (incl. pad bytes) + 2 header
// 	unsigned acf_msg_type       :  7; // 0x02 for ACF_CAN_BRIEF
// 	unsigned acf_msg_length_7_0 :  8; // number of words (acf_msg_payload (incl. pad bytes) + 2 header

// 	unsigned esi                :  1;
// 	unsigned fdf                :  1;
// 	unsigned brs                :  1;
// 	unsigned eff                :  1;
// 	unsigned rtr                :  1;
// 	unsigned mtv                :  1;
// 	unsigned pad                :  2;
// 	unsigned can_bus_id         :  5;
// 	unsigned rsv1               :  3;
// 	unsigned can_id_28_24       :  5;
// 	unsigned rsv2               :  3;
// 	unsigned can_id_23_16       :  8;

// 	unsigned can_id_15_8        :  8;
// 	unsigned can_id_7_0         :  8;
// 	unsigned can_msg_payload0   :  8;
// 	unsigned can_msg_payload1   :  8;
// 	// data
// 	uint8_t  can_msg_payload[64];   //this struct is used for casting only, the real size is controlled outside
// };
// union u_acf_can_brief {
// 	struct s_acf_can_brief             acf;
// 	struct s_acf_can_brief_lit         acf_lit;
// 	struct s_acf_can_brief_noalign     acf_noalign;
// 	struct s_acf_can_brief_noalign_lit acf_noalign_lit;
// 	uint32_t word[2];
// };

// struct s_acf_can_xl_brief {
// 	unsigned acf_msg_type     :  7; // 0x12 for ACF_CAN_XL_BRIEF
// 	unsigned acf_msg_length   :  9; // number of words (acf_msg_payload (incl. pad bytes) + 4 header
// 	unsigned pad              :  2;
// 	unsigned mtv              :  1;
// 	unsigned rsv1             :  2;
// 	unsigned can_bus_id       : 11;

// 	unsigned vcid             :  8;
// 	unsigned sdt              :  8;
// 	unsigned rsv2             :  3;
// 	unsigned rrs              :  1;
// 	unsigned sec              :  1;
// 	unsigned priority_id      : 11;

// 	unsigned acceptance_field : 32;

// 	unsigned rsv3             :  8;
// 	unsigned transaction_num  :  8;
// 	unsigned rsv4             :  3;
// 	unsigned ms               :  1;
// 	unsigned segment_num      : 12;
// 	//data
// 	uint8_t  can_msg_payload[2048]; //this struct is used for casting only, the real size is controlled outside
// };
// union u_acf_can_xl_brief {
// 	struct s_acf_can_xl_brief acf;
// 	uint32_t word[4];
// };

// struct s_can_buffer {
// 	unsigned len     : 12;  // M0 - number of bytes
// 	unsigned rsv1    :  4;  // M0
// 	unsigned prot    :  4;  // M0
// 	unsigned rsv2    :  4;  // M0
// 	unsigned ipn     :  7;  // M0
// 	unsigned tsqr    :  1;  // M0

// 	unsigned rsv3    : 32;  // M1
// 	unsigned rsv4    : 32;  // M2
// 	unsigned rsv5    : 32;  // M3

// 	unsigned canid   : 29;  // H0
// 	unsigned rsv6    :  1;  // H0
// 	unsigned fd      :  1;  // H0
// 	unsigned xtd     :  1;  // H0

// 	unsigned sdt     :  8;  // H1 - CAN XL only
// 	unsigned vcid    :  8;  // H1 - CAN XL only
// 	unsigned sec     :  1;  // H1 - CAN XL only
// 	unsigned esi     :  1;  // H1 - CAN XL only
// 	unsigned brs     :  1;  // H1 - CAN XL only
// 	unsigned rrs     :  1;  // H1 - CAN XL only
// 	unsigned rsv7    :  1;  // H0

// 	unsigned af      : 32;  // H2 - CAN XL only
// 	//data
// 	uint8_t  payload[2048]; //this struct is used for casting only, the real size is controlled outside
// };
// struct s_buffer {
// 	uint32_t lit[BIGENDIAN_OFFSET / 4];
// 	uint32_t big[BIGENDIAN_OFFSET / 4];
// };
// union u_can_buffer {
// 	struct s_can_buffer buffer;
// 	uint32_t word[4];
// };

// struct s_acf_h_vlan {
// 	unsigned da_l      : 32;  // H0
// 	unsigned da_h_sa_l : 32;  // H1
// 	unsigned sa        : 32;  // H2

// 	unsigned etype1    : 16;  // H3
// 	unsigned vlan      : 16;  // H3

// 	unsigned etype2    : 16;  // H4
// 	unsigned stype     :  8;  // H4
// 	unsigned sv        :  1;  // H4
// 	unsigned version   :  3;  // H4
// 	unsigned rsv1      :  1;  // H4
// 	unsigned n_len_h   :  3;  // H4 ntscf_data_len in octets of acf_payload_data (several ACF messages)

// 	unsigned n_len_l   :  8;  // H5
// 	unsigned seq_num   :  8;  // H5
// 	unsigned stream_l  : 16;  // H5

// 	unsigned stream_m  : 32;  // H6

// 	unsigned stream_h  : 16;  // H7
// 	unsigned rsv2      : 16;  // H7
// };
// union u_acf_h_vlan {
// 	struct s_acf_h_vlan acf;
// 	uint32_t word[6];
// };

// struct s_acf_header {
// 	unsigned da_l      : 32;  // H0
// 	unsigned da_h_sa_l : 32;  // H1
// 	unsigned sa        : 32;  // H2

// 	unsigned etype     : 16;  // H3
// 	unsigned stype     :  8;  // H3
// 	unsigned sv        :  1;  // H3
// 	unsigned version   :  3;  // H3
// 	unsigned rsv1      :  1;  // H3
// 	unsigned n_len_h   :  3;  // H3 ntscf_data_len in octets of acf_payload_data (several ACF messages)

// 	unsigned n_len_l   :  8;  // H4
// 	unsigned seq_num   :  8;  // H4
// 	unsigned stream_l  : 16;  // H4

// 	unsigned stream_m  : 32;  // H5

// 	unsigned stream_h  : 16;  // H6
// 	unsigned rsv2      : 16;  // H6
// };
// union u_acf_header {
// 	struct s_acf_header acf;
// 	uint32_t word[5];
// };

//void can_acf_byte2 (const union u_fifoEntry * inbuf, struct s_acfBuf * outbuf, union u_acf_h_vlan * acf_h_v_dram);

int can_eth(const union u_fifoEntry *inBuf, union u_fifoEntry *tgBuf, int stream, const struct s_1722streamGen *streamGenCfg, int flushOnTarget);
int eth_can(const union u_fifoEntry *inBuf, union u_fifoEntry *tgBuf, const int tgEntrySize);


#endif