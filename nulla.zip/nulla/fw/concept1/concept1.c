//Simple CAN/CAN gateway application
//
//Configuration is provided by external memory pre-loading.
// All configuration combined in struct s_raConfig and accessed by the
// C-Code using a pointer to a specific address (RA_CONFIG_ADDR) inside
// the Data RAM.
//
//This code contains parts not functionally required. These
//parts are marked by dbg_...
//-------------------------------------------------------------------

#include <stdint.h>
#include <string.h>

//Enable HW usage by make with CCFLAGS="-DUSE_LOOKUP_HW"  (SHALL be before racfg.h)
#define USE_LOOKUP_HW
//#define USE_COPY_HW  //TODO: allow combination of lookup HW and 1722
#define USE_FIFO_MNGR_HW

#include "ra_adrmap.h"     //RA Hardware mapping
#include "racfg.h"         //Configuration of RA system
//#include "conv_acf.h"  //Configuration and function for ACF handling

//Some debug and measurement configurations
#define VERBOSE_GENERAL
#ifdef VERBOSE_GENERAL
	#define MEASURE_RX_INDICATION
	#if 0
		#define MEASURE_LOOKUP
		#define MEASURE_CLASSIFY
		#define MEASURE_WRITE
		#define MEASURE_FIFO_MNGR
		#define MEASURE_COPY
		#define MEASURE_STREAM_GEN
		#define MEASURE_STREAM_TERM
	#endif

	// #define VERBOSE_CLASSIFY
	// #define VERBOSE_FORWARD
#endif


//Configuration **************************************************
#define RA_CONFIG_ADDR      0x6000   //Address inside dram

const struct s_raConfig *raConfig;


//Statistics **************************************************
uint32_t countersRx[INGRESS_MAX][LAST_COUNTER_RX];
uint32_t countersTx[EGRESS_MAX][LAST_COUNTER_TX];
#ifdef VERBOSE_GENERAL
	static const char *dbg_COUNTER_RX_STR[] = { THE_RX_COUNTERS(GENERATE_STRING) };
	static const char *dbg_COUNTER_TX_STR[] = { THE_TX_COUNTERS(GENERATE_STRING) };
#endif


//Internal variables *****************************************
uint8_t ingressFifoEntryNumber[INGRESS_MAX];  //used in dbg_
static uint8_t egressFifoEntryNumber[EGRESS_MAX];

#ifdef VERBOSE_GENERAL
	#define MEASURE_FRAMES 100  //How many frames should be measured and reported
	static uint32_t time_frame_cnt;
	#ifdef MEASURE_RX_INDICATION
		static uint32_t time_rxindication_sum;        // For global average
		static uint32_t time_rxindication_cnt;
		static uint16_t time_sourceIf[MEASURE_FRAMES];
		static uint16_t time_rxindication[MEASURE_FRAMES];
		static uint16_t time_rxindication_size[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_CLASSIFY
		static uint16_t time_classify[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_LOOKUP
		static uint16_t time_lookup[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_WRITE
		static uint16_t time_write[MEASURE_FRAMES];
		static uint8_t  time_write_targets[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_COPY
		static uint16_t time_copy[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_FIFO_MNGR
		static uint16_t time_fifo_mngr[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_STREAM_GEN
		static uint16_t time_1722_gen[MEASURE_FRAMES];
	#endif
	#ifdef MEASURE_STREAM_TERM
		static uint16_t time_1722_term[MEASURE_FRAMES];
	#endif

#endif



//-----------------------------------------------------------------------------
#ifdef USE_LOOKUP_HW
inline static int lookup32(const struct s_lupTable *tab, uint32_t value)
{
	lup_value[0] = value;
	lup_table = tab;
	while (lup_status & 0x80000000);
	return lup_found;
}

inline static int lookup64(const struct s_lupTable *tab, uint64_t value)
{
	lup_value[0] = value & 0xffffffff;
	lup_value[1] = value >> 32;
	lup_table = tab;
	while (lup_status & 0x80000000);
	return lup_found;
}
#else
int lookup32(const struct s_lupTable *tab, uint32_t value); //the software function
int lookup64(const struct s_lupTable *tab, uint64_t value);
#endif


//-----------------------------------------------------------------------------
static void can_Write(const struct s_canAction *action, const union u_fifoEntry *inBuf)
{
	//dbg_printf("\033[35mcan_Write() Tx targets=%x id=%d size=%d\033[m  buf_out_full=%x\n", action->TargetVector, inBuf->can.id, inBuf->can.len, buf_out_full);
	int payload_length8;
	int truncated;
	int modifyOnTarget, flushOnTarget;
	const union u_canIfTxPduCfg *modify;

	flushOnTarget = action->flushOnTarget;
	modifyOnTarget = action->modifyOnTarget;
	if (modifyOnTarget == 1)
		modify = &action->CanIfTxPduCfg.single;  //in case of 1 target the
	else
		modify = action->CanIfTxPduCfg.multi;

	#ifdef MEASURE_FIFO_MNGR
		//This part cannot be measured directly because it is inside the loop header
		int tBody = 0;
		int tAll = cpuCycle();
	#endif

	#ifdef USE_FIFO_MNGR_HW
		int32_t tg;
		buf_out_targets = action->TargetVector;
		uint32_t usedTargets = buf_out_targets;  //all targets that will be processed
		#ifdef VERBOSE_FORWARD
			dbg_printf("can_Write() targets=%x full=%x\n", usedTargets, buf_out_full);
		#endif

		//Count all busy output fifos
		while ((tg=buf_out_busy) != -1)
			countersTx[tg][CNT_TX_BUSY]++;

		while ((tg=buf_out_store) != -1) {{
			//dbg_printf("    tg=%d\n", tg);
	#else
		#ifdef VERBOSE_FORWARD
			dbg_printf("can_Write(): targets=%x busy=%x\n", action->TargetVector, buf_out_full);
		#endif
		//Head of loop
		for (uint32_t mask=1, tg=0; tg < raConfig->maxEgress; mask <<= 1, tg++) {
		  if (action->TargetVector&mask) {
			//dbg_printf("    tg=%d\n", tg);
			if (buf_out_full & mask)
				countersTx[tg][CNT_TX_BUSY]++;
			else
	#endif
			{
				#ifdef MEASURE_FIFO_MNGR
					int t2 = cpuCycle();
				#endif
				struct s_egressConfig *egress = &raConfig->egress[tg];
				union u_fifoEntry *tgBuf = (union u_fifoEntry*)(egress->fifoBaseAddr + egress->fifoEntrySize * egressFifoEntryNumber[tg]);

				//dbg_printf("  tg=%d  streamHandle=%d  flushOnTarget=%x  &action=%x=%x\n", tg, egress->streamHandle, flushOnTarget, action, *(uint32_t*)action);
				if (egress->streamHandle != -1) { // ========== ACF handling: egress-type is Ethernet => CAN to Ethernet
					#ifdef MEASURE_STREAM_GEN
						int t1 = cpuCycle();
					#endif
					//There is no truncation on Tunnel entry

					//dbg_printf("   CAN/ETH ->%d: %x <= %x, %d (%d)  targetConfig=%x\n", tg, tgBuf, inBuf, inBuf->can.len+FIFO_CAN_HEADER_SIZE8, egress->fifoEntrySize, egress);
					int sendBytes = can_eth(inBuf, tgBuf, egress->streamHandle, raConfig->streamGenCfg[egress->streamHandle], flushOnTarget&1);
					//For ETH targets there is no direct buffer release
					if (sendBytes) {
						countersTx[tg][CNT_TX_BYTES] += sendBytes;
						countersTx[tg][CNT_TX_TOTAL]++;
						//And release the target buffer for tranmission
						egressFifoEntryNumber[tg] = (egressFifoEntryNumber[tg]+1) % egress->fifoEntries;
						#ifndef USE_FIFO_MNGR_HW
							buf_out_inc |= (1<<tg);
						#endif
					}
					#ifdef USE_FIFO_MNGR_HW
					else
						usedTargets &= ~(1<<tg);
					#endif

					flushOnTarget >>= 1;  //because ETH targets are behind CAN, no need to handle in parallel with modifyOnTarget
					#ifdef MEASURE_STREAM_GEN
						t1 = cpuCycle() - t1;
						time_1722_gen[time_frame_cnt] = t1;  //overwrite in case of 1:N multicast
					#endif
				}
				else { // ========== CAN handling: egress-type is CAN => CAN to CAN
					//dbg_printf("   CAN/CAN ->%d: %x <= %x, %d (%d)  targetConfig=%x\n", tg, tgBuf, inBuf, inBuf->can.len+FIFO_CAN_HEADER_SIZE8, egress->fifoEntrySize, egress);

					//truncation in case target buffer is smaller (typically a configuration fault)
					if (inBuf->can.len+FIFO_CAN_HEADER_SIZE8 > egress->fifoEntrySize){
						payload_length8 = egress->fifoEntrySize - FIFO_CAN_HEADER_SIZE8;
						truncated = 1;
						countersTx[tg][CNT_TX_TRUNC]++;
					}
					else {
						payload_length8 = inBuf->can.len;
						truncated = 0;
					}
					countersTx[tg][CNT_TX_BYTES] += payload_length8;
					countersTx[tg][CNT_TX_TOTAL]++;

					//Copy the data
					#ifdef MEASURE_COPY
						int t1 = cpuCycle();
					#endif
					bufferCpy(tgBuf->data32, inBuf->data32, payload_length8+FIFO_CAN_HEADER_SIZE8);
					//bufferCpy(tgBuf+2, inBuf->data32+2, payload_length8+FIFO_CAN_HEADER_SIZE8-8);
					#ifdef MEASURE_COPY
						t1 = cpuCycle() - t1;
						time_copy[time_frame_cnt] = t1;  //overwrite in case of 1:N multicast
					#endif

					//Patch the PduId
					tgBuf->meta.pduid = action->CanIfRxPduId;

					//Reformat the header M0 if this is requested for this multicast case
					if (modifyOnTarget & 1) {
						//dbg_printf("   modify %08x %08x modify=%08x (%d %d %x)\n", inBuf->data32[0], inBuf->data32[4], modify->val32, modify->field.protocolFD, modify->field.protocol, modify->field.canId);
						countersTx[tg][CNT_TX_MODIFY]++;

						//tgBuf[0] = (inBuf->data32[0]&0xfff00000) + (modify->protocol<<16) + (truncated<<15) + payload_length8;
						tgBuf->data32[0] = (inBuf->data32[0]&0xfff00000) + ((modify->val32>>13)&0x30000) + (truncated<<15) + payload_length8;  //manual extract of protocol is faster on GCC/RV
						tgBuf->data32[4] = (modify->val32 & 0x9ffffffff) + ((!modify->field.protocolFD)<<30);

						modify++; //next multicast uses the next rule
					}
					else if (truncated) {
						tgBuf->data32[0] = (inBuf->data32[0] & 0xffff0000) | (1<<15) | payload_length8;
						//dbg_printf("   truncate to %d\n", payload_length8);
					}
					modifyOnTarget >>= 1;

					//And release the target buffer for tranmission
					egressFifoEntryNumber[tg] = (egressFifoEntryNumber[tg]+1) % egress->fifoEntries;
					#ifndef USE_FIFO_MNGR_HW
						buf_out_inc |= mask;
					#endif
				}
				#ifdef MEASURE_WRITE
					time_write_targets[time_frame_cnt]++;
				#endif
				#ifdef MEASURE_FIFO_MNGR
					tBody += cpuCycle() - t2;
				#endif
			}
		}
	}
	#ifdef MEASURE_COPY
		tAll = cpuCycle() - tAll;
		time_fifo_mngr[time_frame_cnt] = tAll - tBody;  //overwrite in case of 1:N multicast
	#endif

	//TODO: Copy can speedup by copy all targets in parallel
	#ifdef USE_FIFO_MNGR_HW
		buf_out_inc |= usedTargets;
	#endif
}


//-----------------------------------------------------------------------------
// FIFO write for 1:n case
static void eth_Write(uint32_t targets, const union u_fifoEntry *inBuf, uint32_t pduid)
{
	uint16_t payload_length8;
	uint8_t truncated;

	#ifdef USE_FIFO_MNGR_HW
		int32_t tg;
		buf_out_targets = targets;
		uint32_t usedTargets = buf_out_targets;  //all targets that will be processed
		#ifdef VERBOSE_FORWARD
			dbg_printf("eth_Write(targets=%x)  full=%x\n", usedTargets, buf_out_full);
		#endif

		//Count all busy output fifos
		while ((tg=buf_out_busy) != -1)
			countersTx[tg][CNT_TX_BUSY]++;

		while ((tg=buf_out_store) != -1) {{
			//dbg_printf("    tg=%d\n", tg);
	#else
		#ifdef VERBOSE_FORWARD
			dbg_printf("eth_Write(): targets=%x busy=%x\n", targets, buf_out_full);
		#endif
		//Head of loop
		for (uint32_t mask=1, tg=0; tg < raConfig->maxEgress; mask <<= 1, tg++) {
		  if (targets&mask) {
			//dbg_printf("    tg=%d\n", tg);
			if (buf_out_full & mask)
				countersTx[tg][CNT_TX_BUSY]++;
			else
	#endif
			{
				struct s_egressConfig *egress = &raConfig->egress[tg];

				//dbg_printf("   tg=%d  streamHandle=%d  inLen=%d  egress->fifoSize=%d\n", tg, egress->streamHandle, inBuf->eth.len, egress->fifoEntrySize);
				if (egress->streamHandle != -1) { // ========== StreamHandling: egress-type is Ethernet => Ethernet to CAN
					#ifdef USE_COPY_HW
						dbg_printf("\033[31;1mSkip forwarding: Not functional if USE_COPY_HW is set\033[m\n");
					#else
					#ifdef MEASURE_STREAM_TERM
						int t1 = cpuCycle();
					#endif
					struct s_1722streamTerm *term = raConfig->streamTermCfg[egress->streamHandle];
					//dbg_printf("   ETH/CAN ->%d: streamHandle=%d vPort=%d  %x <= %x, %d (%d)  targetConfig=%x\n", tg, egress->streamHandle, term->vPortIndex, tgBuf, inBuf, inBuf->eth.len+FIFO_ETH_HEADER_SIZE8, egress->fifoEntrySize, egress);

					//For the ACF extraction the target is the vPort ingress FIFO to store the CAN frames.
					//The egressBuffer itself is not used. The egressFifoEntryNumber of the unused streamTarget is
					//used to count the position inside the vPort ingress FIFO
					//TODO
					//Currently there is storage of the complete ethernet frame (decoding on the fly) this
					//not the final solution, because it takes too long processing time.
					int vPort = term->vPortIndex;
					struct s_ingressConfig *vPortIn = &raConfig->ingress[vPort]; //because we need to fill this
					int problem = eth_can(inBuf, vPortIn, egress->streamHandle, vPort, &egressFifoEntryNumber[tg]);
					#ifdef MEASURE_STREAM_TERM
						t1 = cpuCycle() - t1;
						time_1722_term[time_frame_cnt] = t1;  //overwrite in case of 1:N multicast
						dbg_printf("%d cycles for stream termination\n", t1);
					#endif
					if (problem) {
						#ifdef VERBOSE_FORWARD
							dbg_printf("Problem in eth_can() detected  exceptionPortIndex=%d\n", term->exceptionPortIndex);
						#endif
						eth_Write(1 << term->exceptionPortIndex, inBuf, pduid);
					}
					usedTargets &= ~(1<<tg);
					#endif
				}
				else { // ========== ETH handling: egress-type is ETH => ETH to ETH
					union u_fifoEntry *tgBuf = (union u_fifoEntry*)(egress->fifoBaseAddr + egress->fifoEntrySize * egressFifoEntryNumber[tg]);
					//dbg_printf("   ETH/ETH ->%d: %x <= %x, %d (%d)  targetConfig=%x\n", tg, tgBuf, inBuf, inBuf->can.len+FIFO_CAN_HEADER_SIZE8, egress->fifoEntrySize, egress);
					if (inBuf->eth.len + FIFO_ETH_HEADER_SIZE8 + 2 > egress->fifoEntrySize) {
						payload_length8 = egress->fifoEntrySize - FIFO_ETH_HEADER_SIZE8 - 2;
						truncated = 1;
						countersTx[tg][CNT_TX_TRUNC]++;
					}
					else {
						payload_length8 = inBuf->eth.len;
						truncated = 0;
					}
					countersTx[tg][CNT_TX_BYTES] += payload_length8;
					countersTx[tg][CNT_TX_TOTAL]++;

					//Copy the data
					#ifdef MEASURE_COPY
						int t1 = cpuCycle();
					#endif
					//bufferCpy(tgBuf->data32, inBuf->data32, payload_length8+2+FIFO_ETH_HEADER_SIZE8);
					bufferCpy(tgBuf->data32+2, inBuf->data32+2, payload_length8+2+FIFO_ETH_HEADER_SIZE8-2*4);
					//bufferCpy(tgBuf+2, inBuf->data32+2, payload_length8+FIFO_CAN_HEADER_SIZE8-8);
					#ifdef MEASURE_COPY
						t1 = cpuCycle() - t1;
						time_copy[time_frame_cnt] = t1;  //overwrite in case of 1:N multicast
					#endif

					// Update the target header (first 16 bytes)
					tgBuf->data32[0] = (inBuf->data32[0]&0xffff0000) | (truncated << 15) | payload_length8;
					tgBuf->meta.pduid = pduid;

					//And release the target buffer for tranmission
					egressFifoEntryNumber[tg] = (egressFifoEntryNumber[tg] + 1) % egress->fifoEntries;
					#ifndef USE_FIFO_MNGR_HW
						buf_out_inc |= mask;
					#endif
				}
			}
			#ifdef MEASURE_WRITE
				time_write_targets[time_frame_cnt]++;
			#endif
		}
	}
	//TODO: Copy can speedup by copy all targets in parallel
	#ifdef USE_FIFO_MNGR_HW
		buf_out_inc |= usedTargets;
	#endif
}


//-----------------------------------------------------------------------------
void rx_indication(int idx, const union u_fifoEntry *inBuf)
{
	const struct s_canAction *action;
	const struct s_RxPduCfg *rxPduCfg;
	const uint8_t *frame;
	int rule;
	#if defined(MEASURE_LOOKUP) || defined(MEASURE_WRITE)
		int t1;
	#endif
	#ifdef MEASURE_CLASSIFY
		int t2;
	#endif

	// dbg_printf("rx_indication(%d, %06x)\n", idx, inBuf);
	// dbg_dump_ptr(inBuf, 0, 4);
	countersRx[idx][CNT_RX_TOTAL]++;
	countersRx[idx][CNT_RX_BYTES] += inBuf->meta.len;

	switch (inBuf->meta.prot) {
	//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	case PROTOCOL_bff :
		#ifdef MEASURE_CLASSIFY
			t2 = cpuCycle();
		#endif
		//Acceptance filter for 11-bit CAN-IDs in 2.0 or FD mode
		rxPduCfg = &raConfig->ingress[idx].table.rxPduCfg[Id11];

		#ifdef MEASURE_LOOKUP
			t1 = cpuCycle();
		#endif
		rule = lookup32(rxPduCfg->search, inBuf->data32[4]);  //inBuf->id + and FD,CC
		#ifdef MEASURE_LOOKUP
			t1 = cpuCycle() - t1;
			time_lookup[time_frame_cnt] = t1;
			//dbg_printf("%d cycles for lookup\n", t1);
		#endif
		#ifdef VERBOSE_CLASSIFY
			dbg_printf("rx_indication(%d, BFF): Id=%d/%x  rule=%d/%x  TargetVector=%04x\n", idx, inBuf->can.id, inBuf->can.id, rule, rule, rxPduCfg->action[rule].TargetVector);
		#endif

		//due to action table format we can access default rule at [-1]
		action = &rxPduCfg->action[rule];
		//dbg_printf("  rxPduCfg=%x  action=%x  action[rule]=%x\n", rxPduCfg, rxPduCfg->action, action);
		#ifdef MEASURE_CLASSIFY
			t2 = cpuCycle() - t2;
			time_classify[time_frame_cnt] = t2;
		#endif

		// DataLengthCheck
		//dbg_printf("   CanIfRxPduDataLength=%d modifyOnTarget=%x\n", rxPduCfg->action[rule].CanIfRxPduDataLength, rxPduCfg->action[rule].modifyOnTarget);
		if (inBuf->can.len < action->CanIfRxPduDataLength) {
			countersRx[idx][CNT_RX_DATALERR]++;
			#ifdef VERBOSE_CLASSIFY
				dbg_printf("   DataLengthCheck failed: Received Length=0x%04x CheckLength=0x%04x CNT_RX_DATALERR=%d\n",
					inBuf->can.len, action->CanIfRxPduDataLength,countersRx[idx][CNT_RX_DATALERR]);
			#endif
			return;
		}

		//Forward as per rule
		#ifdef MEASURE_WRITE
			t1 = cpuCycle();
		#endif
		can_Write(action, inBuf);
		#ifdef MEASURE_WRITE
			t1 = cpuCycle() - t1;
			time_write[time_frame_cnt] = t1;
			//dbg_printf("%d cycles for can_write()\n", t1);
		#endif
		break; //case

	//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// T1S Ethernet frame processing
	case (PROTOCOL_t1s):
		#ifdef MEASURE_CLASSIFY
			t2 = cpuCycle();
		#endif
		// Extract Ethernet frame data from the input buffer
		frame = inBuf->eth.data;

		// EthIfCtrlMtu Check
		// This is a controller configuration and realised by the check of fifoEntrySize when fill the input FIFO
		//countersRx[idx][CNT_RX_FRAME_TOO_LARGE]++;

		// Parse Ethernet header fields
		uint16_t etherType = *(uint16_t*)&frame[2+12]; // EtherType field
		int rx_vlan;                                  // VLAN ID (extracted later if present)
		int streamIdOffset;

		// Process VLAN tagged frames (IEEE 802.1Q) C-TAG = 0x8100
		if (etherType == bswap_16(0x8100)) {
			rx_vlan = ((frame[2+14] << 8) | frame[2+15]) & 0x0FFF;  // Extract VLAN ID (12 bits)
			etherType =  *(uint16_t*)&frame[2+16];           // Get actual EtherType after VLAN tag
			streamIdOffset = 2+18+4;                         // Adjust payload offset for VLAN tag
		}
		else {
			rx_vlan = 0;             //TODO: DefaultVlanId from JSON
			streamIdOffset = 2+18;     // Offset to payload (after standard Ethernet header)
		}

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// MAC/VLAN Acceptance Stage: Determine routing based on destination MAC and VLAN
		// Variant B: Combined MAC/VLAN search (similar to IVL in 802.1Q)
		struct s_ethRxPduCfg *rxMacVlanPduCfg = &raConfig->ingress[idx].table.rxEthPduCfg[VlanDa];
		struct s_ethAction *acceptance_stage_action;

		//uint64_t value = *(uint32_t*)&frame[0] | ((uint64_t)(*(uint16_t*)&frame[4]) << 32) | ((uint64_t)rx_vlan << 48);  //no gap in ETH
		uint64_t value = *(uint16_t*)&frame[2+0] | ((uint64_t)(*(uint32_t*)&frame[2+2]) << 16) | ((uint64_t)rx_vlan << 48);  //with gap
		#ifdef MEASURE_LOOKUP
			t1 = cpuCycle();
		#endif
		rule = lookup64(rxMacVlanPduCfg->search, value);
		#ifdef MEASURE_LOOKUP
			t1 = cpuCycle() - t1;
			time_lookup[time_frame_cnt] = t1;
			//dbg_printf("%d cycles for lookup Acceptance\n", t1);
		#endif
		#ifdef VERBOSE_CLASSIFY
			dbg_printf("\033[1;35mrx_indication(%d, ET) acceptance: MAC=%02x:%02x:%02x:%02x:%02x:%02x VID=%d/%x TS=%x_%08x  >  rule=%d/%x TargetVector=%04x\033[m\n", idx,
			frame[2+0], frame[2+1], frame[2+2], frame[2+3], frame[2+4], frame[2+5], rx_vlan, rx_vlan, inBuf->meta.ts_h&0xffffff, inBuf->meta.ts_l,
			rule, rule, rxMacVlanPduCfg->ethaction[rule].TargetVector);
		#endif

		// Apply MAC/VLAN lookup result
		acceptance_stage_action = &rxMacVlanPduCfg->ethaction[rule];

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// Stream identification
		const struct s_ethAction *id_stage_1722_ethaction = NULL;
		const struct s_ethAction *id_et_type_ethaction = NULL;
		// Frame Type Identification: Route based on EtherType or IEEE 1722 Stream ID
		if (acceptance_stage_action->search1722 && (etherType == bswap_16(0x22F0))) {
			const struct s_ethRxPduCfg *rxIeee1722PduCfg = &raConfig->ingress[idx].table.rxEthPduCfg[Ieee1722];

			// Extract 64-bit Stream ID from IEEE 1722 header
			uint64_t streamId = *(uint64_t*)&frame[streamIdOffset];
			#ifdef MEASURE_LOOKUP
				t1 = cpuCycle();
			#endif
			rule = lookup64(rxIeee1722PduCfg->search, streamId);
			#ifdef MEASURE_LOOKUP
				t1 = cpuCycle() - t1;
				time_lookup[time_frame_cnt] += t1;
				//dbg_printf("%d cycles for lookup 1722\n", t1);
			#endif
			#ifdef VERBOSE_CLASSIFY
				dbg_printf("\033[1;35m             (%d, ET) 1722stream: SID=%08x_%08x  rule=%d/%x  TargetVector=%04x\033[m\n", idx,
				bswap_32((uint32_t)streamId), bswap_32((uint32_t)(streamId>>32)),
				rule, rule, rxIeee1722PduCfg->ethaction[rule].TargetVector);
			#endif

			// Apply IEEE 1722 lookup result
			id_stage_1722_ethaction = &rxIeee1722PduCfg->ethaction[rule];
		}

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// ET identification
		if (acceptance_stage_action->searchET) {
			// Non-IEEE 1722 frames: lookup by EtherType
			const struct s_ethRxPduCfg *rxEthPduCfg = &raConfig->ingress[idx].table.rxEthPduCfg[EthType];
			#ifdef MEASURE_LOOKUP
				t1 = cpuCycle();
			#endif
			rule = lookup32(rxEthPduCfg->search, etherType);
			#ifdef MEASURE_LOOKUP
				t1 = cpuCycle() - t1;
				time_lookup[time_frame_cnt] += t1;
				//dbg_printf("%d cycles for lookup ET\n", t1);
			#endif
			#ifdef VERBOSE_CLASSIFY
				dbg_printf("\033[1;35m             (%d, ET) ethertype:  ET=%d/%x  rule=%d/%x  TargetVector=%04x\033[m\n", idx,
				bswap_16(etherType), bswap_16(etherType),
				rule, rule, rxEthPduCfg->ethaction[rule].TargetVector);
			#endif

			// Apply EtherType lookup result
			id_et_type_ethaction = &rxEthPduCfg->ethaction[rule];
		}

		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		// Final Routing Decision: Combine acceptance stage with frame type identification
		uint32_t combinedTargetVector = acceptance_stage_action->TargetVector;
		uint32_t finalFrameOwner = acceptance_stage_action->FrameOwner;
		if (id_stage_1722_ethaction != NULL) {
			// IEEE 1722 path was taken
			combinedTargetVector |= id_stage_1722_ethaction->TargetVector;
			if (id_stage_1722_ethaction->FrameOwner != 0) {
				finalFrameOwner = id_stage_1722_ethaction->FrameOwner;
			}
			#ifdef PRINT_STAGES_OUTPUT
			dbg_printf("\033[1;36m   C : Combined Output (Acceptance Stage + ID_STAGE_1722): FrameOwner=%d, TargetVector=0x%08x\033[0m\n",
				finalFrameOwner, combinedTargetVector);
			#endif
		} else if (id_et_type_ethaction != NULL) {
			// EtherType path was taken
			combinedTargetVector |= id_et_type_ethaction->TargetVector;
			if (id_et_type_ethaction->FrameOwner != 0) {
				finalFrameOwner = id_et_type_ethaction->FrameOwner;
			}
			#ifdef PRINT_STAGES_OUTPUT
			dbg_printf("\033[1;36m   C : Combined Output (Acceptance Stage + ID_STAGE_ET_TYPE): FrameOwner=%d, TargetVector=0x%08x\033[0m\n",
				finalFrameOwner, combinedTargetVector);
			#endif
		} else {
			#ifdef PRINT_STAGES_OUTPUT
			dbg_printf("\033[1;36m   C : Combined Output (Acceptance Stage output only): FrameOwner=%d, TargetVector=0x%08x\033[0m\n",
				finalFrameOwner, combinedTargetVector);
			#endif
		}
		//dbg_printf("\033[94mTarget rule=%08x\033[m\n", combinedTargetVector);
		#ifdef MEASURE_CLASSIFY
			t2 = cpuCycle() - t2;
			time_classify[time_frame_cnt] = t2;
		#endif

		// Forward the frame using the combined routing decision
		#ifdef MEASURE_WRITE
			t1 = cpuCycle();
		#endif
		eth_Write(combinedTargetVector, inBuf, finalFrameOwner);
		#ifdef MEASURE_WRITE
			t1 = cpuCycle() - t1;
			time_write[time_frame_cnt] = t1;
			//dbg_printf("%d cycles for eth_write()\n", t1);
		#endif
		break; // case PROTOCOL_t1s

	//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	default:
		//print_puts("CAN version not yet supported\n");
		countersRx[idx][CNT_RX_FAULTY]++;
		break;
	}
	// dbg_puts("----- End rx_indication -----\n");
}


//-----------------------------------------------------------------------------
void stageLoop()
{
	#ifdef VERBOSE_GENERAL
		dbg_puts("----- Start Forwarding loop -----\n");
	#endif
	int offline = 1;
	int to = 200000;  // very long first timeout in case stimulus starts later
	uint32_t next;
	#ifdef MEASURE_RX_INDICATION
		uint32_t t1;
	#endif

	while (offline) {
		//simple arbitration between ComIF (high) and vPort (low)
		next = 0;
		if (buf_in_valid == 0) {
			for (int i=0; i<INGRESS_STREAM_MAX; i++) {
				if (vPortPending[i]) {
					//dbg_printf("vPort[%d] has %d pending frames\n", i, vPortPending[i]);
					vPortPending[i]--;
					next = (1 << (i+10));   //10 comes from current specification
					break;
				}
			}
		}

		//wait that something is there by polling buffer manager SFR
		if (next == 0) {
			while ((next=buf_in_valid) == 0)
				if (!to--) {
					offline--;
					break;
				}
		}
		//dbg_printf("next ingress=%08x @%d µs\n", next, cpuCycle()/100);

		// something received
		for (uint32_t mask=1, idx=0; idx<INGRESS_MAX; mask <<= 1, idx++) {
			if (next&mask) {
				//Print frame and some sanity checks for sync with PY
				#ifdef VERBOSE_GENERAL
					// dbg_print_IngressFrame(idx, ingressFifoEntryNumber[idx]);
					if (!dbg_sanity_check_IngressFrame(idx)) {
						dbg_puts("Abort: RxIndication() input frame sanity check failure\n");
						return;
					}
				#endif

				#ifdef MEASURE_RX_INDICATION
					t1 = cpuCycle();
				#endif

				struct s_ingressConfig *ingress = &raConfig->ingress[idx];
				const union u_fifoEntry *inBuf = (union u_fifoEntry *)(ingress->fifoBaseAddr + ingress->fifoEntrySize * ingressFifoEntryNumber[idx]);

				rx_indication(idx, inBuf);

				//update SW side buffer pointer and release buffer in SFR
				ingressFifoEntryNumber[idx] = (ingressFifoEntryNumber[idx]+1) % ingress->fifoEntries;
				buf_in_dec = mask;

				#ifdef MEASURE_RX_INDICATION
					//Collect the measured time
					t1 = cpuCycle() - t1;
					time_rxindication_cnt++;
					time_rxindication_sum += t1;
					time_sourceIf[time_frame_cnt] = idx;
					time_rxindication[time_frame_cnt] = t1;
					time_rxindication_size[time_frame_cnt] = inBuf->meta.len;
					#ifdef VERBOSE_CLASSIFY
						dbg_printf("Full forward %03d: %d cycles (%d.%02d0 us) for %d bytes\n", time_frame_cnt, t1, t1/100, t1%100, inBuf->meta.len);
					#endif
					if (time_frame_cnt < MEASURE_FRAMES-1)
						time_frame_cnt++;
				#endif
			}
		}

		to = 20000;	//15000 is a good value for 1 ms gap at 100 MHz
	}
}


//-----------------------------------------------------------------------------
//Setup and forwarding loop
int main(void)
{
	#ifdef VERBOSE_GENERAL
		if (&__stack_top > &dram32[RA_CONFIG_ADDR/4]) {
			dbg_printf("Memory overlap stack=%x config=%x\n", &__stack_top, &dram32[RA_CONFIG_ADDR/4]);
			exit(-1);
		}
		dbg_checkPythonStarted();
	#endif

	raConfig = (struct s_raConfig*)&dram32[RA_CONFIG_ADDR/4];
	#ifdef VERBOSE_GENERAL
		dbg_printConfiguration(0x00);  //1=buffer, 2,4=tables, 10=streamGen, 20=streamTerm
		//return 0;
	#endif

	//Variables init
	memset(countersRx, 0, sizeof(countersRx));
	memset(countersTx, 0, sizeof(countersTx));
	memset(ingressFifoEntryNumber, 0, sizeof(ingressFifoEntryNumber));
	memset(egressFifoEntryNumber, 0, sizeof(egressFifoEntryNumber));
	memset(streamSize, 0, sizeof(streamSize));
	for (int i=0; i<raConfig->maxStreamGen; i++)
		streamGenSequence[i] = raConfig->streamGenCfg[i]->template[raConfig->streamGenCfg[i]->patchDataLengthWord] >> 24;
	memset(streamTermSequence, 255, sizeof(streamTermSequence));  //-1 means no check
	memset(vPortPending, 0, sizeof(vPortPending));


	//Make HW configuration and optional clean the buffers
	for (int i=0; i<raConfig->maxIngress; i++) {
		struct s_ingressConfig *ingress = &raConfig->ingress[i];
		buf_in_info[i] = ingress->fifoEntries;
	}
	for (int i=0; i<raConfig->maxEgress; i++) {
		struct s_egressConfig *egress = &raConfig->egress[i];
		buf_out_info[i] = egress->fifoEntries;
		#ifdef VERBOSE_GENERAL
			//optional
			//memset((void*)egress->fifoBaseAddr, 0x80+i, egress->fifoEntrySize * egress->fifoEntries);
		#endif
	}

	//Init the measurement structures. Only for conditional and aggregating fields
	#ifdef VERBOSE_GENERAL
		time_frame_cnt = 0;
		#ifdef MEASURE_RX_INDICATION
			time_rxindication_sum = 0;
			time_rxindication_cnt = 0;
			//memset(time_rxindication, 0, sizeof(time_rxindication));
		#endif
		#ifdef MEASURE_LOOKUP
			memset(time_lookup, 0, sizeof(time_lookup));
		#endif
		#ifdef MEASURE_WRITE
			memset(time_write, 0, sizeof(time_write));
			memset(time_write_targets, 0, sizeof(time_write_targets));
		#endif
		#ifdef MEASURE_COPY
			memset(time_copy, 0, sizeof(time_copy));
		#endif
		#ifdef MEASURE_FIFO_MNGR
			memset(time_fifo_mngr, 0, sizeof(time_fifo_mngr));
		#endif
		#ifdef MEASURE_STREAM_GEN
			memset(time_1722_gen, 0, sizeof(time_1722_gen));
		#endif
		#ifdef MEASURE_STREAM_TERM
			memset(time_1722_term, 0, sizeof(time_1722_term));
		#endif
	#endif

	stageLoop();
	//return 0;

	#ifdef VERBOSE_GENERAL
		//Print the collected counters
		dbg_puts("+----- Status summary of C-Code side ------------------------------\n");
		dbg_puts("| InputFIFO counters         Sum");
		for (int j=0; j<raConfig->maxIngress; j++)
			dbg_printf(" %4d", j);
		dbg_puts("\n+------------------------------------------------------------------\n");
		for (int j=0; j<LAST_COUNTER_RX; j++) {
			int sum = 0;
			for (int i=0; i<raConfig->maxIngress; i++)
				sum += countersRx[i][j];
			dbg_printf("| %-25s %4d", dbg_COUNTER_RX_STR[j], sum);
			for (int i=0; i<raConfig->maxIngress; i++)
				dbg_printf(" %4d", countersRx[i][j]);
			dbg_putnl();
		}

		dbg_puts("| Frames forwarded              ");
		for (int i=0; i<raConfig->maxIngress; i++)
			dbg_printf(" %4d", countersRx[i][CNT_RX_TOTAL]
					- countersRx[i][CNT_RX_FAULTY]
					- countersRx[i][CNT_RX_DATALERR]
					- countersRx[i][CNT_RX_FRAME_TOO_LARGE]
			);

		dbg_puts("\n+------------------------------------------------------------------\n");
		dbg_puts("| OutputFIFO counters        Sum");
		for (int i=0; i<raConfig->maxEgress; i++)
				dbg_printf(" %4d", i);
		dbg_puts("\n+------------------------------------------------------------------\n");
		for (int j=0; j<LAST_COUNTER_TX; j++) {
			int sum = 0;
			for (int i=0; i<raConfig->maxEgress; i++)
				sum += countersTx[i][j];
			dbg_printf("| %-25s %4d", dbg_COUNTER_TX_STR[j], sum);
			for (int i=0; i<raConfig->maxEgress; i++)
				dbg_printf(" %4d", countersTx[i][j]);
			dbg_putnl();
		}
		dbg_puts("+------------------------------------------------------------------\n");


		//Check if buffer management is in sync and print faults
		for (int i=0;i<32;i++) {
			if (buf_in_info[i]>>16)
				dbg_printf("\033[31mInBuffer[%d] pending %d\033[m\n", i, buf_in_info[i]>>16);
		}
		for (int i=0;i<32;i++) {
			if (buf_out_info[i]>>16)
				dbg_printf("\033[31mOutBuffer[%d] pending %d\033[m\n", i, buf_out_info[i]>>16);
		}


		//Print the Measurements results
		#ifdef USE_COPY_HW
			dbg_puts("MM + USE_COPY_HW\n");
		#endif
		#ifdef USE_FIFO_MNGR_HW
			dbg_puts("MM + USE_FIFO_MNGR_HW\n");
		#endif
		#ifdef USE_LOOKUP_HW
			dbg_puts("MM + USE_LOOKUP_HW\n");
		#endif
		#ifdef MEASURE_RX_INDICATION
			dbg_printf("MM Time RxIndication %d  (average over %d frames)\n", time_rxindication_sum/time_rxindication_cnt, time_rxindication_cnt);
		#endif
		dbg_puts("MM Time of individual frames (right side measurement code is included in left sides)\n");
		dbg_puts("MM  Frame"
		#ifdef MEASURE_RX_INDICATION
			" Size"
			" In"
			"  RxIn"
		#endif
		#ifdef MEASURE_CLASSIFY
			" Class"
		#endif
		#ifdef MEASURE_LOOKUP
			"  Look"
		#endif
		#ifdef MEASURE_WRITE
			" | Write"
			" Cnt"
		#endif
		#ifdef MEASURE_FIFO_MNGR
			" FMngr"
		#endif
		#ifdef MEASURE_COPY
			" Copy"
		#endif
		#ifdef MEASURE_STREAM_GEN
			" ACFgen"
		#endif
		#ifdef MEASURE_STREAM_TERM
			" ACFterm"
		#endif
			"\nMM  -------------------------------------------------------------------------\n");
		for (unsigned int i=0; i<time_frame_cnt;i++) {
			dbg_printf("MM   %4d", i);
			#ifdef MEASURE_RX_INDICATION
				dbg_printf(" %4d %2d %5d", time_rxindication_size[i], time_sourceIf[i], time_rxindication[i]);
			#endif
			#ifdef MEASURE_CLASSIFY
				dbg_printf(" %5d", time_classify[i]);
			#endif
			#ifdef MEASURE_LOOKUP
				dbg_printf(" %5d", time_lookup[i]);
			#endif
			#ifdef MEASURE_WRITE
				dbg_printf(" | %5d %3d", time_write[i], time_write_targets[i]);
			#endif
			#ifdef MEASURE_FIFO_MNGR
				dbg_printf(" %4d", time_fifo_mngr[i]);
			#endif
			#ifdef MEASURE_COPY
				dbg_printf(" %5d", time_copy[i]);
			#endif
			#ifdef MEASURE_STREAM_GEN
				dbg_printf(" %6d", time_1722_gen[i]);
			#endif
			#ifdef MEASURE_STREAM_TERM
				dbg_printf(" %6d", time_1722_term[i]);
			#endif
			dbg_putnl();
		}
	#endif
	return 0;
}
