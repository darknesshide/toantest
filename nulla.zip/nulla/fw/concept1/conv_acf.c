#include <stdint.h>

#include "ra_adrmap.h"
#include "racfg.h"         //Configuration of RA system


//#define VERBOSE_ETH_CAN


//Some local stuff
#define NTSCF_SUBTYPE    0x82U
#define ACF_CAN_BRIEF    0x02
//#define ACF_CAN_XL_BRIEF 0x12

#define NTSCF_HEADER_SIZE8   12


struct s_acf_can_brief {
	unsigned can_bus_id       :  5;
	unsigned rsv1             :  3;
	unsigned esi              :  1;
	unsigned fdf              :  1;
	unsigned brs              :  1;
	unsigned eff              :  1;
	unsigned rtr              :  1;
	unsigned mtv              :  1;
	unsigned pad              :  2;
	unsigned acf_msg_length   :  9; // number of words (acf_msg_payload (incl. pad bytes) + 2 header
	unsigned acf_msg_type     :  7; // 0x02 for ACF_CAN_BRIEF

	unsigned can_identifier   : 29;
	unsigned rsv2             :  3;
	// data
	uint8_t  can_msg_payload[64];   //this struct is used for casting only, the real size is controlled outside
};


//ACF generation using the structures (init happen in main)
uint16_t streamSize[EGRESS_STREAM_MAX];
uint8_t  streamGenSequence[EGRESS_STREAM_MAX];

//NTSCF stream termination
int16_t streamTermSequence[INGRESS_STREAM_MAX];
uint8_t vPortPending[INGRESS_STREAM_MAX];


//=============================================================================
//===== Bring CAN into 1722-ACF tunnel (L2 Raw format)
//=============================================================================

int can_eth(const union u_fifoEntry *inBuf, union u_fifoEntry *tgBuf, const int stream, const struct s_1722streamGen *streamGenCfg, const int flushOnTarget)
{
	struct s_acfBuf *acf;
	int size = streamSize[stream];
	// dbg_printf("   stream=%d  inBuf=%x  tgBuf=%x  streamGenCfg=%x  streamSize=%d  flushOnTarget=%d\n", stream, inBuf, tgBuf, streamGenCfg, streamSize[stream], flushOnTarget);
	// dbg_dump_ptr(inBuf, 0, 8);

	//a new stream frame starts
	if (streamSize[stream] == 0) {
		//dbg_dump_ptr(streamGenCfg->template, 0, (streamGenCfg->templateLength+12)/16);
		size = streamGenCfg->templateLength - 16;
		//dbg_printf("memcpy(%p, %p, %d)  template\n", tgBuf->data32, streamGenCfg->template, streamGenCfg->templateLength);
		#if 0
			memcpy(tgBuf->data32, streamGenCfg->template, streamGenCfg->templateLength);
		#else
			uint32_t *t = tgBuf->data32;
			const uint32_t *s = streamGenCfg->template;
			for (int i=streamGenCfg->templateLength; i>0; i-=4, t++, s++)
				*t = *s;
		#endif
	}
	acf = (struct s_acfBuf*) &tgBuf->data32[4+size/4];


	uint32_t pad                = (4-(inBuf->can.len&3)) & 3;
	uint32_t acf_msg_length32   = (inBuf->can.len + 3) / 4 + 2; // word number (incl. word containing acf_msg_length32) up to last msg_payload
	uint32_t bus_id             = inBuf->can.ipn;
	dbg_printf("[ACF] msg_length32=%d/%x  pad=%d  ipn=%d\n",acf_msg_length32, acf_msg_length32, pad, inBuf->can.ipn);

	uint32_t acf_rtr            = inBuf->can.rtr;
	uint32_t acf_eff            = inBuf->can.prot & 0x1;
	uint32_t acf_brs            = inBuf->can.brs;
	uint32_t acf_fdf            = inBuf->can.fd;
	uint32_t acf_esi            = inBuf->can.esi;

	//to prevent read/modify/write on outbuf, the ACF header is assembled by shift instead of bit field structure
	#ifdef SW_ENDIAN
		acf->lit[0] = (/*res*/0 << 29) + (bus_id << 24)
		            + (pad << 22) + (/*mtv*/0 << 21) + (acf_rtr << 20) + (acf_eff << 19) + (acf_brs << 18) + (acf_fdf << 17) + (acf_esi << 16)
		            + ((acf_msg_length32 & 0x0FF) << 8)
		            + ((acf_msg_length32 & 0x100) >> 8) + (ACF_CAN_BRIEF << 1);
		//dbg_printf("[0]=%x\n", acf->lit[0]);
		acf->lit[1] = bswap_32(inBuf->can.id);
		//dbg_printf("[1]=%x\n", acf->lit[1]);
	#else
		acf->big[0]  = (ACF_CAN_BRIEF << 25)
		            + ((acf_msg_length32 & 0x1FF) << 16)
		            + (pad << 14) + (/*mtv*/0 << 13) + (acf_rtr << 12) + (acf_eff << 11)
		            + (acf_brs << 10) + (acf_fdf << 9) + (acf_esi << 8)
		            + (/*res*/0 << 5) + (bus_id << 0);
		acf->big[1] = inBuf->can.id;
	#endif

	//Append the data
	size += acf_msg_length32*4;
	bufferCpy(&acf->lit[2], &inBuf->data32[7], (acf_msg_length32*4)-8);

	//Handle size bunching or immediate transmit
	if (size > streamGenCfg->maxFrameSize || flushOnTarget) {
		//Patch the streamSize into headerTemplate on Tx
		tgBuf->data32[0] = (streamGenCfg->template[0]) + size;   //The size field in template is 0

		//Patch the streamSize into NTSCF
		int pos = raConfig->streamGenCfg[stream]->patchDataLengthWord;
		int ntscf_data_length = size - pos*4 + 16 - 12;
		//dbg_printf("[NTSCF]=%x size=%d  ntfslength=%d/%x\n", streamGenCfg->template[pos], size, ntscf_data_length, ntscf_data_length);
		tgBuf->data32[pos] = (streamGenCfg->template[pos]&0xf8ff) + ((ntscf_data_length&0xff)<<16) + ((ntscf_data_length&0x700)<<(8-8)) + (streamGenSequence[stream]<<24);
		//dbg_printf("[%d]=%x\n", pos, tgBuf->data32[pos]);

		streamGenSequence[stream]++;
		streamSize[stream] = 0;
		return size;  //size and trigger send
	}
	else {
		streamSize[stream] = size;
		return 0; //no send required
	}
}


//=============================================================================
//===== Extracts all CAN frames from 1722-ACF tunnel (L2 Raw format)
//=============================================================================
int eth_can(const union u_fifoEntry *inBuf, const struct s_ingressConfig *vPortIn, const int stream, const int vPortIndex, uint8_t *egressFifoEntryNumber)
{
	const struct s_acfBuf *acf;
	int ntscf_len8, frame_len8_exp, truncated;
	int seq_num;

	//dbg_printf("eth_can(%06x, stream=%d, vPortIndex=%d)  inBuf.len8=%d\n", inBuf, stream, vPortIndex, inBuf->eth.len);
	//dbg_dump_ptr(inBuf->data32, 0, 1+(inBuf->meta.len+15)/16);

	//Locate the container offset (after EtherType)
	if (*(uint16_t*)&inBuf->eth.data[2+12] == bswap_16(0x8100)) {
		acf = (const struct s_acfBuf*)&inBuf->eth.data[2+14+4];
		frame_len8_exp = inBuf->meta.len - (12+2+4) - NTSCF_HEADER_SIZE8;
	}
	else {
		acf = (const struct s_acfBuf*)&inBuf->eth.data[2+14];
		frame_len8_exp = inBuf->meta.len - (12+2) - NTSCF_HEADER_SIZE8;
	}
	//dbg_puts("1722 container:\n"); dbg_dump_ptr(acf, 1, (FIFO_ETH_HEADER_SIZE8+inBuf->meta.len+15)/16);


	//Check the 1722 stream header
	//BIG: [31:24]=subtype=0x82=NTSCF, [23]=sv=?, [22:20]=version=0, [19]=r=0, [18:8]=ntscf_data_length=?, [7:0]=sequence_num=?
	//dbg_printf("%x\n", acf->big[0]);
	if ((acf->big[0]&0xff780000) != (NTSCF_SUBTYPE<<24)) {
		#ifdef VERBOSE_ETH_CAN
			dbg_printf("   Stream#%d: \033[31mERROR\033[m: NTSCF header issue %08x\n", stream, acf->big[0]);
		#endif
		//TODO: Counter
		return 1;
	}

	ntscf_len8 = (acf->big[0]>>8) & 0x7ff;
	//dbg_printf("   inBuf.len8=%d frame_len8_exp=%d  ntscf_len8=%d  ethHeader=%d\n", inBuf->eth.len, frame_len8_exp, ntscf_len8, FIFO_ETH_HEADER_SIZE8);
	if (ntscf_len8 > frame_len8_exp) {
		#ifdef VERBOSE_ETH_CAN
			dbg_printf("   Stream#%d: \033[31mERROR\033[m: NTSCF package len frame_len8_exp=%d < ntscf_len8=%d\n", frame_len8_exp, ntscf_len8);
		#endif
		//TODO: Counter
		return 1;
	}

	seq_num = acf->big[0] & 0xff;
	if (streamTermSequence[stream] >= 0 && streamTermSequence[stream]+1 != seq_num) {
		#ifdef VERBOSE_ETH_CAN
			dbg_printf("   Stream#%d: \033[31mERROR\033[m: NTSCF package sequence error seq_num=%d  expected %d\n", stream, seq_num, streamTermSequence[stream]+1);
		#endif
		//TODO: Counter
		return 1;
	}
	streamTermSequence[stream] = seq_num;

	//Decode ACF and fill the CAN input buffer of vPort
	int ret = 0;
	while (ntscf_len8) {
		struct s_acf_can_brief *acf_can = (struct s_acf_can_brief *) &acf->big[3];
		int32_t acf_len8 = acf_can->acf_msg_length*4;
		//dbg_printf("%06x %06x %03x  len=%d  remain=%d\n", inBuf, acf, (unsigned)acf - (unsigned)inBuf, acf_can->acf_msg_length, ntscf_len8);
		if (ntscf_len8 < acf_len8) {
			#ifdef VERBOSE_ETH_CAN
				dbg_printf("   Stream#%d: \033[31mERROR\033[m: ACF exceeds NTSCF at %04x  (ntscf remain=%d  acf=%d)\n", stream, (unsigned)acf - (unsigned)inBuf, ntscf_len8, acf_len8);
			#endif
			ret = 1;
			break;
		}

		if (acf_can->acf_msg_type != ACF_CAN_BRIEF) {
			#ifdef VERBOSE_ETH_CAN
				dbg_printf("   Stream#%d: \033[31mERROR\033[m: Unsupported ACF message type %02x at %04x\n", stream, acf_can->acf_msg_type, (unsigned)acf - (unsigned)inBuf);
			#endif
			ret = 1;
		}
		else if (vPortPending[stream] >= vPortIn->fifoEntries) {
			#ifdef VERBOSE_ETH_CAN
				dbg_printf("   Stream#%d: \033[31mERROR\033[m: vPort[%d] full with %d message. ACF extract dropped\n", stream, stream, vPortIn->fifoEntries);
			#endif
			countersTx[vPortIndex][CNT_TX_BUSY]++;
			//this is no decoding issue, no need to forward the 1722 frame to CPU for exception handling
		}
		else {
			// uint32_t acf_t  = eth_inbuf_big->acf.acf_msg_type;
			uint32_t can_len8 = acf_len8 - 8 - acf_can->pad;
			uint32_t fdf      = acf_can->fdf;
			uint32_t eff      = acf_can->eff;
			uint32_t rtr      = acf_can->rtr;
			uint32_t brs      = acf_can->brs;
			uint32_t esi      = acf_can->esi;
			uint32_t canid    = acf_can->can_identifier;

			uint32_t prot      = (rtr) ? PROTOCOL_ccr : eff * PROTOCOL_eff;

			//Check vPort size
			if (can_len8+FIFO_CAN_HEADER_SIZE8 > vPortIn->fifoEntrySize){
				can_len8 = vPortIn->fifoEntrySize - FIFO_CAN_HEADER_SIZE8;
				truncated = 1;
				countersTx[vPortIndex][CNT_TX_TRUNC]++;
			}
			else
				truncated = 0;
			//dbg_printf("   Stream#%d: Decoding: ntscf_len8=%d  sequence_num=%x/%d -> CAN id=%d  len=%d  fd=%d  truncated=%d\n", stream, ntscf_len8, seq_num, seq_num, canid, can_len8, fdf, truncated);

			union u_fifoEntry *tgBuf = (union u_fifoEntry*)(vPortIn->fifoBaseAddr + vPortIn->fifoEntrySize * (*egressFifoEntryNumber));

			//assemble meta data
			tgBuf->data32[0] = ((PN_VPORT_OFFSET+stream)<<24) + (prot << 16) + (truncated<<15) + can_len8;  //TODO: What is the source port (eth or vPort)
			//tgBuf->data32[1] = 0 /*pduid*/;  //don't care filled in CAN forwarding
			tgBuf->data32[2] = inBuf->data32[2];  //TS is TS of ETH frame
			tgBuf->data32[3] = inBuf->data32[3];

			//assemble CAN header
			tgBuf->data32[4] = (fdf << 31) + (!fdf << 30) + canid;
			tgBuf->data32[5] = (rtr << 19) + (brs << 18) + (esi << 17) /* + (sec << 16) + (vcid << 8) + sdt*/;
			//tgBuf->data32[6] = 0 /*af*/;   //don't care in case of CC/FD

			//Add the data (current HW copy cannot be used because vPorts data in in DRAM and not in BRAMin
			#if 0
				memcpy(&tgBuf->data32[7], &acf->lit[3+2], can_len8);
			#else
				for (unsigned i = 0; i < (can_len8+3)/4; i++)
					tgBuf->data32[7+i] = acf->lit[3+2+i];
			#endif
			//dbg_dump_ptr(tgBuf->data32, 0, 4);
			#ifdef VERBOSE_ETH_CAN
				dbg_printf("   Stream#%d: Placed 28+%d bytes on vPort%d at index=%d (%06x)  pending=%d\n", stream, can_len8, vPortIndex, *egressFifoEntryNumber, tgBuf, vPortPending[stream]);
			#endif

			//And release the CAN frame inside the vPort input (egress of this stage)
			*egressFifoEntryNumber = (*egressFifoEntryNumber + 1) % vPortIn->fifoEntries;

			//Mark the frame as available in vPort to be found by rx_indication
			//dbg_printf("vPort[%d] increase pending to %d\n", stream, vPortPending[stream]+1);
			vPortPending[stream]++;

			// //Trigger CAN path processing
			// #ifdef USE_COPY_HW
			// 	dbg_puts("\033[31mError: ETH->CAN is not supported if HW-COPY is enabled.\n");
			// #else
			// 	rx_indication(vPortIndex, tgBuf);
			// #endif
		}

		//dbg_printf("ntscf_len8=%d  acf_len8=%d\n", ntscf_len8, acf_can->acf_msg_length*4);
		ntscf_len8 -= acf_can->acf_msg_length*4;
		acf = (const struct s_acfBuf*)&acf->lit[acf_can->acf_msg_length];
	}
	return ret;
}
