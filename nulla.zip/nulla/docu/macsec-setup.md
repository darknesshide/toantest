# Overview of MACsec operation

~~~shell
#Create a virtual network interface
sudo ip link add veth0 type dummy
sudo ifconfig veth0 hw ether 10:22:33:44:55:66

ip link show veth0
sudo ifconfig veth0 up

#setup a MACsec instance on the interface
sudo ip link add link veth0 vsec0 type macsec port 1 encrypt on cipher gcm-aes-256

sudo ip macsec add vsec0 rx port 1 address 10:AA:AA:AA:00:01
sudo ip macsec add vsec0 rx port 1 address 10:AA:AA:AA:00:01 sa 0 pn 2048 on key 01 8181818181818181818181818181818181818181818181818181818181818181
sudo ip macsec add vsec0 tx                                  sa 0 pn 1024 on key 01 8282828282828282828282828282828282828282828282828282828282828282

ip link show vsec0
sudo ip link set vsec0 up
~~~

And in two other terminals open a tcpdump

~~~shell
#start dump (in another terminal)
sudo tcpdump -i veth0 -nvxx
sudo tcpdump -i vsec0 -nvxx
~~~


## Some useful links

* https://docs.commscope.com/bundle/fastiron-08095-securityguide/page/GUID-333630FE-363D-43F1-A4C9-0EDD0D0D53E2.html
* https://pycryptodome.readthedocs.io/en/latest/src/cipher/modern.html#gcm-mode


## A MACsec example based on above configuration

~~~
IP6 (hlim 255, next-header ICMPv6 (58) payload length: 16)
	0x0000:  3333 0000 0002 1022 3344 5566 86dd 6000
	0x0010:  0000 0010 3aff fe80 0000 0000 0000 1222
	0x0020:  33ff fe44 5566 ff02 0000 0000 0000 0000
	0x0030:  0000 0000 0002 8500 4995 0000 0000 0101
	0x0040:  1022 3344 5566

802.1AE MACsec, an 0, pn 1024, flags ECI, sci 1022334455660001,
	0x0000:  3333 0000 0002 1022 3344 5566 88e5 2c00
	0x0010:  0000 0400 1022 3344 5566 0001 e34a d645
	0x0020:  a526 5b7e c4ed 3a51 a85a 6e35 6245 2266
	0x0030:  69c6 51b3 e30e 512d 05c5 0552 79b2 0a4f
	0x0040:  b72a 8579 ee8b 8878 9237 08cc 9236 c442
	0x0050:  8e75 2c4b e654 0878 2b6b 77a5 f520 bccc
	0x0060:  713b 3847 5eb3

MAC L2
  333300000002 102233445566
Security Tag
  88e5 2c 00 00000400 1022334455660001
  ^    ^  ^  ^        ^
  ET   |  SL |        SCI
       TCI   PN
Secure Data
  e34ad645
  a5265b7e c4ed3a51 a85a6e35 62452266
  69c651b3 e30e512d 05c50552 79b20a4f
  b72a8579 ee8b8878 923708cc 9236c442
  8e752c4b e654
ICV
  08782b6b 77a5f520 bccc713b 38475eb3
~~~


This result in this AES operations
~~~
KEY (256 bit, 32 bytes, 8 long)
  8282828282828282828282828282828282828282828282828282828282828282
IV (96 bit, 12 bytes, 3 long)
  102233445566000100000400

Ingress Stream (86 bytes)
 Auth (28 bytes, 7 words, 1.75 pages)
33330000000210223344556688e52c00000004001022334455660001
 Encrypt (58 bytes, 14.5 (15) words, 3.625 (4) pages)
  86dd6000000000103afffe80000000000000122233fffe445566ff02000000000000000000000000000285004995000000000101102233445566

Expected ICV
  08782b6b77a5f520bccc713b38475eb3
~~~

And can be processed by AES core using this testbench command

~~~script
python3 gcm_testbench.py -m 256 -p 0 -s XS -g -z -k 8282828282828282828282828282828282828282828282828282828282828282 -i 102233445566000100000400  -a 33330000000210223344556688e52c00000004001022334455660001 -d 86dd6000000000103afffe80000000000000122233fffe445566ff02000000000000000000000000000285004995000000000101102233445566
~~~


Analysis of the output
~~~

AAD FFFF 33330000000210223344556688E52C00
AAD FFF0 000004001022334455660001 00 00 00 00

0x0000:  3333 0000 0002 1022 3344 5566 88e5 2c00
0x0010:  0000 0400 1022 3344 5566 0001


CT FFFF E34AD645A5265B7EC4ED3A51A85A6E35
CT FFFF 6245226669C651B3E30E512D05C50552
CT FFFF 79B20A4FB72A8579EE8B8878923708CC
CT FFC0 9236C4428E752C4BE654 1A 41 7A 0E E7 EA

0x0010:                                e34a d645
0x0020:  a526 5b7e c4ed 3a51 a85a 6e35 6245 2266
0x0030:  69c6 51b3 e30e 512d 05c5 0552 79b2 0a4f
0x0040:  b72a 8579 ee8b 8878 9237 08cc 9236 c442
0x0050:  8e75 2c4b e654

DUT	TAG 08782B6B77A5F520BCCC713B38475EB3

0x0050:                 0878 2b6b 77a5 f520 bccc
0x0060:  713b 3847 5eb3
~~~


And the decoding

~~~script
python3 gcm_testbench.py -m 256 -p 0 -s XS -g -z -k 8282828282828282828282828282828282828282828282828282828282828282 -i 102233445566000100000400  -a 33330000000210223344556688e52c00000004001022334455660001 -d E34AD645A5265B7EC4ED3A51A85A6E356245226669C651B3E30E512D05C5055279B20A4FB72A8579EE8B8878923708CC9236C4428E752C4BE654
~~~


## In Python

~~~python
try:
  from Crypto.Cipher import AES
except:
  from Cryptodome.Cipher import AES

key = bytes.fromhex('8282828282828282828282828282828282828282828282828282828282828282')
iv = bytes.fromhex('1022334455660001' '00000400')
header = bytes.fromhex(
  '333300000002' '102233445566' '88e5' '2c00'
  '00000400' '1022334455660001')
data = bytes.fromhex('86dd6000000000103afffe80000000000000122233fffe445566ff02000000000000000000000000000285004995000000000101102233445566')

#Encrypt
cipher = AES.new(key, AES.MODE_GCM, iv)
print(cipher)
cipher.update(header)
ciphertext, tag = cipher.encrypt_and_digest(data)
print(ciphertext.hex())
print(tag.hex())

#Decrypt
cipher = AES.new(key, AES.MODE_GCM, iv)
cipher.update(header)
plaintext = cipher.decrypt_and_verify(ciphertext, tag)
print(plaintext.hex())
~~~


### Missing python library

If Crypto is not available you can either install by `pip` or your package manager (e.g. `apt`).
In newer python version *Crypto* is replaced by *Cryptodome*.

~~~bash
#by package manager
sudo apt install python3-pycryptodome
#alternative by pip
pip install pycryptodome
~~~


## Offloader

### KeyRAM

| FMT(32) | SCI (64) | PN (64) |

 * FMT[7:0]
   * 0 Invalid
   * 1 128 bit
   * 2 256 bit key


### Flow
 1. DPU copies TCI, PN and SCI into MACsec data window
    * MACsec search for key and SC (about 20 clocks)
 2. DPU copies first 16 byte header (auth-only) into MACsec (data window)
 3. DPU waits for search done
    * AES starts its first 3 rounds with key and IV
 4. DPU performs sanity check
    * PN, ??
 5. DPU cancels the frame or continue
    * Copy remaining 96 header bits to data window
 6. Poll data window free and write
    * Option is to do this by DMAC copy


## Speedup
 * 2nd window for TCI, PN, SCI (96 flops) this allows to process the header in one step
