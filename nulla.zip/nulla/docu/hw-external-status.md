# Get the external Ingress-Data-Available (IDA) status

TUBE gets the ingress status from the external Communication Interfaces
(ComIf) like CAN or Ethernet.
This block converts the information provided by external world to
the information needed to schedule TUBE's ingress stage processing.

## IDA SFR

These registers provide the data available information of **N** external
sources to TUBE's firmware. Because different ComIF modules uses
different external signalising strategies **N** is split into 3 sub-ranges as:

- **N1** is 16. It defines number of ComIF category 1 inputs (RSCANFD).
- **N2** is 10. It defines the number of ComIF category 2 inputs (ETNF/RSW).
- **N3** is 8. It defines the number of ComIF category 3 inputs (XS_CAN).

Depending on interfaces availabe on MCU, some inputs may be not
connected during integration and never flag data for processing.

| Name            | Offset    | Bits  | Mode| Description |
|---------------- |---------- |-----  |---- |------------ |
| **IDA_IDX**     | 000       |  31:0 | RO  | Index of next external input FIFO for processing.<br>0~N-1: Number of external source<br>-1:Nothing to process |
| **IDA_DA.CH**   | 008       |  31:0 | RO  | Input Data Available from channel **CH** (0 to **N1**-1)<br>Monitoring of the external status of category 1 inputs.<br>*Register is for architecture evaluation but recommended for final module.* |
| **IDA_NDA.CH**  | 010       |  31:0 | RW  | New Input Data Available from channel **CH** (0 to **N2**-1)<br>Provide the new data status flagged by external category 2 inputs.<br>The **CH** bit is set by the new data event of ComIF.<br>This bit **CH** is cleared by writing 1 if there was no new data since start of TUBE internal processing (**IDA_PROC.CH** is 1). |
| **IDA_PROC.CH** | 014       |  31:0 | RW  | Input Data Processing from channel **CH** (0 to **N2**-1)<br>Indicate the channels with ongoing TUBE internal processing.<br>The **CH** bit is set when writing 1, writing 0 has no effect.<br>This bit **CH** is cleared by the new data event of ComIF. |
| **IDA_EN0.CH**  | ???       |  31:0 | RO  | Input Data Processing enabled of channel **CH** (0 to **N1**-1)<br>These bits are a mirror of the system side enable configuration for ComIF category 1 (RSCANFD). If a channel is disable (set to 0), the status is not shown **IDA_DA.CH**. |
| **IDA_EN1.CH**  | ???       |  31:0 | RO  | Input Data Processing enabled of channel **CH** (0 to **N2**-1)<br>These bits are a mirror of the system side enable configuration for ComIF category 2 (ETH). If a channel is disable (set to 0), the status is not shown **IDA_DA.CH**. |


The show value in **IDA_IDX** depend only on the flagging by external Communication Interfaces.
To prevent retrigger, the external acknowledge needs to be done in ComIF before
checking **IDA_IDX** the next time.
In a real system the transport delay (latency of IP, CDC, ...) has to be considered.
In TUBE firmware using loops for iteration this is typically uncritical, if multiple PEs
are used the race condition can occur.


## Example code

### Detect next channel for processing

```c
#include "ra_adrmap.h"
...
{
   int input_channel;
   ...
   //poll until a channel is available
   while ((input_channel=ida_idx) == -1);
   //Process the found channel
   ...
}
...
```

### Processing of category 2 (Ethernet) channels

```c
...
//mark the channel as 'under processing'
IDA_PROC = (1 << input_channel);

//Check if there are data available (e.g. by status of Rx descriptor chain)
if (data_pending(input_channel) {
   //process the data provided by ComIF module
   ...

   //no acknowledge because there may other frames pending in chain
}
//Acknowledge that processing this chain has be completed
//The clear of NDA is prevented by HW in case there are new data added after write of IDA_PROC
else
   IDA_NDA = (1 << input_channel);

...
```


## Architecture of external ComIF status interaction

![Interaction ComIf and TUBE](docu/comif.svg "Interaction ComIf and TUBE")
