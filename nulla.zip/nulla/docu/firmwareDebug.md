# Debug the software running on the embedded CPU cores

There is OpenOCD based debug support for the embedded CPUs.

Note: In debug mode the CPU execution is influenced by the JTAG interaction, even in run mode.
Program execution is slow down.

## Firmware load by debugger

The make goal `gdb` is used to compile the to start the simulator without pre-loading
the binary. It is up to the debugger to load the application.

The compilation is done with `DEBUG=1` (-Og instead of -O2) to exclude
compiler optimisations irritating during debugging. Use a `make clean`
to force re-compilation even for unchanged files.

In simulator terminal
```
~/nulla/apps/hello> make gdb
Start gdb with: riscv32-unknown-elf-gdb -ex 'target extended-remote localhost:3333' -ex 'set confirm off' -ex 'file /home/cmard/nulla/apps/hello/tmp/hello.elf' -ex load -ex compare-sections -ex 'break main' -ex cont
Execute simulation...
Simulation of "Vtb" starts at 0
Started openOCD on pid=49964
Waiting for connection on port 9824
JTAG Connected
Release CPU reset...
```

For debugger function test, in another terminal the `gdb` debugger is started. If this
works, all other graphical debuggers like Eclipse or VisualStudio Code can be used, too.

```
~/nulla/apps/hello> riscv32-unknown-elf-gdb -ex 'target extended-remote localhost:3333' -ex 'set confirm off' -ex 'file ./tmp/hello.elf' -ex load -ex compare-sections -ex 'break main' -ex cont
riscv32-unknown-elf-gdb: Symbol `PySlice_Type' has different size in shared object, consider re-linking
riscv32-unknown-elf-gdb: Symbol `PyFloat_Type' has different size in shared object, consider re-linking
riscv32-unknown-elf-gdb: Symbol `PyBool_Type' has different size in shared object, consider re-linking
GNU gdb (GDB) 15.1
Copyright (C) 2024 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
Type "show copying" and "show warranty" for details.
This GDB was configured as "--host=x86_64-pc-linux-gnu --target=riscv32-unknown-elf".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<https://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
    <http://www.gnu.org/software/gdb/documentation/>.

For help, type "help".
Type "apropos word" to search for commands related to "word".
Remote debugging using localhost:3333
warning: No executable has been specified and target does not support
determining executable automatically.  Try using the "file" command.
0x00000040 in ?? ()
Reading symbols from ./tmp/hello.elf...
Loading section .text, size 0x42a lma 0x0
Loading section .rodata, size 0x4d lma 0x500
Start address 0x00000040, load size 1143
Transfer rate: 5 KB/sec, 571 bytes/write.
Section .text, range 0x0 -- 0x42a: matched.
Section .rodata, range 0x500 -- 0x54d: matched.
Breakpoint 1 at 0x352: file ../ra_adrmap.h, line 199.
Continuing.

Breakpoint 1, main () at hello.c:11
11              dbg_puts("Hello World.\n");
(gdb)
```

## Activate debug in Makefile

Similar to the `make run` the application specific Makefile needs to define the `gdb` goal.

For pure C code this is
```makefile
gdb: gdbC
```

For mixed C + Python code this is
```makefile
gdb: gdbCP
```

*Attention:* The debugger delays the C-Code execution, but not the scheduling
of the Python code. An explicit synchronisation is between both sides is required.
