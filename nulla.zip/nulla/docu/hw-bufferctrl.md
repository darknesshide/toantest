# Buffer Controller

This block handles input and output requests from CPU and
Adaptor side.
Additionally, it provide CPU offload function for buffer accessing.

Main functions are
- Generation of Tx-Buffer Free indication
  - Offloader to split routing targets into *store* and *busy* targets
  - Offloader to convert store and busy number into numbers.
- Generation of Rx-Buffer valid indication
  - Offloader to provide the next valid buffer number in
    round robin scheme
  - Possibility to mark a valid buffer as *under processing* to exclude
    from rescheduling (allowed pipelined software)
- Handling of FIFO pointers is up to CPU and Adaptor side<br>
  This may later be offloaded, too. First the FIFO layout to be fixed.
  - Currently the buffer controller counts number of messages.


## SFR definition

| Name           | Offset    | Bits| Mode| Description |
|----------------|---------- |-----|---- |------------ |
| **BI_VALID**   | 000       | 31:0| RO  | Buffer In Valid<br>Each bit represent the status of the corresponding input FIFO.<br>0: Empty<br>1:Message available |
| **BI_DEC**     | 010       | 31:0| WO  | Buffer In Decrement<br>Each bit corresponds with an input FIFO.<br>Writing 1 releases the current message from FIFO.<br>Writing 0 is ignored. |
| **BO_FULL**    | 020       | 31:0| RO  | Buffer Out Full<br>Each bit represent the status of the corresponding output FIFO.<br>0: Space left to write a message<br>1:FIFO full |
| **BO_INC**     | 030       | 31:0| WO  | Buffer Out Decrement<br>Each bit corresponds with an input FIFO.<br>Writing 1 releases the current message from FIFO.<br>Writing 0 is ignored. |
| **BO_TARGETS**  | 040   | 31:0| RW  | Intended Output Targets<br>Each bit corresponds with an Output Buffer.<br>Writing to this register updates **BO_STORE** and **BO_BUSY**.<br>When reading this register, the written value mask by **BO_FULL** is provided. After reading **BO_STORE** this register is undefined.<br>Note: In case of more than 32 output buffers CPU has to handled the buffers in chunks sequentially. There is no hardware support for this. |
| **BO_STORE**    | 044   | 31:0| RO  | Output Target to store<br>This value is the decimal number of the next available output target. Full output buffers are excluded. If there are no remaining targets, the read value is -1 (0xffffffff). |
| **BO_BUSY**     | 048   | 31:0| RO  | Output Target busy<br>This value is the decimal number of the next full output target. If there are no remaining targets, the read value is -1 (0xffffffff). |
| **BI_FETCH**    | 050   | 31:0| RO  | Input Target to process<br>This value is the decimal number of the next available input buffer in **BI_VALID**. The search starts after the last read buffer number. If there is no valid buffer, the read value is -1 (0xffffffff). |
| **BI_LAST**     | 054   | 31:0| RO  | Last read input target.<br>This value is updated when read a valid buffer from **BI_FETCH**.<br>*For architecture evaluation only, not part of final IP.* |
| **BINFO.COUNT**    | 0FC   |  15:8 | RO  | Buffer Count<br>This number represents the number of supported Input and Output Buffers. |
| **BINFO.BUFDEPTH** | 0FC   |   7:0 | RO  | Buffer Depth<br>This number is the maximal valid buffer depth to be configured in **BI_INFO.MAX**. |
| **BI_INFO.CNT**  | 200~3FC | 31:16 | RO  | Messages inside Input Buffer<br>This value is incremented when the corresponding adaptor commits a message.<br>This value is decremented when CPU writes the corresponding bit to **BI_DEC**.<br>*For architecture evaluation only, not part of final IP.*|
| **BI_INFO.MAX**  |         | 31:16 | RW  | Maximum number of messages in Input Buffer to reach full.<br>When this value is 5, up to 5 messages can be stored by Adaptor before full is flagged.|
| **BO_INFO.CNT**  | 400~7FC | 31:16 | RO  | Messages inside Output Buffer<br>This value is incremented when CPU writes the corresponding bit to **BO_INC**.<br>This value is decremented when the corresponding adaptor consumed a message.<br>*For architecture evaluation only, not part of final IP.*|
| **BO_INFO.MAX**  |         | 15:0 | RW  | Maximum number of messages in Output Buffer to reach full.<br>When this value is 5, up to 5 messages can be stored by CPU before full is flagged.|

The parameter N depends on the total buffer RAM size. It represent the required address bits for both, input and output buffer.

The SFR layout allows to map 128 input and output buffers. Currently 32 are implemented.


## Basic function of the buffer control module

![Block diagram Buffer Control Module](docu/buffercrtl.svg "Block diagram Buffer Control Module")

A input full generation based on BI_INFO.MAX is not used for python side. This would
require additional python interfacing for an information already available.

How to utilise the input and output buffer RAM and how to organise the FIFOs is up
to the C and python code. This module provides only a synchronisation mechanism as
it is used in a typical hardware implementation.


## Enhanced buffer handling

There is a bin2dec acceleration inside this module. It is not required for the
basic function.

This function allows to have a quicker buffer status check but limits also the
possible structure of the C-Code. In a first check the bin2dec conversion for
output buffers saves in case of 32 buffers about 50 CPU clock cycles (0.5 µs).


