# Inter Processor Communication (IPC) support

## Mailbox/FIFO support for 1:1 communication

This function is available locally for each PE.

PE in TUBE intended to run without any interrupts. A consuming PE polls on IPC until
a job becomes available. To minimise bus load, the polling shall happen on consumers
IPC unit. The requester PE shall write into the IPC of the consuming PE.


### SFR

| Name           | Base Address       | Description         |
|----------------|--------------      |------------         |
| IPC_SELF       | 0003_FF00          | Access my local IPC |
| IPC_p          | 0007_FF00+4_0000*p | Access IPC of PE p  |

Note: A PE can access its own IPC by IPC_p but this should be prevented
because it goes over the main interconnect.


| Name           | Offset    | Bits  | Mode| Description |
|----------------|---------- |-----  |---- |------------ |
| **IPC_PUTi**   | 000+10*i  |  31:0 | WR  | Write of any value increases **IPC_VALUEi**  by 1. Write is ignored if max value already reached. The read value is undefined.<br> It is recommended to write 0 for code generation. |
| **IPC_GETi**   | 004+10*i  |  31:0 | RO  | Read provides the current **IPC_VALUEi** and decrease if it was not 0. Write to this register is ignored. |
| **IPC_VALUEi** | 008+10*i  |  31:0 | RO  | Read provides the current **IPC_VALUEi**. Write to this register is ignored.<br>*For debug purpose only* |
| **IPC_MAXi**   | 00C+10*i  |  31:0 | RO  | Maximum number **IPC_VALUEi** can reach.<br>*For debug purpose only* |


### Prototypes

Available in `ra_adrmap.h`

```c
enum e_pe_index {PE_SELF=-1, PE0, PE1, PE2, PE3, PE4, PE5, PE6, PE7};
#define IPC_CHANNELS 4

#define IPC_PUT(pe, ch) (*(volatile uint32_t *)( 0x7FF00 + (pe)*0x40000 + (ch)*0x10 ))
#define IPC_GET(pe, ch) (*(volatile uint32_t *)( 0x7FF04 + (pe)*0x40000 + (ch)*0x10 ))
#define IPC_VAL(pe, ch) (*(volatile uint32_t *)( 0x7FF08 + (pe)*0x40000 + (ch)*0x10 ))
#define IPC_MAX(pe, ch) (*(volatile uint32_t *)( 0x7FF0C + (pe)*0x40000 + (ch)*0x10 ))

inline void ipc_request(int pe, int channel)
{
   IPC_PUT(pe, channel) = 0; //value don't care
}
```

### Usage Idea

The IPC counter provide a mechanism transferring an information from one PE or process to
another PE. The implementation as counter allows communication without back-channel as
long no counter overflow can happen.

On requester side PE:
- Fill a shared data structure like buffer of software FIFO
- Issue write to the IPC channel c of the consuming PE p by `IPC_PUT(p,c)`

On consumer side PE:
- Check on local IPC channel c if a job is pending by `IPC_get(PE_SELF,c) != 0`
- Process the information from the shared data structure
