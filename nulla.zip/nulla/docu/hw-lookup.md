# Lookup

This block handles table lookup for frame classification. It allows a binary
lookup inside a sorted table *O(log N)* and a linear search inside a table
with free masks *O(N)*.

The lookup table consists of three components:
* A control filed (**CTRL**) defining the table structure and format.
* A sorted table (optional)
* A linear table (optional, not supported for all formats).

If both tables exists inside a lookup table, the result from the
sorted table has higher priority.
Lookup result is the matching table entry number, which continuously
counts over the sorted and linear table entries. In case of no match
-1 is provided.


![Lookup table](docu/lookup-table.svg "Lookup table")

There are formats for generic 8, 16, 32, 48, and 64 bit lookup.

There are specific formats for 11-bit and 29-bit CAN Id lookup
considering the CAN protocol dependency (CC, FD).

Table entries have either 4 or 8 bytes. Gaps inside the entries
can be used freely for other purpose.


## Table utilisation

To achieve best performance, it is recommended to use the sorted
table as much as possible.

Example of 32-bit entry search: \
Sorted lookup inside a 1000 entry table takes 32 clock cycles. \
Linear lookup inside a 30 entry table takes 32 clock cycles. \
If both searches are used in the same table it takes 42 clock cycles
(both searches executed partly overlap, the linear search can use
two cycles during each sorted lookup).

It can be assumed, that linear search below 20 32-bit entries or 10 64-bit
entries does not lengthen the lookup time significantly.

Attention: There should be no overlap of the ranges inside the sorted list
to get a deterministic behaviour. Overlapping configurations have to split
into sub-ranges. For example `id=0x123, range=0x120..0x12f` split into
`range=0x120..0x122, id=0x123, range=0x124..0x123f`.


### Handling of right aligned masks

Mask values lookup cannot be sorted in general. For example
`val=0x1234 mask=0xffef` result is a match at 0x1224 and 0x1234. There
may other values between.

Right aligned masks can be converted into ranges and becomes sortable.
For example `id=0x1234, mask=0xfff0` matches for `range=0x1230..0x123f`.

In case the linear list with mask values is too long, it could be
possible to split the entries to become sorted. For example
`id=0x1234, mask=0xf7ff` can be converted into this two sorted entries
`id=0x1230` and `id=0x1a34`. This can be combined with right aligned
masks: `id=0x1234, mask=0xf7f0` can be converted into `range=0x1230..0x123f`
and `range=0x1a30..0x1a3f`.

Intention is to have a tool doing this conversion during compile time.


## SFR definition

| Name           | Offset | Bits  | Mode| Description |
|----------------|------- |-----  |---- |------------ |
| **VALL**       | 000    |  31:0 | WR  | Value Low<br>Lower 32-bit of lookup value.<br>*Reading is for architecture evaluation only and will not part of final module.* |
| **VALH**       | 004    |  31:0 | WR  | Value HI<br>Upper 32-bit of lookup value.<br>In case of lookup formats <= 32 bit, the value inside this register is ignored.<br>*Reading is for architecture evaluation only and will not part of final module. |
| **TABADDR**    | 008    |  31:0 | WR  | Address of table.<br>The bits [1:0] are always written as 0. Upper bits outside the Data RAM are ignored.<br>Software should not configure tables wapping around the Data RAM size.<br>Writing to this register starts the lookup process.<br>*Reading is for architecture evaluation only and will not part of final module. The read value is either the written value or the incremented value by 4.* |
| **STAT.BUSY**  | 00C    |    31 |  RO | Busy<br>0: Lookup engine idle<br>1: Lookup ongoing |
| **STAT.FOUND** |        |    30 |  RO | Entry found<br>0: Not found<br> 1: Found<br>This bit is undefined while lookup is ongoing (**STAT.BUSY**==1) |
| **STAT.ERROR** |        |    29 |  RO | ECC Error during search<br>This bit is undefined while lookup is ongoing (**STAT.BUSY**==1) |
| **STAT.FOUND** |        |  15:0 |  RO | Found entry number<br>Result in range 0 to (**CTRL.SENUM** + **CTRL.LENUM** -1) indicates a table match. The number 0xffff (-1) indicates no entry found.<br>This bit is undefined while lookup is ongoing (**STAT.BUSY**==1) |
| **PERF**       | 010    | 31:0  | RW  | Monitors the stalls during lookup<br>Write clears this register.<br>*For architecture evaluation only.* |


### Lookup value definition

The search value is provided by **VALL** and **VALH**. The utilisation
of these registers is format specific (**CTRL.FORMAT**).

![Lookup SFR value definition](docu/lookup-value.svg "Lookup SFR value definition")


### CAN Id specific lookup

Format 0 (FORMAT_ID11) and 4 (FORMAT_ID29) allows a CAN protocol version
dependent lookup. The bits **VALL.FD** and **VALL.CC** define the protocol
version of the CAN frame. Exactly one bit should be set.
The **VALL.GAP** bit is ignored by the lookup.


## Table outline

To minimize CPU load, all table specific configurations are part of the
table itself.
The configured **TABADDR** points to the control word **CTRL** at
the top of a lookup table.


### Table Control word

| Name           | Offset           | Bits  | Description |
|----------------|----------------- |------ |------------ |
| **CTRL.FMT**   | **TABADDR* + 000 | 31:28 | Format of this lookup |
| **CTRL.LENUM** |                  | 23:16 | Number of entries inside the table.<br>0: No linear list entry present<br>1..255 Number of linear list entries. |
| **CTRL.SENUM** |                  |  11:0 | Number of entries inside the sorted table.<br>0: No sorted list entry present<br>1..4047: Number of sorted list entries. |


### Table entry outline

For the lookup these formats are available. If a format is defined
for sorted and linar lookup table, both can be combined in the same
table.

![Table entry formats](docu/lookup-format.svg "Table entry formats")

### CAN Id related Protocol control field

For CAN Identifier lookup a three bit **FD**, **CC**, **M** are defined.
This allows to assign an entry either to CC, FD, or both.

In case of sorted list, there could be two separate entries for CC and FD
relating to the same identifier. Both entries should be placed with
CC related entry first.

| FD CC M | Description
|-------  |-------------
| 0 1 0   | match for CC
| 0 1 1   | match for CC, FD related check in next entry
| 1 0 0   | match for FD
| 1 0 1   | match for FD, CC related check in previous entry
| 1 1 0   | match for CC+FD
| others  | Reserved (0, 1, 7)


### Sorted lookup table entries

The sorted entries is placed directly after the **CTRL** word of the table.

The first entry of the sorted table returns the index 0 in **STAT.FOUND**
when matching.

The first entry shall contain the smallest value and the the table
shall have no overlapping range definitions.

If there is a match in this table, the lookup result from linear lookup
table is ignored.


### Linear list

The linear entries is placed directly after the last sorted entry. In case
there are no sorted entries, it starts after **CTRL** word of the table.

There are no requirements to the entry order in linear list.

The **M** field is not existing inside the linear lookup entries, there is
no requirement how to place individual CC, FD entries related to the same
CAN Id.


## Usage examples

For the 32 bit formats (<= FORMAT_ID29) use this sequence.

```c
uint32_t value;
uint32_t lookup_table[DEPTH+1];
[...]
lup_value[0] = value;
lup_table = lookup_table;  //This starts the search
//Do something meaningful independent from lookup result
//Search takes about 30 clock cycles
while (lup_status&0x80000000);
printf("found is %d\n", lup_found);
```

For the 64 bit formats (> FORMAT_ID29) use this sequence.

```c
uint64_t value;
uint32_t lookup_table[DEPTH*2+1];
[...]
lup_value[0] = value;
lup_table = lookup_table;  //This starts the search
//Do something meaningful independent from lookup result
//Search takes about 30 clock cycles
while (lup_status&0x80000000);
printf("found is %d\n", lup_found);
```

For the hardware support the type of `lookup_table` is don't care.
A real application would for example provide the address of
a structure encapsulate the table header and the search array.


Example for an action table. It assumes that there is a 'default'
action in the first entry used in case of no table match. As
long there is no interleaving search and the results is rarely used,
there is no strong requirement
to copy `lup_found` into a temporary variable.

```c
struct s_actionTable action_table[DEPTH+1]
struct s_actionTable *action;
[...]
action = action_table[lup_found+1];
```


## Timing (tentative)

The *binary* search on a sorted list takes:

* 2 clock cycles for setup
* 3 clock cycles for each lookup in 32-bit format
* 4 clock cycles for each lookup in 64-bit format

The number of lookups depend on the sorted list size it is `log(entries)`.
For example 3 lookups in case of 7 entries, 4 lookups in case of 8 entries,
or 0 lookup in case of 0 entries (only the setup phase).

The *linear* search on a random list takes:

* 5 clock cycle for setup
* 1 clock cycles for each lookup in 32-bit format
* 2 clock cycles for each lookup in 64-bit format

The number of lookups depends on the linear list size; it is `N`.

If *binary* and *linear* entries exists inside a table, the search is
executed in parallel. Means the linear search make use of the 2 gaps
within each binary lookup. The linear
search is aborted when there is a sorted match.

In all cases, CPU accesses (read/write) are processed with higher priority.
This means the search time is lengthen by the number of interfered DRAM
accesses. The RAM utilization of binary search 33% respective 50%, in some
cases CPU side access have visible impact. In case of linear search the
RAM utilization is 100%.


## Recommended usage of the table formats

### Specific lookup

1. CAN Base Identifier
   - 11-bit lower and 11-bit upper value and 3-bit format
2. CAN Extended Identifier
   - 29-bit lower and 29-bit upper value and 3-bit format

### Generic lookup
1. Generic 16-bit lookup
   - Ethernet EthType and XL PriorityId (sorted)
   - XL Protocol (SDT and VCID) and Ethernet VLAN (linear with mask)
2. Generic 32-bit lookup
   - XL Acceptance field
3. Generic 48-bit lookup
   - Ethernet MAC
4. Generic 64-bit lookup
   - 1722 StreamId
