# Address map of TUBE and environment


## TUBE internal address view

| Name               | Start       | End           | Access  | Description |
|------------------- |------------ |----------     |-------- |------------ |
| **CODERAM** (self) | 0000_0000   | 0001_FEFC     | 8/16/32 | 128 kByte local PE-RAM of *this* PE. Can be used for code and data. <br>The local PE itself is arbitrated with highest priority. |
| **IPC** (self)     | 0003_FF00   | 0003_FFFC     | 32      | Inter Processor Communication (IPC) function of *this* PE. See [hw-ipc.md] |
| **CODERAM_PEi**    | 0004_0000*i | 0005_FFFC+i*o | 8/16/32 | 128 kByte local PE-RAM and peripherals of *any* PEi. <br>Arbitrated with low priority.
| **DATARAM**        | 0020_0000   | 0021_FFFC     | 8/16/32 | 128 kByte global data RAM for common data and configuration. <br>Arbitrated round robin. |
| **BUFRAM0**        | 0040_0000   | 0041_FFFC     | 32      | 128 kByte global data RAM intended for input buffering. <br>Support big-endian access at address offset of 08_0000<br>Arbitrated round robin. |
| **BUFRAM1**        | 0050_0000   | 0051_FFFC     | 32      | 128 kByte global data RAM intended for output buffering. <br>Support big-endian access at address offset of 08_0000<br>Arbitrated round robin. |
| **EXT**            | 00FF_B000   | 00FF_B0FC     | 32      | External signalling. See [hw-external-status.md] |
| **LUP**            | 00FF_C000   | 00FF_C0FC     | 32      | Lookup accelerator. See [hw-lookup.md] |
| **DCM**            | 00FF_D000   | 00FF_D0FC     | 32      | Data duplication accelerator between Buffer RAMs. See [hw-duplicator.md] |
| **BUF**            | 00FF_E000   | 00FF_E0FC     | 32      | Buffer handling accelerator. See [hw-bufferctrl.md] |
| **IO**             | 00FF_F000   | 00FF_F0FC     | 32      | Debug purpose like simulation IO and EXIT control. |
| **EXTERN**         | 0100_0000   | FFFF_FFFC     | 8/16/32 | Mapped 1:1 to the address space of surrounding MCU.<br>MCU's address map supported by simulation environment is listed below. |


o in End address is the same offset as used in start address.

## TUBE external address view

| Name               | Start              | End           | Access  | Description |
|------------------- |-----------------   |-------------- |-------- |------------ |
| **RSCANFDi**       | FF80_0000+i*2_0000 | FF80_FFFC+i*o     | 8/16/32 | As per U2C spec. 2 Modules of 8 channels. Only Rx-FIFO, COM-FIFO2, and TXQ3 of each channel is in model. |
| **ETNFi**          | FF1D_0000+i*1000   | FF1D_0FFC+i*o | 8/16/32 | As per U2C spec. 8 Channels implemented. Only VRR (Version register). |
| **ETNDi**          | FF94_0000+i*1_0000 | FF94_FFFC+i*o | 8/16/32 | As per U2C spec. 2 Channels implemented. Only RGC (reset value used as version register). |
| **SRAM**           | FE00_0000         |  FE01_FFFC     | 8/16/32 | As per U2C spec. Only 128 kByte implemented. |

o in End address is the same offset as used in start address.

