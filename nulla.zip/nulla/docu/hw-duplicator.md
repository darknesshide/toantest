# Buffer Duplicator

This block is direct attached to the buffer memory and allows fast duplication
from input buffers to output buffers.

The addresses written to this modules are relative to the buffer memory. Because
the module implements only the physical available addresses, the address used
by CPU can be written without masking.

The transfer time is deterministic and described by this formula:

``t_copy = (2 + (T*N) + C) * t_clock``

T: Number of Targets (as per **DAi**)<br>
N: Number of 4-bytes words (as per **LEN**)<br>
C: Concurrent CPU accesses to input buffer RAM

CPU accesses to input buffer RAM allowed and executed with higher priority. This enables software starting with next frame classification while copy is ongoing.


## SFR definition

| Name       | Offset| Bits| Mode| Description |
|------------|------ |-----|---- |------------ |
| **RTAi**    | 00~7F | 31:0| RW  | Ram Target address i<br>Write sets target count **STAT.TC** to i.<br>Protected when **STAT.TO** is 1.<br>Bits [31:24], [22:N], and [1:0] are always written as 0.<br>This value becomes undefined if the transfer has started.<br>*Endian Conversion*: In correspondence to the output buffer memory, there is a byte endian correction when using the upper page of input buffer address space. |
| **RSA**     | 80    | 31:0| RW  | Ram Source address i<br>Protected when **STAT.TO** is 1.<br>Bits [31:24], [22:N], and [1:0] are always written as 0.<br>This value becomes undefined if the transfer has started.<br>*Endian Conversion*: In correspondence to the input buffer memory, there is a byte endian correction when using the upper page of input buffer address space.|
| **LEN**    | 84    | 11:0| RW  | Transfer length<br>Transfer processes **LEN** bytes from **RSA** to all **RTAi** (i=0 to **STAT.TC**). The transfer happens in 4-byte words.<br>The transfer starts and **STAT.TO** is set to 1 when write to this register<br>Only numbers from 4 to 2048 are valid.<br>Bits [1:0] are always written as 0.<br>Protected when **STAT.TO** is 1.<br>This value becomes undefined if the transfer has started. |
| **STAT.TO**| 88    | 31  | RO  | Transfer is ongoing<br>Set when writing to **LEN**.<br>Clear when all transfers are done.|
| **STAT.UF**|       | 17  | RW  | Usage fault<br>Set when writing to **RTAi**, **RSA**, **LEN** while transfer is ongoing.<br>Clear by writing 1<br>*For architecture evaluation only, not part of final IP.*|
| **STAT.DE**|       | 16  | RW  | Data Error<br>Set when uncorrected ECC error reported during input buffer read,<br>Clear by writing 1 |                                                                   |
| **STAT.TC**|       | 4:0 | RO  | Transfer copies<br>Updated when write to **RTAi**. |
| **PERF**   | 8C    | 31:0| WR  | Monitors the stalls during transfer<br>Write clears this register.<br>*For architecture evaluation only. |

The parameter N depends on the total buffer RAM size (currently 17). It represent the required address bits for both, input and output buffer.

*TBD*: May be it would helpful to set a bit in buffer control module (correspond to input buffer data valid) to accelerate arbitration between "input buffer process start" and "data copy done" task.


## Endian conversion

There is an endian conversion for the input buffer memory. It is placed on a shadow address area (+ 0x8_0000). This reduces the theoretical maximum memory size from 1 MByte to 512 kByte.

| Address | Description |
|---------|-------------|
| 0060_0000 | Start of input buffer RAM (currently 0000_0000-0001_FFFC). Default endian (little). |
| 0068_0000 | Start of input buffer RAM (currently 0008_0000-0009_FFFC). Inverted endian (big). |
| 0070_0000 | Start of output buffer RAM (currently 0000_0000-0001_FFFC). Default endian (little). |
| 0078_0000 | Start of output buffer RAM (currently 0008_0000-0009_FFFC). Default endian (big). |


## Limitations

* It is not allow to write to output buffer RAM by software while a transfer
  is ongoing. Reading from input buffer RAM is fine.


## Usage example

The symbols for the hardware register access are part of `ra_adrmap.h`.

Writing to `dc_sa[i]` in ascending order is strongly recommended, because the last written index defines the number of copies. The write to `dc_sa` can be done before, during or after the destination addresses.

Instead of waiting directly after the write lo `dcm_len`, which starts the copy process, some more useful things can be done in software. It is recommended to place the waiting loop to the latest position inside the software flow.

~~~c
//Perform a 1:1 copy
dcm_da[0] = outputFifoAddress;
dcm_sa = inputFifoAddress;
dcm_len = copyByteCount;
while (dcm_stat_to);
~~~

Using the byte representation of of `dcm_stat_to` instead of a bit
mask `dcm_stat&0x80000000` results in more efficient code.

~~~c
//Perform a 1:8 copy
dcm_da[0] = outputFifoAddressArray[0];
dcm_da[1] = outputFifoAddressArray[1];
dcm_da[2] = outputFifoAddressArray[2];
dcm_da[3] = outputFifoAddressArray[3];
dcm_da[4] = outputFifoAddressArray[4];
dcm_da[5] = outputFifoAddressArray[5];
dcm_da[6] = outputFifoAddressArray[6];
dcm_da[7] = outputFifoAddressArray[7];
dcm_sa = inputFifoAddress;
dcm_len = copyByteCount;
while (dcm_stat_to);
~~~

It is a good approach to write the destination addresses from a loop and not in one go.
~~~c
da = dcm_da;
dcm_sa = inputFifoAddress;
while (...) {
   ...
   *(da++) = outputFifoAddressArray[i];
   ...
}
dcm_len = copyByteCount;
...
while (dcm_stat_to);
~~~


## Points to be confirmed

1. How to handle ECC problems during?<br>
   Check a bit at STAT before release the buffer copy.<br>
   Idea is to continue the copy as normal and only record the issue.
   In error case count the problem and ignore all copies (it is a problem of source).
2. Is the SFR layout efficient?<br>
   Assumption is that combination of 8-bit access and check on zero is as
   fast as 32-bit access.
3. Merge duplicator and buffer management SFR?<br>
   A stand alone SFR would allow a common "bit to number" translation with different
   priorities corresponding to the software tasks.<br>
   To implement overlapped software processing, this may require some mask bits to mark postpone input buffers until search and copy is done. On the other hand software can start next classification while copy is ongoing.
   More than 1 copy unit is not beneficial as the first one already utilise the RAM by 100%
   * Input buffer i valid (up to 32)
   * Search i done (up to 4)
   * Copy done (fixed 1)
5. Would it be helpful to round up **LEN** when write a not 4 byte aligned size?
6. Would it be helpful to add a **LEN32** register? For example 1722 have only word length numbers, software does not need to code *4.
